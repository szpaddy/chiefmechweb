package org.springframework.scheduling;

import java.util.Date;

public abstract interface TriggerContext
{
  public abstract Date lastScheduledExecutionTime();

  public abstract Date lastActualExecutionTime();

  public abstract Date lastCompletionTime();
}

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.TriggerContext
 * JD-Core Version:    0.6.0
 */