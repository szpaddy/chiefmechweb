/*     */ package org.springframework.scheduling.concurrent;
/*     */ 
/*     */ import java.util.Date;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.Executor;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Future;
/*     */ import java.util.concurrent.RejectedExecutionException;
/*     */ import java.util.concurrent.RejectedExecutionHandler;
/*     */ import java.util.concurrent.ScheduledExecutorService;
/*     */ import java.util.concurrent.ScheduledFuture;
/*     */ import java.util.concurrent.ScheduledThreadPoolExecutor;
/*     */ import java.util.concurrent.ThreadFactory;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import org.springframework.core.task.TaskRejectedException;
/*     */ import org.springframework.scheduling.SchedulingTaskExecutor;
/*     */ import org.springframework.scheduling.TaskScheduler;
/*     */ import org.springframework.scheduling.Trigger;
/*     */ import org.springframework.scheduling.support.TaskUtils;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ErrorHandler;
/*     */ 
/*     */ public class ThreadPoolTaskScheduler extends ExecutorConfigurationSupport
/*     */   implements TaskScheduler, SchedulingTaskExecutor
/*     */ {
/*     */   private volatile int poolSize;
/*     */   private volatile ScheduledExecutorService scheduledExecutor;
/*     */   private volatile ErrorHandler errorHandler;
/*     */ 
/*     */   public ThreadPoolTaskScheduler()
/*     */   {
/*  55 */     this.poolSize = 1;
/*     */   }
/*     */ 
/*     */   public void setPoolSize(int poolSize)
/*     */   {
/*  67 */     Assert.isTrue(poolSize > 0, "'poolSize' must be 1 or higher");
/*  68 */     this.poolSize = poolSize;
/*     */   }
/*     */ 
/*     */   public void setErrorHandler(ErrorHandler errorHandler)
/*     */   {
/*  75 */     Assert.notNull(errorHandler, "'errorHandler' must not be null");
/*  76 */     this.errorHandler = errorHandler;
/*     */   }
/*     */ 
/*     */   protected ExecutorService initializeExecutor(ThreadFactory threadFactory, RejectedExecutionHandler rejectedExecutionHandler)
/*     */   {
/*  82 */     this.scheduledExecutor = createExecutor(this.poolSize, threadFactory, rejectedExecutionHandler);
/*  83 */     return this.scheduledExecutor;
/*     */   }
/*     */ 
/*     */   protected ScheduledExecutorService createExecutor(int poolSize, ThreadFactory threadFactory, RejectedExecutionHandler rejectedExecutionHandler)
/*     */   {
/* 100 */     return new ScheduledThreadPoolExecutor(poolSize, threadFactory, rejectedExecutionHandler);
/*     */   }
/*     */ 
/*     */   public ScheduledExecutorService getScheduledExecutor()
/*     */     throws IllegalStateException
/*     */   {
/* 109 */     Assert.state(this.scheduledExecutor != null, "ThreadPoolTaskScheduler not initialized");
/* 110 */     return this.scheduledExecutor;
/*     */   }
/*     */ 
/*     */   public void execute(Runnable task)
/*     */   {
/* 117 */     Executor executor = getScheduledExecutor();
/*     */     try {
/* 119 */       executor.execute(errorHandlingTask(task, false));
/*     */     }
/*     */     catch (RejectedExecutionException ex) {
/* 122 */       throw new TaskRejectedException("Executor [" + executor + "] did not accept task: " + task, ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void execute(Runnable task, long startTimeout) {
/* 127 */     execute(task);
/*     */   }
/*     */ 
/*     */   public Future<?> submit(Runnable task) {
/* 131 */     ExecutorService executor = getScheduledExecutor();
/*     */     try {
/* 133 */       return executor.submit(errorHandlingTask(task, false));
/*     */     } catch (RejectedExecutionException ex) {
/*     */     }
/* 136 */     throw new TaskRejectedException("Executor [" + executor + "] did not accept task: " + task, ex);
/*     */   }
/*     */ 
/*     */   public <T> Future<T> submit(Callable<T> task)
/*     */   {
/* 141 */     ExecutorService executor = getScheduledExecutor();
/*     */     try {
/* 143 */       if (this.errorHandler != null) {
/* 144 */         task = new DelegatingErrorHandlingCallable(task, this.errorHandler);
/*     */       }
/* 146 */       return executor.submit(task);
/*     */     } catch (RejectedExecutionException ex) {
/*     */     }
/* 149 */     throw new TaskRejectedException("Executor [" + executor + "] did not accept task: " + task, ex);
/*     */   }
/*     */ 
/*     */   public boolean prefersShortLivedTasks()
/*     */   {
/* 154 */     return true;
/*     */   }
/*     */ 
/*     */   public ScheduledFuture schedule(Runnable task, Trigger trigger)
/*     */   {
/* 161 */     ScheduledExecutorService executor = getScheduledExecutor();
/*     */     try {
/* 163 */       ErrorHandler errorHandler = this.errorHandler != null ? this.errorHandler : TaskUtils.getDefaultErrorHandler(true);
/*     */ 
/* 165 */       return new ReschedulingRunnable(task, trigger, executor, errorHandler).schedule();
/*     */     } catch (RejectedExecutionException ex) {
/*     */     }
/* 168 */     throw new TaskRejectedException("Executor [" + executor + "] did not accept task: " + task, ex);
/*     */   }
/*     */ 
/*     */   public ScheduledFuture schedule(Runnable task, Date startTime)
/*     */   {
/* 173 */     ScheduledExecutorService executor = getScheduledExecutor();
/* 174 */     long initialDelay = startTime.getTime() - System.currentTimeMillis();
/*     */     try {
/* 176 */       return executor.schedule(errorHandlingTask(task, false), initialDelay, TimeUnit.MILLISECONDS);
/*     */     } catch (RejectedExecutionException ex) {
/*     */     }
/* 179 */     throw new TaskRejectedException("Executor [" + executor + "] did not accept task: " + task, ex);
/*     */   }
/*     */ 
/*     */   public ScheduledFuture scheduleAtFixedRate(Runnable task, Date startTime, long period)
/*     */   {
/* 184 */     ScheduledExecutorService executor = getScheduledExecutor();
/* 185 */     long initialDelay = startTime.getTime() - System.currentTimeMillis();
/*     */     try {
/* 187 */       return executor.scheduleAtFixedRate(errorHandlingTask(task, true), initialDelay, period, TimeUnit.MILLISECONDS);
/*     */     } catch (RejectedExecutionException ex) {
/*     */     }
/* 190 */     throw new TaskRejectedException("Executor [" + executor + "] did not accept task: " + task, ex);
/*     */   }
/*     */ 
/*     */   public ScheduledFuture scheduleAtFixedRate(Runnable task, long period)
/*     */   {
/* 195 */     ScheduledExecutorService executor = getScheduledExecutor();
/*     */     try {
/* 197 */       return executor.scheduleAtFixedRate(errorHandlingTask(task, true), 0L, period, TimeUnit.MILLISECONDS);
/*     */     } catch (RejectedExecutionException ex) {
/*     */     }
/* 200 */     throw new TaskRejectedException("Executor [" + executor + "] did not accept task: " + task, ex);
/*     */   }
/*     */ 
/*     */   public ScheduledFuture scheduleWithFixedDelay(Runnable task, Date startTime, long delay)
/*     */   {
/* 205 */     ScheduledExecutorService executor = getScheduledExecutor();
/* 206 */     long initialDelay = startTime.getTime() - System.currentTimeMillis();
/*     */     try {
/* 208 */       return executor.scheduleWithFixedDelay(errorHandlingTask(task, true), initialDelay, delay, TimeUnit.MILLISECONDS);
/*     */     } catch (RejectedExecutionException ex) {
/*     */     }
/* 211 */     throw new TaskRejectedException("Executor [" + executor + "] did not accept task: " + task, ex);
/*     */   }
/*     */ 
/*     */   public ScheduledFuture scheduleWithFixedDelay(Runnable task, long delay)
/*     */   {
/* 216 */     ScheduledExecutorService executor = getScheduledExecutor();
/*     */     try {
/* 218 */       return executor.scheduleWithFixedDelay(errorHandlingTask(task, true), 0L, delay, TimeUnit.MILLISECONDS);
/*     */     } catch (RejectedExecutionException ex) {
/*     */     }
/* 221 */     throw new TaskRejectedException("Executor [" + executor + "] did not accept task: " + task, ex);
/*     */   }
/*     */ 
/*     */   private Runnable errorHandlingTask(Runnable task, boolean isRepeatingTask)
/*     */   {
/* 226 */     return TaskUtils.decorateTaskWithErrorHandler(task, this.errorHandler, isRepeatingTask);
/*     */   }
/*     */ 
/*     */   private static class DelegatingErrorHandlingCallable<V> implements Callable<V>
/*     */   {
/*     */     private final Callable<V> delegate;
/*     */     private final ErrorHandler errorHandler;
/*     */ 
/*     */     DelegatingErrorHandlingCallable(Callable<V> delegate, ErrorHandler errorHandler) {
/* 237 */       this.delegate = delegate;
/* 238 */       this.errorHandler = errorHandler;
/*     */     }
/*     */ 
/*     */     public V call() throws Exception {
/*     */       try {
/* 243 */         return this.delegate.call();
/*     */       }
/*     */       catch (Throwable t) {
/* 246 */         this.errorHandler.handleError(t);
/* 247 */       }return null;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler
 * JD-Core Version:    0.6.0
 */