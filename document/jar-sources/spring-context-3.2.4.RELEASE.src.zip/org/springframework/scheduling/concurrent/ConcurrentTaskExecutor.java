/*     */ package org.springframework.scheduling.concurrent;
/*     */ 
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.Executor;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.Future;
/*     */ import org.springframework.core.task.support.TaskExecutorAdapter;
/*     */ import org.springframework.scheduling.SchedulingTaskExecutor;
/*     */ 
/*     */ public class ConcurrentTaskExecutor
/*     */   implements SchedulingTaskExecutor
/*     */ {
/*     */   private Executor concurrentExecutor;
/*     */   private TaskExecutorAdapter adaptedExecutor;
/*     */ 
/*     */   public ConcurrentTaskExecutor()
/*     */   {
/*  60 */     setConcurrentExecutor(null);
/*     */   }
/*     */ 
/*     */   public ConcurrentTaskExecutor(Executor concurrentExecutor)
/*     */   {
/*  69 */     setConcurrentExecutor(concurrentExecutor);
/*     */   }
/*     */ 
/*     */   public final void setConcurrentExecutor(Executor concurrentExecutor)
/*     */   {
/*  77 */     this.concurrentExecutor = (concurrentExecutor != null ? concurrentExecutor : Executors.newSingleThreadExecutor());
/*     */ 
/*  79 */     this.adaptedExecutor = new TaskExecutorAdapter(this.concurrentExecutor);
/*     */   }
/*     */ 
/*     */   public final Executor getConcurrentExecutor()
/*     */   {
/*  86 */     return this.concurrentExecutor;
/*     */   }
/*     */ 
/*     */   public void execute(Runnable task)
/*     */   {
/*  91 */     this.adaptedExecutor.execute(task);
/*     */   }
/*     */ 
/*     */   public void execute(Runnable task, long startTimeout) {
/*  95 */     this.adaptedExecutor.execute(task, startTimeout);
/*     */   }
/*     */ 
/*     */   public Future<?> submit(Runnable task) {
/*  99 */     return this.adaptedExecutor.submit(task);
/*     */   }
/*     */ 
/*     */   public <T> Future<T> submit(Callable<T> task) {
/* 103 */     return this.adaptedExecutor.submit(task);
/*     */   }
/*     */ 
/*     */   public boolean prefersShortLivedTasks()
/*     */   {
/* 110 */     return true;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.concurrent.ConcurrentTaskExecutor
 * JD-Core Version:    0.6.0
 */