/*     */ package org.springframework.scheduling.concurrent;
/*     */ 
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.RejectedExecutionHandler;
/*     */ import java.util.concurrent.ScheduledExecutorService;
/*     */ import java.util.concurrent.ScheduledThreadPoolExecutor;
/*     */ import java.util.concurrent.ThreadFactory;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.scheduling.support.DelegatingErrorHandlingRunnable;
/*     */ import org.springframework.scheduling.support.TaskUtils;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ public class ScheduledExecutorFactoryBean extends ExecutorConfigurationSupport
/*     */   implements FactoryBean<ScheduledExecutorService>
/*     */ {
/*  67 */   private int poolSize = 1;
/*     */   private ScheduledExecutorTask[] scheduledExecutorTasks;
/*  71 */   private boolean continueScheduledExecutionAfterException = false;
/*     */ 
/*  73 */   private boolean exposeUnconfigurableExecutor = false;
/*     */   private ScheduledExecutorService exposedExecutor;
/*     */ 
/*     */   public void setPoolSize(int poolSize)
/*     */   {
/*  83 */     Assert.isTrue(poolSize > 0, "'poolSize' must be 1 or higher");
/*  84 */     this.poolSize = poolSize;
/*     */   }
/*     */ 
/*     */   public void setScheduledExecutorTasks(ScheduledExecutorTask[] scheduledExecutorTasks)
/*     */   {
/*  96 */     this.scheduledExecutorTasks = scheduledExecutorTasks;
/*     */   }
/*     */ 
/*     */   public void setContinueScheduledExecutionAfterException(boolean continueScheduledExecutionAfterException)
/*     */   {
/* 109 */     this.continueScheduledExecutionAfterException = continueScheduledExecutionAfterException;
/*     */   }
/*     */ 
/*     */   public void setExposeUnconfigurableExecutor(boolean exposeUnconfigurableExecutor)
/*     */   {
/* 121 */     this.exposeUnconfigurableExecutor = exposeUnconfigurableExecutor;
/*     */   }
/*     */ 
/*     */   protected ExecutorService initializeExecutor(ThreadFactory threadFactory, RejectedExecutionHandler rejectedExecutionHandler)
/*     */   {
/* 128 */     ScheduledExecutorService executor = createExecutor(this.poolSize, threadFactory, rejectedExecutionHandler);
/*     */ 
/* 132 */     if (!ObjectUtils.isEmpty(this.scheduledExecutorTasks)) {
/* 133 */       registerTasks(this.scheduledExecutorTasks, executor);
/*     */     }
/*     */ 
/* 137 */     this.exposedExecutor = (this.exposeUnconfigurableExecutor ? Executors.unconfigurableScheduledExecutorService(executor) : executor);
/*     */ 
/* 140 */     return executor;
/*     */   }
/*     */ 
/*     */   protected ScheduledExecutorService createExecutor(int poolSize, ThreadFactory threadFactory, RejectedExecutionHandler rejectedExecutionHandler)
/*     */   {
/* 157 */     return new ScheduledThreadPoolExecutor(poolSize, threadFactory, rejectedExecutionHandler);
/*     */   }
/*     */ 
/*     */   protected void registerTasks(ScheduledExecutorTask[] tasks, ScheduledExecutorService executor)
/*     */   {
/* 167 */     for (ScheduledExecutorTask task : tasks) {
/* 168 */       Runnable runnable = getRunnableToSchedule(task);
/* 169 */       if (task.isOneTimeTask()) {
/* 170 */         executor.schedule(runnable, task.getDelay(), task.getTimeUnit());
/*     */       }
/* 173 */       else if (task.isFixedRate()) {
/* 174 */         executor.scheduleAtFixedRate(runnable, task.getDelay(), task.getPeriod(), task.getTimeUnit());
/*     */       }
/*     */       else
/* 177 */         executor.scheduleWithFixedDelay(runnable, task.getDelay(), task.getPeriod(), task.getTimeUnit());
/*     */     }
/*     */   }
/*     */ 
/*     */   protected Runnable getRunnableToSchedule(ScheduledExecutorTask task)
/*     */   {
/* 195 */     return this.continueScheduledExecutionAfterException ? new DelegatingErrorHandlingRunnable(task.getRunnable(), TaskUtils.LOG_AND_SUPPRESS_ERROR_HANDLER) : new DelegatingErrorHandlingRunnable(task.getRunnable(), TaskUtils.LOG_AND_PROPAGATE_ERROR_HANDLER);
/*     */   }
/*     */ 
/*     */   public ScheduledExecutorService getObject()
/*     */   {
/* 202 */     return this.exposedExecutor;
/*     */   }
/*     */ 
/*     */   public Class<? extends ScheduledExecutorService> getObjectType() {
/* 206 */     return this.exposedExecutor != null ? this.exposedExecutor.getClass() : ScheduledExecutorService.class;
/*     */   }
/*     */ 
/*     */   public boolean isSingleton() {
/* 210 */     return true;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.concurrent.ScheduledExecutorFactoryBean
 * JD-Core Version:    0.6.0
 */