/*     */ package org.springframework.scheduling.concurrent;
/*     */ 
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.RejectedExecutionHandler;
/*     */ import java.util.concurrent.ThreadFactory;
/*     */ import java.util.concurrent.ThreadPoolExecutor.AbortPolicy;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.BeanNameAware;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ 
/*     */ public abstract class ExecutorConfigurationSupport extends CustomizableThreadFactory
/*     */   implements BeanNameAware, InitializingBean, DisposableBean
/*     */ {
/*  48 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */ 
/*  50 */   private ThreadFactory threadFactory = this;
/*     */ 
/*  52 */   private boolean threadNamePrefixSet = false;
/*     */ 
/*  54 */   private RejectedExecutionHandler rejectedExecutionHandler = new ThreadPoolExecutor.AbortPolicy();
/*     */ 
/*  56 */   private boolean waitForTasksToCompleteOnShutdown = false;
/*     */ 
/*  58 */   private int awaitTerminationSeconds = 0;
/*     */   private String beanName;
/*     */   private ExecutorService executor;
/*     */ 
/*     */   public void setThreadFactory(ThreadFactory threadFactory)
/*     */   {
/*  71 */     this.threadFactory = (threadFactory != null ? threadFactory : this);
/*     */   }
/*     */ 
/*     */   public void setThreadNamePrefix(String threadNamePrefix)
/*     */   {
/*  76 */     super.setThreadNamePrefix(threadNamePrefix);
/*  77 */     this.threadNamePrefixSet = true;
/*     */   }
/*     */ 
/*     */   public void setRejectedExecutionHandler(RejectedExecutionHandler rejectedExecutionHandler)
/*     */   {
/*  86 */     this.rejectedExecutionHandler = (rejectedExecutionHandler != null ? rejectedExecutionHandler : new ThreadPoolExecutor.AbortPolicy());
/*     */   }
/*     */ 
/*     */   public void setWaitForTasksToCompleteOnShutdown(boolean waitForJobsToCompleteOnShutdown)
/*     */   {
/* 106 */     this.waitForTasksToCompleteOnShutdown = waitForJobsToCompleteOnShutdown;
/*     */   }
/*     */ 
/*     */   public void setAwaitTerminationSeconds(int awaitTerminationSeconds)
/*     */   {
/* 133 */     this.awaitTerminationSeconds = awaitTerminationSeconds;
/*     */   }
/*     */ 
/*     */   public void setBeanName(String name) {
/* 137 */     this.beanName = name;
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */   {
/* 146 */     initialize();
/*     */   }
/*     */ 
/*     */   public void initialize()
/*     */   {
/* 153 */     if (this.logger.isInfoEnabled()) {
/* 154 */       this.logger.info("Initializing ExecutorService " + (this.beanName != null ? " '" + this.beanName + "'" : ""));
/*     */     }
/* 156 */     if ((!this.threadNamePrefixSet) && (this.beanName != null)) {
/* 157 */       setThreadNamePrefix(this.beanName + "-");
/*     */     }
/* 159 */     this.executor = initializeExecutor(this.threadFactory, this.rejectedExecutionHandler);
/*     */   }
/*     */ 
/*     */   protected abstract ExecutorService initializeExecutor(ThreadFactory paramThreadFactory, RejectedExecutionHandler paramRejectedExecutionHandler);
/*     */ 
/*     */   public void destroy()
/*     */   {
/* 180 */     shutdown();
/*     */   }
/*     */ 
/*     */   public void shutdown()
/*     */   {
/* 190 */     if (this.logger.isInfoEnabled()) {
/* 191 */       this.logger.info("Shutting down ExecutorService" + (this.beanName != null ? " '" + this.beanName + "'" : ""));
/*     */     }
/* 193 */     if (this.waitForTasksToCompleteOnShutdown) {
/* 194 */       this.executor.shutdown();
/*     */     }
/*     */     else {
/* 197 */       this.executor.shutdownNow();
/*     */     }
/* 199 */     awaitTerminationIfNecessary();
/*     */   }
/*     */ 
/*     */   private void awaitTerminationIfNecessary()
/*     */   {
/* 207 */     if (this.awaitTerminationSeconds > 0)
/*     */       try {
/* 209 */         if ((!this.executor.awaitTermination(this.awaitTerminationSeconds, TimeUnit.SECONDS)) && 
/* 210 */           (this.logger.isWarnEnabled())) {
/* 211 */           this.logger.warn("Timed out while waiting for executor" + (this.beanName != null ? " '" + this.beanName + "'" : "") + " to terminate");
/*     */         }
/*     */ 
/*     */       }
/*     */       catch (InterruptedException ex)
/*     */       {
/* 217 */         if (this.logger.isWarnEnabled()) {
/* 218 */           this.logger.warn("Interrupted while waiting for executor" + (this.beanName != null ? " '" + this.beanName + "'" : "") + " to terminate");
/*     */         }
/*     */ 
/* 221 */         Thread.currentThread().interrupt();
/*     */       }
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.concurrent.ExecutorConfigurationSupport
 * JD-Core Version:    0.6.0
 */