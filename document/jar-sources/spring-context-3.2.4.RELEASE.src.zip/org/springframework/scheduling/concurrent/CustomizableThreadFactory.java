/*    */ package org.springframework.scheduling.concurrent;
/*    */ 
/*    */ import java.util.concurrent.ThreadFactory;
/*    */ import org.springframework.util.CustomizableThreadCreator;
/*    */ 
/*    */ public class CustomizableThreadFactory extends CustomizableThreadCreator
/*    */   implements ThreadFactory
/*    */ {
/*    */   public CustomizableThreadFactory()
/*    */   {
/*    */   }
/*    */ 
/*    */   public CustomizableThreadFactory(String threadNamePrefix)
/*    */   {
/* 50 */     super(threadNamePrefix);
/*    */   }
/*    */ 
/*    */   public Thread newThread(Runnable runnable)
/*    */   {
/* 55 */     return createThread(runnable);
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.concurrent.CustomizableThreadFactory
 * JD-Core Version:    0.6.0
 */