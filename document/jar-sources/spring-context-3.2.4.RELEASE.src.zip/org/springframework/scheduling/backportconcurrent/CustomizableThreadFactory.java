/*    */ package org.springframework.scheduling.backportconcurrent;
/*    */ 
/*    */ import edu.emory.mathcs.backport.java.util.concurrent.ThreadFactory;
/*    */ import org.springframework.util.CustomizableThreadCreator;
/*    */ 
/*    */ @Deprecated
/*    */ public class CustomizableThreadFactory extends CustomizableThreadCreator
/*    */   implements ThreadFactory
/*    */ {
/*    */   public CustomizableThreadFactory()
/*    */   {
/*    */   }
/*    */ 
/*    */   public CustomizableThreadFactory(String threadNamePrefix)
/*    */   {
/* 53 */     super(threadNamePrefix);
/*    */   }
/*    */ 
/*    */   public Thread newThread(Runnable runnable)
/*    */   {
/* 58 */     return createThread(runnable);
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.backportconcurrent.CustomizableThreadFactory
 * JD-Core Version:    0.6.0
 */