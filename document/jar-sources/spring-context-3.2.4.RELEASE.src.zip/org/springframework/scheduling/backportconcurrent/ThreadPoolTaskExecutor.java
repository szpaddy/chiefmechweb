/*     */ package org.springframework.scheduling.backportconcurrent;
/*     */ 
/*     */ import edu.emory.mathcs.backport.java.util.concurrent.BlockingQueue;
/*     */ import edu.emory.mathcs.backport.java.util.concurrent.Executor;
/*     */ import edu.emory.mathcs.backport.java.util.concurrent.LinkedBlockingQueue;
/*     */ import edu.emory.mathcs.backport.java.util.concurrent.RejectedExecutionException;
/*     */ import edu.emory.mathcs.backport.java.util.concurrent.RejectedExecutionHandler;
/*     */ import edu.emory.mathcs.backport.java.util.concurrent.SynchronousQueue;
/*     */ import edu.emory.mathcs.backport.java.util.concurrent.ThreadFactory;
/*     */ import edu.emory.mathcs.backport.java.util.concurrent.ThreadPoolExecutor;
/*     */ import edu.emory.mathcs.backport.java.util.concurrent.ThreadPoolExecutor.AbortPolicy;
/*     */ import edu.emory.mathcs.backport.java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.Future;
/*     */ import java.util.concurrent.FutureTask;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.BeanNameAware;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.core.task.TaskRejectedException;
/*     */ import org.springframework.scheduling.SchedulingTaskExecutor;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ @Deprecated
/*     */ public class ThreadPoolTaskExecutor extends CustomizableThreadFactory
/*     */   implements SchedulingTaskExecutor, Executor, BeanNameAware, InitializingBean, DisposableBean
/*     */ {
/*  82 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */ 
/*  84 */   private final Object poolSizeMonitor = new Object();
/*     */ 
/*  86 */   private int corePoolSize = 1;
/*     */ 
/*  88 */   private int maxPoolSize = 2147483647;
/*     */ 
/*  90 */   private int keepAliveSeconds = 60;
/*     */ 
/*  92 */   private boolean allowCoreThreadTimeOut = false;
/*     */ 
/*  94 */   private int queueCapacity = 2147483647;
/*     */ 
/*  96 */   private ThreadFactory threadFactory = this;
/*     */ 
/*  98 */   private RejectedExecutionHandler rejectedExecutionHandler = new ThreadPoolExecutor.AbortPolicy();
/*     */ 
/* 100 */   private boolean waitForTasksToCompleteOnShutdown = false;
/*     */ 
/* 102 */   private boolean threadNamePrefixSet = false;
/*     */   private String beanName;
/*     */   private ThreadPoolExecutor threadPoolExecutor;
/*     */ 
/*     */   public void setCorePoolSize(int corePoolSize)
/*     */   {
/* 115 */     synchronized (this.poolSizeMonitor) {
/* 116 */       this.corePoolSize = corePoolSize;
/* 117 */       if (this.threadPoolExecutor != null)
/* 118 */         this.threadPoolExecutor.setCorePoolSize(corePoolSize);
/*     */     }
/*     */   }
/*     */ 
/*     */   public int getCorePoolSize()
/*     */   {
/* 127 */     synchronized (this.poolSizeMonitor) {
/* 128 */       return this.corePoolSize;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setMaxPoolSize(int maxPoolSize)
/*     */   {
/* 138 */     synchronized (this.poolSizeMonitor) {
/* 139 */       this.maxPoolSize = maxPoolSize;
/* 140 */       if (this.threadPoolExecutor != null)
/* 141 */         this.threadPoolExecutor.setMaximumPoolSize(maxPoolSize);
/*     */     }
/*     */   }
/*     */ 
/*     */   public int getMaxPoolSize()
/*     */   {
/* 150 */     synchronized (this.poolSizeMonitor) {
/* 151 */       return this.maxPoolSize;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setKeepAliveSeconds(int keepAliveSeconds)
/*     */   {
/* 161 */     synchronized (this.poolSizeMonitor) {
/* 162 */       this.keepAliveSeconds = keepAliveSeconds;
/* 163 */       if (this.threadPoolExecutor != null)
/* 164 */         this.threadPoolExecutor.setKeepAliveTime(keepAliveSeconds, TimeUnit.SECONDS);
/*     */     }
/*     */   }
/*     */ 
/*     */   public int getKeepAliveSeconds()
/*     */   {
/* 173 */     synchronized (this.poolSizeMonitor) {
/* 174 */       return this.keepAliveSeconds;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setAllowCoreThreadTimeOut(boolean allowCoreThreadTimeOut)
/*     */   {
/* 187 */     this.allowCoreThreadTimeOut = allowCoreThreadTimeOut;
/*     */   }
/*     */ 
/*     */   public void setQueueCapacity(int queueCapacity)
/*     */   {
/* 199 */     this.queueCapacity = queueCapacity;
/*     */   }
/*     */ 
/*     */   public void setThreadFactory(ThreadFactory threadFactory)
/*     */   {
/* 211 */     this.threadFactory = (threadFactory != null ? threadFactory : this);
/*     */   }
/*     */ 
/*     */   public void setRejectedExecutionHandler(RejectedExecutionHandler rejectedExecutionHandler)
/*     */   {
/* 220 */     this.rejectedExecutionHandler = (rejectedExecutionHandler != null ? rejectedExecutionHandler : new ThreadPoolExecutor.AbortPolicy());
/*     */   }
/*     */ 
/*     */   public void setWaitForTasksToCompleteOnShutdown(boolean waitForJobsToCompleteOnShutdown)
/*     */   {
/* 232 */     this.waitForTasksToCompleteOnShutdown = waitForJobsToCompleteOnShutdown;
/*     */   }
/*     */ 
/*     */   public void setThreadNamePrefix(String threadNamePrefix)
/*     */   {
/* 237 */     super.setThreadNamePrefix(threadNamePrefix);
/* 238 */     this.threadNamePrefixSet = true;
/*     */   }
/*     */ 
/*     */   public void setBeanName(String name) {
/* 242 */     this.beanName = name;
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */   {
/* 251 */     initialize();
/*     */   }
/*     */ 
/*     */   public void initialize()
/*     */   {
/* 259 */     if (this.logger.isInfoEnabled()) {
/* 260 */       this.logger.info("Initializing ThreadPoolExecutor" + (this.beanName != null ? " '" + this.beanName + "'" : ""));
/*     */     }
/* 262 */     if ((!this.threadNamePrefixSet) && (this.beanName != null)) {
/* 263 */       setThreadNamePrefix(this.beanName + "-");
/*     */     }
/* 265 */     BlockingQueue queue = createQueue(this.queueCapacity);
/* 266 */     this.threadPoolExecutor = new ThreadPoolExecutor(this.corePoolSize, this.maxPoolSize, this.keepAliveSeconds, TimeUnit.SECONDS, queue, this.threadFactory, this.rejectedExecutionHandler);
/*     */ 
/* 269 */     if (this.allowCoreThreadTimeOut)
/* 270 */       this.threadPoolExecutor.allowCoreThreadTimeOut(true);
/*     */   }
/*     */ 
/*     */   protected BlockingQueue createQueue(int queueCapacity)
/*     */   {
/* 284 */     if (queueCapacity > 0) {
/* 285 */       return new LinkedBlockingQueue(queueCapacity);
/*     */     }
/*     */ 
/* 288 */     return new SynchronousQueue();
/*     */   }
/*     */ 
/*     */   public ThreadPoolExecutor getThreadPoolExecutor()
/*     */     throws IllegalStateException
/*     */   {
/* 298 */     Assert.state(this.threadPoolExecutor != null, "ThreadPoolTaskExecutor not initialized");
/* 299 */     return this.threadPoolExecutor;
/*     */   }
/*     */ 
/*     */   public void execute(Runnable task)
/*     */   {
/* 310 */     Executor executor = getThreadPoolExecutor();
/*     */     try {
/* 312 */       executor.execute(task);
/*     */     }
/*     */     catch (RejectedExecutionException ex) {
/* 315 */       throw new TaskRejectedException("Executor [" + executor + "] did not accept task: " + task, ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void execute(Runnable task, long startTimeout) {
/* 320 */     execute(task);
/*     */   }
/*     */ 
/*     */   public Future<?> submit(Runnable task) {
/* 324 */     FutureTask future = new FutureTask(task, null);
/* 325 */     execute(future);
/* 326 */     return future;
/*     */   }
/*     */ 
/*     */   public <T> Future<T> submit(Callable<T> task) {
/* 330 */     FutureTask future = new FutureTask(task);
/* 331 */     execute(future);
/* 332 */     return future;
/*     */   }
/*     */ 
/*     */   public boolean prefersShortLivedTasks()
/*     */   {
/* 339 */     return true;
/*     */   }
/*     */ 
/*     */   public int getPoolSize()
/*     */   {
/* 348 */     return getThreadPoolExecutor().getPoolSize();
/*     */   }
/*     */ 
/*     */   public int getActiveCount()
/*     */   {
/* 356 */     return getThreadPoolExecutor().getActiveCount();
/*     */   }
/*     */ 
/*     */   public void destroy()
/*     */   {
/* 366 */     shutdown();
/*     */   }
/*     */ 
/*     */   public void shutdown()
/*     */   {
/* 374 */     if (this.logger.isInfoEnabled()) {
/* 375 */       this.logger.info("Shutting down ThreadPoolExecutor" + (this.beanName != null ? " '" + this.beanName + "'" : ""));
/*     */     }
/* 377 */     if (this.waitForTasksToCompleteOnShutdown) {
/* 378 */       this.threadPoolExecutor.shutdown();
/*     */     }
/*     */     else
/* 381 */       this.threadPoolExecutor.shutdownNow();
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.backportconcurrent.ThreadPoolTaskExecutor
 * JD-Core Version:    0.6.0
 */