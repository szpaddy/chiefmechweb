/*    */ package org.springframework.scheduling.support;
/*    */ 
/*    */ import java.util.Date;
/*    */ import org.springframework.scheduling.TriggerContext;
/*    */ 
/*    */ public class SimpleTriggerContext
/*    */   implements TriggerContext
/*    */ {
/*    */   private volatile Date lastScheduledExecutionTime;
/*    */   private volatile Date lastActualExecutionTime;
/*    */   private volatile Date lastCompletionTime;
/*    */ 
/*    */   public void update(Date lastScheduledExecutionTime, Date lastActualExecutionTime, Date lastCompletionTime)
/*    */   {
/* 45 */     this.lastScheduledExecutionTime = lastScheduledExecutionTime;
/* 46 */     this.lastActualExecutionTime = lastActualExecutionTime;
/* 47 */     this.lastCompletionTime = lastCompletionTime;
/*    */   }
/*    */ 
/*    */   public Date lastScheduledExecutionTime()
/*    */   {
/* 52 */     return this.lastScheduledExecutionTime;
/*    */   }
/*    */ 
/*    */   public Date lastActualExecutionTime() {
/* 56 */     return this.lastActualExecutionTime;
/*    */   }
/*    */ 
/*    */   public Date lastCompletionTime() {
/* 60 */     return this.lastCompletionTime;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.support.SimpleTriggerContext
 * JD-Core Version:    0.6.0
 */