/*     */ package org.springframework.scheduling.support;
/*     */ 
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.util.ErrorHandler;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ public abstract class TaskUtils
/*     */ {
/*  45 */   public static final ErrorHandler LOG_AND_SUPPRESS_ERROR_HANDLER = new LoggingErrorHandler();
/*     */ 
/*  52 */   public static final ErrorHandler LOG_AND_PROPAGATE_ERROR_HANDLER = new PropagatingErrorHandler();
/*     */ 
/*     */   public static DelegatingErrorHandlingRunnable decorateTaskWithErrorHandler(Runnable task, ErrorHandler errorHandler, boolean isRepeatingTask)
/*     */   {
/*  66 */     if ((task instanceof DelegatingErrorHandlingRunnable)) {
/*  67 */       return (DelegatingErrorHandlingRunnable)task;
/*     */     }
/*  69 */     ErrorHandler eh = errorHandler != null ? errorHandler : getDefaultErrorHandler(isRepeatingTask);
/*  70 */     return new DelegatingErrorHandlingRunnable(task, eh);
/*     */   }
/*     */ 
/*     */   public static ErrorHandler getDefaultErrorHandler(boolean isRepeatingTask)
/*     */   {
/*  80 */     return isRepeatingTask ? LOG_AND_SUPPRESS_ERROR_HANDLER : LOG_AND_PROPAGATE_ERROR_HANDLER;
/*     */   }
/*     */ 
/*     */   static class PropagatingErrorHandler extends TaskUtils.LoggingErrorHandler
/*     */   {
/*     */     public void handleError(Throwable t)
/*     */     {
/* 108 */       super.handleError(t);
/* 109 */       ReflectionUtils.rethrowRuntimeException(t);
/*     */     }
/*     */   }
/*     */ 
/*     */   static class LoggingErrorHandler
/*     */     implements ErrorHandler
/*     */   {
/*  91 */     private final Log logger = LogFactory.getLog(LoggingErrorHandler.class);
/*     */ 
/*     */     public void handleError(Throwable t) {
/*  94 */       if (this.logger.isErrorEnabled())
/*  95 */         this.logger.error("Unexpected error occurred in scheduled task.", t);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.support.TaskUtils
 * JD-Core Version:    0.6.0
 */