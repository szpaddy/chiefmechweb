/*    */ package org.springframework.scheduling.support;
/*    */ 
/*    */ import java.util.Date;
/*    */ import java.util.TimeZone;
/*    */ import org.springframework.scheduling.Trigger;
/*    */ import org.springframework.scheduling.TriggerContext;
/*    */ 
/*    */ public class CronTrigger
/*    */   implements Trigger
/*    */ {
/*    */   private final CronSequenceGenerator sequenceGenerator;
/*    */ 
/*    */   public CronTrigger(String cronExpression)
/*    */   {
/* 44 */     this.sequenceGenerator = new CronSequenceGenerator(cronExpression);
/*    */   }
/*    */ 
/*    */   public CronTrigger(String cronExpression, TimeZone timeZone)
/*    */   {
/* 54 */     this.sequenceGenerator = new CronSequenceGenerator(cronExpression, timeZone);
/*    */   }
/*    */ 
/*    */   public Date nextExecutionTime(TriggerContext triggerContext)
/*    */   {
/* 65 */     Date date = triggerContext.lastCompletionTime();
/* 66 */     if (date != null) {
/* 67 */       Date scheduled = triggerContext.lastScheduledExecutionTime();
/* 68 */       if ((scheduled != null) && (date.before(scheduled)))
/*    */       {
/* 72 */         date = scheduled;
/*    */       }
/*    */     }
/*    */     else {
/* 76 */       date = new Date();
/*    */     }
/* 78 */     return this.sequenceGenerator.next(date);
/*    */   }
/*    */ 
/*    */   public String getExpression() {
/* 82 */     return this.sequenceGenerator.getExpression();
/*    */   }
/*    */ 
/*    */   public boolean equals(Object obj)
/*    */   {
/* 87 */     return (this == obj) || (((obj instanceof CronTrigger)) && (this.sequenceGenerator.equals(((CronTrigger)obj).sequenceGenerator)));
/*    */   }
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 93 */     return this.sequenceGenerator.hashCode();
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 98 */     return this.sequenceGenerator.toString();
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.support.CronTrigger
 * JD-Core Version:    0.6.0
 */