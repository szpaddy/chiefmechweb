package org.springframework.scheduling;

import org.springframework.core.task.AsyncTaskExecutor;

public abstract interface SchedulingTaskExecutor extends AsyncTaskExecutor
{
  public abstract boolean prefersShortLivedTasks();
}

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.SchedulingTaskExecutor
 * JD-Core Version:    0.6.0
 */