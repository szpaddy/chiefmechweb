/*     */ package org.springframework.scheduling.timer;
/*     */ 
/*     */ import java.util.Timer;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.BeanNameAware;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ @Deprecated
/*     */ public class TimerFactoryBean
/*     */   implements FactoryBean<Timer>, BeanNameAware, InitializingBean, DisposableBean
/*     */ {
/*  55 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   private ScheduledTimerTask[] scheduledTimerTasks;
/*  59 */   private boolean daemon = false;
/*     */   private String beanName;
/*     */   private Timer timer;
/*     */ 
/*     */   public void setScheduledTimerTasks(ScheduledTimerTask[] scheduledTimerTasks)
/*     */   {
/*  75 */     this.scheduledTimerTasks = scheduledTimerTasks;
/*     */   }
/*     */ 
/*     */   public void setDaemon(boolean daemon)
/*     */   {
/*  88 */     this.daemon = daemon;
/*     */   }
/*     */ 
/*     */   public void setBeanName(String beanName) {
/*  92 */     this.beanName = beanName;
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */   {
/*  97 */     this.logger.info("Initializing Timer");
/*  98 */     this.timer = createTimer(this.beanName, this.daemon);
/*     */ 
/* 101 */     if (!ObjectUtils.isEmpty(this.scheduledTimerTasks))
/* 102 */       registerTasks(this.scheduledTimerTasks, this.timer);
/*     */   }
/*     */ 
/*     */   protected Timer createTimer(String name, boolean daemon)
/*     */   {
/* 116 */     if (StringUtils.hasText(name)) {
/* 117 */       return new Timer(name, daemon);
/*     */     }
/*     */ 
/* 120 */     return new Timer(daemon);
/*     */   }
/*     */ 
/*     */   protected void registerTasks(ScheduledTimerTask[] tasks, Timer timer)
/*     */   {
/* 131 */     for (ScheduledTimerTask task : tasks)
/* 132 */       if (task.isOneTimeTask()) {
/* 133 */         timer.schedule(task.getTimerTask(), task.getDelay());
/*     */       }
/* 136 */       else if (task.isFixedRate()) {
/* 137 */         timer.scheduleAtFixedRate(task.getTimerTask(), task.getDelay(), task.getPeriod());
/*     */       }
/*     */       else
/* 140 */         timer.schedule(task.getTimerTask(), task.getDelay(), task.getPeriod());
/*     */   }
/*     */ 
/*     */   public Timer getObject()
/*     */   {
/* 148 */     return this.timer;
/*     */   }
/*     */ 
/*     */   public Class<? extends Timer> getObjectType() {
/* 152 */     return Timer.class;
/*     */   }
/*     */ 
/*     */   public boolean isSingleton() {
/* 156 */     return true;
/*     */   }
/*     */ 
/*     */   public void destroy()
/*     */   {
/* 165 */     this.logger.info("Cancelling Timer");
/* 166 */     this.timer.cancel();
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.timer.TimerFactoryBean
 * JD-Core Version:    0.6.0
 */