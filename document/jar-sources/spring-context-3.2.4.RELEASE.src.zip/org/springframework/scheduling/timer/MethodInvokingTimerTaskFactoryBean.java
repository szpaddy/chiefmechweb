/*    */ package org.springframework.scheduling.timer;
/*    */ 
/*    */ import java.util.TimerTask;
/*    */ import org.springframework.beans.factory.FactoryBean;
/*    */ import org.springframework.scheduling.support.MethodInvokingRunnable;
/*    */ 
/*    */ @Deprecated
/*    */ public class MethodInvokingTimerTaskFactoryBean extends MethodInvokingRunnable
/*    */   implements FactoryBean<TimerTask>
/*    */ {
/*    */   private TimerTask timerTask;
/*    */ 
/*    */   public void afterPropertiesSet()
/*    */     throws ClassNotFoundException, NoSuchMethodException
/*    */   {
/* 51 */     super.afterPropertiesSet();
/* 52 */     this.timerTask = new DelegatingTimerTask(this);
/*    */   }
/*    */ 
/*    */   public TimerTask getObject()
/*    */   {
/* 57 */     return this.timerTask;
/*    */   }
/*    */ 
/*    */   public Class<TimerTask> getObjectType() {
/* 61 */     return TimerTask.class;
/*    */   }
/*    */ 
/*    */   public boolean isSingleton() {
/* 65 */     return true;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.timer.MethodInvokingTimerTaskFactoryBean
 * JD-Core Version:    0.6.0
 */