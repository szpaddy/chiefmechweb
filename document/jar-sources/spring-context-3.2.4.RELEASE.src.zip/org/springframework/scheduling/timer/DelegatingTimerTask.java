/*    */ package org.springframework.scheduling.timer;
/*    */ 
/*    */ import java.util.TimerTask;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ @Deprecated
/*    */ public class DelegatingTimerTask extends TimerTask
/*    */ {
/* 41 */   private static final Log logger = LogFactory.getLog(DelegatingTimerTask.class);
/*    */   private final Runnable delegate;
/*    */ 
/*    */   public DelegatingTimerTask(Runnable delegate)
/*    */   {
/* 51 */     Assert.notNull(delegate, "Delegate must not be null");
/* 52 */     this.delegate = delegate;
/*    */   }
/*    */ 
/*    */   public final Runnable getDelegate()
/*    */   {
/* 59 */     return this.delegate;
/*    */   }
/*    */ 
/*    */   public void run()
/*    */   {
/*    */     try
/*    */     {
/* 70 */       this.delegate.run();
/*    */     }
/*    */     catch (Throwable ex) {
/* 73 */       logger.error("Unexpected exception thrown from Runnable: " + this.delegate, ex);
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.timer.DelegatingTimerTask
 * JD-Core Version:    0.6.0
 */