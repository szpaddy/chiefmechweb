/*     */ package org.springframework.scheduling.timer;
/*     */ 
/*     */ import java.util.TimerTask;
/*     */ 
/*     */ @Deprecated
/*     */ public class ScheduledTimerTask
/*     */ {
/*     */   private TimerTask timerTask;
/*  48 */   private long delay = 0L;
/*     */ 
/*  50 */   private long period = -1L;
/*     */ 
/*  52 */   private boolean fixedRate = false;
/*     */ 
/*     */   public ScheduledTimerTask()
/*     */   {
/*     */   }
/*     */ 
/*     */   public ScheduledTimerTask(TimerTask timerTask)
/*     */   {
/*  72 */     this.timerTask = timerTask;
/*     */   }
/*     */ 
/*     */   public ScheduledTimerTask(TimerTask timerTask, long delay)
/*     */   {
/*  82 */     this.timerTask = timerTask;
/*  83 */     this.delay = delay;
/*     */   }
/*     */ 
/*     */   public ScheduledTimerTask(TimerTask timerTask, long delay, long period, boolean fixedRate)
/*     */   {
/*  94 */     this.timerTask = timerTask;
/*  95 */     this.delay = delay;
/*  96 */     this.period = period;
/*  97 */     this.fixedRate = fixedRate;
/*     */   }
/*     */ 
/*     */   public ScheduledTimerTask(Runnable timerTask)
/*     */   {
/* 106 */     setRunnable(timerTask);
/*     */   }
/*     */ 
/*     */   public ScheduledTimerTask(Runnable timerTask, long delay)
/*     */   {
/* 116 */     setRunnable(timerTask);
/* 117 */     this.delay = delay;
/*     */   }
/*     */ 
/*     */   public ScheduledTimerTask(Runnable timerTask, long delay, long period, boolean fixedRate)
/*     */   {
/* 128 */     setRunnable(timerTask);
/* 129 */     this.delay = delay;
/* 130 */     this.period = period;
/* 131 */     this.fixedRate = fixedRate;
/*     */   }
/*     */ 
/*     */   public void setRunnable(Runnable timerTask)
/*     */   {
/* 140 */     this.timerTask = new DelegatingTimerTask(timerTask);
/*     */   }
/*     */ 
/*     */   public void setTimerTask(TimerTask timerTask)
/*     */   {
/* 147 */     this.timerTask = timerTask;
/*     */   }
/*     */ 
/*     */   public TimerTask getTimerTask()
/*     */   {
/* 154 */     return this.timerTask;
/*     */   }
/*     */ 
/*     */   public void setDelay(long delay)
/*     */   {
/* 163 */     this.delay = delay;
/*     */   }
/*     */ 
/*     */   public long getDelay()
/*     */   {
/* 170 */     return this.delay;
/*     */   }
/*     */ 
/*     */   public void setPeriod(long period)
/*     */   {
/* 189 */     this.period = period;
/*     */   }
/*     */ 
/*     */   public long getPeriod()
/*     */   {
/* 196 */     return this.period;
/*     */   }
/*     */ 
/*     */   public boolean isOneTimeTask()
/*     */   {
/* 205 */     return this.period <= 0L;
/*     */   }
/*     */ 
/*     */   public void setFixedRate(boolean fixedRate)
/*     */   {
/* 216 */     this.fixedRate = fixedRate;
/*     */   }
/*     */ 
/*     */   public boolean isFixedRate()
/*     */   {
/* 223 */     return this.fixedRate;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.timer.ScheduledTimerTask
 * JD-Core Version:    0.6.0
 */