/*    */ package org.springframework.scheduling.config;
/*    */ 
/*    */ import org.springframework.scheduling.support.CronTrigger;
/*    */ 
/*    */ public class CronTask extends TriggerTask
/*    */ {
/*    */   private String expression;
/*    */ 
/*    */   public CronTask(Runnable runnable, String expression)
/*    */   {
/* 44 */     this(runnable, new CronTrigger(expression));
/*    */   }
/*    */ 
/*    */   public CronTask(Runnable runnable, CronTrigger cronTrigger)
/*    */   {
/* 53 */     super(runnable, cronTrigger);
/* 54 */     this.expression = cronTrigger.getExpression();
/*    */   }
/*    */ 
/*    */   public String getExpression() {
/* 58 */     return this.expression;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.config.CronTask
 * JD-Core Version:    0.6.0
 */