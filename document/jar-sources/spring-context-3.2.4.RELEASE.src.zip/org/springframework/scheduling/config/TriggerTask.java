/*    */ package org.springframework.scheduling.config;
/*    */ 
/*    */ import org.springframework.scheduling.Trigger;
/*    */ 
/*    */ public class TriggerTask extends Task
/*    */ {
/*    */   private final Trigger trigger;
/*    */ 
/*    */   public TriggerTask(Runnable runnable, Trigger trigger)
/*    */   {
/* 42 */     super(runnable);
/* 43 */     this.trigger = trigger;
/*    */   }
/*    */ 
/*    */   public Trigger getTrigger()
/*    */   {
/* 48 */     return this.trigger;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.config.TriggerTask
 * JD-Core Version:    0.6.0
 */