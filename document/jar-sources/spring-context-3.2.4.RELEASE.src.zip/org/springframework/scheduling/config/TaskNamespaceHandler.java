/*    */ package org.springframework.scheduling.config;
/*    */ 
/*    */ import org.springframework.beans.factory.xml.NamespaceHandlerSupport;
/*    */ 
/*    */ public class TaskNamespaceHandler extends NamespaceHandlerSupport
/*    */ {
/*    */   public void init()
/*    */   {
/* 30 */     registerBeanDefinitionParser("annotation-driven", new AnnotationDrivenBeanDefinitionParser());
/* 31 */     registerBeanDefinitionParser("executor", new ExecutorBeanDefinitionParser());
/* 32 */     registerBeanDefinitionParser("scheduled-tasks", new ScheduledTasksBeanDefinitionParser());
/* 33 */     registerBeanDefinitionParser("scheduler", new SchedulerBeanDefinitionParser());
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.config.TaskNamespaceHandler
 * JD-Core Version:    0.6.0
 */