/*     */ package org.springframework.scheduling.config;
/*     */ 
/*     */ import org.springframework.beans.BeanWrapper;
/*     */ import org.springframework.beans.BeanWrapperImpl;
/*     */ import org.springframework.beans.factory.BeanNameAware;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.core.JdkVersion;
/*     */ import org.springframework.core.task.TaskExecutor;
/*     */ import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class TaskExecutorFactoryBean
/*     */   implements FactoryBean<TaskExecutor>, BeanNameAware, InitializingBean, DisposableBean
/*     */ {
/*     */   private String poolSize;
/*     */   private Integer queueCapacity;
/*     */   private Object rejectedExecutionHandler;
/*     */   private Integer keepAliveSeconds;
/*     */   private String beanName;
/*     */   private TaskExecutor target;
/*     */ 
/*     */   public void setPoolSize(String poolSize)
/*     */   {
/*  55 */     this.poolSize = poolSize;
/*     */   }
/*     */ 
/*     */   public void setQueueCapacity(int queueCapacity) {
/*  59 */     this.queueCapacity = Integer.valueOf(queueCapacity);
/*     */   }
/*     */ 
/*     */   public void setRejectedExecutionHandler(Object rejectedExecutionHandler) {
/*  63 */     this.rejectedExecutionHandler = rejectedExecutionHandler;
/*     */   }
/*     */ 
/*     */   public void setKeepAliveSeconds(int keepAliveSeconds) {
/*  67 */     this.keepAliveSeconds = Integer.valueOf(keepAliveSeconds);
/*     */   }
/*     */ 
/*     */   public void setBeanName(String beanName) {
/*  71 */     this.beanName = beanName;
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet() throws Exception
/*     */   {
/*  76 */     Class executorClass = shouldUseBackport() ? getClass().getClassLoader().loadClass("org.springframework.scheduling.backportconcurrent.ThreadPoolTaskExecutor") : ThreadPoolTaskExecutor.class;
/*     */ 
/*  79 */     BeanWrapper bw = new BeanWrapperImpl(executorClass);
/*  80 */     determinePoolSizeRange(bw);
/*  81 */     if (this.queueCapacity != null) {
/*  82 */       bw.setPropertyValue("queueCapacity", this.queueCapacity);
/*     */     }
/*  84 */     if (this.keepAliveSeconds != null) {
/*  85 */       bw.setPropertyValue("keepAliveSeconds", this.keepAliveSeconds);
/*     */     }
/*  87 */     if (this.rejectedExecutionHandler != null) {
/*  88 */       bw.setPropertyValue("rejectedExecutionHandler", this.rejectedExecutionHandler);
/*     */     }
/*  90 */     if (this.beanName != null) {
/*  91 */       bw.setPropertyValue("threadNamePrefix", this.beanName + "-");
/*     */     }
/*  93 */     this.target = ((TaskExecutor)bw.getWrappedInstance());
/*  94 */     if ((this.target instanceof InitializingBean))
/*  95 */       ((InitializingBean)this.target).afterPropertiesSet();
/*     */   }
/*     */ 
/*     */   private boolean shouldUseBackport()
/*     */   {
/* 100 */     return (StringUtils.hasText(this.poolSize)) && (this.poolSize.startsWith("0")) && (JdkVersion.getMajorJavaVersion() < 3);
/*     */   }
/*     */ 
/*     */   private void determinePoolSizeRange(BeanWrapper bw)
/*     */   {
/* 105 */     if (StringUtils.hasText(this.poolSize))
/*     */     {
/*     */       try
/*     */       {
/* 109 */         int separatorIndex = this.poolSize.indexOf('-');
/*     */         int corePoolSize;
/*     */         int maxPoolSize;
/* 110 */         if (separatorIndex != -1) {
/* 111 */           int corePoolSize = Integer.valueOf(this.poolSize.substring(0, separatorIndex)).intValue();
/* 112 */           int maxPoolSize = Integer.valueOf(this.poolSize.substring(separatorIndex + 1, this.poolSize.length())).intValue();
/* 113 */           if (corePoolSize > maxPoolSize) {
/* 114 */             throw new IllegalArgumentException("Lower bound of pool-size range must not exceed the upper bound");
/*     */           }
/*     */ 
/* 117 */           if (this.queueCapacity == null)
/*     */           {
/* 119 */             if (corePoolSize == 0)
/*     */             {
/* 122 */               bw.setPropertyValue("allowCoreThreadTimeOut", Boolean.valueOf(true));
/* 123 */               corePoolSize = maxPoolSize;
/*     */             }
/*     */             else
/*     */             {
/* 127 */               throw new IllegalArgumentException("A non-zero lower bound for the size range requires a queue-capacity value");
/*     */             }
/*     */           }
/*     */         }
/*     */         else
/*     */         {
/* 133 */           Integer value = Integer.valueOf(this.poolSize);
/* 134 */           corePoolSize = value.intValue();
/* 135 */           maxPoolSize = value.intValue();
/*     */         }
/* 137 */         bw.setPropertyValue("corePoolSize", Integer.valueOf(corePoolSize));
/* 138 */         bw.setPropertyValue("maxPoolSize", Integer.valueOf(maxPoolSize));
/*     */       }
/*     */       catch (NumberFormatException ex) {
/* 141 */         throw new IllegalArgumentException("Invalid pool-size value [" + this.poolSize + "]: only single " + "maximum integer (e.g. \"5\") and minimum-maximum range (e.g. \"3-5\") are supported", ex);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public TaskExecutor getObject()
/*     */   {
/* 149 */     return this.target;
/*     */   }
/*     */ 
/*     */   public Class<? extends TaskExecutor> getObjectType() {
/* 153 */     if (this.target != null) {
/* 154 */       return this.target.getClass();
/*     */     }
/* 156 */     return !shouldUseBackport() ? ThreadPoolTaskExecutor.class : TaskExecutor.class;
/*     */   }
/*     */ 
/*     */   public boolean isSingleton() {
/* 160 */     return true;
/*     */   }
/*     */ 
/*     */   public void destroy() throws Exception
/*     */   {
/* 165 */     if ((this.target instanceof DisposableBean))
/* 166 */       ((DisposableBean)this.target).destroy();
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.config.TaskExecutorFactoryBean
 * JD-Core Version:    0.6.0
 */