/*    */ package org.springframework.scheduling.annotation;
/*    */ 
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.context.annotation.Role;
/*    */ import org.springframework.core.annotation.AnnotationAttributes;
/*    */ import org.springframework.core.annotation.AnnotationUtils;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ @Configuration
/*    */ public class ProxyAsyncConfiguration extends AbstractAsyncConfiguration
/*    */ {
/*    */   @Bean(name={"org.springframework.context.annotation.internalAsyncAnnotationProcessor"})
/*    */   @Role(2)
/*    */   public AsyncAnnotationBeanPostProcessor asyncAdvisor()
/*    */   {
/* 45 */     Assert.notNull(this.enableAsync, "@EnableAsync annotation metadata was not injected");
/*    */ 
/* 47 */     AsyncAnnotationBeanPostProcessor bpp = new AsyncAnnotationBeanPostProcessor();
/*    */ 
/* 49 */     Class customAsyncAnnotation = this.enableAsync.getClass("annotation");
/* 50 */     if (customAsyncAnnotation != AnnotationUtils.getDefaultValue(EnableAsync.class, "annotation")) {
/* 51 */       bpp.setAsyncAnnotationType(customAsyncAnnotation);
/*    */     }
/*    */ 
/* 54 */     if (this.executor != null) {
/* 55 */       bpp.setExecutor(this.executor);
/*    */     }
/*    */ 
/* 58 */     bpp.setProxyTargetClass(this.enableAsync.getBoolean("proxyTargetClass"));
/* 59 */     bpp.setOrder(((Integer)this.enableAsync.getNumber("order")).intValue());
/*    */ 
/* 61 */     return bpp;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.annotation.ProxyAsyncConfiguration
 * JD-Core Version:    0.6.0
 */