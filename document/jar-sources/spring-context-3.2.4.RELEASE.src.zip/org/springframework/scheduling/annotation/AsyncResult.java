/*    */ package org.springframework.scheduling.annotation;
/*    */ 
/*    */ import java.util.concurrent.Future;
/*    */ import java.util.concurrent.TimeUnit;
/*    */ 
/*    */ public class AsyncResult<V>
/*    */   implements Future<V>
/*    */ {
/*    */   private final V value;
/*    */ 
/*    */   public AsyncResult(V value)
/*    */   {
/* 40 */     this.value = value;
/*    */   }
/*    */ 
/*    */   public boolean cancel(boolean mayInterruptIfRunning) {
/* 44 */     return false;
/*    */   }
/*    */ 
/*    */   public boolean isCancelled() {
/* 48 */     return false;
/*    */   }
/*    */ 
/*    */   public boolean isDone() {
/* 52 */     return true;
/*    */   }
/*    */ 
/*    */   public V get() {
/* 56 */     return this.value;
/*    */   }
/*    */ 
/*    */   public V get(long timeout, TimeUnit unit) {
/* 60 */     return this.value;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.annotation.AsyncResult
 * JD-Core Version:    0.6.0
 */