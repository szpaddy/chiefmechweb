package org.springframework.scheduling.annotation;

import org.springframework.scheduling.config.ScheduledTaskRegistrar;

public abstract interface SchedulingConfigurer
{
  public abstract void configureTasks(ScheduledTaskRegistrar paramScheduledTaskRegistrar);
}

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.annotation.SchedulingConfigurer
 * JD-Core Version:    0.6.0
 */