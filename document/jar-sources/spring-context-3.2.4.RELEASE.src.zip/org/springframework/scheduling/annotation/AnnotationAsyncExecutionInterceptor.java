/*    */ package org.springframework.scheduling.annotation;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import java.util.concurrent.Executor;
/*    */ import org.springframework.aop.interceptor.AsyncExecutionInterceptor;
/*    */ import org.springframework.core.annotation.AnnotationUtils;
/*    */ 
/*    */ public class AnnotationAsyncExecutionInterceptor extends AsyncExecutionInterceptor
/*    */ {
/*    */   public AnnotationAsyncExecutionInterceptor(Executor defaultExecutor)
/*    */   {
/* 45 */     super(defaultExecutor);
/*    */   }
/*    */ 
/*    */   protected String getExecutorQualifier(Method method)
/*    */   {
/* 63 */     Async async = (Async)AnnotationUtils.findAnnotation(method, Async.class);
/* 64 */     if (async == null) {
/* 65 */       async = (Async)AnnotationUtils.findAnnotation(method.getDeclaringClass(), Async.class);
/*    */     }
/* 67 */     return async != null ? async.value() : null;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.annotation.AnnotationAsyncExecutionInterceptor
 * JD-Core Version:    0.6.0
 */