/*    */ package org.springframework.scheduling.annotation;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.Iterator;
/*    */ import java.util.concurrent.Executor;
/*    */ import org.springframework.beans.factory.annotation.Autowired;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.context.annotation.ImportAware;
/*    */ import org.springframework.core.annotation.AnnotationAttributes;
/*    */ import org.springframework.core.type.AnnotationMetadata;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ @Configuration
/*    */ public abstract class AbstractAsyncConfiguration
/*    */   implements ImportAware
/*    */ {
/*    */   protected AnnotationAttributes enableAsync;
/*    */   protected Executor executor;
/*    */ 
/*    */   public void setImportMetadata(AnnotationMetadata importMetadata)
/*    */   {
/* 44 */     this.enableAsync = AnnotationAttributes.fromMap(importMetadata.getAnnotationAttributes(EnableAsync.class.getName(), false));
/*    */ 
/* 46 */     Assert.notNull(this.enableAsync, "@EnableAsync is not present on importing class " + importMetadata.getClassName());
/*    */   }
/*    */ 
/*    */   public abstract Object asyncAdvisor();
/*    */ 
/*    */   @Autowired(required=false)
/*    */   void setConfigurers(Collection<AsyncConfigurer> configurers)
/*    */   {
/* 63 */     if ((configurers == null) || (configurers.isEmpty())) {
/* 64 */       return;
/*    */     }
/*    */ 
/* 67 */     if (configurers.size() > 1) {
/* 68 */       throw new IllegalStateException("only one AsyncConfigurer may exist");
/*    */     }
/*    */ 
/* 71 */     AsyncConfigurer configurer = (AsyncConfigurer)configurers.iterator().next();
/* 72 */     this.executor = configurer.getAsyncExecutor();
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.annotation.AbstractAsyncConfiguration
 * JD-Core Version:    0.6.0
 */