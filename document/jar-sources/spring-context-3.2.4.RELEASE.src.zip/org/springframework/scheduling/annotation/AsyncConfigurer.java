package org.springframework.scheduling.annotation;

import java.util.concurrent.Executor;

public abstract interface AsyncConfigurer
{
  public abstract Executor getAsyncExecutor();
}

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.annotation.AsyncConfigurer
 * JD-Core Version:    0.6.0
 */