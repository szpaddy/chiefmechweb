package org.springframework.scheduling;

public abstract interface SchedulingAwareRunnable extends Runnable
{
  public abstract boolean isLongLived();
}

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.SchedulingAwareRunnable
 * JD-Core Version:    0.6.0
 */