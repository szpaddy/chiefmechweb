/*    */ package org.springframework.instrument.classloading.oc4j;
/*    */ 
/*    */ import java.lang.instrument.ClassFileTransformer;
/*    */ import java.lang.reflect.InvocationTargetException;
/*    */ import java.lang.reflect.Method;
/*    */ import java.lang.reflect.Proxy;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ class OC4JClassLoaderAdapter
/*    */ {
/*    */   private static final String CL_UTILS = "oracle.classloader.util.ClassLoaderUtilities";
/*    */   private static final String PREPROCESS_UTILS = "oracle.classloader.util.ClassPreprocessor";
/*    */   private final ClassLoader classLoader;
/*    */   private final Class<?> processorClass;
/*    */   private final Method addTransformer;
/*    */   private final Method copy;
/*    */ 
/*    */   public OC4JClassLoaderAdapter(ClassLoader classLoader)
/*    */   {
/*    */     try
/*    */     {
/* 46 */       Class utilClass = classLoader.loadClass("oracle.classloader.util.ClassLoaderUtilities");
/* 47 */       this.processorClass = classLoader.loadClass("oracle.classloader.util.ClassPreprocessor");
/*    */ 
/* 49 */       this.addTransformer = utilClass.getMethod("addPreprocessor", new Class[] { ClassLoader.class, this.processorClass });
/*    */ 
/* 51 */       this.copy = utilClass.getMethod("copy", new Class[] { ClassLoader.class });
/*    */     }
/*    */     catch (Exception ex) {
/* 54 */       throw new IllegalStateException("Could not initialize OC4J LoadTimeWeaver because OC4J API classes are not available", ex);
/*    */     }
/*    */ 
/* 58 */     this.classLoader = classLoader;
/*    */   }
/*    */ 
/*    */   public void addTransformer(ClassFileTransformer transformer) {
/* 62 */     Assert.notNull(transformer, "ClassFileTransformer must not be null");
/*    */     try {
/* 64 */       OC4JClassPreprocessorAdapter adapter = new OC4JClassPreprocessorAdapter(transformer);
/* 65 */       Object adapterInstance = Proxy.newProxyInstance(this.processorClass.getClassLoader(), new Class[] { this.processorClass }, adapter);
/*    */ 
/* 67 */       this.addTransformer.invoke(null, new Object[] { this.classLoader, adapterInstance });
/*    */     } catch (InvocationTargetException ex) {
/* 69 */       throw new IllegalStateException("OC4J addPreprocessor method threw exception", ex.getCause());
/*    */     } catch (Exception ex) {
/* 71 */       throw new IllegalStateException("Could not invoke OC4J addPreprocessor method", ex);
/*    */     }
/*    */   }
/*    */ 
/*    */   public ClassLoader getClassLoader() {
/* 76 */     return this.classLoader;
/*    */   }
/*    */ 
/*    */   public ClassLoader getThrowawayClassLoader() {
/*    */     try {
/* 81 */       return (ClassLoader)this.copy.invoke(null, new Object[] { this.classLoader });
/*    */     } catch (InvocationTargetException ex) {
/* 83 */       throw new IllegalStateException("OC4J copy method failed", ex.getCause()); } catch (Exception ex) {
/*    */     }
/* 85 */     throw new IllegalStateException("Could not copy OC4J classloader", ex);
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.instrument.classloading.oc4j.OC4JClassLoaderAdapter
 * JD-Core Version:    0.6.0
 */