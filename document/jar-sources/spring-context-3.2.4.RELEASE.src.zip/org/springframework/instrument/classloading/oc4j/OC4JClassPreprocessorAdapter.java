/*    */ package org.springframework.instrument.classloading.oc4j;
/*    */ 
/*    */ import java.lang.instrument.ClassFileTransformer;
/*    */ import java.lang.instrument.IllegalClassFormatException;
/*    */ import java.lang.reflect.InvocationHandler;
/*    */ import java.lang.reflect.Method;
/*    */ import java.security.ProtectionDomain;
/*    */ 
/*    */ class OC4JClassPreprocessorAdapter
/*    */   implements InvocationHandler
/*    */ {
/*    */   private final ClassFileTransformer transformer;
/*    */ 
/*    */   public OC4JClassPreprocessorAdapter(ClassFileTransformer transformer)
/*    */   {
/* 43 */     this.transformer = transformer;
/*    */   }
/*    */ 
/*    */   public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
/* 47 */     String name = method.getName();
/*    */ 
/* 49 */     if ("equals".equals(name))
/* 50 */       return Boolean.valueOf(proxy == args[0]);
/* 51 */     if ("hashCode".equals(name))
/* 52 */       return Integer.valueOf(hashCode());
/* 53 */     if ("toString".equals(name))
/* 54 */       return toString();
/* 55 */     if ("initialize".equals(name)) {
/* 56 */       initialize(proxy, (ClassLoader)args[0]);
/* 57 */       return null;
/* 58 */     }if ("processClass".equals(name)) {
/* 59 */       return processClass((String)args[0], (byte[])(byte[])args[1], ((Integer)args[2]).intValue(), ((Integer)args[3]).intValue(), (ProtectionDomain)args[4], (ClassLoader)args[5]);
/*    */     }
/*    */ 
/* 62 */     throw new IllegalArgumentException("Unknown method: " + method);
/*    */   }
/*    */ 
/*    */   public Object initialize(Object proxy, ClassLoader loader)
/*    */   {
/* 70 */     return proxy;
/*    */   }
/*    */ 
/*    */   public byte[] processClass(String className, byte[] origClassBytes, int offset, int length, ProtectionDomain pd, ClassLoader loader)
/*    */   {
/*    */     try {
/* 76 */       byte[] tempArray = new byte[length];
/* 77 */       System.arraycopy(origClassBytes, offset, tempArray, 0, length);
/*    */ 
/* 81 */       byte[] result = this.transformer.transform(loader, className.replace('.', '/'), null, pd, tempArray);
/* 82 */       return result != null ? result : origClassBytes; } catch (IllegalClassFormatException ex) {
/*    */     }
/* 84 */     throw new IllegalStateException("Cannot transform because of illegal class format", ex);
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 90 */     StringBuilder builder = new StringBuilder(getClass().getName());
/* 91 */     builder.append(" for transformer: ");
/* 92 */     builder.append(this.transformer);
/* 93 */     return builder.toString();
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.instrument.classloading.oc4j.OC4JClassPreprocessorAdapter
 * JD-Core Version:    0.6.0
 */