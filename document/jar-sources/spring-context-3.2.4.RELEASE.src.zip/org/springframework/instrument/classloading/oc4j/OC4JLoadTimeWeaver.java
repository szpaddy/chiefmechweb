/*    */ package org.springframework.instrument.classloading.oc4j;
/*    */ 
/*    */ import java.lang.instrument.ClassFileTransformer;
/*    */ import org.springframework.instrument.classloading.LoadTimeWeaver;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.util.ClassUtils;
/*    */ 
/*    */ @Deprecated
/*    */ public class OC4JLoadTimeWeaver
/*    */   implements LoadTimeWeaver
/*    */ {
/*    */   private final OC4JClassLoaderAdapter classLoader;
/*    */ 
/*    */   public OC4JLoadTimeWeaver()
/*    */   {
/* 51 */     this(ClassUtils.getDefaultClassLoader());
/*    */   }
/*    */ 
/*    */   public OC4JLoadTimeWeaver(ClassLoader classLoader)
/*    */   {
/* 60 */     Assert.notNull(classLoader, "ClassLoader must not be null");
/* 61 */     this.classLoader = new OC4JClassLoaderAdapter(classLoader);
/*    */   }
/*    */ 
/*    */   public void addTransformer(ClassFileTransformer transformer)
/*    */   {
/* 66 */     Assert.notNull(transformer, "Transformer must not be null");
/*    */ 
/* 69 */     this.classLoader.addTransformer(transformer);
/*    */   }
/*    */ 
/*    */   public ClassLoader getInstrumentableClassLoader() {
/* 73 */     return this.classLoader.getClassLoader();
/*    */   }
/*    */ 
/*    */   public ClassLoader getThrowawayClassLoader() {
/* 77 */     return this.classLoader.getThrowawayClassLoader();
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.instrument.classloading.oc4j.OC4JLoadTimeWeaver
 * JD-Core Version:    0.6.0
 */