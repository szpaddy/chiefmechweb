/*     */ package org.springframework.instrument.classloading;
/*     */ 
/*     */ import java.lang.instrument.ClassFileTransformer;
/*     */ import java.lang.instrument.IllegalClassFormatException;
/*     */ import java.lang.instrument.Instrumentation;
/*     */ import java.security.ProtectionDomain;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.springframework.instrument.InstrumentationSavingAgent;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ public class InstrumentationLoadTimeWeaver
/*     */   implements LoadTimeWeaver
/*     */ {
/*  51 */   private static final boolean AGENT_CLASS_PRESENT = ClassUtils.isPresent("org.springframework.instrument.InstrumentationSavingAgent", InstrumentationLoadTimeWeaver.class.getClassLoader());
/*     */   private final ClassLoader classLoader;
/*     */   private final Instrumentation instrumentation;
/*  60 */   private final List<ClassFileTransformer> transformers = new ArrayList(4);
/*     */ 
/*     */   public InstrumentationLoadTimeWeaver()
/*     */   {
/*  67 */     this(ClassUtils.getDefaultClassLoader());
/*     */   }
/*     */ 
/*     */   public InstrumentationLoadTimeWeaver(ClassLoader classLoader)
/*     */   {
/*  75 */     Assert.notNull(classLoader, "ClassLoader must not be null");
/*  76 */     this.classLoader = classLoader;
/*  77 */     this.instrumentation = getInstrumentation();
/*     */   }
/*     */ 
/*     */   public void addTransformer(ClassFileTransformer transformer)
/*     */   {
/*  82 */     Assert.notNull(transformer, "Transformer must not be null");
/*  83 */     FilteringClassFileTransformer actualTransformer = new FilteringClassFileTransformer(transformer, this.classLoader);
/*     */ 
/*  85 */     synchronized (this.transformers) {
/*  86 */       if (this.instrumentation == null) {
/*  87 */         throw new IllegalStateException("Must start with Java agent to use InstrumentationLoadTimeWeaver. See Spring documentation.");
/*     */       }
/*     */ 
/*  90 */       this.instrumentation.addTransformer(actualTransformer);
/*  91 */       this.transformers.add(actualTransformer);
/*     */     }
/*     */   }
/*     */ 
/*     */   public ClassLoader getInstrumentableClassLoader()
/*     */   {
/* 101 */     return this.classLoader;
/*     */   }
/*     */ 
/*     */   public ClassLoader getThrowawayClassLoader()
/*     */   {
/* 108 */     return new SimpleThrowawayClassLoader(getInstrumentableClassLoader());
/*     */   }
/*     */ 
/*     */   public void removeTransformers()
/*     */   {
/* 115 */     synchronized (this.transformers) {
/* 116 */       if (!this.transformers.isEmpty()) {
/* 117 */         for (int i = this.transformers.size() - 1; i >= 0; i--) {
/* 118 */           this.instrumentation.removeTransformer((ClassFileTransformer)this.transformers.get(i));
/*     */         }
/* 120 */         this.transformers.clear();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public static boolean isInstrumentationAvailable()
/*     */   {
/* 131 */     return getInstrumentation() != null;
/*     */   }
/*     */ 
/*     */   private static Instrumentation getInstrumentation()
/*     */   {
/* 140 */     if (AGENT_CLASS_PRESENT) {
/* 141 */       return InstrumentationAccessor.getInstrumentation();
/*     */     }
/*     */ 
/* 144 */     return null;
/*     */   }
/*     */ 
/*     */   private static class FilteringClassFileTransformer
/*     */     implements ClassFileTransformer
/*     */   {
/*     */     private final ClassFileTransformer targetTransformer;
/*     */     private final ClassLoader targetClassLoader;
/*     */ 
/*     */     public FilteringClassFileTransformer(ClassFileTransformer targetTransformer, ClassLoader targetClassLoader)
/*     */     {
/* 170 */       this.targetTransformer = targetTransformer;
/* 171 */       this.targetClassLoader = targetClassLoader;
/*     */     }
/*     */ 
/*     */     public byte[] transform(ClassLoader loader, String className, Class<?> classBeingRedefined, ProtectionDomain protectionDomain, byte[] classfileBuffer)
/*     */       throws IllegalClassFormatException
/*     */     {
/* 177 */       if (!this.targetClassLoader.equals(loader)) {
/* 178 */         return null;
/*     */       }
/* 180 */       return this.targetTransformer.transform(loader, className, classBeingRedefined, protectionDomain, classfileBuffer);
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/* 186 */       return "FilteringClassFileTransformer for: " + this.targetTransformer.toString();
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class InstrumentationAccessor
/*     */   {
/*     */     public static Instrumentation getInstrumentation()
/*     */     {
/* 155 */       return InstrumentationSavingAgent.getInstrumentation();
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.instrument.classloading.InstrumentationLoadTimeWeaver
 * JD-Core Version:    0.6.0
 */