/*     */ package org.springframework.instrument.classloading.glassfish;
/*     */ 
/*     */ import java.lang.instrument.ClassFileTransformer;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ 
/*     */ class GlassFishClassLoaderAdapter
/*     */ {
/*     */   static final String INSTRUMENTABLE_CLASSLOADER_GLASSFISH_V2 = "com.sun.enterprise.loader.InstrumentableClassLoader";
/*     */   static final String INSTRUMENTABLE_CLASSLOADER_GLASSFISH_V3 = "org.glassfish.api.deployment.InstrumentableClassLoader";
/*     */   private static final String CLASS_TRANSFORMER = "javax.persistence.spi.ClassTransformer";
/*     */   private final ClassLoader classLoader;
/*     */   private final Method addTransformer;
/*     */   private final Method copy;
/*     */   private final boolean glassFishV3;
/*     */ 
/*     */   public GlassFishClassLoaderAdapter(ClassLoader classLoader)
/*     */   {
/*  53 */     boolean glassV3 = false;
/*     */     Class instrumentableLoaderClass;
/*     */     try
/*     */     {
/*  56 */       instrumentableLoaderClass = classLoader.loadClass("com.sun.enterprise.loader.InstrumentableClassLoader");
/*     */     }
/*     */     catch (ClassNotFoundException ex)
/*     */     {
/*     */       try {
/*  61 */         instrumentableLoaderClass = classLoader.loadClass("org.glassfish.api.deployment.InstrumentableClassLoader");
/*  62 */         glassV3 = true;
/*     */       }
/*     */       catch (ClassNotFoundException cnfe) {
/*  65 */         throw new IllegalStateException("Could not initialize GlassFish LoadTimeWeaver because GlassFish (V1, V2 or V3) API classes are not available", ex);
/*     */       }
/*     */     }
/*     */     try
/*     */     {
/*  70 */       Class classTransformerClass = glassV3 ? ClassFileTransformer.class : classLoader.loadClass("javax.persistence.spi.ClassTransformer");
/*     */ 
/*  73 */       this.addTransformer = instrumentableLoaderClass.getMethod("addTransformer", new Class[] { classTransformerClass });
/*  74 */       this.copy = instrumentableLoaderClass.getMethod("copy", new Class[0]);
/*     */     }
/*     */     catch (Exception ex) {
/*  77 */       throw new IllegalStateException("Could not initialize GlassFish LoadTimeWeaver because GlassFish API classes are not available", ex);
/*     */     }
/*     */ 
/*  81 */     ClassLoader clazzLoader = null;
/*     */ 
/*  84 */     for (ClassLoader cl = classLoader; (cl != null) && (clazzLoader == null); cl = cl.getParent()) {
/*  85 */       if (instrumentableLoaderClass.isInstance(cl)) {
/*  86 */         clazzLoader = cl;
/*     */       }
/*     */     }
/*     */ 
/*  90 */     if (clazzLoader == null) {
/*  91 */       throw new IllegalArgumentException(classLoader + " and its parents are not suitable ClassLoaders: A [" + instrumentableLoaderClass.getName() + "] implementation is required.");
/*     */     }
/*     */ 
/*  95 */     this.classLoader = clazzLoader;
/*  96 */     this.glassFishV3 = glassV3;
/*     */   }
/*     */ 
/*     */   public void addTransformer(ClassFileTransformer transformer) {
/*     */     try {
/* 101 */       this.addTransformer.invoke(this.classLoader, new Object[] { this.glassFishV3 ? transformer : new ClassTransformerAdapter(transformer) });
/*     */     }
/*     */     catch (InvocationTargetException ex)
/*     */     {
/* 105 */       throw new IllegalStateException("GlassFish addTransformer method threw exception ", ex.getCause());
/*     */     }
/*     */     catch (Exception ex) {
/* 108 */       throw new IllegalStateException("Could not invoke GlassFish addTransformer method", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public ClassLoader getClassLoader() {
/* 113 */     return this.classLoader;
/*     */   }
/*     */ 
/*     */   public ClassLoader getThrowawayClassLoader() {
/*     */     try {
/* 118 */       return (ClassLoader)this.copy.invoke(this.classLoader, new Object[0]);
/*     */     }
/*     */     catch (InvocationTargetException ex) {
/* 121 */       throw new IllegalStateException("GlassFish copy method threw exception ", ex.getCause());
/*     */     } catch (Exception ex) {
/*     */     }
/* 124 */     throw new IllegalStateException("Could not invoke GlassFish copy method", ex);
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.instrument.classloading.glassfish.GlassFishClassLoaderAdapter
 * JD-Core Version:    0.6.0
 */