/*    */ package org.springframework.instrument.classloading.glassfish;
/*    */ 
/*    */ import java.lang.instrument.ClassFileTransformer;
/*    */ import java.lang.instrument.IllegalClassFormatException;
/*    */ import java.security.ProtectionDomain;
/*    */ import javax.persistence.spi.ClassTransformer;
/*    */ 
/*    */ class ClassTransformerAdapter
/*    */   implements ClassTransformer
/*    */ {
/*    */   private final ClassFileTransformer classFileTransformer;
/*    */ 
/*    */   public ClassTransformerAdapter(ClassFileTransformer classFileTransformer)
/*    */   {
/* 42 */     this.classFileTransformer = classFileTransformer;
/*    */   }
/*    */ 
/*    */   public byte[] transform(ClassLoader loader, String className, Class<?> classBeingRedefined, ProtectionDomain protectionDomain, byte[] classfileBuffer)
/*    */     throws IllegalClassFormatException
/*    */   {
/* 48 */     byte[] result = this.classFileTransformer.transform(loader, className, classBeingRedefined, protectionDomain, classfileBuffer);
/*    */ 
/* 52 */     return result == classfileBuffer ? null : result;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.instrument.classloading.glassfish.ClassTransformerAdapter
 * JD-Core Version:    0.6.0
 */