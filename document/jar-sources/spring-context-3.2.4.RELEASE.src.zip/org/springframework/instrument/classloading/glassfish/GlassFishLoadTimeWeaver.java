/*    */ package org.springframework.instrument.classloading.glassfish;
/*    */ 
/*    */ import java.lang.instrument.ClassFileTransformer;
/*    */ import org.springframework.instrument.classloading.LoadTimeWeaver;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.util.ClassUtils;
/*    */ 
/*    */ public class GlassFishLoadTimeWeaver
/*    */   implements LoadTimeWeaver
/*    */ {
/*    */   private final GlassFishClassLoaderAdapter classLoader;
/*    */ 
/*    */   public GlassFishLoadTimeWeaver()
/*    */   {
/* 46 */     this(ClassUtils.getDefaultClassLoader());
/*    */   }
/*    */ 
/*    */   public GlassFishLoadTimeWeaver(ClassLoader classLoader)
/*    */   {
/* 57 */     Assert.notNull(classLoader, "ClassLoader must not be null");
/* 58 */     this.classLoader = new GlassFishClassLoaderAdapter(classLoader);
/*    */   }
/*    */ 
/*    */   public void addTransformer(ClassFileTransformer transformer)
/*    */   {
/* 63 */     this.classLoader.addTransformer(transformer);
/*    */   }
/*    */ 
/*    */   public ClassLoader getInstrumentableClassLoader() {
/* 67 */     return this.classLoader.getClassLoader();
/*    */   }
/*    */ 
/*    */   public ClassLoader getThrowawayClassLoader() {
/* 71 */     return this.classLoader.getThrowawayClassLoader();
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.instrument.classloading.glassfish.GlassFishLoadTimeWeaver
 * JD-Core Version:    0.6.0
 */