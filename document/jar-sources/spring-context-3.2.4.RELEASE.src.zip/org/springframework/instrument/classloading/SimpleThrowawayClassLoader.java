/*    */ package org.springframework.instrument.classloading;
/*    */ 
/*    */ import org.springframework.core.OverridingClassLoader;
/*    */ 
/*    */ public class SimpleThrowawayClassLoader extends OverridingClassLoader
/*    */ {
/*    */   public SimpleThrowawayClassLoader(ClassLoader parent)
/*    */   {
/* 36 */     super(parent);
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.instrument.classloading.SimpleThrowawayClassLoader
 * JD-Core Version:    0.6.0
 */