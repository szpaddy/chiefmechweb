/*     */ package org.springframework.instrument.classloading.websphere;
/*     */ 
/*     */ import java.lang.instrument.ClassFileTransformer;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.InvocationHandler;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Proxy;
/*     */ import java.util.List;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ class WebSphereClassLoaderAdapter
/*     */ {
/*     */   private static final String COMPOUND_CLASS_LOADER_NAME = "com.ibm.ws.classloader.CompoundClassLoader";
/*     */   private static final String CLASS_PRE_PROCESSOR_NAME = "com.ibm.websphere.classloader.ClassLoaderInstancePreDefinePlugin";
/*     */   private static final String PLUGINS_FIELD = "preDefinePlugins";
/*     */   private ClassLoader classLoader;
/*     */   private Class<?> wsPreProcessorClass;
/*     */   private Method addPreDefinePlugin;
/*     */   private Constructor<? extends ClassLoader> cloneConstructor;
/*     */   private Field transformerList;
/*     */ 
/*     */   public WebSphereClassLoaderAdapter(ClassLoader classLoader)
/*     */   {
/*  52 */     Class wsCompoundClassLoaderClass = null;
/*     */     try {
/*  54 */       wsCompoundClassLoaderClass = classLoader.loadClass("com.ibm.ws.classloader.CompoundClassLoader");
/*  55 */       this.cloneConstructor = classLoader.getClass().getDeclaredConstructor(new Class[] { wsCompoundClassLoaderClass });
/*  56 */       this.cloneConstructor.setAccessible(true);
/*     */ 
/*  58 */       this.wsPreProcessorClass = classLoader.loadClass("com.ibm.websphere.classloader.ClassLoaderInstancePreDefinePlugin");
/*  59 */       this.addPreDefinePlugin = classLoader.getClass().getMethod("addPreDefinePlugin", new Class[] { this.wsPreProcessorClass });
/*  60 */       this.transformerList = wsCompoundClassLoaderClass.getDeclaredField("preDefinePlugins");
/*  61 */       this.transformerList.setAccessible(true);
/*     */     }
/*     */     catch (Exception ex) {
/*  64 */       throw new IllegalStateException("Could not initialize WebSphere LoadTimeWeaver because WebSphere 7 API classes are not available", ex);
/*     */     }
/*     */ 
/*  68 */     Assert.isInstanceOf(wsCompoundClassLoaderClass, classLoader, "ClassLoader must be instance of [com.ibm.ws.classloader.CompoundClassLoader]");
/*     */ 
/*  70 */     this.classLoader = classLoader;
/*     */   }
/*     */ 
/*     */   public ClassLoader getClassLoader() {
/*  74 */     return this.classLoader;
/*     */   }
/*     */ 
/*     */   public void addTransformer(ClassFileTransformer transformer) {
/*  78 */     Assert.notNull(transformer, "ClassFileTransformer must not be null");
/*     */     try {
/*  80 */       InvocationHandler adapter = new WebSphereClassPreDefinePlugin(transformer);
/*  81 */       Object adapterInstance = Proxy.newProxyInstance(this.wsPreProcessorClass.getClassLoader(), new Class[] { this.wsPreProcessorClass }, adapter);
/*     */ 
/*  83 */       this.addPreDefinePlugin.invoke(this.classLoader, new Object[] { adapterInstance });
/*     */     }
/*     */     catch (InvocationTargetException ex)
/*     */     {
/*  87 */       throw new IllegalStateException("WebSphere addPreDefinePlugin method threw exception", ex.getCause());
/*     */     }
/*     */     catch (Exception ex) {
/*  90 */       throw new IllegalStateException("Could not invoke WebSphere addPreDefinePlugin method", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public ClassLoader getThrowawayClassLoader() {
/*     */     try {
/*  96 */       ClassLoader loader = (ClassLoader)this.cloneConstructor.newInstance(new Object[] { getClassLoader() });
/*     */ 
/*  98 */       List list = (List)this.transformerList.get(loader);
/*  99 */       list.clear();
/* 100 */       return loader;
/*     */     }
/*     */     catch (InvocationTargetException ex) {
/* 103 */       throw new IllegalStateException("WebSphere CompoundClassLoader constructor failed", ex.getCause());
/*     */     } catch (Exception ex) {
/*     */     }
/* 106 */     throw new IllegalStateException("Could not construct WebSphere CompoundClassLoader", ex);
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.instrument.classloading.websphere.WebSphereClassLoaderAdapter
 * JD-Core Version:    0.6.0
 */