/*    */ package org.springframework.instrument.classloading.websphere;
/*    */ 
/*    */ import java.lang.instrument.ClassFileTransformer;
/*    */ import java.lang.reflect.InvocationHandler;
/*    */ import java.lang.reflect.Method;
/*    */ import java.security.CodeSource;
/*    */ import org.springframework.util.FileCopyUtils;
/*    */ 
/*    */ class WebSphereClassPreDefinePlugin
/*    */   implements InvocationHandler
/*    */ {
/*    */   private final ClassFileTransformer transformer;
/*    */ 
/*    */   public WebSphereClassPreDefinePlugin(ClassFileTransformer transformer)
/*    */   {
/* 46 */     this.transformer = transformer;
/* 47 */     ClassLoader classLoader = transformer.getClass().getClassLoader();
/*    */     try
/*    */     {
/* 51 */       String dummyClass = Dummy.class.getName().replace('.', '/');
/* 52 */       byte[] bytes = FileCopyUtils.copyToByteArray(classLoader.getResourceAsStream(dummyClass + ".class"));
/* 53 */       transformer.transform(classLoader, dummyClass, null, null, bytes);
/*    */     }
/*    */     catch (Throwable ex) {
/* 56 */       throw new IllegalArgumentException("Cannot load transformer", ex);
/*    */     }
/*    */   }
/*    */ 
/*    */   public Object invoke(Object proxy, Method method, Object[] args) throws Throwable
/*    */   {
/* 62 */     String name = method.getName();
/* 63 */     if ("equals".equals(name)) {
/* 64 */       return Boolean.valueOf(proxy == args[0]);
/*    */     }
/* 66 */     if ("hashCode".equals(name)) {
/* 67 */       return Integer.valueOf(hashCode());
/*    */     }
/* 69 */     if ("toString".equals(name)) {
/* 70 */       return toString();
/*    */     }
/* 72 */     if ("transformClass".equals(name)) {
/* 73 */       return transform((String)args[0], (byte[])(byte[])args[1], (CodeSource)args[2], (ClassLoader)args[3]);
/*    */     }
/*    */ 
/* 76 */     throw new IllegalArgumentException("Unknown method: " + method);
/*    */   }
/*    */ 
/*    */   protected byte[] transform(String className, byte[] classfileBuffer, CodeSource codeSource, ClassLoader classLoader)
/*    */     throws Exception
/*    */   {
/* 84 */     byte[] result = this.transformer.transform(classLoader, className.replace('.', '/'), null, null, classfileBuffer);
/* 85 */     return result != null ? result : classfileBuffer;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 90 */     StringBuilder builder = new StringBuilder(getClass().getName());
/* 91 */     builder.append(" for transformer: ");
/* 92 */     builder.append(this.transformer);
/* 93 */     return builder.toString();
/*    */   }
/*    */ 
/*    */   private static class Dummy
/*    */   {
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.instrument.classloading.websphere.WebSphereClassPreDefinePlugin
 * JD-Core Version:    0.6.0
 */