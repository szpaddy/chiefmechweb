/*    */ package org.springframework.instrument.classloading.websphere;
/*    */ 
/*    */ import java.lang.instrument.ClassFileTransformer;
/*    */ import org.springframework.instrument.classloading.LoadTimeWeaver;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.util.ClassUtils;
/*    */ 
/*    */ public class WebSphereLoadTimeWeaver
/*    */   implements LoadTimeWeaver
/*    */ {
/*    */   private final WebSphereClassLoaderAdapter classLoader;
/*    */ 
/*    */   public WebSphereLoadTimeWeaver()
/*    */   {
/* 43 */     this(ClassUtils.getDefaultClassLoader());
/*    */   }
/*    */ 
/*    */   public WebSphereLoadTimeWeaver(ClassLoader classLoader)
/*    */   {
/* 53 */     Assert.notNull(classLoader, "ClassLoader must not be null");
/* 54 */     this.classLoader = new WebSphereClassLoaderAdapter(classLoader);
/*    */   }
/*    */ 
/*    */   public void addTransformer(ClassFileTransformer transformer)
/*    */   {
/* 59 */     this.classLoader.addTransformer(transformer);
/*    */   }
/*    */ 
/*    */   public ClassLoader getInstrumentableClassLoader() {
/* 63 */     return this.classLoader.getClassLoader();
/*    */   }
/*    */ 
/*    */   public ClassLoader getThrowawayClassLoader() {
/* 67 */     return this.classLoader.getThrowawayClassLoader();
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.instrument.classloading.websphere.WebSphereLoadTimeWeaver
 * JD-Core Version:    0.6.0
 */