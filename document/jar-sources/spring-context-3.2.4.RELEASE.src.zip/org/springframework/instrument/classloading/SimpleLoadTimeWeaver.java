/*    */ package org.springframework.instrument.classloading;
/*    */ 
/*    */ import java.lang.instrument.ClassFileTransformer;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.util.ClassUtils;
/*    */ 
/*    */ public class SimpleLoadTimeWeaver
/*    */   implements LoadTimeWeaver
/*    */ {
/*    */   private final SimpleInstrumentableClassLoader classLoader;
/*    */ 
/*    */   public SimpleLoadTimeWeaver()
/*    */   {
/* 50 */     this.classLoader = new SimpleInstrumentableClassLoader(ClassUtils.getDefaultClassLoader());
/*    */   }
/*    */ 
/*    */   public SimpleLoadTimeWeaver(SimpleInstrumentableClassLoader classLoader)
/*    */   {
/* 60 */     Assert.notNull(classLoader, "ClassLoader must not be null");
/* 61 */     this.classLoader = classLoader;
/*    */   }
/*    */ 
/*    */   public void addTransformer(ClassFileTransformer transformer)
/*    */   {
/* 66 */     this.classLoader.addTransformer(transformer);
/*    */   }
/*    */ 
/*    */   public ClassLoader getInstrumentableClassLoader() {
/* 70 */     return this.classLoader;
/*    */   }
/*    */ 
/*    */   public ClassLoader getThrowawayClassLoader()
/*    */   {
/* 77 */     return new SimpleThrowawayClassLoader(getInstrumentableClassLoader());
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.instrument.classloading.SimpleLoadTimeWeaver
 * JD-Core Version:    0.6.0
 */