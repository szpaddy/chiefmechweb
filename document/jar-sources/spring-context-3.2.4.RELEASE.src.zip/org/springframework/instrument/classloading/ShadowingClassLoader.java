/*     */ package org.springframework.instrument.classloading;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.lang.instrument.ClassFileTransformer;
/*     */ import java.lang.instrument.IllegalClassFormatException;
/*     */ import java.net.URL;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.springframework.core.DecoratingClassLoader;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.FileCopyUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class ShadowingClassLoader extends DecoratingClassLoader
/*     */ {
/*  49 */   public static final String[] DEFAULT_EXCLUDED_PACKAGES = { "java.", "javax.", "sun.", "oracle.", "com.sun.", "com.ibm.", "COM.ibm.", "org.w3c.", "org.xml.", "org.dom4j.", "org.eclipse", "org.aspectj.", "net.sf.cglib", "org.springframework.cglib", "org.apache.xerces.", "org.apache.commons.logging." };
/*     */   private final ClassLoader enclosingClassLoader;
/*  57 */   private final List<ClassFileTransformer> classFileTransformers = new LinkedList();
/*     */ 
/*  59 */   private final Map<String, Class> classCache = new HashMap();
/*     */ 
/*     */   public ShadowingClassLoader(ClassLoader enclosingClassLoader)
/*     */   {
/*  67 */     Assert.notNull(enclosingClassLoader, "Enclosing ClassLoader must not be null");
/*  68 */     this.enclosingClassLoader = enclosingClassLoader;
/*  69 */     for (String excludedPackage : DEFAULT_EXCLUDED_PACKAGES)
/*  70 */       excludePackage(excludedPackage);
/*     */   }
/*     */ 
/*     */   public void addTransformer(ClassFileTransformer transformer)
/*     */   {
/*  81 */     Assert.notNull(transformer, "Transformer must not be null");
/*  82 */     this.classFileTransformers.add(transformer);
/*     */   }
/*     */ 
/*     */   public void copyTransformers(ShadowingClassLoader other)
/*     */   {
/*  91 */     Assert.notNull(other, "Other ClassLoader must not be null");
/*  92 */     this.classFileTransformers.addAll(other.classFileTransformers);
/*     */   }
/*     */ 
/*     */   public Class<?> loadClass(String name)
/*     */     throws ClassNotFoundException
/*     */   {
/*  98 */     if (shouldShadow(name)) {
/*  99 */       Class cls = (Class)this.classCache.get(name);
/* 100 */       if (cls != null) {
/* 101 */         return cls;
/*     */       }
/* 103 */       return doLoadClass(name);
/*     */     }
/*     */ 
/* 106 */     return this.enclosingClassLoader.loadClass(name);
/*     */   }
/*     */ 
/*     */   private boolean shouldShadow(String className)
/*     */   {
/* 116 */     return (!className.equals(getClass().getName())) && (!className.endsWith("ShadowingClassLoader")) && (isEligibleForShadowing(className));
/*     */   }
/*     */ 
/*     */   protected boolean isEligibleForShadowing(String className)
/*     */   {
/* 128 */     return !isExcluded(className);
/*     */   }
/*     */ 
/*     */   private Class doLoadClass(String name) throws ClassNotFoundException
/*     */   {
/* 133 */     String internalName = StringUtils.replace(name, ".", "/") + ".class";
/* 134 */     InputStream is = this.enclosingClassLoader.getResourceAsStream(internalName);
/* 135 */     if (is == null)
/* 136 */       throw new ClassNotFoundException(name);
/*     */     try
/*     */     {
/* 139 */       byte[] bytes = FileCopyUtils.copyToByteArray(is);
/* 140 */       bytes = applyTransformers(name, bytes);
/* 141 */       Class cls = defineClass(name, bytes, 0, bytes.length);
/*     */ 
/* 143 */       if (cls.getPackage() == null) {
/* 144 */         int packageSeparator = name.lastIndexOf('.');
/* 145 */         if (packageSeparator != -1) {
/* 146 */           String packageName = name.substring(0, packageSeparator);
/* 147 */           definePackage(packageName, null, null, null, null, null, null, null);
/*     */         }
/*     */       }
/* 150 */       this.classCache.put(name, cls);
/* 151 */       return cls;
/*     */     } catch (IOException ex) {
/*     */     }
/* 154 */     throw new ClassNotFoundException("Cannot load resource for class [" + name + "]", ex);
/*     */   }
/*     */ 
/*     */   private byte[] applyTransformers(String name, byte[] bytes)
/*     */   {
/* 159 */     String internalName = StringUtils.replace(name, ".", "/");
/*     */     try {
/* 161 */       for (ClassFileTransformer transformer : this.classFileTransformers) {
/* 162 */         byte[] transformed = transformer.transform(this, internalName, null, null, bytes);
/* 163 */         bytes = transformed != null ? transformed : bytes;
/*     */       }
/* 165 */       return bytes;
/*     */     } catch (IllegalClassFormatException ex) {
/*     */     }
/* 168 */     throw new IllegalStateException(ex);
/*     */   }
/*     */ 
/*     */   public URL getResource(String name)
/*     */   {
/* 175 */     return this.enclosingClassLoader.getResource(name);
/*     */   }
/*     */ 
/*     */   public InputStream getResourceAsStream(String name)
/*     */   {
/* 180 */     return this.enclosingClassLoader.getResourceAsStream(name);
/*     */   }
/*     */ 
/*     */   public Enumeration<URL> getResources(String name) throws IOException
/*     */   {
/* 185 */     return this.enclosingClassLoader.getResources(name);
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.instrument.classloading.ShadowingClassLoader
 * JD-Core Version:    0.6.0
 */