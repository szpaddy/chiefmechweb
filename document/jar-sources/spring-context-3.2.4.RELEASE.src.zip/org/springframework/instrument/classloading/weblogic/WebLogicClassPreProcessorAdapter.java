/*    */ package org.springframework.instrument.classloading.weblogic;
/*    */ 
/*    */ import java.lang.instrument.ClassFileTransformer;
/*    */ import java.lang.instrument.IllegalClassFormatException;
/*    */ import java.lang.reflect.InvocationHandler;
/*    */ import java.lang.reflect.Method;
/*    */ import java.util.Hashtable;
/*    */ 
/*    */ class WebLogicClassPreProcessorAdapter
/*    */   implements InvocationHandler
/*    */ {
/*    */   private final ClassFileTransformer transformer;
/*    */   private final ClassLoader loader;
/*    */ 
/*    */   public WebLogicClassPreProcessorAdapter(ClassFileTransformer transformer, ClassLoader loader)
/*    */   {
/* 48 */     this.transformer = transformer;
/* 49 */     this.loader = loader;
/*    */   }
/*    */ 
/*    */   public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
/* 53 */     String name = method.getName();
/*    */ 
/* 55 */     if ("equals".equals(name))
/* 56 */       return Boolean.valueOf(proxy == args[0]);
/* 57 */     if ("hashCode".equals(name))
/* 58 */       return Integer.valueOf(hashCode());
/* 59 */     if ("toString".equals(name))
/* 60 */       return toString();
/* 61 */     if ("initialize".equals(name)) {
/* 62 */       initialize((Hashtable)args[0]);
/* 63 */       return null;
/* 64 */     }if ("preProcess".equals(name)) {
/* 65 */       return preProcess((String)args[0], (byte[])(byte[])args[1]);
/*    */     }
/* 67 */     throw new IllegalArgumentException("Unknown method: " + method);
/*    */   }
/*    */ 
/*    */   public void initialize(Hashtable params)
/*    */   {
/*    */   }
/*    */ 
/*    */   public byte[] preProcess(String className, byte[] classBytes) {
/*    */     try {
/* 76 */       byte[] result = this.transformer.transform(this.loader, className, null, null, classBytes);
/* 77 */       return result != null ? result : classBytes; } catch (IllegalClassFormatException ex) {
/*    */     }
/* 79 */     throw new IllegalStateException("Cannot transform due to illegal class format", ex);
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 85 */     StringBuilder builder = new StringBuilder(getClass().getName());
/* 86 */     builder.append(" for transformer: ");
/* 87 */     builder.append(this.transformer);
/* 88 */     return builder.toString();
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.instrument.classloading.weblogic.WebLogicClassPreProcessorAdapter
 * JD-Core Version:    0.6.0
 */