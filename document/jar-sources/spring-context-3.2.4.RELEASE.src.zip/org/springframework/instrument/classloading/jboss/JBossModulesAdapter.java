/*    */ package org.springframework.instrument.classloading.jboss;
/*    */ 
/*    */ import java.lang.instrument.ClassFileTransformer;
/*    */ import java.lang.reflect.Field;
/*    */ import java.lang.reflect.Method;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.util.ReflectionUtils;
/*    */ 
/*    */ class JBossModulesAdapter
/*    */   implements JBossClassLoaderAdapter
/*    */ {
/*    */   private static final String TRANSFORMER_FIELD_NAME = "transformer";
/*    */   private static final String TRANSFORMER_ADD_METHOD_NAME = "addTransformer";
/*    */   private static final String DELEGATING_TRANSFORMER_CLASS_NAME = "org.jboss.as.server.deployment.module.DelegatingClassFileTransformer";
/*    */   private final ClassLoader classLoader;
/*    */   private final Method addTransformer;
/*    */   private final Object delegatingTransformer;
/*    */ 
/*    */   public JBossModulesAdapter(ClassLoader loader)
/*    */   {
/* 42 */     this.classLoader = loader;
/*    */     try
/*    */     {
/* 45 */       Field transformers = ReflectionUtils.findField(this.classLoader.getClass(), "transformer");
/* 46 */       transformers.setAccessible(true);
/*    */ 
/* 48 */       this.delegatingTransformer = transformers.get(this.classLoader);
/*    */ 
/* 50 */       Assert.state(this.delegatingTransformer.getClass().getName().equals("org.jboss.as.server.deployment.module.DelegatingClassFileTransformer"), "Transformer not of the expected type: " + this.delegatingTransformer.getClass().getName());
/*    */ 
/* 52 */       this.addTransformer = ReflectionUtils.findMethod(this.delegatingTransformer.getClass(), "addTransformer", new Class[] { ClassFileTransformer.class });
/*    */ 
/* 54 */       this.addTransformer.setAccessible(true);
/*    */     } catch (Exception ex) {
/* 56 */       throw new IllegalStateException("Could not initialize JBoss 7 LoadTimeWeaver", ex);
/*    */     }
/*    */   }
/*    */ 
/*    */   public void addTransformer(ClassFileTransformer transformer) {
/*    */     try {
/* 62 */       this.addTransformer.invoke(this.delegatingTransformer, new Object[] { transformer });
/*    */     } catch (Exception ex) {
/* 64 */       throw new IllegalStateException("Could not add transformer on JBoss 7 classloader " + this.classLoader, ex);
/*    */     }
/*    */   }
/*    */ 
/*    */   public ClassLoader getInstrumentableClassLoader() {
/* 69 */     return this.classLoader;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.instrument.classloading.jboss.JBossModulesAdapter
 * JD-Core Version:    0.6.0
 */