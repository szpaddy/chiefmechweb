package org.springframework.instrument.classloading.jboss;

import java.lang.instrument.ClassFileTransformer;

abstract interface JBossClassLoaderAdapter
{
  public abstract void addTransformer(ClassFileTransformer paramClassFileTransformer);

  public abstract ClassLoader getInstrumentableClassLoader();
}

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.instrument.classloading.jboss.JBossClassLoaderAdapter
 * JD-Core Version:    0.6.0
 */