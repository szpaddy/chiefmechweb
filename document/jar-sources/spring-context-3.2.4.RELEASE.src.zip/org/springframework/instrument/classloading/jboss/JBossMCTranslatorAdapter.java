/*    */ package org.springframework.instrument.classloading.jboss;
/*    */ 
/*    */ import java.lang.instrument.ClassFileTransformer;
/*    */ import java.lang.reflect.InvocationHandler;
/*    */ import java.lang.reflect.Method;
/*    */ import java.security.ProtectionDomain;
/*    */ 
/*    */ class JBossMCTranslatorAdapter
/*    */   implements InvocationHandler
/*    */ {
/*    */   private final ClassFileTransformer transformer;
/*    */ 
/*    */   public JBossMCTranslatorAdapter(ClassFileTransformer transformer)
/*    */   {
/* 43 */     this.transformer = transformer;
/*    */   }
/*    */ 
/*    */   public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
/* 47 */     String name = method.getName();
/*    */ 
/* 49 */     if ("equals".equals(name))
/* 50 */       return Boolean.valueOf(proxy == args[0]);
/* 51 */     if ("hashCode".equals(name))
/* 52 */       return Integer.valueOf(hashCode());
/* 53 */     if ("toString".equals(name))
/* 54 */       return toString();
/* 55 */     if ("transform".equals(name)) {
/* 56 */       return transform((ClassLoader)args[0], (String)args[1], (Class)args[2], (ProtectionDomain)args[3], (byte[])(byte[])args[4]);
/*    */     }
/* 58 */     if ("unregisterClassLoader".equals(name)) {
/* 59 */       unregisterClassLoader((ClassLoader)args[0]);
/* 60 */       return null;
/*    */     }
/*    */ 
/* 63 */     throw new IllegalArgumentException("Unknown method: " + method);
/*    */   }
/*    */ 
/*    */   public byte[] transform(ClassLoader loader, String className, Class<?> classBeingRedefined, ProtectionDomain protectionDomain, byte[] classfileBuffer)
/*    */     throws Exception
/*    */   {
/* 69 */     return this.transformer.transform(loader, className, classBeingRedefined, protectionDomain, classfileBuffer);
/*    */   }
/*    */ 
/*    */   public void unregisterClassLoader(ClassLoader loader)
/*    */   {
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 77 */     StringBuilder builder = new StringBuilder(getClass().getName());
/* 78 */     builder.append(" for transformer: ");
/* 79 */     builder.append(this.transformer);
/* 80 */     return builder.toString();
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.instrument.classloading.jboss.JBossMCTranslatorAdapter
 * JD-Core Version:    0.6.0
 */