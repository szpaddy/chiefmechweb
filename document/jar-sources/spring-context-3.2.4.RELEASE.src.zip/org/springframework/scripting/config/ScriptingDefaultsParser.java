/*    */ package org.springframework.scripting.config;
/*    */ 
/*    */ import org.springframework.beans.MutablePropertyValues;
/*    */ import org.springframework.beans.factory.config.BeanDefinition;
/*    */ import org.springframework.beans.factory.config.TypedStringValue;
/*    */ import org.springframework.beans.factory.xml.BeanDefinitionParser;
/*    */ import org.springframework.beans.factory.xml.ParserContext;
/*    */ import org.springframework.util.StringUtils;
/*    */ import org.w3c.dom.Element;
/*    */ 
/*    */ public class ScriptingDefaultsParser
/*    */   implements BeanDefinitionParser
/*    */ {
/*    */   private static final String REFRESH_CHECK_DELAY_ATTRIBUTE = "refresh-check-delay";
/*    */   private static final String PROXY_TARGET_CLASS_ATTRIBUTE = "proxy-target-class";
/*    */ 
/*    */   public BeanDefinition parse(Element element, ParserContext parserContext)
/*    */   {
/* 39 */     BeanDefinition bd = LangNamespaceUtils.registerScriptFactoryPostProcessorIfNecessary(parserContext.getRegistry());
/*    */ 
/* 41 */     String refreshCheckDelay = element.getAttribute("refresh-check-delay");
/* 42 */     if (StringUtils.hasText(refreshCheckDelay)) {
/* 43 */       bd.getPropertyValues().add("defaultRefreshCheckDelay", new Long(refreshCheckDelay));
/*    */     }
/* 45 */     String proxyTargetClass = element.getAttribute("proxy-target-class");
/* 46 */     if (StringUtils.hasText(proxyTargetClass)) {
/* 47 */       bd.getPropertyValues().add("defaultProxyTargetClass", new TypedStringValue(proxyTargetClass, Boolean.class));
/*    */     }
/* 49 */     return null;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.scripting.config.ScriptingDefaultsParser
 * JD-Core Version:    0.6.0
 */