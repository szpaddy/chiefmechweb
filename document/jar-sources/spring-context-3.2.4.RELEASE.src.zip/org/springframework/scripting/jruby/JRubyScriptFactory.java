/*     */ package org.springframework.scripting.jruby;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import org.jruby.RubyException;
/*     */ import org.jruby.exceptions.JumpException;
/*     */ import org.jruby.exceptions.RaiseException;
/*     */ import org.springframework.beans.factory.BeanClassLoaderAware;
/*     */ import org.springframework.scripting.ScriptCompilationException;
/*     */ import org.springframework.scripting.ScriptFactory;
/*     */ import org.springframework.scripting.ScriptSource;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ public class JRubyScriptFactory
/*     */   implements ScriptFactory, BeanClassLoaderAware
/*     */ {
/*     */   private final String scriptSourceLocator;
/*     */   private final Class[] scriptInterfaces;
/*  52 */   private ClassLoader beanClassLoader = ClassUtils.getDefaultClassLoader();
/*     */ 
/*     */   public JRubyScriptFactory(String scriptSourceLocator, Class[] scriptInterfaces)
/*     */   {
/*  63 */     Assert.hasText(scriptSourceLocator, "'scriptSourceLocator' must not be empty");
/*  64 */     Assert.notEmpty(scriptInterfaces, "'scriptInterfaces' must not be empty");
/*  65 */     this.scriptSourceLocator = scriptSourceLocator;
/*  66 */     this.scriptInterfaces = scriptInterfaces;
/*     */   }
/*     */ 
/*     */   public void setBeanClassLoader(ClassLoader classLoader)
/*     */   {
/*  71 */     this.beanClassLoader = classLoader;
/*     */   }
/*     */ 
/*     */   public String getScriptSourceLocator()
/*     */   {
/*  76 */     return this.scriptSourceLocator;
/*     */   }
/*     */ 
/*     */   public Class[] getScriptInterfaces() {
/*  80 */     return this.scriptInterfaces;
/*     */   }
/*     */ 
/*     */   public boolean requiresConfigInterface()
/*     */   {
/*  87 */     return true;
/*     */   }
/*     */ 
/*     */   public Object getScriptedObject(ScriptSource scriptSource, Class[] actualInterfaces)
/*     */     throws IOException, ScriptCompilationException
/*     */   {
/*     */     try
/*     */     {
/*  97 */       return JRubyScriptUtils.createJRubyObject(scriptSource.getScriptAsString(), actualInterfaces, this.beanClassLoader);
/*     */     }
/*     */     catch (RaiseException ex)
/*     */     {
/* 101 */       RubyException rubyEx = ex.getException();
/* 102 */       String msg = (rubyEx != null) && (rubyEx.message != null) ? rubyEx.message.toString() : "Unexpected JRuby error";
/*     */ 
/* 104 */       throw new ScriptCompilationException(scriptSource, msg, ex);
/*     */     } catch (JumpException ex) {
/*     */     }
/* 107 */     throw new ScriptCompilationException(scriptSource, ex);
/*     */   }
/*     */ 
/*     */   public Class getScriptedObjectType(ScriptSource scriptSource)
/*     */     throws IOException, ScriptCompilationException
/*     */   {
/* 114 */     return null;
/*     */   }
/*     */ 
/*     */   public boolean requiresScriptedObjectRefresh(ScriptSource scriptSource) {
/* 118 */     return scriptSource.isModified();
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 124 */     return "JRubyScriptFactory: script source locator [" + this.scriptSourceLocator + "]";
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.scripting.jruby.JRubyScriptFactory
 * JD-Core Version:    0.6.0
 */