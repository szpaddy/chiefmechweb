/*     */ package org.springframework.scripting.bsh;
/*     */ 
/*     */ import bsh.EvalError;
/*     */ import java.io.IOException;
/*     */ import org.springframework.beans.factory.BeanClassLoaderAware;
/*     */ import org.springframework.scripting.ScriptCompilationException;
/*     */ import org.springframework.scripting.ScriptFactory;
/*     */ import org.springframework.scripting.ScriptSource;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ public class BshScriptFactory
/*     */   implements ScriptFactory, BeanClassLoaderAware
/*     */ {
/*     */   private final String scriptSourceLocator;
/*     */   private final Class[] scriptInterfaces;
/*  50 */   private ClassLoader beanClassLoader = ClassUtils.getDefaultClassLoader();
/*     */   private Class scriptClass;
/*  54 */   private final Object scriptClassMonitor = new Object();
/*     */ 
/*  56 */   private boolean wasModifiedForTypeCheck = false;
/*     */ 
/*     */   public BshScriptFactory(String scriptSourceLocator)
/*     */   {
/*  67 */     this(scriptSourceLocator, null);
/*     */   }
/*     */ 
/*     */   public BshScriptFactory(String scriptSourceLocator, Class[] scriptInterfaces)
/*     */   {
/*  82 */     Assert.hasText(scriptSourceLocator, "'scriptSourceLocator' must not be empty");
/*  83 */     this.scriptSourceLocator = scriptSourceLocator;
/*  84 */     this.scriptInterfaces = scriptInterfaces;
/*     */   }
/*     */ 
/*     */   public void setBeanClassLoader(ClassLoader classLoader) {
/*  88 */     this.beanClassLoader = classLoader;
/*     */   }
/*     */ 
/*     */   public String getScriptSourceLocator()
/*     */   {
/*  93 */     return this.scriptSourceLocator;
/*     */   }
/*     */ 
/*     */   public Class[] getScriptInterfaces() {
/*  97 */     return this.scriptInterfaces;
/*     */   }
/*     */ 
/*     */   public boolean requiresConfigInterface()
/*     */   {
/* 104 */     return true;
/*     */   }
/*     */ 
/*     */   public Object getScriptedObject(ScriptSource scriptSource, Class[] actualInterfaces)
/*     */     throws IOException, ScriptCompilationException
/*     */   {
/*     */     try
/*     */     {
/* 115 */       Class clazz = null;
/*     */ 
/* 117 */       synchronized (this.scriptClassMonitor) {
/* 118 */         boolean requiresScriptEvaluation = (this.wasModifiedForTypeCheck) && (this.scriptClass == null);
/* 119 */         this.wasModifiedForTypeCheck = false;
/*     */ 
/* 121 */         if ((scriptSource.isModified()) || (requiresScriptEvaluation))
/*     */         {
/* 123 */           Object result = BshScriptUtils.evaluateBshScript(scriptSource.getScriptAsString(), actualInterfaces, this.beanClassLoader);
/*     */ 
/* 125 */           if ((result instanceof Class))
/*     */           {
/* 128 */             this.scriptClass = ((Class)result);
/*     */           }
/*     */           else
/*     */           {
/* 135 */             return result;
/*     */           }
/*     */         }
/* 138 */         clazz = this.scriptClass;
/*     */       }
/*     */ 
/* 141 */       if (clazz != null) {
/*     */         try
/*     */         {
/* 144 */           return clazz.newInstance();
/*     */         }
/*     */         catch (Throwable ex) {
/* 147 */           throw new ScriptCompilationException(scriptSource, "Could not instantiate script class: " + clazz.getName(), ex);
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 153 */       return BshScriptUtils.createBshObject(scriptSource.getScriptAsString(), actualInterfaces, this.beanClassLoader);
/*     */     }
/*     */     catch (EvalError ex)
/*     */     {
/*     */     }
/* 158 */     throw new ScriptCompilationException(scriptSource, ex);
/*     */   }
/*     */ 
/*     */   public Class getScriptedObjectType(ScriptSource scriptSource)
/*     */     throws IOException, ScriptCompilationException
/*     */   {
/*     */     try
/*     */     {
/* 166 */       synchronized (this.scriptClassMonitor) {
/* 167 */         if (scriptSource.isModified())
/*     */         {
/* 169 */           this.wasModifiedForTypeCheck = true;
/* 170 */           this.scriptClass = BshScriptUtils.determineBshObjectType(scriptSource.getScriptAsString());
/*     */         }
/* 172 */         return this.scriptClass;
/*     */       }
/*     */     } catch (EvalError ex) {
/*     */     }
/* 176 */     throw new ScriptCompilationException(scriptSource, ex);
/*     */   }
/*     */ 
/*     */   public boolean requiresScriptedObjectRefresh(ScriptSource scriptSource)
/*     */   {
/* 181 */     synchronized (this.scriptClassMonitor) {
/* 182 */       return (scriptSource.isModified()) || (this.wasModifiedForTypeCheck);
/*     */     }
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 189 */     return "BshScriptFactory: script source locator [" + this.scriptSourceLocator + "]";
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.scripting.bsh.BshScriptFactory
 * JD-Core Version:    0.6.0
 */