/*     */ package org.springframework.scripting.groovy;
/*     */ 
/*     */ import groovy.lang.GroovyClassLoader;
/*     */ import groovy.lang.GroovyObject;
/*     */ import groovy.lang.MetaClass;
/*     */ import groovy.lang.Script;
/*     */ import java.io.IOException;
/*     */ import org.codehaus.groovy.control.CompilationFailedException;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.BeanClassLoaderAware;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.scripting.ScriptCompilationException;
/*     */ import org.springframework.scripting.ScriptFactory;
/*     */ import org.springframework.scripting.ScriptSource;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ public class GroovyScriptFactory
/*     */   implements ScriptFactory, BeanFactoryAware, BeanClassLoaderAware
/*     */ {
/*     */   private final String scriptSourceLocator;
/*     */   private final GroovyObjectCustomizer groovyObjectCustomizer;
/*     */   private GroovyClassLoader groovyClassLoader;
/*     */   private Class scriptClass;
/*     */   private Class scriptResultClass;
/*     */   private CachedResultHolder cachedResult;
/*  67 */   private final Object scriptClassMonitor = new Object();
/*     */ 
/*  69 */   private boolean wasModifiedForTypeCheck = false;
/*     */ 
/*     */   public GroovyScriptFactory(String scriptSourceLocator)
/*     */   {
/*  80 */     this(scriptSourceLocator, null);
/*     */   }
/*     */ 
/*     */   public GroovyScriptFactory(String scriptSourceLocator, GroovyObjectCustomizer groovyObjectCustomizer)
/*     */   {
/*  96 */     Assert.hasText(scriptSourceLocator, "'scriptSourceLocator' must not be empty");
/*  97 */     this.scriptSourceLocator = scriptSourceLocator;
/*  98 */     this.groovyObjectCustomizer = groovyObjectCustomizer;
/*     */   }
/*     */ 
/*     */   public void setBeanFactory(BeanFactory beanFactory) throws BeansException
/*     */   {
/* 103 */     if ((beanFactory instanceof ConfigurableListableBeanFactory))
/* 104 */       ((ConfigurableListableBeanFactory)beanFactory).ignoreDependencyType(MetaClass.class);
/*     */   }
/*     */ 
/*     */   public void setBeanClassLoader(ClassLoader classLoader)
/*     */   {
/* 109 */     this.groovyClassLoader = new GroovyClassLoader(classLoader);
/*     */   }
/*     */ 
/*     */   public GroovyClassLoader getGroovyClassLoader()
/*     */   {
/* 116 */     synchronized (this.scriptClassMonitor) {
/* 117 */       if (this.groovyClassLoader == null) {
/* 118 */         this.groovyClassLoader = new GroovyClassLoader(ClassUtils.getDefaultClassLoader());
/*     */       }
/* 120 */       return this.groovyClassLoader;
/*     */     }
/*     */   }
/*     */ 
/*     */   public String getScriptSourceLocator()
/*     */   {
/* 126 */     return this.scriptSourceLocator;
/*     */   }
/*     */ 
/*     */   public Class[] getScriptInterfaces()
/*     */   {
/* 135 */     return null;
/*     */   }
/*     */ 
/*     */   public boolean requiresConfigInterface()
/*     */   {
/* 143 */     return false;
/*     */   }
/*     */ 
/*     */   public Object getScriptedObject(ScriptSource scriptSource, Class[] actualInterfaces)
/*     */     throws IOException, ScriptCompilationException
/*     */   {
/*     */     try
/*     */     {
/* 155 */       Class scriptClassToExecute = null;
/*     */ 
/* 157 */       synchronized (this.scriptClassMonitor) {
/* 158 */         this.wasModifiedForTypeCheck = false;
/*     */ 
/* 160 */         if (this.cachedResult != null) {
/* 161 */           Object result = this.cachedResult.object;
/* 162 */           this.cachedResult = null;
/* 163 */           return result;
/*     */         }
/*     */ 
/* 166 */         if ((this.scriptClass == null) || (scriptSource.isModified()))
/*     */         {
/* 168 */           this.scriptClass = getGroovyClassLoader().parseClass(scriptSource.getScriptAsString(), scriptSource.suggestedClassName());
/*     */ 
/* 171 */           if (Script.class.isAssignableFrom(this.scriptClass))
/*     */           {
/* 173 */             Object result = executeScript(scriptSource, this.scriptClass);
/* 174 */             this.scriptResultClass = (result != null ? result.getClass() : null);
/* 175 */             return result;
/*     */           }
/*     */ 
/* 178 */           this.scriptResultClass = this.scriptClass;
/*     */         }
/*     */ 
/* 181 */         scriptClassToExecute = this.scriptClass;
/*     */       }
/*     */ 
/* 185 */       return executeScript(scriptSource, scriptClassToExecute);
/*     */     } catch (CompilationFailedException ex) {
/*     */     }
/* 188 */     throw new ScriptCompilationException(scriptSource, ex);
/*     */   }
/*     */ 
/*     */   public Class getScriptedObjectType(ScriptSource scriptSource)
/*     */     throws IOException, ScriptCompilationException
/*     */   {
/*     */     try
/*     */     {
/* 196 */       synchronized (this.scriptClassMonitor) {
/* 197 */         if ((this.scriptClass == null) || (scriptSource.isModified()))
/*     */         {
/* 199 */           this.wasModifiedForTypeCheck = true;
/* 200 */           this.scriptClass = getGroovyClassLoader().parseClass(scriptSource.getScriptAsString(), scriptSource.suggestedClassName());
/*     */ 
/* 203 */           if (Script.class.isAssignableFrom(this.scriptClass))
/*     */           {
/* 205 */             Object result = executeScript(scriptSource, this.scriptClass);
/* 206 */             this.scriptResultClass = (result != null ? result.getClass() : null);
/* 207 */             this.cachedResult = new CachedResultHolder(result);
/*     */           }
/*     */           else {
/* 210 */             this.scriptResultClass = this.scriptClass;
/*     */           }
/*     */         }
/* 213 */         return this.scriptResultClass;
/*     */       }
/*     */     } catch (CompilationFailedException ex) {
/*     */     }
/* 217 */     throw new ScriptCompilationException(scriptSource, ex);
/*     */   }
/*     */ 
/*     */   public boolean requiresScriptedObjectRefresh(ScriptSource scriptSource)
/*     */   {
/* 222 */     synchronized (this.scriptClassMonitor) {
/* 223 */       return (scriptSource.isModified()) || (this.wasModifiedForTypeCheck);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected Object executeScript(ScriptSource scriptSource, Class scriptClass)
/*     */     throws ScriptCompilationException
/*     */   {
/*     */     try
/*     */     {
/* 238 */       GroovyObject goo = (GroovyObject)scriptClass.newInstance();
/*     */ 
/* 240 */       if (this.groovyObjectCustomizer != null)
/*     */       {
/* 242 */         this.groovyObjectCustomizer.customize(goo);
/*     */       }
/*     */ 
/* 245 */       if ((goo instanceof Script))
/*     */       {
/* 247 */         return ((Script)goo).run();
/*     */       }
/*     */ 
/* 251 */       return goo;
/*     */     }
/*     */     catch (InstantiationException ex)
/*     */     {
/* 255 */       throw new ScriptCompilationException(scriptSource, "Could not instantiate Groovy script class: " + scriptClass.getName(), ex);
/*     */     }
/*     */     catch (IllegalAccessException ex) {
/*     */     }
/* 259 */     throw new ScriptCompilationException(scriptSource, "Could not access Groovy script constructor: " + scriptClass.getName(), ex);
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 267 */     return "GroovyScriptFactory: script source locator [" + this.scriptSourceLocator + "]";
/*     */   }
/*     */ 
/*     */   private static class CachedResultHolder
/*     */   {
/*     */     public final Object object;
/*     */ 
/*     */     public CachedResultHolder(Object object)
/*     */     {
/* 279 */       this.object = object;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.scripting.groovy.GroovyScriptFactory
 * JD-Core Version:    0.6.0
 */