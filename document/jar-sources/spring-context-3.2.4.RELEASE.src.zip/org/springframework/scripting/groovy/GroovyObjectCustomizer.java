package org.springframework.scripting.groovy;

import groovy.lang.GroovyObject;

public abstract interface GroovyObjectCustomizer
{
  public abstract void customize(GroovyObject paramGroovyObject);
}

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.scripting.groovy.GroovyObjectCustomizer
 * JD-Core Version:    0.6.0
 */