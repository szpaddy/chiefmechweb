/*     */ package org.springframework.scripting.support;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.Reader;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.scripting.ScriptSource;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.FileCopyUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class ResourceScriptSource
/*     */   implements ScriptSource
/*     */ {
/*  50 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   private final Resource resource;
/*  54 */   private long lastModified = -1L;
/*     */ 
/*  56 */   private final Object lastModifiedMonitor = new Object();
/*     */ 
/*  58 */   private String encoding = "UTF-8";
/*     */ 
/*     */   public ResourceScriptSource(Resource resource)
/*     */   {
/*  65 */     Assert.notNull(resource, "Resource must not be null");
/*  66 */     this.resource = resource;
/*     */   }
/*     */ 
/*     */   public final Resource getResource()
/*     */   {
/*  74 */     return this.resource;
/*     */   }
/*     */ 
/*     */   public String getScriptAsString() throws IOException {
/*  78 */     synchronized (this.lastModifiedMonitor) {
/*  79 */       this.lastModified = retrieveLastModifiedTime();
/*     */     }
/*     */ 
/*  82 */     InputStream stream = this.resource.getInputStream();
/*  83 */     Object reader = StringUtils.hasText(this.encoding) ? new InputStreamReader(stream, this.encoding) : new InputStreamReader(stream);
/*     */ 
/*  86 */     return (String)FileCopyUtils.copyToString((Reader)reader);
/*     */   }
/*     */ 
/*     */   public boolean isModified() {
/*  90 */     synchronized (this.lastModifiedMonitor) {
/*  91 */       return (this.lastModified < 0L) || (retrieveLastModifiedTime() > this.lastModified);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected long retrieveLastModifiedTime()
/*     */   {
/*     */     try
/*     */     {
/* 101 */       return getResource().lastModified();
/*     */     } catch (IOException ex) {
/* 103 */       if (this.logger.isDebugEnabled()) {
/* 104 */         this.logger.debug(getResource() + " could not be resolved in the file system - " + "current timestamp not available for script modification check", ex);
/*     */       }
/*     */     }
/* 107 */     return 0L;
/*     */   }
/*     */ 
/*     */   public String suggestedClassName()
/*     */   {
/* 112 */     return StringUtils.stripFilenameExtension(getResource().getFilename());
/*     */   }
/*     */ 
/*     */   public void setEncoding(String encoding)
/*     */   {
/* 122 */     this.encoding = encoding;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 127 */     return this.resource.toString();
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.scripting.support.ResourceScriptSource
 * JD-Core Version:    0.6.0
 */