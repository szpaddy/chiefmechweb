/*    */ package org.springframework.cache.support;
/*    */ 
/*    */ import org.springframework.cache.Cache.ValueWrapper;
/*    */ 
/*    */ public class SimpleValueWrapper
/*    */   implements Cache.ValueWrapper
/*    */ {
/*    */   private final Object value;
/*    */ 
/*    */   public SimpleValueWrapper(Object value)
/*    */   {
/* 38 */     this.value = value;
/*    */   }
/*    */ 
/*    */   public Object get()
/*    */   {
/* 46 */     return this.value;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.cache.support.SimpleValueWrapper
 * JD-Core Version:    0.6.0
 */