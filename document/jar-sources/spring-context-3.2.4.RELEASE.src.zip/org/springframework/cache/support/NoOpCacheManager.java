/*    */ package org.springframework.cache.support;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.Collections;
/*    */ import java.util.LinkedHashSet;
/*    */ import java.util.Set;
/*    */ import java.util.concurrent.ConcurrentHashMap;
/*    */ import java.util.concurrent.ConcurrentMap;
/*    */ import org.springframework.cache.Cache;
/*    */ import org.springframework.cache.Cache.ValueWrapper;
/*    */ import org.springframework.cache.CacheManager;
/*    */ 
/*    */ public class NoOpCacheManager
/*    */   implements CacheManager
/*    */ {
/*    */   private final ConcurrentMap<String, Cache> caches;
/*    */   private final Set<String> cacheNames;
/*    */ 
/*    */   public NoOpCacheManager()
/*    */   {
/* 42 */     this.caches = new ConcurrentHashMap(16);
/*    */ 
/* 44 */     this.cacheNames = new LinkedHashSet(16);
/*    */   }
/*    */ 
/*    */   public Cache getCache(String name)
/*    */   {
/* 52 */     Cache cache = (Cache)this.caches.get(name);
/* 53 */     if (cache == null) {
/* 54 */       this.caches.putIfAbsent(name, new NoOpCache(name));
/* 55 */       synchronized (this.cacheNames) {
/* 56 */         this.cacheNames.add(name);
/*    */       }
/*    */     }
/*    */ 
/* 60 */     return (Cache)this.caches.get(name);
/*    */   }
/*    */ 
/*    */   public Collection<String> getCacheNames()
/*    */   {
/* 67 */     synchronized (this.cacheNames) {
/* 68 */       return Collections.unmodifiableSet(this.cacheNames);
/*    */     }
/*    */   }
/*    */ 
/*    */   private static class NoOpCache implements Cache
/*    */   {
/*    */     private final String name;
/*    */ 
/*    */     public NoOpCache(String name) {
/* 78 */       this.name = name;
/*    */     }
/*    */ 
/*    */     public void clear() {
/*    */     }
/*    */ 
/*    */     public void evict(Object key) {
/*    */     }
/*    */ 
/*    */     public Cache.ValueWrapper get(Object key) {
/* 88 */       return null;
/*    */     }
/*    */ 
/*    */     public String getName() {
/* 92 */       return this.name;
/*    */     }
/*    */ 
/*    */     public Object getNativeCache() {
/* 96 */       return null;
/*    */     }
/*    */ 
/*    */     public void put(Object key, Object value)
/*    */     {
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.cache.support.NoOpCacheManager
 * JD-Core Version:    0.6.0
 */