/*     */ package org.springframework.cache.concurrent;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ import org.springframework.cache.Cache;
/*     */ import org.springframework.cache.Cache.ValueWrapper;
/*     */ import org.springframework.cache.support.SimpleValueWrapper;
/*     */ 
/*     */ public class ConcurrentMapCache
/*     */   implements Cache
/*     */ {
/*  45 */   private static final Object NULL_HOLDER = new NullHolder(null);
/*     */   private final String name;
/*     */   private final ConcurrentMap<Object, Object> store;
/*     */   private final boolean allowNullValues;
/*     */ 
/*     */   public ConcurrentMapCache(String name)
/*     */   {
/*  59 */     this(name, new ConcurrentHashMap(256), true);
/*     */   }
/*     */ 
/*     */   public ConcurrentMapCache(String name, boolean allowNullValues)
/*     */   {
/*  68 */     this(name, new ConcurrentHashMap(256), allowNullValues);
/*     */   }
/*     */ 
/*     */   public ConcurrentMapCache(String name, ConcurrentMap<Object, Object> store, boolean allowNullValues)
/*     */   {
/*  80 */     this.name = name;
/*  81 */     this.store = store;
/*  82 */     this.allowNullValues = allowNullValues;
/*     */   }
/*     */ 
/*     */   public String getName()
/*     */   {
/*  87 */     return this.name;
/*     */   }
/*     */ 
/*     */   public ConcurrentMap getNativeCache() {
/*  91 */     return this.store;
/*     */   }
/*     */ 
/*     */   public boolean isAllowNullValues() {
/*  95 */     return this.allowNullValues;
/*     */   }
/*     */ 
/*     */   public Cache.ValueWrapper get(Object key) {
/*  99 */     Object value = this.store.get(key);
/* 100 */     return value != null ? new SimpleValueWrapper(fromStoreValue(value)) : null;
/*     */   }
/*     */ 
/*     */   public void put(Object key, Object value) {
/* 104 */     this.store.put(key, toStoreValue(value));
/*     */   }
/*     */ 
/*     */   public void evict(Object key) {
/* 108 */     this.store.remove(key);
/*     */   }
/*     */ 
/*     */   public void clear() {
/* 112 */     this.store.clear();
/*     */   }
/*     */ 
/*     */   protected Object fromStoreValue(Object storeValue)
/*     */   {
/* 123 */     if ((this.allowNullValues) && (storeValue == NULL_HOLDER)) {
/* 124 */       return null;
/*     */     }
/* 126 */     return storeValue;
/*     */   }
/*     */ 
/*     */   protected Object toStoreValue(Object userValue)
/*     */   {
/* 136 */     if ((this.allowNullValues) && (userValue == null)) {
/* 137 */       return NULL_HOLDER;
/*     */     }
/* 139 */     return userValue;
/*     */   }
/*     */ 
/*     */   private static class NullHolder
/*     */     implements Serializable
/*     */   {
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.cache.concurrent.ConcurrentMapCache
 * JD-Core Version:    0.6.0
 */