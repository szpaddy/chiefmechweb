/*    */ package org.springframework.cache.concurrent;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.Collection;
/*    */ import java.util.Collections;
/*    */ import java.util.concurrent.ConcurrentHashMap;
/*    */ import java.util.concurrent.ConcurrentMap;
/*    */ import org.springframework.cache.Cache;
/*    */ import org.springframework.cache.CacheManager;
/*    */ 
/*    */ public class ConcurrentMapCacheManager
/*    */   implements CacheManager
/*    */ {
/* 39 */   private final ConcurrentMap<String, Cache> cacheMap = new ConcurrentHashMap(16);
/*    */ 
/* 41 */   private boolean dynamic = true;
/*    */ 
/*    */   public ConcurrentMapCacheManager()
/*    */   {
/*    */   }
/*    */ 
/*    */   public ConcurrentMapCacheManager(String[] cacheNames)
/*    */   {
/* 56 */     setCacheNames(Arrays.asList(cacheNames));
/*    */   }
/*    */ 
/*    */   public void setCacheNames(Collection<String> cacheNames)
/*    */   {
/* 66 */     if (cacheNames != null) {
/* 67 */       for (String name : cacheNames) {
/* 68 */         this.cacheMap.put(name, createConcurrentMapCache(name));
/*    */       }
/* 70 */       this.dynamic = false;
/*    */     }
/*    */   }
/*    */ 
/*    */   public Collection<String> getCacheNames() {
/* 75 */     return Collections.unmodifiableSet(this.cacheMap.keySet());
/*    */   }
/*    */ 
/*    */   public Cache getCache(String name) {
/* 79 */     Cache cache = (Cache)this.cacheMap.get(name);
/* 80 */     if ((cache == null) && (this.dynamic)) {
/* 81 */       synchronized (this.cacheMap) {
/* 82 */         cache = (Cache)this.cacheMap.get(name);
/* 83 */         if (cache == null) {
/* 84 */           cache = createConcurrentMapCache(name);
/* 85 */           this.cacheMap.put(name, cache);
/*    */         }
/*    */       }
/*    */     }
/* 89 */     return cache;
/*    */   }
/*    */ 
/*    */   protected Cache createConcurrentMapCache(String name)
/*    */   {
/* 98 */     return new ConcurrentMapCache(name);
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.cache.concurrent.ConcurrentMapCacheManager
 * JD-Core Version:    0.6.0
 */