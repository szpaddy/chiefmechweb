package org.springframework.cache.annotation;

import org.springframework.cache.CacheManager;
import org.springframework.cache.interceptor.KeyGenerator;

public abstract interface CachingConfigurer
{
  public abstract CacheManager cacheManager();

  public abstract KeyGenerator keyGenerator();
}

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.cache.annotation.CachingConfigurer
 * JD-Core Version:    0.6.0
 */