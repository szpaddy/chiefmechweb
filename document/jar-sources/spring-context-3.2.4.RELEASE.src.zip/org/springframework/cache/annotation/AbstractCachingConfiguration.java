/*    */ package org.springframework.cache.annotation;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.Iterator;
/*    */ import javax.annotation.PostConstruct;
/*    */ import org.springframework.beans.factory.annotation.Autowired;
/*    */ import org.springframework.cache.CacheManager;
/*    */ import org.springframework.cache.interceptor.KeyGenerator;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.context.annotation.ImportAware;
/*    */ import org.springframework.core.annotation.AnnotationAttributes;
/*    */ import org.springframework.core.type.AnnotationMetadata;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.util.CollectionUtils;
/*    */ 
/*    */ @Configuration
/*    */ public abstract class AbstractCachingConfiguration
/*    */   implements ImportAware
/*    */ {
/*    */   protected AnnotationAttributes enableCaching;
/*    */   protected CacheManager cacheManager;
/*    */   protected KeyGenerator keyGenerator;
/*    */ 
/*    */   @Autowired(required=false)
/*    */   private Collection<CacheManager> cacheManagerBeans;
/*    */ 
/*    */   @Autowired(required=false)
/*    */   private Collection<CachingConfigurer> cachingConfigurers;
/*    */ 
/*    */   public void setImportMetadata(AnnotationMetadata importMetadata)
/*    */   {
/* 54 */     this.enableCaching = AnnotationAttributes.fromMap(importMetadata.getAnnotationAttributes(EnableCaching.class.getName(), false));
/*    */ 
/* 56 */     Assert.notNull(this.enableCaching, "@EnableCaching is not present on importing class " + importMetadata.getClassName());
/*    */   }
/*    */ 
/*    */   @PostConstruct
/*    */   protected void reconcileCacheManager()
/*    */   {
/* 71 */     if (!CollectionUtils.isEmpty(this.cachingConfigurers)) {
/* 72 */       int nConfigurers = this.cachingConfigurers.size();
/* 73 */       if (nConfigurers > 1) {
/* 74 */         throw new IllegalStateException(nConfigurers + " implementations of " + "CachingConfigurer were found when only 1 was expected. " + "Refactor the configuration such that CachingConfigurer is " + "implemented only once or not at all.");
/*    */       }
/*    */ 
/* 79 */       CachingConfigurer cachingConfigurer = (CachingConfigurer)this.cachingConfigurers.iterator().next();
/* 80 */       this.cacheManager = cachingConfigurer.cacheManager();
/* 81 */       this.keyGenerator = cachingConfigurer.keyGenerator();
/*    */     }
/* 83 */     else if (!CollectionUtils.isEmpty(this.cacheManagerBeans)) {
/* 84 */       int nManagers = this.cacheManagerBeans.size();
/* 85 */       if (nManagers > 1) {
/* 86 */         throw new IllegalStateException(nManagers + " beans of type CacheManager " + "were found when only 1 was expected. Remove all but one of the " + "CacheManager bean definitions, or implement CachingConfigurer " + "to make explicit which CacheManager should be used for " + "annotation-driven cache management.");
/*    */       }
/*    */ 
/* 92 */       CacheManager cacheManager = (CacheManager)this.cacheManagerBeans.iterator().next();
/* 93 */       this.cacheManager = cacheManager;
/*    */     }
/*    */     else
/*    */     {
/* 97 */       throw new IllegalStateException("No bean of type CacheManager could be found. Register a CacheManager bean or remove the @EnableCaching annotation from your configuration.");
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.cache.annotation.AbstractCachingConfiguration
 * JD-Core Version:    0.6.0
 */