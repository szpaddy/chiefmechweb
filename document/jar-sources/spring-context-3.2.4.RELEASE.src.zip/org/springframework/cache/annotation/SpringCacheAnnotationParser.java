/*     */ package org.springframework.cache.annotation;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.AnnotatedElement;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import org.springframework.cache.interceptor.CacheEvictOperation;
/*     */ import org.springframework.cache.interceptor.CacheOperation;
/*     */ import org.springframework.cache.interceptor.CachePutOperation;
/*     */ import org.springframework.cache.interceptor.CacheableOperation;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ public class SpringCacheAnnotationParser
/*     */   implements CacheAnnotationParser, Serializable
/*     */ {
/*     */   public Collection<CacheOperation> parseCacheAnnotations(AnnotatedElement ae)
/*     */   {
/*  45 */     Collection ops = null;
/*     */ 
/*  47 */     Collection cacheables = getAnnotations(ae, Cacheable.class);
/*  48 */     if (cacheables != null) {
/*  49 */       ops = lazyInit(ops);
/*  50 */       for (Cacheable cacheable : cacheables) {
/*  51 */         ops.add(parseCacheableAnnotation(ae, cacheable));
/*     */       }
/*     */     }
/*  54 */     Collection evicts = getAnnotations(ae, CacheEvict.class);
/*  55 */     if (evicts != null) {
/*  56 */       ops = lazyInit(ops);
/*  57 */       for (CacheEvict e : evicts) {
/*  58 */         ops.add(parseEvictAnnotation(ae, e));
/*     */       }
/*     */     }
/*  61 */     Collection updates = getAnnotations(ae, CachePut.class);
/*  62 */     if (updates != null) {
/*  63 */       ops = lazyInit(ops);
/*  64 */       for (CachePut p : updates) {
/*  65 */         ops.add(parseUpdateAnnotation(ae, p));
/*     */       }
/*     */     }
/*  68 */     Collection caching = getAnnotations(ae, Caching.class);
/*  69 */     if (caching != null) {
/*  70 */       ops = lazyInit(ops);
/*  71 */       for (Caching c : caching) {
/*  72 */         ops.addAll(parseCachingAnnotation(ae, c));
/*     */       }
/*     */     }
/*  75 */     return ops;
/*     */   }
/*     */ 
/*     */   private <T extends Annotation> Collection<CacheOperation> lazyInit(Collection<CacheOperation> ops) {
/*  79 */     return ops != null ? ops : new ArrayList(1);
/*     */   }
/*     */ 
/*     */   CacheableOperation parseCacheableAnnotation(AnnotatedElement ae, Cacheable caching) {
/*  83 */     CacheableOperation cuo = new CacheableOperation();
/*  84 */     cuo.setCacheNames(caching.value());
/*  85 */     cuo.setCondition(caching.condition());
/*  86 */     cuo.setUnless(caching.unless());
/*  87 */     cuo.setKey(caching.key());
/*  88 */     cuo.setName(ae.toString());
/*  89 */     return cuo;
/*     */   }
/*     */ 
/*     */   CacheEvictOperation parseEvictAnnotation(AnnotatedElement ae, CacheEvict caching) {
/*  93 */     CacheEvictOperation ceo = new CacheEvictOperation();
/*  94 */     ceo.setCacheNames(caching.value());
/*  95 */     ceo.setCondition(caching.condition());
/*  96 */     ceo.setKey(caching.key());
/*  97 */     ceo.setCacheWide(caching.allEntries());
/*  98 */     ceo.setBeforeInvocation(caching.beforeInvocation());
/*  99 */     ceo.setName(ae.toString());
/* 100 */     return ceo;
/*     */   }
/*     */ 
/*     */   CacheOperation parseUpdateAnnotation(AnnotatedElement ae, CachePut caching) {
/* 104 */     CachePutOperation cuo = new CachePutOperation();
/* 105 */     cuo.setCacheNames(caching.value());
/* 106 */     cuo.setCondition(caching.condition());
/* 107 */     cuo.setUnless(caching.unless());
/* 108 */     cuo.setKey(caching.key());
/* 109 */     cuo.setName(ae.toString());
/* 110 */     return cuo;
/*     */   }
/*     */ 
/*     */   Collection<CacheOperation> parseCachingAnnotation(AnnotatedElement ae, Caching caching) {
/* 114 */     Collection ops = null;
/*     */ 
/* 116 */     Cacheable[] cacheables = caching.cacheable();
/* 117 */     if (!ObjectUtils.isEmpty(cacheables)) {
/* 118 */       ops = lazyInit(ops);
/* 119 */       for (Cacheable cacheable : cacheables) {
/* 120 */         ops.add(parseCacheableAnnotation(ae, cacheable));
/*     */       }
/*     */     }
/* 123 */     CacheEvict[] evicts = caching.evict();
/* 124 */     if (!ObjectUtils.isEmpty(evicts)) {
/* 125 */       ops = lazyInit(ops);
/* 126 */       for (CacheEvict evict : evicts) {
/* 127 */         ops.add(parseEvictAnnotation(ae, evict));
/*     */       }
/*     */     }
/* 130 */     CachePut[] updates = caching.put();
/* 131 */     if (!ObjectUtils.isEmpty(updates)) {
/* 132 */       ops = lazyInit(ops);
/* 133 */       for (CachePut update : updates) {
/* 134 */         ops.add(parseUpdateAnnotation(ae, update));
/*     */       }
/*     */     }
/*     */ 
/* 138 */     return ops;
/*     */   }
/*     */ 
/*     */   private <T extends Annotation> Collection<T> getAnnotations(AnnotatedElement ae, Class<T> annotationType) {
/* 142 */     Collection anns = new ArrayList(2);
/*     */ 
/* 145 */     Annotation ann = ae.getAnnotation(annotationType);
/* 146 */     if (ann != null) {
/* 147 */       anns.add(ann);
/*     */     }
/*     */ 
/* 151 */     for (Annotation metaAnn : ae.getAnnotations()) {
/* 152 */       ann = metaAnn.annotationType().getAnnotation(annotationType);
/* 153 */       if (ann != null) {
/* 154 */         anns.add(ann);
/*     */       }
/*     */     }
/*     */ 
/* 158 */     return anns.isEmpty() ? null : anns;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object other)
/*     */   {
/* 163 */     return (this == other) || ((other instanceof SpringCacheAnnotationParser));
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 168 */     return SpringCacheAnnotationParser.class.hashCode();
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.cache.annotation.SpringCacheAnnotationParser
 * JD-Core Version:    0.6.0
 */