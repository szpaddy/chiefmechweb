/*    */ package org.springframework.cache.annotation;
/*    */ 
/*    */ import org.springframework.context.annotation.AdviceMode;
/*    */ import org.springframework.context.annotation.AdviceModeImportSelector;
/*    */ import org.springframework.context.annotation.AutoProxyRegistrar;
/*    */ 
/*    */ public class CachingConfigurationSelector extends AdviceModeImportSelector<EnableCaching>
/*    */ {
/*    */   public String[] selectImports(AdviceMode adviceMode)
/*    */   {
/* 43 */     switch (1.$SwitchMap$org$springframework$context$annotation$AdviceMode[adviceMode.ordinal()]) {
/*    */     case 1:
/* 45 */       return new String[] { AutoProxyRegistrar.class.getName(), ProxyCachingConfiguration.class.getName() };
/*    */     case 2:
/* 47 */       return new String[] { "org.springframework.cache.aspectj.AspectJCachingConfiguration" };
/*    */     }
/* 49 */     return null;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.cache.annotation.CachingConfigurationSelector
 * JD-Core Version:    0.6.0
 */