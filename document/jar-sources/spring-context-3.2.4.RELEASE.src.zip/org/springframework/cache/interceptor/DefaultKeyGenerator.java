/*    */ package org.springframework.cache.interceptor;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ 
/*    */ public class DefaultKeyGenerator
/*    */   implements KeyGenerator
/*    */ {
/*    */   public static final int NO_PARAM_KEY = 0;
/*    */   public static final int NULL_PARAM_KEY = 53;
/*    */ 
/*    */   public Object generate(Object target, Method method, Object[] params)
/*    */   {
/* 40 */     if (params.length == 1) {
/* 41 */       return params[0] == null ? Integer.valueOf(53) : params[0];
/*    */     }
/* 43 */     if (params.length == 0) {
/* 44 */       return Integer.valueOf(0);
/*    */     }
/* 46 */     int hashCode = 17;
/* 47 */     for (Object object : params) {
/* 48 */       hashCode = 31 * hashCode + (object == null ? 53 : object.hashCode());
/*    */     }
/* 50 */     return Integer.valueOf(hashCode);
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.cache.interceptor.DefaultKeyGenerator
 * JD-Core Version:    0.6.0
 */