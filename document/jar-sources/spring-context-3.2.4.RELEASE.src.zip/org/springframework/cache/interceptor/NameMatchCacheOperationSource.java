/*     */ package org.springframework.cache.interceptor;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Collection;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.PatternMatchUtils;
/*     */ 
/*     */ public class NameMatchCacheOperationSource
/*     */   implements CacheOperationSource, Serializable
/*     */ {
/*  43 */   protected static final Log logger = LogFactory.getLog(NameMatchCacheOperationSource.class);
/*     */ 
/*  46 */   private Map<String, Collection<CacheOperation>> nameMap = new LinkedHashMap();
/*     */ 
/*     */   public void setNameMap(Map<String, Collection<CacheOperation>> nameMap)
/*     */   {
/*  55 */     for (Map.Entry entry : nameMap.entrySet())
/*  56 */       addCacheMethod((String)entry.getKey(), (Collection)entry.getValue());
/*     */   }
/*     */ 
/*     */   public void addCacheMethod(String methodName, Collection<CacheOperation> ops)
/*     */   {
/*  68 */     if (logger.isDebugEnabled()) {
/*  69 */       logger.debug("Adding method [" + methodName + "] with cache operations [" + ops + "]");
/*     */     }
/*  71 */     this.nameMap.put(methodName, ops);
/*     */   }
/*     */ 
/*     */   public Collection<CacheOperation> getCacheOperations(Method method, Class<?> targetClass)
/*     */   {
/*  76 */     String methodName = method.getName();
/*  77 */     Collection ops = (Collection)this.nameMap.get(methodName);
/*     */     String bestNameMatch;
/*  79 */     if (ops == null)
/*     */     {
/*  81 */       bestNameMatch = null;
/*  82 */       for (String mappedName : this.nameMap.keySet()) {
/*  83 */         if ((isMatch(methodName, mappedName)) && ((bestNameMatch == null) || (bestNameMatch.length() <= mappedName.length())))
/*     */         {
/*  85 */           ops = (Collection)this.nameMap.get(mappedName);
/*  86 */           bestNameMatch = mappedName;
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*  91 */     return ops;
/*     */   }
/*     */ 
/*     */   protected boolean isMatch(String methodName, String mappedName)
/*     */   {
/* 104 */     return PatternMatchUtils.simpleMatch(mappedName, methodName);
/*     */   }
/*     */ 
/*     */   public boolean equals(Object other)
/*     */   {
/* 109 */     if (this == other) {
/* 110 */       return true;
/*     */     }
/* 112 */     if (!(other instanceof NameMatchCacheOperationSource)) {
/* 113 */       return false;
/*     */     }
/* 115 */     NameMatchCacheOperationSource otherTas = (NameMatchCacheOperationSource)other;
/* 116 */     return ObjectUtils.nullSafeEquals(this.nameMap, otherTas.nameMap);
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 121 */     return NameMatchCacheOperationSource.class.hashCode();
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 126 */     return getClass().getName() + ": " + this.nameMap;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.cache.interceptor.NameMatchCacheOperationSource
 * JD-Core Version:    0.6.0
 */