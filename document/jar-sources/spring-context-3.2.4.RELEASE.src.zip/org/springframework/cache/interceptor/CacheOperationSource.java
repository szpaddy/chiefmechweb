package org.springframework.cache.interceptor;

import java.lang.reflect.Method;
import java.util.Collection;

public abstract interface CacheOperationSource
{
  public abstract Collection<CacheOperation> getCacheOperations(Method paramMethod, Class<?> paramClass);
}

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.cache.interceptor.CacheOperationSource
 * JD-Core Version:    0.6.0
 */