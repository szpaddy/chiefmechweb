/*    */ package org.springframework.cache.interceptor;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.lang.reflect.Method;
/*    */ import org.aopalliance.intercept.MethodInterceptor;
/*    */ import org.aopalliance.intercept.MethodInvocation;
/*    */ 
/*    */ public class CacheInterceptor extends CacheAspectSupport
/*    */   implements MethodInterceptor, Serializable
/*    */ {
/*    */   public Object invoke(MethodInvocation invocation)
/*    */     throws Throwable
/*    */   {
/* 53 */     Method method = invocation.getMethod();
/*    */ 
/* 55 */     CacheAspectSupport.Invoker aopAllianceInvoker = new CacheAspectSupport.Invoker(invocation) {
/*    */       public Object invoke() {
/*    */         try {
/* 58 */           return this.val$invocation.proceed(); } catch (Throwable ex) {
/*    */         }
/* 60 */         throw new CacheInterceptor.ThrowableWrapper(ex);
/*    */       }
/*    */     };
/*    */     try
/*    */     {
/* 66 */       return execute(aopAllianceInvoker, invocation.getThis(), method, invocation.getArguments()); } catch (ThrowableWrapper th) {
/*    */     }
/* 68 */     throw th.original;
/*    */   }
/*    */ 
/*    */   private static class ThrowableWrapper extends RuntimeException
/*    */   {
/*    */     private final Throwable original;
/*    */ 
/*    */     ThrowableWrapper(Throwable original)
/*    */     {
/* 48 */       this.original = original;
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.cache.interceptor.CacheInterceptor
 * JD-Core Version:    0.6.0
 */