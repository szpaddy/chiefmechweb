/*     */ package org.springframework.cache.interceptor;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.BridgeMethodResolver;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ public abstract class AbstractFallbackCacheOperationSource
/*     */   implements CacheOperationSource
/*     */ {
/*  61 */   private static final Collection<CacheOperation> NULL_CACHING_ATTRIBUTE = Collections.emptyList();
/*     */   protected final Log logger;
/*     */   final Map<Object, Collection<CacheOperation>> attributeCache;
/*     */ 
/*     */   public AbstractFallbackCacheOperationSource()
/*     */   {
/*  68 */     this.logger = LogFactory.getLog(getClass());
/*     */ 
/*  75 */     this.attributeCache = new ConcurrentHashMap(1024);
/*     */   }
/*     */ 
/*     */   public Collection<CacheOperation> getCacheOperations(Method method, Class<?> targetClass)
/*     */   {
/*  89 */     Object cacheKey = getCacheKey(method, targetClass);
/*  90 */     Collection cached = (Collection)this.attributeCache.get(cacheKey);
/*  91 */     if (cached != null) {
/*  92 */       if (cached == NULL_CACHING_ATTRIBUTE) {
/*  93 */         return null;
/*     */       }
/*     */ 
/*  97 */       return cached;
/*     */     }
/*     */ 
/* 101 */     Collection cacheOps = computeCacheOperations(method, targetClass);
/*     */ 
/* 103 */     if (cacheOps == null) {
/* 104 */       this.attributeCache.put(cacheKey, NULL_CACHING_ATTRIBUTE);
/*     */     }
/*     */     else {
/* 107 */       if (this.logger.isDebugEnabled()) {
/* 108 */         this.logger.debug("Adding cacheable method '" + method.getName() + "' with attribute: " + cacheOps);
/*     */       }
/* 110 */       this.attributeCache.put(cacheKey, cacheOps);
/*     */     }
/* 112 */     return cacheOps;
/*     */   }
/*     */ 
/*     */   protected Object getCacheKey(Method method, Class<?> targetClass)
/*     */   {
/* 125 */     return new DefaultCacheKey(method, targetClass);
/*     */   }
/*     */ 
/*     */   private Collection<CacheOperation> computeCacheOperations(Method method, Class<?> targetClass)
/*     */   {
/* 130 */     if ((allowPublicMethodsOnly()) && (!Modifier.isPublic(method.getModifiers()))) {
/* 131 */       return null;
/*     */     }
/*     */ 
/* 136 */     Method specificMethod = ClassUtils.getMostSpecificMethod(method, targetClass);
/*     */ 
/* 138 */     specificMethod = BridgeMethodResolver.findBridgedMethod(specificMethod);
/*     */ 
/* 141 */     Collection opDef = findCacheOperations(specificMethod);
/* 142 */     if (opDef != null) {
/* 143 */       return opDef;
/*     */     }
/*     */ 
/* 147 */     opDef = findCacheOperations(specificMethod.getDeclaringClass());
/* 148 */     if (opDef != null) {
/* 149 */       return opDef;
/*     */     }
/*     */ 
/* 152 */     if (specificMethod != method)
/*     */     {
/* 154 */       opDef = findCacheOperations(method);
/* 155 */       if (opDef != null) {
/* 156 */         return opDef;
/*     */       }
/*     */ 
/* 159 */       return findCacheOperations(method.getDeclaringClass());
/*     */     }
/* 161 */     return null;
/*     */   }
/*     */ 
/*     */   protected abstract Collection<CacheOperation> findCacheOperations(Method paramMethod);
/*     */ 
/*     */   protected abstract Collection<CacheOperation> findCacheOperations(Class<?> paramClass);
/*     */ 
/*     */   protected boolean allowPublicMethodsOnly()
/*     */   {
/* 188 */     return false;
/*     */   }
/*     */ 
/*     */   private static class DefaultCacheKey
/*     */   {
/*     */     private final Method method;
/*     */     private final Class<?> targetClass;
/*     */ 
/*     */     public DefaultCacheKey(Method method, Class<?> targetClass)
/*     */     {
/* 202 */       this.method = method;
/* 203 */       this.targetClass = targetClass;
/*     */     }
/*     */ 
/*     */     public boolean equals(Object other)
/*     */     {
/* 208 */       if (this == other) {
/* 209 */         return true;
/*     */       }
/* 211 */       if (!(other instanceof DefaultCacheKey)) {
/* 212 */         return false;
/*     */       }
/* 214 */       DefaultCacheKey otherKey = (DefaultCacheKey)other;
/* 215 */       return (this.method.equals(otherKey.method)) && (ObjectUtils.nullSafeEquals(this.targetClass, otherKey.targetClass));
/*     */     }
/*     */ 
/*     */     public int hashCode()
/*     */     {
/* 221 */       return this.method.hashCode() * 29 + (this.targetClass != null ? this.targetClass.hashCode() : 0);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.cache.interceptor.AbstractFallbackCacheOperationSource
 * JD-Core Version:    0.6.0
 */