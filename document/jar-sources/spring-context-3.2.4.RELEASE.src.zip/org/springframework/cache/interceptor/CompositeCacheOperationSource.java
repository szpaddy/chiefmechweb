/*    */ package org.springframework.cache.interceptor;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.lang.reflect.Method;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ public class CompositeCacheOperationSource
/*    */   implements CacheOperationSource, Serializable
/*    */ {
/*    */   private final CacheOperationSource[] cacheOperationSources;
/*    */ 
/*    */   public CompositeCacheOperationSource(CacheOperationSource[] cacheOperationSources)
/*    */   {
/* 43 */     Assert.notEmpty(cacheOperationSources, "cacheOperationSources array must not be empty");
/* 44 */     this.cacheOperationSources = cacheOperationSources;
/*    */   }
/*    */ 
/*    */   public final CacheOperationSource[] getCacheOperationSources()
/*    */   {
/* 52 */     return this.cacheOperationSources;
/*    */   }
/*    */ 
/*    */   public Collection<CacheOperation> getCacheOperations(Method method, Class<?> targetClass) {
/* 56 */     Collection ops = null;
/*    */ 
/* 58 */     for (CacheOperationSource source : this.cacheOperationSources) {
/* 59 */       Collection cacheOperations = source.getCacheOperations(method, targetClass);
/* 60 */       if (cacheOperations != null) {
/* 61 */         if (ops == null) {
/* 62 */           ops = new ArrayList();
/*    */         }
/*    */ 
/* 65 */         ops.addAll(cacheOperations);
/*    */       }
/*    */     }
/* 68 */     return ops;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.cache.interceptor.CompositeCacheOperationSource
 * JD-Core Version:    0.6.0
 */