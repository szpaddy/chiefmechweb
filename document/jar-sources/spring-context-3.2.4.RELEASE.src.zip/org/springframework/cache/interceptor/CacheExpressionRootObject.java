/*    */ package org.springframework.cache.interceptor;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import java.util.Collection;
/*    */ import org.springframework.cache.Cache;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ class CacheExpressionRootObject
/*    */ {
/*    */   private final Collection<Cache> caches;
/*    */   private final Method method;
/*    */   private final Object[] args;
/*    */   private final Object target;
/*    */   private final Class<?> targetClass;
/*    */ 
/*    */   public CacheExpressionRootObject(Collection<Cache> caches, Method method, Object[] args, Object target, Class<?> targetClass)
/*    */   {
/* 47 */     Assert.notNull(method, "Method is required");
/* 48 */     Assert.notNull(targetClass, "targetClass is required");
/* 49 */     this.method = method;
/* 50 */     this.target = target;
/* 51 */     this.targetClass = targetClass;
/* 52 */     this.args = args;
/* 53 */     this.caches = caches;
/*    */   }
/*    */ 
/*    */   public Collection<Cache> getCaches()
/*    */   {
/* 58 */     return this.caches;
/*    */   }
/*    */ 
/*    */   public Method getMethod() {
/* 62 */     return this.method;
/*    */   }
/*    */ 
/*    */   public String getMethodName() {
/* 66 */     return this.method.getName();
/*    */   }
/*    */ 
/*    */   public Object[] getArgs() {
/* 70 */     return this.args;
/*    */   }
/*    */ 
/*    */   public Object getTarget() {
/* 74 */     return this.target;
/*    */   }
/*    */ 
/*    */   public Class<?> getTargetClass() {
/* 78 */     return this.targetClass;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.cache.interceptor.CacheExpressionRootObject
 * JD-Core Version:    0.6.0
 */