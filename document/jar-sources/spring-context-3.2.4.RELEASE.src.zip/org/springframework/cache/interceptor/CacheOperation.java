/*     */ package org.springframework.cache.interceptor;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public abstract class CacheOperation
/*     */ {
/*  32 */   private Set<String> cacheNames = Collections.emptySet();
/*  33 */   private String condition = "";
/*  34 */   private String key = "";
/*  35 */   private String name = "";
/*     */ 
/*     */   public Set<String> getCacheNames()
/*     */   {
/*  39 */     return this.cacheNames;
/*     */   }
/*     */ 
/*     */   public String getCondition() {
/*  43 */     return this.condition;
/*     */   }
/*     */ 
/*     */   public String getKey() {
/*  47 */     return this.key;
/*     */   }
/*     */ 
/*     */   public String getName() {
/*  51 */     return this.name;
/*     */   }
/*     */ 
/*     */   public void setCacheName(String cacheName) {
/*  55 */     Assert.hasText(cacheName);
/*  56 */     this.cacheNames = Collections.singleton(cacheName);
/*     */   }
/*     */ 
/*     */   public void setCacheNames(String[] cacheNames) {
/*  60 */     Assert.notEmpty(cacheNames);
/*  61 */     this.cacheNames = new LinkedHashSet(cacheNames.length);
/*  62 */     for (String string : cacheNames)
/*  63 */       this.cacheNames.add(string);
/*     */   }
/*     */ 
/*     */   public void setCondition(String condition)
/*     */   {
/*  68 */     Assert.notNull(condition);
/*  69 */     this.condition = condition;
/*     */   }
/*     */ 
/*     */   public void setKey(String key) {
/*  73 */     Assert.notNull(key);
/*  74 */     this.key = key;
/*     */   }
/*     */ 
/*     */   public void setName(String name) {
/*  78 */     Assert.hasText(name);
/*  79 */     this.name = name;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object other)
/*     */   {
/*  88 */     return ((other instanceof CacheOperation)) && (toString().equals(other.toString()));
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/*  97 */     return toString().hashCode();
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 108 */     return getOperationDescription().toString();
/*     */   }
/*     */ 
/*     */   protected StringBuilder getOperationDescription()
/*     */   {
/* 116 */     StringBuilder result = new StringBuilder();
/* 117 */     result.append(getClass().getSimpleName());
/* 118 */     result.append("[");
/* 119 */     result.append(this.name);
/* 120 */     result.append("] caches=");
/* 121 */     result.append(this.cacheNames);
/* 122 */     result.append(" | key='");
/* 123 */     result.append(this.key);
/* 124 */     result.append("' | condition='");
/* 125 */     result.append(this.condition);
/* 126 */     result.append("'");
/* 127 */     return result;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.cache.interceptor.CacheOperation
 * JD-Core Version:    0.6.0
 */