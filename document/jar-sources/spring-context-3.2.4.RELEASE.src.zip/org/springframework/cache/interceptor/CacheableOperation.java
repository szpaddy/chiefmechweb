/*    */ package org.springframework.cache.interceptor;
/*    */ 
/*    */ public class CacheableOperation extends CacheOperation
/*    */ {
/*    */   private String unless;
/*    */ 
/*    */   public String getUnless()
/*    */   {
/* 32 */     return this.unless;
/*    */   }
/*    */ 
/*    */   public void setUnless(String unless) {
/* 36 */     this.unless = unless;
/*    */   }
/*    */ 
/*    */   protected StringBuilder getOperationDescription()
/*    */   {
/* 41 */     StringBuilder sb = super.getOperationDescription();
/* 42 */     sb.append(" | unless='");
/* 43 */     sb.append(this.unless);
/* 44 */     sb.append("'");
/* 45 */     return sb;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.cache.interceptor.CacheableOperation
 * JD-Core Version:    0.6.0
 */