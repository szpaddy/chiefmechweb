/*    */ package org.springframework.cache.interceptor;
/*    */ 
/*    */ public class CacheEvictOperation extends CacheOperation
/*    */ {
/* 27 */   private boolean cacheWide = false;
/* 28 */   private boolean beforeInvocation = false;
/*    */ 
/*    */   public void setCacheWide(boolean cacheWide)
/*    */   {
/* 32 */     this.cacheWide = cacheWide;
/*    */   }
/*    */ 
/*    */   public boolean isCacheWide() {
/* 36 */     return this.cacheWide;
/*    */   }
/*    */ 
/*    */   public void setBeforeInvocation(boolean beforeInvocation) {
/* 40 */     this.beforeInvocation = beforeInvocation;
/*    */   }
/*    */ 
/*    */   public boolean isBeforeInvocation() {
/* 44 */     return this.beforeInvocation;
/*    */   }
/*    */ 
/*    */   protected StringBuilder getOperationDescription()
/*    */   {
/* 49 */     StringBuilder sb = super.getOperationDescription();
/* 50 */     sb.append(",");
/* 51 */     sb.append(this.cacheWide);
/* 52 */     sb.append(",");
/* 53 */     sb.append(this.beforeInvocation);
/* 54 */     return sb;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.cache.interceptor.CacheEvictOperation
 * JD-Core Version:    0.6.0
 */