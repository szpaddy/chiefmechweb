package org.springframework.cache.interceptor;

import java.lang.reflect.Method;

public abstract interface KeyGenerator
{
  public abstract Object generate(Object paramObject, Method paramMethod, Object[] paramArrayOfObject);
}

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.cache.interceptor.KeyGenerator
 * JD-Core Version:    0.6.0
 */