/*    */ package org.springframework.cache.config;
/*    */ 
/*    */ import org.springframework.beans.MutablePropertyValues;
/*    */ import org.springframework.beans.factory.config.BeanDefinition;
/*    */ import org.springframework.beans.factory.config.RuntimeBeanReference;
/*    */ import org.springframework.beans.factory.xml.NamespaceHandlerSupport;
/*    */ import org.springframework.util.StringUtils;
/*    */ import org.w3c.dom.Element;
/*    */ 
/*    */ public class CacheNamespaceHandler extends NamespaceHandlerSupport
/*    */ {
/*    */   static final String CACHE_MANAGER_ATTRIBUTE = "cache-manager";
/*    */   static final String DEFAULT_CACHE_MANAGER_BEAN_NAME = "cacheManager";
/*    */ 
/*    */   static String extractCacheManager(Element element)
/*    */   {
/* 41 */     return element.hasAttribute("cache-manager") ? element.getAttribute("cache-manager") : "cacheManager";
/*    */   }
/*    */ 
/*    */   static BeanDefinition parseKeyGenerator(Element element, BeanDefinition def)
/*    */   {
/* 47 */     String name = element.getAttribute("key-generator");
/* 48 */     if (StringUtils.hasText(name)) {
/* 49 */       def.getPropertyValues().add("keyGenerator", new RuntimeBeanReference(name.trim()));
/*    */     }
/* 51 */     return def;
/*    */   }
/*    */ 
/*    */   public void init() {
/* 55 */     registerBeanDefinitionParser("annotation-driven", new AnnotationDrivenCacheBeanDefinitionParser());
/* 56 */     registerBeanDefinitionParser("advice", new CacheAdviceParser());
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.cache.config.CacheNamespaceHandler
 * JD-Core Version:    0.6.0
 */