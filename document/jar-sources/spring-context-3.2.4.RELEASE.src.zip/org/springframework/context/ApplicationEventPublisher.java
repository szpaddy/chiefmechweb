package org.springframework.context;

public abstract interface ApplicationEventPublisher
{
  public abstract void publishEvent(ApplicationEvent paramApplicationEvent);
}

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.context.ApplicationEventPublisher
 * JD-Core Version:    0.6.0
 */