package org.springframework.context;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.Aware;

public abstract interface ApplicationContextAware extends Aware
{
  public abstract void setApplicationContext(ApplicationContext paramApplicationContext)
    throws BeansException;
}

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.context.ApplicationContextAware
 * JD-Core Version:    0.6.0
 */