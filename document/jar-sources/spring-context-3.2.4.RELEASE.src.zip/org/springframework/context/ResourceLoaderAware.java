package org.springframework.context;

import org.springframework.beans.factory.Aware;
import org.springframework.core.io.ResourceLoader;

public abstract interface ResourceLoaderAware extends Aware
{
  public abstract void setResourceLoader(ResourceLoader paramResourceLoader);
}

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.context.ResourceLoaderAware
 * JD-Core Version:    0.6.0
 */