/*     */ package org.springframework.context.event;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.LinkedList;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.context.ApplicationEvent;
/*     */ import org.springframework.context.ApplicationListener;
/*     */ import org.springframework.core.OrderComparator;
/*     */ 
/*     */ public abstract class AbstractApplicationEventMulticaster
/*     */   implements ApplicationEventMulticaster, BeanFactoryAware
/*     */ {
/*     */   private final ListenerRetriever defaultRetriever;
/*     */   private final Map<ListenerCacheKey, ListenerRetriever> retrieverCache;
/*     */   private BeanFactory beanFactory;
/*     */ 
/*     */   public AbstractApplicationEventMulticaster()
/*     */   {
/*  53 */     this.defaultRetriever = new ListenerRetriever(false);
/*     */ 
/*  55 */     this.retrieverCache = new ConcurrentHashMap(64);
/*     */   }
/*     */ 
/*     */   public void addApplicationListener(ApplicationListener listener)
/*     */   {
/*  62 */     synchronized (this.defaultRetriever) {
/*  63 */       this.defaultRetriever.applicationListeners.add(listener);
/*  64 */       this.retrieverCache.clear();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void addApplicationListenerBean(String listenerBeanName) {
/*  69 */     synchronized (this.defaultRetriever) {
/*  70 */       this.defaultRetriever.applicationListenerBeans.add(listenerBeanName);
/*  71 */       this.retrieverCache.clear();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void removeApplicationListener(ApplicationListener listener) {
/*  76 */     synchronized (this.defaultRetriever) {
/*  77 */       this.defaultRetriever.applicationListeners.remove(listener);
/*  78 */       this.retrieverCache.clear();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void removeApplicationListenerBean(String listenerBeanName) {
/*  83 */     synchronized (this.defaultRetriever) {
/*  84 */       this.defaultRetriever.applicationListenerBeans.remove(listenerBeanName);
/*  85 */       this.retrieverCache.clear();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void removeAllListeners() {
/*  90 */     synchronized (this.defaultRetriever) {
/*  91 */       this.defaultRetriever.applicationListeners.clear();
/*  92 */       this.defaultRetriever.applicationListenerBeans.clear();
/*  93 */       this.retrieverCache.clear();
/*     */     }
/*     */   }
/*     */ 
/*     */   public final void setBeanFactory(BeanFactory beanFactory) {
/*  98 */     this.beanFactory = beanFactory;
/*     */   }
/*     */ 
/*     */   private BeanFactory getBeanFactory() {
/* 102 */     if (this.beanFactory == null) {
/* 103 */       throw new IllegalStateException("ApplicationEventMulticaster cannot retrieve listener beans because it is not associated with a BeanFactory");
/*     */     }
/*     */ 
/* 106 */     return this.beanFactory;
/*     */   }
/*     */ 
/*     */   protected Collection<ApplicationListener> getApplicationListeners()
/*     */   {
/* 116 */     synchronized (this.defaultRetriever) {
/* 117 */       return this.defaultRetriever.getApplicationListeners();
/*     */     }
/*     */   }
/*     */ 
/*     */   protected Collection<ApplicationListener> getApplicationListeners(ApplicationEvent event)
/*     */   {
/* 130 */     Class eventType = event.getClass();
/* 131 */     Class sourceType = event.getSource().getClass();
/* 132 */     ListenerCacheKey cacheKey = new ListenerCacheKey(eventType, sourceType);
/* 133 */     ListenerRetriever retriever = (ListenerRetriever)this.retrieverCache.get(cacheKey);
/* 134 */     if (retriever != null) {
/* 135 */       return retriever.getApplicationListeners();
/*     */     }
/*     */ 
/* 138 */     retriever = new ListenerRetriever(true);
/* 139 */     LinkedList allListeners = new LinkedList();
/*     */     Set listeners;
/*     */     Set listenerBeans;
/* 142 */     synchronized (this.defaultRetriever) {
/* 143 */       listeners = new LinkedHashSet(this.defaultRetriever.applicationListeners);
/* 144 */       listenerBeans = new LinkedHashSet(this.defaultRetriever.applicationListenerBeans);
/*     */     }
/* 146 */     for (ApplicationListener listener : listeners)
/* 147 */       if (supportsEvent(listener, eventType, sourceType)) {
/* 148 */         retriever.applicationListeners.add(listener);
/* 149 */         allListeners.add(listener);
/*     */       }
/*     */     BeanFactory beanFactory;
/* 152 */     if (!listenerBeans.isEmpty()) {
/* 153 */       beanFactory = getBeanFactory();
/* 154 */       for (String listenerBeanName : listenerBeans) {
/* 155 */         ApplicationListener listener = (ApplicationListener)beanFactory.getBean(listenerBeanName, ApplicationListener.class);
/* 156 */         if ((!allListeners.contains(listener)) && (supportsEvent(listener, eventType, sourceType))) {
/* 157 */           retriever.applicationListenerBeans.add(listenerBeanName);
/* 158 */           allListeners.add(listener);
/*     */         }
/*     */       }
/*     */     }
/* 162 */     OrderComparator.sort(allListeners);
/* 163 */     this.retrieverCache.put(cacheKey, retriever);
/* 164 */     return allListeners;
/*     */   }
/*     */ 
/*     */   protected boolean supportsEvent(ApplicationListener listener, Class<? extends ApplicationEvent> eventType, Class sourceType)
/*     */   {
/* 183 */     SmartApplicationListener smartListener = (listener instanceof SmartApplicationListener) ? (SmartApplicationListener)listener : new GenericApplicationListenerAdapter(listener);
/*     */ 
/* 185 */     return (smartListener.supportsEventType(eventType)) && (smartListener.supportsSourceType(sourceType));
/*     */   }
/*     */ 
/*     */   private class ListenerRetriever
/*     */   {
/*     */     public final Set<ApplicationListener> applicationListeners;
/*     */     public final Set<String> applicationListenerBeans;
/*     */     private final boolean preFiltered;
/*     */ 
/*     */     public ListenerRetriever(boolean preFiltered)
/*     */     {
/* 233 */       this.applicationListeners = new LinkedHashSet();
/* 234 */       this.applicationListenerBeans = new LinkedHashSet();
/* 235 */       this.preFiltered = preFiltered;
/*     */     }
/*     */ 
/*     */     public Collection<ApplicationListener> getApplicationListeners() {
/* 239 */       LinkedList allListeners = new LinkedList();
/* 240 */       for (ApplicationListener listener : this.applicationListeners)
/* 241 */         allListeners.add(listener);
/*     */       BeanFactory beanFactory;
/* 243 */       if (!this.applicationListenerBeans.isEmpty()) {
/* 244 */         beanFactory = AbstractApplicationEventMulticaster.this.getBeanFactory();
/* 245 */         for (String listenerBeanName : this.applicationListenerBeans) {
/* 246 */           ApplicationListener listener = (ApplicationListener)beanFactory.getBean(listenerBeanName, ApplicationListener.class);
/* 247 */           if ((this.preFiltered) || (!allListeners.contains(listener))) {
/* 248 */             allListeners.add(listener);
/*     */           }
/*     */         }
/*     */       }
/* 252 */       OrderComparator.sort(allListeners);
/* 253 */       return allListeners;
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class ListenerCacheKey
/*     */   {
/*     */     private final Class eventType;
/*     */     private final Class sourceType;
/*     */ 
/*     */     public ListenerCacheKey(Class eventType, Class sourceType)
/*     */     {
/* 199 */       this.eventType = eventType;
/* 200 */       this.sourceType = sourceType;
/*     */     }
/*     */ 
/*     */     public boolean equals(Object other)
/*     */     {
/* 205 */       if (this == other) {
/* 206 */         return true;
/*     */       }
/* 208 */       ListenerCacheKey otherKey = (ListenerCacheKey)other;
/* 209 */       return (this.eventType.equals(otherKey.eventType)) && (this.sourceType.equals(otherKey.sourceType));
/*     */     }
/*     */ 
/*     */     public int hashCode()
/*     */     {
/* 214 */       return this.eventType.hashCode() * 29 + this.sourceType.hashCode();
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.context.event.AbstractApplicationEventMulticaster
 * JD-Core Version:    0.6.0
 */