/*    */ package org.springframework.context.event;
/*    */ 
/*    */ import org.springframework.context.ApplicationContext;
/*    */ 
/*    */ public class ContextStoppedEvent extends ApplicationContextEvent
/*    */ {
/*    */   public ContextStoppedEvent(ApplicationContext source)
/*    */   {
/* 38 */     super(source);
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.context.event.ContextStoppedEvent
 * JD-Core Version:    0.6.0
 */