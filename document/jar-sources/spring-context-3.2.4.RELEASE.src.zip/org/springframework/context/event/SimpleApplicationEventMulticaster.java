/*    */ package org.springframework.context.event;
/*    */ 
/*    */ import java.util.concurrent.Executor;
/*    */ import org.springframework.beans.factory.BeanFactory;
/*    */ import org.springframework.context.ApplicationEvent;
/*    */ import org.springframework.context.ApplicationListener;
/*    */ 
/*    */ public class SimpleApplicationEventMulticaster extends AbstractApplicationEventMulticaster
/*    */ {
/*    */   private Executor taskExecutor;
/*    */ 
/*    */   public SimpleApplicationEventMulticaster()
/*    */   {
/*    */   }
/*    */ 
/*    */   public SimpleApplicationEventMulticaster(BeanFactory beanFactory)
/*    */   {
/* 57 */     setBeanFactory(beanFactory);
/*    */   }
/*    */ 
/*    */   public void setTaskExecutor(Executor taskExecutor)
/*    */   {
/* 73 */     this.taskExecutor = taskExecutor;
/*    */   }
/*    */ 
/*    */   protected Executor getTaskExecutor()
/*    */   {
/* 80 */     return this.taskExecutor;
/*    */   }
/*    */ 
/*    */   public void multicastEvent(ApplicationEvent event)
/*    */   {
/* 86 */     for (ApplicationListener listener : getApplicationListeners(event)) {
/* 87 */       Executor executor = getTaskExecutor();
/* 88 */       if (executor != null)
/* 89 */         executor.execute(new Runnable(listener, event) {
/*    */           public void run() {
/* 91 */             this.val$listener.onApplicationEvent(this.val$event);
/*    */           }
/*    */         });
/*    */       else
/* 96 */         listener.onApplicationEvent(event);
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.context.event.SimpleApplicationEventMulticaster
 * JD-Core Version:    0.6.0
 */