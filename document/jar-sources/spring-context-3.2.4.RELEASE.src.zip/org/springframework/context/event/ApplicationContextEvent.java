/*    */ package org.springframework.context.event;
/*    */ 
/*    */ import org.springframework.context.ApplicationContext;
/*    */ import org.springframework.context.ApplicationEvent;
/*    */ 
/*    */ public abstract class ApplicationContextEvent extends ApplicationEvent
/*    */ {
/*    */   public ApplicationContextEvent(ApplicationContext source)
/*    */   {
/* 37 */     super(source);
/*    */   }
/*    */ 
/*    */   public final ApplicationContext getApplicationContext()
/*    */   {
/* 44 */     return (ApplicationContext)getSource();
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.context.event.ApplicationContextEvent
 * JD-Core Version:    0.6.0
 */