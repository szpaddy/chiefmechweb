package org.springframework.context.event;

import org.springframework.context.ApplicationEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.core.Ordered;

public abstract interface SmartApplicationListener extends ApplicationListener<ApplicationEvent>, Ordered
{
  public abstract boolean supportsEventType(Class<? extends ApplicationEvent> paramClass);

  public abstract boolean supportsSourceType(Class<?> paramClass);
}

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.context.event.SmartApplicationListener
 * JD-Core Version:    0.6.0
 */