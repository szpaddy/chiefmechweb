/*    */ package org.springframework.context;
/*    */ 
/*    */ import java.util.Locale;
/*    */ 
/*    */ public class NoSuchMessageException extends RuntimeException
/*    */ {
/*    */   public NoSuchMessageException(String code, Locale locale)
/*    */   {
/* 35 */     super("No message found under code '" + code + "' for locale '" + locale + "'.");
/*    */   }
/*    */ 
/*    */   public NoSuchMessageException(String code)
/*    */   {
/* 43 */     super("No message found under code '" + code + "' for locale '" + Locale.getDefault() + "'.");
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.context.NoSuchMessageException
 * JD-Core Version:    0.6.0
 */