package org.springframework.context;

public abstract interface Lifecycle
{
  public abstract void start();

  public abstract void stop();

  public abstract boolean isRunning();
}

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.context.Lifecycle
 * JD-Core Version:    0.6.0
 */