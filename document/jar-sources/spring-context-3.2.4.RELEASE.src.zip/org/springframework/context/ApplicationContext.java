package org.springframework.context;

import org.springframework.beans.factory.HierarchicalBeanFactory;
import org.springframework.beans.factory.ListableBeanFactory;
import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
import org.springframework.core.env.EnvironmentCapable;
import org.springframework.core.io.support.ResourcePatternResolver;

public abstract interface ApplicationContext extends EnvironmentCapable, ListableBeanFactory, HierarchicalBeanFactory, MessageSource, ApplicationEventPublisher, ResourcePatternResolver
{
  public abstract String getId();

  public abstract String getApplicationName();

  public abstract String getDisplayName();

  public abstract long getStartupDate();

  public abstract ApplicationContext getParent();

  public abstract AutowireCapableBeanFactory getAutowireCapableBeanFactory()
    throws IllegalStateException;
}

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.context.ApplicationContext
 * JD-Core Version:    0.6.0
 */