package org.springframework.context.support;

public abstract interface LiveBeansViewMBean
{
  public abstract String getSnapshotAsJson();
}

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.context.support.LiveBeansViewMBean
 * JD-Core Version:    0.6.0
 */