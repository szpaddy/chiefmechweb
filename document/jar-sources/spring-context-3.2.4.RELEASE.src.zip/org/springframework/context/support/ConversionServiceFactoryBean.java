/*    */ package org.springframework.context.support;
/*    */ 
/*    */ import java.util.Set;
/*    */ import org.springframework.beans.factory.FactoryBean;
/*    */ import org.springframework.beans.factory.InitializingBean;
/*    */ import org.springframework.core.convert.ConversionService;
/*    */ import org.springframework.core.convert.support.ConversionServiceFactory;
/*    */ import org.springframework.core.convert.support.DefaultConversionService;
/*    */ import org.springframework.core.convert.support.GenericConversionService;
/*    */ 
/*    */ public class ConversionServiceFactoryBean
/*    */   implements FactoryBean<ConversionService>, InitializingBean
/*    */ {
/*    */   private Set<?> converters;
/*    */   private GenericConversionService conversionService;
/*    */ 
/*    */   public void setConverters(Set<?> converters)
/*    */   {
/* 64 */     this.converters = converters;
/*    */   }
/*    */ 
/*    */   public void afterPropertiesSet() {
/* 68 */     this.conversionService = createConversionService();
/* 69 */     ConversionServiceFactory.registerConverters(this.converters, this.conversionService);
/*    */   }
/*    */ 
/*    */   protected GenericConversionService createConversionService()
/*    */   {
/* 79 */     return new DefaultConversionService();
/*    */   }
/*    */ 
/*    */   public ConversionService getObject()
/*    */   {
/* 86 */     return this.conversionService;
/*    */   }
/*    */ 
/*    */   public Class<? extends ConversionService> getObjectType() {
/* 90 */     return GenericConversionService.class;
/*    */   }
/*    */ 
/*    */   public boolean isSingleton() {
/* 94 */     return true;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.context.support.ConversionServiceFactoryBean
 * JD-Core Version:    0.6.0
 */