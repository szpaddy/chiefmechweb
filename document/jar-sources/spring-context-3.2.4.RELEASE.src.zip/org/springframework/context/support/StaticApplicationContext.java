/*     */ package org.springframework.context.support;
/*     */ 
/*     */ import java.util.Locale;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.MutablePropertyValues;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.beans.factory.support.DefaultListableBeanFactory;
/*     */ import org.springframework.beans.factory.support.GenericBeanDefinition;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ 
/*     */ public class StaticApplicationContext extends GenericApplicationContext
/*     */ {
/*     */   private final StaticMessageSource staticMessageSource;
/*     */ 
/*     */   public StaticApplicationContext()
/*     */     throws BeansException
/*     */   {
/*  52 */     this(null);
/*     */   }
/*     */ 
/*     */   public StaticApplicationContext(ApplicationContext parent)
/*     */     throws BeansException
/*     */   {
/*  63 */     super(parent);
/*     */ 
/*  66 */     this.staticMessageSource = new StaticMessageSource();
/*  67 */     getBeanFactory().registerSingleton("messageSource", this.staticMessageSource);
/*     */   }
/*     */ 
/*     */   public final StaticMessageSource getStaticMessageSource()
/*     */   {
/*  77 */     return this.staticMessageSource;
/*     */   }
/*     */ 
/*     */   public void registerSingleton(String name, Class clazz)
/*     */     throws BeansException
/*     */   {
/*  87 */     GenericBeanDefinition bd = new GenericBeanDefinition();
/*  88 */     bd.setBeanClass(clazz);
/*  89 */     getDefaultListableBeanFactory().registerBeanDefinition(name, bd);
/*     */   }
/*     */ 
/*     */   public void registerSingleton(String name, Class clazz, MutablePropertyValues pvs)
/*     */     throws BeansException
/*     */   {
/*  98 */     GenericBeanDefinition bd = new GenericBeanDefinition();
/*  99 */     bd.setBeanClass(clazz);
/* 100 */     bd.setPropertyValues(pvs);
/* 101 */     getDefaultListableBeanFactory().registerBeanDefinition(name, bd);
/*     */   }
/*     */ 
/*     */   public void registerPrototype(String name, Class clazz)
/*     */     throws BeansException
/*     */   {
/* 110 */     GenericBeanDefinition bd = new GenericBeanDefinition();
/* 111 */     bd.setScope("prototype");
/* 112 */     bd.setBeanClass(clazz);
/* 113 */     getDefaultListableBeanFactory().registerBeanDefinition(name, bd);
/*     */   }
/*     */ 
/*     */   public void registerPrototype(String name, Class clazz, MutablePropertyValues pvs)
/*     */     throws BeansException
/*     */   {
/* 122 */     GenericBeanDefinition bd = new GenericBeanDefinition();
/* 123 */     bd.setScope("prototype");
/* 124 */     bd.setBeanClass(clazz);
/* 125 */     bd.setPropertyValues(pvs);
/* 126 */     getDefaultListableBeanFactory().registerBeanDefinition(name, bd);
/*     */   }
/*     */ 
/*     */   public void addMessage(String code, Locale locale, String defaultMessage)
/*     */   {
/* 137 */     getStaticMessageSource().addMessage(code, locale, defaultMessage);
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.context.support.StaticApplicationContext
 * JD-Core Version:    0.6.0
 */