/*    */ package org.springframework.context.support;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.beans.factory.ObjectFactory;
/*    */ import org.springframework.beans.factory.config.Scope;
/*    */ import org.springframework.core.NamedThreadLocal;
/*    */ 
/*    */ public class SimpleThreadScope
/*    */   implements Scope
/*    */ {
/* 48 */   private static final Log logger = LogFactory.getLog(SimpleThreadScope.class);
/*    */ 
/* 50 */   private final ThreadLocal<Map<String, Object>> threadScope = new NamedThreadLocal("SimpleThreadScope")
/*    */   {
/*    */     protected Map<String, Object> initialValue()
/*    */     {
/* 54 */       return new HashMap();
/*    */     }
/* 50 */   };
/*    */ 
/*    */   public Object get(String name, ObjectFactory objectFactory)
/*    */   {
/* 59 */     Map scope = (Map)this.threadScope.get();
/* 60 */     Object object = scope.get(name);
/* 61 */     if (object == null) {
/* 62 */       object = objectFactory.getObject();
/* 63 */       scope.put(name, object);
/*    */     }
/* 65 */     return object;
/*    */   }
/*    */ 
/*    */   public Object remove(String name) {
/* 69 */     Map scope = (Map)this.threadScope.get();
/* 70 */     return scope.remove(name);
/*    */   }
/*    */ 
/*    */   public void registerDestructionCallback(String name, Runnable callback) {
/* 74 */     logger.warn("SimpleThreadScope does not support descruction callbacks. Consider using a RequestScope in a Web environment.");
/*    */   }
/*    */ 
/*    */   public Object resolveContextualObject(String key)
/*    */   {
/* 79 */     return null;
/*    */   }
/*    */ 
/*    */   public String getConversationId() {
/* 83 */     return Thread.currentThread().getName();
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.context.support.SimpleThreadScope
 * JD-Core Version:    0.6.0
 */