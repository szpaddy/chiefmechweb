/*     */ package org.springframework.context.support;
/*     */ 
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationContextAware;
/*     */ import org.springframework.context.ApplicationContextException;
/*     */ 
/*     */ public abstract class ApplicationObjectSupport
/*     */   implements ApplicationContextAware
/*     */ {
/*  50 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   private ApplicationContext applicationContext;
/*     */   private MessageSourceAccessor messageSourceAccessor;
/*     */ 
/*     */   public final void setApplicationContext(ApplicationContext context)
/*     */     throws BeansException
/*     */   {
/*  60 */     if ((context == null) && (!isContextRequired()))
/*     */     {
/*  62 */       this.applicationContext = null;
/*  63 */       this.messageSourceAccessor = null;
/*     */     }
/*  65 */     else if (this.applicationContext == null)
/*     */     {
/*  67 */       if (!requiredContextClass().isInstance(context)) {
/*  68 */         throw new ApplicationContextException("Invalid application context: needs to be of type [" + requiredContextClass().getName() + "]");
/*     */       }
/*     */ 
/*  71 */       this.applicationContext = context;
/*  72 */       this.messageSourceAccessor = new MessageSourceAccessor(context);
/*  73 */       initApplicationContext(context);
/*     */     }
/*  77 */     else if (this.applicationContext != context) {
/*  78 */       throw new ApplicationContextException("Cannot reinitialize with different application context: current one is [" + this.applicationContext + "], passed-in one is [" + context + "]");
/*     */     }
/*     */   }
/*     */ 
/*     */   protected boolean isContextRequired()
/*     */   {
/*  93 */     return false;
/*     */   }
/*     */ 
/*     */   protected Class requiredContextClass()
/*     */   {
/* 103 */     return ApplicationContext.class;
/*     */   }
/*     */ 
/*     */   protected void initApplicationContext(ApplicationContext context)
/*     */     throws BeansException
/*     */   {
/* 119 */     initApplicationContext();
/*     */   }
/*     */ 
/*     */   protected void initApplicationContext()
/*     */     throws BeansException
/*     */   {
/*     */   }
/*     */ 
/*     */   public final ApplicationContext getApplicationContext()
/*     */     throws IllegalStateException
/*     */   {
/* 139 */     if ((this.applicationContext == null) && (isContextRequired())) {
/* 140 */       throw new IllegalStateException("ApplicationObjectSupport instance [" + this + "] does not run in an ApplicationContext");
/*     */     }
/*     */ 
/* 143 */     return this.applicationContext;
/*     */   }
/*     */ 
/*     */   protected final MessageSourceAccessor getMessageSourceAccessor()
/*     */     throws IllegalStateException
/*     */   {
/* 152 */     if ((this.messageSourceAccessor == null) && (isContextRequired())) {
/* 153 */       throw new IllegalStateException("ApplicationObjectSupport instance [" + this + "] does not run in an ApplicationContext");
/*     */     }
/*     */ 
/* 156 */     return this.messageSourceAccessor;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.context.support.ApplicationObjectSupport
 * JD-Core Version:    0.6.0
 */