/*     */ package org.springframework.context.support;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.context.ResourceLoaderAware;
/*     */ import org.springframework.core.io.DefaultResourceLoader;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.DefaultPropertiesPersister;
/*     */ import org.springframework.util.PropertiesPersister;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class ReloadableResourceBundleMessageSource extends AbstractMessageSource
/*     */   implements ResourceLoaderAware
/*     */ {
/*     */   private static final String PROPERTIES_SUFFIX = ".properties";
/*     */   private static final String XML_SUFFIX = ".xml";
/*     */   private String[] basenames;
/*     */   private String defaultEncoding;
/*     */   private Properties fileEncodings;
/*     */   private boolean fallbackToSystemLocale;
/*     */   private long cacheMillis;
/*     */   private PropertiesPersister propertiesPersister;
/*     */   private ResourceLoader resourceLoader;
/*     */   private final Map<String, Map<Locale, List<String>>> cachedFilenames;
/*     */   private final Map<String, PropertiesHolder> cachedProperties;
/*     */   private final Map<Locale, PropertiesHolder> cachedMergedProperties;
/*     */ 
/*     */   public ReloadableResourceBundleMessageSource()
/*     */   {
/* 103 */     this.basenames = new String[0];
/*     */ 
/* 109 */     this.fallbackToSystemLocale = true;
/*     */ 
/* 111 */     this.cacheMillis = -1L;
/*     */ 
/* 113 */     this.propertiesPersister = new DefaultPropertiesPersister();
/*     */ 
/* 115 */     this.resourceLoader = new DefaultResourceLoader();
/*     */ 
/* 118 */     this.cachedFilenames = new HashMap();
/*     */ 
/* 122 */     this.cachedProperties = new HashMap();
/*     */ 
/* 125 */     this.cachedMergedProperties = new HashMap();
/*     */   }
/*     */ 
/*     */   public void setBasename(String basename)
/*     */   {
/* 142 */     setBasenames(new String[] { basename });
/*     */   }
/*     */ 
/*     */   public void setBasenames(String[] basenames)
/*     */   {
/* 161 */     if (basenames != null) {
/* 162 */       this.basenames = new String[basenames.length];
/* 163 */       for (int i = 0; i < basenames.length; i++) {
/* 164 */         String basename = basenames[i];
/* 165 */         Assert.hasText(basename, "Basename must not be empty");
/* 166 */         this.basenames[i] = basename.trim();
/*     */       }
/*     */     }
/*     */     else {
/* 170 */       this.basenames = new String[0];
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setDefaultEncoding(String defaultEncoding)
/*     */   {
/* 185 */     this.defaultEncoding = defaultEncoding;
/*     */   }
/*     */ 
/*     */   public void setFileEncodings(Properties fileEncodings)
/*     */   {
/* 199 */     this.fileEncodings = fileEncodings;
/*     */   }
/*     */ 
/*     */   public void setFallbackToSystemLocale(boolean fallbackToSystemLocale)
/*     */   {
/* 213 */     this.fallbackToSystemLocale = fallbackToSystemLocale;
/*     */   }
/*     */ 
/*     */   public void setCacheSeconds(int cacheSeconds)
/*     */   {
/* 231 */     this.cacheMillis = (cacheSeconds * 1000);
/*     */   }
/*     */ 
/*     */   public void setPropertiesPersister(PropertiesPersister propertiesPersister)
/*     */   {
/* 240 */     this.propertiesPersister = (propertiesPersister != null ? propertiesPersister : new DefaultPropertiesPersister());
/*     */   }
/*     */ 
/*     */   public void setResourceLoader(ResourceLoader resourceLoader)
/*     */   {
/* 254 */     this.resourceLoader = (resourceLoader != null ? resourceLoader : new DefaultResourceLoader());
/*     */   }
/*     */ 
/*     */   protected String resolveCodeWithoutArguments(String code, Locale locale)
/*     */   {
/* 264 */     if (this.cacheMillis < 0L) {
/* 265 */       PropertiesHolder propHolder = getMergedProperties(locale);
/* 266 */       String result = propHolder.getProperty(code);
/* 267 */       if (result != null)
/* 268 */         return result;
/*     */     }
/*     */     else
/*     */     {
/* 272 */       for (String basename : this.basenames) {
/* 273 */         List filenames = calculateAllFilenames(basename, locale);
/* 274 */         for (String filename : filenames) {
/* 275 */           PropertiesHolder propHolder = getProperties(filename);
/* 276 */           String result = propHolder.getProperty(code);
/* 277 */           if (result != null) {
/* 278 */             return result;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 283 */     return null;
/*     */   }
/*     */ 
/*     */   protected MessageFormat resolveCode(String code, Locale locale)
/*     */   {
/* 292 */     if (this.cacheMillis < 0L) {
/* 293 */       PropertiesHolder propHolder = getMergedProperties(locale);
/* 294 */       MessageFormat result = propHolder.getMessageFormat(code, locale);
/* 295 */       if (result != null)
/* 296 */         return result;
/*     */     }
/*     */     else
/*     */     {
/* 300 */       for (String basename : this.basenames) {
/* 301 */         List filenames = calculateAllFilenames(basename, locale);
/* 302 */         for (String filename : filenames) {
/* 303 */           PropertiesHolder propHolder = getProperties(filename);
/* 304 */           MessageFormat result = propHolder.getMessageFormat(code, locale);
/* 305 */           if (result != null) {
/* 306 */             return result;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 311 */     return null;
/*     */   }
/*     */ 
/*     */   protected PropertiesHolder getMergedProperties(Locale locale)
/*     */   {
/* 324 */     synchronized (this.cachedMergedProperties) {
/* 325 */       PropertiesHolder mergedHolder = (PropertiesHolder)this.cachedMergedProperties.get(locale);
/* 326 */       if (mergedHolder != null) {
/* 327 */         return mergedHolder;
/*     */       }
/* 329 */       Properties mergedProps = new Properties();
/* 330 */       mergedHolder = new PropertiesHolder(mergedProps, -1L);
/* 331 */       for (int i = this.basenames.length - 1; i >= 0; i--) {
/* 332 */         List filenames = calculateAllFilenames(this.basenames[i], locale);
/* 333 */         for (int j = filenames.size() - 1; j >= 0; j--) {
/* 334 */           String filename = (String)filenames.get(j);
/* 335 */           PropertiesHolder propHolder = getProperties(filename);
/* 336 */           if (propHolder.getProperties() != null) {
/* 337 */             mergedProps.putAll(propHolder.getProperties());
/*     */           }
/*     */         }
/*     */       }
/* 341 */       this.cachedMergedProperties.put(locale, mergedHolder);
/* 342 */       return mergedHolder;
/*     */     }
/*     */   }
/*     */ 
/*     */   protected List<String> calculateAllFilenames(String basename, Locale locale)
/*     */   {
/* 357 */     synchronized (this.cachedFilenames) {
/* 358 */       Map localeMap = (Map)this.cachedFilenames.get(basename);
/* 359 */       if (localeMap != null) {
/* 360 */         List filenames = (List)localeMap.get(locale);
/* 361 */         if (filenames != null) {
/* 362 */           return filenames;
/*     */         }
/*     */       }
/* 365 */       List filenames = new ArrayList(7);
/* 366 */       filenames.addAll(calculateFilenamesForLocale(basename, locale));
/* 367 */       if ((this.fallbackToSystemLocale) && (!locale.equals(Locale.getDefault()))) {
/* 368 */         List fallbackFilenames = calculateFilenamesForLocale(basename, Locale.getDefault());
/* 369 */         for (String fallbackFilename : fallbackFilenames) {
/* 370 */           if (!filenames.contains(fallbackFilename))
/*     */           {
/* 372 */             filenames.add(fallbackFilename);
/*     */           }
/*     */         }
/*     */       }
/* 376 */       filenames.add(basename);
/* 377 */       if (localeMap != null) {
/* 378 */         localeMap.put(locale, filenames);
/*     */       }
/*     */       else {
/* 381 */         localeMap = new HashMap();
/* 382 */         localeMap.put(locale, filenames);
/* 383 */         this.cachedFilenames.put(basename, localeMap);
/*     */       }
/* 385 */       return filenames;
/*     */     }
/*     */   }
/*     */ 
/*     */   protected List<String> calculateFilenamesForLocale(String basename, Locale locale)
/*     */   {
/* 400 */     List result = new ArrayList(3);
/* 401 */     String language = locale.getLanguage();
/* 402 */     String country = locale.getCountry();
/* 403 */     String variant = locale.getVariant();
/* 404 */     StringBuilder temp = new StringBuilder(basename);
/*     */ 
/* 406 */     temp.append('_');
/* 407 */     if (language.length() > 0) {
/* 408 */       temp.append(language);
/* 409 */       result.add(0, temp.toString());
/*     */     }
/*     */ 
/* 412 */     temp.append('_');
/* 413 */     if (country.length() > 0) {
/* 414 */       temp.append(country);
/* 415 */       result.add(0, temp.toString());
/*     */     }
/*     */ 
/* 418 */     if ((variant.length() > 0) && ((language.length() > 0) || (country.length() > 0))) {
/* 419 */       temp.append('_').append(variant);
/* 420 */       result.add(0, temp.toString());
/*     */     }
/*     */ 
/* 423 */     return result;
/*     */   }
/*     */ 
/*     */   protected PropertiesHolder getProperties(String filename)
/*     */   {
/* 434 */     synchronized (this.cachedProperties) {
/* 435 */       PropertiesHolder propHolder = (PropertiesHolder)this.cachedProperties.get(filename);
/* 436 */       if ((propHolder != null) && ((propHolder.getRefreshTimestamp() < 0L) || (propHolder.getRefreshTimestamp() > System.currentTimeMillis() - this.cacheMillis)))
/*     */       {
/* 440 */         return propHolder;
/*     */       }
/* 442 */       return refreshProperties(filename, propHolder);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected PropertiesHolder refreshProperties(String filename, PropertiesHolder propHolder)
/*     */   {
/* 454 */     long refreshTimestamp = this.cacheMillis < 0L ? -1L : System.currentTimeMillis();
/*     */ 
/* 456 */     Resource resource = this.resourceLoader.getResource(filename + ".properties");
/* 457 */     if (!resource.exists()) {
/* 458 */       resource = this.resourceLoader.getResource(filename + ".xml");
/*     */     }
/*     */ 
/* 461 */     if (resource.exists()) {
/* 462 */       long fileTimestamp = -1L;
/* 463 */       if (this.cacheMillis >= 0L)
/*     */         try
/*     */         {
/* 466 */           fileTimestamp = resource.lastModified();
/* 467 */           if ((propHolder != null) && (propHolder.getFileTimestamp() == fileTimestamp)) {
/* 468 */             if (this.logger.isDebugEnabled()) {
/* 469 */               this.logger.debug("Re-caching properties for filename [" + filename + "] - file hasn't been modified");
/*     */             }
/* 471 */             propHolder.setRefreshTimestamp(refreshTimestamp);
/* 472 */             return propHolder;
/*     */           }
/*     */         }
/*     */         catch (IOException ex)
/*     */         {
/* 477 */           if (this.logger.isDebugEnabled()) {
/* 478 */             this.logger.debug(resource + " could not be resolved in the file system - assuming that is hasn't changed", ex);
/*     */           }
/*     */ 
/* 481 */           fileTimestamp = -1L;
/*     */         }
/*     */       try
/*     */       {
/* 485 */         Properties props = loadProperties(resource, filename);
/* 486 */         propHolder = new PropertiesHolder(props, fileTimestamp);
/*     */       }
/*     */       catch (IOException ex) {
/* 489 */         if (this.logger.isWarnEnabled()) {
/* 490 */           this.logger.warn("Could not parse properties file [" + resource.getFilename() + "]", ex);
/*     */         }
/*     */ 
/* 493 */         propHolder = new PropertiesHolder();
/*     */       }
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 499 */       if (this.logger.isDebugEnabled()) {
/* 500 */         this.logger.debug("No properties file found for [" + filename + "] - neither plain properties nor XML");
/*     */       }
/*     */ 
/* 503 */       propHolder = new PropertiesHolder();
/*     */     }
/*     */ 
/* 506 */     propHolder.setRefreshTimestamp(refreshTimestamp);
/* 507 */     this.cachedProperties.put(filename, propHolder);
/* 508 */     return propHolder;
/*     */   }
/*     */ 
/*     */   protected Properties loadProperties(Resource resource, String filename)
/*     */     throws IOException
/*     */   {
/* 519 */     InputStream is = resource.getInputStream();
/* 520 */     Properties props = new Properties();
/*     */     try {
/* 522 */       if (resource.getFilename().endsWith(".xml")) {
/* 523 */         if (this.logger.isDebugEnabled()) {
/* 524 */           this.logger.debug("Loading properties [" + resource.getFilename() + "]");
/*     */         }
/* 526 */         this.propertiesPersister.loadFromXml(props, is);
/*     */       }
/*     */       else {
/* 529 */         encoding = null;
/* 530 */         if (this.fileEncodings != null) {
/* 531 */           encoding = this.fileEncodings.getProperty(filename);
/*     */         }
/* 533 */         if (encoding == null) {
/* 534 */           encoding = this.defaultEncoding;
/*     */         }
/* 536 */         if (encoding != null) {
/* 537 */           if (this.logger.isDebugEnabled()) {
/* 538 */             this.logger.debug("Loading properties [" + resource.getFilename() + "] with encoding '" + encoding + "'");
/*     */           }
/* 540 */           this.propertiesPersister.load(props, new InputStreamReader(is, encoding));
/*     */         }
/*     */         else {
/* 543 */           if (this.logger.isDebugEnabled()) {
/* 544 */             this.logger.debug("Loading properties [" + resource.getFilename() + "]");
/*     */           }
/* 546 */           this.propertiesPersister.load(props, is);
/*     */         }
/*     */       }
/* 549 */       String encoding = props;
/*     */       return encoding; } finally { is.close(); } throw localObject;
/*     */   }
/*     */ 
/*     */   public void clearCache()
/*     */   {
/* 562 */     this.logger.debug("Clearing entire resource bundle cache");
/* 563 */     synchronized (this.cachedProperties) {
/* 564 */       this.cachedProperties.clear();
/*     */     }
/* 566 */     synchronized (this.cachedMergedProperties) {
/* 567 */       this.cachedMergedProperties.clear();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void clearCacheIncludingAncestors()
/*     */   {
/* 576 */     clearCache();
/* 577 */     if ((getParentMessageSource() instanceof ReloadableResourceBundleMessageSource))
/* 578 */       ((ReloadableResourceBundleMessageSource)getParentMessageSource()).clearCacheIncludingAncestors();
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 585 */     return getClass().getName() + ": basenames=[" + StringUtils.arrayToCommaDelimitedString(this.basenames) + "]";
/*     */   }
/*     */ 
/*     */   protected class PropertiesHolder
/*     */   {
/*     */     private Properties properties;
/* 599 */     private long fileTimestamp = -1L;
/*     */ 
/* 601 */     private long refreshTimestamp = -1L;
/*     */ 
/* 604 */     private final Map<String, Map<Locale, MessageFormat>> cachedMessageFormats = new HashMap();
/*     */ 
/*     */     public PropertiesHolder(Properties properties, long fileTimestamp)
/*     */     {
/* 608 */       this.properties = properties;
/* 609 */       this.fileTimestamp = fileTimestamp;
/*     */     }
/*     */ 
/*     */     public PropertiesHolder() {
/*     */     }
/*     */ 
/*     */     public Properties getProperties() {
/* 616 */       return this.properties;
/*     */     }
/*     */ 
/*     */     public long getFileTimestamp() {
/* 620 */       return this.fileTimestamp;
/*     */     }
/*     */ 
/*     */     public void setRefreshTimestamp(long refreshTimestamp) {
/* 624 */       this.refreshTimestamp = refreshTimestamp;
/*     */     }
/*     */ 
/*     */     public long getRefreshTimestamp() {
/* 628 */       return this.refreshTimestamp;
/*     */     }
/*     */ 
/*     */     public String getProperty(String code) {
/* 632 */       if (this.properties == null) {
/* 633 */         return null;
/*     */       }
/* 635 */       return this.properties.getProperty(code);
/*     */     }
/*     */ 
/*     */     public MessageFormat getMessageFormat(String code, Locale locale) {
/* 639 */       if (this.properties == null) {
/* 640 */         return null;
/*     */       }
/* 642 */       synchronized (this.cachedMessageFormats) {
/* 643 */         Map localeMap = (Map)this.cachedMessageFormats.get(code);
/* 644 */         if (localeMap != null) {
/* 645 */           MessageFormat result = (MessageFormat)localeMap.get(locale);
/* 646 */           if (result != null) {
/* 647 */             return result;
/*     */           }
/*     */         }
/* 650 */         String msg = this.properties.getProperty(code);
/* 651 */         if (msg != null) {
/* 652 */           if (localeMap == null) {
/* 653 */             localeMap = new HashMap();
/* 654 */             this.cachedMessageFormats.put(code, localeMap);
/*     */           }
/* 656 */           MessageFormat result = ReloadableResourceBundleMessageSource.this.createMessageFormat(msg, locale);
/* 657 */           localeMap.put(locale, result);
/* 658 */           return result;
/*     */         }
/* 660 */         return null;
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.context.support.ReloadableResourceBundleMessageSource
 * JD-Core Version:    0.6.0
 */