/*     */ package org.springframework.context.support;
/*     */ 
/*     */ import org.springframework.beans.factory.xml.XmlBeanDefinitionReader;
/*     */ import org.springframework.core.env.ConfigurableEnvironment;
/*     */ import org.springframework.core.io.ClassPathResource;
/*     */ import org.springframework.core.io.Resource;
/*     */ 
/*     */ public class GenericXmlApplicationContext extends GenericApplicationContext
/*     */ {
/*  43 */   private final XmlBeanDefinitionReader reader = new XmlBeanDefinitionReader(this);
/*     */ 
/*     */   public GenericXmlApplicationContext()
/*     */   {
/*  51 */     this.reader.setEnvironment(getEnvironment());
/*     */   }
/*     */ 
/*     */   public GenericXmlApplicationContext(Resource[] resources)
/*     */   {
/*  60 */     load(resources);
/*  61 */     refresh();
/*     */   }
/*     */ 
/*     */   public GenericXmlApplicationContext(String[] resourceLocations)
/*     */   {
/*  70 */     load(resourceLocations);
/*  71 */     refresh();
/*     */   }
/*     */ 
/*     */   public GenericXmlApplicationContext(Class<?> relativeClass, String[] resourceNames)
/*     */   {
/*  82 */     load(relativeClass, resourceNames);
/*  83 */     refresh();
/*     */   }
/*     */ 
/*     */   public void setValidating(boolean validating)
/*     */   {
/*  90 */     this.reader.setValidating(validating);
/*     */   }
/*     */ 
/*     */   public void setEnvironment(ConfigurableEnvironment environment)
/*     */   {
/* 100 */     super.setEnvironment(environment);
/* 101 */     this.reader.setEnvironment(getEnvironment());
/*     */   }
/*     */ 
/*     */   public void load(Resource[] resources)
/*     */   {
/* 109 */     this.reader.loadBeanDefinitions(resources);
/*     */   }
/*     */ 
/*     */   public void load(String[] resourceLocations)
/*     */   {
/* 117 */     this.reader.loadBeanDefinitions(resourceLocations);
/*     */   }
/*     */ 
/*     */   public void load(Class<?> relativeClass, String[] resourceNames)
/*     */   {
/* 127 */     Resource[] resources = new Resource[resourceNames.length];
/* 128 */     for (int i = 0; i < resourceNames.length; i++) {
/* 129 */       resources[i] = new ClassPathResource(resourceNames[i], relativeClass);
/*     */     }
/* 131 */     load(resources);
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.context.support.GenericXmlApplicationContext
 * JD-Core Version:    0.6.0
 */