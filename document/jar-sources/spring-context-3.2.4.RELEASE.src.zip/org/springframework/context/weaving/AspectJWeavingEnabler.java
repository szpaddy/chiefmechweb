/*     */ package org.springframework.context.weaving;
/*     */ 
/*     */ import java.lang.instrument.ClassFileTransformer;
/*     */ import java.lang.instrument.IllegalClassFormatException;
/*     */ import java.security.ProtectionDomain;
/*     */ import org.aspectj.weaver.loadtime.ClassPreProcessorAgentAdapter;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.BeanClassLoaderAware;
/*     */ import org.springframework.beans.factory.config.BeanFactoryPostProcessor;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.core.Ordered;
/*     */ import org.springframework.instrument.classloading.InstrumentationLoadTimeWeaver;
/*     */ import org.springframework.instrument.classloading.LoadTimeWeaver;
/*     */ 
/*     */ public class AspectJWeavingEnabler
/*     */   implements BeanFactoryPostProcessor, BeanClassLoaderAware, LoadTimeWeaverAware, Ordered
/*     */ {
/*     */   private ClassLoader beanClassLoader;
/*     */   private LoadTimeWeaver loadTimeWeaver;
/*     */   public static final String ASPECTJ_AOP_XML_RESOURCE = "META-INF/aop.xml";
/*     */ 
/*     */   public void setBeanClassLoader(ClassLoader classLoader)
/*     */   {
/*  54 */     this.beanClassLoader = classLoader;
/*     */   }
/*     */ 
/*     */   public void setLoadTimeWeaver(LoadTimeWeaver loadTimeWeaver) {
/*  58 */     this.loadTimeWeaver = loadTimeWeaver;
/*     */   }
/*     */ 
/*     */   public int getOrder() {
/*  62 */     return -2147483648;
/*     */   }
/*     */ 
/*     */   public void postProcessBeanFactory(ConfigurableListableBeanFactory beanFactory) throws BeansException {
/*  66 */     enableAspectJWeaving(this.loadTimeWeaver, this.beanClassLoader);
/*     */   }
/*     */ 
/*     */   public static void enableAspectJWeaving(LoadTimeWeaver weaverToUse, ClassLoader beanClassLoader) {
/*  70 */     if (weaverToUse == null) {
/*  71 */       if (InstrumentationLoadTimeWeaver.isInstrumentationAvailable()) {
/*  72 */         weaverToUse = new InstrumentationLoadTimeWeaver(beanClassLoader);
/*     */       }
/*     */       else {
/*  75 */         throw new IllegalStateException("No LoadTimeWeaver available");
/*     */       }
/*     */     }
/*  78 */     weaverToUse.addTransformer(new AspectJClassBypassingClassFileTransformer(new ClassPreProcessorAgentAdapter()));
/*     */   }
/*     */ 
/*     */   private static class AspectJClassBypassingClassFileTransformer
/*     */     implements ClassFileTransformer
/*     */   {
/*     */     private final ClassFileTransformer delegate;
/*     */ 
/*     */     public AspectJClassBypassingClassFileTransformer(ClassFileTransformer delegate)
/*     */     {
/*  95 */       this.delegate = delegate;
/*     */     }
/*     */ 
/*     */     public byte[] transform(ClassLoader loader, String className, Class<?> classBeingRedefined, ProtectionDomain protectionDomain, byte[] classfileBuffer)
/*     */       throws IllegalClassFormatException
/*     */     {
/* 101 */       if ((className.startsWith("org.aspectj")) || (className.startsWith("org/aspectj"))) {
/* 102 */         return classfileBuffer;
/*     */       }
/* 104 */       return this.delegate.transform(loader, className, classBeingRedefined, protectionDomain, classfileBuffer);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.context.weaving.AspectJWeavingEnabler
 * JD-Core Version:    0.6.0
 */