package org.springframework.context.weaving;

import org.springframework.beans.factory.Aware;
import org.springframework.instrument.classloading.LoadTimeWeaver;

public abstract interface LoadTimeWeaverAware extends Aware
{
  public abstract void setLoadTimeWeaver(LoadTimeWeaver paramLoadTimeWeaver);
}

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.context.weaving.LoadTimeWeaverAware
 * JD-Core Version:    0.6.0
 */