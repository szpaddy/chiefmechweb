/*     */ package org.springframework.context.weaving;
/*     */ 
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.config.BeanPostProcessor;
/*     */ import org.springframework.instrument.classloading.LoadTimeWeaver;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public class LoadTimeWeaverAwareProcessor
/*     */   implements BeanPostProcessor, BeanFactoryAware
/*     */ {
/*     */   private LoadTimeWeaver loadTimeWeaver;
/*     */   private BeanFactory beanFactory;
/*     */ 
/*     */   public LoadTimeWeaverAwareProcessor()
/*     */   {
/*     */   }
/*     */ 
/*     */   public LoadTimeWeaverAwareProcessor(LoadTimeWeaver loadTimeWeaver)
/*     */   {
/*  69 */     this.loadTimeWeaver = loadTimeWeaver;
/*     */   }
/*     */ 
/*     */   public LoadTimeWeaverAwareProcessor(BeanFactory beanFactory)
/*     */   {
/*  80 */     this.beanFactory = beanFactory;
/*     */   }
/*     */ 
/*     */   public void setBeanFactory(BeanFactory beanFactory)
/*     */   {
/*  85 */     this.beanFactory = beanFactory;
/*     */   }
/*     */ 
/*     */   public Object postProcessBeforeInitialization(Object bean, String beanName) throws BeansException
/*     */   {
/*  90 */     if ((bean instanceof LoadTimeWeaverAware)) {
/*  91 */       LoadTimeWeaver ltw = this.loadTimeWeaver;
/*  92 */       if (ltw == null) {
/*  93 */         Assert.state(this.beanFactory != null, "BeanFactory required if no LoadTimeWeaver explicitly specified");
/*     */ 
/*  95 */         ltw = (LoadTimeWeaver)this.beanFactory.getBean("loadTimeWeaver", LoadTimeWeaver.class);
/*     */       }
/*     */ 
/*  98 */       ((LoadTimeWeaverAware)bean).setLoadTimeWeaver(ltw);
/*     */     }
/* 100 */     return bean;
/*     */   }
/*     */ 
/*     */   public Object postProcessAfterInitialization(Object bean, String name) {
/* 104 */     return bean;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.context.weaving.LoadTimeWeaverAwareProcessor
 * JD-Core Version:    0.6.0
 */