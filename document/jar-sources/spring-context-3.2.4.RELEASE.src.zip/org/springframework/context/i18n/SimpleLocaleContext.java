/*    */ package org.springframework.context.i18n;
/*    */ 
/*    */ import java.util.Locale;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ public class SimpleLocaleContext
/*    */   implements LocaleContext
/*    */ {
/*    */   private final Locale locale;
/*    */ 
/*    */   public SimpleLocaleContext(Locale locale)
/*    */   {
/* 41 */     Assert.notNull(locale, "Locale must not be null");
/* 42 */     this.locale = locale;
/*    */   }
/*    */ 
/*    */   public Locale getLocale() {
/* 46 */     return this.locale;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 51 */     return this.locale.toString();
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.context.i18n.SimpleLocaleContext
 * JD-Core Version:    0.6.0
 */