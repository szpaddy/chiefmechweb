/*     */ package org.springframework.context.i18n;
/*     */ 
/*     */ import java.util.Locale;
/*     */ import org.springframework.core.NamedInheritableThreadLocal;
/*     */ import org.springframework.core.NamedThreadLocal;
/*     */ 
/*     */ public abstract class LocaleContextHolder
/*     */ {
/*  44 */   private static final ThreadLocal<LocaleContext> localeContextHolder = new NamedThreadLocal("Locale context");
/*     */ 
/*  47 */   private static final ThreadLocal<LocaleContext> inheritableLocaleContextHolder = new NamedInheritableThreadLocal("Locale context");
/*     */ 
/*     */   public static void resetLocaleContext()
/*     */   {
/*  55 */     localeContextHolder.remove();
/*  56 */     inheritableLocaleContextHolder.remove();
/*     */   }
/*     */ 
/*     */   public static void setLocaleContext(LocaleContext localeContext)
/*     */   {
/*  65 */     setLocaleContext(localeContext, false);
/*     */   }
/*     */ 
/*     */   public static void setLocaleContext(LocaleContext localeContext, boolean inheritable)
/*     */   {
/*  76 */     if (localeContext == null) {
/*  77 */       resetLocaleContext();
/*     */     }
/*  80 */     else if (inheritable) {
/*  81 */       inheritableLocaleContextHolder.set(localeContext);
/*  82 */       localeContextHolder.remove();
/*     */     }
/*     */     else {
/*  85 */       localeContextHolder.set(localeContext);
/*  86 */       inheritableLocaleContextHolder.remove();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static LocaleContext getLocaleContext()
/*     */   {
/*  96 */     LocaleContext localeContext = (LocaleContext)localeContextHolder.get();
/*  97 */     if (localeContext == null) {
/*  98 */       localeContext = (LocaleContext)inheritableLocaleContextHolder.get();
/*     */     }
/* 100 */     return localeContext;
/*     */   }
/*     */ 
/*     */   public static void setLocale(Locale locale)
/*     */   {
/* 112 */     setLocale(locale, false);
/*     */   }
/*     */ 
/*     */   public static void setLocale(Locale locale, boolean inheritable)
/*     */   {
/* 125 */     LocaleContext localeContext = locale != null ? new SimpleLocaleContext(locale) : null;
/* 126 */     setLocaleContext(localeContext, inheritable);
/*     */   }
/*     */ 
/*     */   public static Locale getLocale()
/*     */   {
/* 138 */     LocaleContext localeContext = getLocaleContext();
/* 139 */     return localeContext != null ? localeContext.getLocale() : Locale.getDefault();
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.context.i18n.LocaleContextHolder
 * JD-Core Version:    0.6.0
 */