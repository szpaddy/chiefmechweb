/*    */ package org.springframework.context.config;
/*    */ 
/*    */ import org.springframework.beans.factory.config.BeanDefinition;
/*    */ import org.springframework.beans.factory.parsing.BeanComponentDefinition;
/*    */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*    */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*    */ import org.springframework.beans.factory.xml.BeanDefinitionParser;
/*    */ import org.springframework.beans.factory.xml.ParserContext;
/*    */ import org.w3c.dom.Element;
/*    */ 
/*    */ class SpringConfiguredBeanDefinitionParser
/*    */   implements BeanDefinitionParser
/*    */ {
/*    */   public static final String BEAN_CONFIGURER_ASPECT_BEAN_NAME = "org.springframework.context.config.internalBeanConfigurerAspect";
/*    */   static final String BEAN_CONFIGURER_ASPECT_CLASS_NAME = "org.springframework.beans.factory.aspectj.AnnotationBeanConfigurerAspect";
/*    */ 
/*    */   public BeanDefinition parse(Element element, ParserContext parserContext)
/*    */   {
/* 47 */     if (!parserContext.getRegistry().containsBeanDefinition("org.springframework.context.config.internalBeanConfigurerAspect")) {
/* 48 */       RootBeanDefinition def = new RootBeanDefinition();
/* 49 */       def.setBeanClassName("org.springframework.beans.factory.aspectj.AnnotationBeanConfigurerAspect");
/* 50 */       def.setFactoryMethodName("aspectOf");
/* 51 */       def.setRole(2);
/* 52 */       def.setSource(parserContext.extractSource(element));
/* 53 */       parserContext.registerBeanComponent(new BeanComponentDefinition(def, "org.springframework.context.config.internalBeanConfigurerAspect"));
/*    */     }
/* 55 */     return null;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.context.config.SpringConfiguredBeanDefinitionParser
 * JD-Core Version:    0.6.0
 */