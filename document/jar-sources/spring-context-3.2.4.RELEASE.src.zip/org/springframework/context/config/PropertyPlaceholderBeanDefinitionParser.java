/*    */ package org.springframework.context.config;
/*    */ 
/*    */ import org.springframework.beans.factory.config.PropertyPlaceholderConfigurer;
/*    */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*    */ import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
/*    */ import org.springframework.util.StringUtils;
/*    */ import org.w3c.dom.Element;
/*    */ 
/*    */ class PropertyPlaceholderBeanDefinitionParser extends AbstractPropertyLoadingBeanDefinitionParser
/*    */ {
/*    */   private static final String SYSTEM_PROPERTIES_MODE_ATTRIB = "system-properties-mode";
/*    */   private static final String SYSTEM_PROPERTIES_MODE_DEFAULT = "ENVIRONMENT";
/*    */ 
/*    */   protected Class<?> getBeanClass(Element element)
/*    */   {
/* 45 */     if (element.getAttribute("system-properties-mode").equals("ENVIRONMENT")) {
/* 46 */       return PropertySourcesPlaceholderConfigurer.class;
/*    */     }
/*    */ 
/* 51 */     return PropertyPlaceholderConfigurer.class;
/*    */   }
/*    */ 
/*    */   protected void doParse(Element element, BeanDefinitionBuilder builder)
/*    */   {
/* 56 */     super.doParse(element, builder);
/*    */ 
/* 58 */     builder.addPropertyValue("ignoreUnresolvablePlaceholders", Boolean.valueOf(element.getAttribute("ignore-unresolvable")));
/*    */ 
/* 61 */     String systemPropertiesModeName = element.getAttribute("system-properties-mode");
/* 62 */     if ((StringUtils.hasLength(systemPropertiesModeName)) && (!systemPropertiesModeName.equals("ENVIRONMENT")))
/*    */     {
/* 64 */       builder.addPropertyValue("systemPropertiesModeName", "SYSTEM_PROPERTIES_MODE_" + systemPropertiesModeName);
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.context.config.PropertyPlaceholderBeanDefinitionParser
 * JD-Core Version:    0.6.0
 */