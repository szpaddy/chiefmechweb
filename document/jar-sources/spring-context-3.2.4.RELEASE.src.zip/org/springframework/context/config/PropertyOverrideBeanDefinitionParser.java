/*    */ package org.springframework.context.config;
/*    */ 
/*    */ import org.springframework.beans.factory.config.PropertyOverrideConfigurer;
/*    */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*    */ import org.w3c.dom.Element;
/*    */ 
/*    */ class PropertyOverrideBeanDefinitionParser extends AbstractPropertyLoadingBeanDefinitionParser
/*    */ {
/*    */   protected Class getBeanClass(Element element)
/*    */   {
/* 35 */     return PropertyOverrideConfigurer.class;
/*    */   }
/*    */ 
/*    */   protected void doParse(Element element, BeanDefinitionBuilder builder)
/*    */   {
/* 41 */     super.doParse(element, builder);
/* 42 */     builder.addPropertyValue("ignoreInvalidKeys", Boolean.valueOf(element.getAttribute("ignore-unresolvable")));
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.context.config.PropertyOverrideBeanDefinitionParser
 * JD-Core Version:    0.6.0
 */