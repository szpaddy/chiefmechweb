package org.springframework.context;

import org.springframework.beans.factory.Aware;

public abstract interface ApplicationEventPublisherAware extends Aware
{
  public abstract void setApplicationEventPublisher(ApplicationEventPublisher paramApplicationEventPublisher);
}

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.context.ApplicationEventPublisherAware
 * JD-Core Version:    0.6.0
 */