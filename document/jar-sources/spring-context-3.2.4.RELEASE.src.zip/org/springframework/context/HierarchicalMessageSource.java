package org.springframework.context;

public abstract interface HierarchicalMessageSource extends MessageSource
{
  public abstract void setParentMessageSource(MessageSource paramMessageSource);

  public abstract MessageSource getParentMessageSource();
}

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.context.HierarchicalMessageSource
 * JD-Core Version:    0.6.0
 */