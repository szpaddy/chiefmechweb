package org.springframework.context;

import java.util.Locale;

public abstract interface MessageSource
{
  public abstract String getMessage(String paramString1, Object[] paramArrayOfObject, String paramString2, Locale paramLocale);

  public abstract String getMessage(String paramString, Object[] paramArrayOfObject, Locale paramLocale)
    throws NoSuchMessageException;

  public abstract String getMessage(MessageSourceResolvable paramMessageSourceResolvable, Locale paramLocale)
    throws NoSuchMessageException;
}

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.context.MessageSource
 * JD-Core Version:    0.6.0
 */