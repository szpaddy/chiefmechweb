/*    */ package org.springframework.context;
/*    */ 
/*    */ import java.util.EventObject;
/*    */ 
/*    */ public abstract class ApplicationEvent extends EventObject
/*    */ {
/*    */   private static final long serialVersionUID = 7099057708183571937L;
/*    */   private final long timestamp;
/*    */ 
/*    */   public ApplicationEvent(Object source)
/*    */   {
/* 42 */     super(source);
/* 43 */     this.timestamp = System.currentTimeMillis();
/*    */   }
/*    */ 
/*    */   public final long getTimestamp()
/*    */   {
/* 51 */     return this.timestamp;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.context.ApplicationEvent
 * JD-Core Version:    0.6.0
 */