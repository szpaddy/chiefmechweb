package org.springframework.context.annotation;

import org.springframework.beans.factory.config.BeanDefinition;

public abstract interface ScopeMetadataResolver
{
  public abstract ScopeMetadata resolveScopeMetadata(BeanDefinition paramBeanDefinition);
}

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.context.annotation.ScopeMetadataResolver
 * JD-Core Version:    0.6.0
 */