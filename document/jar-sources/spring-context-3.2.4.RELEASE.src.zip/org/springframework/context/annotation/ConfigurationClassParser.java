/*     */ package org.springframework.context.annotation;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.Stack;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.factory.Aware;
/*     */ import org.springframework.beans.factory.BeanClassLoaderAware;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanDefinitionHolder;
/*     */ import org.springframework.beans.factory.config.ConfigurableBeanFactory;
/*     */ import org.springframework.beans.factory.parsing.Location;
/*     */ import org.springframework.beans.factory.parsing.Problem;
/*     */ import org.springframework.beans.factory.parsing.ProblemReporter;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.beans.factory.support.BeanNameGenerator;
/*     */ import org.springframework.context.ResourceLoaderAware;
/*     */ import org.springframework.core.NestedIOException;
/*     */ import org.springframework.core.annotation.AnnotationAttributes;
/*     */ import org.springframework.core.env.CompositePropertySource;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.core.io.support.ResourcePropertySource;
/*     */ import org.springframework.core.type.AnnotationMetadata;
/*     */ import org.springframework.core.type.MethodMetadata;
/*     */ import org.springframework.core.type.StandardAnnotationMetadata;
/*     */ import org.springframework.core.type.classreading.MetadataReader;
/*     */ import org.springframework.core.type.classreading.MetadataReaderFactory;
/*     */ import org.springframework.core.type.filter.AssignableTypeFilter;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ class ConfigurationClassParser
/*     */ {
/*     */   private final MetadataReaderFactory metadataReaderFactory;
/*     */   private final ProblemReporter problemReporter;
/*     */   private final Environment environment;
/*     */   private final ResourceLoader resourceLoader;
/*     */   private final BeanDefinitionRegistry registry;
/*     */   private final ComponentScanAnnotationParser componentScanParser;
/*  96 */   private final Set<ConfigurationClass> configurationClasses = new LinkedHashSet();
/*     */ 
/*  98 */   private final Map<String, ConfigurationClass> knownSuperclasses = new HashMap();
/*     */ 
/* 100 */   private final Stack<org.springframework.core.env.PropertySource<?>> propertySources = new Stack();
/*     */ 
/* 102 */   private final ImportStack importStack = new ImportStack(null);
/*     */ 
/*     */   public ConfigurationClassParser(MetadataReaderFactory metadataReaderFactory, ProblemReporter problemReporter, Environment environment, ResourceLoader resourceLoader, BeanNameGenerator componentScanBeanNameGenerator, BeanDefinitionRegistry registry)
/*     */   {
/* 113 */     this.metadataReaderFactory = metadataReaderFactory;
/* 114 */     this.problemReporter = problemReporter;
/* 115 */     this.environment = environment;
/* 116 */     this.resourceLoader = resourceLoader;
/* 117 */     this.registry = registry;
/* 118 */     this.componentScanParser = new ComponentScanAnnotationParser(resourceLoader, environment, componentScanBeanNameGenerator, registry);
/*     */   }
/*     */ 
/*     */   public void parse(String className, String beanName)
/*     */     throws IOException
/*     */   {
/* 130 */     MetadataReader reader = this.metadataReaderFactory.getMetadataReader(className);
/* 131 */     processConfigurationClass(new ConfigurationClass(reader, beanName));
/*     */   }
/*     */ 
/*     */   public void parse(Class<?> clazz, String beanName)
/*     */     throws IOException
/*     */   {
/* 140 */     processConfigurationClass(new ConfigurationClass(clazz, beanName));
/*     */   }
/*     */ 
/*     */   protected void processConfigurationClass(ConfigurationClass configClass) throws IOException {
/* 144 */     AnnotationMetadata metadata = configClass.getMetadata();
/* 145 */     if ((this.environment != null) && (metadata.isAnnotated(Profile.class.getName()))) {
/* 146 */       AnnotationAttributes profile = MetadataUtils.attributesFor(metadata, Profile.class);
/* 147 */       if (!this.environment.acceptsProfiles(profile.getStringArray("value")))
/* 148 */         return;
/*     */     }
/*     */     Iterator it;
/* 152 */     if ((this.configurationClasses.contains(configClass)) && (configClass.getBeanName() != null))
/*     */     {
/* 155 */       this.configurationClasses.remove(configClass);
/* 156 */       for (it = this.knownSuperclasses.values().iterator(); it.hasNext(); ) {
/* 157 */         if (configClass.equals(it.next())) {
/* 158 */           it.remove();
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*     */     do
/*     */     {
/* 165 */       metadata = doProcessConfigurationClass(configClass, metadata);
/*     */     }
/* 167 */     while (metadata != null);
/*     */ 
/* 169 */     this.configurationClasses.add(configClass);
/*     */   }
/*     */ 
/*     */   protected AnnotationMetadata doProcessConfigurationClass(ConfigurationClass configClass, AnnotationMetadata metadata)
/*     */     throws IOException
/*     */   {
/* 179 */     processMemberClasses(metadata);
/*     */ 
/* 182 */     AnnotationAttributes propertySource = MetadataUtils.attributesFor(metadata, PropertySource.class);
/* 183 */     if (propertySource != null) {
/* 184 */       processPropertySource(propertySource);
/*     */     }
/*     */ 
/* 188 */     AnnotationAttributes componentScan = MetadataUtils.attributesFor(metadata, ComponentScan.class);
/* 189 */     if (componentScan != null)
/*     */     {
/* 191 */       Set scannedBeanDefinitions = this.componentScanParser.parse(componentScan, metadata.getClassName());
/*     */ 
/* 195 */       for (BeanDefinitionHolder holder : scannedBeanDefinitions) {
/* 196 */         if (ConfigurationClassUtils.checkConfigurationClassCandidate(holder.getBeanDefinition(), this.metadataReaderFactory)) {
/* 197 */           parse(holder.getBeanDefinition().getBeanClassName(), holder.getBeanName());
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 203 */     Set imports = new LinkedHashSet();
/* 204 */     Set visited = new LinkedHashSet();
/* 205 */     collectImports(metadata, imports, visited);
/* 206 */     if (!imports.isEmpty()) {
/* 207 */       processImport(configClass, imports, true);
/*     */     }
/*     */ 
/* 211 */     if (metadata.isAnnotated(ImportResource.class.getName())) {
/* 212 */       AnnotationAttributes importResource = MetadataUtils.attributesFor(metadata, ImportResource.class);
/* 213 */       String[] resources = importResource.getStringArray("value");
/* 214 */       Class readerClass = importResource.getClass("reader");
/* 215 */       for (String resource : resources) {
/* 216 */         String resolvedResource = this.environment.resolveRequiredPlaceholders(resource);
/* 217 */         configClass.addImportedResource(resolvedResource, readerClass);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 222 */     Set beanMethods = metadata.getAnnotatedMethods(Bean.class.getName());
/* 223 */     for (MethodMetadata methodMetadata : beanMethods) {
/* 224 */       configClass.addBeanMethod(new BeanMethod(methodMetadata, configClass));
/*     */     }
/*     */ 
/* 228 */     if (metadata.hasSuperClass()) {
/* 229 */       String superclass = metadata.getSuperClassName();
/* 230 */       if (!this.knownSuperclasses.containsKey(superclass)) {
/* 231 */         this.knownSuperclasses.put(superclass, configClass);
/*     */ 
/* 233 */         if ((metadata instanceof StandardAnnotationMetadata)) {
/* 234 */           Class clazz = ((StandardAnnotationMetadata)metadata).getIntrospectedClass();
/* 235 */           return new StandardAnnotationMetadata(clazz.getSuperclass(), true);
/*     */         }
/* 237 */         if (superclass.startsWith("java")) {
/*     */           try
/*     */           {
/* 240 */             return new StandardAnnotationMetadata(this.resourceLoader.getClassLoader().loadClass(superclass), true);
/*     */           }
/*     */           catch (ClassNotFoundException ex)
/*     */           {
/* 244 */             throw new IllegalStateException(ex);
/*     */           }
/*     */         }
/*     */ 
/* 248 */         MetadataReader reader = this.metadataReaderFactory.getMetadataReader(superclass);
/* 249 */         return reader.getAnnotationMetadata();
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 255 */     return null;
/*     */   }
/*     */ 
/*     */   private void processMemberClasses(AnnotationMetadata metadata)
/*     */     throws IOException
/*     */   {
/* 264 */     if ((metadata instanceof StandardAnnotationMetadata)) {
/* 265 */       for (Class memberClass : ((StandardAnnotationMetadata)metadata).getIntrospectedClass().getDeclaredClasses()) {
/* 266 */         if (ConfigurationClassUtils.isConfigurationCandidate(new StandardAnnotationMetadata(memberClass))) {
/* 267 */           processConfigurationClass(new ConfigurationClass(memberClass, true));
/*     */         }
/*     */       }
/*     */     }
/*     */     else
/* 272 */       for (String memberClassName : metadata.getMemberClassNames()) {
/* 273 */         MetadataReader reader = this.metadataReaderFactory.getMetadataReader(memberClassName);
/* 274 */         AnnotationMetadata memberClassMetadata = reader.getAnnotationMetadata();
/* 275 */         if (ConfigurationClassUtils.isConfigurationCandidate(memberClassMetadata))
/* 276 */           processConfigurationClass(new ConfigurationClass(reader, true));
/*     */       }
/*     */   }
/*     */ 
/*     */   private void processPropertySource(AnnotationAttributes propertySource)
/*     */     throws IOException
/*     */   {
/* 288 */     String name = propertySource.getString("name");
/* 289 */     String[] locations = propertySource.getStringArray("value");
/* 290 */     int nLocations = locations.length;
/* 291 */     if (nLocations == 0) {
/* 292 */       throw new IllegalArgumentException("At least one @PropertySource(value) location is required");
/*     */     }
/* 294 */     for (int i = 0; i < nLocations; i++) {
/* 295 */       locations[i] = this.environment.resolveRequiredPlaceholders(locations[i]);
/*     */     }
/* 297 */     ClassLoader classLoader = this.resourceLoader.getClassLoader();
/* 298 */     if (!StringUtils.hasText(name)) {
/* 299 */       for (String location : locations) {
/* 300 */         this.propertySources.push(new ResourcePropertySource(location, classLoader));
/*     */       }
/*     */ 
/*     */     }
/* 304 */     else if (nLocations == 1) {
/* 305 */       this.propertySources.push(new ResourcePropertySource(name, locations[0], classLoader));
/*     */     }
/*     */     else {
/* 308 */       CompositePropertySource ps = new CompositePropertySource(name);
/* 309 */       for (String location : locations) {
/* 310 */         ps.addPropertySource(new ResourcePropertySource(location, classLoader));
/*     */       }
/* 312 */       this.propertySources.push(ps);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void collectImports(AnnotationMetadata metadata, Set<Object> imports, Set<Object> visited)
/*     */     throws IOException
/*     */   {
/* 331 */     String className = metadata.getClassName();
/* 332 */     if (visited.add(className))
/* 333 */       if ((metadata instanceof StandardAnnotationMetadata)) {
/* 334 */         StandardAnnotationMetadata stdMetadata = (StandardAnnotationMetadata)metadata;
/* 335 */         for (Annotation ann : stdMetadata.getIntrospectedClass().getAnnotations()) {
/* 336 */           if ((!ann.annotationType().getName().startsWith("java")) && (!(ann instanceof Import))) {
/* 337 */             collectImports(new StandardAnnotationMetadata(ann.annotationType()), imports, visited);
/*     */           }
/*     */         }
/* 340 */         Map attributes = stdMetadata.getAnnotationAttributes(Import.class.getName(), false);
/* 341 */         if (attributes != null) {
/* 342 */           Class[] value = (Class[])(Class[])attributes.get("value");
/* 343 */           if (!ObjectUtils.isEmpty(value))
/* 344 */             imports.addAll(Arrays.asList(value));
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 349 */         for (String annotationType : metadata.getAnnotationTypes()) {
/* 350 */           if ((!className.startsWith("java")) && (!className.equals(Import.class.getName()))) {
/*     */             try {
/* 352 */               collectImports(new StandardAnnotationMetadata(this.resourceLoader.getClassLoader().loadClass(annotationType)), imports, visited);
/*     */             }
/*     */             catch (ClassNotFoundException ex)
/*     */             {
/*     */             }
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/* 361 */         Map attributes = metadata.getAnnotationAttributes(Import.class.getName(), true);
/* 362 */         if (attributes != null) {
/* 363 */           String[] value = (String[])(String[])attributes.get("value");
/* 364 */           if (!ObjectUtils.isEmpty(value))
/* 365 */             imports.addAll(Arrays.asList(value));
/*     */         }
/*     */       }
/*     */   }
/*     */ 
/*     */   private void processImport(ConfigurationClass configClass, Collection<?> classesToImport, boolean checkForCircularImports)
/*     */     throws IOException
/*     */   {
/* 373 */     if ((checkForCircularImports) && (this.importStack.contains(configClass))) {
/* 374 */       this.problemReporter.error(new CircularImportProblem(configClass, this.importStack, configClass.getMetadata()));
/*     */     }
/*     */     else {
/* 377 */       this.importStack.push(configClass);
/* 378 */       AnnotationMetadata importingClassMetadata = configClass.getMetadata();
/*     */       try {
/* 380 */         for (i$ = classesToImport.iterator(); i$.hasNext(); ) { Object candidate = i$.next();
/* 381 */           Object candidateToCheck = (candidate instanceof Class) ? (Class)candidate : this.metadataReaderFactory.getMetadataReader((String)candidate);
/*     */ 
/* 383 */           if (checkAssignability(ImportSelector.class, candidateToCheck))
/*     */           {
/* 385 */             Class candidateClass = (candidate instanceof Class) ? (Class)candidate : this.resourceLoader.getClassLoader().loadClass((String)candidate);
/*     */ 
/* 387 */             ImportSelector selector = (ImportSelector)BeanUtils.instantiateClass(candidateClass, ImportSelector.class);
/* 388 */             processImport(configClass, Arrays.asList(selector.selectImports(importingClassMetadata)), false);
/*     */           }
/* 390 */           else if (checkAssignability(ImportBeanDefinitionRegistrar.class, candidateToCheck))
/*     */           {
/* 392 */             Class candidateClass = (candidate instanceof Class) ? (Class)candidate : this.resourceLoader.getClassLoader().loadClass((String)candidate);
/*     */ 
/* 394 */             ImportBeanDefinitionRegistrar registrar = (ImportBeanDefinitionRegistrar)BeanUtils.instantiateClass(candidateClass, ImportBeanDefinitionRegistrar.class);
/* 395 */             invokeAwareMethods(registrar);
/* 396 */             registrar.registerBeanDefinitions(importingClassMetadata, this.registry);
/*     */           }
/*     */           else
/*     */           {
/* 400 */             this.importStack.registerImport(importingClassMetadata.getClassName(), (candidate instanceof Class) ? ((Class)candidate).getName() : (String)candidate);
/*     */ 
/* 402 */             processConfigurationClass((candidateToCheck instanceof Class) ? new ConfigurationClass((Class)candidateToCheck, true) : new ConfigurationClass((MetadataReader)candidateToCheck, true));
/*     */           }
/*     */         }
/*     */       }
/*     */       catch (ClassNotFoundException ex)
/*     */       {
/*     */         Iterator i$;
/* 408 */         throw new NestedIOException("Failed to load import candidate class", ex);
/*     */       }
/*     */       finally {
/* 411 */         this.importStack.pop();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private boolean checkAssignability(Class<?> clazz, Object candidate) throws IOException {
/* 417 */     if ((candidate instanceof Class)) {
/* 418 */       return clazz.isAssignableFrom((Class)candidate);
/*     */     }
/*     */ 
/* 421 */     return new AssignableTypeFilter(clazz).match((MetadataReader)candidate, this.metadataReaderFactory);
/*     */   }
/*     */ 
/*     */   private void invokeAwareMethods(ImportBeanDefinitionRegistrar registrar)
/*     */   {
/* 430 */     if ((registrar instanceof Aware)) {
/* 431 */       if ((registrar instanceof ResourceLoaderAware)) {
/* 432 */         ((ResourceLoaderAware)registrar).setResourceLoader(this.resourceLoader);
/*     */       }
/* 434 */       if ((registrar instanceof BeanClassLoaderAware)) {
/* 435 */         ClassLoader classLoader = (this.registry instanceof ConfigurableBeanFactory) ? ((ConfigurableBeanFactory)this.registry).getBeanClassLoader() : this.resourceLoader.getClassLoader();
/*     */ 
/* 438 */         ((BeanClassLoaderAware)registrar).setBeanClassLoader(classLoader);
/*     */       }
/* 440 */       if (((registrar instanceof BeanFactoryAware)) && ((this.registry instanceof BeanFactory)))
/* 441 */         ((BeanFactoryAware)registrar).setBeanFactory((BeanFactory)this.registry);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void validate()
/*     */   {
/* 452 */     for (ConfigurationClass configClass : this.configurationClasses)
/* 453 */       configClass.validate(this.problemReporter);
/*     */   }
/*     */ 
/*     */   public Set<ConfigurationClass> getConfigurationClasses()
/*     */   {
/* 458 */     return this.configurationClasses;
/*     */   }
/*     */ 
/*     */   public Stack<org.springframework.core.env.PropertySource<?>> getPropertySources() {
/* 462 */     return this.propertySources;
/*     */   }
/*     */ 
/*     */   ImportRegistry getImportRegistry() {
/* 466 */     return this.importStack;
/*     */   }
/*     */ 
/*     */   private static class CircularImportProblem extends Problem
/*     */   {
/*     */     public CircularImportProblem(ConfigurationClass attemptedImport, Stack<ConfigurationClass> importStack, AnnotationMetadata metadata)
/*     */     {
/* 535 */       super(new Location(((ConfigurationClass)importStack.peek()).getResource(), metadata));
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class ImportStack extends Stack<ConfigurationClass>
/*     */     implements ConfigurationClassParser.ImportRegistry
/*     */   {
/* 479 */     private final Map<String, String> imports = new HashMap();
/*     */ 
/*     */     public void registerImport(String importingClass, String importedClass) {
/* 482 */       this.imports.put(importedClass, importingClass);
/*     */     }
/*     */ 
/*     */     public String getImportingClassFor(String importedClass) {
/* 486 */       return (String)this.imports.get(importedClass);
/*     */     }
/*     */ 
/*     */     public boolean contains(Object elem)
/*     */     {
/* 496 */       ConfigurationClass configClass = (ConfigurationClass)elem;
/* 497 */       Comparator comparator = new Comparator() {
/*     */         public int compare(ConfigurationClass first, ConfigurationClass second) {
/* 499 */           return first.getMetadata().getClassName().equals(second.getMetadata().getClassName()) ? 0 : 1;
/*     */         }
/*     */       };
/* 502 */       return Collections.binarySearch(this, configClass, comparator) != -1;
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/* 516 */       StringBuilder builder = new StringBuilder("ImportStack: [");
/* 517 */       Iterator iterator = iterator();
/* 518 */       while (iterator.hasNext()) {
/* 519 */         builder.append(((ConfigurationClass)iterator.next()).getSimpleName());
/* 520 */         if (iterator.hasNext()) {
/* 521 */           builder.append("->");
/*     */         }
/*     */       }
/* 524 */       return ']';
/*     */     }
/*     */   }
/*     */ 
/*     */   static abstract interface ImportRegistry
/*     */   {
/*     */     public abstract String getImportingClassFor(String paramString);
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.context.annotation.ConfigurationClassParser
 * JD-Core Version:    0.6.0
 */