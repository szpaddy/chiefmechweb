/*     */ package org.springframework.context.annotation;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.Stack;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.BeanClassLoaderAware;
/*     */ import org.springframework.beans.factory.BeanDefinitionStoreException;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanDefinitionHolder;
/*     */ import org.springframework.beans.factory.config.BeanPostProcessor;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.beans.factory.config.SingletonBeanRegistry;
/*     */ import org.springframework.beans.factory.parsing.FailFastProblemReporter;
/*     */ import org.springframework.beans.factory.parsing.PassThroughSourceExtractor;
/*     */ import org.springframework.beans.factory.parsing.ProblemReporter;
/*     */ import org.springframework.beans.factory.parsing.SourceExtractor;
/*     */ import org.springframework.beans.factory.support.AbstractBeanDefinition;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistryPostProcessor;
/*     */ import org.springframework.beans.factory.support.BeanNameGenerator;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ import org.springframework.context.EnvironmentAware;
/*     */ import org.springframework.context.ResourceLoaderAware;
/*     */ import org.springframework.core.Ordered;
/*     */ import org.springframework.core.PriorityOrdered;
/*     */ import org.springframework.core.env.ConfigurableEnvironment;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.env.MutablePropertySources;
/*     */ import org.springframework.core.env.PropertySource;
/*     */ import org.springframework.core.io.DefaultResourceLoader;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.core.type.AnnotationMetadata;
/*     */ import org.springframework.core.type.classreading.CachingMetadataReaderFactory;
/*     */ import org.springframework.core.type.classreading.MetadataReader;
/*     */ import org.springframework.core.type.classreading.MetadataReaderFactory;
/*     */ import org.springframework.core.type.classreading.SimpleMetadataReaderFactory;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ public class ConfigurationClassPostProcessor
/*     */   implements BeanDefinitionRegistryPostProcessor, ResourceLoaderAware, BeanClassLoaderAware, EnvironmentAware, Ordered
/*     */ {
/*  90 */   private static final String IMPORT_AWARE_PROCESSOR_BEAN_NAME = ConfigurationClassPostProcessor.class.getName() + ".importAwareProcessor";
/*     */ 
/*  93 */   private static final String IMPORT_REGISTRY_BEAN_NAME = ConfigurationClassPostProcessor.class.getName() + ".importRegistry";
/*     */   private final Log logger;
/*     */   private SourceExtractor sourceExtractor;
/*     */   private ProblemReporter problemReporter;
/*     */   private Environment environment;
/*     */   private ResourceLoader resourceLoader;
/*     */   private ClassLoader beanClassLoader;
/*     */   private MetadataReaderFactory metadataReaderFactory;
/*     */   private boolean setMetadataReaderFactoryCalled;
/*     */   private final Set<Integer> registriesPostProcessed;
/*     */   private final Set<Integer> factoriesPostProcessed;
/*     */   private ConfigurationClassBeanDefinitionReader reader;
/*     */   private boolean localBeanNameGeneratorSet;
/*     */   private BeanNameGenerator componentScanBeanNameGenerator;
/*     */   private BeanNameGenerator importBeanNameGenerator;
/*     */ 
/*     */   public ConfigurationClassPostProcessor()
/*     */   {
/*  97 */     this.logger = LogFactory.getLog(getClass());
/*     */ 
/*  99 */     this.sourceExtractor = new PassThroughSourceExtractor();
/*     */ 
/* 101 */     this.problemReporter = new FailFastProblemReporter();
/*     */ 
/* 105 */     this.resourceLoader = new DefaultResourceLoader();
/*     */ 
/* 107 */     this.beanClassLoader = ClassUtils.getDefaultClassLoader();
/*     */ 
/* 109 */     this.metadataReaderFactory = new CachingMetadataReaderFactory();
/*     */ 
/* 111 */     this.setMetadataReaderFactoryCalled = false;
/*     */ 
/* 113 */     this.registriesPostProcessed = new HashSet();
/*     */ 
/* 115 */     this.factoriesPostProcessed = new HashSet();
/*     */ 
/* 119 */     this.localBeanNameGeneratorSet = false;
/*     */ 
/* 122 */     this.componentScanBeanNameGenerator = new AnnotationBeanNameGenerator();
/*     */ 
/* 125 */     this.importBeanNameGenerator = new AnnotationBeanNameGenerator()
/*     */     {
/*     */       protected String buildDefaultBeanName(BeanDefinition definition) {
/* 128 */         return definition.getBeanClassName();
/*     */       }
/*     */     };
/*     */   }
/*     */ 
/*     */   public void setSourceExtractor(SourceExtractor sourceExtractor)
/*     */   {
/* 138 */     this.sourceExtractor = (sourceExtractor != null ? sourceExtractor : new PassThroughSourceExtractor());
/*     */   }
/*     */ 
/*     */   public void setProblemReporter(ProblemReporter problemReporter)
/*     */   {
/* 148 */     this.problemReporter = (problemReporter != null ? problemReporter : new FailFastProblemReporter());
/*     */   }
/*     */ 
/*     */   public void setMetadataReaderFactory(MetadataReaderFactory metadataReaderFactory)
/*     */   {
/* 157 */     Assert.notNull(metadataReaderFactory, "MetadataReaderFactory must not be null");
/* 158 */     this.metadataReaderFactory = metadataReaderFactory;
/* 159 */     this.setMetadataReaderFactoryCalled = true;
/*     */   }
/*     */ 
/*     */   public void setBeanNameGenerator(BeanNameGenerator beanNameGenerator)
/*     */   {
/* 180 */     Assert.notNull(beanNameGenerator, "BeanNameGenerator must not be null");
/* 181 */     this.localBeanNameGeneratorSet = true;
/* 182 */     this.componentScanBeanNameGenerator = beanNameGenerator;
/* 183 */     this.importBeanNameGenerator = beanNameGenerator;
/*     */   }
/*     */ 
/*     */   public void setEnvironment(Environment environment) {
/* 187 */     Assert.notNull(environment, "Environment must not be null");
/* 188 */     this.environment = environment;
/*     */   }
/*     */ 
/*     */   public void setResourceLoader(ResourceLoader resourceLoader) {
/* 192 */     Assert.notNull(resourceLoader, "ResourceLoader must not be null");
/* 193 */     this.resourceLoader = resourceLoader;
/*     */   }
/*     */ 
/*     */   public void setBeanClassLoader(ClassLoader beanClassLoader) {
/* 197 */     this.beanClassLoader = beanClassLoader;
/* 198 */     if (!this.setMetadataReaderFactoryCalled)
/* 199 */       this.metadataReaderFactory = new CachingMetadataReaderFactory(beanClassLoader);
/*     */   }
/*     */ 
/*     */   public void postProcessBeanDefinitionRegistry(BeanDefinitionRegistry registry)
/*     */   {
/* 208 */     RootBeanDefinition iabpp = new RootBeanDefinition(ImportAwareBeanPostProcessor.class);
/* 209 */     iabpp.setRole(2);
/* 210 */     registry.registerBeanDefinition(IMPORT_AWARE_PROCESSOR_BEAN_NAME, iabpp);
/*     */ 
/* 212 */     int registryId = System.identityHashCode(registry);
/* 213 */     if (this.registriesPostProcessed.contains(Integer.valueOf(registryId))) {
/* 214 */       throw new IllegalStateException("postProcessBeanDefinitionRegistry already called for this post-processor against " + registry);
/*     */     }
/*     */ 
/* 217 */     if (this.factoriesPostProcessed.contains(Integer.valueOf(registryId))) {
/* 218 */       throw new IllegalStateException("postProcessBeanFactory already called for this post-processor against " + registry);
/*     */     }
/*     */ 
/* 221 */     this.registriesPostProcessed.add(Integer.valueOf(registryId));
/*     */ 
/* 223 */     processConfigBeanDefinitions(registry);
/*     */   }
/*     */ 
/*     */   public void postProcessBeanFactory(ConfigurableListableBeanFactory beanFactory)
/*     */   {
/* 231 */     int factoryId = System.identityHashCode(beanFactory);
/* 232 */     if (this.factoriesPostProcessed.contains(Integer.valueOf(factoryId))) {
/* 233 */       throw new IllegalStateException("postProcessBeanFactory already called for this post-processor against " + beanFactory);
/*     */     }
/*     */ 
/* 236 */     this.factoriesPostProcessed.add(Integer.valueOf(factoryId));
/* 237 */     if (!this.registriesPostProcessed.contains(Integer.valueOf(factoryId)))
/*     */     {
/* 240 */       processConfigBeanDefinitions((BeanDefinitionRegistry)beanFactory);
/*     */     }
/* 242 */     enhanceConfigurationClasses(beanFactory);
/*     */   }
/*     */ 
/*     */   public void processConfigBeanDefinitions(BeanDefinitionRegistry registry)
/*     */   {
/* 250 */     Set configCandidates = new LinkedHashSet();
/* 251 */     for (String beanName : registry.getBeanDefinitionNames()) {
/* 252 */       BeanDefinition beanDef = registry.getBeanDefinition(beanName);
/* 253 */       if (ConfigurationClassUtils.checkConfigurationClassCandidate(beanDef, this.metadataReaderFactory)) {
/* 254 */         configCandidates.add(new BeanDefinitionHolder(beanDef, beanName));
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 259 */     if (configCandidates.isEmpty()) {
/* 260 */       return;
/*     */     }
/*     */ 
/* 264 */     SingletonBeanRegistry singletonRegistry = null;
/* 265 */     if ((registry instanceof SingletonBeanRegistry)) {
/* 266 */       singletonRegistry = (SingletonBeanRegistry)registry;
/* 267 */       if ((!this.localBeanNameGeneratorSet) && (singletonRegistry.containsSingleton("org.springframework.context.annotation.internalConfigurationBeanNameGenerator"))) {
/* 268 */         BeanNameGenerator generator = (BeanNameGenerator)singletonRegistry.getSingleton("org.springframework.context.annotation.internalConfigurationBeanNameGenerator");
/* 269 */         this.componentScanBeanNameGenerator = generator;
/* 270 */         this.importBeanNameGenerator = generator;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 275 */     ConfigurationClassParser parser = new ConfigurationClassParser(this.metadataReaderFactory, this.problemReporter, this.environment, this.resourceLoader, this.componentScanBeanNameGenerator, registry);
/*     */ 
/* 278 */     for (BeanDefinitionHolder holder : configCandidates) {
/* 279 */       BeanDefinition bd = holder.getBeanDefinition();
/*     */       try {
/* 281 */         if (((bd instanceof AbstractBeanDefinition)) && (((AbstractBeanDefinition)bd).hasBeanClass())) {
/* 282 */           parser.parse(((AbstractBeanDefinition)bd).getBeanClass(), holder.getBeanName());
/*     */         }
/*     */         else
/* 285 */           parser.parse(bd.getBeanClassName(), holder.getBeanName());
/*     */       }
/*     */       catch (IOException ex)
/*     */       {
/* 289 */         throw new BeanDefinitionStoreException("Failed to load bean class: " + bd.getBeanClassName(), ex);
/*     */       }
/*     */     }
/* 292 */     parser.validate();
/*     */ 
/* 295 */     Stack parsedPropertySources = parser.getPropertySources();
/* 296 */     if (!parsedPropertySources.isEmpty()) {
/* 297 */       if (!(this.environment instanceof ConfigurableEnvironment)) {
/* 298 */         this.logger.warn("Ignoring @PropertySource annotations. Reason: Environment must implement ConfigurableEnvironment");
/*     */       }
/*     */       else
/*     */       {
/* 302 */         MutablePropertySources envPropertySources = ((ConfigurableEnvironment)this.environment).getPropertySources();
/* 303 */         while (!parsedPropertySources.isEmpty()) {
/* 304 */           envPropertySources.addLast((PropertySource)parsedPropertySources.pop());
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 310 */     if (this.reader == null) {
/* 311 */       this.reader = new ConfigurationClassBeanDefinitionReader(registry, this.sourceExtractor, this.problemReporter, this.metadataReaderFactory, this.resourceLoader, this.environment, this.importBeanNameGenerator);
/*     */     }
/*     */ 
/* 315 */     this.reader.loadBeanDefinitions(parser.getConfigurationClasses());
/*     */ 
/* 318 */     if ((singletonRegistry != null) && 
/* 319 */       (!singletonRegistry.containsSingleton(IMPORT_REGISTRY_BEAN_NAME))) {
/* 320 */       singletonRegistry.registerSingleton(IMPORT_REGISTRY_BEAN_NAME, parser.getImportRegistry());
/*     */     }
/*     */ 
/* 324 */     if ((this.metadataReaderFactory instanceof CachingMetadataReaderFactory))
/* 325 */       ((CachingMetadataReaderFactory)this.metadataReaderFactory).clearCache();
/*     */   }
/*     */ 
/*     */   public void enhanceConfigurationClasses(ConfigurableListableBeanFactory beanFactory)
/*     */   {
/* 336 */     Map configBeanDefs = new LinkedHashMap();
/* 337 */     for (String beanName : beanFactory.getBeanDefinitionNames()) {
/* 338 */       BeanDefinition beanDef = beanFactory.getBeanDefinition(beanName);
/* 339 */       if (ConfigurationClassUtils.isFullConfigurationClass(beanDef)) {
/* 340 */         if (!(beanDef instanceof AbstractBeanDefinition)) {
/* 341 */           throw new BeanDefinitionStoreException("Cannot enhance @Configuration bean definition '" + beanName + "' since it is not stored in an AbstractBeanDefinition subclass");
/*     */         }
/*     */ 
/* 344 */         configBeanDefs.put(beanName, (AbstractBeanDefinition)beanDef);
/*     */       }
/*     */     }
/* 347 */     if (configBeanDefs.isEmpty())
/*     */     {
/* 349 */       return;
/*     */     }
/* 351 */     ConfigurationClassEnhancer enhancer = new ConfigurationClassEnhancer(beanFactory);
/* 352 */     for (Map.Entry entry : configBeanDefs.entrySet()) {
/* 353 */       AbstractBeanDefinition beanDef = (AbstractBeanDefinition)entry.getValue();
/*     */       try {
/* 355 */         Class configClass = beanDef.resolveBeanClass(this.beanClassLoader);
/* 356 */         Class enhancedClass = enhancer.enhance(configClass);
/* 357 */         if (configClass != enhancedClass) {
/* 358 */           if (this.logger.isDebugEnabled()) {
/* 359 */             this.logger.debug(String.format("Replacing bean definition '%s' existing class name '%s' with enhanced class name '%s'", new Object[] { entry.getKey(), configClass.getName(), enhancedClass.getName() }));
/*     */           }
/*     */ 
/* 362 */           beanDef.setBeanClass(enhancedClass);
/*     */         }
/*     */       }
/*     */       catch (Throwable ex) {
/* 366 */         throw new IllegalStateException("Cannot load configuration class: " + beanDef.getBeanClassName(), ex);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public int getOrder()
/*     */   {
/* 373 */     return -2147483648;
/*     */   }
/*     */ 
/*     */   private static class ImportAwareBeanPostProcessor implements PriorityOrdered, BeanFactoryAware, BeanPostProcessor
/*     */   {
/*     */     private BeanFactory beanFactory;
/*     */ 
/*     */     public void setBeanFactory(BeanFactory beanFactory) throws BeansException {
/* 382 */       this.beanFactory = beanFactory;
/*     */     }
/*     */ 
/*     */     public Object postProcessBeforeInitialization(Object bean, String beanName) throws BeansException {
/* 386 */       if ((bean instanceof ImportAware)) {
/* 387 */         ConfigurationClassParser.ImportRegistry importRegistry = (ConfigurationClassParser.ImportRegistry)this.beanFactory.getBean(ConfigurationClassPostProcessor.IMPORT_REGISTRY_BEAN_NAME, ConfigurationClassParser.ImportRegistry.class);
/* 388 */         String importingClass = importRegistry.getImportingClassFor(bean.getClass().getSuperclass().getName());
/* 389 */         if (importingClass != null) {
/*     */           try {
/* 391 */             AnnotationMetadata metadata = new SimpleMetadataReaderFactory().getMetadataReader(importingClass).getAnnotationMetadata();
/*     */ 
/* 393 */             ((ImportAware)bean).setImportMetadata(metadata);
/*     */           }
/*     */           catch (IOException ex)
/*     */           {
/* 397 */             throw new IllegalStateException(ex);
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 404 */       return bean;
/*     */     }
/*     */ 
/*     */     public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException {
/* 408 */       return bean;
/*     */     }
/*     */ 
/*     */     public int getOrder() {
/* 412 */       return -2147483648;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.context.annotation.ConfigurationClassPostProcessor
 * JD-Core Version:    0.6.0
 */