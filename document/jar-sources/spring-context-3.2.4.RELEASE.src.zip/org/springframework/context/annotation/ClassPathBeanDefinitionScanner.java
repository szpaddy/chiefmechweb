/*     */ package org.springframework.context.annotation;
/*     */ 
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import org.springframework.beans.factory.annotation.AnnotatedBeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanDefinitionHolder;
/*     */ import org.springframework.beans.factory.support.AbstractBeanDefinition;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionDefaults;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionReaderUtils;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.beans.factory.support.BeanNameGenerator;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.env.EnvironmentCapable;
/*     */ import org.springframework.core.env.StandardEnvironment;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.PatternMatchUtils;
/*     */ 
/*     */ public class ClassPathBeanDefinitionScanner extends ClassPathScanningCandidateComponentProvider
/*     */ {
/*     */   private final BeanDefinitionRegistry registry;
/*  66 */   private BeanDefinitionDefaults beanDefinitionDefaults = new BeanDefinitionDefaults();
/*     */   private String[] autowireCandidatePatterns;
/*  70 */   private BeanNameGenerator beanNameGenerator = new AnnotationBeanNameGenerator();
/*     */ 
/*  72 */   private ScopeMetadataResolver scopeMetadataResolver = new AnnotationScopeMetadataResolver();
/*     */ 
/*  74 */   private boolean includeAnnotationConfig = true;
/*     */ 
/*     */   public ClassPathBeanDefinitionScanner(BeanDefinitionRegistry registry)
/*     */   {
/*  83 */     this(registry, true);
/*     */   }
/*     */ 
/*     */   public ClassPathBeanDefinitionScanner(BeanDefinitionRegistry registry, boolean useDefaultFilters)
/*     */   {
/* 112 */     this(registry, useDefaultFilters, getOrCreateEnvironment(registry));
/*     */   }
/*     */ 
/*     */   public ClassPathBeanDefinitionScanner(BeanDefinitionRegistry registry, boolean useDefaultFilters, Environment environment)
/*     */   {
/* 138 */     super(useDefaultFilters, environment);
/*     */ 
/* 140 */     Assert.notNull(registry, "BeanDefinitionRegistry must not be null");
/* 141 */     this.registry = registry;
/*     */ 
/* 144 */     if ((this.registry instanceof ResourceLoader))
/* 145 */       setResourceLoader((ResourceLoader)this.registry);
/*     */   }
/*     */ 
/*     */   public final BeanDefinitionRegistry getRegistry()
/*     */   {
/* 154 */     return this.registry;
/*     */   }
/*     */ 
/*     */   public void setBeanDefinitionDefaults(BeanDefinitionDefaults beanDefinitionDefaults)
/*     */   {
/* 162 */     this.beanDefinitionDefaults = (beanDefinitionDefaults != null ? beanDefinitionDefaults : new BeanDefinitionDefaults());
/*     */   }
/*     */ 
/*     */   public void setAutowireCandidatePatterns(String[] autowireCandidatePatterns)
/*     */   {
/* 171 */     this.autowireCandidatePatterns = autowireCandidatePatterns;
/*     */   }
/*     */ 
/*     */   public void setBeanNameGenerator(BeanNameGenerator beanNameGenerator)
/*     */   {
/* 179 */     this.beanNameGenerator = (beanNameGenerator != null ? beanNameGenerator : new AnnotationBeanNameGenerator());
/*     */   }
/*     */ 
/*     */   public void setScopeMetadataResolver(ScopeMetadataResolver scopeMetadataResolver)
/*     */   {
/* 189 */     this.scopeMetadataResolver = (scopeMetadataResolver != null ? scopeMetadataResolver : new AnnotationScopeMetadataResolver());
/*     */   }
/*     */ 
/*     */   public void setScopedProxyMode(ScopedProxyMode scopedProxyMode)
/*     */   {
/* 199 */     this.scopeMetadataResolver = new AnnotationScopeMetadataResolver(scopedProxyMode);
/*     */   }
/*     */ 
/*     */   public void setIncludeAnnotationConfig(boolean includeAnnotationConfig)
/*     */   {
/* 208 */     this.includeAnnotationConfig = includeAnnotationConfig;
/*     */   }
/*     */ 
/*     */   public int scan(String[] basePackages)
/*     */   {
/* 218 */     int beanCountAtScanStart = this.registry.getBeanDefinitionCount();
/*     */ 
/* 220 */     doScan(basePackages);
/*     */ 
/* 223 */     if (this.includeAnnotationConfig) {
/* 224 */       AnnotationConfigUtils.registerAnnotationConfigProcessors(this.registry);
/*     */     }
/*     */ 
/* 227 */     return this.registry.getBeanDefinitionCount() - beanCountAtScanStart;
/*     */   }
/*     */ 
/*     */   protected Set<BeanDefinitionHolder> doScan(String[] basePackages)
/*     */   {
/* 239 */     Assert.notEmpty(basePackages, "At least one base package must be specified");
/* 240 */     Set beanDefinitions = new LinkedHashSet();
/* 241 */     for (String basePackage : basePackages) {
/* 242 */       Set candidates = findCandidateComponents(basePackage);
/* 243 */       for (BeanDefinition candidate : candidates) {
/* 244 */         ScopeMetadata scopeMetadata = this.scopeMetadataResolver.resolveScopeMetadata(candidate);
/* 245 */         candidate.setScope(scopeMetadata.getScopeName());
/* 246 */         String beanName = this.beanNameGenerator.generateBeanName(candidate, this.registry);
/* 247 */         if ((candidate instanceof AbstractBeanDefinition)) {
/* 248 */           postProcessBeanDefinition((AbstractBeanDefinition)candidate, beanName);
/*     */         }
/* 250 */         if ((candidate instanceof AnnotatedBeanDefinition)) {
/* 251 */           AnnotationConfigUtils.processCommonDefinitionAnnotations((AnnotatedBeanDefinition)candidate);
/*     */         }
/* 253 */         if (checkCandidate(beanName, candidate)) {
/* 254 */           BeanDefinitionHolder definitionHolder = new BeanDefinitionHolder(candidate, beanName);
/* 255 */           definitionHolder = AnnotationConfigUtils.applyScopedProxyMode(scopeMetadata, definitionHolder, this.registry);
/* 256 */           beanDefinitions.add(definitionHolder);
/* 257 */           registerBeanDefinition(definitionHolder, this.registry);
/*     */         }
/*     */       }
/*     */     }
/* 261 */     return beanDefinitions;
/*     */   }
/*     */ 
/*     */   protected void postProcessBeanDefinition(AbstractBeanDefinition beanDefinition, String beanName)
/*     */   {
/* 271 */     beanDefinition.applyDefaults(this.beanDefinitionDefaults);
/* 272 */     if (this.autowireCandidatePatterns != null)
/* 273 */       beanDefinition.setAutowireCandidate(PatternMatchUtils.simpleMatch(this.autowireCandidatePatterns, beanName));
/*     */   }
/*     */ 
/*     */   protected void registerBeanDefinition(BeanDefinitionHolder definitionHolder, BeanDefinitionRegistry registry)
/*     */   {
/* 285 */     BeanDefinitionReaderUtils.registerBeanDefinition(definitionHolder, registry);
/*     */   }
/*     */ 
/*     */   protected boolean checkCandidate(String beanName, BeanDefinition beanDefinition)
/*     */     throws IllegalStateException
/*     */   {
/* 301 */     if (!this.registry.containsBeanDefinition(beanName)) {
/* 302 */       return true;
/*     */     }
/* 304 */     BeanDefinition existingDef = this.registry.getBeanDefinition(beanName);
/* 305 */     BeanDefinition originatingDef = existingDef.getOriginatingBeanDefinition();
/* 306 */     if (originatingDef != null) {
/* 307 */       existingDef = originatingDef;
/*     */     }
/* 309 */     if (isCompatible(beanDefinition, existingDef)) {
/* 310 */       return false;
/*     */     }
/* 312 */     throw new ConflictingBeanDefinitionException("Annotation-specified bean name '" + beanName + "' for bean class [" + beanDefinition.getBeanClassName() + "] conflicts with existing, " + "non-compatible bean definition of same name and class [" + existingDef.getBeanClassName() + "]");
/*     */   }
/*     */ 
/*     */   protected boolean isCompatible(BeanDefinition newDefinition, BeanDefinition existingDefinition)
/*     */   {
/* 329 */     return (!(existingDefinition instanceof ScannedGenericBeanDefinition)) || (newDefinition.getSource().equals(existingDefinition.getSource())) || (newDefinition.equals(existingDefinition));
/*     */   }
/*     */ 
/*     */   private static Environment getOrCreateEnvironment(BeanDefinitionRegistry registry)
/*     */   {
/* 340 */     Assert.notNull(registry, "BeanDefinitionRegistry must not be null");
/* 341 */     if ((registry instanceof EnvironmentCapable)) {
/* 342 */       return ((EnvironmentCapable)registry).getEnvironment();
/*     */     }
/* 344 */     return new StandardEnvironment();
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.context.annotation.ClassPathBeanDefinitionScanner
 * JD-Core Version:    0.6.0
 */