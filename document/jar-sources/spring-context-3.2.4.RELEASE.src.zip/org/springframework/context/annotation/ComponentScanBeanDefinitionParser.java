/*     */ package org.springframework.context.annotation;
/*     */ 
/*     */ import java.util.Set;
/*     */ import java.util.regex.Pattern;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.FatalBeanException;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanDefinitionHolder;
/*     */ import org.springframework.beans.factory.parsing.BeanComponentDefinition;
/*     */ import org.springframework.beans.factory.parsing.CompositeComponentDefinition;
/*     */ import org.springframework.beans.factory.support.BeanNameGenerator;
/*     */ import org.springframework.beans.factory.xml.BeanDefinitionParser;
/*     */ import org.springframework.beans.factory.xml.BeanDefinitionParserDelegate;
/*     */ import org.springframework.beans.factory.xml.ParserContext;
/*     */ import org.springframework.beans.factory.xml.XmlReaderContext;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.core.type.filter.AnnotationTypeFilter;
/*     */ import org.springframework.core.type.filter.AspectJTypeFilter;
/*     */ import org.springframework.core.type.filter.AssignableTypeFilter;
/*     */ import org.springframework.core.type.filter.RegexPatternTypeFilter;
/*     */ import org.springframework.core.type.filter.TypeFilter;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ 
/*     */ public class ComponentScanBeanDefinitionParser
/*     */   implements BeanDefinitionParser
/*     */ {
/*     */   private static final String BASE_PACKAGE_ATTRIBUTE = "base-package";
/*     */   private static final String RESOURCE_PATTERN_ATTRIBUTE = "resource-pattern";
/*     */   private static final String USE_DEFAULT_FILTERS_ATTRIBUTE = "use-default-filters";
/*     */   private static final String ANNOTATION_CONFIG_ATTRIBUTE = "annotation-config";
/*     */   private static final String NAME_GENERATOR_ATTRIBUTE = "name-generator";
/*     */   private static final String SCOPE_RESOLVER_ATTRIBUTE = "scope-resolver";
/*     */   private static final String SCOPED_PROXY_ATTRIBUTE = "scoped-proxy";
/*     */   private static final String EXCLUDE_FILTER_ELEMENT = "exclude-filter";
/*     */   private static final String INCLUDE_FILTER_ELEMENT = "include-filter";
/*     */   private static final String FILTER_TYPE_ATTRIBUTE = "type";
/*     */   private static final String FILTER_EXPRESSION_ATTRIBUTE = "expression";
/*     */ 
/*     */   public BeanDefinition parse(Element element, ParserContext parserContext)
/*     */   {
/*  79 */     String[] basePackages = StringUtils.tokenizeToStringArray(element.getAttribute("base-package"), ",; \t\n");
/*     */ 
/*  83 */     ClassPathBeanDefinitionScanner scanner = configureScanner(parserContext, element);
/*  84 */     Set beanDefinitions = scanner.doScan(basePackages);
/*  85 */     registerComponents(parserContext.getReaderContext(), beanDefinitions, element);
/*     */ 
/*  87 */     return null;
/*     */   }
/*     */ 
/*     */   protected ClassPathBeanDefinitionScanner configureScanner(ParserContext parserContext, Element element) {
/*  91 */     XmlReaderContext readerContext = parserContext.getReaderContext();
/*     */ 
/*  93 */     boolean useDefaultFilters = true;
/*  94 */     if (element.hasAttribute("use-default-filters")) {
/*  95 */       useDefaultFilters = Boolean.valueOf(element.getAttribute("use-default-filters")).booleanValue();
/*     */     }
/*     */ 
/*  99 */     ClassPathBeanDefinitionScanner scanner = createScanner(readerContext, useDefaultFilters);
/* 100 */     scanner.setResourceLoader(readerContext.getResourceLoader());
/* 101 */     scanner.setEnvironment(parserContext.getDelegate().getEnvironment());
/* 102 */     scanner.setBeanDefinitionDefaults(parserContext.getDelegate().getBeanDefinitionDefaults());
/* 103 */     scanner.setAutowireCandidatePatterns(parserContext.getDelegate().getAutowireCandidatePatterns());
/*     */ 
/* 105 */     if (element.hasAttribute("resource-pattern")) {
/* 106 */       scanner.setResourcePattern(element.getAttribute("resource-pattern"));
/*     */     }
/*     */     try
/*     */     {
/* 110 */       parseBeanNameGenerator(element, scanner);
/*     */     }
/*     */     catch (Exception ex) {
/* 113 */       readerContext.error(ex.getMessage(), readerContext.extractSource(element), ex.getCause());
/*     */     }
/*     */     try
/*     */     {
/* 117 */       parseScope(element, scanner);
/*     */     }
/*     */     catch (Exception ex) {
/* 120 */       readerContext.error(ex.getMessage(), readerContext.extractSource(element), ex.getCause());
/*     */     }
/*     */ 
/* 123 */     parseTypeFilters(element, scanner, readerContext, parserContext);
/*     */ 
/* 125 */     return scanner;
/*     */   }
/*     */ 
/*     */   protected ClassPathBeanDefinitionScanner createScanner(XmlReaderContext readerContext, boolean useDefaultFilters) {
/* 129 */     return new ClassPathBeanDefinitionScanner(readerContext.getRegistry(), useDefaultFilters);
/*     */   }
/*     */ 
/*     */   protected void registerComponents(XmlReaderContext readerContext, Set<BeanDefinitionHolder> beanDefinitions, Element element)
/*     */   {
/* 135 */     Object source = readerContext.extractSource(element);
/* 136 */     CompositeComponentDefinition compositeDef = new CompositeComponentDefinition(element.getTagName(), source);
/*     */ 
/* 138 */     for (BeanDefinitionHolder beanDefHolder : beanDefinitions) {
/* 139 */       compositeDef.addNestedComponent(new BeanComponentDefinition(beanDefHolder));
/*     */     }
/*     */ 
/* 143 */     boolean annotationConfig = true;
/* 144 */     if (element.hasAttribute("annotation-config")) {
/* 145 */       annotationConfig = Boolean.valueOf(element.getAttribute("annotation-config")).booleanValue();
/*     */     }
/* 147 */     if (annotationConfig) {
/* 148 */       Set processorDefinitions = AnnotationConfigUtils.registerAnnotationConfigProcessors(readerContext.getRegistry(), source);
/*     */ 
/* 150 */       for (BeanDefinitionHolder processorDefinition : processorDefinitions) {
/* 151 */         compositeDef.addNestedComponent(new BeanComponentDefinition(processorDefinition));
/*     */       }
/*     */     }
/*     */ 
/* 155 */     readerContext.fireComponentRegistered(compositeDef);
/*     */   }
/*     */ 
/*     */   protected void parseBeanNameGenerator(Element element, ClassPathBeanDefinitionScanner scanner) {
/* 159 */     if (element.hasAttribute("name-generator")) {
/* 160 */       BeanNameGenerator beanNameGenerator = (BeanNameGenerator)instantiateUserDefinedStrategy(element.getAttribute("name-generator"), BeanNameGenerator.class, scanner.getResourceLoader().getClassLoader());
/*     */ 
/* 163 */       scanner.setBeanNameGenerator(beanNameGenerator);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void parseScope(Element element, ClassPathBeanDefinitionScanner scanner)
/*     */   {
/* 169 */     if (element.hasAttribute("scope-resolver")) {
/* 170 */       if (element.hasAttribute("scoped-proxy")) {
/* 171 */         throw new IllegalArgumentException("Cannot define both 'scope-resolver' and 'scoped-proxy' on <component-scan> tag");
/*     */       }
/*     */ 
/* 174 */       ScopeMetadataResolver scopeMetadataResolver = (ScopeMetadataResolver)instantiateUserDefinedStrategy(element.getAttribute("scope-resolver"), ScopeMetadataResolver.class, scanner.getResourceLoader().getClassLoader());
/*     */ 
/* 177 */       scanner.setScopeMetadataResolver(scopeMetadataResolver);
/*     */     }
/*     */ 
/* 180 */     if (element.hasAttribute("scoped-proxy")) {
/* 181 */       String mode = element.getAttribute("scoped-proxy");
/* 182 */       if ("targetClass".equals(mode)) {
/* 183 */         scanner.setScopedProxyMode(ScopedProxyMode.TARGET_CLASS);
/*     */       }
/* 185 */       else if ("interfaces".equals(mode)) {
/* 186 */         scanner.setScopedProxyMode(ScopedProxyMode.INTERFACES);
/*     */       }
/* 188 */       else if ("no".equals(mode)) {
/* 189 */         scanner.setScopedProxyMode(ScopedProxyMode.NO);
/*     */       }
/*     */       else
/* 192 */         throw new IllegalArgumentException("scoped-proxy only supports 'no', 'interfaces' and 'targetClass'");
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void parseTypeFilters(Element element, ClassPathBeanDefinitionScanner scanner, XmlReaderContext readerContext, ParserContext parserContext)
/*     */   {
/* 201 */     ClassLoader classLoader = scanner.getResourceLoader().getClassLoader();
/* 202 */     NodeList nodeList = element.getChildNodes();
/* 203 */     for (int i = 0; i < nodeList.getLength(); i++) {
/* 204 */       Node node = nodeList.item(i);
/* 205 */       if (node.getNodeType() == 1) {
/* 206 */         String localName = parserContext.getDelegate().getLocalName(node);
/*     */         try {
/* 208 */           if ("include-filter".equals(localName)) {
/* 209 */             TypeFilter typeFilter = createTypeFilter((Element)node, classLoader);
/* 210 */             scanner.addIncludeFilter(typeFilter);
/*     */           }
/* 212 */           else if ("exclude-filter".equals(localName)) {
/* 213 */             TypeFilter typeFilter = createTypeFilter((Element)node, classLoader);
/* 214 */             scanner.addExcludeFilter(typeFilter);
/*     */           }
/*     */         }
/*     */         catch (Exception ex) {
/* 218 */           readerContext.error(ex.getMessage(), readerContext.extractSource(element), ex.getCause());
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   protected TypeFilter createTypeFilter(Element element, ClassLoader classLoader)
/*     */   {
/* 226 */     String filterType = element.getAttribute("type");
/* 227 */     String expression = element.getAttribute("expression");
/*     */     try {
/* 229 */       if ("annotation".equals(filterType)) {
/* 230 */         return new AnnotationTypeFilter(classLoader.loadClass(expression));
/*     */       }
/* 232 */       if ("assignable".equals(filterType)) {
/* 233 */         return new AssignableTypeFilter(classLoader.loadClass(expression));
/*     */       }
/* 235 */       if ("aspectj".equals(filterType)) {
/* 236 */         return new AspectJTypeFilter(expression, classLoader);
/*     */       }
/* 238 */       if ("regex".equals(filterType)) {
/* 239 */         return new RegexPatternTypeFilter(Pattern.compile(expression));
/*     */       }
/* 241 */       if ("custom".equals(filterType)) {
/* 242 */         Class filterClass = classLoader.loadClass(expression);
/* 243 */         if (!TypeFilter.class.isAssignableFrom(filterClass)) {
/* 244 */           throw new IllegalArgumentException("Class is not assignable to [" + TypeFilter.class.getName() + "]: " + expression);
/*     */         }
/*     */ 
/* 247 */         return (TypeFilter)BeanUtils.instantiateClass(filterClass);
/*     */       }
/*     */ 
/* 250 */       throw new IllegalArgumentException("Unsupported filter type: " + filterType);
/*     */     }
/*     */     catch (ClassNotFoundException ex) {
/*     */     }
/* 254 */     throw new FatalBeanException("Type filter class not found: " + expression, ex);
/*     */   }
/*     */ 
/*     */   private Object instantiateUserDefinedStrategy(String className, Class strategyType, ClassLoader classLoader)
/*     */   {
/* 260 */     Object result = null;
/*     */     try {
/* 262 */       result = classLoader.loadClass(className).newInstance();
/*     */     }
/*     */     catch (ClassNotFoundException ex) {
/* 265 */       throw new IllegalArgumentException("Class [" + className + "] for strategy [" + strategyType.getName() + "] not found", ex);
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/* 269 */       throw new IllegalArgumentException("Unable to instantiate class [" + className + "] for strategy [" + strategyType.getName() + "]. A zero-argument constructor is required", ex);
/*     */     }
/*     */ 
/* 273 */     if (!strategyType.isAssignableFrom(result.getClass())) {
/* 274 */       throw new IllegalArgumentException("Provided class name must be an implementation of " + strategyType);
/*     */     }
/* 276 */     return result;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.context.annotation.ComponentScanBeanDefinitionParser
 * JD-Core Version:    0.6.0
 */