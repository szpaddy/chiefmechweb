/*     */ package org.springframework.context.annotation;
/*     */ 
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import org.springframework.beans.factory.annotation.AnnotatedBeanDefinition;
/*     */ import org.springframework.beans.factory.annotation.AutowiredAnnotationBeanPostProcessor;
/*     */ import org.springframework.beans.factory.annotation.RequiredAnnotationBeanPostProcessor;
/*     */ import org.springframework.beans.factory.config.BeanDefinitionHolder;
/*     */ import org.springframework.beans.factory.support.AbstractBeanDefinition;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ import org.springframework.core.annotation.AnnotationAttributes;
/*     */ import org.springframework.core.type.AnnotationMetadata;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ public class AnnotationConfigUtils
/*     */ {
/*     */   public static final String CONFIGURATION_ANNOTATION_PROCESSOR_BEAN_NAME = "org.springframework.context.annotation.internalConfigurationAnnotationProcessor";
/*     */   public static final String CONFIGURATION_BEAN_NAME_GENERATOR = "org.springframework.context.annotation.internalConfigurationBeanNameGenerator";
/*     */   public static final String AUTOWIRED_ANNOTATION_PROCESSOR_BEAN_NAME = "org.springframework.context.annotation.internalAutowiredAnnotationProcessor";
/*     */   public static final String REQUIRED_ANNOTATION_PROCESSOR_BEAN_NAME = "org.springframework.context.annotation.internalRequiredAnnotationProcessor";
/*     */   public static final String COMMON_ANNOTATION_PROCESSOR_BEAN_NAME = "org.springframework.context.annotation.internalCommonAnnotationProcessor";
/*     */   public static final String SCHEDULED_ANNOTATION_PROCESSOR_BEAN_NAME = "org.springframework.context.annotation.internalScheduledAnnotationProcessor";
/*     */   public static final String ASYNC_ANNOTATION_PROCESSOR_BEAN_NAME = "org.springframework.context.annotation.internalAsyncAnnotationProcessor";
/*     */   public static final String ASYNC_EXECUTION_ASPECT_BEAN_NAME = "org.springframework.scheduling.config.internalAsyncExecutionAspect";
/*     */   public static final String ASYNC_EXECUTION_ASPECT_CLASS_NAME = "org.springframework.scheduling.aspectj.AnnotationAsyncExecutionAspect";
/*     */   public static final String ASYNC_EXECUTION_ASPECT_CONFIGURATION_CLASS_NAME = "org.springframework.scheduling.aspectj.AspectJAsyncConfiguration";
/*     */   public static final String CACHE_ADVISOR_BEAN_NAME = "org.springframework.cache.config.internalCacheAdvisor";
/*     */   public static final String CACHE_ASPECT_BEAN_NAME = "org.springframework.cache.config.internalCacheAspect";
/*     */   public static final String CACHE_ASPECT_CLASS_NAME = "org.springframework.cache.aspectj.AnnotationCacheAspect";
/*     */   public static final String CACHE_ASPECT_CONFIGURATION_CLASS_NAME = "org.springframework.cache.aspectj.AspectJCachingConfiguration";
/*     */   public static final String PERSISTENCE_ANNOTATION_PROCESSOR_BEAN_NAME = "org.springframework.context.annotation.internalPersistenceAnnotationProcessor";
/*     */   private static final String PERSISTENCE_ANNOTATION_PROCESSOR_CLASS_NAME = "org.springframework.orm.jpa.support.PersistenceAnnotationBeanPostProcessor";
/* 153 */   private static final boolean jsr250Present = ClassUtils.isPresent("javax.annotation.Resource", AnnotationConfigUtils.class.getClassLoader());
/*     */ 
/* 156 */   private static final boolean jpaPresent = (ClassUtils.isPresent("javax.persistence.EntityManagerFactory", AnnotationConfigUtils.class.getClassLoader())) && (ClassUtils.isPresent("org.springframework.orm.jpa.support.PersistenceAnnotationBeanPostProcessor", AnnotationConfigUtils.class.getClassLoader()));
/*     */ 
/*     */   public static void registerAnnotationConfigProcessors(BeanDefinitionRegistry registry)
/*     */   {
/* 166 */     registerAnnotationConfigProcessors(registry, null);
/*     */   }
/*     */ 
/*     */   public static Set<BeanDefinitionHolder> registerAnnotationConfigProcessors(BeanDefinitionRegistry registry, Object source)
/*     */   {
/* 180 */     Set beanDefs = new LinkedHashSet(4);
/*     */ 
/* 182 */     if (!registry.containsBeanDefinition("org.springframework.context.annotation.internalConfigurationAnnotationProcessor")) {
/* 183 */       RootBeanDefinition def = new RootBeanDefinition(ConfigurationClassPostProcessor.class);
/* 184 */       def.setSource(source);
/* 185 */       beanDefs.add(registerPostProcessor(registry, def, "org.springframework.context.annotation.internalConfigurationAnnotationProcessor"));
/*     */     }
/*     */ 
/* 188 */     if (!registry.containsBeanDefinition("org.springframework.context.annotation.internalAutowiredAnnotationProcessor")) {
/* 189 */       RootBeanDefinition def = new RootBeanDefinition(AutowiredAnnotationBeanPostProcessor.class);
/* 190 */       def.setSource(source);
/* 191 */       beanDefs.add(registerPostProcessor(registry, def, "org.springframework.context.annotation.internalAutowiredAnnotationProcessor"));
/*     */     }
/*     */ 
/* 194 */     if (!registry.containsBeanDefinition("org.springframework.context.annotation.internalRequiredAnnotationProcessor")) {
/* 195 */       RootBeanDefinition def = new RootBeanDefinition(RequiredAnnotationBeanPostProcessor.class);
/* 196 */       def.setSource(source);
/* 197 */       beanDefs.add(registerPostProcessor(registry, def, "org.springframework.context.annotation.internalRequiredAnnotationProcessor"));
/*     */     }
/*     */ 
/* 201 */     if ((jsr250Present) && (!registry.containsBeanDefinition("org.springframework.context.annotation.internalCommonAnnotationProcessor"))) {
/* 202 */       RootBeanDefinition def = new RootBeanDefinition(CommonAnnotationBeanPostProcessor.class);
/* 203 */       def.setSource(source);
/* 204 */       beanDefs.add(registerPostProcessor(registry, def, "org.springframework.context.annotation.internalCommonAnnotationProcessor"));
/*     */     }
/*     */ 
/* 208 */     if ((jpaPresent) && (!registry.containsBeanDefinition("org.springframework.context.annotation.internalPersistenceAnnotationProcessor"))) {
/* 209 */       RootBeanDefinition def = new RootBeanDefinition();
/*     */       try {
/* 211 */         ClassLoader cl = AnnotationConfigUtils.class.getClassLoader();
/* 212 */         def.setBeanClass(cl.loadClass("org.springframework.orm.jpa.support.PersistenceAnnotationBeanPostProcessor"));
/*     */       }
/*     */       catch (ClassNotFoundException ex) {
/* 215 */         throw new IllegalStateException("Cannot load optional framework class: org.springframework.orm.jpa.support.PersistenceAnnotationBeanPostProcessor", ex);
/*     */       }
/*     */ 
/* 218 */       def.setSource(source);
/* 219 */       beanDefs.add(registerPostProcessor(registry, def, "org.springframework.context.annotation.internalPersistenceAnnotationProcessor"));
/*     */     }
/*     */ 
/* 222 */     return beanDefs;
/*     */   }
/*     */ 
/*     */   private static BeanDefinitionHolder registerPostProcessor(BeanDefinitionRegistry registry, RootBeanDefinition definition, String beanName)
/*     */   {
/* 228 */     definition.setRole(2);
/* 229 */     registry.registerBeanDefinition(beanName, definition);
/* 230 */     return new BeanDefinitionHolder(definition, beanName);
/*     */   }
/*     */ 
/*     */   static void processCommonDefinitionAnnotations(AnnotatedBeanDefinition abd) {
/* 234 */     AnnotationMetadata metadata = abd.getMetadata();
/* 235 */     if (metadata.isAnnotated(Primary.class.getName())) {
/* 236 */       abd.setPrimary(true);
/*     */     }
/* 238 */     if (metadata.isAnnotated(Lazy.class.getName())) {
/* 239 */       abd.setLazyInit(MetadataUtils.attributesFor(metadata, Lazy.class).getBoolean("value"));
/*     */     }
/* 241 */     if (metadata.isAnnotated(DependsOn.class.getName())) {
/* 242 */       abd.setDependsOn(MetadataUtils.attributesFor(metadata, DependsOn.class).getStringArray("value"));
/*     */     }
/* 244 */     if (((abd instanceof AbstractBeanDefinition)) && 
/* 245 */       (metadata.isAnnotated(Role.class.getName()))) {
/* 246 */       Integer role = (Integer)MetadataUtils.attributesFor(metadata, Role.class).getNumber("value");
/* 247 */       ((AbstractBeanDefinition)abd).setRole(role.intValue());
/*     */     }
/*     */   }
/*     */ 
/*     */   static BeanDefinitionHolder applyScopedProxyMode(ScopeMetadata metadata, BeanDefinitionHolder definition, BeanDefinitionRegistry registry)
/*     */   {
/* 255 */     ScopedProxyMode scopedProxyMode = metadata.getScopedProxyMode();
/* 256 */     if (scopedProxyMode.equals(ScopedProxyMode.NO)) {
/* 257 */       return definition;
/*     */     }
/* 259 */     boolean proxyTargetClass = scopedProxyMode.equals(ScopedProxyMode.TARGET_CLASS);
/* 260 */     return ScopedProxyCreator.createScopedProxy(definition, registry, proxyTargetClass);
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.context.annotation.AnnotationConfigUtils
 * JD-Core Version:    0.6.0
 */