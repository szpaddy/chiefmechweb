/*     */ package org.springframework.context.annotation;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Arrays;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.aop.scope.ScopedProxyFactoryBean;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.beans.factory.config.BeanFactoryPostProcessor;
/*     */ import org.springframework.beans.factory.config.ConfigurableBeanFactory;
/*     */ import org.springframework.beans.factory.support.SimpleInstantiationStrategy;
/*     */ import org.springframework.cglib.proxy.Callback;
/*     */ import org.springframework.cglib.proxy.CallbackFilter;
/*     */ import org.springframework.cglib.proxy.Enhancer;
/*     */ import org.springframework.cglib.proxy.MethodInterceptor;
/*     */ import org.springframework.cglib.proxy.MethodProxy;
/*     */ import org.springframework.cglib.proxy.NoOp;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ class ConfigurationClassEnhancer
/*     */ {
/*  53 */   private static final Log logger = LogFactory.getLog(ConfigurationClassEnhancer.class);
/*     */ 
/*  55 */   private static final CallbackFilter CALLBACK_FILTER = new ConfigurationClassCallbackFilter(null);
/*     */ 
/*  57 */   private static final Callback DISPOSABLE_BEAN_METHOD_INTERCEPTOR = new DisposableBeanMethodInterceptor(null);
/*     */ 
/*  59 */   private static final Class<?>[] CALLBACK_TYPES = { BeanMethodInterceptor.class, DisposableBeanMethodInterceptor.class, NoOp.class };
/*     */   private final Callback[] callbackInstances;
/*     */ 
/*     */   public ConfigurationClassEnhancer(ConfigurableBeanFactory beanFactory)
/*     */   {
/*  69 */     Assert.notNull(beanFactory, "BeanFactory must not be null");
/*     */ 
/*  71 */     this.callbackInstances = new Callback[] { new BeanMethodInterceptor(beanFactory), DISPOSABLE_BEAN_METHOD_INTERCEPTOR, NoOp.INSTANCE };
/*     */   }
/*     */ 
/*     */   public Class<?> enhance(Class<?> configClass)
/*     */   {
/*  81 */     if (EnhancedConfiguration.class.isAssignableFrom(configClass)) {
/*  82 */       if (logger.isDebugEnabled()) {
/*  83 */         logger.debug(String.format("Ignoring request to enhance %s as it has already been enhanced. This usually indicates that more than one ConfigurationClassPostProcessor has been registered (e.g. via <context:annotation-config>). This is harmless, but you may want check your configuration and remove one CCPP if possible", new Object[] { configClass.getName() }));
/*     */       }
/*     */ 
/*  90 */       return configClass;
/*     */     }
/*  92 */     Class enhancedClass = createClass(newEnhancer(configClass));
/*  93 */     if (logger.isDebugEnabled()) {
/*  94 */       logger.debug(String.format("Successfully enhanced %s; enhanced class name is: %s", new Object[] { configClass.getName(), enhancedClass.getName() }));
/*     */     }
/*     */ 
/*  97 */     return enhancedClass;
/*     */   }
/*     */ 
/*     */   private Enhancer newEnhancer(Class<?> superclass)
/*     */   {
/* 104 */     Enhancer enhancer = new Enhancer();
/* 105 */     enhancer.setSuperclass(superclass);
/* 106 */     enhancer.setInterfaces(new Class[] { EnhancedConfiguration.class });
/* 107 */     enhancer.setUseFactory(false);
/* 108 */     enhancer.setCallbackFilter(CALLBACK_FILTER);
/* 109 */     enhancer.setCallbackTypes(CALLBACK_TYPES);
/* 110 */     return enhancer;
/*     */   }
/*     */ 
/*     */   private Class<?> createClass(Enhancer enhancer)
/*     */   {
/* 118 */     Class subclass = enhancer.createClass();
/*     */ 
/* 120 */     Enhancer.registerStaticCallbacks(subclass, this.callbackInstances);
/* 121 */     return subclass;
/*     */   }
/*     */ 
/*     */   private static class BeanMethodInterceptor
/*     */     implements MethodInterceptor
/*     */   {
/* 219 */     private static final Class<?>[] CALLBACK_TYPES = { ConfigurationClassEnhancer.GetObjectMethodInterceptor.class, NoOp.class };
/*     */ 
/* 221 */     private static final CallbackFilter CALLBACK_FILTER = new CallbackFilter() {
/*     */       public int accept(Method method) {
/* 223 */         return method.getName().equals("getObject") ? 0 : 1;
/*     */       } } ;
/*     */     private final ConfigurableBeanFactory beanFactory;
/*     */ 
/*     */     public BeanMethodInterceptor(ConfigurableBeanFactory beanFactory) {
/* 230 */       this.beanFactory = beanFactory;
/*     */     }
/*     */ 
/*     */     public Object intercept(Object enhancedConfigInstance, Method beanMethod, Object[] beanMethodArgs, MethodProxy cglibMethodProxy)
/*     */       throws Throwable
/*     */     {
/* 243 */       String beanName = BeanAnnotationHelper.determineBeanNameFor(beanMethod);
/*     */ 
/* 246 */       Scope scope = (Scope)AnnotationUtils.findAnnotation(beanMethod, Scope.class);
/* 247 */       if ((scope != null) && (scope.proxyMode() != ScopedProxyMode.NO)) {
/* 248 */         String scopedBeanName = ScopedProxyCreator.getTargetBeanName(beanName);
/* 249 */         if (this.beanFactory.isCurrentlyInCreation(scopedBeanName)) {
/* 250 */           beanName = scopedBeanName;
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 261 */       if ((factoryContainsBean("&" + beanName)) && (factoryContainsBean(beanName))) {
/* 262 */         Object factoryBean = this.beanFactory.getBean("&" + beanName);
/* 263 */         if (!(factoryBean instanceof ScopedProxyFactoryBean))
/*     */         {
/* 269 */           return enhanceFactoryBean(factoryBean.getClass(), beanName);
/*     */         }
/*     */       }
/*     */ 
/* 273 */       if ((isCurrentlyInvokedFactoryMethod(beanMethod)) && (!this.beanFactory.containsSingleton(beanName)))
/*     */       {
/* 277 */         if (BeanFactoryPostProcessor.class.isAssignableFrom(beanMethod.getReturnType())) {
/* 278 */           ConfigurationClassEnhancer.logger.warn(String.format("@Bean method %s.%s is non-static and returns an object assignable to Spring's BeanFactoryPostProcessor interface. This will result in a failure to process annotations such as @Autowired, @Resource and @PostConstruct within the method's declaring @Configuration class. Add the 'static' modifier to this method to avoid these container lifecycle issues; see @Bean Javadoc for complete details", new Object[] { beanMethod.getDeclaringClass().getSimpleName(), beanMethod.getName() }));
/*     */         }
/*     */ 
/* 286 */         return cglibMethodProxy.invokeSuper(enhancedConfigInstance, beanMethodArgs);
/*     */       }
/*     */ 
/* 293 */       boolean alreadyInCreation = this.beanFactory.isCurrentlyInCreation(beanName);
/*     */       try {
/* 295 */         if (alreadyInCreation) {
/* 296 */           this.beanFactory.setCurrentlyInCreation(beanName, false);
/*     */         }
/* 298 */         Object localObject1 = this.beanFactory.getBean(beanName);
/*     */         return localObject1;
/*     */       }
/*     */       finally
/*     */       {
/* 301 */         if (alreadyInCreation)
/* 302 */           this.beanFactory.setCurrentlyInCreation(beanName, true); 
/* 302 */       }throw localObject2;
/*     */     }
/*     */ 
/*     */     private boolean factoryContainsBean(String beanName)
/*     */     {
/* 323 */       return (this.beanFactory.containsBean(beanName)) && (!this.beanFactory.isCurrentlyInCreation(beanName));
/*     */     }
/*     */ 
/*     */     private boolean isCurrentlyInvokedFactoryMethod(Method method)
/*     */     {
/* 333 */       Method currentlyInvoked = SimpleInstantiationStrategy.getCurrentlyInvokedFactoryMethod();
/* 334 */       return (currentlyInvoked != null) && (method.getName().equals(currentlyInvoked.getName())) && (Arrays.equals(method.getParameterTypes(), currentlyInvoked.getParameterTypes()));
/*     */     }
/*     */ 
/*     */     private Object enhanceFactoryBean(Class<?> fbClass, String beanName)
/*     */       throws InstantiationException, IllegalAccessException
/*     */     {
/* 346 */       Enhancer enhancer = new Enhancer();
/* 347 */       enhancer.setSuperclass(fbClass);
/* 348 */       enhancer.setUseFactory(false);
/* 349 */       enhancer.setCallbackFilter(CALLBACK_FILTER);
/*     */ 
/* 351 */       Callback[] callbackInstances = { new ConfigurationClassEnhancer.GetObjectMethodInterceptor(this.beanFactory, beanName), NoOp.INSTANCE };
/*     */ 
/* 355 */       enhancer.setCallbackTypes(CALLBACK_TYPES);
/* 356 */       Class fbSubclass = enhancer.createClass();
/* 357 */       Enhancer.registerCallbacks(fbSubclass, callbackInstances);
/* 358 */       return fbSubclass.newInstance();
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class DisposableBeanMethodInterceptor
/*     */     implements MethodInterceptor
/*     */   {
/*     */     public Object intercept(Object obj, Method method, Object[] args, MethodProxy proxy)
/*     */       throws Throwable
/*     */     {
/* 194 */       Enhancer.registerStaticCallbacks(obj.getClass(), null);
/*     */ 
/* 197 */       if (DisposableBean.class.isAssignableFrom(obj.getClass().getSuperclass())) {
/* 198 */         return proxy.invokeSuper(obj, args);
/*     */       }
/* 200 */       return null;
/*     */     }
/*     */ 
/*     */     public static boolean isDestroyMethod(Method candidateMethod) {
/* 204 */       return (candidateMethod.getName().equals("destroy")) && (candidateMethod.getParameterTypes().length == 0) && (DisposableBean.class.isAssignableFrom(candidateMethod.getDeclaringClass()));
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class GetObjectMethodInterceptor
/*     */     implements MethodInterceptor
/*     */   {
/*     */     private final ConfigurableBeanFactory beanFactory;
/*     */     private final String beanName;
/*     */ 
/*     */     public GetObjectMethodInterceptor(ConfigurableBeanFactory beanFactory, String beanName)
/*     */     {
/* 175 */       this.beanFactory = beanFactory;
/* 176 */       this.beanName = beanName;
/*     */     }
/*     */ 
/*     */     public Object intercept(Object obj, Method method, Object[] args, MethodProxy proxy) throws Throwable {
/* 180 */       return this.beanFactory.getBean(this.beanName);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class ConfigurationClassCallbackFilter
/*     */     implements CallbackFilter
/*     */   {
/*     */     public int accept(Method candidateMethod)
/*     */     {
/* 151 */       if (BeanAnnotationHelper.isBeanAnnotated(candidateMethod)) {
/* 152 */         return 0;
/*     */       }
/* 154 */       if (ConfigurationClassEnhancer.DisposableBeanMethodInterceptor.isDestroyMethod(candidateMethod)) {
/* 155 */         return 1;
/*     */       }
/* 157 */       return 2;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static abstract interface EnhancedConfiguration extends DisposableBean
/*     */   {
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.context.annotation.ConfigurationClassEnhancer
 * JD-Core Version:    0.6.0
 */