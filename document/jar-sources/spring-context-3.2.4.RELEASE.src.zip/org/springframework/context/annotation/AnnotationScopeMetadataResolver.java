/*    */ package org.springframework.context.annotation;
/*    */ 
/*    */ import java.lang.annotation.Annotation;
/*    */ import org.springframework.beans.factory.annotation.AnnotatedBeanDefinition;
/*    */ import org.springframework.beans.factory.config.BeanDefinition;
/*    */ import org.springframework.core.annotation.AnnotationAttributes;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ public class AnnotationScopeMetadataResolver
/*    */   implements ScopeMetadataResolver
/*    */ {
/*    */   private final ScopedProxyMode defaultProxyMode;
/* 44 */   protected Class<? extends Annotation> scopeAnnotationType = Scope.class;
/*    */ 
/*    */   public AnnotationScopeMetadataResolver()
/*    */   {
/* 53 */     this.defaultProxyMode = ScopedProxyMode.NO;
/*    */   }
/*    */ 
/*    */   public AnnotationScopeMetadataResolver(ScopedProxyMode defaultProxyMode)
/*    */   {
/* 61 */     Assert.notNull(defaultProxyMode, "'defaultProxyMode' must not be null");
/* 62 */     this.defaultProxyMode = defaultProxyMode;
/*    */   }
/*    */ 
/*    */   public void setScopeAnnotationType(Class<? extends Annotation> scopeAnnotationType)
/*    */   {
/* 72 */     Assert.notNull(scopeAnnotationType, "'scopeAnnotationType' must not be null");
/* 73 */     this.scopeAnnotationType = scopeAnnotationType;
/*    */   }
/*    */ 
/*    */   public ScopeMetadata resolveScopeMetadata(BeanDefinition definition)
/*    */   {
/* 78 */     ScopeMetadata metadata = new ScopeMetadata();
/* 79 */     if ((definition instanceof AnnotatedBeanDefinition)) {
/* 80 */       AnnotatedBeanDefinition annDef = (AnnotatedBeanDefinition)definition;
/* 81 */       AnnotationAttributes attributes = MetadataUtils.attributesFor(annDef.getMetadata(), this.scopeAnnotationType);
/* 82 */       if (attributes != null) {
/* 83 */         metadata.setScopeName(attributes.getString("value"));
/* 84 */         ScopedProxyMode proxyMode = (ScopedProxyMode)attributes.getEnum("proxyMode");
/* 85 */         if ((proxyMode == null) || (proxyMode == ScopedProxyMode.DEFAULT)) {
/* 86 */           proxyMode = this.defaultProxyMode;
/*    */         }
/* 88 */         metadata.setScopedProxyMode(proxyMode);
/*    */       }
/*    */     }
/* 91 */     return metadata;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.context.annotation.AnnotationScopeMetadataResolver
 * JD-Core Version:    0.6.0
 */