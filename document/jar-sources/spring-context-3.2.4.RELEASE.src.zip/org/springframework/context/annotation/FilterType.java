/*    */ package org.springframework.context.annotation;
/*    */ 
/*    */ public enum FilterType
/*    */ {
/* 41 */   ANNOTATION, 
/*    */ 
/* 47 */   ASSIGNABLE_TYPE, 
/*    */ 
/* 52 */   CUSTOM;
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.context.annotation.FilterType
 * JD-Core Version:    0.6.0
 */