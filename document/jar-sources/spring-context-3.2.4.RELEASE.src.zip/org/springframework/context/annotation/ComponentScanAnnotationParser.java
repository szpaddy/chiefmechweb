/*     */ package org.springframework.context.annotation;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.factory.config.BeanDefinitionHolder;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.beans.factory.support.BeanNameGenerator;
/*     */ import org.springframework.core.annotation.AnnotationAttributes;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.core.type.filter.AnnotationTypeFilter;
/*     */ import org.springframework.core.type.filter.AssignableTypeFilter;
/*     */ import org.springframework.core.type.filter.TypeFilter;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ class ComponentScanAnnotationParser
/*     */ {
/*     */   private final ResourceLoader resourceLoader;
/*     */   private final Environment environment;
/*     */   private final BeanDefinitionRegistry registry;
/*     */   private final BeanNameGenerator beanNameGenerator;
/*     */ 
/*     */   public ComponentScanAnnotationParser(ResourceLoader resourceLoader, Environment environment, BeanNameGenerator beanNameGenerator, BeanDefinitionRegistry registry)
/*     */   {
/*  60 */     this.resourceLoader = resourceLoader;
/*  61 */     this.environment = environment;
/*  62 */     this.beanNameGenerator = beanNameGenerator;
/*  63 */     this.registry = registry;
/*     */   }
/*     */ 
/*     */   public Set<BeanDefinitionHolder> parse(AnnotationAttributes componentScan, String declaringClass)
/*     */   {
/*  68 */     ClassPathBeanDefinitionScanner scanner = new ClassPathBeanDefinitionScanner(this.registry, componentScan.getBoolean("useDefaultFilters"));
/*     */ 
/*  71 */     Assert.notNull(this.environment, "Environment must not be null");
/*  72 */     scanner.setEnvironment(this.environment);
/*     */ 
/*  74 */     Assert.notNull(this.resourceLoader, "ResourceLoader must not be null");
/*  75 */     scanner.setResourceLoader(this.resourceLoader);
/*     */ 
/*  77 */     Class generatorClass = componentScan.getClass("nameGenerator");
/*  78 */     boolean useInheritedGenerator = BeanNameGenerator.class.equals(generatorClass);
/*  79 */     scanner.setBeanNameGenerator(useInheritedGenerator ? this.beanNameGenerator : (BeanNameGenerator)BeanUtils.instantiateClass(generatorClass));
/*     */ 
/*  82 */     ScopedProxyMode scopedProxyMode = (ScopedProxyMode)componentScan.getEnum("scopedProxy");
/*  83 */     if (scopedProxyMode != ScopedProxyMode.DEFAULT) {
/*  84 */       scanner.setScopedProxyMode(scopedProxyMode);
/*     */     }
/*     */     else {
/*  87 */       Class resolverClass = componentScan.getClass("scopeResolver");
/*  88 */       scanner.setScopeMetadataResolver((ScopeMetadataResolver)BeanUtils.instantiateClass(resolverClass));
/*     */     }
/*     */ 
/*  91 */     scanner.setResourcePattern(componentScan.getString("resourcePattern"));
/*     */ 
/*  93 */     for (AnnotationAttributes filter : componentScan.getAnnotationArray("includeFilters")) {
/*  94 */       for (TypeFilter typeFilter : typeFiltersFor(filter)) {
/*  95 */         scanner.addIncludeFilter(typeFilter);
/*     */       }
/*     */     }
/*  98 */     for (AnnotationAttributes filter : componentScan.getAnnotationArray("excludeFilters")) {
/*  99 */       for (TypeFilter typeFilter : typeFiltersFor(filter)) {
/* 100 */         scanner.addExcludeFilter(typeFilter);
/*     */       }
/*     */     }
/*     */ 
/* 104 */     List basePackages = new ArrayList();
/* 105 */     for (String pkg : componentScan.getStringArray("value")) {
/* 106 */       if (StringUtils.hasText(pkg)) {
/* 107 */         basePackages.add(pkg);
/*     */       }
/*     */     }
/* 110 */     for (String pkg : componentScan.getStringArray("basePackages")) {
/* 111 */       if (StringUtils.hasText(pkg)) {
/* 112 */         basePackages.add(pkg);
/*     */       }
/*     */     }
/* 115 */     for (Class clazz : componentScan.getClassArray("basePackageClasses")) {
/* 116 */       basePackages.add(ClassUtils.getPackageName(clazz));
/*     */     }
/*     */ 
/* 119 */     if (basePackages.isEmpty()) {
/* 120 */       basePackages.add(ClassUtils.getPackageName(declaringClass));
/*     */     }
/*     */ 
/* 123 */     return scanner.doScan(StringUtils.toStringArray(basePackages));
/*     */   }
/*     */ 
/*     */   private List<TypeFilter> typeFiltersFor(AnnotationAttributes filterAttributes) {
/* 127 */     List typeFilters = new ArrayList();
/* 128 */     FilterType filterType = (FilterType)filterAttributes.getEnum("type");
/*     */ 
/* 130 */     for (Class filterClass : filterAttributes.getClassArray("value")) {
/* 131 */       switch (1.$SwitchMap$org$springframework$context$annotation$FilterType[filterType.ordinal()]) {
/*     */       case 1:
/* 133 */         Assert.isAssignable(Annotation.class, filterClass, "An error occured when processing a @ComponentScan ANNOTATION type filter: ");
/*     */ 
/* 137 */         Class annoClass = filterClass;
/* 138 */         typeFilters.add(new AnnotationTypeFilter(annoClass));
/* 139 */         break;
/*     */       case 2:
/* 141 */         typeFilters.add(new AssignableTypeFilter(filterClass));
/* 142 */         break;
/*     */       case 3:
/* 144 */         Assert.isAssignable(TypeFilter.class, filterClass, "An error occured when processing a @ComponentScan CUSTOM type filter: ");
/*     */ 
/* 147 */         typeFilters.add(BeanUtils.instantiateClass(filterClass, TypeFilter.class));
/* 148 */         break;
/*     */       default:
/* 150 */         throw new IllegalArgumentException("unknown filter type " + filterType);
/*     */       }
/*     */     }
/* 153 */     return typeFilters;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.context.annotation.ComponentScanAnnotationParser
 * JD-Core Version:    0.6.0
 */