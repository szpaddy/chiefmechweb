/*     */ package org.springframework.context.annotation;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.springframework.beans.factory.parsing.Location;
/*     */ import org.springframework.beans.factory.parsing.Problem;
/*     */ import org.springframework.beans.factory.parsing.ProblemReporter;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionReader;
/*     */ import org.springframework.core.io.DescriptiveResource;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.type.AnnotationMetadata;
/*     */ import org.springframework.core.type.StandardAnnotationMetadata;
/*     */ import org.springframework.core.type.classreading.MetadataReader;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ final class ConfigurationClass
/*     */ {
/*     */   private final AnnotationMetadata metadata;
/*     */   private final Resource resource;
/*     */   private String beanName;
/*     */   private final boolean imported;
/*  58 */   private final Set<BeanMethod> beanMethods = new LinkedHashSet();
/*     */ 
/*  60 */   private final Map<String, Class<? extends BeanDefinitionReader>> importedResources = new LinkedHashMap();
/*     */ 
/*     */   public ConfigurationClass(MetadataReader metadataReader, String beanName)
/*     */   {
/*  72 */     Assert.hasText(beanName, "bean name must not be null");
/*  73 */     this.metadata = metadataReader.getAnnotationMetadata();
/*  74 */     this.resource = metadataReader.getResource();
/*  75 */     this.beanName = beanName;
/*  76 */     this.imported = false;
/*     */   }
/*     */ 
/*     */   public ConfigurationClass(MetadataReader metadataReader, boolean imported)
/*     */   {
/*  88 */     this.metadata = metadataReader.getAnnotationMetadata();
/*  89 */     this.resource = metadataReader.getResource();
/*  90 */     this.imported = imported;
/*     */   }
/*     */ 
/*     */   public ConfigurationClass(Class<?> clazz, String beanName)
/*     */   {
/* 101 */     Assert.hasText(beanName, "Bean name must not be null");
/* 102 */     this.metadata = new StandardAnnotationMetadata(clazz, true);
/* 103 */     this.resource = new DescriptiveResource(clazz.toString());
/* 104 */     this.beanName = beanName;
/* 105 */     this.imported = false;
/*     */   }
/*     */ 
/*     */   public ConfigurationClass(Class<?> clazz, boolean imported)
/*     */   {
/* 117 */     this.metadata = new StandardAnnotationMetadata(clazz, true);
/* 118 */     this.resource = new DescriptiveResource(clazz.toString());
/* 119 */     this.imported = imported;
/*     */   }
/*     */ 
/*     */   public AnnotationMetadata getMetadata()
/*     */   {
/* 124 */     return this.metadata;
/*     */   }
/*     */ 
/*     */   public Resource getResource() {
/* 128 */     return this.resource;
/*     */   }
/*     */ 
/*     */   public String getSimpleName() {
/* 132 */     return ClassUtils.getShortName(getMetadata().getClassName());
/*     */   }
/*     */ 
/*     */   public void setBeanName(String beanName) {
/* 136 */     this.beanName = beanName;
/*     */   }
/*     */ 
/*     */   public String getBeanName() {
/* 140 */     return this.beanName;
/*     */   }
/*     */ 
/*     */   public boolean isImported()
/*     */   {
/* 149 */     return this.imported;
/*     */   }
/*     */ 
/*     */   public void addBeanMethod(BeanMethod method) {
/* 153 */     this.beanMethods.add(method);
/*     */   }
/*     */ 
/*     */   public Set<BeanMethod> getBeanMethods() {
/* 157 */     return this.beanMethods;
/*     */   }
/*     */ 
/*     */   public void addImportedResource(String importedResource, Class<? extends BeanDefinitionReader> readerClass) {
/* 161 */     this.importedResources.put(importedResource, readerClass);
/*     */   }
/*     */ 
/*     */   public Map<String, Class<? extends BeanDefinitionReader>> getImportedResources() {
/* 165 */     return this.importedResources;
/*     */   }
/*     */ 
/*     */   public void validate(ProblemReporter problemReporter)
/*     */   {
/* 171 */     if ((getMetadata().isAnnotated(Configuration.class.getName())) && 
/* 172 */       (getMetadata().isFinal())) {
/* 173 */       problemReporter.error(new FinalConfigurationProblem());
/*     */     }
/*     */ 
/* 179 */     Map methodNameCounts = new HashMap();
/* 180 */     for (BeanMethod beanMethod : this.beanMethods) {
/* 181 */       String fqMethodName = beanMethod.getFullyQualifiedMethodName();
/* 182 */       Integer currentCount = (Integer)methodNameCounts.get(fqMethodName);
/* 183 */       int newCount = currentCount != null ? currentCount.intValue() + 1 : 1;
/* 184 */       methodNameCounts.put(fqMethodName, Integer.valueOf(newCount));
/*     */     }
/* 186 */     for (String fqMethodName : methodNameCounts.keySet()) {
/* 187 */       int count = ((Integer)methodNameCounts.get(fqMethodName)).intValue();
/* 188 */       if (count > 1) {
/* 189 */         String shortMethodName = ConfigurationMethod.getShortMethodName(fqMethodName);
/* 190 */         problemReporter.error(new BeanMethodOverloadingProblem(shortMethodName, count));
/*     */       }
/*     */     }
/*     */ 
/* 194 */     for (BeanMethod beanMethod : this.beanMethods)
/* 195 */       beanMethod.validate(problemReporter);
/*     */   }
/*     */ 
/*     */   public boolean equals(Object other)
/*     */   {
/* 202 */     return (this == other) || (((other instanceof ConfigurationClass)) && (getMetadata().getClassName().equals(((ConfigurationClass)other).getMetadata().getClassName())));
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 208 */     return getMetadata().getClassName().hashCode();
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 213 */     return String.format("[ConfigurationClass:beanName=%s,resource=%s]", new Object[] { this.beanName, this.resource });
/*     */   }
/*     */ 
/*     */   private class BeanMethodOverloadingProblem extends Problem
/*     */   {
/*     */     public BeanMethodOverloadingProblem(String methodName, int count)
/*     */     {
/* 235 */       super(new Location(ConfigurationClass.this.getResource(), ConfigurationClass.this.getMetadata()));
/*     */     }
/*     */   }
/*     */ 
/*     */   private class FinalConfigurationProblem extends Problem
/*     */   {
/*     */     public FinalConfigurationProblem()
/*     */     {
/* 223 */       super(new Location(ConfigurationClass.this.getResource(), ConfigurationClass.this.getMetadata()));
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.context.annotation.ConfigurationClass
 * JD-Core Version:    0.6.0
 */