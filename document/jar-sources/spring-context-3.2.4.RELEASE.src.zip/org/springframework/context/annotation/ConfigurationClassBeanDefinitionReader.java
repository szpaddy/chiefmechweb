/*     */ package org.springframework.context.annotation;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.annotation.AnnotatedBeanDefinition;
/*     */ import org.springframework.beans.factory.annotation.AnnotatedGenericBeanDefinition;
/*     */ import org.springframework.beans.factory.annotation.Autowire;
/*     */ import org.springframework.beans.factory.annotation.RequiredAnnotationBeanPostProcessor;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanDefinitionHolder;
/*     */ import org.springframework.beans.factory.parsing.Location;
/*     */ import org.springframework.beans.factory.parsing.Problem;
/*     */ import org.springframework.beans.factory.parsing.ProblemReporter;
/*     */ import org.springframework.beans.factory.parsing.SourceExtractor;
/*     */ import org.springframework.beans.factory.support.AbstractBeanDefinitionReader;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionReader;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.beans.factory.support.BeanNameGenerator;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ import org.springframework.core.annotation.AnnotationAttributes;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.core.type.AnnotationMetadata;
/*     */ import org.springframework.core.type.MethodMetadata;
/*     */ import org.springframework.core.type.classreading.MetadataReaderFactory;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ class ConfigurationClassBeanDefinitionReader
/*     */ {
/*  71 */   private static final Log logger = LogFactory.getLog(ConfigurationClassBeanDefinitionReader.class);
/*     */   private final BeanDefinitionRegistry registry;
/*     */   private final SourceExtractor sourceExtractor;
/*     */   private final ProblemReporter problemReporter;
/*     */   private final MetadataReaderFactory metadataReaderFactory;
/*     */   private final ResourceLoader resourceLoader;
/*     */   private final Environment environment;
/*     */   private final BeanNameGenerator importBeanNameGenerator;
/*     */ 
/*     */   public ConfigurationClassBeanDefinitionReader(BeanDefinitionRegistry registry, SourceExtractor sourceExtractor, ProblemReporter problemReporter, MetadataReaderFactory metadataReaderFactory, ResourceLoader resourceLoader, Environment environment, BeanNameGenerator importBeanNameGenerator)
/*     */   {
/*  97 */     this.registry = registry;
/*  98 */     this.sourceExtractor = sourceExtractor;
/*  99 */     this.problemReporter = problemReporter;
/* 100 */     this.metadataReaderFactory = metadataReaderFactory;
/* 101 */     this.resourceLoader = resourceLoader;
/* 102 */     this.environment = environment;
/* 103 */     this.importBeanNameGenerator = importBeanNameGenerator;
/*     */   }
/*     */ 
/*     */   public void loadBeanDefinitions(Set<ConfigurationClass> configurationModel)
/*     */   {
/* 112 */     for (ConfigurationClass configClass : configurationModel)
/* 113 */       loadBeanDefinitionsForConfigurationClass(configClass);
/*     */   }
/*     */ 
/*     */   private void loadBeanDefinitionsForConfigurationClass(ConfigurationClass configClass)
/*     */   {
/* 122 */     if (configClass.isImported()) {
/* 123 */       registerBeanDefinitionForImportedConfigurationClass(configClass);
/*     */     }
/* 125 */     for (BeanMethod beanMethod : configClass.getBeanMethods()) {
/* 126 */       loadBeanDefinitionsForBeanMethod(beanMethod);
/*     */     }
/* 128 */     loadBeanDefinitionsFromImportedResources(configClass.getImportedResources());
/*     */   }
/*     */ 
/*     */   private void registerBeanDefinitionForImportedConfigurationClass(ConfigurationClass configClass)
/*     */   {
/* 135 */     AnnotationMetadata metadata = configClass.getMetadata();
/* 136 */     BeanDefinition configBeanDef = new AnnotatedGenericBeanDefinition(metadata);
/* 137 */     if (ConfigurationClassUtils.checkConfigurationClassCandidate(configBeanDef, this.metadataReaderFactory)) {
/* 138 */       String configBeanName = this.importBeanNameGenerator.generateBeanName(configBeanDef, this.registry);
/* 139 */       this.registry.registerBeanDefinition(configBeanName, configBeanDef);
/* 140 */       configClass.setBeanName(configBeanName);
/* 141 */       if (logger.isDebugEnabled())
/* 142 */         logger.debug(String.format("Registered bean definition for imported @Configuration class %s", new Object[] { configBeanName }));
/*     */     }
/*     */     else
/*     */     {
/* 146 */       this.problemReporter.error(new InvalidConfigurationImportProblem(metadata.getClassName(), configClass.getResource(), metadata));
/*     */     }
/*     */   }
/*     */ 
/*     */   private void loadBeanDefinitionsForBeanMethod(BeanMethod beanMethod)
/*     */   {
/* 156 */     ConfigurationClass configClass = beanMethod.getConfigurationClass();
/* 157 */     MethodMetadata metadata = beanMethod.getMetadata();
/*     */ 
/* 159 */     RootBeanDefinition beanDef = new ConfigurationClassBeanDefinition(configClass);
/* 160 */     beanDef.setResource(configClass.getResource());
/* 161 */     beanDef.setSource(this.sourceExtractor.extractSource(metadata, configClass.getResource()));
/* 162 */     if (metadata.isStatic())
/*     */     {
/* 164 */       beanDef.setBeanClassName(configClass.getMetadata().getClassName());
/* 165 */       beanDef.setFactoryMethodName(metadata.getMethodName());
/*     */     }
/*     */     else
/*     */     {
/* 169 */       beanDef.setFactoryBeanName(configClass.getBeanName());
/* 170 */       beanDef.setUniqueFactoryMethodName(metadata.getMethodName());
/*     */     }
/* 172 */     beanDef.setAutowireMode(3);
/* 173 */     beanDef.setAttribute(RequiredAnnotationBeanPostProcessor.SKIP_REQUIRED_CHECK_ATTRIBUTE, Boolean.TRUE);
/*     */ 
/* 176 */     AnnotationAttributes role = MetadataUtils.attributesFor(metadata, Role.class);
/* 177 */     if (role != null) {
/* 178 */       beanDef.setRole(((Integer)role.getNumber("value")).intValue());
/*     */     }
/*     */ 
/* 182 */     AnnotationAttributes bean = MetadataUtils.attributesFor(metadata, Bean.class);
/* 183 */     List names = new ArrayList(Arrays.asList(bean.getStringArray("name")));
/* 184 */     String beanName = names.size() > 0 ? (String)names.remove(0) : beanMethod.getMetadata().getMethodName();
/* 185 */     for (String alias : names) {
/* 186 */       this.registry.registerAlias(beanName, alias);
/*     */     }
/*     */ 
/* 190 */     if (this.registry.containsBeanDefinition(beanName)) {
/* 191 */       BeanDefinition existingBeanDef = this.registry.getBeanDefinition(beanName);
/*     */ 
/* 193 */       if (!(existingBeanDef instanceof ConfigurationClassBeanDefinition))
/*     */       {
/* 196 */         if (logger.isDebugEnabled()) {
/* 197 */           logger.debug(String.format("Skipping loading bean definition for %s: a definition for bean '%s' already exists. This is likely due to an override in XML.", new Object[] { beanMethod, beanName }));
/*     */         }
/*     */ 
/* 200 */         return;
/*     */       }
/*     */     }
/*     */ 
/* 204 */     if (metadata.isAnnotated(Primary.class.getName())) {
/* 205 */       beanDef.setPrimary(true);
/*     */     }
/*     */ 
/* 209 */     if (metadata.isAnnotated(Lazy.class.getName())) {
/* 210 */       AnnotationAttributes lazy = MetadataUtils.attributesFor(metadata, Lazy.class);
/* 211 */       beanDef.setLazyInit(lazy.getBoolean("value"));
/*     */     }
/* 213 */     else if (configClass.getMetadata().isAnnotated(Lazy.class.getName())) {
/* 214 */       AnnotationAttributes lazy = MetadataUtils.attributesFor(configClass.getMetadata(), Lazy.class);
/* 215 */       beanDef.setLazyInit(lazy.getBoolean("value"));
/*     */     }
/*     */ 
/* 218 */     if (metadata.isAnnotated(DependsOn.class.getName())) {
/* 219 */       AnnotationAttributes dependsOn = MetadataUtils.attributesFor(metadata, DependsOn.class);
/* 220 */       String[] otherBeans = dependsOn.getStringArray("value");
/* 221 */       if (otherBeans.length > 0) {
/* 222 */         beanDef.setDependsOn(otherBeans);
/*     */       }
/*     */     }
/*     */ 
/* 226 */     Autowire autowire = (Autowire)bean.getEnum("autowire");
/* 227 */     if (autowire.isAutowire()) {
/* 228 */       beanDef.setAutowireMode(autowire.value());
/*     */     }
/*     */ 
/* 231 */     String initMethodName = bean.getString("initMethod");
/* 232 */     if (StringUtils.hasText(initMethodName)) {
/* 233 */       beanDef.setInitMethodName(initMethodName);
/*     */     }
/*     */ 
/* 236 */     String destroyMethodName = bean.getString("destroyMethod");
/* 237 */     if (StringUtils.hasText(destroyMethodName)) {
/* 238 */       beanDef.setDestroyMethodName(destroyMethodName);
/*     */     }
/*     */ 
/* 242 */     ScopedProxyMode proxyMode = ScopedProxyMode.NO;
/* 243 */     AnnotationAttributes scope = MetadataUtils.attributesFor(metadata, Scope.class);
/* 244 */     if (scope != null) {
/* 245 */       beanDef.setScope(scope.getString("value"));
/* 246 */       proxyMode = (ScopedProxyMode)scope.getEnum("proxyMode");
/* 247 */       if (proxyMode == ScopedProxyMode.DEFAULT) {
/* 248 */         proxyMode = ScopedProxyMode.NO;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 253 */     BeanDefinition beanDefToRegister = beanDef;
/* 254 */     if (proxyMode != ScopedProxyMode.NO) {
/* 255 */       BeanDefinitionHolder proxyDef = ScopedProxyCreator.createScopedProxy(new BeanDefinitionHolder(beanDef, beanName), this.registry, proxyMode == ScopedProxyMode.TARGET_CLASS);
/*     */ 
/* 257 */       beanDefToRegister = new ConfigurationClassBeanDefinition((RootBeanDefinition)proxyDef.getBeanDefinition(), configClass);
/*     */     }
/*     */ 
/* 261 */     if (logger.isDebugEnabled()) {
/* 262 */       logger.debug(String.format("Registering bean definition for @Bean method %s.%s()", new Object[] { configClass.getMetadata().getClassName(), beanName }));
/*     */     }
/*     */ 
/* 265 */     this.registry.registerBeanDefinition(beanName, beanDefToRegister);
/*     */   }
/*     */ 
/*     */   private void loadBeanDefinitionsFromImportedResources(Map<String, Class<? extends BeanDefinitionReader>> importedResources)
/*     */   {
/* 272 */     Map readerInstanceCache = new HashMap();
/* 273 */     for (Map.Entry entry : importedResources.entrySet()) {
/* 274 */       String resource = (String)entry.getKey();
/* 275 */       Class readerClass = (Class)entry.getValue();
/* 276 */       if (!readerInstanceCache.containsKey(readerClass)) {
/*     */         try
/*     */         {
/* 279 */           BeanDefinitionReader readerInstance = (BeanDefinitionReader)readerClass.getConstructor(new Class[] { BeanDefinitionRegistry.class }).newInstance(new Object[] { this.registry });
/*     */ 
/* 282 */           if ((readerInstance instanceof AbstractBeanDefinitionReader)) {
/* 283 */             AbstractBeanDefinitionReader abdr = (AbstractBeanDefinitionReader)readerInstance;
/* 284 */             abdr.setResourceLoader(this.resourceLoader);
/* 285 */             abdr.setEnvironment(this.environment);
/*     */           }
/* 287 */           readerInstanceCache.put(readerClass, readerInstance);
/*     */         }
/*     */         catch (Exception ex) {
/* 290 */           throw new IllegalStateException("Could not instantiate BeanDefinitionReader class [" + readerClass.getName() + "]");
/*     */         }
/*     */       }
/* 293 */       BeanDefinitionReader reader = (BeanDefinitionReader)readerInstanceCache.get(readerClass);
/*     */ 
/* 295 */       reader.loadBeanDefinitions(resource);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class InvalidConfigurationImportProblem extends Problem
/*     */   {
/*     */     public InvalidConfigurationImportProblem(String className, Resource resource, AnnotationMetadata metadata)
/*     */     {
/* 348 */       super(new Location(resource, metadata));
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class ConfigurationClassBeanDefinition extends RootBeanDefinition
/*     */     implements AnnotatedBeanDefinition
/*     */   {
/*     */     private final AnnotationMetadata annotationMetadata;
/*     */ 
/*     */     public ConfigurationClassBeanDefinition(ConfigurationClass configClass)
/*     */     {
/* 312 */       this.annotationMetadata = configClass.getMetadata();
/*     */     }
/*     */ 
/*     */     public ConfigurationClassBeanDefinition(RootBeanDefinition original, ConfigurationClass configClass) {
/* 316 */       super();
/* 317 */       this.annotationMetadata = configClass.getMetadata();
/*     */     }
/*     */ 
/*     */     private ConfigurationClassBeanDefinition(ConfigurationClassBeanDefinition original) {
/* 321 */       super();
/* 322 */       this.annotationMetadata = original.annotationMetadata;
/*     */     }
/*     */ 
/*     */     public AnnotationMetadata getMetadata() {
/* 326 */       return this.annotationMetadata;
/*     */     }
/*     */ 
/*     */     public boolean isFactoryMethod(Method candidate)
/*     */     {
/* 331 */       return (super.isFactoryMethod(candidate)) && (BeanAnnotationHelper.isBeanAnnotated(candidate));
/*     */     }
/*     */ 
/*     */     public ConfigurationClassBeanDefinition cloneBeanDefinition()
/*     */     {
/* 336 */       return new ConfigurationClassBeanDefinition(this);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.context.annotation.ConfigurationClassBeanDefinitionReader
 * JD-Core Version:    0.6.0
 */