/*    */ package org.springframework.context.annotation;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import org.springframework.core.annotation.AnnotationUtils;
/*    */ 
/*    */ class BeanAnnotationHelper
/*    */ {
/*    */   public static boolean isBeanAnnotated(Method method)
/*    */   {
/* 35 */     return AnnotationUtils.findAnnotation(method, Bean.class) != null;
/*    */   }
/*    */ 
/*    */   public static String determineBeanNameFor(Method beanMethod)
/*    */   {
/* 40 */     String beanName = beanMethod.getName();
/*    */ 
/* 43 */     Bean bean = (Bean)AnnotationUtils.findAnnotation(beanMethod, Bean.class);
/* 44 */     if ((bean != null) && (bean.name().length > 0)) {
/* 45 */       beanName = bean.name()[0];
/*    */     }
/*    */ 
/* 48 */     return beanName;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.context.annotation.BeanAnnotationHelper
 * JD-Core Version:    0.6.0
 */