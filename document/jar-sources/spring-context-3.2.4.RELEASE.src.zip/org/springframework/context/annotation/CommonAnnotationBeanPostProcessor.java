/*     */ package org.springframework.context.annotation;
/*     */ 
/*     */ import java.beans.Introspector;
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.io.Serializable;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.AnnotatedElement;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Member;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.LinkedList;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import javax.annotation.PostConstruct;
/*     */ import javax.annotation.PreDestroy;
/*     */ import javax.annotation.Resource;
/*     */ import javax.ejb.EJB;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.ws.Service;
/*     */ import javax.xml.ws.WebServiceClient;
/*     */ import javax.xml.ws.WebServiceRef;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.PropertyValues;
/*     */ import org.springframework.beans.factory.BeanCreationException;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*     */ import org.springframework.beans.factory.annotation.InitDestroyAnnotationBeanPostProcessor;
/*     */ import org.springframework.beans.factory.annotation.InjectionMetadata;
/*     */ import org.springframework.beans.factory.annotation.InjectionMetadata.InjectedElement;
/*     */ import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
/*     */ import org.springframework.beans.factory.config.ConfigurableBeanFactory;
/*     */ import org.springframework.beans.factory.config.DependencyDescriptor;
/*     */ import org.springframework.beans.factory.config.InstantiationAwareBeanPostProcessor;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ import org.springframework.core.BridgeMethodResolver;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.jndi.support.SimpleJndiBeanFactory;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class CommonAnnotationBeanPostProcessor extends InitDestroyAnnotationBeanPostProcessor
/*     */   implements InstantiationAwareBeanPostProcessor, BeanFactoryAware, Serializable
/*     */ {
/* 143 */   private static Class<? extends Annotation> webServiceRefClass = null;
/*     */ 
/* 145 */   private static Class<? extends Annotation> ejbRefClass = null;
/*     */ 
/* 168 */   private final Set<String> ignoredResourceTypes = new HashSet(1);
/*     */ 
/* 170 */   private boolean fallbackToDefaultTypeMatch = true;
/*     */ 
/* 172 */   private boolean alwaysUseJndiLookup = false;
/*     */ 
/* 174 */   private transient BeanFactory jndiFactory = new SimpleJndiBeanFactory();
/*     */   private transient BeanFactory resourceFactory;
/*     */   private transient BeanFactory beanFactory;
/* 180 */   private final transient Map<Class<?>, InjectionMetadata> injectionMetadataCache = new ConcurrentHashMap(64);
/*     */ 
/*     */   public CommonAnnotationBeanPostProcessor()
/*     */   {
/* 191 */     setOrder(2147483644);
/* 192 */     setInitAnnotationType(PostConstruct.class);
/* 193 */     setDestroyAnnotationType(PreDestroy.class);
/* 194 */     ignoreResourceType("javax.xml.ws.WebServiceContext");
/*     */   }
/*     */ 
/*     */   public void ignoreResourceType(String resourceType)
/*     */   {
/* 206 */     Assert.notNull(resourceType, "Ignored resource type must not be null");
/* 207 */     this.ignoredResourceTypes.add(resourceType);
/*     */   }
/*     */ 
/*     */   public void setFallbackToDefaultTypeMatch(boolean fallbackToDefaultTypeMatch)
/*     */   {
/* 221 */     this.fallbackToDefaultTypeMatch = fallbackToDefaultTypeMatch;
/*     */   }
/*     */ 
/*     */   public void setAlwaysUseJndiLookup(boolean alwaysUseJndiLookup)
/*     */   {
/* 235 */     this.alwaysUseJndiLookup = alwaysUseJndiLookup;
/*     */   }
/*     */ 
/*     */   public void setJndiFactory(BeanFactory jndiFactory)
/*     */   {
/* 250 */     Assert.notNull(jndiFactory, "BeanFactory must not be null");
/* 251 */     this.jndiFactory = jndiFactory;
/*     */   }
/*     */ 
/*     */   public void setResourceFactory(BeanFactory resourceFactory)
/*     */   {
/* 268 */     Assert.notNull(resourceFactory, "BeanFactory must not be null");
/* 269 */     this.resourceFactory = resourceFactory;
/*     */   }
/*     */ 
/*     */   public void setBeanFactory(BeanFactory beanFactory) throws BeansException {
/* 273 */     Assert.notNull(beanFactory, "BeanFactory must not be null");
/* 274 */     this.beanFactory = beanFactory;
/* 275 */     if (this.resourceFactory == null)
/* 276 */       this.resourceFactory = beanFactory;
/*     */   }
/*     */ 
/*     */   public void postProcessMergedBeanDefinition(RootBeanDefinition beanDefinition, Class<?> beanType, String beanName)
/*     */   {
/* 283 */     super.postProcessMergedBeanDefinition(beanDefinition, beanType, beanName);
/* 284 */     if (beanType != null) {
/* 285 */       InjectionMetadata metadata = findResourceMetadata(beanType);
/* 286 */       metadata.checkConfigMembers(beanDefinition);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Object postProcessBeforeInstantiation(Class<?> beanClass, String beanName) throws BeansException {
/* 291 */     return null;
/*     */   }
/*     */ 
/*     */   public boolean postProcessAfterInstantiation(Object bean, String beanName) throws BeansException {
/* 295 */     return true;
/*     */   }
/*     */ 
/*     */   public PropertyValues postProcessPropertyValues(PropertyValues pvs, PropertyDescriptor[] pds, Object bean, String beanName)
/*     */     throws BeansException
/*     */   {
/* 301 */     InjectionMetadata metadata = findResourceMetadata(bean.getClass());
/*     */     try {
/* 303 */       metadata.inject(bean, beanName, pvs);
/*     */     }
/*     */     catch (Throwable ex) {
/* 306 */       throw new BeanCreationException(beanName, "Injection of resource dependencies failed", ex);
/*     */     }
/* 308 */     return pvs;
/*     */   }
/*     */ 
/*     */   private InjectionMetadata findResourceMetadata(Class<?> clazz)
/*     */   {
/* 314 */     InjectionMetadata metadata = (InjectionMetadata)this.injectionMetadataCache.get(clazz);
/* 315 */     if (metadata == null) {
/* 316 */       synchronized (this.injectionMetadataCache) {
/* 317 */         metadata = (InjectionMetadata)this.injectionMetadataCache.get(clazz);
/* 318 */         if (metadata == null) {
/* 319 */           LinkedList elements = new LinkedList();
/* 320 */           Class targetClass = clazz;
/*     */           do
/*     */           {
/* 323 */             LinkedList currElements = new LinkedList();
/* 324 */             for (Field field : targetClass.getDeclaredFields()) {
/* 325 */               if ((webServiceRefClass != null) && (field.isAnnotationPresent(webServiceRefClass))) {
/* 326 */                 if (Modifier.isStatic(field.getModifiers())) {
/* 327 */                   throw new IllegalStateException("@WebServiceRef annotation is not supported on static fields");
/*     */                 }
/* 329 */                 currElements.add(new WebServiceRefElement(field, null));
/*     */               }
/* 331 */               else if ((ejbRefClass != null) && (field.isAnnotationPresent(ejbRefClass))) {
/* 332 */                 if (Modifier.isStatic(field.getModifiers())) {
/* 333 */                   throw new IllegalStateException("@EJB annotation is not supported on static fields");
/*     */                 }
/* 335 */                 currElements.add(new EjbRefElement(field, null));
/*     */               }
/* 337 */               else if (field.isAnnotationPresent(Resource.class)) {
/* 338 */                 if (Modifier.isStatic(field.getModifiers())) {
/* 339 */                   throw new IllegalStateException("@Resource annotation is not supported on static fields");
/*     */                 }
/* 341 */                 if (!this.ignoredResourceTypes.contains(field.getType().getName())) {
/* 342 */                   currElements.add(new ResourceElement(field, null));
/*     */                 }
/*     */               }
/*     */             }
/* 346 */             for (Method method : targetClass.getDeclaredMethods()) {
/* 347 */               method = BridgeMethodResolver.findBridgedMethod(method);
/* 348 */               Method mostSpecificMethod = BridgeMethodResolver.findBridgedMethod(ClassUtils.getMostSpecificMethod(method, clazz));
/* 349 */               if (method.equals(mostSpecificMethod)) {
/* 350 */                 if ((webServiceRefClass != null) && (method.isAnnotationPresent(webServiceRefClass))) {
/* 351 */                   if (Modifier.isStatic(method.getModifiers())) {
/* 352 */                     throw new IllegalStateException("@WebServiceRef annotation is not supported on static methods");
/*     */                   }
/* 354 */                   if (method.getParameterTypes().length != 1) {
/* 355 */                     throw new IllegalStateException("@WebServiceRef annotation requires a single-arg method: " + method);
/*     */                   }
/* 357 */                   PropertyDescriptor pd = BeanUtils.findPropertyForMethod(method);
/* 358 */                   currElements.add(new WebServiceRefElement(method, pd));
/*     */                 }
/* 360 */                 else if ((ejbRefClass != null) && (method.isAnnotationPresent(ejbRefClass))) {
/* 361 */                   if (Modifier.isStatic(method.getModifiers())) {
/* 362 */                     throw new IllegalStateException("@EJB annotation is not supported on static methods");
/*     */                   }
/* 364 */                   if (method.getParameterTypes().length != 1) {
/* 365 */                     throw new IllegalStateException("@EJB annotation requires a single-arg method: " + method);
/*     */                   }
/* 367 */                   PropertyDescriptor pd = BeanUtils.findPropertyForMethod(method);
/* 368 */                   currElements.add(new EjbRefElement(method, pd));
/*     */                 }
/* 370 */                 else if (method.isAnnotationPresent(Resource.class)) {
/* 371 */                   if (Modifier.isStatic(method.getModifiers())) {
/* 372 */                     throw new IllegalStateException("@Resource annotation is not supported on static methods");
/*     */                   }
/* 374 */                   Class[] paramTypes = method.getParameterTypes();
/* 375 */                   if (paramTypes.length != 1) {
/* 376 */                     throw new IllegalStateException("@Resource annotation requires a single-arg method: " + method);
/*     */                   }
/* 378 */                   if (!this.ignoredResourceTypes.contains(paramTypes[0].getName())) {
/* 379 */                     PropertyDescriptor pd = BeanUtils.findPropertyForMethod(method);
/* 380 */                     currElements.add(new ResourceElement(method, pd));
/*     */                   }
/*     */                 }
/*     */               }
/*     */             }
/* 385 */             elements.addAll(0, currElements);
/* 386 */             targetClass = targetClass.getSuperclass();
/*     */           }
/* 388 */           while ((targetClass != null) && (targetClass != Object.class));
/*     */ 
/* 390 */           metadata = new InjectionMetadata(clazz, elements);
/* 391 */           this.injectionMetadataCache.put(clazz, metadata);
/*     */         }
/*     */       }
/*     */     }
/* 395 */     return metadata;
/*     */   }
/*     */ 
/*     */   protected Object getResource(LookupElement element, String requestingBeanName)
/*     */     throws BeansException
/*     */   {
/* 406 */     if (StringUtils.hasLength(element.mappedName)) {
/* 407 */       return this.jndiFactory.getBean(element.mappedName, element.lookupType);
/*     */     }
/* 409 */     if (this.alwaysUseJndiLookup) {
/* 410 */       return this.jndiFactory.getBean(element.name, element.lookupType);
/*     */     }
/* 412 */     if (this.resourceFactory == null) {
/* 413 */       throw new NoSuchBeanDefinitionException(element.lookupType, "No resource factory configured - specify the 'resourceFactory' property");
/*     */     }
/*     */ 
/* 416 */     return autowireResource(this.resourceFactory, element, requestingBeanName);
/*     */   }
/*     */ 
/*     */   protected Object autowireResource(BeanFactory factory, LookupElement element, String requestingBeanName)
/*     */     throws BeansException
/*     */   {
/* 433 */     String name = element.name;
/*     */     Object resource;
/*     */     Object resource;
/*     */     Set autowiredBeanNames;
/* 435 */     if ((this.fallbackToDefaultTypeMatch) && (element.isDefaultName) && ((factory instanceof AutowireCapableBeanFactory)) && (!factory.containsBean(name)))
/*     */     {
/* 437 */       Set autowiredBeanNames = new LinkedHashSet();
/* 438 */       resource = ((AutowireCapableBeanFactory)factory).resolveDependency(element.getDependencyDescriptor(), requestingBeanName, autowiredBeanNames, null);
/*     */     }
/*     */     else
/*     */     {
/* 442 */       resource = factory.getBean(name, element.lookupType);
/* 443 */       autowiredBeanNames = Collections.singleton(name);
/*     */     }
/*     */     ConfigurableBeanFactory beanFactory;
/* 446 */     if ((factory instanceof ConfigurableBeanFactory)) {
/* 447 */       beanFactory = (ConfigurableBeanFactory)factory;
/* 448 */       for (String autowiredBeanName : autowiredBeanNames) {
/* 449 */         if (beanFactory.containsBean(autowiredBeanName)) {
/* 450 */           beanFactory.registerDependentBean(autowiredBeanName, requestingBeanName);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 455 */     return resource;
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/* 148 */     ClassLoader cl = CommonAnnotationBeanPostProcessor.class.getClassLoader();
/*     */     try
/*     */     {
/* 151 */       Class clazz = cl.loadClass("javax.xml.ws.WebServiceRef");
/* 152 */       webServiceRefClass = clazz;
/*     */     }
/*     */     catch (ClassNotFoundException ex) {
/* 155 */       webServiceRefClass = null;
/*     */     }
/*     */     try
/*     */     {
/* 159 */       Class clazz = cl.loadClass("javax.ejb.EJB");
/* 160 */       ejbRefClass = clazz;
/*     */     }
/*     */     catch (ClassNotFoundException ex) {
/* 163 */       ejbRefClass = null;
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class LookupDependencyDescriptor extends DependencyDescriptor
/*     */   {
/*     */     private final Class<?> lookupType;
/*     */ 
/*     */     public LookupDependencyDescriptor(Field field, Class<?> lookupType)
/*     */     {
/* 713 */       super(true);
/* 714 */       this.lookupType = lookupType;
/*     */     }
/*     */ 
/*     */     public LookupDependencyDescriptor(Method method, Class<?> lookupType) {
/* 718 */       super(true);
/* 719 */       this.lookupType = lookupType;
/*     */     }
/*     */ 
/*     */     public Class<?> getDependencyType()
/*     */     {
/* 724 */       return this.lookupType;
/*     */     }
/*     */   }
/*     */ 
/*     */   private class EjbRefElement extends CommonAnnotationBeanPostProcessor.LookupElement
/*     */   {
/*     */     private String beanName;
/*     */ 
/*     */     public EjbRefElement(Member member, PropertyDescriptor pd)
/*     */     {
/* 653 */       super(member, pd);
/*     */     }
/*     */ 
/*     */     protected void initAnnotation(AnnotatedElement ae)
/*     */     {
/* 658 */       EJB resource = (EJB)ae.getAnnotation(EJB.class);
/* 659 */       String resourceBeanName = resource.beanName();
/* 660 */       String resourceName = resource.name();
/* 661 */       this.isDefaultName = (!StringUtils.hasLength(resourceName));
/* 662 */       if (this.isDefaultName) {
/* 663 */         resourceName = this.member.getName();
/* 664 */         if (((this.member instanceof Method)) && (resourceName.startsWith("set")) && (resourceName.length() > 3)) {
/* 665 */           resourceName = Introspector.decapitalize(resourceName.substring(3));
/*     */         }
/*     */       }
/* 668 */       Class resourceType = resource.beanInterface();
/* 669 */       if ((resourceType != null) && (!Object.class.equals(resourceType))) {
/* 670 */         checkResourceType(resourceType);
/*     */       }
/*     */       else
/*     */       {
/* 674 */         resourceType = getResourceType();
/*     */       }
/* 676 */       this.beanName = resourceBeanName;
/* 677 */       this.name = resourceName;
/* 678 */       this.lookupType = resourceType;
/* 679 */       this.mappedName = resource.mappedName();
/*     */     }
/*     */ 
/*     */     protected Object getResourceToInject(Object target, String requestingBeanName)
/*     */     {
/* 684 */       if (StringUtils.hasLength(this.beanName)) {
/* 685 */         if ((CommonAnnotationBeanPostProcessor.this.beanFactory != null) && (CommonAnnotationBeanPostProcessor.this.beanFactory.containsBean(this.beanName)))
/*     */         {
/* 687 */           Object bean = CommonAnnotationBeanPostProcessor.this.beanFactory.getBean(this.beanName, this.lookupType);
/* 688 */           if ((CommonAnnotationBeanPostProcessor.this.beanFactory instanceof ConfigurableBeanFactory)) {
/* 689 */             ((ConfigurableBeanFactory)CommonAnnotationBeanPostProcessor.this.beanFactory).registerDependentBean(this.beanName, requestingBeanName);
/*     */           }
/* 691 */           return bean;
/*     */         }
/* 693 */         if ((this.isDefaultName) && (!StringUtils.hasLength(this.mappedName))) {
/* 694 */           throw new NoSuchBeanDefinitionException(this.beanName, "Cannot resolve 'beanName' in local BeanFactory. Consider specifying a general 'name' value instead.");
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 699 */       return CommonAnnotationBeanPostProcessor.this.getResource(this, requestingBeanName);
/*     */     }
/*     */   }
/*     */ 
/*     */   private class WebServiceRefElement extends CommonAnnotationBeanPostProcessor.LookupElement
/*     */   {
/*     */     private Class<?> elementType;
/*     */     private String wsdlLocation;
/*     */ 
/*     */     public WebServiceRefElement(Member member, PropertyDescriptor pd)
/*     */     {
/* 566 */       super(member, pd);
/*     */     }
/*     */ 
/*     */     protected void initAnnotation(AnnotatedElement ae)
/*     */     {
/* 571 */       WebServiceRef resource = (WebServiceRef)ae.getAnnotation(WebServiceRef.class);
/* 572 */       String resourceName = resource.name();
/* 573 */       Class resourceType = resource.type();
/* 574 */       this.isDefaultName = (!StringUtils.hasLength(resourceName));
/* 575 */       if (this.isDefaultName) {
/* 576 */         resourceName = this.member.getName();
/* 577 */         if (((this.member instanceof Method)) && (resourceName.startsWith("set")) && (resourceName.length() > 3)) {
/* 578 */           resourceName = Introspector.decapitalize(resourceName.substring(3));
/*     */         }
/*     */       }
/* 581 */       if ((resourceType != null) && (!Object.class.equals(resourceType))) {
/* 582 */         checkResourceType(resourceType);
/*     */       }
/*     */       else
/*     */       {
/* 586 */         resourceType = getResourceType();
/*     */       }
/* 588 */       this.name = resourceName;
/* 589 */       this.elementType = resourceType;
/* 590 */       if (Service.class.isAssignableFrom(resourceType)) {
/* 591 */         this.lookupType = resourceType;
/*     */       }
/*     */       else {
/* 594 */         this.lookupType = (!Object.class.equals(resource.value()) ? resource.value() : Service.class);
/*     */       }
/* 596 */       this.mappedName = resource.mappedName();
/* 597 */       this.wsdlLocation = resource.wsdlLocation();
/*     */     }
/*     */ 
/*     */     protected Object getResourceToInject(Object target, String requestingBeanName) {
/*     */       Service service;
/*     */       try {
/* 604 */         service = (Service)CommonAnnotationBeanPostProcessor.this.getResource(this, requestingBeanName);
/*     */       }
/*     */       catch (NoSuchBeanDefinitionException notFound)
/*     */       {
/* 608 */         if (Service.class.equals(this.lookupType)) {
/* 609 */           throw new IllegalStateException("No resource with name '" + this.name + "' found in context, " + "and no specific JAX-WS Service subclass specified. The typical solution is to either specify " + "a LocalJaxWsServiceFactoryBean with the given name or to specify the (generated) Service " + "subclass as @WebServiceRef(...) value.");
/*     */         }
/*     */ 
/* 614 */         if (StringUtils.hasLength(this.wsdlLocation)) {
/*     */           try {
/* 616 */             Constructor ctor = this.lookupType.getConstructor(new Class[] { URL.class, QName.class });
/* 617 */             WebServiceClient clientAnn = (WebServiceClient)this.lookupType.getAnnotation(WebServiceClient.class);
/* 618 */             if (clientAnn == null) {
/* 619 */               throw new IllegalStateException("JAX-WS Service class [" + this.lookupType.getName() + "] does not carry a WebServiceClient annotation");
/*     */             }
/*     */ 
/* 622 */             service = (Service)BeanUtils.instantiateClass(ctor, new Object[] { new URL(this.wsdlLocation), new QName(clientAnn.targetNamespace(), clientAnn.name()) });
/*     */           }
/*     */           catch (NoSuchMethodException ex)
/*     */           {
/* 626 */             throw new IllegalStateException("JAX-WS Service class [" + this.lookupType.getName() + "] does not have a (URL, QName) constructor. Cannot apply specified WSDL location [" + this.wsdlLocation + "].");
/*     */           }
/*     */           catch (MalformedURLException ex)
/*     */           {
/* 631 */             throw new IllegalArgumentException("Specified WSDL location [" + this.wsdlLocation + "] isn't a valid URL");
/*     */           }
/*     */         }
/*     */         else
/*     */         {
/* 636 */           service = (Service)BeanUtils.instantiateClass(this.lookupType);
/*     */         }
/*     */       }
/* 639 */       return service.getPort(this.elementType);
/*     */     }
/*     */   }
/*     */ 
/*     */   private class ResourceElement extends CommonAnnotationBeanPostProcessor.LookupElement
/*     */   {
/* 514 */     protected boolean shareable = true;
/*     */ 
/*     */     public ResourceElement(Member member, PropertyDescriptor pd) {
/* 517 */       super(member, pd);
/*     */     }
/*     */ 
/*     */     protected void initAnnotation(AnnotatedElement ae)
/*     */     {
/* 522 */       Resource resource = (Resource)ae.getAnnotation(Resource.class);
/* 523 */       String resourceName = resource.name();
/* 524 */       Class resourceType = resource.type();
/* 525 */       this.isDefaultName = (!StringUtils.hasLength(resourceName));
/* 526 */       if (this.isDefaultName) {
/* 527 */         resourceName = this.member.getName();
/* 528 */         if (((this.member instanceof Method)) && (resourceName.startsWith("set")) && (resourceName.length() > 3)) {
/* 529 */           resourceName = Introspector.decapitalize(resourceName.substring(3));
/*     */         }
/*     */       }
/* 532 */       else if ((CommonAnnotationBeanPostProcessor.this.beanFactory instanceof ConfigurableBeanFactory)) {
/* 533 */         resourceName = ((ConfigurableBeanFactory)CommonAnnotationBeanPostProcessor.this.beanFactory).resolveEmbeddedValue(resourceName);
/*     */       }
/* 535 */       if ((resourceType != null) && (!Object.class.equals(resourceType))) {
/* 536 */         checkResourceType(resourceType);
/*     */       }
/*     */       else
/*     */       {
/* 540 */         resourceType = getResourceType();
/*     */       }
/* 542 */       this.name = resourceName;
/* 543 */       this.lookupType = resourceType;
/* 544 */       this.mappedName = resource.mappedName();
/* 545 */       this.shareable = resource.shareable();
/*     */     }
/*     */ 
/*     */     protected Object getResourceToInject(Object target, String requestingBeanName)
/*     */     {
/* 550 */       return CommonAnnotationBeanPostProcessor.this.getResource(this, requestingBeanName);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected abstract class LookupElement extends InjectionMetadata.InjectedElement
/*     */   {
/*     */     protected String name;
/* 467 */     protected boolean isDefaultName = false;
/*     */     protected Class<?> lookupType;
/*     */     protected String mappedName;
/*     */ 
/*     */     public LookupElement(Member member, PropertyDescriptor pd)
/*     */     {
/* 474 */       super(pd);
/* 475 */       initAnnotation((AnnotatedElement)member);
/*     */     }
/*     */ 
/*     */     protected abstract void initAnnotation(AnnotatedElement paramAnnotatedElement);
/*     */ 
/*     */     public final String getName()
/*     */     {
/* 484 */       return this.name;
/*     */     }
/*     */ 
/*     */     public final Class<?> getLookupType()
/*     */     {
/* 491 */       return this.lookupType;
/*     */     }
/*     */ 
/*     */     public final DependencyDescriptor getDependencyDescriptor()
/*     */     {
/* 498 */       if (this.isField) {
/* 499 */         return new CommonAnnotationBeanPostProcessor.LookupDependencyDescriptor((Field)this.member, this.lookupType);
/*     */       }
/*     */ 
/* 502 */       return new CommonAnnotationBeanPostProcessor.LookupDependencyDescriptor((Method)this.member, this.lookupType);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.context.annotation.CommonAnnotationBeanPostProcessor
 * JD-Core Version:    0.6.0
 */