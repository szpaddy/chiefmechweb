/*     */ package org.springframework.context.annotation;
/*     */ 
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.beans.factory.support.BeanNameGenerator;
/*     */ import org.springframework.context.support.GenericApplicationContext;
/*     */ import org.springframework.core.env.ConfigurableEnvironment;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public class AnnotationConfigApplicationContext extends GenericApplicationContext
/*     */ {
/*     */   private final AnnotatedBeanDefinitionReader reader;
/*     */   private final ClassPathBeanDefinitionScanner scanner;
/*     */ 
/*     */   public AnnotationConfigApplicationContext()
/*     */   {
/*  60 */     this.reader = new AnnotatedBeanDefinitionReader(this);
/*  61 */     this.scanner = new ClassPathBeanDefinitionScanner(this);
/*     */   }
/*     */ 
/*     */   public AnnotationConfigApplicationContext(Class<?>[] annotatedClasses)
/*     */   {
/*  71 */     this();
/*  72 */     register(annotatedClasses);
/*  73 */     refresh();
/*     */   }
/*     */ 
/*     */   public AnnotationConfigApplicationContext(String[] basePackages)
/*     */   {
/*  82 */     this();
/*  83 */     scan(basePackages);
/*  84 */     refresh();
/*     */   }
/*     */ 
/*     */   public void setEnvironment(ConfigurableEnvironment environment)
/*     */   {
/*  95 */     super.setEnvironment(environment);
/*  96 */     this.reader.setEnvironment(environment);
/*  97 */     this.scanner.setEnvironment(environment);
/*     */   }
/*     */ 
/*     */   public void setBeanNameGenerator(BeanNameGenerator beanNameGenerator)
/*     */   {
/* 110 */     this.reader.setBeanNameGenerator(beanNameGenerator);
/* 111 */     this.scanner.setBeanNameGenerator(beanNameGenerator);
/* 112 */     getBeanFactory().registerSingleton("org.springframework.context.annotation.internalConfigurationBeanNameGenerator", beanNameGenerator);
/*     */   }
/*     */ 
/*     */   public void setScopeMetadataResolver(ScopeMetadataResolver scopeMetadataResolver)
/*     */   {
/* 123 */     this.reader.setScopeMetadataResolver(scopeMetadataResolver);
/* 124 */     this.scanner.setScopeMetadataResolver(scopeMetadataResolver);
/*     */   }
/*     */ 
/*     */   public void register(Class<?>[] annotatedClasses)
/*     */   {
/* 139 */     Assert.notEmpty(annotatedClasses, "At least one annotated class must be specified");
/* 140 */     this.reader.register(annotatedClasses);
/*     */   }
/*     */ 
/*     */   public void scan(String[] basePackages)
/*     */   {
/* 152 */     Assert.notEmpty(basePackages, "At least one base package must be specified");
/* 153 */     this.scanner.scan(basePackages);
/*     */   }
/*     */ 
/*     */   protected void prepareRefresh()
/*     */   {
/* 158 */     this.scanner.clearCache();
/* 159 */     super.prepareRefresh();
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.context.annotation.AnnotationConfigApplicationContext
 * JD-Core Version:    0.6.0
 */