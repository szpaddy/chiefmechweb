package org.springframework.context.annotation;

import org.springframework.core.type.AnnotationMetadata;

public abstract interface ImportSelector
{
  public abstract String[] selectImports(AnnotationMetadata paramAnnotationMetadata);
}

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.context.annotation.ImportSelector
 * JD-Core Version:    0.6.0
 */