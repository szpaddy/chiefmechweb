/*    */ package org.springframework.context.annotation;
/*    */ 
/*    */ import java.util.Set;
/*    */ import org.springframework.beans.factory.config.BeanDefinition;
/*    */ import org.springframework.beans.factory.config.BeanDefinitionHolder;
/*    */ import org.springframework.beans.factory.parsing.BeanComponentDefinition;
/*    */ import org.springframework.beans.factory.parsing.CompositeComponentDefinition;
/*    */ import org.springframework.beans.factory.xml.BeanDefinitionParser;
/*    */ import org.springframework.beans.factory.xml.ParserContext;
/*    */ import org.w3c.dom.Element;
/*    */ 
/*    */ public class AnnotationConfigBeanDefinitionParser
/*    */   implements BeanDefinitionParser
/*    */ {
/*    */   public BeanDefinition parse(Element element, ParserContext parserContext)
/*    */   {
/* 42 */     Object source = parserContext.extractSource(element);
/*    */ 
/* 45 */     Set processorDefinitions = AnnotationConfigUtils.registerAnnotationConfigProcessors(parserContext.getRegistry(), source);
/*    */ 
/* 49 */     CompositeComponentDefinition compDefinition = new CompositeComponentDefinition(element.getTagName(), source);
/* 50 */     parserContext.pushContainingComponent(compDefinition);
/*    */ 
/* 53 */     for (BeanDefinitionHolder processorDefinition : processorDefinitions) {
/* 54 */       parserContext.registerComponent(new BeanComponentDefinition(processorDefinition));
/*    */     }
/*    */ 
/* 58 */     parserContext.popAndRegisterContainingComponent();
/*    */ 
/* 60 */     return null;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.context.annotation.AnnotationConfigBeanDefinitionParser
 * JD-Core Version:    0.6.0
 */