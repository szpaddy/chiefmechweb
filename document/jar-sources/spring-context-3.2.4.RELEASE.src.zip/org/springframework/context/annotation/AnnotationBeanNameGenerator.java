/*     */ package org.springframework.context.annotation;
/*     */ 
/*     */ import java.beans.Introspector;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.springframework.beans.factory.annotation.AnnotatedBeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.beans.factory.support.BeanNameGenerator;
/*     */ import org.springframework.core.annotation.AnnotationAttributes;
/*     */ import org.springframework.core.type.AnnotationMetadata;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class AnnotationBeanNameGenerator
/*     */   implements BeanNameGenerator
/*     */ {
/*     */   private static final String COMPONENT_ANNOTATION_CLASSNAME = "org.springframework.stereotype.Component";
/*     */ 
/*     */   public String generateBeanName(BeanDefinition definition, BeanDefinitionRegistry registry)
/*     */   {
/*  68 */     if ((definition instanceof AnnotatedBeanDefinition)) {
/*  69 */       String beanName = determineBeanNameFromAnnotation((AnnotatedBeanDefinition)definition);
/*  70 */       if (StringUtils.hasText(beanName))
/*     */       {
/*  72 */         return beanName;
/*     */       }
/*     */     }
/*     */ 
/*  76 */     return buildDefaultBeanName(definition, registry);
/*     */   }
/*     */ 
/*     */   protected String determineBeanNameFromAnnotation(AnnotatedBeanDefinition annotatedDef)
/*     */   {
/*  85 */     AnnotationMetadata amd = annotatedDef.getMetadata();
/*  86 */     Set types = amd.getAnnotationTypes();
/*  87 */     String beanName = null;
/*  88 */     for (String type : types) {
/*  89 */       AnnotationAttributes attributes = MetadataUtils.attributesFor(amd, type);
/*  90 */       if (isStereotypeWithNameValue(type, amd.getMetaAnnotationTypes(type), attributes)) {
/*  91 */         String value = (String)attributes.get("value");
/*  92 */         if (StringUtils.hasLength(value)) {
/*  93 */           if ((beanName != null) && (!value.equals(beanName))) {
/*  94 */             throw new IllegalStateException("Stereotype annotations suggest inconsistent component names: '" + beanName + "' versus '" + value + "'");
/*     */           }
/*     */ 
/*  97 */           beanName = value;
/*     */         }
/*     */       }
/*     */     }
/* 101 */     return beanName;
/*     */   }
/*     */ 
/*     */   protected boolean isStereotypeWithNameValue(String annotationType, Set<String> metaAnnotationTypes, Map<String, Object> attributes)
/*     */   {
/* 115 */     boolean isStereotype = (annotationType.equals("org.springframework.stereotype.Component")) || ((metaAnnotationTypes != null) && (metaAnnotationTypes.contains("org.springframework.stereotype.Component"))) || (annotationType.equals("javax.annotation.ManagedBean")) || (annotationType.equals("javax.inject.Named"));
/*     */ 
/* 120 */     return (isStereotype) && (attributes != null) && (attributes.containsKey("value")) && ((attributes.get("value") instanceof String));
/*     */   }
/*     */ 
/*     */   protected String buildDefaultBeanName(BeanDefinition definition, BeanDefinitionRegistry registry)
/*     */   {
/* 133 */     return buildDefaultBeanName(definition);
/*     */   }
/*     */ 
/*     */   protected String buildDefaultBeanName(BeanDefinition definition)
/*     */   {
/* 147 */     String shortClassName = ClassUtils.getShortName(definition.getBeanClassName());
/* 148 */     return Introspector.decapitalize(shortClassName);
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.context.annotation.AnnotationBeanNameGenerator
 * JD-Core Version:    0.6.0
 */