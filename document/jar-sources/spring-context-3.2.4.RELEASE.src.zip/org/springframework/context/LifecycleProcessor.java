package org.springframework.context;

public abstract interface LifecycleProcessor extends Lifecycle
{
  public abstract void onRefresh();

  public abstract void onClose();
}

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.context.LifecycleProcessor
 * JD-Core Version:    0.6.0
 */