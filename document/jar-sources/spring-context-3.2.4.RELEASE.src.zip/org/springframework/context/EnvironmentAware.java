package org.springframework.context;

import org.springframework.beans.factory.Aware;
import org.springframework.core.env.Environment;

public abstract interface EnvironmentAware extends Aware
{
  public abstract void setEnvironment(Environment paramEnvironment);
}

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.context.EnvironmentAware
 * JD-Core Version:    0.6.0
 */