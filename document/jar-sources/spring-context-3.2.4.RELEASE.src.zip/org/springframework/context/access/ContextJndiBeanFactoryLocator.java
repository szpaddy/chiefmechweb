/*     */ package org.springframework.context.access;
/*     */ 
/*     */ import javax.naming.NamingException;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.access.BeanFactoryLocator;
/*     */ import org.springframework.beans.factory.access.BeanFactoryReference;
/*     */ import org.springframework.beans.factory.access.BootstrapException;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.support.ClassPathXmlApplicationContext;
/*     */ import org.springframework.jndi.JndiLocatorSupport;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class ContextJndiBeanFactoryLocator extends JndiLocatorSupport
/*     */   implements BeanFactoryLocator
/*     */ {
/*     */   public static final String BEAN_FACTORY_PATH_DELIMITERS = ",; \t\n";
/*     */ 
/*     */   public BeanFactoryReference useBeanFactory(String factoryKey)
/*     */     throws BeansException
/*     */   {
/*     */     try
/*     */     {
/*  62 */       String beanFactoryPath = (String)lookup(factoryKey, String.class);
/*  63 */       if (this.logger.isTraceEnabled()) {
/*  64 */         this.logger.trace("Bean factory path from JNDI environment variable [" + factoryKey + "] is: " + beanFactoryPath);
/*     */       }
/*     */ 
/*  67 */       String[] paths = StringUtils.tokenizeToStringArray(beanFactoryPath, ",; \t\n");
/*  68 */       return createBeanFactory(paths);
/*     */     } catch (NamingException ex) {
/*     */     }
/*  71 */     throw new BootstrapException("Define an environment variable [" + factoryKey + "] containing " + "the class path locations of XML bean definition files", ex);
/*     */   }
/*     */ 
/*     */   protected BeanFactoryReference createBeanFactory(String[] resources)
/*     */     throws BeansException
/*     */   {
/*  90 */     ApplicationContext ctx = createApplicationContext(resources);
/*  91 */     return new ContextBeanFactoryReference(ctx);
/*     */   }
/*     */ 
/*     */   protected ApplicationContext createApplicationContext(String[] resources)
/*     */     throws BeansException
/*     */   {
/* 102 */     return new ClassPathXmlApplicationContext(resources);
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.context.access.ContextJndiBeanFactoryLocator
 * JD-Core Version:    0.6.0
 */