/*    */ package org.springframework.context.access;
/*    */ 
/*    */ import org.springframework.beans.FatalBeanException;
/*    */ import org.springframework.beans.factory.access.BeanFactoryLocator;
/*    */ 
/*    */ public class DefaultLocatorFactory
/*    */ {
/*    */   public static BeanFactoryLocator getInstance()
/*    */     throws FatalBeanException
/*    */   {
/* 36 */     return ContextSingletonBeanFactoryLocator.getInstance();
/*    */   }
/*    */ 
/*    */   public static BeanFactoryLocator getInstance(String selector)
/*    */     throws FatalBeanException
/*    */   {
/* 47 */     return ContextSingletonBeanFactoryLocator.getInstance(selector);
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.context.access.DefaultLocatorFactory
 * JD-Core Version:    0.6.0
 */