/*    */ package org.springframework.ui.context.support;
/*    */ 
/*    */ import org.springframework.ui.context.HierarchicalThemeSource;
/*    */ import org.springframework.ui.context.Theme;
/*    */ import org.springframework.ui.context.ThemeSource;
/*    */ 
/*    */ public class DelegatingThemeSource
/*    */   implements HierarchicalThemeSource
/*    */ {
/*    */   private ThemeSource parentThemeSource;
/*    */ 
/*    */   public void setParentThemeSource(ThemeSource parentThemeSource)
/*    */   {
/* 40 */     this.parentThemeSource = parentThemeSource;
/*    */   }
/*    */ 
/*    */   public ThemeSource getParentThemeSource() {
/* 44 */     return this.parentThemeSource;
/*    */   }
/*    */ 
/*    */   public Theme getTheme(String themeName)
/*    */   {
/* 49 */     if (this.parentThemeSource != null) {
/* 50 */       return this.parentThemeSource.getTheme(themeName);
/*    */     }
/*    */ 
/* 53 */     return null;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.ui.context.support.DelegatingThemeSource
 * JD-Core Version:    0.6.0
 */