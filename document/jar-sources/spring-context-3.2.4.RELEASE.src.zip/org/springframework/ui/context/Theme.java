package org.springframework.ui.context;

import org.springframework.context.MessageSource;

public abstract interface Theme
{
  public abstract String getName();

  public abstract MessageSource getMessageSource();
}

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.ui.context.Theme
 * JD-Core Version:    0.6.0
 */