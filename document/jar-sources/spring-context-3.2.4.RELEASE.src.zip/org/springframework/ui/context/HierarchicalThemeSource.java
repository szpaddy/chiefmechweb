package org.springframework.ui.context;

public abstract interface HierarchicalThemeSource extends ThemeSource
{
  public abstract void setParentThemeSource(ThemeSource paramThemeSource);

  public abstract ThemeSource getParentThemeSource();
}

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.ui.context.HierarchicalThemeSource
 * JD-Core Version:    0.6.0
 */