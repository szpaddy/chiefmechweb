package org.springframework.format;

import java.text.ParseException;
import java.util.Locale;

public abstract interface Parser<T>
{
  public abstract T parse(String paramString, Locale paramLocale)
    throws ParseException;
}

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.format.Parser
 * JD-Core Version:    0.6.0
 */