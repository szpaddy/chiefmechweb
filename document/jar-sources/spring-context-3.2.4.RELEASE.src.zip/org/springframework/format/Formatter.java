package org.springframework.format;

public abstract interface Formatter<T> extends Printer<T>, Parser<T>
{
}

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.format.Formatter
 * JD-Core Version:    0.6.0
 */