package org.springframework.format;

import java.lang.annotation.Annotation;
import java.util.Set;

public abstract interface AnnotationFormatterFactory<A extends Annotation>
{
  public abstract Set<Class<?>> getFieldTypes();

  public abstract Printer<?> getPrinter(A paramA, Class<?> paramClass);

  public abstract Parser<?> getParser(A paramA, Class<?> paramClass);
}

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.format.AnnotationFormatterFactory
 * JD-Core Version:    0.6.0
 */