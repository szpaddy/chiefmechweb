/*     */ package org.springframework.format.datetime;
/*     */ 
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import org.springframework.core.convert.converter.Converter;
/*     */ import org.springframework.core.convert.converter.ConverterRegistry;
/*     */ import org.springframework.format.FormatterRegistrar;
/*     */ import org.springframework.format.FormatterRegistry;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public class DateFormatterRegistrar
/*     */   implements FormatterRegistrar
/*     */ {
/*     */   private DateFormatter dateFormatter;
/*     */ 
/*     */   public void setFormatter(DateFormatter dateFormatter)
/*     */   {
/*  51 */     Assert.notNull(dateFormatter, "DateFormatter must not be null");
/*  52 */     this.dateFormatter = dateFormatter;
/*     */   }
/*     */ 
/*     */   public void registerFormatters(FormatterRegistry registry)
/*     */   {
/*  57 */     addDateConverters(registry);
/*  58 */     registry.addFormatterForFieldAnnotation(new DateTimeFormatAnnotationFormatterFactory());
/*     */ 
/*  62 */     if (this.dateFormatter != null) {
/*  63 */       registry.addFormatter(this.dateFormatter);
/*  64 */       registry.addFormatterForFieldType(Calendar.class, this.dateFormatter);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void addDateConverters(ConverterRegistry converterRegistry)
/*     */   {
/*  73 */     converterRegistry.addConverter(new DateToLongConverter(null));
/*  74 */     converterRegistry.addConverter(new DateToCalendarConverter(null));
/*  75 */     converterRegistry.addConverter(new CalendarToDateConverter(null));
/*  76 */     converterRegistry.addConverter(new CalendarToLongConverter(null));
/*  77 */     converterRegistry.addConverter(new LongToDateConverter(null));
/*  78 */     converterRegistry.addConverter(new LongToCalendarConverter(null));
/*     */   }
/*     */ 
/*     */   private static class LongToCalendarConverter
/*     */     implements Converter<Long, Calendar>
/*     */   {
/* 126 */     private final DateFormatterRegistrar.DateToCalendarConverter dateToCalendarConverter = new DateFormatterRegistrar.DateToCalendarConverter(null);
/*     */ 
/*     */     public Calendar convert(Long source) {
/* 129 */       return this.dateToCalendarConverter.convert(new Date(source.longValue()));
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class LongToDateConverter
/*     */     implements Converter<Long, Date>
/*     */   {
/*     */     public Date convert(Long source)
/*     */     {
/* 119 */       return new Date(source.longValue());
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class CalendarToLongConverter
/*     */     implements Converter<Calendar, Long>
/*     */   {
/*     */     public Long convert(Calendar source)
/*     */     {
/* 111 */       return Long.valueOf(source.getTime().getTime());
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class CalendarToDateConverter
/*     */     implements Converter<Calendar, Date>
/*     */   {
/*     */     public Date convert(Calendar source)
/*     */     {
/* 103 */       return source.getTime();
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class DateToCalendarConverter
/*     */     implements Converter<Date, Calendar>
/*     */   {
/*     */     public Calendar convert(Date source)
/*     */     {
/*  93 */       Calendar calendar = Calendar.getInstance();
/*  94 */       calendar.setTime(source);
/*  95 */       return calendar;
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class DateToLongConverter
/*     */     implements Converter<Date, Long>
/*     */   {
/*     */     public Long convert(Date source)
/*     */     {
/*  85 */       return Long.valueOf(source.getTime());
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.format.datetime.DateFormatterRegistrar
 * JD-Core Version:    0.6.0
 */