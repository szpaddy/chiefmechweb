/*    */ package org.springframework.format.datetime.joda;
/*    */ 
/*    */ import java.util.Locale;
/*    */ import org.joda.time.ReadableInstant;
/*    */ import org.joda.time.format.DateTimeFormatter;
/*    */ import org.springframework.format.Printer;
/*    */ 
/*    */ public final class ReadableInstantPrinter
/*    */   implements Printer<ReadableInstant>
/*    */ {
/*    */   private final DateTimeFormatter formatter;
/*    */ 
/*    */   public ReadableInstantPrinter(DateTimeFormatter formatter)
/*    */   {
/* 40 */     this.formatter = formatter;
/*    */   }
/*    */ 
/*    */   public String print(ReadableInstant instant, Locale locale) {
/* 44 */     return JodaTimeContextHolder.getFormatter(this.formatter, locale).print(instant);
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.format.datetime.joda.ReadableInstantPrinter
 * JD-Core Version:    0.6.0
 */