/*     */ package org.springframework.format.datetime.joda;
/*     */ 
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import org.joda.time.DateMidnight;
/*     */ import org.joda.time.DateTime;
/*     */ import org.joda.time.Instant;
/*     */ import org.joda.time.LocalDate;
/*     */ import org.joda.time.LocalDateTime;
/*     */ import org.joda.time.LocalTime;
/*     */ import org.joda.time.MutableDateTime;
/*     */ import org.joda.time.ReadableInstant;
/*     */ import org.springframework.core.convert.converter.Converter;
/*     */ import org.springframework.core.convert.converter.ConverterRegistry;
/*     */ import org.springframework.format.datetime.DateFormatterRegistrar;
/*     */ 
/*     */ final class JodaTimeConverters
/*     */ {
/*     */   public static void registerConverters(ConverterRegistry registry)
/*     */   {
/*  50 */     DateFormatterRegistrar.addDateConverters(registry);
/*  51 */     registry.addConverter(new DateTimeToLocalDateConverter(null));
/*  52 */     registry.addConverter(new DateTimeToLocalTimeConverter(null));
/*  53 */     registry.addConverter(new DateTimeToLocalDateTimeConverter(null));
/*  54 */     registry.addConverter(new DateTimeToDateMidnightConverter(null));
/*  55 */     registry.addConverter(new DateTimeToMutableDateTimeConverter(null));
/*  56 */     registry.addConverter(new DateTimeToInstantConverter(null));
/*  57 */     registry.addConverter(new DateTimeToDateConverter(null));
/*  58 */     registry.addConverter(new DateTimeToCalendarConverter(null));
/*  59 */     registry.addConverter(new DateTimeToLongConverter(null));
/*  60 */     registry.addConverter(new DateToReadableInstantConverter(null));
/*  61 */     registry.addConverter(new CalendarToReadableInstantConverter(null));
/*     */   }
/*     */ 
/*     */   private static class CalendarToReadableInstantConverter
/*     */     implements Converter<Calendar, ReadableInstant>
/*     */   {
/*     */     public ReadableInstant convert(Calendar source)
/*     */     {
/* 158 */       return new DateTime(source);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class DateToReadableInstantConverter
/*     */     implements Converter<Date, ReadableInstant>
/*     */   {
/*     */     public ReadableInstant convert(Date source)
/*     */     {
/* 145 */       return new DateTime(source);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class DateTimeToLongConverter
/*     */     implements Converter<DateTime, Long>
/*     */   {
/*     */     public Long convert(DateTime source)
/*     */     {
/* 132 */       return Long.valueOf(source.getMillis());
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class DateTimeToCalendarConverter
/*     */     implements Converter<DateTime, Calendar>
/*     */   {
/*     */     public Calendar convert(DateTime source)
/*     */     {
/* 124 */       return source.toGregorianCalendar();
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class DateTimeToDateConverter
/*     */     implements Converter<DateTime, Date>
/*     */   {
/*     */     public Date convert(DateTime source)
/*     */     {
/* 116 */       return source.toDate();
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class DateTimeToInstantConverter
/*     */     implements Converter<DateTime, Instant>
/*     */   {
/*     */     public Instant convert(DateTime source)
/*     */     {
/* 108 */       return source.toInstant();
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class DateTimeToMutableDateTimeConverter
/*     */     implements Converter<DateTime, MutableDateTime>
/*     */   {
/*     */     public MutableDateTime convert(DateTime source)
/*     */     {
/* 100 */       return source.toMutableDateTime();
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class DateTimeToDateMidnightConverter
/*     */     implements Converter<DateTime, DateMidnight>
/*     */   {
/*     */     public DateMidnight convert(DateTime source)
/*     */     {
/*  92 */       return source.toDateMidnight();
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class DateTimeToLocalDateTimeConverter
/*     */     implements Converter<DateTime, LocalDateTime>
/*     */   {
/*     */     public LocalDateTime convert(DateTime source)
/*     */     {
/*  84 */       return source.toLocalDateTime();
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class DateTimeToLocalTimeConverter
/*     */     implements Converter<DateTime, LocalTime>
/*     */   {
/*     */     public LocalTime convert(DateTime source)
/*     */     {
/*  76 */       return source.toLocalTime();
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class DateTimeToLocalDateConverter
/*     */     implements Converter<DateTime, LocalDate>
/*     */   {
/*     */     public LocalDate convert(DateTime source)
/*     */     {
/*  68 */       return source.toLocalDate();
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.format.datetime.joda.JodaTimeConverters
 * JD-Core Version:    0.6.0
 */