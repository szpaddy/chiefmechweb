/*    */ package org.springframework.format.datetime.joda;
/*    */ 
/*    */ import java.util.Locale;
/*    */ import org.joda.time.format.DateTimeFormatter;
/*    */ import org.springframework.core.NamedThreadLocal;
/*    */ 
/*    */ public final class JodaTimeContextHolder
/*    */ {
/* 35 */   private static final ThreadLocal<JodaTimeContext> jodaTimeContextHolder = new NamedThreadLocal("JodaTime Context");
/*    */ 
/*    */   public static void resetJodaTimeContext()
/*    */   {
/* 43 */     jodaTimeContextHolder.remove();
/*    */   }
/*    */ 
/*    */   public static void setJodaTimeContext(JodaTimeContext jodaTimeContext)
/*    */   {
/* 52 */     if (jodaTimeContext == null) {
/* 53 */       resetJodaTimeContext();
/*    */     }
/*    */     else
/* 56 */       jodaTimeContextHolder.set(jodaTimeContext);
/*    */   }
/*    */ 
/*    */   public static JodaTimeContext getJodaTimeContext()
/*    */   {
/* 65 */     return (JodaTimeContext)jodaTimeContextHolder.get();
/*    */   }
/*    */ 
/*    */   public static DateTimeFormatter getFormatter(DateTimeFormatter formatter, Locale locale)
/*    */   {
/* 77 */     DateTimeFormatter formatterToUse = locale != null ? formatter.withLocale(locale) : formatter;
/* 78 */     JodaTimeContext context = getJodaTimeContext();
/* 79 */     return context != null ? context.getFormatter(formatterToUse) : formatterToUse;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.format.datetime.joda.JodaTimeContextHolder
 * JD-Core Version:    0.6.0
 */