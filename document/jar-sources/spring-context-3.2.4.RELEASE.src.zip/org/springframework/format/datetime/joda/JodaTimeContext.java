/*    */ package org.springframework.format.datetime.joda;
/*    */ 
/*    */ import org.joda.time.Chronology;
/*    */ import org.joda.time.DateTimeZone;
/*    */ import org.joda.time.format.DateTimeFormatter;
/*    */ 
/*    */ public class JodaTimeContext
/*    */ {
/*    */   private Chronology chronology;
/*    */   private DateTimeZone timeZone;
/*    */ 
/*    */   public void setChronology(Chronology chronology)
/*    */   {
/* 44 */     this.chronology = chronology;
/*    */   }
/*    */ 
/*    */   public Chronology getChronology()
/*    */   {
/* 51 */     return this.chronology;
/*    */   }
/*    */ 
/*    */   public void setTimeZone(DateTimeZone timeZone)
/*    */   {
/* 58 */     this.timeZone = timeZone;
/*    */   }
/*    */ 
/*    */   public DateTimeZone getTimeZone()
/*    */   {
/* 65 */     return this.timeZone;
/*    */   }
/*    */ 
/*    */   public DateTimeFormatter getFormatter(DateTimeFormatter formatter)
/*    */   {
/* 77 */     if (this.chronology != null) {
/* 78 */       formatter = formatter.withChronology(this.chronology);
/*    */     }
/* 80 */     if (this.timeZone != null) {
/* 81 */       formatter = formatter.withZone(this.timeZone);
/*    */     }
/* 83 */     return formatter;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.format.datetime.joda.JodaTimeContext
 * JD-Core Version:    0.6.0
 */