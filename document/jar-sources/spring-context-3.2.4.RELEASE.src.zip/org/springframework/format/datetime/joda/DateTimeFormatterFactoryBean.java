/*    */ package org.springframework.format.datetime.joda;
/*    */ 
/*    */ import org.joda.time.format.DateTimeFormatter;
/*    */ import org.springframework.beans.factory.FactoryBean;
/*    */ import org.springframework.beans.factory.InitializingBean;
/*    */ 
/*    */ public class DateTimeFormatterFactoryBean extends DateTimeFormatterFactory
/*    */   implements FactoryBean<DateTimeFormatter>, InitializingBean
/*    */ {
/*    */   private DateTimeFormatter dateTimeFormatter;
/*    */ 
/*    */   public void afterPropertiesSet()
/*    */   {
/* 43 */     this.dateTimeFormatter = createDateTimeFormatter();
/*    */   }
/*    */ 
/*    */   public DateTimeFormatter getObject() {
/* 47 */     return this.dateTimeFormatter;
/*    */   }
/*    */ 
/*    */   public Class<?> getObjectType() {
/* 51 */     return DateTimeFormatter.class;
/*    */   }
/*    */ 
/*    */   public boolean isSingleton() {
/* 55 */     return true;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.format.datetime.joda.DateTimeFormatterFactoryBean
 * JD-Core Version:    0.6.0
 */