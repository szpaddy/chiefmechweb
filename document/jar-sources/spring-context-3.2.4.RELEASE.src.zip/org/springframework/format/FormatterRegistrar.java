package org.springframework.format;

public abstract interface FormatterRegistrar
{
  public abstract void registerFormatters(FormatterRegistry paramFormatterRegistry);
}

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.format.FormatterRegistrar
 * JD-Core Version:    0.6.0
 */