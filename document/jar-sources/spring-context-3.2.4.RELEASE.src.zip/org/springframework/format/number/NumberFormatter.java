/*    */ package org.springframework.format.number;
/*    */ 
/*    */ import java.text.DecimalFormat;
/*    */ import java.text.NumberFormat;
/*    */ import java.util.Locale;
/*    */ 
/*    */ public class NumberFormatter extends AbstractNumberFormatter
/*    */ {
/*    */   private String pattern;
/*    */ 
/*    */   public NumberFormatter()
/*    */   {
/*    */   }
/*    */ 
/*    */   public NumberFormatter(String pattern)
/*    */   {
/* 54 */     this.pattern = pattern;
/*    */   }
/*    */ 
/*    */   public void setPattern(String pattern)
/*    */   {
/* 64 */     this.pattern = pattern;
/*    */   }
/*    */ 
/*    */   public NumberFormat getNumberFormat(Locale locale)
/*    */   {
/* 69 */     NumberFormat format = NumberFormat.getInstance(locale);
/* 70 */     if (!(format instanceof DecimalFormat)) {
/* 71 */       if (this.pattern != null) {
/* 72 */         throw new IllegalStateException("Cannot support pattern for non-DecimalFormat: " + format);
/*    */       }
/* 74 */       return format;
/*    */     }
/* 76 */     DecimalFormat decimalFormat = (DecimalFormat)format;
/* 77 */     decimalFormat.setParseBigDecimal(true);
/* 78 */     if (this.pattern != null) {
/* 79 */       decimalFormat.applyPattern(this.pattern);
/*    */     }
/* 81 */     return decimalFormat;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.format.number.NumberFormatter
 * JD-Core Version:    0.6.0
 */