/*     */ package org.springframework.format.number;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import java.math.RoundingMode;
/*     */ import java.text.DecimalFormat;
/*     */ import java.text.NumberFormat;
/*     */ import java.text.ParseException;
/*     */ import java.util.Currency;
/*     */ import java.util.Locale;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ public class CurrencyFormatter extends AbstractNumberFormatter
/*     */ {
/*  44 */   private static final boolean roundingModeOnDecimalFormat = ClassUtils.hasMethod(DecimalFormat.class, "setRoundingMode", new Class[] { RoundingMode.class });
/*     */ 
/*  47 */   private int fractionDigits = 2;
/*     */   private RoundingMode roundingMode;
/*     */   private Currency currency;
/*     */ 
/*     */   public void setFractionDigits(int fractionDigits)
/*     */   {
/*  59 */     this.fractionDigits = fractionDigits;
/*     */   }
/*     */ 
/*     */   public void setRoundingMode(RoundingMode roundingMode)
/*     */   {
/*  67 */     this.roundingMode = roundingMode;
/*     */   }
/*     */ 
/*     */   public void setCurrency(Currency currency)
/*     */   {
/*  74 */     this.currency = currency;
/*     */   }
/*     */ 
/*     */   public BigDecimal parse(String text, Locale locale) throws ParseException
/*     */   {
/*  79 */     BigDecimal decimal = (BigDecimal)super.parse(text, locale);
/*  80 */     if (decimal != null) {
/*  81 */       if (this.roundingMode != null) {
/*  82 */         decimal = decimal.setScale(this.fractionDigits, this.roundingMode);
/*     */       }
/*     */       else {
/*  85 */         decimal = decimal.setScale(this.fractionDigits);
/*     */       }
/*     */     }
/*  88 */     return decimal;
/*     */   }
/*     */ 
/*     */   protected NumberFormat getNumberFormat(Locale locale) {
/*  92 */     DecimalFormat format = (DecimalFormat)NumberFormat.getCurrencyInstance(locale);
/*  93 */     format.setParseBigDecimal(true);
/*  94 */     format.setMaximumFractionDigits(this.fractionDigits);
/*  95 */     format.setMinimumFractionDigits(this.fractionDigits);
/*  96 */     if ((this.roundingMode != null) && (roundingModeOnDecimalFormat)) {
/*  97 */       format.setRoundingMode(this.roundingMode);
/*     */     }
/*  99 */     if (this.currency != null) {
/* 100 */       format.setCurrency(this.currency);
/*     */     }
/* 102 */     return format;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.format.number.CurrencyFormatter
 * JD-Core Version:    0.6.0
 */