/*    */ package org.springframework.format.number;
/*    */ 
/*    */ import java.text.NumberFormat;
/*    */ import java.text.ParseException;
/*    */ import java.text.ParsePosition;
/*    */ import java.util.Locale;
/*    */ import org.springframework.format.Formatter;
/*    */ 
/*    */ public abstract class AbstractNumberFormatter
/*    */   implements Formatter<Number>
/*    */ {
/* 36 */   private boolean lenient = false;
/*    */ 
/*    */   public void setLenient(boolean lenient)
/*    */   {
/* 44 */     this.lenient = lenient;
/*    */   }
/*    */ 
/*    */   public String print(Number number, Locale locale) {
/* 48 */     return getNumberFormat(locale).format(number);
/*    */   }
/*    */ 
/*    */   public Number parse(String text, Locale locale) throws ParseException {
/* 52 */     NumberFormat format = getNumberFormat(locale);
/* 53 */     ParsePosition position = new ParsePosition(0);
/* 54 */     Number number = format.parse(text, position);
/* 55 */     if (position.getErrorIndex() != -1) {
/* 56 */       throw new ParseException(text, position.getIndex());
/*    */     }
/* 58 */     if ((!this.lenient) && 
/* 59 */       (text.length() != position.getIndex()))
/*    */     {
/* 61 */       throw new ParseException(text, position.getIndex());
/*    */     }
/*    */ 
/* 64 */     return number;
/*    */   }
/*    */ 
/*    */   protected abstract NumberFormat getNumberFormat(Locale paramLocale);
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.format.number.AbstractNumberFormatter
 * JD-Core Version:    0.6.0
 */