/*     */ package org.springframework.jndi;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import javax.naming.Context;
/*     */ import javax.naming.NamingException;
/*     */ import org.aopalliance.intercept.MethodInterceptor;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.aop.framework.ProxyFactory;
/*     */ import org.springframework.beans.factory.BeanClassLoaderAware;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ public class JndiObjectFactoryBean extends JndiObjectLocator
/*     */   implements FactoryBean<Object>, BeanClassLoaderAware
/*     */ {
/*     */   private Class[] proxyInterfaces;
/*     */   private boolean lookupOnStartup;
/*     */   private boolean cache;
/*     */   private boolean exposeAccessContext;
/*     */   private Object defaultObject;
/*     */   private ClassLoader beanClassLoader;
/*     */   private Object jndiObject;
/*     */ 
/*     */   public JndiObjectFactoryBean()
/*     */   {
/*  68 */     this.lookupOnStartup = true;
/*     */ 
/*  70 */     this.cache = true;
/*     */ 
/*  72 */     this.exposeAccessContext = false;
/*     */ 
/*  76 */     this.beanClassLoader = ClassUtils.getDefaultClassLoader();
/*     */   }
/*     */ 
/*     */   public void setProxyInterface(Class proxyInterface)
/*     */   {
/*  91 */     this.proxyInterfaces = new Class[] { proxyInterface };
/*     */   }
/*     */ 
/*     */   public void setProxyInterfaces(Class[] proxyInterfaces)
/*     */   {
/* 104 */     this.proxyInterfaces = proxyInterfaces;
/*     */   }
/*     */ 
/*     */   public void setLookupOnStartup(boolean lookupOnStartup)
/*     */   {
/* 116 */     this.lookupOnStartup = lookupOnStartup;
/*     */   }
/*     */ 
/*     */   public void setCache(boolean cache)
/*     */   {
/* 129 */     this.cache = cache;
/*     */   }
/*     */ 
/*     */   public void setExposeAccessContext(boolean exposeAccessContext)
/*     */   {
/* 142 */     this.exposeAccessContext = exposeAccessContext;
/*     */   }
/*     */ 
/*     */   public void setDefaultObject(Object defaultObject)
/*     */   {
/* 155 */     this.defaultObject = defaultObject;
/*     */   }
/*     */ 
/*     */   public void setBeanClassLoader(ClassLoader classLoader) {
/* 159 */     this.beanClassLoader = classLoader;
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */     throws IllegalArgumentException, NamingException
/*     */   {
/* 168 */     super.afterPropertiesSet();
/*     */ 
/* 170 */     if ((this.proxyInterfaces != null) || (!this.lookupOnStartup) || (!this.cache) || (this.exposeAccessContext))
/*     */     {
/* 172 */       if (this.defaultObject != null) {
/* 173 */         throw new IllegalArgumentException("'defaultObject' is not supported in combination with 'proxyInterface'");
/*     */       }
/*     */ 
/* 177 */       this.jndiObject = JndiObjectProxyFactory.access$000(this);
/*     */     }
/*     */     else {
/* 180 */       if ((this.defaultObject != null) && (getExpectedType() != null) && (!getExpectedType().isInstance(this.defaultObject)))
/*     */       {
/* 182 */         throw new IllegalArgumentException("Default object [" + this.defaultObject + "] of type [" + this.defaultObject.getClass().getName() + "] is not of expected type [" + getExpectedType().getName() + "]");
/*     */       }
/*     */ 
/* 187 */       this.jndiObject = lookupWithFallback();
/*     */     }
/*     */   }
/*     */ 
/*     */   protected Object lookupWithFallback()
/*     */     throws NamingException
/*     */   {
/* 199 */     ClassLoader originalClassLoader = ClassUtils.overrideThreadContextClassLoader(this.beanClassLoader);
/*     */     try {
/* 201 */       Object localObject1 = lookup();
/*     */       return localObject1;
/*     */     }
/*     */     catch (TypeMismatchNamingException ex)
/*     */     {
/* 206 */       throw ex;
/*     */     }
/*     */     catch (NamingException ex) {
/* 209 */       if (this.defaultObject != null) {
/* 210 */         if (this.logger.isDebugEnabled()) {
/* 211 */           this.logger.debug("JNDI lookup failed - returning specified default object instead", ex);
/*     */         }
/* 213 */         else if (this.logger.isInfoEnabled()) {
/* 214 */           this.logger.info("JNDI lookup failed - returning specified default object instead: " + ex);
/*     */         }
/* 216 */         Object localObject2 = this.defaultObject;
/*     */         return localObject2;
/*     */       }
/* 218 */       throw ex;
/*     */     }
/*     */     finally {
/* 221 */       if (originalClassLoader != null)
/* 222 */         Thread.currentThread().setContextClassLoader(originalClassLoader); 
/* 222 */     }throw localObject3;
/*     */   }
/*     */ 
/*     */   public Object getObject()
/*     */   {
/* 232 */     return this.jndiObject;
/*     */   }
/*     */ 
/*     */   public Class<?> getObjectType() {
/* 236 */     if (this.proxyInterfaces != null) {
/* 237 */       if (this.proxyInterfaces.length == 1) {
/* 238 */         return this.proxyInterfaces[0];
/*     */       }
/* 240 */       if (this.proxyInterfaces.length > 1) {
/* 241 */         return createCompositeInterface(this.proxyInterfaces);
/*     */       }
/*     */     }
/* 244 */     if (this.jndiObject != null) {
/* 245 */       return this.jndiObject.getClass();
/*     */     }
/*     */ 
/* 248 */     return getExpectedType();
/*     */   }
/*     */ 
/*     */   public boolean isSingleton()
/*     */   {
/* 253 */     return true;
/*     */   }
/*     */ 
/*     */   protected Class createCompositeInterface(Class[] interfaces)
/*     */   {
/* 267 */     return ClassUtils.createCompositeInterface(interfaces, this.beanClassLoader);
/*     */   }
/*     */ 
/*     */   private static class JndiContextExposingInterceptor
/*     */     implements MethodInterceptor
/*     */   {
/*     */     private final JndiTemplate jndiTemplate;
/*     */ 
/*     */     public JndiContextExposingInterceptor(JndiTemplate jndiTemplate)
/*     */     {
/* 323 */       this.jndiTemplate = jndiTemplate;
/*     */     }
/*     */ 
/*     */     public Object invoke(MethodInvocation invocation) throws Throwable {
/* 327 */       Context ctx = isEligible(invocation.getMethod()) ? this.jndiTemplate.getContext() : null;
/*     */       try {
/* 329 */         Object localObject1 = invocation.proceed();
/*     */         return localObject1; } finally { this.jndiTemplate.releaseContext(ctx); } throw localObject2;
/*     */     }
/*     */ 
/*     */     protected boolean isEligible(Method method)
/*     */     {
/* 337 */       return !Object.class.equals(method.getDeclaringClass());
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class JndiObjectProxyFactory
/*     */   {
/*     */     private static Object createJndiObjectProxy(JndiObjectFactoryBean jof)
/*     */       throws NamingException
/*     */     {
/* 278 */       JndiObjectTargetSource targetSource = new JndiObjectTargetSource();
/* 279 */       targetSource.setJndiTemplate(jof.getJndiTemplate());
/* 280 */       targetSource.setJndiName(jof.getJndiName());
/* 281 */       targetSource.setExpectedType(jof.getExpectedType());
/* 282 */       targetSource.setResourceRef(jof.isResourceRef());
/* 283 */       targetSource.setLookupOnStartup(jof.lookupOnStartup);
/* 284 */       targetSource.setCache(jof.cache);
/* 285 */       targetSource.afterPropertiesSet();
/*     */ 
/* 288 */       ProxyFactory proxyFactory = new ProxyFactory();
/* 289 */       if (jof.proxyInterfaces != null) {
/* 290 */         proxyFactory.setInterfaces(jof.proxyInterfaces);
/*     */       }
/*     */       else {
/* 293 */         Class targetClass = targetSource.getTargetClass();
/* 294 */         if (targetClass == null) {
/* 295 */           throw new IllegalStateException("Cannot deactivate 'lookupOnStartup' without specifying a 'proxyInterface' or 'expectedType'");
/*     */         }
/*     */ 
/* 298 */         Class[] ifcs = ClassUtils.getAllInterfacesForClass(targetClass, jof.beanClassLoader);
/* 299 */         for (Class ifc : ifcs) {
/* 300 */           if (Modifier.isPublic(ifc.getModifiers())) {
/* 301 */             proxyFactory.addInterface(ifc);
/*     */           }
/*     */         }
/*     */       }
/* 305 */       if (jof.exposeAccessContext) {
/* 306 */         proxyFactory.addAdvice(new JndiObjectFactoryBean.JndiContextExposingInterceptor(jof.getJndiTemplate()));
/*     */       }
/* 308 */       proxyFactory.setTargetSource(targetSource);
/* 309 */       return proxyFactory.getProxy(jof.beanClassLoader);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.jndi.JndiObjectFactoryBean
 * JD-Core Version:    0.6.0
 */