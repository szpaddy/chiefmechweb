/*     */ package org.springframework.jndi;
/*     */ 
/*     */ import java.util.Hashtable;
/*     */ import java.util.Properties;
/*     */ import javax.naming.Context;
/*     */ import javax.naming.InitialContext;
/*     */ import javax.naming.NameNotFoundException;
/*     */ import javax.naming.NamingException;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ 
/*     */ public class JndiTemplate
/*     */ {
/*  43 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   private Properties environment;
/*     */ 
/*     */   public JndiTemplate()
/*     */   {
/*     */   }
/*     */ 
/*     */   public JndiTemplate(Properties environment)
/*     */   {
/*  58 */     this.environment = environment;
/*     */   }
/*     */ 
/*     */   public void setEnvironment(Properties environment)
/*     */   {
/*  66 */     this.environment = environment;
/*     */   }
/*     */ 
/*     */   public Properties getEnvironment()
/*     */   {
/*  73 */     return this.environment;
/*     */   }
/*     */ 
/*     */   public <T> T execute(JndiCallback<T> contextCallback)
/*     */     throws NamingException
/*     */   {
/*  85 */     Context ctx = getContext();
/*     */     try {
/*  87 */       Object localObject1 = contextCallback.doInContext(ctx);
/*     */       return localObject1; } finally { releaseContext(ctx); } throw localObject2;
/*     */   }
/*     */ 
/*     */   public Context getContext()
/*     */     throws NamingException
/*     */   {
/* 103 */     return createInitialContext();
/*     */   }
/*     */ 
/*     */   public void releaseContext(Context ctx)
/*     */   {
/* 112 */     if (ctx != null)
/*     */       try {
/* 114 */         ctx.close();
/*     */       }
/*     */       catch (NamingException ex) {
/* 117 */         this.logger.debug("Could not close JNDI InitialContext", ex);
/*     */       }
/*     */   }
/*     */ 
/*     */   protected Context createInitialContext()
/*     */     throws NamingException
/*     */   {
/* 130 */     Hashtable icEnv = null;
/* 131 */     Properties env = getEnvironment();
/* 132 */     if (env != null) {
/* 133 */       icEnv = new Hashtable(env.size());
/* 134 */       CollectionUtils.mergePropertiesIntoMap(env, icEnv);
/*     */     }
/* 136 */     return new InitialContext(icEnv);
/*     */   }
/*     */ 
/*     */   public Object lookup(String name)
/*     */     throws NamingException
/*     */   {
/* 149 */     if (this.logger.isDebugEnabled()) {
/* 150 */       this.logger.debug("Looking up JNDI object with name [" + name + "]");
/*     */     }
/* 152 */     return execute(new JndiCallback(name) {
/*     */       public Object doInContext(Context ctx) throws NamingException {
/* 154 */         Object located = ctx.lookup(this.val$name);
/* 155 */         if (located == null) {
/* 156 */           throw new NameNotFoundException("JNDI object with [" + this.val$name + "] not found: JNDI implementation returned null");
/*     */         }
/*     */ 
/* 159 */         return located;
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   public <T> T lookup(String name, Class<T> requiredType)
/*     */     throws NamingException
/*     */   {
/* 178 */     Object jndiObject = lookup(name);
/* 179 */     if ((requiredType != null) && (!requiredType.isInstance(jndiObject))) {
/* 180 */       throw new TypeMismatchNamingException(name, requiredType, jndiObject != null ? jndiObject.getClass() : null);
/*     */     }
/*     */ 
/* 183 */     return jndiObject;
/*     */   }
/*     */ 
/*     */   public void bind(String name, Object object)
/*     */     throws NamingException
/*     */   {
/* 193 */     if (this.logger.isDebugEnabled()) {
/* 194 */       this.logger.debug("Binding JNDI object with name [" + name + "]");
/*     */     }
/* 196 */     execute(new JndiCallback(name, object) {
/*     */       public Object doInContext(Context ctx) throws NamingException {
/* 198 */         ctx.bind(this.val$name, this.val$object);
/* 199 */         return null;
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   public void rebind(String name, Object object)
/*     */     throws NamingException
/*     */   {
/* 212 */     if (this.logger.isDebugEnabled()) {
/* 213 */       this.logger.debug("Rebinding JNDI object with name [" + name + "]");
/*     */     }
/* 215 */     execute(new JndiCallback(name, object) {
/*     */       public Object doInContext(Context ctx) throws NamingException {
/* 217 */         ctx.rebind(this.val$name, this.val$object);
/* 218 */         return null;
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   public void unbind(String name)
/*     */     throws NamingException
/*     */   {
/* 229 */     if (this.logger.isDebugEnabled()) {
/* 230 */       this.logger.debug("Unbinding JNDI object with name [" + name + "]");
/*     */     }
/* 232 */     execute(new JndiCallback(name) {
/*     */       public Object doInContext(Context ctx) throws NamingException {
/* 234 */         ctx.unbind(this.val$name);
/* 235 */         return null;
/*     */       }
/*     */     });
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.jndi.JndiTemplate
 * JD-Core Version:    0.6.0
 */