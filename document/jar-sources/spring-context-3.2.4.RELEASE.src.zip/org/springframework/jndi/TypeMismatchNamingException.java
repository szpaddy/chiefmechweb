/*    */ package org.springframework.jndi;
/*    */ 
/*    */ import javax.naming.NamingException;
/*    */ 
/*    */ public class TypeMismatchNamingException extends NamingException
/*    */ {
/*    */   private Class requiredType;
/*    */   private Class actualType;
/*    */ 
/*    */   public TypeMismatchNamingException(String jndiName, Class requiredType, Class actualType)
/*    */   {
/* 45 */     super("Object of type [" + actualType + "] available at JNDI location [" + jndiName + "] is not assignable to [" + requiredType.getName() + "]");
/*    */ 
/* 47 */     this.requiredType = requiredType;
/* 48 */     this.actualType = actualType;
/*    */   }
/*    */ 
/*    */   public TypeMismatchNamingException(String explanation)
/*    */   {
/* 56 */     super(explanation);
/*    */   }
/*    */ 
/*    */   public final Class getRequiredType()
/*    */   {
/* 64 */     return this.requiredType;
/*    */   }
/*    */ 
/*    */   public final Class getActualType()
/*    */   {
/* 71 */     return this.actualType;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.jndi.TypeMismatchNamingException
 * JD-Core Version:    0.6.0
 */