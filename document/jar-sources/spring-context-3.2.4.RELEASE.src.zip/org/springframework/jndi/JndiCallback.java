package org.springframework.jndi;

import javax.naming.Context;
import javax.naming.NamingException;

public abstract interface JndiCallback<T>
{
  public abstract T doInContext(Context paramContext)
    throws NamingException;
}

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.jndi.JndiCallback
 * JD-Core Version:    0.6.0
 */