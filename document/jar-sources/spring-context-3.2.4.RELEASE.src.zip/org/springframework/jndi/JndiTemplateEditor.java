/*    */ package org.springframework.jndi;
/*    */ 
/*    */ import java.beans.PropertyEditorSupport;
/*    */ import java.util.Properties;
/*    */ import org.springframework.beans.propertyeditors.PropertiesEditor;
/*    */ 
/*    */ public class JndiTemplateEditor extends PropertyEditorSupport
/*    */ {
/* 33 */   private final PropertiesEditor propertiesEditor = new PropertiesEditor();
/*    */ 
/*    */   public void setAsText(String text) throws IllegalArgumentException
/*    */   {
/* 37 */     if (text == null) {
/* 38 */       throw new IllegalArgumentException("JndiTemplate cannot be created from null string");
/*    */     }
/* 40 */     if ("".equals(text))
/*    */     {
/* 42 */       setValue(new JndiTemplate());
/*    */     }
/*    */     else
/*    */     {
/* 46 */       this.propertiesEditor.setAsText(text);
/* 47 */       Properties props = (Properties)this.propertiesEditor.getValue();
/* 48 */       setValue(new JndiTemplate(props));
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.jndi.JndiTemplateEditor
 * JD-Core Version:    0.6.0
 */