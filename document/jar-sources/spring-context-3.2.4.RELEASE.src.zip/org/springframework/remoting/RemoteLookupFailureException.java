/*    */ package org.springframework.remoting;
/*    */ 
/*    */ public class RemoteLookupFailureException extends RemoteAccessException
/*    */ {
/*    */   public RemoteLookupFailureException(String msg)
/*    */   {
/* 34 */     super(msg);
/*    */   }
/*    */ 
/*    */   public RemoteLookupFailureException(String msg, Throwable cause)
/*    */   {
/* 43 */     super(msg, cause);
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.remoting.RemoteLookupFailureException
 * JD-Core Version:    0.6.0
 */