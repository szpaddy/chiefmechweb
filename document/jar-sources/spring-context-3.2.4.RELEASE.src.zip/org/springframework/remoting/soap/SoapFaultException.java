/*    */ package org.springframework.remoting.soap;
/*    */ 
/*    */ import javax.xml.namespace.QName;
/*    */ import org.springframework.remoting.RemoteInvocationFailureException;
/*    */ 
/*    */ public abstract class SoapFaultException extends RemoteInvocationFailureException
/*    */ {
/*    */   protected SoapFaultException(String msg, Throwable cause)
/*    */   {
/* 41 */     super(msg, cause);
/*    */   }
/*    */ 
/*    */   public abstract String getFaultCode();
/*    */ 
/*    */   public abstract QName getFaultCodeAsQName();
/*    */ 
/*    */   public abstract String getFaultString();
/*    */ 
/*    */   public abstract String getFaultActor();
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.remoting.soap.SoapFaultException
 * JD-Core Version:    0.6.0
 */