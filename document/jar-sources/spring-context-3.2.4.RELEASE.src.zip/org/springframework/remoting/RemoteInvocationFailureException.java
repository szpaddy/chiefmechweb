/*    */ package org.springframework.remoting;
/*    */ 
/*    */ public class RemoteInvocationFailureException extends RemoteAccessException
/*    */ {
/*    */   public RemoteInvocationFailureException(String msg, Throwable cause)
/*    */   {
/* 37 */     super(msg, cause);
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.remoting.RemoteInvocationFailureException
 * JD-Core Version:    0.6.0
 */