/*     */ package org.springframework.remoting.rmi;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.rmi.RemoteException;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.remoting.support.RemoteInvocation;
/*     */ import org.springframework.remoting.support.RemoteInvocationBasedExporter;
/*     */ import org.springframework.remoting.support.RemoteInvocationResult;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ public abstract class RemoteInvocationSerializingExporter extends RemoteInvocationBasedExporter
/*     */   implements InitializingBean
/*     */ {
/*     */   public static final String CONTENT_TYPE_SERIALIZED_OBJECT = "application/x-java-serialized-object";
/*  58 */   private String contentType = "application/x-java-serialized-object";
/*     */ 
/*  60 */   private boolean acceptProxyClasses = true;
/*     */   private Object proxy;
/*     */ 
/*     */   public void setContentType(String contentType)
/*     */   {
/*  70 */     Assert.notNull(contentType, "'contentType' must not be null");
/*  71 */     this.contentType = contentType;
/*     */   }
/*     */ 
/*     */   public String getContentType()
/*     */   {
/*  78 */     return this.contentType;
/*     */   }
/*     */ 
/*     */   public void setAcceptProxyClasses(boolean acceptProxyClasses)
/*     */   {
/*  86 */     this.acceptProxyClasses = acceptProxyClasses;
/*     */   }
/*     */ 
/*     */   public boolean isAcceptProxyClasses()
/*     */   {
/*  93 */     return this.acceptProxyClasses;
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */   {
/*  98 */     prepare();
/*     */   }
/*     */ 
/*     */   public void prepare()
/*     */   {
/* 105 */     this.proxy = getProxyForService();
/*     */   }
/*     */ 
/*     */   protected final Object getProxy() {
/* 109 */     Assert.notNull(this.proxy, ClassUtils.getShortName(getClass()) + " has not been initialized");
/* 110 */     return this.proxy;
/*     */   }
/*     */ 
/*     */   protected ObjectInputStream createObjectInputStream(InputStream is)
/*     */     throws IOException
/*     */   {
/* 122 */     return new CodebaseAwareObjectInputStream(is, getBeanClassLoader(), isAcceptProxyClasses());
/*     */   }
/*     */ 
/*     */   protected RemoteInvocation doReadRemoteInvocation(ObjectInputStream ois)
/*     */     throws IOException, ClassNotFoundException
/*     */   {
/* 141 */     Object obj = ois.readObject();
/* 142 */     if (!(obj instanceof RemoteInvocation)) {
/* 143 */       throw new RemoteException("Deserialized object needs to be assignable to type [" + RemoteInvocation.class.getName() + "]: " + obj);
/*     */     }
/*     */ 
/* 146 */     return (RemoteInvocation)obj;
/*     */   }
/*     */ 
/*     */   protected ObjectOutputStream createObjectOutputStream(OutputStream os)
/*     */     throws IOException
/*     */   {
/* 158 */     return new ObjectOutputStream(os);
/*     */   }
/*     */ 
/*     */   protected void doWriteRemoteInvocationResult(RemoteInvocationResult result, ObjectOutputStream oos)
/*     */     throws IOException
/*     */   {
/* 175 */     oos.writeObject(result);
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.remoting.rmi.RemoteInvocationSerializingExporter
 * JD-Core Version:    0.6.0
 */