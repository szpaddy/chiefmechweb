/*     */ package org.springframework.remoting.rmi;
/*     */ 
/*     */ import java.rmi.AlreadyBoundException;
/*     */ import java.rmi.NoSuchObjectException;
/*     */ import java.rmi.NotBoundException;
/*     */ import java.rmi.Remote;
/*     */ import java.rmi.RemoteException;
/*     */ import java.rmi.registry.LocateRegistry;
/*     */ import java.rmi.registry.Registry;
/*     */ import java.rmi.server.RMIClientSocketFactory;
/*     */ import java.rmi.server.RMIServerSocketFactory;
/*     */ import java.rmi.server.UnicastRemoteObject;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ 
/*     */ public class RmiServiceExporter extends RmiBasedExporter
/*     */   implements InitializingBean, DisposableBean
/*     */ {
/*     */   private String serviceName;
/*  73 */   private int servicePort = 0;
/*     */   private RMIClientSocketFactory clientSocketFactory;
/*     */   private RMIServerSocketFactory serverSocketFactory;
/*     */   private Registry registry;
/*     */   private String registryHost;
/*  83 */   private int registryPort = 1099;
/*     */   private RMIClientSocketFactory registryClientSocketFactory;
/*     */   private RMIServerSocketFactory registryServerSocketFactory;
/*  89 */   private boolean alwaysCreateRegistry = false;
/*     */ 
/*  91 */   private boolean replaceExistingBinding = true;
/*     */   private Remote exportedObject;
/*  95 */   private boolean createdRegistry = false;
/*     */ 
/*     */   public void setServiceName(String serviceName)
/*     */   {
/* 103 */     this.serviceName = serviceName;
/*     */   }
/*     */ 
/*     */   public void setServicePort(int servicePort)
/*     */   {
/* 111 */     this.servicePort = servicePort;
/*     */   }
/*     */ 
/*     */   public void setClientSocketFactory(RMIClientSocketFactory clientSocketFactory)
/*     */   {
/* 124 */     this.clientSocketFactory = clientSocketFactory;
/*     */   }
/*     */ 
/*     */   public void setServerSocketFactory(RMIServerSocketFactory serverSocketFactory)
/*     */   {
/* 137 */     this.serverSocketFactory = serverSocketFactory;
/*     */   }
/*     */ 
/*     */   public void setRegistry(Registry registry)
/*     */   {
/* 155 */     this.registry = registry;
/*     */   }
/*     */ 
/*     */   public void setRegistryHost(String registryHost)
/*     */   {
/* 164 */     this.registryHost = registryHost;
/*     */   }
/*     */ 
/*     */   public void setRegistryPort(int registryPort)
/*     */   {
/* 174 */     this.registryPort = registryPort;
/*     */   }
/*     */ 
/*     */   public void setRegistryClientSocketFactory(RMIClientSocketFactory registryClientSocketFactory)
/*     */   {
/* 187 */     this.registryClientSocketFactory = registryClientSocketFactory;
/*     */   }
/*     */ 
/*     */   public void setRegistryServerSocketFactory(RMIServerSocketFactory registryServerSocketFactory)
/*     */   {
/* 200 */     this.registryServerSocketFactory = registryServerSocketFactory;
/*     */   }
/*     */ 
/*     */   public void setAlwaysCreateRegistry(boolean alwaysCreateRegistry)
/*     */   {
/* 211 */     this.alwaysCreateRegistry = alwaysCreateRegistry;
/*     */   }
/*     */ 
/*     */   public void setReplaceExistingBinding(boolean replaceExistingBinding)
/*     */   {
/* 224 */     this.replaceExistingBinding = replaceExistingBinding;
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet() throws RemoteException
/*     */   {
/* 229 */     prepare();
/*     */   }
/*     */ 
/*     */   public void prepare()
/*     */     throws RemoteException
/*     */   {
/* 238 */     checkService();
/*     */ 
/* 240 */     if (this.serviceName == null) {
/* 241 */       throw new IllegalArgumentException("Property 'serviceName' is required");
/*     */     }
/*     */ 
/* 245 */     if ((this.clientSocketFactory instanceof RMIServerSocketFactory)) {
/* 246 */       this.serverSocketFactory = ((RMIServerSocketFactory)this.clientSocketFactory);
/*     */     }
/* 248 */     if (((this.clientSocketFactory != null) && (this.serverSocketFactory == null)) || ((this.clientSocketFactory == null) && (this.serverSocketFactory != null)))
/*     */     {
/* 250 */       throw new IllegalArgumentException("Both RMIClientSocketFactory and RMIServerSocketFactory or none required");
/*     */     }
/*     */ 
/* 255 */     if ((this.registryClientSocketFactory instanceof RMIServerSocketFactory)) {
/* 256 */       this.registryServerSocketFactory = ((RMIServerSocketFactory)this.registryClientSocketFactory);
/*     */     }
/* 258 */     if ((this.registryClientSocketFactory == null) && (this.registryServerSocketFactory != null)) {
/* 259 */       throw new IllegalArgumentException("RMIServerSocketFactory without RMIClientSocketFactory for registry not supported");
/*     */     }
/*     */ 
/* 263 */     this.createdRegistry = false;
/*     */ 
/* 266 */     if (this.registry == null) {
/* 267 */       this.registry = getRegistry(this.registryHost, this.registryPort, this.registryClientSocketFactory, this.registryServerSocketFactory);
/*     */ 
/* 269 */       this.createdRegistry = true;
/*     */     }
/*     */ 
/* 273 */     this.exportedObject = getObjectToExport();
/*     */ 
/* 275 */     if (this.logger.isInfoEnabled()) {
/* 276 */       this.logger.info("Binding service '" + this.serviceName + "' to RMI registry: " + this.registry);
/*     */     }
/*     */ 
/* 280 */     if (this.clientSocketFactory != null) {
/* 281 */       UnicastRemoteObject.exportObject(this.exportedObject, this.servicePort, this.clientSocketFactory, this.serverSocketFactory);
/*     */     }
/*     */     else
/*     */     {
/* 285 */       UnicastRemoteObject.exportObject(this.exportedObject, this.servicePort);
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 290 */       if (this.replaceExistingBinding) {
/* 291 */         this.registry.rebind(this.serviceName, this.exportedObject);
/*     */       }
/*     */       else {
/* 294 */         this.registry.bind(this.serviceName, this.exportedObject);
/*     */       }
/*     */     }
/*     */     catch (AlreadyBoundException ex)
/*     */     {
/* 299 */       unexportObjectSilently();
/* 300 */       throw new IllegalStateException("Already an RMI object bound for name '" + this.serviceName + "': " + ex.toString());
/*     */     }
/*     */     catch (RemoteException ex)
/*     */     {
/* 305 */       unexportObjectSilently();
/* 306 */       throw ex;
/*     */     }
/*     */   }
/*     */ 
/*     */   protected Registry getRegistry(String registryHost, int registryPort, RMIClientSocketFactory clientSocketFactory, RMIServerSocketFactory serverSocketFactory)
/*     */     throws RemoteException
/*     */   {
/* 325 */     if (registryHost != null)
/*     */     {
/* 327 */       if (this.logger.isInfoEnabled()) {
/* 328 */         this.logger.info("Looking for RMI registry at port '" + registryPort + "' of host [" + registryHost + "]");
/*     */       }
/* 330 */       Registry reg = LocateRegistry.getRegistry(registryHost, registryPort, clientSocketFactory);
/* 331 */       testRegistry(reg);
/* 332 */       return reg;
/*     */     }
/*     */ 
/* 336 */     return getRegistry(registryPort, clientSocketFactory, serverSocketFactory);
/*     */   }
/*     */ 
/*     */   protected Registry getRegistry(int registryPort, RMIClientSocketFactory clientSocketFactory, RMIServerSocketFactory serverSocketFactory)
/*     */     throws RemoteException
/*     */   {
/* 352 */     if (clientSocketFactory != null) {
/* 353 */       if (this.alwaysCreateRegistry) {
/* 354 */         this.logger.info("Creating new RMI registry");
/* 355 */         return LocateRegistry.createRegistry(registryPort, clientSocketFactory, serverSocketFactory);
/*     */       }
/* 357 */       if (this.logger.isInfoEnabled()) {
/* 358 */         this.logger.info("Looking for RMI registry at port '" + registryPort + "', using custom socket factory");
/*     */       }
/* 360 */       synchronized (LocateRegistry.class)
/*     */       {
/*     */         try {
/* 363 */           Registry reg = LocateRegistry.getRegistry(null, registryPort, clientSocketFactory);
/* 364 */           testRegistry(reg);
/* 365 */           return reg;
/*     */         }
/*     */         catch (RemoteException ex) {
/* 368 */           this.logger.debug("RMI registry access threw exception", ex);
/* 369 */           this.logger.info("Could not detect RMI registry - creating new one");
/*     */ 
/* 371 */           return LocateRegistry.createRegistry(registryPort, clientSocketFactory, serverSocketFactory);
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 377 */     return getRegistry(registryPort);
/*     */   }
/*     */ 
/*     */   protected Registry getRegistry(int registryPort)
/*     */     throws RemoteException
/*     */   {
/* 388 */     if (this.alwaysCreateRegistry) {
/* 389 */       this.logger.info("Creating new RMI registry");
/* 390 */       return LocateRegistry.createRegistry(registryPort);
/*     */     }
/* 392 */     if (this.logger.isInfoEnabled()) {
/* 393 */       this.logger.info("Looking for RMI registry at port '" + registryPort + "'");
/*     */     }
/* 395 */     synchronized (LocateRegistry.class)
/*     */     {
/*     */       try {
/* 398 */         Registry reg = LocateRegistry.getRegistry(registryPort);
/* 399 */         testRegistry(reg);
/* 400 */         return reg;
/*     */       }
/*     */       catch (RemoteException ex) {
/* 403 */         this.logger.debug("RMI registry access threw exception", ex);
/* 404 */         this.logger.info("Could not detect RMI registry - creating new one");
/*     */ 
/* 406 */         return LocateRegistry.createRegistry(registryPort);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void testRegistry(Registry registry)
/*     */     throws RemoteException
/*     */   {
/* 420 */     registry.list();
/*     */   }
/*     */ 
/*     */   public void destroy()
/*     */     throws RemoteException
/*     */   {
/* 428 */     if (this.logger.isInfoEnabled()) {
/* 429 */       this.logger.info("Unbinding RMI service '" + this.serviceName + "' from registry" + (this.createdRegistry ? " at port '" + this.registryPort + "'" : ""));
/*     */     }
/*     */     try
/*     */     {
/* 433 */       this.registry.unbind(this.serviceName);
/*     */     }
/*     */     catch (NotBoundException ex) {
/* 436 */       if (this.logger.isWarnEnabled()) {
/* 437 */         this.logger.warn("RMI service '" + this.serviceName + "' is not bound to registry" + (this.createdRegistry ? " at port '" + this.registryPort + "' anymore" : ""), ex);
/*     */       }
/*     */     }
/*     */     finally
/*     */     {
/* 442 */       unexportObjectSilently();
/*     */     }
/*     */   }
/*     */ 
/*     */   private void unexportObjectSilently()
/*     */   {
/*     */     try
/*     */     {
/* 451 */       UnicastRemoteObject.unexportObject(this.exportedObject, true);
/*     */     }
/*     */     catch (NoSuchObjectException ex) {
/* 454 */       if (this.logger.isWarnEnabled())
/* 455 */         this.logger.warn("RMI object for service '" + this.serviceName + "' isn't exported anymore", ex);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.remoting.rmi.RmiServiceExporter
 * JD-Core Version:    0.6.0
 */