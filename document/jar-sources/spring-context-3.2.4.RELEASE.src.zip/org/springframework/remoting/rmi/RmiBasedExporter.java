/*    */ package org.springframework.remoting.rmi;
/*    */ 
/*    */ import java.lang.reflect.InvocationTargetException;
/*    */ import java.rmi.Remote;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.springframework.remoting.support.RemoteInvocation;
/*    */ import org.springframework.remoting.support.RemoteInvocationBasedExporter;
/*    */ 
/*    */ public abstract class RmiBasedExporter extends RemoteInvocationBasedExporter
/*    */ {
/*    */   protected Remote getObjectToExport()
/*    */   {
/* 51 */     if (((getService() instanceof Remote)) && ((getServiceInterface() == null) || (Remote.class.isAssignableFrom(getServiceInterface()))))
/*    */     {
/* 54 */       return (Remote)getService();
/*    */     }
/*    */ 
/* 58 */     if (this.logger.isDebugEnabled()) {
/* 59 */       this.logger.debug("RMI service [" + getService() + "] is an RMI invoker");
/*    */     }
/* 61 */     return new RmiInvocationWrapper(getProxyForService(), this);
/*    */   }
/*    */ 
/*    */   protected Object invoke(RemoteInvocation invocation, Object targetObject)
/*    */     throws NoSuchMethodException, IllegalAccessException, InvocationTargetException
/*    */   {
/* 73 */     return super.invoke(invocation, targetObject);
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.remoting.rmi.RmiBasedExporter
 * JD-Core Version:    0.6.0
 */