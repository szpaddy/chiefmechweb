/*    */ package org.springframework.remoting.rmi;
/*    */ 
/*    */ import javax.naming.NamingException;
/*    */ import org.springframework.aop.framework.ProxyFactory;
/*    */ import org.springframework.beans.factory.BeanClassLoaderAware;
/*    */ import org.springframework.beans.factory.FactoryBean;
/*    */ import org.springframework.util.ClassUtils;
/*    */ 
/*    */ public class JndiRmiProxyFactoryBean extends JndiRmiClientInterceptor
/*    */   implements FactoryBean<Object>, BeanClassLoaderAware
/*    */ {
/* 67 */   private ClassLoader beanClassLoader = ClassUtils.getDefaultClassLoader();
/*    */   private Object serviceProxy;
/*    */ 
/*    */   public void setBeanClassLoader(ClassLoader classLoader)
/*    */   {
/* 73 */     this.beanClassLoader = classLoader;
/*    */   }
/*    */ 
/*    */   public void afterPropertiesSet() throws NamingException
/*    */   {
/* 78 */     super.afterPropertiesSet();
/* 79 */     if (getServiceInterface() == null) {
/* 80 */       throw new IllegalArgumentException("Property 'serviceInterface' is required");
/*    */     }
/* 82 */     this.serviceProxy = new ProxyFactory(getServiceInterface(), this).getProxy(this.beanClassLoader);
/*    */   }
/*    */ 
/*    */   public Object getObject()
/*    */   {
/* 87 */     return this.serviceProxy;
/*    */   }
/*    */ 
/*    */   public Class<?> getObjectType() {
/* 91 */     return getServiceInterface();
/*    */   }
/*    */ 
/*    */   public boolean isSingleton() {
/* 95 */     return true;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.remoting.rmi.JndiRmiProxyFactoryBean
 * JD-Core Version:    0.6.0
 */