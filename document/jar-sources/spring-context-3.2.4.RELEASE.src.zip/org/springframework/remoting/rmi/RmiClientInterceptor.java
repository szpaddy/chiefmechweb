/*     */ package org.springframework.remoting.rmi;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import java.net.URLStreamHandler;
/*     */ import java.rmi.Naming;
/*     */ import java.rmi.NotBoundException;
/*     */ import java.rmi.Remote;
/*     */ import java.rmi.RemoteException;
/*     */ import java.rmi.registry.LocateRegistry;
/*     */ import java.rmi.registry.Registry;
/*     */ import java.rmi.server.RMIClientSocketFactory;
/*     */ import org.aopalliance.intercept.MethodInterceptor;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.aop.support.AopUtils;
/*     */ import org.springframework.remoting.RemoteConnectFailureException;
/*     */ import org.springframework.remoting.RemoteInvocationFailureException;
/*     */ import org.springframework.remoting.RemoteLookupFailureException;
/*     */ import org.springframework.remoting.support.RemoteInvocationBasedAccessor;
/*     */ import org.springframework.remoting.support.RemoteInvocationUtils;
/*     */ 
/*     */ public class RmiClientInterceptor extends RemoteInvocationBasedAccessor
/*     */   implements MethodInterceptor
/*     */ {
/*     */   private boolean lookupStubOnStartup;
/*     */   private boolean cacheStub;
/*     */   private boolean refreshStubOnConnectFailure;
/*     */   private RMIClientSocketFactory registryClientSocketFactory;
/*     */   private Remote cachedStub;
/*     */   private final Object stubMonitor;
/*     */ 
/*     */   public RmiClientInterceptor()
/*     */   {
/*  73 */     this.lookupStubOnStartup = true;
/*     */ 
/*  75 */     this.cacheStub = true;
/*     */ 
/*  77 */     this.refreshStubOnConnectFailure = false;
/*     */ 
/*  83 */     this.stubMonitor = new Object();
/*     */   }
/*     */ 
/*     */   public void setLookupStubOnStartup(boolean lookupStubOnStartup)
/*     */   {
/*  93 */     this.lookupStubOnStartup = lookupStubOnStartup;
/*     */   }
/*     */ 
/*     */   public void setCacheStub(boolean cacheStub)
/*     */   {
/* 104 */     this.cacheStub = cacheStub;
/*     */   }
/*     */ 
/*     */   public void setRefreshStubOnConnectFailure(boolean refreshStubOnConnectFailure)
/*     */   {
/* 119 */     this.refreshStubOnConnectFailure = refreshStubOnConnectFailure;
/*     */   }
/*     */ 
/*     */   public void setRegistryClientSocketFactory(RMIClientSocketFactory registryClientSocketFactory)
/*     */   {
/* 128 */     this.registryClientSocketFactory = registryClientSocketFactory;
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */   {
/* 134 */     super.afterPropertiesSet();
/* 135 */     prepare();
/*     */   }
/*     */ 
/*     */   public void prepare()
/*     */     throws RemoteLookupFailureException
/*     */   {
/* 146 */     if (this.lookupStubOnStartup) {
/* 147 */       Remote remoteObj = lookupStub();
/* 148 */       if (this.logger.isDebugEnabled()) {
/* 149 */         if ((remoteObj instanceof RmiInvocationHandler)) {
/* 150 */           this.logger.debug("RMI stub [" + getServiceUrl() + "] is an RMI invoker");
/*     */         }
/* 152 */         else if (getServiceInterface() != null) {
/* 153 */           boolean isImpl = getServiceInterface().isInstance(remoteObj);
/* 154 */           this.logger.debug("Using service interface [" + getServiceInterface().getName() + "] for RMI stub [" + getServiceUrl() + "] - " + (!isImpl ? "not " : "") + "directly implemented");
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 159 */       if (this.cacheStub)
/* 160 */         this.cachedStub = remoteObj;
/*     */     }
/*     */   }
/*     */ 
/*     */   protected Remote lookupStub()
/*     */     throws RemoteLookupFailureException
/*     */   {
/*     */     try
/*     */     {
/* 178 */       Remote stub = null;
/* 179 */       if (this.registryClientSocketFactory != null)
/*     */       {
/* 184 */         URL url = new URL(null, getServiceUrl(), new DummyURLStreamHandler(null));
/* 185 */         String protocol = url.getProtocol();
/* 186 */         if ((protocol != null) && (!"rmi".equals(protocol))) {
/* 187 */           throw new MalformedURLException("Invalid URL scheme '" + protocol + "'");
/*     */         }
/* 189 */         String host = url.getHost();
/* 190 */         int port = url.getPort();
/* 191 */         String name = url.getPath();
/* 192 */         if ((name != null) && (name.startsWith("/"))) {
/* 193 */           name = name.substring(1);
/*     */         }
/* 195 */         Registry registry = LocateRegistry.getRegistry(host, port, this.registryClientSocketFactory);
/* 196 */         stub = registry.lookup(name);
/*     */       }
/*     */       else
/*     */       {
/* 200 */         stub = Naming.lookup(getServiceUrl());
/*     */       }
/* 202 */       if (this.logger.isDebugEnabled()) {
/* 203 */         this.logger.debug("Located RMI stub with URL [" + getServiceUrl() + "]");
/*     */       }
/* 205 */       return stub;
/*     */     }
/*     */     catch (MalformedURLException ex) {
/* 208 */       throw new RemoteLookupFailureException("Service URL [" + getServiceUrl() + "] is invalid", ex);
/*     */     }
/*     */     catch (NotBoundException ex) {
/* 211 */       throw new RemoteLookupFailureException("Could not find RMI service [" + getServiceUrl() + "] in RMI registry", ex);
/*     */     }
/*     */     catch (RemoteException ex) {
/*     */     }
/* 215 */     throw new RemoteLookupFailureException("Lookup of RMI stub failed", ex);
/*     */   }
/*     */ 
/*     */   protected Remote getStub()
/*     */     throws RemoteLookupFailureException
/*     */   {
/* 231 */     if ((!this.cacheStub) || ((this.lookupStubOnStartup) && (!this.refreshStubOnConnectFailure))) {
/* 232 */       return this.cachedStub != null ? this.cachedStub : lookupStub();
/*     */     }
/*     */ 
/* 235 */     synchronized (this.stubMonitor) {
/* 236 */       if (this.cachedStub == null) {
/* 237 */         this.cachedStub = lookupStub();
/*     */       }
/* 239 */       return this.cachedStub;
/*     */     }
/*     */   }
/*     */ 
/*     */   public Object invoke(MethodInvocation invocation)
/*     */     throws Throwable
/*     */   {
/* 257 */     Remote stub = getStub();
/*     */     try {
/* 259 */       return doInvoke(invocation, stub);
/*     */     }
/*     */     catch (RemoteConnectFailureException ex) {
/* 262 */       return handleRemoteConnectFailure(invocation, ex);
/*     */     }
/*     */     catch (RemoteException ex) {
/* 265 */       if (isConnectFailure(ex)) {
/* 266 */         return handleRemoteConnectFailure(invocation, ex);
/*     */       }
/*     */     }
/* 269 */     throw ex;
/*     */   }
/*     */ 
/*     */   protected boolean isConnectFailure(RemoteException ex)
/*     */   {
/* 282 */     return RmiClientInterceptorUtils.isConnectFailure(ex);
/*     */   }
/*     */ 
/*     */   private Object handleRemoteConnectFailure(MethodInvocation invocation, Exception ex)
/*     */     throws Throwable
/*     */   {
/* 298 */     if (this.refreshStubOnConnectFailure) {
/* 299 */       String msg = "Could not connect to RMI service [" + getServiceUrl() + "] - retrying";
/* 300 */       if (this.logger.isDebugEnabled()) {
/* 301 */         this.logger.warn(msg, ex);
/*     */       }
/* 303 */       else if (this.logger.isWarnEnabled()) {
/* 304 */         this.logger.warn(msg);
/*     */       }
/* 306 */       return refreshAndRetry(invocation);
/*     */     }
/*     */ 
/* 309 */     throw ex;
/*     */   }
/*     */ 
/*     */   protected Object refreshAndRetry(MethodInvocation invocation)
/*     */     throws Throwable
/*     */   {
/* 322 */     Remote freshStub = null;
/* 323 */     synchronized (this.stubMonitor) {
/* 324 */       this.cachedStub = null;
/* 325 */       freshStub = lookupStub();
/* 326 */       if (this.cacheStub) {
/* 327 */         this.cachedStub = freshStub;
/*     */       }
/*     */     }
/* 330 */     return doInvoke(invocation, freshStub);
/*     */   }
/*     */ 
/*     */   protected Object doInvoke(MethodInvocation invocation, Remote stub)
/*     */     throws Throwable
/*     */   {
/* 341 */     if ((stub instanceof RmiInvocationHandler)) {
/*     */       try
/*     */       {
/* 344 */         return doInvoke(invocation, (RmiInvocationHandler)stub);
/*     */       }
/*     */       catch (RemoteException ex) {
/* 347 */         throw RmiClientInterceptorUtils.convertRmiAccessException(invocation.getMethod(), ex, isConnectFailure(ex), getServiceUrl());
/*     */       }
/*     */       catch (InvocationTargetException ex)
/*     */       {
/* 351 */         Throwable exToThrow = ex.getTargetException();
/* 352 */         RemoteInvocationUtils.fillInClientStackTraceIfPossible(exToThrow);
/* 353 */         throw exToThrow;
/*     */       }
/*     */       catch (Throwable ex) {
/* 356 */         throw new RemoteInvocationFailureException("Invocation of method [" + invocation.getMethod() + "] failed in RMI service [" + getServiceUrl() + "]", ex);
/*     */       }
/*     */     }
/*     */     Throwable targetEx;
/*     */     try
/*     */     {
/* 363 */       return RmiClientInterceptorUtils.invokeRemoteMethod(invocation, stub);
/*     */     }
/*     */     catch (InvocationTargetException ex) {
/* 366 */       targetEx = ex.getTargetException();
/* 367 */       if ((targetEx instanceof RemoteException)) {
/* 368 */         RemoteException rex = (RemoteException)targetEx;
/* 369 */         throw RmiClientInterceptorUtils.convertRmiAccessException(invocation.getMethod(), rex, isConnectFailure(rex), getServiceUrl());
/*     */       }
/*     */     }
/*     */ 
/* 373 */     throw targetEx;
/*     */   }
/*     */ 
/*     */   protected Object doInvoke(MethodInvocation methodInvocation, RmiInvocationHandler invocationHandler)
/*     */     throws RemoteException, NoSuchMethodException, IllegalAccessException, InvocationTargetException
/*     */   {
/* 394 */     if (AopUtils.isToStringMethod(methodInvocation.getMethod())) {
/* 395 */       return "RMI invoker proxy for service URL [" + getServiceUrl() + "]";
/*     */     }
/*     */ 
/* 398 */     return invocationHandler.invoke(createRemoteInvocation(methodInvocation));
/*     */   }
/*     */ 
/*     */   private static class DummyURLStreamHandler extends URLStreamHandler
/*     */   {
/*     */     protected URLConnection openConnection(URL url)
/*     */       throws IOException
/*     */     {
/* 411 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.remoting.rmi.RmiClientInterceptor
 * JD-Core Version:    0.6.0
 */