/*     */ package org.springframework.remoting.rmi;
/*     */ 
/*     */ import java.rmi.NoSuchObjectException;
/*     */ import java.rmi.Remote;
/*     */ import java.rmi.RemoteException;
/*     */ import java.util.Properties;
/*     */ import javax.naming.NamingException;
/*     */ import javax.rmi.PortableRemoteObject;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.jndi.JndiTemplate;
/*     */ 
/*     */ public class JndiRmiServiceExporter extends RmiBasedExporter
/*     */   implements InitializingBean, DisposableBean
/*     */ {
/*  71 */   private JndiTemplate jndiTemplate = new JndiTemplate();
/*     */   private String jndiName;
/*     */   private Remote exportedObject;
/*     */ 
/*     */   public void setJndiTemplate(JndiTemplate jndiTemplate)
/*     */   {
/*  84 */     this.jndiTemplate = (jndiTemplate != null ? jndiTemplate : new JndiTemplate());
/*     */   }
/*     */ 
/*     */   public void setJndiEnvironment(Properties jndiEnvironment)
/*     */   {
/*  93 */     this.jndiTemplate = new JndiTemplate(jndiEnvironment);
/*     */   }
/*     */ 
/*     */   public void setJndiName(String jndiName)
/*     */   {
/* 100 */     this.jndiName = jndiName;
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet() throws NamingException, RemoteException
/*     */   {
/* 105 */     prepare();
/*     */   }
/*     */ 
/*     */   public void prepare()
/*     */     throws NamingException, RemoteException
/*     */   {
/* 114 */     if (this.jndiName == null) {
/* 115 */       throw new IllegalArgumentException("Property 'jndiName' is required");
/*     */     }
/*     */ 
/* 119 */     this.exportedObject = getObjectToExport();
/* 120 */     PortableRemoteObject.exportObject(this.exportedObject);
/*     */ 
/* 122 */     rebind();
/*     */   }
/*     */ 
/*     */   public void rebind()
/*     */     throws NamingException
/*     */   {
/* 131 */     if (this.logger.isInfoEnabled()) {
/* 132 */       this.logger.info("Binding RMI service to JNDI location [" + this.jndiName + "]");
/*     */     }
/* 134 */     this.jndiTemplate.rebind(this.jndiName, this.exportedObject);
/*     */   }
/*     */ 
/*     */   public void destroy()
/*     */     throws NamingException, NoSuchObjectException
/*     */   {
/* 141 */     if (this.logger.isInfoEnabled()) {
/* 142 */       this.logger.info("Unbinding RMI service from JNDI location [" + this.jndiName + "]");
/*     */     }
/* 144 */     this.jndiTemplate.unbind(this.jndiName);
/* 145 */     PortableRemoteObject.unexportObject(this.exportedObject);
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.remoting.rmi.JndiRmiServiceExporter
 * JD-Core Version:    0.6.0
 */