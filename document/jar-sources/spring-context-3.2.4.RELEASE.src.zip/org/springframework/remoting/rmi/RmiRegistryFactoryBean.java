/*     */ package org.springframework.remoting.rmi;
/*     */ 
/*     */ import java.rmi.RemoteException;
/*     */ import java.rmi.registry.LocateRegistry;
/*     */ import java.rmi.registry.Registry;
/*     */ import java.rmi.server.RMIClientSocketFactory;
/*     */ import java.rmi.server.RMIServerSocketFactory;
/*     */ import java.rmi.server.UnicastRemoteObject;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ 
/*     */ public class RmiRegistryFactoryBean
/*     */   implements FactoryBean<Registry>, InitializingBean, DisposableBean
/*     */ {
/*  65 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   private String host;
/*  69 */   private int port = 1099;
/*     */   private RMIClientSocketFactory clientSocketFactory;
/*     */   private RMIServerSocketFactory serverSocketFactory;
/*     */   private Registry registry;
/*  77 */   private boolean alwaysCreate = false;
/*     */ 
/*  79 */   private boolean created = false;
/*     */ 
/*     */   public void setHost(String host)
/*     */   {
/*  88 */     this.host = host;
/*     */   }
/*     */ 
/*     */   public String getHost()
/*     */   {
/*  95 */     return this.host;
/*     */   }
/*     */ 
/*     */   public void setPort(int port)
/*     */   {
/* 104 */     this.port = port;
/*     */   }
/*     */ 
/*     */   public int getPort()
/*     */   {
/* 111 */     return this.port;
/*     */   }
/*     */ 
/*     */   public void setClientSocketFactory(RMIClientSocketFactory clientSocketFactory)
/*     */   {
/* 124 */     this.clientSocketFactory = clientSocketFactory;
/*     */   }
/*     */ 
/*     */   public void setServerSocketFactory(RMIServerSocketFactory serverSocketFactory)
/*     */   {
/* 137 */     this.serverSocketFactory = serverSocketFactory;
/*     */   }
/*     */ 
/*     */   public void setAlwaysCreate(boolean alwaysCreate)
/*     */   {
/* 148 */     this.alwaysCreate = alwaysCreate;
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */     throws Exception
/*     */   {
/* 154 */     if ((this.clientSocketFactory instanceof RMIServerSocketFactory)) {
/* 155 */       this.serverSocketFactory = ((RMIServerSocketFactory)this.clientSocketFactory);
/*     */     }
/* 157 */     if (((this.clientSocketFactory != null) && (this.serverSocketFactory == null)) || ((this.clientSocketFactory == null) && (this.serverSocketFactory != null)))
/*     */     {
/* 159 */       throw new IllegalArgumentException("Both RMIClientSocketFactory and RMIServerSocketFactory or none required");
/*     */     }
/*     */ 
/* 164 */     this.registry = getRegistry(this.host, this.port, this.clientSocketFactory, this.serverSocketFactory);
/*     */   }
/*     */ 
/*     */   protected Registry getRegistry(String registryHost, int registryPort, RMIClientSocketFactory clientSocketFactory, RMIServerSocketFactory serverSocketFactory)
/*     */     throws RemoteException
/*     */   {
/* 182 */     if (registryHost != null)
/*     */     {
/* 184 */       if (this.logger.isInfoEnabled()) {
/* 185 */         this.logger.info("Looking for RMI registry at port '" + registryPort + "' of host [" + registryHost + "]");
/*     */       }
/* 187 */       Registry reg = LocateRegistry.getRegistry(registryHost, registryPort, clientSocketFactory);
/* 188 */       testRegistry(reg);
/* 189 */       return reg;
/*     */     }
/*     */ 
/* 193 */     return getRegistry(registryPort, clientSocketFactory, serverSocketFactory);
/*     */   }
/*     */ 
/*     */   protected Registry getRegistry(int registryPort, RMIClientSocketFactory clientSocketFactory, RMIServerSocketFactory serverSocketFactory)
/*     */     throws RemoteException
/*     */   {
/* 209 */     if (clientSocketFactory != null) {
/* 210 */       if (this.alwaysCreate) {
/* 211 */         this.logger.info("Creating new RMI registry");
/* 212 */         this.created = true;
/* 213 */         return LocateRegistry.createRegistry(registryPort, clientSocketFactory, serverSocketFactory);
/*     */       }
/* 215 */       if (this.logger.isInfoEnabled()) {
/* 216 */         this.logger.info("Looking for RMI registry at port '" + registryPort + "', using custom socket factory");
/*     */       }
/* 218 */       synchronized (LocateRegistry.class)
/*     */       {
/*     */         try {
/* 221 */           Registry reg = LocateRegistry.getRegistry(null, registryPort, clientSocketFactory);
/* 222 */           testRegistry(reg);
/* 223 */           return reg;
/*     */         }
/*     */         catch (RemoteException ex) {
/* 226 */           this.logger.debug("RMI registry access threw exception", ex);
/* 227 */           this.logger.info("Could not detect RMI registry - creating new one");
/*     */ 
/* 229 */           this.created = true;
/* 230 */           return LocateRegistry.createRegistry(registryPort, clientSocketFactory, serverSocketFactory);
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 236 */     return getRegistry(registryPort);
/*     */   }
/*     */ 
/*     */   protected Registry getRegistry(int registryPort)
/*     */     throws RemoteException
/*     */   {
/* 247 */     if (this.alwaysCreate) {
/* 248 */       this.logger.info("Creating new RMI registry");
/* 249 */       this.created = true;
/* 250 */       return LocateRegistry.createRegistry(registryPort);
/*     */     }
/* 252 */     if (this.logger.isInfoEnabled()) {
/* 253 */       this.logger.info("Looking for RMI registry at port '" + registryPort + "'");
/*     */     }
/* 255 */     synchronized (LocateRegistry.class)
/*     */     {
/*     */       try {
/* 258 */         Registry reg = LocateRegistry.getRegistry(registryPort);
/* 259 */         testRegistry(reg);
/* 260 */         return reg;
/*     */       }
/*     */       catch (RemoteException ex) {
/* 263 */         this.logger.debug("RMI registry access threw exception", ex);
/* 264 */         this.logger.info("Could not detect RMI registry - creating new one");
/*     */ 
/* 266 */         this.created = true;
/* 267 */         return LocateRegistry.createRegistry(registryPort);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void testRegistry(Registry registry)
/*     */     throws RemoteException
/*     */   {
/* 281 */     registry.list();
/*     */   }
/*     */ 
/*     */   public Registry getObject() throws Exception
/*     */   {
/* 286 */     return this.registry;
/*     */   }
/*     */ 
/*     */   public Class<? extends Registry> getObjectType() {
/* 290 */     return this.registry != null ? this.registry.getClass() : Registry.class;
/*     */   }
/*     */ 
/*     */   public boolean isSingleton() {
/* 294 */     return true;
/*     */   }
/*     */ 
/*     */   public void destroy()
/*     */     throws RemoteException
/*     */   {
/* 303 */     if (this.created) {
/* 304 */       this.logger.info("Unexporting RMI registry");
/* 305 */       UnicastRemoteObject.unexportObject(this.registry, true);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.remoting.rmi.RmiRegistryFactoryBean
 * JD-Core Version:    0.6.0
 */