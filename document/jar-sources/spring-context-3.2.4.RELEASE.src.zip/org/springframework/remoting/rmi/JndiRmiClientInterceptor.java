/*     */ package org.springframework.remoting.rmi;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.rmi.RemoteException;
/*     */ import javax.naming.Context;
/*     */ import javax.naming.NamingException;
/*     */ import javax.rmi.PortableRemoteObject;
/*     */ import org.aopalliance.intercept.MethodInterceptor;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.omg.CORBA.OBJECT_NOT_EXIST;
/*     */ import org.omg.CORBA.SystemException;
/*     */ import org.springframework.aop.support.AopUtils;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.jndi.JndiObjectLocator;
/*     */ import org.springframework.jndi.JndiTemplate;
/*     */ import org.springframework.remoting.RemoteAccessException;
/*     */ import org.springframework.remoting.RemoteConnectFailureException;
/*     */ import org.springframework.remoting.RemoteInvocationFailureException;
/*     */ import org.springframework.remoting.RemoteLookupFailureException;
/*     */ import org.springframework.remoting.support.DefaultRemoteInvocationFactory;
/*     */ import org.springframework.remoting.support.RemoteInvocation;
/*     */ import org.springframework.remoting.support.RemoteInvocationFactory;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ public class JndiRmiClientInterceptor extends JndiObjectLocator
/*     */   implements MethodInterceptor, InitializingBean
/*     */ {
/*     */   private Class serviceInterface;
/*  83 */   private RemoteInvocationFactory remoteInvocationFactory = new DefaultRemoteInvocationFactory();
/*     */ 
/*  85 */   private boolean lookupStubOnStartup = true;
/*     */ 
/*  87 */   private boolean cacheStub = true;
/*     */ 
/*  89 */   private boolean refreshStubOnConnectFailure = false;
/*     */ 
/*  91 */   private boolean exposeAccessContext = false;
/*     */   private Object cachedStub;
/*  95 */   private final Object stubMonitor = new Object();
/*     */ 
/*     */   public void setServiceInterface(Class serviceInterface)
/*     */   {
/* 105 */     if ((serviceInterface != null) && (!serviceInterface.isInterface())) {
/* 106 */       throw new IllegalArgumentException("'serviceInterface' must be an interface");
/*     */     }
/* 108 */     this.serviceInterface = serviceInterface;
/*     */   }
/*     */ 
/*     */   public Class getServiceInterface()
/*     */   {
/* 115 */     return this.serviceInterface;
/*     */   }
/*     */ 
/*     */   public void setRemoteInvocationFactory(RemoteInvocationFactory remoteInvocationFactory)
/*     */   {
/* 125 */     this.remoteInvocationFactory = remoteInvocationFactory;
/*     */   }
/*     */ 
/*     */   public RemoteInvocationFactory getRemoteInvocationFactory()
/*     */   {
/* 132 */     return this.remoteInvocationFactory;
/*     */   }
/*     */ 
/*     */   public void setLookupStubOnStartup(boolean lookupStubOnStartup)
/*     */   {
/* 142 */     this.lookupStubOnStartup = lookupStubOnStartup;
/*     */   }
/*     */ 
/*     */   public void setCacheStub(boolean cacheStub)
/*     */   {
/* 153 */     this.cacheStub = cacheStub;
/*     */   }
/*     */ 
/*     */   public void setRefreshStubOnConnectFailure(boolean refreshStubOnConnectFailure)
/*     */   {
/* 168 */     this.refreshStubOnConnectFailure = refreshStubOnConnectFailure;
/*     */   }
/*     */ 
/*     */   public void setExposeAccessContext(boolean exposeAccessContext)
/*     */   {
/* 180 */     this.exposeAccessContext = exposeAccessContext;
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */     throws NamingException
/*     */   {
/* 186 */     super.afterPropertiesSet();
/* 187 */     prepare();
/*     */   }
/*     */ 
/*     */   public void prepare()
/*     */     throws RemoteLookupFailureException
/*     */   {
/* 198 */     if (this.lookupStubOnStartup) {
/* 199 */       Object remoteObj = lookupStub();
/* 200 */       if (this.logger.isDebugEnabled()) {
/* 201 */         if ((remoteObj instanceof RmiInvocationHandler)) {
/* 202 */           this.logger.debug("JNDI RMI object [" + getJndiName() + "] is an RMI invoker");
/*     */         }
/* 204 */         else if (getServiceInterface() != null) {
/* 205 */           boolean isImpl = getServiceInterface().isInstance(remoteObj);
/* 206 */           this.logger.debug("Using service interface [" + getServiceInterface().getName() + "] for JNDI RMI object [" + getJndiName() + "] - " + (!isImpl ? "not " : "") + "directly implemented");
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 211 */       if (this.cacheStub)
/* 212 */         this.cachedStub = remoteObj;
/*     */     }
/*     */   }
/*     */ 
/*     */   protected Object lookupStub()
/*     */     throws RemoteLookupFailureException
/*     */   {
/*     */     try
/*     */     {
/* 230 */       Object stub = lookup();
/* 231 */       if ((getServiceInterface() != null) && (!(stub instanceof RmiInvocationHandler))) {
/*     */         try {
/* 233 */           stub = PortableRemoteObject.narrow(stub, getServiceInterface());
/*     */         }
/*     */         catch (ClassCastException ex) {
/* 236 */           throw new RemoteLookupFailureException("Could not narrow RMI stub to service interface [" + getServiceInterface().getName() + "]", ex);
/*     */         }
/*     */       }
/*     */ 
/* 240 */       return stub;
/*     */     } catch (NamingException ex) {
/*     */     }
/* 243 */     throw new RemoteLookupFailureException("JNDI lookup for RMI service [" + getJndiName() + "] failed", ex);
/*     */   }
/*     */ 
/*     */   protected Object getStub()
/*     */     throws NamingException, RemoteLookupFailureException
/*     */   {
/* 259 */     if ((!this.cacheStub) || ((this.lookupStubOnStartup) && (!this.refreshStubOnConnectFailure))) {
/* 260 */       return this.cachedStub != null ? this.cachedStub : lookupStub();
/*     */     }
/*     */ 
/* 263 */     synchronized (this.stubMonitor) {
/* 264 */       if (this.cachedStub == null) {
/* 265 */         this.cachedStub = lookupStub();
/*     */       }
/* 267 */       return this.cachedStub;
/*     */     }
/*     */   }
/*     */ 
/*     */   public Object invoke(MethodInvocation invocation)
/*     */     throws Throwable
/*     */   {
/*     */     Object stub;
/*     */     try
/*     */     {
/* 287 */       stub = getStub();
/*     */     }
/*     */     catch (NamingException ex) {
/* 290 */       throw new RemoteLookupFailureException("JNDI lookup for RMI service [" + getJndiName() + "] failed", ex);
/*     */     }
/*     */ 
/* 293 */     Context ctx = this.exposeAccessContext ? getJndiTemplate().getContext() : null;
/*     */     try {
/* 295 */       Object localObject1 = doInvoke(invocation, stub);
/*     */       return localObject1;
/*     */     }
/*     */     catch (RemoteConnectFailureException ex)
/*     */     {
/* 298 */       localObject2 = handleRemoteConnectFailure(invocation, ex);
/*     */       return localObject2;
/*     */     }
/*     */     catch (RemoteException ex)
/*     */     {
/* 301 */       if (isConnectFailure(ex)) {
/* 302 */         localObject2 = handleRemoteConnectFailure(invocation, ex);
/*     */         return localObject2;
/*     */       }
/* 305 */       throw ex;
/*     */     }
/*     */     catch (SystemException ex)
/*     */     {
/*     */       Object localObject2;
/* 309 */       if (isConnectFailure(ex)) {
/* 310 */         localObject2 = handleRemoteConnectFailure(invocation, ex);
/*     */         return localObject2;
/*     */       }
/* 313 */       throw ex;
/*     */     }
/*     */     finally
/*     */     {
/* 317 */       getJndiTemplate().releaseContext(ctx); } throw localObject3;
/*     */   }
/*     */ 
/*     */   protected boolean isConnectFailure(RemoteException ex)
/*     */   {
/* 329 */     return RmiClientInterceptorUtils.isConnectFailure(ex);
/*     */   }
/*     */ 
/*     */   protected boolean isConnectFailure(SystemException ex)
/*     */   {
/* 340 */     return ex instanceof OBJECT_NOT_EXIST;
/*     */   }
/*     */ 
/*     */   private Object handleRemoteConnectFailure(MethodInvocation invocation, Exception ex)
/*     */     throws Throwable
/*     */   {
/* 353 */     if (this.refreshStubOnConnectFailure) {
/* 354 */       if (this.logger.isDebugEnabled()) {
/* 355 */         this.logger.debug("Could not connect to RMI service [" + getJndiName() + "] - retrying", ex);
/*     */       }
/* 357 */       else if (this.logger.isWarnEnabled()) {
/* 358 */         this.logger.warn("Could not connect to RMI service [" + getJndiName() + "] - retrying");
/*     */       }
/* 360 */       return refreshAndRetry(invocation);
/*     */     }
/*     */ 
/* 363 */     throw ex;
/*     */   }
/*     */ 
/*     */   protected Object refreshAndRetry(MethodInvocation invocation)
/*     */     throws Throwable
/*     */   {
/*     */     Object freshStub;
/* 377 */     synchronized (this.stubMonitor) {
/* 378 */       this.cachedStub = null;
/* 379 */       freshStub = lookupStub();
/* 380 */       if (this.cacheStub) {
/* 381 */         this.cachedStub = freshStub;
/*     */       }
/*     */     }
/* 384 */     return doInvoke(invocation, freshStub);
/*     */   }
/*     */ 
/*     */   protected Object doInvoke(MethodInvocation invocation, Object stub)
/*     */     throws Throwable
/*     */   {
/* 396 */     if ((stub instanceof RmiInvocationHandler)) {
/*     */       try
/*     */       {
/* 399 */         return doInvoke(invocation, (RmiInvocationHandler)stub);
/*     */       }
/*     */       catch (RemoteException ex) {
/* 402 */         throw convertRmiAccessException(ex, invocation.getMethod());
/*     */       }
/*     */       catch (SystemException ex) {
/* 405 */         throw convertCorbaAccessException(ex, invocation.getMethod());
/*     */       }
/*     */       catch (InvocationTargetException ex) {
/* 408 */         throw ex.getTargetException();
/*     */       }
/*     */       catch (Throwable ex) {
/* 411 */         throw new RemoteInvocationFailureException("Invocation of method [" + invocation.getMethod() + "] failed in RMI service [" + getJndiName() + "]", ex);
/*     */       }
/*     */     }
/*     */     Throwable targetEx;
/*     */     try
/*     */     {
/* 418 */       return RmiClientInterceptorUtils.invokeRemoteMethod(invocation, stub);
/*     */     }
/*     */     catch (InvocationTargetException ex) {
/* 421 */       targetEx = ex.getTargetException();
/* 422 */       if ((targetEx instanceof RemoteException)) {
/* 423 */         throw convertRmiAccessException((RemoteException)targetEx, invocation.getMethod());
/*     */       }
/* 425 */       if ((targetEx instanceof SystemException)) {
/* 426 */         throw convertCorbaAccessException((SystemException)targetEx, invocation.getMethod());
/*     */       }
/*     */     }
/* 429 */     throw targetEx;
/*     */   }
/*     */ 
/*     */   protected Object doInvoke(MethodInvocation methodInvocation, RmiInvocationHandler invocationHandler)
/*     */     throws RemoteException, NoSuchMethodException, IllegalAccessException, InvocationTargetException
/*     */   {
/* 450 */     if (AopUtils.isToStringMethod(methodInvocation.getMethod())) {
/* 451 */       return "RMI invoker proxy for service URL [" + getJndiName() + "]";
/*     */     }
/*     */ 
/* 454 */     return invocationHandler.invoke(createRemoteInvocation(methodInvocation));
/*     */   }
/*     */ 
/*     */   protected RemoteInvocation createRemoteInvocation(MethodInvocation methodInvocation)
/*     */   {
/* 470 */     return getRemoteInvocationFactory().createRemoteInvocation(methodInvocation);
/*     */   }
/*     */ 
/*     */   private Exception convertRmiAccessException(RemoteException ex, Method method)
/*     */   {
/* 482 */     return RmiClientInterceptorUtils.convertRmiAccessException(method, ex, isConnectFailure(ex), getJndiName());
/*     */   }
/*     */ 
/*     */   private Exception convertCorbaAccessException(SystemException ex, Method method)
/*     */   {
/* 494 */     if (ReflectionUtils.declaresException(method, RemoteException.class))
/*     */     {
/* 496 */       return new RemoteException("Failed to access CORBA service [" + getJndiName() + "]", ex);
/*     */     }
/*     */ 
/* 499 */     if (isConnectFailure(ex)) {
/* 500 */       return new RemoteConnectFailureException("Could not connect to CORBA service [" + getJndiName() + "]", ex);
/*     */     }
/*     */ 
/* 503 */     return new RemoteAccessException("Could not access CORBA service [" + getJndiName() + "]", ex);
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.remoting.rmi.JndiRmiClientInterceptor
 * JD-Core Version:    0.6.0
 */