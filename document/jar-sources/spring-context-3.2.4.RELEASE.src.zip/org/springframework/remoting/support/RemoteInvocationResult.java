/*     */ package org.springframework.remoting.support;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ 
/*     */ public class RemoteInvocationResult
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 2138555143707773549L;
/*     */   private Object value;
/*     */   private Throwable exception;
/*     */ 
/*     */   public RemoteInvocationResult(Object value)
/*     */   {
/*  50 */     this.value = value;
/*     */   }
/*     */ 
/*     */   public RemoteInvocationResult(Throwable exception)
/*     */   {
/*  59 */     this.exception = exception;
/*     */   }
/*     */ 
/*     */   public Object getValue()
/*     */   {
/*  69 */     return this.value;
/*     */   }
/*     */ 
/*     */   public Throwable getException()
/*     */   {
/*  78 */     return this.exception;
/*     */   }
/*     */ 
/*     */   public boolean hasException()
/*     */   {
/*  89 */     return this.exception != null;
/*     */   }
/*     */ 
/*     */   public boolean hasInvocationTargetException()
/*     */   {
/*  98 */     return this.exception instanceof InvocationTargetException;
/*     */   }
/*     */ 
/*     */   public Object recreate()
/*     */     throws Throwable
/*     */   {
/* 110 */     if (this.exception != null) {
/* 111 */       Throwable exToThrow = this.exception;
/* 112 */       if ((this.exception instanceof InvocationTargetException)) {
/* 113 */         exToThrow = ((InvocationTargetException)this.exception).getTargetException();
/*     */       }
/* 115 */       RemoteInvocationUtils.fillInClientStackTraceIfPossible(exToThrow);
/* 116 */       throw exToThrow;
/*     */     }
/*     */ 
/* 119 */     return this.value;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.remoting.support.RemoteInvocationResult
 * JD-Core Version:    0.6.0
 */