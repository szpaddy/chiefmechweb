/*    */ package org.springframework.remoting.support;
/*    */ 
/*    */ import org.springframework.beans.factory.InitializingBean;
/*    */ 
/*    */ public abstract class UrlBasedRemoteAccessor extends RemoteAccessor
/*    */   implements InitializingBean
/*    */ {
/*    */   private String serviceUrl;
/*    */ 
/*    */   public void setServiceUrl(String serviceUrl)
/*    */   {
/* 38 */     this.serviceUrl = serviceUrl;
/*    */   }
/*    */ 
/*    */   public String getServiceUrl()
/*    */   {
/* 45 */     return this.serviceUrl;
/*    */   }
/*    */ 
/*    */   public void afterPropertiesSet()
/*    */   {
/* 50 */     if (getServiceUrl() == null)
/* 51 */       throw new IllegalArgumentException("Property 'serviceUrl' is required");
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.remoting.support.UrlBasedRemoteAccessor
 * JD-Core Version:    0.6.0
 */