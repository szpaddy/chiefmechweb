package org.springframework.remoting.support;

import org.aopalliance.intercept.MethodInvocation;

public abstract interface RemoteInvocationFactory
{
  public abstract RemoteInvocation createRemoteInvocation(MethodInvocation paramMethodInvocation);
}

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.remoting.support.RemoteInvocationFactory
 * JD-Core Version:    0.6.0
 */