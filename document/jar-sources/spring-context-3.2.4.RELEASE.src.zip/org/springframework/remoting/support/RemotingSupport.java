/*    */ package org.springframework.remoting.support;
/*    */ 
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.beans.factory.BeanClassLoaderAware;
/*    */ import org.springframework.util.ClassUtils;
/*    */ 
/*    */ public abstract class RemotingSupport
/*    */   implements BeanClassLoaderAware
/*    */ {
/* 35 */   protected final Log logger = LogFactory.getLog(getClass());
/*    */ 
/* 37 */   private ClassLoader beanClassLoader = ClassUtils.getDefaultClassLoader();
/*    */ 
/*    */   public void setBeanClassLoader(ClassLoader classLoader)
/*    */   {
/* 41 */     this.beanClassLoader = classLoader;
/*    */   }
/*    */ 
/*    */   protected ClassLoader getBeanClassLoader()
/*    */   {
/* 49 */     return this.beanClassLoader;
/*    */   }
/*    */ 
/*    */   protected ClassLoader overrideThreadContextClassLoader()
/*    */   {
/* 60 */     return ClassUtils.overrideThreadContextClassLoader(getBeanClassLoader());
/*    */   }
/*    */ 
/*    */   protected void resetThreadContextClassLoader(ClassLoader original)
/*    */   {
/* 69 */     if (original != null)
/* 70 */       Thread.currentThread().setContextClassLoader(original);
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.remoting.support.RemotingSupport
 * JD-Core Version:    0.6.0
 */