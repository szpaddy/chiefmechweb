/*    */ package org.springframework.remoting.support;
/*    */ 
/*    */ import org.aopalliance.intercept.MethodInvocation;
/*    */ 
/*    */ public abstract class RemoteInvocationBasedAccessor extends UrlBasedRemoteAccessor
/*    */ {
/* 37 */   private RemoteInvocationFactory remoteInvocationFactory = new DefaultRemoteInvocationFactory();
/*    */ 
/*    */   public void setRemoteInvocationFactory(RemoteInvocationFactory remoteInvocationFactory)
/*    */   {
/* 47 */     this.remoteInvocationFactory = (remoteInvocationFactory != null ? remoteInvocationFactory : new DefaultRemoteInvocationFactory());
/*    */   }
/*    */ 
/*    */   public RemoteInvocationFactory getRemoteInvocationFactory()
/*    */   {
/* 55 */     return this.remoteInvocationFactory;
/*    */   }
/*    */ 
/*    */   protected RemoteInvocation createRemoteInvocation(MethodInvocation methodInvocation)
/*    */   {
/* 71 */     return getRemoteInvocationFactory().createRemoteInvocation(methodInvocation);
/*    */   }
/*    */ 
/*    */   protected Object recreateRemoteInvocationResult(RemoteInvocationResult result)
/*    */     throws Throwable
/*    */   {
/* 85 */     return result.recreate();
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.remoting.support.RemoteInvocationBasedAccessor
 * JD-Core Version:    0.6.0
 */