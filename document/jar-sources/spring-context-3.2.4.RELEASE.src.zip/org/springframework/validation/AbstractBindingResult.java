/*     */ package org.springframework.validation;
/*     */ 
/*     */ import java.beans.PropertyEditor;
/*     */ import java.io.Serializable;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.springframework.beans.PropertyEditorRegistry;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public abstract class AbstractBindingResult extends AbstractErrors
/*     */   implements BindingResult, Serializable
/*     */ {
/*     */   private final String objectName;
/*  49 */   private MessageCodesResolver messageCodesResolver = new DefaultMessageCodesResolver();
/*     */ 
/*  51 */   private final List<ObjectError> errors = new LinkedList();
/*     */ 
/*  53 */   private final Set<String> suppressedFields = new HashSet();
/*     */ 
/*     */   protected AbstractBindingResult(String objectName)
/*     */   {
/*  62 */     this.objectName = objectName;
/*     */   }
/*     */ 
/*     */   public void setMessageCodesResolver(MessageCodesResolver messageCodesResolver)
/*     */   {
/*  71 */     Assert.notNull(messageCodesResolver, "MessageCodesResolver must not be null");
/*  72 */     this.messageCodesResolver = messageCodesResolver;
/*     */   }
/*     */ 
/*     */   public MessageCodesResolver getMessageCodesResolver()
/*     */   {
/*  79 */     return this.messageCodesResolver;
/*     */   }
/*     */ 
/*     */   public String getObjectName()
/*     */   {
/*  88 */     return this.objectName;
/*     */   }
/*     */ 
/*     */   public void reject(String errorCode, Object[] errorArgs, String defaultMessage)
/*     */   {
/*  93 */     addError(new ObjectError(getObjectName(), resolveMessageCodes(errorCode), errorArgs, defaultMessage));
/*     */   }
/*     */ 
/*     */   public void rejectValue(String field, String errorCode, Object[] errorArgs, String defaultMessage) {
/*  97 */     if (("".equals(getNestedPath())) && (!StringUtils.hasLength(field)))
/*     */     {
/* 101 */       reject(errorCode, errorArgs, defaultMessage);
/* 102 */       return;
/*     */     }
/* 104 */     String fixedField = fixedField(field);
/* 105 */     Object newVal = getActualFieldValue(fixedField);
/* 106 */     FieldError fe = new FieldError(getObjectName(), fixedField, newVal, false, resolveMessageCodes(errorCode, field), errorArgs, defaultMessage);
/*     */ 
/* 109 */     addError(fe);
/*     */   }
/*     */ 
/*     */   public void addError(ObjectError error) {
/* 113 */     this.errors.add(error);
/*     */   }
/*     */ 
/*     */   public void addAllErrors(Errors errors) {
/* 117 */     if (!errors.getObjectName().equals(getObjectName())) {
/* 118 */       throw new IllegalArgumentException("Errors object needs to have same object name");
/*     */     }
/* 120 */     this.errors.addAll(errors.getAllErrors());
/*     */   }
/*     */ 
/*     */   public String[] resolveMessageCodes(String errorCode) {
/* 124 */     return getMessageCodesResolver().resolveMessageCodes(errorCode, getObjectName());
/*     */   }
/*     */ 
/*     */   public String[] resolveMessageCodes(String errorCode, String field) {
/* 128 */     Class fieldType = getFieldType(field);
/* 129 */     return getMessageCodesResolver().resolveMessageCodes(errorCode, getObjectName(), fixedField(field), fieldType);
/*     */   }
/*     */ 
/*     */   public boolean hasErrors()
/*     */   {
/* 136 */     return !this.errors.isEmpty();
/*     */   }
/*     */ 
/*     */   public int getErrorCount()
/*     */   {
/* 141 */     return this.errors.size();
/*     */   }
/*     */ 
/*     */   public List<ObjectError> getAllErrors()
/*     */   {
/* 146 */     return Collections.unmodifiableList(this.errors);
/*     */   }
/*     */ 
/*     */   public List<ObjectError> getGlobalErrors() {
/* 150 */     List result = new LinkedList();
/* 151 */     for (ObjectError objectError : this.errors) {
/* 152 */       if (!(objectError instanceof FieldError)) {
/* 153 */         result.add(objectError);
/*     */       }
/*     */     }
/* 156 */     return Collections.unmodifiableList(result);
/*     */   }
/*     */ 
/*     */   public ObjectError getGlobalError()
/*     */   {
/* 161 */     for (ObjectError objectError : this.errors) {
/* 162 */       if (!(objectError instanceof FieldError)) {
/* 163 */         return objectError;
/*     */       }
/*     */     }
/* 166 */     return null;
/*     */   }
/*     */ 
/*     */   public List<FieldError> getFieldErrors() {
/* 170 */     List result = new LinkedList();
/* 171 */     for (ObjectError objectError : this.errors) {
/* 172 */       if ((objectError instanceof FieldError)) {
/* 173 */         result.add((FieldError)objectError);
/*     */       }
/*     */     }
/* 176 */     return Collections.unmodifiableList(result);
/*     */   }
/*     */ 
/*     */   public FieldError getFieldError()
/*     */   {
/* 181 */     for (ObjectError objectError : this.errors) {
/* 182 */       if ((objectError instanceof FieldError)) {
/* 183 */         return (FieldError)objectError;
/*     */       }
/*     */     }
/* 186 */     return null;
/*     */   }
/*     */ 
/*     */   public List<FieldError> getFieldErrors(String field)
/*     */   {
/* 191 */     List result = new LinkedList();
/* 192 */     String fixedField = fixedField(field);
/* 193 */     for (ObjectError objectError : this.errors) {
/* 194 */       if (((objectError instanceof FieldError)) && (isMatchingFieldError(fixedField, (FieldError)objectError))) {
/* 195 */         result.add((FieldError)objectError);
/*     */       }
/*     */     }
/* 198 */     return Collections.unmodifiableList(result);
/*     */   }
/*     */ 
/*     */   public FieldError getFieldError(String field)
/*     */   {
/* 203 */     String fixedField = fixedField(field);
/* 204 */     for (ObjectError objectError : this.errors) {
/* 205 */       if ((objectError instanceof FieldError)) {
/* 206 */         FieldError fieldError = (FieldError)objectError;
/* 207 */         if (isMatchingFieldError(fixedField, fieldError)) {
/* 208 */           return fieldError;
/*     */         }
/*     */       }
/*     */     }
/* 212 */     return null;
/*     */   }
/*     */ 
/*     */   public Object getFieldValue(String field) {
/* 216 */     FieldError fieldError = getFieldError(field);
/*     */ 
/* 218 */     Object value = fieldError != null ? fieldError.getRejectedValue() : getActualFieldValue(fixedField(field));
/*     */ 
/* 221 */     if ((fieldError == null) || (!fieldError.isBindingFailure())) {
/* 222 */       value = formatFieldValue(field, value);
/*     */     }
/* 224 */     return value;
/*     */   }
/*     */ 
/*     */   public Class<?> getFieldType(String field)
/*     */   {
/* 235 */     Object value = getActualFieldValue(fixedField(field));
/* 236 */     if (value != null) {
/* 237 */       return value.getClass();
/*     */     }
/* 239 */     return null;
/*     */   }
/*     */ 
/*     */   public Map<String, Object> getModel()
/*     */   {
/* 266 */     Map model = new LinkedHashMap(2);
/*     */ 
/* 268 */     model.put(getObjectName(), getTarget());
/*     */ 
/* 270 */     model.put(MODEL_KEY_PREFIX + getObjectName(), this);
/* 271 */     return model;
/*     */   }
/*     */ 
/*     */   public Object getRawFieldValue(String field) {
/* 275 */     return getActualFieldValue(fixedField(field));
/*     */   }
/*     */ 
/*     */   public PropertyEditor findEditor(String field, Class<?> valueType)
/*     */   {
/* 284 */     PropertyEditorRegistry editorRegistry = getPropertyEditorRegistry();
/* 285 */     if (editorRegistry != null) {
/* 286 */       Class valueTypeToUse = valueType;
/* 287 */       if (valueTypeToUse == null) {
/* 288 */         valueTypeToUse = getFieldType(field);
/*     */       }
/* 290 */       return editorRegistry.findCustomEditor(valueTypeToUse, fixedField(field));
/*     */     }
/*     */ 
/* 293 */     return null;
/*     */   }
/*     */ 
/*     */   public PropertyEditorRegistry getPropertyEditorRegistry()
/*     */   {
/* 301 */     return null;
/*     */   }
/*     */ 
/*     */   public void recordSuppressedField(String field)
/*     */   {
/* 311 */     this.suppressedFields.add(field);
/*     */   }
/*     */ 
/*     */   public String[] getSuppressedFields()
/*     */   {
/* 321 */     return StringUtils.toStringArray(this.suppressedFields);
/*     */   }
/*     */ 
/*     */   public boolean equals(Object other)
/*     */   {
/* 327 */     if (this == other) {
/* 328 */       return true;
/*     */     }
/* 330 */     if (!(other instanceof Serializable)) {
/* 331 */       return false;
/*     */     }
/* 333 */     BindingResult otherResult = (Serializable)other;
/* 334 */     return (getObjectName().equals(otherResult.getObjectName())) && (ObjectUtils.nullSafeEquals(getTarget(), otherResult.getTarget())) && (getAllErrors().equals(otherResult.getAllErrors()));
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 341 */     return getObjectName().hashCode();
/*     */   }
/*     */ 
/*     */   public abstract Object getTarget();
/*     */ 
/*     */   protected abstract Object getActualFieldValue(String paramString);
/*     */ 
/*     */   protected Object formatFieldValue(String field, Object value)
/*     */   {
/* 370 */     return value;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.validation.AbstractBindingResult
 * JD-Core Version:    0.6.0
 */