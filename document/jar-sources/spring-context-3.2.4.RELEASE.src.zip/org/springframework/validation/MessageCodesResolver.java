package org.springframework.validation;

public abstract interface MessageCodesResolver
{
  public abstract String[] resolveMessageCodes(String paramString1, String paramString2);

  public abstract String[] resolveMessageCodes(String paramString1, String paramString2, String paramString3, Class<?> paramClass);
}

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.validation.MessageCodesResolver
 * JD-Core Version:    0.6.0
 */