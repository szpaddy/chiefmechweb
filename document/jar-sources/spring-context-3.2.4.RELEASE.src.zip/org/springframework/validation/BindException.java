/*     */ package org.springframework.validation;
/*     */ 
/*     */ import java.beans.PropertyEditor;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.springframework.beans.PropertyEditorRegistry;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public class BindException extends Exception
/*     */   implements BindingResult
/*     */ {
/*     */   private final BindingResult bindingResult;
/*     */ 
/*     */   public BindException(BindingResult bindingResult)
/*     */   {
/*  54 */     Assert.notNull(bindingResult, "BindingResult must not be null");
/*  55 */     this.bindingResult = bindingResult;
/*     */   }
/*     */ 
/*     */   public BindException(Object target, String objectName)
/*     */   {
/*  65 */     Assert.notNull(target, "Target object must not be null");
/*  66 */     this.bindingResult = new BeanPropertyBindingResult(target, objectName);
/*     */   }
/*     */ 
/*     */   public final BindingResult getBindingResult()
/*     */   {
/*  76 */     return this.bindingResult;
/*     */   }
/*     */ 
/*     */   public String getObjectName()
/*     */   {
/*  81 */     return this.bindingResult.getObjectName();
/*     */   }
/*     */ 
/*     */   public void setNestedPath(String nestedPath) {
/*  85 */     this.bindingResult.setNestedPath(nestedPath);
/*     */   }
/*     */ 
/*     */   public String getNestedPath() {
/*  89 */     return this.bindingResult.getNestedPath();
/*     */   }
/*     */ 
/*     */   public void pushNestedPath(String subPath) {
/*  93 */     this.bindingResult.pushNestedPath(subPath);
/*     */   }
/*     */ 
/*     */   public void popNestedPath() throws IllegalStateException {
/*  97 */     this.bindingResult.popNestedPath();
/*     */   }
/*     */ 
/*     */   public void reject(String errorCode)
/*     */   {
/* 102 */     this.bindingResult.reject(errorCode);
/*     */   }
/*     */ 
/*     */   public void reject(String errorCode, String defaultMessage) {
/* 106 */     this.bindingResult.reject(errorCode, defaultMessage);
/*     */   }
/*     */ 
/*     */   public void reject(String errorCode, Object[] errorArgs, String defaultMessage) {
/* 110 */     this.bindingResult.reject(errorCode, errorArgs, defaultMessage);
/*     */   }
/*     */ 
/*     */   public void rejectValue(String field, String errorCode) {
/* 114 */     this.bindingResult.rejectValue(field, errorCode);
/*     */   }
/*     */ 
/*     */   public void rejectValue(String field, String errorCode, String defaultMessage) {
/* 118 */     this.bindingResult.rejectValue(field, errorCode, defaultMessage);
/*     */   }
/*     */ 
/*     */   public void rejectValue(String field, String errorCode, Object[] errorArgs, String defaultMessage) {
/* 122 */     this.bindingResult.rejectValue(field, errorCode, errorArgs, defaultMessage);
/*     */   }
/*     */ 
/*     */   public void addAllErrors(Errors errors) {
/* 126 */     this.bindingResult.addAllErrors(errors);
/*     */   }
/*     */ 
/*     */   public boolean hasErrors()
/*     */   {
/* 131 */     return this.bindingResult.hasErrors();
/*     */   }
/*     */ 
/*     */   public int getErrorCount() {
/* 135 */     return this.bindingResult.getErrorCount();
/*     */   }
/*     */ 
/*     */   public List<ObjectError> getAllErrors() {
/* 139 */     return this.bindingResult.getAllErrors();
/*     */   }
/*     */ 
/*     */   public boolean hasGlobalErrors() {
/* 143 */     return this.bindingResult.hasGlobalErrors();
/*     */   }
/*     */ 
/*     */   public int getGlobalErrorCount() {
/* 147 */     return this.bindingResult.getGlobalErrorCount();
/*     */   }
/*     */ 
/*     */   public List<ObjectError> getGlobalErrors() {
/* 151 */     return this.bindingResult.getGlobalErrors();
/*     */   }
/*     */ 
/*     */   public ObjectError getGlobalError() {
/* 155 */     return this.bindingResult.getGlobalError();
/*     */   }
/*     */ 
/*     */   public boolean hasFieldErrors() {
/* 159 */     return this.bindingResult.hasFieldErrors();
/*     */   }
/*     */ 
/*     */   public int getFieldErrorCount() {
/* 163 */     return this.bindingResult.getFieldErrorCount();
/*     */   }
/*     */ 
/*     */   public List<FieldError> getFieldErrors() {
/* 167 */     return this.bindingResult.getFieldErrors();
/*     */   }
/*     */ 
/*     */   public FieldError getFieldError() {
/* 171 */     return this.bindingResult.getFieldError();
/*     */   }
/*     */ 
/*     */   public boolean hasFieldErrors(String field) {
/* 175 */     return this.bindingResult.hasFieldErrors(field);
/*     */   }
/*     */ 
/*     */   public int getFieldErrorCount(String field) {
/* 179 */     return this.bindingResult.getFieldErrorCount(field);
/*     */   }
/*     */ 
/*     */   public List<FieldError> getFieldErrors(String field) {
/* 183 */     return this.bindingResult.getFieldErrors(field);
/*     */   }
/*     */ 
/*     */   public FieldError getFieldError(String field) {
/* 187 */     return this.bindingResult.getFieldError(field);
/*     */   }
/*     */ 
/*     */   public Object getFieldValue(String field) {
/* 191 */     return this.bindingResult.getFieldValue(field);
/*     */   }
/*     */ 
/*     */   public Class<?> getFieldType(String field) {
/* 195 */     return this.bindingResult.getFieldType(field);
/*     */   }
/*     */ 
/*     */   public Object getTarget() {
/* 199 */     return this.bindingResult.getTarget();
/*     */   }
/*     */ 
/*     */   public Map<String, Object> getModel() {
/* 203 */     return this.bindingResult.getModel();
/*     */   }
/*     */ 
/*     */   public Object getRawFieldValue(String field) {
/* 207 */     return this.bindingResult.getRawFieldValue(field);
/*     */   }
/*     */ 
/*     */   public PropertyEditor findEditor(String field, Class valueType)
/*     */   {
/* 212 */     return this.bindingResult.findEditor(field, valueType);
/*     */   }
/*     */ 
/*     */   public PropertyEditorRegistry getPropertyEditorRegistry() {
/* 216 */     return this.bindingResult.getPropertyEditorRegistry();
/*     */   }
/*     */ 
/*     */   public void addError(ObjectError error) {
/* 220 */     this.bindingResult.addError(error);
/*     */   }
/*     */ 
/*     */   public String[] resolveMessageCodes(String errorCode) {
/* 224 */     return this.bindingResult.resolveMessageCodes(errorCode);
/*     */   }
/*     */ 
/*     */   public String[] resolveMessageCodes(String errorCode, String field) {
/* 228 */     return this.bindingResult.resolveMessageCodes(errorCode, field);
/*     */   }
/*     */ 
/*     */   public void recordSuppressedField(String field) {
/* 232 */     this.bindingResult.recordSuppressedField(field);
/*     */   }
/*     */ 
/*     */   public String[] getSuppressedFields() {
/* 236 */     return this.bindingResult.getSuppressedFields();
/*     */   }
/*     */ 
/*     */   public String getMessage()
/*     */   {
/* 245 */     return this.bindingResult.toString();
/*     */   }
/*     */ 
/*     */   public boolean equals(Object other)
/*     */   {
/* 250 */     return (this == other) || (this.bindingResult.equals(other));
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 255 */     return this.bindingResult.hashCode();
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.validation.BindException
 * JD-Core Version:    0.6.0
 */