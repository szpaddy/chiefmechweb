/*    */ package org.springframework.validation.beanvalidation;
/*    */ 
/*    */ import java.util.Locale;
/*    */ import javax.validation.MessageInterpolator;
/*    */ import javax.validation.MessageInterpolator.Context;
/*    */ import org.springframework.context.i18n.LocaleContextHolder;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ public class LocaleContextMessageInterpolator
/*    */   implements MessageInterpolator
/*    */ {
/*    */   private final MessageInterpolator targetInterpolator;
/*    */ 
/*    */   public LocaleContextMessageInterpolator(MessageInterpolator targetInterpolator)
/*    */   {
/* 43 */     Assert.notNull(targetInterpolator, "Target MessageInterpolator must not be null");
/* 44 */     this.targetInterpolator = targetInterpolator;
/*    */   }
/*    */ 
/*    */   public String interpolate(String message, MessageInterpolator.Context context)
/*    */   {
/* 49 */     return this.targetInterpolator.interpolate(message, context, LocaleContextHolder.getLocale());
/*    */   }
/*    */ 
/*    */   public String interpolate(String message, MessageInterpolator.Context context, Locale locale) {
/* 53 */     return this.targetInterpolator.interpolate(message, context, locale);
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.validation.beanvalidation.LocaleContextMessageInterpolator
 * JD-Core Version:    0.6.0
 */