/*     */ package org.springframework.validation.beanvalidation;
/*     */ 
/*     */ import java.util.Set;
/*     */ import javax.validation.Validation;
/*     */ import javax.validation.Validator;
/*     */ import javax.validation.ValidatorFactory;
/*     */ import javax.validation.bootstrap.ProviderSpecificBootstrap;
/*     */ import org.aopalliance.intercept.MethodInterceptor;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.hibernate.validator.HibernateValidator;
/*     */ import org.hibernate.validator.HibernateValidatorConfiguration;
/*     */ import org.hibernate.validator.method.MethodConstraintViolationException;
/*     */ import org.hibernate.validator.method.MethodValidator;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.validation.annotation.Validated;
/*     */ 
/*     */ public class MethodValidationInterceptor
/*     */   implements MethodInterceptor
/*     */ {
/*     */   private final MethodValidator validator;
/*     */ 
/*     */   public MethodValidationInterceptor()
/*     */   {
/*  66 */     this(((HibernateValidatorConfiguration)Validation.byProvider(HibernateValidator.class).configure()).buildValidatorFactory());
/*     */   }
/*     */ 
/*     */   public MethodValidationInterceptor(ValidatorFactory validatorFactory)
/*     */   {
/*  74 */     this(validatorFactory.getValidator());
/*     */   }
/*     */ 
/*     */   public MethodValidationInterceptor(Validator validator)
/*     */   {
/*  82 */     this.validator = ((MethodValidator)validator.unwrap(MethodValidator.class));
/*     */   }
/*     */ 
/*     */   public Object invoke(MethodInvocation invocation) throws Throwable
/*     */   {
/*  87 */     Class[] groups = determineValidationGroups(invocation);
/*  88 */     Set result = this.validator.validateAllParameters(invocation.getThis(), invocation.getMethod(), invocation.getArguments(), groups);
/*     */ 
/*  90 */     if (!result.isEmpty()) {
/*  91 */       throw new MethodConstraintViolationException(result);
/*     */     }
/*  93 */     Object returnValue = invocation.proceed();
/*  94 */     result = this.validator.validateReturnValue(invocation.getThis(), invocation.getMethod(), returnValue, groups);
/*     */ 
/*  96 */     if (!result.isEmpty()) {
/*  97 */       throw new MethodConstraintViolationException(result);
/*     */     }
/*  99 */     return returnValue;
/*     */   }
/*     */ 
/*     */   protected Class[] determineValidationGroups(MethodInvocation invocation)
/*     */   {
/* 110 */     Validated valid = (Validated)AnnotationUtils.findAnnotation(invocation.getThis().getClass(), Validated.class);
/* 111 */     return valid != null ? valid.value() : new Class[0];
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.validation.beanvalidation.MethodValidationInterceptor
 * JD-Core Version:    0.6.0
 */