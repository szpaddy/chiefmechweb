/*     */ package org.springframework.validation;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Collections;
/*     */ import java.util.EmptyStackException;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Stack;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public abstract class AbstractErrors
/*     */   implements Errors, Serializable
/*     */ {
/*  39 */   private String nestedPath = "";
/*     */ 
/*  41 */   private final Stack<String> nestedPathStack = new Stack();
/*     */ 
/*     */   public void setNestedPath(String nestedPath)
/*     */   {
/*  45 */     doSetNestedPath(nestedPath);
/*  46 */     this.nestedPathStack.clear();
/*     */   }
/*     */ 
/*     */   public String getNestedPath() {
/*  50 */     return this.nestedPath;
/*     */   }
/*     */ 
/*     */   public void pushNestedPath(String subPath) {
/*  54 */     this.nestedPathStack.push(getNestedPath());
/*  55 */     doSetNestedPath(getNestedPath() + subPath);
/*     */   }
/*     */ 
/*     */   public void popNestedPath() throws IllegalArgumentException {
/*     */     try {
/*  60 */       String formerNestedPath = (String)this.nestedPathStack.pop();
/*  61 */       doSetNestedPath(formerNestedPath);
/*     */     }
/*     */     catch (EmptyStackException ex) {
/*  64 */       throw new IllegalStateException("Cannot pop nested path: no nested path on stack");
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void doSetNestedPath(String nestedPath)
/*     */   {
/*  73 */     if (nestedPath == null) {
/*  74 */       nestedPath = "";
/*     */     }
/*  76 */     nestedPath = canonicalFieldName(nestedPath);
/*  77 */     if ((nestedPath.length() > 0) && (!nestedPath.endsWith("."))) {
/*  78 */       nestedPath = nestedPath + ".";
/*     */     }
/*  80 */     this.nestedPath = nestedPath;
/*     */   }
/*     */ 
/*     */   protected String fixedField(String field)
/*     */   {
/*  88 */     if (StringUtils.hasLength(field)) {
/*  89 */       return getNestedPath() + canonicalFieldName(field);
/*     */     }
/*     */ 
/*  92 */     String path = getNestedPath();
/*  93 */     return path.endsWith(".") ? path.substring(0, path.length() - ".".length()) : path;
/*     */   }
/*     */ 
/*     */   protected String canonicalFieldName(String field)
/*     */   {
/* 105 */     return field;
/*     */   }
/*     */ 
/*     */   public void reject(String errorCode)
/*     */   {
/* 110 */     reject(errorCode, null, null);
/*     */   }
/*     */ 
/*     */   public void reject(String errorCode, String defaultMessage) {
/* 114 */     reject(errorCode, null, defaultMessage);
/*     */   }
/*     */ 
/*     */   public void rejectValue(String field, String errorCode) {
/* 118 */     rejectValue(field, errorCode, null, null);
/*     */   }
/*     */ 
/*     */   public void rejectValue(String field, String errorCode, String defaultMessage) {
/* 122 */     rejectValue(field, errorCode, null, defaultMessage);
/*     */   }
/*     */ 
/*     */   public boolean hasErrors()
/*     */   {
/* 127 */     return !getAllErrors().isEmpty();
/*     */   }
/*     */ 
/*     */   public int getErrorCount() {
/* 131 */     return getAllErrors().size();
/*     */   }
/*     */ 
/*     */   public List<ObjectError> getAllErrors() {
/* 135 */     List result = new LinkedList();
/* 136 */     result.addAll(getGlobalErrors());
/* 137 */     result.addAll(getFieldErrors());
/* 138 */     return Collections.unmodifiableList(result);
/*     */   }
/*     */ 
/*     */   public boolean hasGlobalErrors() {
/* 142 */     return getGlobalErrorCount() > 0;
/*     */   }
/*     */ 
/*     */   public int getGlobalErrorCount() {
/* 146 */     return getGlobalErrors().size();
/*     */   }
/*     */ 
/*     */   public ObjectError getGlobalError() {
/* 150 */     List globalErrors = getGlobalErrors();
/* 151 */     return !globalErrors.isEmpty() ? (ObjectError)globalErrors.get(0) : null;
/*     */   }
/*     */ 
/*     */   public boolean hasFieldErrors() {
/* 155 */     return getFieldErrorCount() > 0;
/*     */   }
/*     */ 
/*     */   public int getFieldErrorCount() {
/* 159 */     return getFieldErrors().size();
/*     */   }
/*     */ 
/*     */   public FieldError getFieldError() {
/* 163 */     List fieldErrors = getFieldErrors();
/* 164 */     return !fieldErrors.isEmpty() ? (FieldError)fieldErrors.get(0) : null;
/*     */   }
/*     */ 
/*     */   public boolean hasFieldErrors(String field) {
/* 168 */     return getFieldErrorCount(field) > 0;
/*     */   }
/*     */ 
/*     */   public int getFieldErrorCount(String field) {
/* 172 */     return getFieldErrors(field).size();
/*     */   }
/*     */ 
/*     */   public List<FieldError> getFieldErrors(String field) {
/* 176 */     List fieldErrors = getFieldErrors();
/* 177 */     List result = new LinkedList();
/* 178 */     String fixedField = fixedField(field);
/* 179 */     for (FieldError error : fieldErrors) {
/* 180 */       if (isMatchingFieldError(fixedField, error)) {
/* 181 */         result.add(error);
/*     */       }
/*     */     }
/* 184 */     return Collections.unmodifiableList(result);
/*     */   }
/*     */ 
/*     */   public FieldError getFieldError(String field) {
/* 188 */     List fieldErrors = getFieldErrors(field);
/* 189 */     return !fieldErrors.isEmpty() ? (FieldError)fieldErrors.get(0) : null;
/*     */   }
/*     */ 
/*     */   public Class<?> getFieldType(String field)
/*     */   {
/* 194 */     Object value = getFieldValue(field);
/* 195 */     if (value != null) {
/* 196 */       return value.getClass();
/*     */     }
/* 198 */     return null;
/*     */   }
/*     */ 
/*     */   protected boolean isMatchingFieldError(String field, FieldError fieldError)
/*     */   {
/* 208 */     return (field.equals(fieldError.getField())) || ((field.endsWith("*")) && (fieldError.getField().startsWith(field.substring(0, field.length() - 1))));
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 215 */     StringBuilder sb = new StringBuilder(getClass().getName());
/* 216 */     sb.append(": ").append(getErrorCount()).append(" errors");
/* 217 */     for (ObjectError error : getAllErrors()) {
/* 218 */       sb.append('\n').append(error);
/*     */     }
/* 220 */     return sb.toString();
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.validation.AbstractErrors
 * JD-Core Version:    0.6.0
 */