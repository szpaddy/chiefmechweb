package org.springframework.validation;

public abstract interface Validator
{
  public abstract boolean supports(Class<?> paramClass);

  public abstract void validate(Object paramObject, Errors paramErrors);
}

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.validation.Validator
 * JD-Core Version:    0.6.0
 */