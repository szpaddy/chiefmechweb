/*     */ package org.springframework.validation;
/*     */ 
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ public class FieldError extends ObjectError
/*     */ {
/*     */   private final String field;
/*     */   private final Object rejectedValue;
/*     */   private final boolean bindingFailure;
/*     */ 
/*     */   public FieldError(String objectName, String field, String defaultMessage)
/*     */   {
/*  51 */     this(objectName, field, null, false, null, null, defaultMessage);
/*     */   }
/*     */ 
/*     */   public FieldError(String objectName, String field, Object rejectedValue, boolean bindingFailure, String[] codes, Object[] arguments, String defaultMessage)
/*     */   {
/*  69 */     super(objectName, codes, arguments, defaultMessage);
/*  70 */     Assert.notNull(field, "Field must not be null");
/*  71 */     this.field = field;
/*  72 */     this.rejectedValue = rejectedValue;
/*  73 */     this.bindingFailure = bindingFailure;
/*     */   }
/*     */ 
/*     */   public String getField()
/*     */   {
/*  81 */     return this.field;
/*     */   }
/*     */ 
/*     */   public Object getRejectedValue()
/*     */   {
/*  88 */     return this.rejectedValue;
/*     */   }
/*     */ 
/*     */   public boolean isBindingFailure()
/*     */   {
/*  96 */     return this.bindingFailure;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 102 */     return "Field error in object '" + getObjectName() + "' on field '" + this.field + "': rejected value [" + this.rejectedValue + "]; " + resolvableToString();
/*     */   }
/*     */ 
/*     */   public boolean equals(Object other)
/*     */   {
/* 108 */     if (this == other) {
/* 109 */       return true;
/*     */     }
/* 111 */     if (!super.equals(other)) {
/* 112 */       return false;
/*     */     }
/* 114 */     FieldError otherError = (FieldError)other;
/* 115 */     return (getField().equals(otherError.getField())) && (ObjectUtils.nullSafeEquals(getRejectedValue(), otherError.getRejectedValue())) && (isBindingFailure() == otherError.isBindingFailure());
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 122 */     int hashCode = super.hashCode();
/* 123 */     hashCode = 29 * hashCode + getField().hashCode();
/* 124 */     hashCode = 29 * hashCode + ObjectUtils.nullSafeHashCode(getRejectedValue());
/* 125 */     hashCode = 29 * hashCode + (isBindingFailure() ? 1 : 0);
/* 126 */     return hashCode;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.validation.FieldError
 * JD-Core Version:    0.6.0
 */