/*     */ package org.springframework.jmx.support;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import javax.management.InstanceAlreadyExistsException;
/*     */ import javax.management.InstanceNotFoundException;
/*     */ import javax.management.JMException;
/*     */ import javax.management.MBeanServer;
/*     */ import javax.management.ObjectInstance;
/*     */ import javax.management.ObjectName;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.Constants;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public class MBeanRegistrationSupport
/*     */ {
/*     */ 
/*     */   @Deprecated
/*     */   public static final int REGISTRATION_FAIL_ON_EXISTING = 0;
/*     */ 
/*     */   @Deprecated
/*     */   public static final int REGISTRATION_IGNORE_EXISTING = 1;
/*     */ 
/*     */   @Deprecated
/*     */   public static final int REGISTRATION_REPLACE_EXISTING = 2;
/* 101 */   private static final Constants constants = new Constants(MBeanRegistrationSupport.class);
/*     */ 
/* 106 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   protected MBeanServer server;
/* 116 */   private final Set<ObjectName> registeredBeans = Collections.synchronizedSet(new LinkedHashSet());
/*     */ 
/* 122 */   private RegistrationPolicy registrationPolicy = RegistrationPolicy.FAIL_ON_EXISTING;
/*     */ 
/*     */   public void setServer(MBeanServer server)
/*     */   {
/* 131 */     this.server = server;
/*     */   }
/*     */ 
/*     */   public final MBeanServer getServer()
/*     */   {
/* 138 */     return this.server;
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public void setRegistrationBehaviorName(String registrationBehavior)
/*     */   {
/* 152 */     setRegistrationBehavior(constants.asNumber(registrationBehavior).intValue());
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public void setRegistrationBehavior(int registrationBehavior)
/*     */   {
/* 167 */     setRegistrationPolicy(RegistrationPolicy.valueOf(registrationBehavior));
/*     */   }
/*     */ 
/*     */   public void setRegistrationPolicy(RegistrationPolicy registrationPolicy)
/*     */   {
/* 177 */     Assert.notNull(registrationPolicy, "RegistrationPolicy must not be null");
/* 178 */     this.registrationPolicy = registrationPolicy;
/*     */   }
/*     */ 
/*     */   protected void doRegister(Object mbean, ObjectName objectName)
/*     */     throws JMException
/*     */   {
/* 191 */     ObjectInstance registeredBean = null;
/*     */     try {
/* 193 */       registeredBean = this.server.registerMBean(mbean, objectName);
/*     */     }
/*     */     catch (InstanceAlreadyExistsException ex) {
/* 196 */       if (this.registrationPolicy == RegistrationPolicy.IGNORE_EXISTING) {
/* 197 */         if (this.logger.isDebugEnabled()) {
/* 198 */           this.logger.debug("Ignoring existing MBean at [" + objectName + "]");
/*     */         }
/*     */       }
/* 201 */       else if (this.registrationPolicy == RegistrationPolicy.REPLACE_EXISTING) {
/*     */         try {
/* 203 */           if (this.logger.isDebugEnabled()) {
/* 204 */             this.logger.debug("Replacing existing MBean at [" + objectName + "]");
/*     */           }
/* 206 */           this.server.unregisterMBean(objectName);
/* 207 */           registeredBean = this.server.registerMBean(mbean, objectName);
/*     */         }
/*     */         catch (InstanceNotFoundException ex2) {
/* 210 */           this.logger.error("Unable to replace existing MBean at [" + objectName + "]", ex2);
/* 211 */           throw ex;
/*     */         }
/*     */       }
/*     */       else {
/* 215 */         throw ex;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 220 */     ObjectName actualObjectName = registeredBean != null ? registeredBean.getObjectName() : null;
/* 221 */     if (actualObjectName == null) {
/* 222 */       actualObjectName = objectName;
/*     */     }
/* 224 */     this.registeredBeans.add(actualObjectName);
/* 225 */     onRegister(actualObjectName, mbean);
/*     */   }
/*     */ 
/*     */   protected void unregisterBeans()
/*     */   {
/* 232 */     for (ObjectName objectName : new LinkedHashSet(this.registeredBeans))
/* 233 */       doUnregister(objectName);
/*     */   }
/*     */ 
/*     */   protected void doUnregister(ObjectName objectName)
/*     */   {
/*     */     try
/*     */     {
/* 244 */       if (this.server.isRegistered(objectName)) {
/* 245 */         this.server.unregisterMBean(objectName);
/* 246 */         onUnregister(objectName);
/*     */       }
/* 249 */       else if (this.logger.isWarnEnabled()) {
/* 250 */         this.logger.warn("Could not unregister MBean [" + objectName + "] as said MBean " + "is not registered (perhaps already unregistered by an external process)");
/*     */       }
/*     */ 
/*     */     }
/*     */     catch (JMException ex)
/*     */     {
/* 256 */       if (this.logger.isErrorEnabled()) {
/* 257 */         this.logger.error("Could not unregister MBean [" + objectName + "]", ex);
/*     */       }
/*     */     }
/* 260 */     this.registeredBeans.remove(objectName);
/*     */   }
/*     */ 
/*     */   protected final ObjectName[] getRegisteredObjectNames()
/*     */   {
/* 267 */     return (ObjectName[])this.registeredBeans.toArray(new ObjectName[this.registeredBeans.size()]);
/*     */   }
/*     */ 
/*     */   protected void onRegister(ObjectName objectName, Object mbean)
/*     */   {
/* 279 */     onRegister(objectName);
/*     */   }
/*     */ 
/*     */   protected void onRegister(ObjectName objectName)
/*     */   {
/*     */   }
/*     */ 
/*     */   protected void onUnregister(ObjectName objectName)
/*     */   {
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.jmx.support.MBeanRegistrationSupport
 * JD-Core Version:    0.6.0
 */