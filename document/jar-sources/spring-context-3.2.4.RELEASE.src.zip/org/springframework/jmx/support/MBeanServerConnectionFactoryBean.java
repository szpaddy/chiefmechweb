/*     */ package org.springframework.jmx.support;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.MalformedURLException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import javax.management.MBeanServerConnection;
/*     */ import javax.management.remote.JMXConnector;
/*     */ import javax.management.remote.JMXConnectorFactory;
/*     */ import javax.management.remote.JMXServiceURL;
/*     */ import org.springframework.aop.TargetSource;
/*     */ import org.springframework.aop.framework.ProxyFactory;
/*     */ import org.springframework.aop.target.AbstractLazyCreationTargetSource;
/*     */ import org.springframework.beans.factory.BeanClassLoaderAware;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ 
/*     */ public class MBeanServerConnectionFactoryBean
/*     */   implements FactoryBean<MBeanServerConnection>, BeanClassLoaderAware, InitializingBean, DisposableBean
/*     */ {
/*     */   private JMXServiceURL serviceUrl;
/*     */   private Map<String, Object> environment;
/*     */   private boolean connectOnStartup;
/*     */   private ClassLoader beanClassLoader;
/*     */   private JMXConnector connector;
/*     */   private MBeanServerConnection connection;
/*     */   private JMXConnectorLazyInitTargetSource connectorTargetSource;
/*     */ 
/*     */   public MBeanServerConnectionFactoryBean()
/*     */   {
/*  57 */     this.environment = new HashMap();
/*     */ 
/*  59 */     this.connectOnStartup = true;
/*     */ 
/*  61 */     this.beanClassLoader = ClassUtils.getDefaultClassLoader();
/*     */   }
/*     */ 
/*     */   public void setServiceUrl(String url)
/*     */     throws MalformedURLException
/*     */   {
/*  74 */     this.serviceUrl = new JMXServiceURL(url);
/*     */   }
/*     */ 
/*     */   public void setEnvironment(Properties environment)
/*     */   {
/*  82 */     CollectionUtils.mergePropertiesIntoMap(environment, this.environment);
/*     */   }
/*     */ 
/*     */   public void setEnvironmentMap(Map<String, ?> environment)
/*     */   {
/*  90 */     if (environment != null)
/*  91 */       this.environment.putAll(environment);
/*     */   }
/*     */ 
/*     */   public void setConnectOnStartup(boolean connectOnStartup)
/*     */   {
/* 101 */     this.connectOnStartup = connectOnStartup;
/*     */   }
/*     */ 
/*     */   public void setBeanClassLoader(ClassLoader classLoader) {
/* 105 */     this.beanClassLoader = classLoader;
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */     throws IOException
/*     */   {
/* 114 */     if (this.serviceUrl == null) {
/* 115 */       throw new IllegalArgumentException("Property 'serviceUrl' is required");
/*     */     }
/*     */ 
/* 118 */     if (this.connectOnStartup) {
/* 119 */       connect();
/*     */     }
/*     */     else
/* 122 */       createLazyConnection();
/*     */   }
/*     */ 
/*     */   private void connect()
/*     */     throws IOException
/*     */   {
/* 131 */     this.connector = JMXConnectorFactory.connect(this.serviceUrl, this.environment);
/* 132 */     this.connection = this.connector.getMBeanServerConnection();
/*     */   }
/*     */ 
/*     */   private void createLazyConnection()
/*     */   {
/* 139 */     this.connectorTargetSource = new JMXConnectorLazyInitTargetSource(null);
/* 140 */     TargetSource connectionTargetSource = new MBeanServerConnectionLazyInitTargetSource(null);
/*     */ 
/* 142 */     this.connector = ((JMXConnector)new ProxyFactory(JMXConnector.class, this.connectorTargetSource).getProxy(this.beanClassLoader));
/*     */ 
/* 144 */     this.connection = ((MBeanServerConnection)new ProxyFactory(MBeanServerConnection.class, connectionTargetSource).getProxy(this.beanClassLoader));
/*     */   }
/*     */ 
/*     */   public MBeanServerConnection getObject()
/*     */   {
/* 150 */     return this.connection;
/*     */   }
/*     */ 
/*     */   public Class<? extends MBeanServerConnection> getObjectType() {
/* 154 */     return this.connection != null ? this.connection.getClass() : MBeanServerConnection.class;
/*     */   }
/*     */ 
/*     */   public boolean isSingleton() {
/* 158 */     return true;
/*     */   }
/*     */ 
/*     */   public void destroy()
/*     */     throws IOException
/*     */   {
/* 166 */     if ((this.connectorTargetSource == null) || (this.connectorTargetSource.isInitialized()))
/* 167 */       this.connector.close();
/*     */   }
/*     */ 
/*     */   private class MBeanServerConnectionLazyInitTargetSource extends AbstractLazyCreationTargetSource
/*     */   {
/*     */     private MBeanServerConnectionLazyInitTargetSource()
/*     */     {
/*     */     }
/*     */ 
/*     */     protected Object createObject()
/*     */       throws Exception
/*     */     {
/* 199 */       return MBeanServerConnectionFactoryBean.this.connector.getMBeanServerConnection();
/*     */     }
/*     */ 
/*     */     public Class<?> getTargetClass()
/*     */     {
/* 204 */       return MBeanServerConnection.class;
/*     */     }
/*     */   }
/*     */ 
/*     */   private class JMXConnectorLazyInitTargetSource extends AbstractLazyCreationTargetSource
/*     */   {
/*     */     private JMXConnectorLazyInitTargetSource()
/*     */     {
/*     */     }
/*     */ 
/*     */     protected Object createObject()
/*     */       throws Exception
/*     */     {
/* 182 */       return JMXConnectorFactory.connect(MBeanServerConnectionFactoryBean.this.serviceUrl, MBeanServerConnectionFactoryBean.this.environment);
/*     */     }
/*     */ 
/*     */     public Class<?> getTargetClass()
/*     */     {
/* 187 */       return JMXConnector.class;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.jmx.support.MBeanServerConnectionFactoryBean
 * JD-Core Version:    0.6.0
 */