package org.springframework.jmx.export.assembler;

public abstract interface AutodetectCapableMBeanInfoAssembler extends MBeanInfoAssembler
{
  public abstract boolean includeBean(Class<?> paramClass, String paramString);
}

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.jmx.export.assembler.AutodetectCapableMBeanInfoAssembler
 * JD-Core Version:    0.6.0
 */