/*     */ package org.springframework.jmx.export.assembler;
/*     */ 
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.lang.reflect.Method;
/*     */ import javax.management.Descriptor;
/*     */ import javax.management.MBeanParameterInfo;
/*     */ import javax.management.modelmbean.ModelMBeanNotificationInfo;
/*     */ import org.springframework.aop.support.AopUtils;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.jmx.export.metadata.InvalidMetadataException;
/*     */ import org.springframework.jmx.export.metadata.JmxAttributeSource;
/*     */ import org.springframework.jmx.export.metadata.JmxMetadataUtils;
/*     */ import org.springframework.jmx.export.metadata.ManagedAttribute;
/*     */ import org.springframework.jmx.export.metadata.ManagedMetric;
/*     */ import org.springframework.jmx.export.metadata.ManagedNotification;
/*     */ import org.springframework.jmx.export.metadata.ManagedOperation;
/*     */ import org.springframework.jmx.export.metadata.ManagedOperationParameter;
/*     */ import org.springframework.jmx.export.metadata.ManagedResource;
/*     */ import org.springframework.jmx.support.MetricType;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class MetadataMBeanInfoAssembler extends AbstractReflectiveMBeanInfoAssembler
/*     */   implements AutodetectCapableMBeanInfoAssembler, InitializingBean
/*     */ {
/*     */   private JmxAttributeSource attributeSource;
/*     */ 
/*     */   public MetadataMBeanInfoAssembler()
/*     */   {
/*     */   }
/*     */ 
/*     */   public MetadataMBeanInfoAssembler(JmxAttributeSource attributeSource)
/*     */   {
/*  77 */     Assert.notNull(attributeSource, "JmxAttributeSource must not be null");
/*  78 */     this.attributeSource = attributeSource;
/*     */   }
/*     */ 
/*     */   public void setAttributeSource(JmxAttributeSource attributeSource)
/*     */   {
/*  88 */     Assert.notNull(attributeSource, "JmxAttributeSource must not be null");
/*  89 */     this.attributeSource = attributeSource;
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet() {
/*  93 */     if (this.attributeSource == null)
/*  94 */       throw new IllegalArgumentException("Property 'attributeSource' is required");
/*     */   }
/*     */ 
/*     */   protected void checkManagedBean(Object managedBean)
/*     */     throws IllegalArgumentException
/*     */   {
/* 105 */     if (AopUtils.isJdkDynamicProxy(managedBean))
/* 106 */       throw new IllegalArgumentException("MetadataMBeanInfoAssembler does not support JDK dynamic proxies - export the target beans directly or use CGLIB proxies instead");
/*     */   }
/*     */ 
/*     */   public boolean includeBean(Class<?> beanClass, String beanName)
/*     */   {
/* 119 */     return this.attributeSource.getManagedResource(getClassToExpose(beanClass)) != null;
/*     */   }
/*     */ 
/*     */   protected boolean includeReadAttribute(Method method, String beanKey)
/*     */   {
/* 130 */     return (hasManagedAttribute(method)) || (hasManagedMetric(method));
/*     */   }
/*     */ 
/*     */   protected boolean includeWriteAttribute(Method method, String beanKey)
/*     */   {
/* 141 */     return hasManagedAttribute(method);
/*     */   }
/*     */ 
/*     */   protected boolean includeOperation(Method method, String beanKey)
/*     */   {
/* 152 */     PropertyDescriptor pd = BeanUtils.findPropertyForMethod(method);
/* 153 */     if ((pd != null) && 
/* 154 */       (hasManagedAttribute(method))) {
/* 155 */       return true;
/*     */     }
/*     */ 
/* 158 */     return hasManagedOperation(method);
/*     */   }
/*     */ 
/*     */   private boolean hasManagedAttribute(Method method)
/*     */   {
/* 165 */     return this.attributeSource.getManagedAttribute(method) != null;
/*     */   }
/*     */ 
/*     */   private boolean hasManagedMetric(Method method)
/*     */   {
/* 172 */     return this.attributeSource.getManagedMetric(method) != null;
/*     */   }
/*     */ 
/*     */   private boolean hasManagedOperation(Method method)
/*     */   {
/* 180 */     return this.attributeSource.getManagedOperation(method) != null;
/*     */   }
/*     */ 
/*     */   protected String getDescription(Object managedBean, String beanKey)
/*     */   {
/* 190 */     ManagedResource mr = this.attributeSource.getManagedResource(getClassToExpose(managedBean));
/* 191 */     return mr != null ? mr.getDescription() : "";
/*     */   }
/*     */ 
/*     */   protected String getAttributeDescription(PropertyDescriptor propertyDescriptor, String beanKey)
/*     */   {
/* 201 */     Method readMethod = propertyDescriptor.getReadMethod();
/* 202 */     Method writeMethod = propertyDescriptor.getWriteMethod();
/*     */ 
/* 204 */     ManagedAttribute getter = readMethod != null ? this.attributeSource.getManagedAttribute(readMethod) : null;
/*     */ 
/* 206 */     ManagedAttribute setter = writeMethod != null ? this.attributeSource.getManagedAttribute(writeMethod) : null;
/*     */ 
/* 209 */     if ((getter != null) && (StringUtils.hasText(getter.getDescription()))) {
/* 210 */       return getter.getDescription();
/*     */     }
/* 212 */     if ((setter != null) && (StringUtils.hasText(setter.getDescription()))) {
/* 213 */       return setter.getDescription();
/*     */     }
/*     */ 
/* 216 */     ManagedMetric metric = readMethod != null ? this.attributeSource.getManagedMetric(readMethod) : null;
/* 217 */     if ((metric != null) && (StringUtils.hasText(metric.getDescription()))) {
/* 218 */       return metric.getDescription();
/*     */     }
/*     */ 
/* 221 */     return propertyDescriptor.getDisplayName();
/*     */   }
/*     */ 
/*     */   protected String getOperationDescription(Method method, String beanKey)
/*     */   {
/* 230 */     PropertyDescriptor pd = BeanUtils.findPropertyForMethod(method);
/* 231 */     if (pd != null) {
/* 232 */       ManagedAttribute ma = this.attributeSource.getManagedAttribute(method);
/* 233 */       if ((ma != null) && (StringUtils.hasText(ma.getDescription()))) {
/* 234 */         return ma.getDescription();
/*     */       }
/* 236 */       ManagedMetric metric = this.attributeSource.getManagedMetric(method);
/* 237 */       if ((metric != null) && (StringUtils.hasText(metric.getDescription()))) {
/* 238 */         return metric.getDescription();
/*     */       }
/* 240 */       return method.getName();
/*     */     }
/*     */ 
/* 243 */     ManagedOperation mo = this.attributeSource.getManagedOperation(method);
/* 244 */     if ((mo != null) && (StringUtils.hasText(mo.getDescription()))) {
/* 245 */       return mo.getDescription();
/*     */     }
/* 247 */     return method.getName();
/*     */   }
/*     */ 
/*     */   protected MBeanParameterInfo[] getOperationParameters(Method method, String beanKey)
/*     */   {
/* 258 */     ManagedOperationParameter[] params = this.attributeSource.getManagedOperationParameters(method);
/* 259 */     if (ObjectUtils.isEmpty(params)) {
/* 260 */       return super.getOperationParameters(method, beanKey);
/*     */     }
/*     */ 
/* 263 */     MBeanParameterInfo[] parameterInfo = new MBeanParameterInfo[params.length];
/* 264 */     Class[] methodParameters = method.getParameterTypes();
/* 265 */     for (int i = 0; i < params.length; i++) {
/* 266 */       ManagedOperationParameter param = params[i];
/* 267 */       parameterInfo[i] = new MBeanParameterInfo(param.getName(), methodParameters[i].getName(), param.getDescription());
/*     */     }
/*     */ 
/* 270 */     return parameterInfo;
/*     */   }
/*     */ 
/*     */   protected ModelMBeanNotificationInfo[] getNotificationInfo(Object managedBean, String beanKey)
/*     */   {
/* 279 */     ManagedNotification[] notificationAttributes = this.attributeSource.getManagedNotifications(getClassToExpose(managedBean));
/*     */ 
/* 281 */     ModelMBeanNotificationInfo[] notificationInfos = new ModelMBeanNotificationInfo[notificationAttributes.length];
/*     */ 
/* 284 */     for (int i = 0; i < notificationAttributes.length; i++) {
/* 285 */       ManagedNotification attribute = notificationAttributes[i];
/* 286 */       notificationInfos[i] = JmxMetadataUtils.convertToModelMBeanNotificationInfo(attribute);
/*     */     }
/*     */ 
/* 289 */     return notificationInfos;
/*     */   }
/*     */ 
/*     */   protected void populateMBeanDescriptor(Descriptor desc, Object managedBean, String beanKey)
/*     */   {
/* 300 */     ManagedResource mr = this.attributeSource.getManagedResource(getClassToExpose(managedBean));
/* 301 */     if (mr == null) {
/* 302 */       throw new InvalidMetadataException("No ManagedResource attribute found for class: " + getClassToExpose(managedBean));
/*     */     }
/*     */ 
/* 306 */     applyCurrencyTimeLimit(desc, mr.getCurrencyTimeLimit());
/*     */ 
/* 308 */     if (mr.isLog()) {
/* 309 */       desc.setField("log", "true");
/*     */     }
/* 311 */     if (StringUtils.hasLength(mr.getLogFile())) {
/* 312 */       desc.setField("logFile", mr.getLogFile());
/*     */     }
/*     */ 
/* 315 */     if (StringUtils.hasLength(mr.getPersistPolicy())) {
/* 316 */       desc.setField("persistPolicy", mr.getPersistPolicy());
/*     */     }
/* 318 */     if (mr.getPersistPeriod() >= 0) {
/* 319 */       desc.setField("persistPeriod", Integer.toString(mr.getPersistPeriod()));
/*     */     }
/* 321 */     if (StringUtils.hasLength(mr.getPersistName())) {
/* 322 */       desc.setField("persistName", mr.getPersistName());
/*     */     }
/* 324 */     if (StringUtils.hasLength(mr.getPersistLocation()))
/* 325 */       desc.setField("persistLocation", mr.getPersistLocation());
/*     */   }
/*     */ 
/*     */   protected void populateAttributeDescriptor(Descriptor desc, Method getter, Method setter, String beanKey)
/*     */   {
/* 335 */     if ((getter != null) && (hasManagedMetric(getter))) {
/* 336 */       populateMetricDescriptor(desc, this.attributeSource.getManagedMetric(getter));
/*     */     }
/*     */     else {
/* 339 */       ManagedAttribute gma = getter == null ? ManagedAttribute.EMPTY : this.attributeSource.getManagedAttribute(getter);
/*     */ 
/* 341 */       ManagedAttribute sma = setter == null ? ManagedAttribute.EMPTY : this.attributeSource.getManagedAttribute(setter);
/*     */ 
/* 343 */       populateAttributeDescriptor(desc, gma, sma);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void populateAttributeDescriptor(Descriptor desc, ManagedAttribute gma, ManagedAttribute sma) {
/* 348 */     applyCurrencyTimeLimit(desc, resolveIntDescriptor(gma.getCurrencyTimeLimit(), sma.getCurrencyTimeLimit()));
/*     */ 
/* 350 */     Object defaultValue = resolveObjectDescriptor(gma.getDefaultValue(), sma.getDefaultValue());
/* 351 */     desc.setField("default", defaultValue);
/*     */ 
/* 353 */     String persistPolicy = resolveStringDescriptor(gma.getPersistPolicy(), sma.getPersistPolicy());
/* 354 */     if (StringUtils.hasLength(persistPolicy)) {
/* 355 */       desc.setField("persistPolicy", persistPolicy);
/*     */     }
/* 357 */     int persistPeriod = resolveIntDescriptor(gma.getPersistPeriod(), sma.getPersistPeriod());
/* 358 */     if (persistPeriod >= 0)
/* 359 */       desc.setField("persistPeriod", Integer.toString(persistPeriod));
/*     */   }
/*     */ 
/*     */   private void populateMetricDescriptor(Descriptor desc, ManagedMetric metric)
/*     */   {
/* 364 */     applyCurrencyTimeLimit(desc, metric.getCurrencyTimeLimit());
/*     */ 
/* 366 */     if (StringUtils.hasLength(metric.getPersistPolicy())) {
/* 367 */       desc.setField("persistPolicy", metric.getPersistPolicy());
/*     */     }
/* 369 */     if (metric.getPersistPeriod() >= 0) {
/* 370 */       desc.setField("persistPeriod", Integer.toString(metric.getPersistPeriod()));
/*     */     }
/*     */ 
/* 373 */     if (StringUtils.hasLength(metric.getDisplayName())) {
/* 374 */       desc.setField("displayName", metric.getDisplayName());
/*     */     }
/*     */ 
/* 377 */     if (StringUtils.hasLength(metric.getUnit())) {
/* 378 */       desc.setField("units", metric.getUnit());
/*     */     }
/*     */ 
/* 381 */     if (StringUtils.hasLength(metric.getCategory())) {
/* 382 */       desc.setField("metricCategory", metric.getCategory());
/*     */     }
/*     */ 
/* 385 */     String metricType = metric.getMetricType() == null ? MetricType.GAUGE.toString() : metric.getMetricType().toString();
/* 386 */     desc.setField("metricType", metricType);
/*     */   }
/*     */ 
/*     */   protected void populateOperationDescriptor(Descriptor desc, Method method, String beanKey)
/*     */   {
/* 396 */     ManagedOperation mo = this.attributeSource.getManagedOperation(method);
/* 397 */     if (mo != null)
/* 398 */       applyCurrencyTimeLimit(desc, mo.getCurrencyTimeLimit());
/*     */   }
/*     */ 
/*     */   private int resolveIntDescriptor(int getter, int setter)
/*     */   {
/* 412 */     return getter >= setter ? getter : setter;
/*     */   }
/*     */ 
/*     */   private Object resolveObjectDescriptor(Object getter, Object setter)
/*     */   {
/* 424 */     return getter != null ? getter : setter;
/*     */   }
/*     */ 
/*     */   private String resolveStringDescriptor(String getter, String setter)
/*     */   {
/* 438 */     return StringUtils.hasLength(getter) ? getter : setter;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.jmx.export.assembler.MetadataMBeanInfoAssembler
 * JD-Core Version:    0.6.0
 */