package org.springframework.jmx.export.assembler;

import javax.management.JMException;
import javax.management.modelmbean.ModelMBeanInfo;

public abstract interface MBeanInfoAssembler
{
  public abstract ModelMBeanInfo getMBeanInfo(Object paramObject, String paramString)
    throws JMException;
}

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.jmx.export.assembler.MBeanInfoAssembler
 * JD-Core Version:    0.6.0
 */