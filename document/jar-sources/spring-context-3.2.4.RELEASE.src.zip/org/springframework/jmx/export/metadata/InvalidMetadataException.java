/*    */ package org.springframework.jmx.export.metadata;
/*    */ 
/*    */ import org.springframework.jmx.JmxException;
/*    */ 
/*    */ public class InvalidMetadataException extends JmxException
/*    */ {
/*    */   public InvalidMetadataException(String msg)
/*    */   {
/* 39 */     super(msg);
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.jmx.export.metadata.InvalidMetadataException
 * JD-Core Version:    0.6.0
 */