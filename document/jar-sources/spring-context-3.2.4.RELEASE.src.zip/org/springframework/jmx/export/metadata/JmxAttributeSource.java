package org.springframework.jmx.export.metadata;

import java.lang.reflect.Method;

public abstract interface JmxAttributeSource
{
  public abstract ManagedResource getManagedResource(Class<?> paramClass)
    throws InvalidMetadataException;

  public abstract ManagedAttribute getManagedAttribute(Method paramMethod)
    throws InvalidMetadataException;

  public abstract ManagedMetric getManagedMetric(Method paramMethod)
    throws InvalidMetadataException;

  public abstract ManagedOperation getManagedOperation(Method paramMethod)
    throws InvalidMetadataException;

  public abstract ManagedOperationParameter[] getManagedOperationParameters(Method paramMethod)
    throws InvalidMetadataException;

  public abstract ManagedNotification[] getManagedNotifications(Class<?> paramClass)
    throws InvalidMetadataException;
}

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.jmx.export.metadata.JmxAttributeSource
 * JD-Core Version:    0.6.0
 */