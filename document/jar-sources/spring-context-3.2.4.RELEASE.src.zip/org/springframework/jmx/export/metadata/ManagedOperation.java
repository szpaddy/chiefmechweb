package org.springframework.jmx.export.metadata;

public class ManagedOperation extends AbstractJmxAttribute
{
}

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.jmx.export.metadata.ManagedOperation
 * JD-Core Version:    0.6.0
 */