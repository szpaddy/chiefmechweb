package org.springframework.jmx.export.notification;

import org.springframework.beans.factory.Aware;

public abstract interface NotificationPublisherAware extends Aware
{
  public abstract void setNotificationPublisher(NotificationPublisher paramNotificationPublisher);
}

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.jmx.export.notification.NotificationPublisherAware
 * JD-Core Version:    0.6.0
 */