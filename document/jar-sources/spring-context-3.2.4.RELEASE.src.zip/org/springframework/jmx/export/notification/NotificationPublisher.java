package org.springframework.jmx.export.notification;

import javax.management.Notification;

public abstract interface NotificationPublisher
{
  public abstract void sendNotification(Notification paramNotification)
    throws UnableToSendNotificationException;
}

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.jmx.export.notification.NotificationPublisher
 * JD-Core Version:    0.6.0
 */