package org.springframework.jmx.export.naming;

import javax.management.MalformedObjectNameException;
import javax.management.ObjectName;

public abstract interface SelfNaming
{
  public abstract ObjectName getObjectName()
    throws MalformedObjectNameException;
}

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.jmx.export.naming.SelfNaming
 * JD-Core Version:    0.6.0
 */