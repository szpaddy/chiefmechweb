/*     */ package org.springframework.jmx.export.naming;
/*     */ 
/*     */ import java.util.Hashtable;
/*     */ import javax.management.MalformedObjectNameException;
/*     */ import javax.management.ObjectName;
/*     */ import org.springframework.aop.support.AopUtils;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.jmx.export.metadata.JmxAttributeSource;
/*     */ import org.springframework.jmx.export.metadata.ManagedResource;
/*     */ import org.springframework.jmx.support.ObjectNameManager;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class MetadataNamingStrategy
/*     */   implements ObjectNamingStrategy, InitializingBean
/*     */ {
/*     */   private JmxAttributeSource attributeSource;
/*     */   private String defaultDomain;
/*     */ 
/*     */   public MetadataNamingStrategy()
/*     */   {
/*     */   }
/*     */ 
/*     */   public MetadataNamingStrategy(JmxAttributeSource attributeSource)
/*     */   {
/*  72 */     Assert.notNull(attributeSource, "JmxAttributeSource must not be null");
/*  73 */     this.attributeSource = attributeSource;
/*     */   }
/*     */ 
/*     */   public void setAttributeSource(JmxAttributeSource attributeSource)
/*     */   {
/*  82 */     Assert.notNull(attributeSource, "JmxAttributeSource must not be null");
/*  83 */     this.attributeSource = attributeSource;
/*     */   }
/*     */ 
/*     */   public void setDefaultDomain(String defaultDomain)
/*     */   {
/*  94 */     this.defaultDomain = defaultDomain;
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet() {
/*  98 */     if (this.attributeSource == null)
/*  99 */       throw new IllegalArgumentException("Property 'attributeSource' is required");
/*     */   }
/*     */ 
/*     */   public ObjectName getObjectName(Object managedBean, String beanKey)
/*     */     throws MalformedObjectNameException
/*     */   {
/* 109 */     Class managedClass = AopUtils.getTargetClass(managedBean);
/* 110 */     ManagedResource mr = this.attributeSource.getManagedResource(managedClass);
/*     */ 
/* 113 */     if ((mr != null) && (StringUtils.hasText(mr.getObjectName())))
/* 114 */       return ObjectNameManager.getInstance(mr.getObjectName()); String domain;
/*     */     Hashtable properties;
/*     */     try { return ObjectNameManager.getInstance(beanKey);
/*     */     } catch (MalformedObjectNameException ex)
/*     */     {
/* 121 */       domain = this.defaultDomain;
/* 122 */       if (domain == null) {
/* 123 */         domain = ClassUtils.getPackageName(managedClass);
/*     */       }
/* 125 */       properties = new Hashtable();
/* 126 */       properties.put("type", ClassUtils.getShortName(managedClass));
/* 127 */       properties.put("name", beanKey);
/* 128 */     }return ObjectNameManager.getInstance(domain, properties);
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.jmx.export.naming.MetadataNamingStrategy
 * JD-Core Version:    0.6.0
 */