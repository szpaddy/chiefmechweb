package org.springframework.jmx.export.naming;

import javax.management.MalformedObjectNameException;
import javax.management.ObjectName;

public abstract interface ObjectNamingStrategy
{
  public abstract ObjectName getObjectName(Object paramObject, String paramString)
    throws MalformedObjectNameException;
}

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.jmx.export.naming.ObjectNamingStrategy
 * JD-Core Version:    0.6.0
 */