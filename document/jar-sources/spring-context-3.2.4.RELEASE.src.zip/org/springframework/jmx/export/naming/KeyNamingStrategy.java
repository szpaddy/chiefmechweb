/*     */ package org.springframework.jmx.export.naming;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Properties;
/*     */ import javax.management.MalformedObjectNameException;
/*     */ import javax.management.ObjectName;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.support.PropertiesLoaderUtils;
/*     */ import org.springframework.jmx.support.ObjectNameManager;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ 
/*     */ public class KeyNamingStrategy
/*     */   implements ObjectNamingStrategy, InitializingBean
/*     */ {
/*  58 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   private Properties mappings;
/*     */   private Resource[] mappingLocations;
/*     */   private Properties mergedMappings;
/*     */ 
/*     */   public void setMappings(Properties mappings)
/*     */   {
/*  85 */     this.mappings = mappings;
/*     */   }
/*     */ 
/*     */   public void setMappingLocation(Resource location)
/*     */   {
/*  93 */     this.mappingLocations = new Resource[] { location };
/*     */   }
/*     */ 
/*     */   public void setMappingLocations(Resource[] mappingLocations)
/*     */   {
/* 101 */     this.mappingLocations = mappingLocations;
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */     throws IOException
/*     */   {
/* 112 */     this.mergedMappings = new Properties();
/*     */ 
/* 114 */     CollectionUtils.mergePropertiesIntoMap(this.mappings, this.mergedMappings);
/*     */ 
/* 116 */     if (this.mappingLocations != null)
/* 117 */       for (int i = 0; i < this.mappingLocations.length; i++) {
/* 118 */         Resource location = this.mappingLocations[i];
/* 119 */         if (this.logger.isInfoEnabled()) {
/* 120 */           this.logger.info("Loading JMX object name mappings file from " + location);
/*     */         }
/* 122 */         PropertiesLoaderUtils.fillProperties(this.mergedMappings, location);
/*     */       }
/*     */   }
/*     */ 
/*     */   public ObjectName getObjectName(Object managedBean, String beanKey)
/*     */     throws MalformedObjectNameException
/*     */   {
/* 133 */     String objectName = null;
/* 134 */     if (this.mergedMappings != null) {
/* 135 */       objectName = this.mergedMappings.getProperty(beanKey);
/*     */     }
/* 137 */     if (objectName == null) {
/* 138 */       objectName = beanKey;
/*     */     }
/* 140 */     return ObjectNameManager.getInstance(objectName);
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.jmx.export.naming.KeyNamingStrategy
 * JD-Core Version:    0.6.0
 */