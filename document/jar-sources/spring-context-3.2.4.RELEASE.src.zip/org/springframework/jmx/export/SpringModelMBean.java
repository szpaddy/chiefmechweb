/*     */ package org.springframework.jmx.export;
/*     */ 
/*     */ import javax.management.Attribute;
/*     */ import javax.management.AttributeList;
/*     */ import javax.management.AttributeNotFoundException;
/*     */ import javax.management.InstanceNotFoundException;
/*     */ import javax.management.InvalidAttributeValueException;
/*     */ import javax.management.MBeanException;
/*     */ import javax.management.ReflectionException;
/*     */ import javax.management.RuntimeOperationsException;
/*     */ import javax.management.modelmbean.InvalidTargetObjectTypeException;
/*     */ import javax.management.modelmbean.ModelMBeanInfo;
/*     */ import javax.management.modelmbean.RequiredModelMBean;
/*     */ 
/*     */ public class SpringModelMBean extends RequiredModelMBean
/*     */ {
/*  46 */   private ClassLoader managedResourceClassLoader = Thread.currentThread().getContextClassLoader();
/*     */ 
/*     */   public SpringModelMBean()
/*     */     throws MBeanException, RuntimeOperationsException
/*     */   {
/*     */   }
/*     */ 
/*     */   public SpringModelMBean(ModelMBeanInfo mbi)
/*     */     throws MBeanException, RuntimeOperationsException
/*     */   {
/*  62 */     super(mbi);
/*     */   }
/*     */ 
/*     */   public void setManagedResource(Object managedResource, String managedResourceType)
/*     */     throws MBeanException, InstanceNotFoundException, InvalidTargetObjectTypeException
/*     */   {
/*  73 */     this.managedResourceClassLoader = managedResource.getClass().getClassLoader();
/*  74 */     super.setManagedResource(managedResource, managedResourceType);
/*     */   }
/*     */ 
/*     */   public Object invoke(String opName, Object[] opArgs, String[] sig)
/*     */     throws MBeanException, ReflectionException
/*     */   {
/*  87 */     ClassLoader currentClassLoader = Thread.currentThread().getContextClassLoader();
/*     */     try {
/*  89 */       Thread.currentThread().setContextClassLoader(this.managedResourceClassLoader);
/*  90 */       Object localObject1 = super.invoke(opName, opArgs, sig);
/*     */       return localObject1; } finally { Thread.currentThread().setContextClassLoader(currentClassLoader); } throw localObject2;
/*     */   }
/*     */ 
/*     */   public Object getAttribute(String attrName)
/*     */     throws AttributeNotFoundException, MBeanException, ReflectionException
/*     */   {
/* 106 */     ClassLoader currentClassLoader = Thread.currentThread().getContextClassLoader();
/*     */     try {
/* 108 */       Thread.currentThread().setContextClassLoader(this.managedResourceClassLoader);
/* 109 */       Object localObject1 = super.getAttribute(attrName);
/*     */       return localObject1; } finally { Thread.currentThread().setContextClassLoader(currentClassLoader); } throw localObject2;
/*     */   }
/*     */ 
/*     */   public AttributeList getAttributes(String[] attrNames)
/*     */   {
/* 123 */     ClassLoader currentClassLoader = Thread.currentThread().getContextClassLoader();
/*     */     try {
/* 125 */       Thread.currentThread().setContextClassLoader(this.managedResourceClassLoader);
/* 126 */       AttributeList localAttributeList = super.getAttributes(attrNames);
/*     */       return localAttributeList; } finally { Thread.currentThread().setContextClassLoader(currentClassLoader); } throw localObject;
/*     */   }
/*     */ 
/*     */   public void setAttribute(Attribute attribute)
/*     */     throws AttributeNotFoundException, InvalidAttributeValueException, MBeanException, ReflectionException
/*     */   {
/* 142 */     ClassLoader currentClassLoader = Thread.currentThread().getContextClassLoader();
/*     */     try {
/* 144 */       Thread.currentThread().setContextClassLoader(this.managedResourceClassLoader);
/* 145 */       super.setAttribute(attribute);
/*     */     }
/*     */     finally {
/* 148 */       Thread.currentThread().setContextClassLoader(currentClassLoader);
/*     */     }
/*     */   }
/*     */ 
/*     */   public AttributeList setAttributes(AttributeList attributes)
/*     */   {
/* 159 */     ClassLoader currentClassLoader = Thread.currentThread().getContextClassLoader();
/*     */     try {
/* 161 */       Thread.currentThread().setContextClassLoader(this.managedResourceClassLoader);
/* 162 */       AttributeList localAttributeList = super.setAttributes(attributes);
/*     */       return localAttributeList; } finally { Thread.currentThread().setContextClassLoader(currentClassLoader); } throw localObject;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.jmx.export.SpringModelMBean
 * JD-Core Version:    0.6.0
 */