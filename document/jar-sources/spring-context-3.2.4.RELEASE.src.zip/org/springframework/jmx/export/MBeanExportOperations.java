package org.springframework.jmx.export;

import javax.management.ObjectName;

public abstract interface MBeanExportOperations
{
  public abstract ObjectName registerManagedResource(Object paramObject)
    throws MBeanExportException;

  public abstract void registerManagedResource(Object paramObject, ObjectName paramObjectName)
    throws MBeanExportException;

  public abstract void unregisterManagedResource(ObjectName paramObjectName);
}

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.jmx.export.MBeanExportOperations
 * JD-Core Version:    0.6.0
 */