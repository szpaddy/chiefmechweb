/*    */ package org.springframework.jmx.access;
/*    */ 
/*    */ import org.springframework.jmx.JmxException;
/*    */ 
/*    */ public class MBeanConnectFailureException extends JmxException
/*    */ {
/*    */   public MBeanConnectFailureException(String msg, Throwable cause)
/*    */   {
/* 39 */     super(msg, cause);
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.jmx.access.MBeanConnectFailureException
 * JD-Core Version:    0.6.0
 */