/*    */ package org.springframework.jmx.access;
/*    */ 
/*    */ import javax.management.JMRuntimeException;
/*    */ 
/*    */ public class InvalidInvocationException extends JMRuntimeException
/*    */ {
/*    */   public InvalidInvocationException(String msg)
/*    */   {
/* 39 */     super(msg);
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.jmx.access.InvalidInvocationException
 * JD-Core Version:    0.6.0
 */