/*     */ package org.springframework.jmx.access;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.MalformedURLException;
/*     */ import java.util.Arrays;
/*     */ import java.util.Map;
/*     */ import javax.management.MBeanServerConnection;
/*     */ import javax.management.ObjectName;
/*     */ import javax.management.remote.JMXServiceURL;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.jmx.JmxException;
/*     */ import org.springframework.jmx.MBeanServerNotFoundException;
/*     */ import org.springframework.jmx.support.NotificationListenerHolder;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ 
/*     */ public class NotificationListenerRegistrar extends NotificationListenerHolder
/*     */   implements InitializingBean, DisposableBean
/*     */ {
/*  53 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   private MBeanServerConnection server;
/*     */   private JMXServiceURL serviceUrl;
/*     */   private Map<String, ?> environment;
/*     */   private String agentId;
/*  63 */   private final ConnectorDelegate connector = new ConnectorDelegate();
/*     */   private ObjectName[] actualObjectNames;
/*     */ 
/*     */   public void setServer(MBeanServerConnection server)
/*     */   {
/*  73 */     this.server = server;
/*     */   }
/*     */ 
/*     */   public void setEnvironment(Map<String, ?> environment)
/*     */   {
/*  81 */     this.environment = environment;
/*     */   }
/*     */ 
/*     */   public Map<String, ?> getEnvironment()
/*     */   {
/*  92 */     return this.environment;
/*     */   }
/*     */ 
/*     */   public void setServiceUrl(String url)
/*     */     throws MalformedURLException
/*     */   {
/*  99 */     this.serviceUrl = new JMXServiceURL(url);
/*     */   }
/*     */ 
/*     */   public void setAgentId(String agentId)
/*     */   {
/* 111 */     this.agentId = agentId;
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */   {
/* 116 */     if (getNotificationListener() == null) {
/* 117 */       throw new IllegalArgumentException("Property 'notificationListener' is required");
/*     */     }
/* 119 */     if (CollectionUtils.isEmpty(this.mappedObjectNames)) {
/* 120 */       throw new IllegalArgumentException("Property 'mappedObjectName' is required");
/*     */     }
/* 122 */     prepare();
/*     */   }
/*     */ 
/*     */   public void prepare()
/*     */   {
/* 131 */     if (this.server == null)
/* 132 */       this.server = this.connector.connect(this.serviceUrl, this.environment, this.agentId);
/*     */     try
/*     */     {
/* 135 */       this.actualObjectNames = getResolvedObjectNames();
/* 136 */       if (this.logger.isDebugEnabled()) {
/* 137 */         this.logger.debug("Registering NotificationListener for MBeans " + Arrays.asList(this.actualObjectNames));
/*     */       }
/* 139 */       for (ObjectName actualObjectName : this.actualObjectNames) {
/* 140 */         this.server.addNotificationListener(actualObjectName, getNotificationListener(), getNotificationFilter(), getHandback());
/*     */       }
/*     */     }
/*     */     catch (IOException ex)
/*     */     {
/* 145 */       throw new MBeanServerNotFoundException("Could not connect to remote MBeanServer at URL [" + this.serviceUrl + "]", ex);
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/* 149 */       throw new JmxException("Unable to register NotificationListener", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void destroy()
/*     */   {
/*     */     try
/*     */     {
/* 158 */       if (this.actualObjectNames != null) {
/* 159 */         for (ObjectName actualObjectName : this.actualObjectNames) {
/*     */           try {
/* 161 */             this.server.removeNotificationListener(actualObjectName, getNotificationListener(), getNotificationFilter(), getHandback());
/*     */           }
/*     */           catch (Exception ex)
/*     */           {
/* 165 */             if (this.logger.isDebugEnabled())
/* 166 */               this.logger.debug("Unable to unregister NotificationListener", ex);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     finally
/*     */     {
/* 173 */       this.connector.close();
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.jmx.access.NotificationListenerRegistrar
 * JD-Core Version:    0.6.0
 */