/*    */ package org.springframework.ejb.config;
/*    */ 
/*    */ import org.w3c.dom.Element;
/*    */ 
/*    */ class LocalStatelessSessionBeanDefinitionParser extends AbstractJndiLocatingBeanDefinitionParser
/*    */ {
/*    */   protected String getBeanClassName(Element element)
/*    */   {
/* 36 */     return "org.springframework.ejb.access.LocalStatelessSessionProxyFactoryBean";
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.ejb.config.LocalStatelessSessionBeanDefinitionParser
 * JD-Core Version:    0.6.0
 */