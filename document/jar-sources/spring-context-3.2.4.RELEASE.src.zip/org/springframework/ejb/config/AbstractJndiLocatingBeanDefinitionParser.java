/*    */ package org.springframework.ejb.config;
/*    */ 
/*    */ import org.springframework.beans.factory.config.RuntimeBeanReference;
/*    */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*    */ import org.springframework.beans.factory.xml.AbstractSimpleBeanDefinitionParser;
/*    */ import org.springframework.util.StringUtils;
/*    */ import org.springframework.util.xml.DomUtils;
/*    */ import org.w3c.dom.Element;
/*    */ 
/*    */ abstract class AbstractJndiLocatingBeanDefinitionParser extends AbstractSimpleBeanDefinitionParser
/*    */ {
/*    */   public static final String ENVIRONMENT = "environment";
/*    */   public static final String ENVIRONMENT_REF = "environment-ref";
/*    */   public static final String JNDI_ENVIRONMENT = "jndiEnvironment";
/*    */ 
/*    */   protected boolean isEligibleAttribute(String attributeName)
/*    */   {
/* 49 */     return (super.isEligibleAttribute(attributeName)) && (!"environment-ref".equals(attributeName)) && (!"lazy-init".equals(attributeName));
/*    */   }
/*    */ 
/*    */   protected void postProcess(BeanDefinitionBuilder definitionBuilder, Element element)
/*    */   {
/* 55 */     Object envValue = DomUtils.getChildElementValueByTagName(element, "environment");
/* 56 */     if (envValue != null)
/*    */     {
/* 58 */       definitionBuilder.addPropertyValue("jndiEnvironment", envValue);
/*    */     }
/*    */     else
/*    */     {
/* 62 */       String envRef = element.getAttribute("environment-ref");
/* 63 */       if (StringUtils.hasLength(envRef)) {
/* 64 */         definitionBuilder.addPropertyValue("jndiEnvironment", new RuntimeBeanReference(envRef));
/*    */       }
/*    */     }
/*    */ 
/* 68 */     String lazyInit = element.getAttribute("lazy-init");
/* 69 */     if ((StringUtils.hasText(lazyInit)) && (!"default".equals(lazyInit)))
/* 70 */       definitionBuilder.setLazyInit("true".equals(lazyInit));
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.ejb.config.AbstractJndiLocatingBeanDefinitionParser
 * JD-Core Version:    0.6.0
 */