package org.springframework.ejb.support;

import javax.ejb.SessionBean;
import javax.ejb.SessionContext;

@Deprecated
public abstract interface SmartSessionBean extends SessionBean
{
  public abstract SessionContext getSessionContext();
}

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.ejb.support.SmartSessionBean
 * JD-Core Version:    0.6.0
 */