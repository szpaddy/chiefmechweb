/*    */ package org.springframework.ejb.support;
/*    */ 
/*    */ import javax.ejb.SessionContext;
/*    */ 
/*    */ @Deprecated
/*    */ public abstract class AbstractSessionBean extends AbstractEnterpriseBean
/*    */   implements SmartSessionBean
/*    */ {
/*    */   private SessionContext sessionContext;
/*    */ 
/*    */   public void setSessionContext(SessionContext sessionContext)
/*    */   {
/* 46 */     this.sessionContext = sessionContext;
/*    */   }
/*    */ 
/*    */   public final SessionContext getSessionContext()
/*    */   {
/* 54 */     return this.sessionContext;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.ejb.support.AbstractSessionBean
 * JD-Core Version:    0.6.0
 */