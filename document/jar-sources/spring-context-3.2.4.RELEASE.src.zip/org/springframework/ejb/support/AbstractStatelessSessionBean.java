/*    */ package org.springframework.ejb.support;
/*    */ 
/*    */ import javax.ejb.CreateException;
/*    */ import javax.ejb.EJBException;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ @Deprecated
/*    */ public abstract class AbstractStatelessSessionBean extends AbstractSessionBean
/*    */ {
/* 55 */   protected final Log logger = LogFactory.getLog(getClass());
/*    */ 
/*    */   public void ejbCreate()
/*    */     throws CreateException
/*    */   {
/* 69 */     loadBeanFactory();
/* 70 */     onEjbCreate();
/*    */   }
/*    */ 
/*    */   protected abstract void onEjbCreate()
/*    */     throws CreateException;
/*    */ 
/*    */   public void ejbActivate()
/*    */     throws EJBException
/*    */   {
/* 89 */     throw new IllegalStateException("ejbActivate must not be invoked on a stateless session bean");
/*    */   }
/*    */ 
/*    */   public void ejbPassivate()
/*    */     throws EJBException
/*    */   {
/* 97 */     throw new IllegalStateException("ejbPassivate must not be invoked on a stateless session bean");
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.ejb.support.AbstractStatelessSessionBean
 * JD-Core Version:    0.6.0
 */