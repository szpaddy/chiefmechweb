/*     */ package org.springframework.ejb.support;
/*     */ 
/*     */ import javax.ejb.EnterpriseBean;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.FatalBeanException;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.access.BeanFactoryLocator;
/*     */ import org.springframework.beans.factory.access.BeanFactoryReference;
/*     */ import org.springframework.context.access.ContextJndiBeanFactoryLocator;
/*     */ import org.springframework.util.WeakReferenceMonitor;
/*     */ import org.springframework.util.WeakReferenceMonitor.ReleaseListener;
/*     */ 
/*     */ @Deprecated
/*     */ public abstract class AbstractEnterpriseBean
/*     */   implements EnterpriseBean
/*     */ {
/*     */   public static final String BEAN_FACTORY_PATH_ENVIRONMENT_KEY = "java:comp/env/ejb/BeanFactoryPath";
/*     */   private BeanFactoryLocator beanFactoryLocator;
/*     */   private String beanFactoryLocatorKey;
/*     */   private BeanFactoryReference beanFactoryReference;
/*     */ 
/*     */   public void setBeanFactoryLocator(BeanFactoryLocator beanFactoryLocator)
/*     */   {
/*  91 */     this.beanFactoryLocator = beanFactoryLocator;
/*     */   }
/*     */ 
/*     */   public void setBeanFactoryLocatorKey(String factoryKey)
/*     */   {
/* 104 */     this.beanFactoryLocatorKey = factoryKey;
/*     */   }
/*     */ 
/*     */   void loadBeanFactory()
/*     */     throws BeansException
/*     */   {
/* 114 */     if (this.beanFactoryLocator == null) {
/* 115 */       this.beanFactoryLocator = new ContextJndiBeanFactoryLocator();
/*     */     }
/* 117 */     if (this.beanFactoryLocatorKey == null) {
/* 118 */       this.beanFactoryLocatorKey = "java:comp/env/ejb/BeanFactoryPath";
/*     */     }
/*     */ 
/* 121 */     this.beanFactoryReference = this.beanFactoryLocator.useBeanFactory(this.beanFactoryLocatorKey);
/*     */ 
/* 126 */     WeakReferenceMonitor.monitor(this, new BeanFactoryReferenceReleaseListener(this.beanFactoryReference));
/*     */   }
/*     */ 
/*     */   void unloadBeanFactory()
/*     */     throws FatalBeanException
/*     */   {
/* 139 */     if (this.beanFactoryReference != null) {
/* 140 */       this.beanFactoryReference.release();
/* 141 */       this.beanFactoryReference = null;
/*     */     }
/*     */   }
/*     */ 
/*     */   protected BeanFactory getBeanFactory()
/*     */   {
/* 150 */     return this.beanFactoryReference.getFactory();
/*     */   }
/*     */ 
/*     */   public void ejbRemove()
/*     */   {
/* 160 */     onEjbRemove();
/* 161 */     unloadBeanFactory();
/*     */   }
/*     */ 
/*     */   protected void onEjbRemove()
/*     */   {
/*     */   }
/*     */ 
/*     */   private static class BeanFactoryReferenceReleaseListener
/*     */     implements WeakReferenceMonitor.ReleaseListener
/*     */   {
/*     */     private final BeanFactoryReference beanFactoryReference;
/*     */ 
/*     */     public BeanFactoryReferenceReleaseListener(BeanFactoryReference beanFactoryReference)
/*     */     {
/* 187 */       this.beanFactoryReference = beanFactoryReference;
/*     */     }
/*     */ 
/*     */     public void released() {
/* 191 */       this.beanFactoryReference.release();
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.ejb.support.AbstractEnterpriseBean
 * JD-Core Version:    0.6.0
 */