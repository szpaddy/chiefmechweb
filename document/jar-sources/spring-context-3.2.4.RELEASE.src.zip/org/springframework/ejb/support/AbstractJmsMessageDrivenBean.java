package org.springframework.ejb.support;

import javax.jms.MessageListener;

@Deprecated
public abstract class AbstractJmsMessageDrivenBean extends AbstractMessageDrivenBean
  implements MessageListener
{
}

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.ejb.support.AbstractJmsMessageDrivenBean
 * JD-Core Version:    0.6.0
 */