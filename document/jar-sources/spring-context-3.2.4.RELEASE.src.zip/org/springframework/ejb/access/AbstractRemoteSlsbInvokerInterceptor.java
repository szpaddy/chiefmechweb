/*     */ package org.springframework.ejb.access;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.rmi.RemoteException;
/*     */ import javax.ejb.EJBHome;
/*     */ import javax.ejb.EJBObject;
/*     */ import javax.naming.NamingException;
/*     */ import javax.rmi.PortableRemoteObject;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.remoting.RemoteConnectFailureException;
/*     */ import org.springframework.remoting.RemoteLookupFailureException;
/*     */ import org.springframework.remoting.rmi.RmiClientInterceptorUtils;
/*     */ 
/*     */ public abstract class AbstractRemoteSlsbInvokerInterceptor extends AbstractSlsbInvokerInterceptor
/*     */ {
/*     */   private Class homeInterface;
/*  48 */   private boolean refreshHomeOnConnectFailure = false;
/*     */ 
/*  50 */   private volatile boolean homeAsComponent = false;
/*     */ 
/*     */   public void setHomeInterface(Class homeInterface)
/*     */   {
/*  64 */     if ((homeInterface != null) && (!homeInterface.isInterface())) {
/*  65 */       throw new IllegalArgumentException("Home interface class [" + homeInterface.getClass() + "] is not an interface");
/*     */     }
/*     */ 
/*  68 */     this.homeInterface = homeInterface;
/*     */   }
/*     */ 
/*     */   public void setRefreshHomeOnConnectFailure(boolean refreshHomeOnConnectFailure)
/*     */   {
/*  83 */     this.refreshHomeOnConnectFailure = refreshHomeOnConnectFailure;
/*     */   }
/*     */ 
/*     */   protected boolean isHomeRefreshable()
/*     */   {
/*  88 */     return this.refreshHomeOnConnectFailure;
/*     */   }
/*     */ 
/*     */   protected Object lookup()
/*     */     throws NamingException
/*     */   {
/* 100 */     Object homeObject = super.lookup();
/* 101 */     if (this.homeInterface != null) {
/*     */       try {
/* 103 */         homeObject = PortableRemoteObject.narrow(homeObject, this.homeInterface);
/*     */       }
/*     */       catch (ClassCastException ex) {
/* 106 */         throw new RemoteLookupFailureException("Could not narrow EJB home stub to home interface [" + this.homeInterface.getName() + "]", ex);
/*     */       }
/*     */     }
/*     */ 
/* 110 */     return homeObject;
/*     */   }
/*     */ 
/*     */   protected Method getCreateMethod(Object home)
/*     */     throws EjbAccessException
/*     */   {
/* 118 */     if (this.homeAsComponent) {
/* 119 */       return null;
/*     */     }
/* 121 */     if (!(home instanceof EJBHome))
/*     */     {
/* 123 */       this.homeAsComponent = true;
/* 124 */       return null;
/*     */     }
/* 126 */     return super.getCreateMethod(home);
/*     */   }
/*     */ 
/*     */   public Object invokeInContext(MethodInvocation invocation)
/*     */     throws Throwable
/*     */   {
/*     */     try
/*     */     {
/* 141 */       return doInvoke(invocation);
/*     */     }
/*     */     catch (RemoteConnectFailureException ex) {
/* 144 */       return handleRemoteConnectFailure(invocation, ex);
/*     */     }
/*     */     catch (RemoteException ex) {
/* 147 */       if (isConnectFailure(ex)) {
/* 148 */         return handleRemoteConnectFailure(invocation, ex);
/*     */       }
/*     */     }
/* 151 */     throw ex;
/*     */   }
/*     */ 
/*     */   protected boolean isConnectFailure(RemoteException ex)
/*     */   {
/* 164 */     return RmiClientInterceptorUtils.isConnectFailure(ex);
/*     */   }
/*     */ 
/*     */   private Object handleRemoteConnectFailure(MethodInvocation invocation, Exception ex) throws Throwable {
/* 168 */     if (this.refreshHomeOnConnectFailure) {
/* 169 */       if (this.logger.isDebugEnabled()) {
/* 170 */         this.logger.debug("Could not connect to remote EJB [" + getJndiName() + "] - retrying", ex);
/*     */       }
/* 172 */       else if (this.logger.isWarnEnabled()) {
/* 173 */         this.logger.warn("Could not connect to remote EJB [" + getJndiName() + "] - retrying");
/*     */       }
/* 175 */       return refreshAndRetry(invocation);
/*     */     }
/*     */ 
/* 178 */     throw ex;
/*     */   }
/*     */ 
/*     */   protected Object refreshAndRetry(MethodInvocation invocation)
/*     */     throws Throwable
/*     */   {
/*     */     try
/*     */     {
/* 192 */       refreshHome();
/*     */     }
/*     */     catch (NamingException ex) {
/* 195 */       throw new RemoteLookupFailureException("Failed to locate remote EJB [" + getJndiName() + "]", ex);
/*     */     }
/* 197 */     return doInvoke(invocation);
/*     */   }
/*     */ 
/*     */   protected abstract Object doInvoke(MethodInvocation paramMethodInvocation)
/*     */     throws Throwable;
/*     */ 
/*     */   protected Object newSessionBeanInstance()
/*     */     throws NamingException, InvocationTargetException
/*     */   {
/* 222 */     if (this.logger.isDebugEnabled()) {
/* 223 */       this.logger.debug("Trying to create reference to remote EJB");
/*     */     }
/* 225 */     Object ejbInstance = create();
/* 226 */     if (this.logger.isDebugEnabled()) {
/* 227 */       this.logger.debug("Obtained reference to remote EJB: " + ejbInstance);
/*     */     }
/* 229 */     return ejbInstance;
/*     */   }
/*     */ 
/*     */   protected void removeSessionBeanInstance(EJBObject ejb)
/*     */   {
/* 239 */     if ((ejb != null) && (!this.homeAsComponent))
/*     */       try {
/* 241 */         ejb.remove();
/*     */       }
/*     */       catch (Throwable ex) {
/* 244 */         this.logger.warn("Could not invoke 'remove' on remote EJB proxy", ex);
/*     */       }
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.ejb.access.AbstractRemoteSlsbInvokerInterceptor
 * JD-Core Version:    0.6.0
 */