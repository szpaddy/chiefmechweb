/*    */ package org.springframework.ejb.access;
/*    */ 
/*    */ import org.springframework.core.NestedRuntimeException;
/*    */ 
/*    */ public class EjbAccessException extends NestedRuntimeException
/*    */ {
/*    */   public EjbAccessException(String msg)
/*    */   {
/* 35 */     super(msg);
/*    */   }
/*    */ 
/*    */   public EjbAccessException(String msg, Throwable cause)
/*    */   {
/* 44 */     super(msg, cause);
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.ejb.access.EjbAccessException
 * JD-Core Version:    0.6.0
 */