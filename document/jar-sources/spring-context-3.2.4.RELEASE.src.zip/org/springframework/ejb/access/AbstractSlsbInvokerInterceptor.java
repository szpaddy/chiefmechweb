/*     */ package org.springframework.ejb.access;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import javax.naming.Context;
/*     */ import javax.naming.NamingException;
/*     */ import org.aopalliance.intercept.MethodInterceptor;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.springframework.jndi.JndiObjectLocator;
/*     */ import org.springframework.jndi.JndiTemplate;
/*     */ 
/*     */ public abstract class AbstractSlsbInvokerInterceptor extends JndiObjectLocator
/*     */   implements MethodInterceptor
/*     */ {
/*  44 */   private boolean lookupHomeOnStartup = true;
/*     */ 
/*  46 */   private boolean cacheHome = true;
/*     */ 
/*  48 */   private boolean exposeAccessContext = false;
/*     */   private Object cachedHome;
/*     */   private Method createMethod;
/*  61 */   private final Object homeMonitor = new Object();
/*     */ 
/*     */   public void setLookupHomeOnStartup(boolean lookupHomeOnStartup)
/*     */   {
/*  72 */     this.lookupHomeOnStartup = lookupHomeOnStartup;
/*     */   }
/*     */ 
/*     */   public void setCacheHome(boolean cacheHome)
/*     */   {
/*  83 */     this.cacheHome = cacheHome;
/*     */   }
/*     */ 
/*     */   public void setExposeAccessContext(boolean exposeAccessContext)
/*     */   {
/*  95 */     this.exposeAccessContext = exposeAccessContext;
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */     throws NamingException
/*     */   {
/* 106 */     super.afterPropertiesSet();
/* 107 */     if (this.lookupHomeOnStartup)
/*     */     {
/* 109 */       refreshHome();
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void refreshHome()
/*     */     throws NamingException
/*     */   {
/* 121 */     synchronized (this.homeMonitor) {
/* 122 */       Object home = lookup();
/* 123 */       if (this.cacheHome) {
/* 124 */         this.cachedHome = home;
/* 125 */         this.createMethod = getCreateMethod(home);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   protected Method getCreateMethod(Object home)
/*     */     throws EjbAccessException
/*     */   {
/*     */     try
/*     */     {
/* 139 */       return home.getClass().getMethod("create", (Class[])null);
/*     */     } catch (NoSuchMethodException ex) {
/*     */     }
/* 142 */     throw new EjbAccessException("EJB home [" + home + "] has no no-arg create() method");
/*     */   }
/*     */ 
/*     */   protected Object getHome()
/*     */     throws NamingException
/*     */   {
/* 159 */     if ((!this.cacheHome) || ((this.lookupHomeOnStartup) && (!isHomeRefreshable()))) {
/* 160 */       return this.cachedHome != null ? this.cachedHome : lookup();
/*     */     }
/*     */ 
/* 163 */     synchronized (this.homeMonitor) {
/* 164 */       if (this.cachedHome == null) {
/* 165 */         this.cachedHome = lookup();
/* 166 */         this.createMethod = getCreateMethod(this.cachedHome);
/*     */       }
/* 168 */       return this.cachedHome;
/*     */     }
/*     */   }
/*     */ 
/*     */   protected boolean isHomeRefreshable()
/*     */   {
/* 178 */     return false;
/*     */   }
/*     */ 
/*     */   public Object invoke(MethodInvocation invocation)
/*     */     throws Throwable
/*     */   {
/* 187 */     Context ctx = this.exposeAccessContext ? getJndiTemplate().getContext() : null;
/*     */     try {
/* 189 */       Object localObject1 = invokeInContext(invocation);
/*     */       return localObject1; } finally { getJndiTemplate().releaseContext(ctx); } throw localObject2;
/*     */   }
/*     */ 
/*     */   protected abstract Object invokeInContext(MethodInvocation paramMethodInvocation)
/*     */     throws Throwable;
/*     */ 
/*     */   protected Object create()
/*     */     throws NamingException, InvocationTargetException
/*     */   {
/*     */     try
/*     */     {
/* 215 */       Object home = getHome();
/* 216 */       Method createMethodToUse = this.createMethod;
/* 217 */       if (createMethodToUse == null) {
/* 218 */         createMethodToUse = getCreateMethod(home);
/*     */       }
/* 220 */       if (createMethodToUse == null) {
/* 221 */         return home;
/*     */       }
/*     */ 
/* 224 */       return createMethodToUse.invoke(home, (Object[])null);
/*     */     } catch (IllegalAccessException ex) {
/*     */     }
/* 227 */     throw new EjbAccessException("Could not access EJB home create() method", ex);
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-context-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.ejb.access.AbstractSlsbInvokerInterceptor
 * JD-Core Version:    0.6.0
 */