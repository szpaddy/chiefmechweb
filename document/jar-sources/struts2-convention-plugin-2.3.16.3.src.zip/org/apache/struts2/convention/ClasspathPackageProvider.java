/*    */ package org.apache.struts2.convention;
/*    */ 
/*    */ import com.opensymphony.xwork2.config.Configuration;
/*    */ import com.opensymphony.xwork2.config.ConfigurationException;
/*    */ import com.opensymphony.xwork2.config.PackageProvider;
/*    */ import com.opensymphony.xwork2.inject.Container;
/*    */ import com.opensymphony.xwork2.inject.Inject;
/*    */ 
/*    */ public class ClasspathPackageProvider
/*    */   implements PackageProvider
/*    */ {
/*    */   private ActionConfigBuilder actionConfigBuilder;
/*    */ 
/*    */   @Inject
/*    */   public ClasspathPackageProvider(Container container)
/*    */   {
/* 42 */     this.actionConfigBuilder = ((ActionConfigBuilder)container.getInstance(ActionConfigBuilder.class, (String)container.getInstance(String.class, "struts.convention.actionConfigBuilder")));
/*    */   }
/*    */ 
/*    */   public void init(Configuration configuration) throws ConfigurationException {
/*    */   }
/*    */ 
/*    */   public boolean needsReload() {
/* 49 */     return this.actionConfigBuilder.needsReload();
/*    */   }
/*    */ 
/*    */   public void loadPackages() throws ConfigurationException {
/* 53 */     this.actionConfigBuilder.buildActionConfigs();
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-convention-plugin-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.convention.ClasspathPackageProvider
 * JD-Core Version:    0.6.0
 */