/*     */ package org.apache.struts2.convention;
/*     */ 
/*     */ import com.opensymphony.xwork2.config.Configuration;
/*     */ import com.opensymphony.xwork2.config.ConfigurationException;
/*     */ import com.opensymphony.xwork2.config.ConfigurationManager;
/*     */ import com.opensymphony.xwork2.config.ConfigurationProvider;
/*     */ import com.opensymphony.xwork2.inject.Container;
/*     */ import com.opensymphony.xwork2.inject.ContainerBuilder;
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import com.opensymphony.xwork2.util.location.LocatableProperties;
/*     */ import org.apache.struts2.dispatcher.Dispatcher;
/*     */ import org.apache.struts2.dispatcher.DispatcherListener;
/*     */ 
/*     */ public class ClasspathConfigurationProvider
/*     */   implements ConfigurationProvider, DispatcherListener
/*     */ {
/*     */   private ActionConfigBuilder actionConfigBuilder;
/*     */   private boolean devMode;
/*     */   private boolean reload;
/*     */   private boolean listeningToDispatcher;
/*     */ 
/*     */   @Inject
/*     */   public ClasspathConfigurationProvider(Container container)
/*     */   {
/*  47 */     this.actionConfigBuilder = ((ActionConfigBuilder)container.getInstance(ActionConfigBuilder.class, (String)container.getInstance(String.class, "struts.convention.actionConfigBuilder")));
/*     */   }
/*     */   @Inject("struts.devMode")
/*     */   public void setDevMode(String mode) {
/*  52 */     this.devMode = "true".equals(mode);
/*     */   }
/*     */   @Inject("struts.convention.classes.reload")
/*     */   public void setReload(String reload) {
/*  57 */     this.reload = "true".equals(reload);
/*     */   }
/*     */ 
/*     */   public void destroy()
/*     */   {
/*  64 */     if (this.listeningToDispatcher)
/*  65 */       Dispatcher.removeDispatcherListener(this);
/*  66 */     this.actionConfigBuilder.destroy();
/*     */   }
/*     */ 
/*     */   public void init(Configuration configuration)
/*     */   {
/*  73 */     if ((this.devMode) && (this.reload) && (!this.listeningToDispatcher))
/*     */     {
/*  76 */       this.listeningToDispatcher = true;
/*  77 */       Dispatcher.addDispatcherListener(this);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void register(ContainerBuilder containerBuilder, LocatableProperties locatableProperties)
/*     */     throws ConfigurationException
/*     */   {
/*     */   }
/*     */ 
/*     */   public void loadPackages()
/*     */     throws ConfigurationException
/*     */   {
/*     */   }
/*     */ 
/*     */   public boolean needsReload()
/*     */   {
/* 101 */     return (this.devMode) && (this.reload) && (this.actionConfigBuilder.needsReload());
/*     */   }
/*     */ 
/*     */   public void dispatcherInitialized(Dispatcher du) {
/* 105 */     du.getConfigurationManager().addContainerProvider(this);
/*     */   }
/*     */ 
/*     */   public void dispatcherDestroyed(Dispatcher du)
/*     */   {
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-convention-plugin-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.convention.ClasspathConfigurationProvider
 * JD-Core Version:    0.6.0
 */