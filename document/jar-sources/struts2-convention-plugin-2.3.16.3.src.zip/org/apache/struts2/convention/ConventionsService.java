package org.apache.struts2.convention;

import com.opensymphony.xwork2.config.entities.ActionConfig;
import com.opensymphony.xwork2.config.entities.PackageConfig;
import com.opensymphony.xwork2.config.entities.ResultTypeConfig;
import java.util.Map;

public abstract interface ConventionsService
{
  public abstract String determineResultPath(Class<?> paramClass);

  public abstract String determineResultPath(ActionConfig paramActionConfig);

  public abstract Map<String, ResultTypeConfig> getResultTypesByExtension(PackageConfig paramPackageConfig);
}

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-convention-plugin-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.convention.ConventionsService
 * JD-Core Version:    0.6.0
 */