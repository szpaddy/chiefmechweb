/*     */ package org.apache.struts2.convention;
/*     */ 
/*     */ import com.opensymphony.xwork2.config.ConfigurationException;
/*     */ import com.opensymphony.xwork2.config.entities.ActionConfig;
/*     */ import com.opensymphony.xwork2.config.entities.PackageConfig;
/*     */ import com.opensymphony.xwork2.config.entities.ResultTypeConfig;
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import com.opensymphony.xwork2.util.AnnotationUtils;
/*     */ import com.opensymphony.xwork2.util.ClassLoaderUtil;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.ResourceBundle;
/*     */ import org.apache.struts2.convention.annotation.ResultPath;
/*     */ 
/*     */ public class ConventionsServiceImpl
/*     */   implements ConventionsService
/*     */ {
/*     */   private String resultPath;
/*     */ 
/*     */   @Inject
/*     */   public ConventionsServiceImpl(@Inject("struts.convention.result.path") String resultPath)
/*     */   {
/*  53 */     this.resultPath = resultPath;
/*     */   }
/*     */ 
/*     */   public String determineResultPath(Class<?> actionClass)
/*     */   {
/*  60 */     String localResultPath = this.resultPath;
/*  61 */     ResultPath resultPathAnnotation = (ResultPath)AnnotationUtils.findAnnotation(actionClass, ResultPath.class);
/*  62 */     if (resultPathAnnotation != null) {
/*  63 */       if ((resultPathAnnotation.value().equals("")) && (resultPathAnnotation.property().equals(""))) {
/*  64 */         throw new ConfigurationException("The ResultPath annotation must have either a value or property specified.");
/*     */       }
/*     */ 
/*  68 */       String property = resultPathAnnotation.property();
/*  69 */       if (property.equals(""))
/*  70 */         localResultPath = resultPathAnnotation.value();
/*     */       else {
/*     */         try {
/*  73 */           ResourceBundle strutsBundle = ResourceBundle.getBundle("struts");
/*  74 */           localResultPath = strutsBundle.getString(property);
/*     */         } catch (Exception e) {
/*  76 */           throw new ConfigurationException("The action class [" + actionClass + "] defines" + " a @ResultPath annotation and a property definition however the" + " struts.properties could not be found in the classpath using ResourceBundle" + " OR the bundle exists but the property [" + property + "] is not defined" + " in the file.", e);
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/*  85 */     return localResultPath;
/*     */   }
/*     */ 
/*     */   public String determineResultPath(ActionConfig actionConfig)
/*     */   {
/*  92 */     if (actionConfig == null) {
/*  93 */       return this.resultPath;
/*     */     }
/*     */     try
/*     */     {
/*  97 */       return determineResultPath(ClassLoaderUtil.loadClass(actionConfig.getClassName(), getClass())); } catch (ClassNotFoundException e) {
/*     */     }
/*  99 */     throw new RuntimeException("Invalid action class configuration that references an unknown class named [" + actionConfig.getClassName() + "]", e);
/*     */   }
/*     */ 
/*     */   public Map<String, ResultTypeConfig> getResultTypesByExtension(PackageConfig packageConfig)
/*     */   {
/* 108 */     Map results = packageConfig.getAllResultTypeConfigs();
/*     */ 
/* 110 */     Map resultsByExtension = new HashMap();
/* 111 */     resultsByExtension.put("jsp", results.get("dispatcher"));
/* 112 */     resultsByExtension.put("jspf", results.get("dispatcher"));
/* 113 */     resultsByExtension.put("jspx", results.get("dispatcher"));
/* 114 */     resultsByExtension.put("vm", results.get("velocity"));
/* 115 */     resultsByExtension.put("ftl", results.get("freemarker"));
/* 116 */     resultsByExtension.put("html", results.get("dispatcher"));
/* 117 */     resultsByExtension.put("htm", results.get("dispatcher"));
/* 118 */     return resultsByExtension;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-convention-plugin-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.convention.ConventionsServiceImpl
 * JD-Core Version:    0.6.0
 */