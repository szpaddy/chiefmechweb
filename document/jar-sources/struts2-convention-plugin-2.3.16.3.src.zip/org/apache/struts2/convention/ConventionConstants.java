package org.apache.struts2.convention;

public class ConventionConstants
{
  public static final String CONVENTION_ACTION_CONFIG_BUILDER = "struts.convention.actionConfigBuilder";
  public static final String CONVENTION_ACTION_NAME_BUILDER = "struts.convention.actionNameBuilder";
  public static final String CONVENTION_RESULT_MAP_BUILDER = "struts.convention.resultMapBuilder";
  public static final String CONVENTION_INTERCEPTOR_MAP_BUILDER = "struts.convention.interceptorMapBuilder";
  public static final String CONVENTION_CONVENTIONS_SERVICE = "struts.convention.conventionsService";
}

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-convention-plugin-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.convention.ConventionConstants
 * JD-Core Version:    0.6.0
 */