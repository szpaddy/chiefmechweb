package org.apache.struts2.convention;

public abstract interface ActionConfigBuilder
{
  public abstract void buildActionConfigs();

  public abstract boolean needsReload();

  public abstract void destroy();
}

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-convention-plugin-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.convention.ActionConfigBuilder
 * JD-Core Version:    0.6.0
 */