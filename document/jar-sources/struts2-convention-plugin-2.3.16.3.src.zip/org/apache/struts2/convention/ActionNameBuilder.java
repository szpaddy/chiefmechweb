package org.apache.struts2.convention;

public abstract interface ActionNameBuilder
{
  public abstract String build(String paramString);
}

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-convention-plugin-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.convention.ActionNameBuilder
 * JD-Core Version:    0.6.0
 */