/*    */ package org.apache.struts2.convention;
/*    */ 
/*    */ import com.opensymphony.xwork2.inject.Inject;
/*    */ import org.apache.commons.lang3.StringUtils;
/*    */ 
/*    */ public class DefaultActionNameBuilder
/*    */   implements ActionNameBuilder
/*    */ {
/* 36 */   private String actionSuffix = "Action";
/*    */   private boolean lowerCase;
/*    */ 
/*    */   @Inject
/*    */   public DefaultActionNameBuilder(@Inject("struts.convention.action.name.lowercase") String lowerCase)
/*    */   {
/* 41 */     this.lowerCase = Boolean.parseBoolean(lowerCase);
/*    */   }
/*    */ 
/*    */   @Inject(value="struts.convention.action.suffix", required=false)
/*    */   public void setActionSuffix(String actionSuffix)
/*    */   {
/* 50 */     if (StringUtils.isNotBlank(actionSuffix))
/* 51 */       this.actionSuffix = actionSuffix;
/*    */   }
/*    */ 
/*    */   public String build(String className)
/*    */   {
/* 56 */     String actionName = className;
/*    */ 
/* 59 */     if (actionName.endsWith(this.actionSuffix)) {
/* 60 */       actionName = actionName.substring(0, actionName.length() - this.actionSuffix.length());
/*    */     }
/*    */ 
/* 64 */     if ((this.lowerCase) && (actionName.length() > 1)) {
/* 65 */       int lowerPos = actionName.lastIndexOf('/') + 1;
/* 66 */       StringBuilder sb = new StringBuilder();
/* 67 */       sb.append(actionName.substring(0, lowerPos));
/* 68 */       sb.append(Character.toLowerCase(actionName.charAt(lowerPos)));
/* 69 */       sb.append(actionName.substring(lowerPos + 1));
/* 70 */       actionName = sb.toString();
/*    */     }
/*    */ 
/* 73 */     return actionName;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-convention-plugin-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.convention.DefaultActionNameBuilder
 * JD-Core Version:    0.6.0
 */