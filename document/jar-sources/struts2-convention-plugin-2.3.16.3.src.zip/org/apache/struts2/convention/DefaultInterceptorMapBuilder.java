/*     */ package org.apache.struts2.convention;
/*     */ 
/*     */ import com.opensymphony.xwork2.ObjectFactory;
/*     */ import com.opensymphony.xwork2.config.Configuration;
/*     */ import com.opensymphony.xwork2.config.entities.InterceptorMapping;
/*     */ import com.opensymphony.xwork2.config.entities.PackageConfig;
/*     */ import com.opensymphony.xwork2.config.entities.PackageConfig.Builder;
/*     */ import com.opensymphony.xwork2.config.providers.InterceptorBuilder;
/*     */ import com.opensymphony.xwork2.inject.Container;
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import com.opensymphony.xwork2.util.AnnotationUtils;
/*     */ import com.opensymphony.xwork2.util.logging.Logger;
/*     */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.struts2.convention.annotation.Action;
/*     */ import org.apache.struts2.convention.annotation.InterceptorRef;
/*     */ import org.apache.struts2.convention.annotation.InterceptorRefs;
/*     */ 
/*     */ public class DefaultInterceptorMapBuilder
/*     */   implements InterceptorMapBuilder
/*     */ {
/*  46 */   private static final Logger LOG = LoggerFactory.getLogger(DefaultInterceptorMapBuilder.class);
/*     */   private Configuration configuration;
/*     */ 
/*     */   public List<InterceptorMapping> build(Class<?> actionClass, PackageConfig.Builder builder, String actionName, Action annotation)
/*     */   {
/*  53 */     List interceptorList = new ArrayList(10);
/*     */ 
/*  57 */     InterceptorRefs interceptorRefs = (InterceptorRefs)AnnotationUtils.findAnnotation(actionClass, InterceptorRefs.class);
/*  58 */     if (interceptorRefs != null) {
/*  59 */       interceptorList.addAll(build(interceptorRefs.value(), actionName, builder));
/*     */     }
/*     */ 
/*  62 */     InterceptorRef interceptorRef = (InterceptorRef)AnnotationUtils.findAnnotation(actionClass, InterceptorRef.class);
/*  63 */     if (interceptorRef != null) {
/*  64 */       interceptorList.addAll(build(new InterceptorRef[] { interceptorRef }, actionName, builder));
/*     */     }
/*     */ 
/*  67 */     if (annotation != null) {
/*  68 */       InterceptorRef[] interceptors = annotation.interceptorRefs();
/*  69 */       if (interceptors != null) {
/*  70 */         interceptorList.addAll(build(interceptors, actionName, builder));
/*     */       }
/*     */     }
/*     */ 
/*  74 */     return interceptorList;
/*     */   }
/*     */ 
/*     */   protected List<InterceptorMapping> build(InterceptorRef[] interceptors, String actionName, PackageConfig.Builder builder) {
/*  78 */     List interceptorList = new ArrayList(10);
/*     */ 
/*  80 */     for (InterceptorRef interceptor : interceptors) {
/*  81 */       if (LOG.isTraceEnabled()) {
/*  82 */         LOG.trace("Adding interceptor [#0] to [#1]", new String[] { interceptor.value(), actionName });
/*     */       }
/*  84 */       Map params = StringTools.createParameterMap(interceptor.params());
/*     */ 
/*  86 */       interceptorList.addAll(buildInterceptorList(builder, interceptor, params));
/*     */     }
/*     */ 
/*  90 */     return interceptorList;
/*     */   }
/*     */ 
/*     */   protected List<InterceptorMapping> buildInterceptorList(PackageConfig.Builder builder, InterceptorRef ref, Map params)
/*     */   {
/*  95 */     return InterceptorBuilder.constructInterceptorReference(builder, ref.value(), params, builder.build().getLocation(), (ObjectFactory)this.configuration.getContainer().getInstance(ObjectFactory.class));
/*     */   }
/*     */ 
/*     */   @Inject
/*     */   public void setConfiguration(Configuration configuration)
/*     */   {
/* 103 */     this.configuration = configuration;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-convention-plugin-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.convention.DefaultInterceptorMapBuilder
 * JD-Core Version:    0.6.0
 */