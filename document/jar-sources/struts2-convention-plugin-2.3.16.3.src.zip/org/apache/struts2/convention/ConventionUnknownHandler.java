/*     */ package org.apache.struts2.convention;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionContext;
/*     */ import com.opensymphony.xwork2.ActionSupport;
/*     */ import com.opensymphony.xwork2.ObjectFactory;
/*     */ import com.opensymphony.xwork2.Result;
/*     */ import com.opensymphony.xwork2.UnknownHandler;
/*     */ import com.opensymphony.xwork2.XWorkException;
/*     */ import com.opensymphony.xwork2.config.Configuration;
/*     */ import com.opensymphony.xwork2.config.ConfigurationException;
/*     */ import com.opensymphony.xwork2.config.RuntimeConfiguration;
/*     */ import com.opensymphony.xwork2.config.entities.ActionConfig;
/*     */ import com.opensymphony.xwork2.config.entities.ActionConfig.Builder;
/*     */ import com.opensymphony.xwork2.config.entities.PackageConfig;
/*     */ import com.opensymphony.xwork2.config.entities.ResultConfig;
/*     */ import com.opensymphony.xwork2.config.entities.ResultConfig.Builder;
/*     */ import com.opensymphony.xwork2.config.entities.ResultTypeConfig;
/*     */ import com.opensymphony.xwork2.config.providers.InterceptorBuilder;
/*     */ import com.opensymphony.xwork2.inject.Container;
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import com.opensymphony.xwork2.util.ClassLoaderUtil;
/*     */ import com.opensymphony.xwork2.util.logging.Logger;
/*     */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*     */ import java.net.MalformedURLException;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.servlet.ServletContext;
/*     */ 
/*     */ public class ConventionUnknownHandler
/*     */   implements UnknownHandler
/*     */ {
/*  70 */   private static final Logger LOG = LoggerFactory.getLogger(ConventionUnknownHandler.class);
/*     */   protected Configuration configuration;
/*     */   protected ObjectFactory objectFactory;
/*     */   protected ServletContext servletContext;
/*     */   protected ResultMapBuilder resultMapBuilder;
/*     */   protected String defaultParentPackageName;
/*     */   protected PackageConfig parentPackage;
/*     */   private boolean redirectToSlash;
/*     */   private ConventionsService conventionsService;
/*     */   private String nameSeparator;
/*     */ 
/*     */   @Inject
/*     */   public ConventionUnknownHandler(Configuration configuration, ObjectFactory objectFactory, ServletContext servletContext, Container container, @Inject("struts.convention.default.parent.package") String defaultParentPackageName, @Inject("struts.convention.redirect.to.slash") String redirectToSlash, @Inject("struts.convention.action.name.separator") String nameSeparator)
/*     */   {
/* 104 */     this.configuration = configuration;
/* 105 */     this.objectFactory = objectFactory;
/* 106 */     this.servletContext = servletContext;
/* 107 */     this.resultMapBuilder = ((ResultMapBuilder)container.getInstance(ResultMapBuilder.class, (String)container.getInstance(String.class, "struts.convention.resultMapBuilder")));
/* 108 */     this.conventionsService = ((ConventionsService)container.getInstance(ConventionsService.class, (String)container.getInstance(String.class, "struts.convention.conventionsService")));
/* 109 */     this.defaultParentPackageName = defaultParentPackageName;
/* 110 */     this.nameSeparator = nameSeparator;
/*     */ 
/* 112 */     this.parentPackage = configuration.getPackageConfig(defaultParentPackageName);
/* 113 */     if (this.parentPackage == null) {
/* 114 */       throw new ConfigurationException("Unknown default parent package [" + defaultParentPackageName + "]");
/*     */     }
/*     */ 
/* 117 */     this.redirectToSlash = Boolean.parseBoolean(redirectToSlash);
/*     */   }
/*     */ 
/*     */   public ActionConfig handleUnknownAction(String namespace, String actionName)
/*     */     throws XWorkException
/*     */   {
/* 123 */     if ((namespace == null) || ("/".equals(namespace))) {
/* 124 */       namespace = "";
/*     */     }
/*     */ 
/* 127 */     Map resultsByExtension = this.conventionsService.getResultTypesByExtension(this.parentPackage);
/* 128 */     String pathPrefix = determinePath(null, namespace);
/* 129 */     ActionConfig actionConfig = null;
/*     */ 
/* 132 */     if (!actionName.equals("")) {
/* 133 */       Resource resource = findResource(resultsByExtension, new String[] { pathPrefix, actionName });
/* 134 */       if (resource != null) {
/* 135 */         actionConfig = buildActionConfig(resource.path, (ResultTypeConfig)resultsByExtension.get(resource.ext));
/*     */       }
/*     */     }
/*     */ 
/* 139 */     if (actionConfig == null) {
/* 140 */       Resource resource = findResource(resultsByExtension, new String[] { pathPrefix, actionName, "/index" });
/*     */ 
/* 145 */       if ((!actionName.equals("")) && (this.redirectToSlash)) {
/* 146 */         ResultTypeConfig redirectResultTypeConfig = (ResultTypeConfig)this.parentPackage.getAllResultTypeConfigs().get("redirect");
/* 147 */         String redirectNamespace = namespace + "/" + actionName;
/* 148 */         if (LOG.isTraceEnabled()) {
/* 149 */           LOG.trace("Checking if there is an action named index in the namespace [#0]", new String[] { redirectNamespace });
/*     */         }
/*     */ 
/* 153 */         actionConfig = this.configuration.getRuntimeConfiguration().getActionConfig(redirectNamespace, "index");
/* 154 */         if (actionConfig != null) {
/* 155 */           if (LOG.isTraceEnabled()) {
/* 156 */             LOG.trace("Found action config", new String[0]);
/*     */           }
/* 158 */           PackageConfig packageConfig = this.configuration.getPackageConfig(actionConfig.getPackageName());
/* 159 */           if (redirectNamespace.equals(packageConfig.getNamespace())) {
/* 160 */             if (LOG.isTraceEnabled())
/* 161 */               LOG.trace("Action is not a default - redirecting", new String[0]);
/* 162 */             return buildActionConfig(redirectNamespace + "/", redirectResultTypeConfig);
/*     */           }
/*     */ 
/* 165 */           if (LOG.isTraceEnabled()) {
/* 166 */             LOG.trace("Action was a default - NOT redirecting", new String[0]);
/*     */           }
/*     */         }
/* 169 */         if (resource != null) {
/* 170 */           return buildActionConfig(redirectNamespace + "/", redirectResultTypeConfig);
/*     */         }
/*     */       }
/*     */ 
/* 174 */       if (resource != null)
/*     */       {
/* 176 */         actionConfig = buildActionConfig(resource.path, (ResultTypeConfig)resultsByExtension.get(resource.ext));
/*     */       }
/*     */ 
/* 180 */       if (actionConfig == null) {
/* 181 */         if (LOG.isTraceEnabled()) {
/* 182 */           LOG.trace("Looking for action named [index] in namespace [#0] or in default namespace", new String[] { namespace });
/*     */         }
/* 184 */         actionConfig = this.configuration.getRuntimeConfiguration().getActionConfig(namespace, "index");
/*     */       }
/*     */     }
/*     */ 
/* 188 */     return actionConfig;
/*     */   }
/*     */ 
/*     */   protected Resource findResource(Map<String, ResultTypeConfig> resultsByExtension, String[] parts)
/*     */   {
/* 199 */     for (String ext : resultsByExtension.keySet()) {
/* 200 */       String canonicalPath = canonicalize(string(parts) + "." + ext);
/* 201 */       if (LOG.isTraceEnabled()) {
/* 202 */         LOG.trace("Checking for [#0]", new String[] { canonicalPath });
/*     */       }
/*     */       try
/*     */       {
/* 206 */         if (this.servletContext.getResource(canonicalPath) != null)
/* 207 */           return new Resource(canonicalPath, ext);
/*     */       }
/*     */       catch (MalformedURLException e) {
/* 210 */         if (LOG.isErrorEnabled()) {
/* 211 */           LOG.error("Unable to parse path to the web application resource [#0] skipping...", new String[] { canonicalPath });
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 216 */     return null;
/*     */   }
/*     */ 
/*     */   protected String canonicalize(String path) {
/* 220 */     if (path == null) {
/* 221 */       return null;
/*     */     }
/*     */ 
/* 224 */     return path.replaceAll("/+", "/");
/*     */   }
/*     */ 
/*     */   protected ActionConfig buildActionConfig(String path, ResultTypeConfig resultTypeConfig) {
/* 228 */     Map results = new HashMap();
/* 229 */     HashMap params = new HashMap();
/* 230 */     if (resultTypeConfig.getParams() != null) {
/* 231 */       params.putAll(resultTypeConfig.getParams());
/*     */     }
/* 233 */     params.put(resultTypeConfig.getDefaultResultParam(), path);
/*     */ 
/* 235 */     PackageConfig pkg = this.configuration.getPackageConfig(this.defaultParentPackageName);
/* 236 */     List interceptors = InterceptorBuilder.constructInterceptorReference(pkg, pkg.getFullDefaultInterceptorRef(), Collections.emptyMap(), null, this.objectFactory);
/* 237 */     ResultConfig config = new ResultConfig.Builder("success", resultTypeConfig.getClassName()).addParams(params).build();
/*     */ 
/* 239 */     results.put("success", config);
/*     */ 
/* 241 */     return new ActionConfig.Builder(this.defaultParentPackageName, "execute", ActionSupport.class.getName()).addInterceptors(interceptors).addResultConfigs(results).build();
/*     */   }
/*     */ 
/*     */   private Result scanResultsByExtension(String ns, String actionName, String pathPrefix, String resultCode, ActionContext actionContext)
/*     */   {
/* 247 */     Map resultsByExtension = this.conventionsService.getResultTypesByExtension(this.parentPackage);
/* 248 */     Result result = null;
/* 249 */     for (String ext : resultsByExtension.keySet()) {
/* 250 */       if (LOG.isTraceEnabled()) {
/* 251 */         String fqan = ns + "/" + actionName;
/* 252 */         LOG.trace("Trying to locate the correct result for the FQ action [#0] with an file extension of [#1] in the directory [#2] and a result code of [#3]", new String[] { fqan, ext, pathPrefix, resultCode });
/*     */       }
/*     */ 
/* 257 */       String path = string(new String[] { pathPrefix, actionName, this.nameSeparator, resultCode, ".", ext });
/* 258 */       result = findResult(path, resultCode, ext, actionContext, resultsByExtension);
/* 259 */       if (result != null)
/*     */       {
/*     */         break;
/*     */       }
/* 263 */       path = string(new String[] { pathPrefix, actionName, ".", ext });
/* 264 */       result = findResult(path, resultCode, ext, actionContext, resultsByExtension);
/* 265 */       if (result != null)
/*     */       {
/*     */         break;
/*     */       }
/*     */ 
/* 270 */       path = string(new String[] { pathPrefix, resultCode, ".", ext });
/* 271 */       result = findResult(path, resultCode, ext, actionContext, resultsByExtension);
/* 272 */       if (result != null)
/*     */       {
/*     */         break;
/*     */       }
/*     */     }
/* 277 */     return result;
/*     */   }
/*     */ 
/*     */   public Result handleUnknownResult(ActionContext actionContext, String actionName, ActionConfig actionConfig, String resultCode)
/*     */     throws XWorkException
/*     */   {
/* 283 */     PackageConfig pkg = this.configuration.getPackageConfig(actionConfig.getPackageName());
/* 284 */     String ns = pkg.getNamespace();
/* 285 */     String pathPrefix = determinePath(actionConfig, ns);
/*     */ 
/* 287 */     Result result = scanResultsByExtension(ns, actionName, pathPrefix, resultCode, actionContext);
/*     */     Map resultsByExtension;
/* 289 */     if (result == null)
/*     */     {
/* 291 */       resultsByExtension = this.conventionsService.getResultTypesByExtension(pkg);
/* 292 */       for (String ext : resultsByExtension.keySet()) {
/* 293 */         if (LOG.isTraceEnabled()) {
/* 294 */           String fqan = ns + "/" + actionName;
/* 295 */           LOG.trace("Checking for [#0/index.#1]", new String[] { fqan, ext });
/*     */         }
/*     */ 
/* 298 */         String path = string(new String[] { pathPrefix, actionName, "/index", this.nameSeparator, resultCode, ".", ext });
/* 299 */         result = findResult(path, resultCode, ext, actionContext, resultsByExtension);
/* 300 */         if (result != null)
/*     */         {
/*     */           break;
/*     */         }
/* 304 */         path = string(new String[] { pathPrefix, actionName, "/index.", ext });
/* 305 */         result = findResult(path, resultCode, ext, actionContext, resultsByExtension);
/* 306 */         if (result != null)
/*     */         {
/*     */           break;
/*     */         }
/*     */       }
/*     */     }
/* 312 */     if ((result == null) && (resultCode != null))
/*     */     {
/* 316 */       String chainedTo = actionName + this.nameSeparator + resultCode;
/* 317 */       ActionConfig chainedToConfig = (ActionConfig)pkg.getActionConfigs().get(chainedTo);
/* 318 */       if (chainedToConfig != null) {
/* 319 */         if (LOG.isTraceEnabled()) {
/* 320 */           LOG.trace("Action [#0] used as chain result for [#1] and result [#2]", new String[] { chainedTo, actionName, resultCode });
/*     */         }
/*     */ 
/* 323 */         ResultTypeConfig chainResultType = (ResultTypeConfig)pkg.getAllResultTypeConfigs().get("chain");
/* 324 */         result = buildResult(chainedTo, resultCode, chainResultType, actionContext);
/*     */       }
/*     */     }
/*     */ 
/* 328 */     return result;
/*     */   }
/*     */ 
/*     */   protected Result findResult(String path, String resultCode, String ext, ActionContext actionContext, Map<String, ResultTypeConfig> resultsByExtension)
/*     */   {
/*     */     try {
/* 334 */       boolean traceEnabled = LOG.isTraceEnabled();
/* 335 */       if (traceEnabled) {
/* 336 */         LOG.trace("Checking ServletContext for [#0]", new String[] { path });
/*     */       }
/* 338 */       if (this.servletContext.getResource(path) != null) {
/* 339 */         if (traceEnabled)
/* 340 */           LOG.trace("Found", new String[0]);
/* 341 */         return buildResult(path, resultCode, (ResultTypeConfig)resultsByExtension.get(ext), actionContext);
/*     */       }
/*     */ 
/* 344 */       if (traceEnabled) {
/* 345 */         LOG.trace("Checking ClasLoader for #0", new String[] { path });
/*     */       }
/* 347 */       String classLoaderPath = path.startsWith("/") ? path.substring(1, path.length()) : path;
/* 348 */       if (ClassLoaderUtil.getResource(classLoaderPath, getClass()) != null) {
/* 349 */         if (traceEnabled)
/* 350 */           LOG.trace("Found", new String[0]);
/* 351 */         return buildResult(path, resultCode, (ResultTypeConfig)resultsByExtension.get(ext), actionContext);
/*     */       }
/*     */     } catch (MalformedURLException e) {
/* 354 */       if (LOG.isErrorEnabled()) {
/* 355 */         LOG.error("Unable to parse template path: [#0] skipping...", new String[] { path });
/*     */       }
/*     */     }
/* 358 */     return null;
/*     */   }
/*     */ 
/*     */   protected Result buildResult(String path, String resultCode, ResultTypeConfig config, ActionContext invocationContext) {
/* 362 */     String resultClass = config.getClassName();
/*     */ 
/* 364 */     Map params = new LinkedHashMap();
/* 365 */     if (config.getParams() != null) {
/* 366 */       params.putAll(config.getParams());
/*     */     }
/* 368 */     params.put(config.getDefaultResultParam(), path);
/*     */ 
/* 370 */     ResultConfig resultConfig = new ResultConfig.Builder(resultCode, resultClass).addParams(params).build();
/*     */     try {
/* 372 */       return this.objectFactory.buildResult(resultConfig, invocationContext.getContextMap()); } catch (Exception e) {
/*     */     }
/* 374 */     throw new XWorkException("Unable to build convention result", e, resultConfig);
/*     */   }
/*     */ 
/*     */   protected String string(String[] parts)
/*     */   {
/* 379 */     StringBuilder sb = new StringBuilder();
/* 380 */     for (String part : parts) {
/* 381 */       sb.append(part);
/*     */     }
/* 383 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   protected String determinePath(ActionConfig actionConfig, String namespace)
/*     */   {
/* 396 */     String finalPrefix = this.conventionsService.determineResultPath(actionConfig);
/*     */ 
/* 398 */     if (!finalPrefix.endsWith("/")) {
/* 399 */       finalPrefix = finalPrefix + "/";
/*     */     }
/*     */ 
/* 402 */     if ((namespace == null) || ("/".equals(namespace))) {
/* 403 */       namespace = "";
/*     */     }
/*     */ 
/* 406 */     if (namespace.length() > 0) {
/* 407 */       if (namespace.startsWith("/")) {
/* 408 */         namespace = namespace.substring(1);
/*     */       }
/*     */ 
/* 411 */       if (!namespace.endsWith("/")) {
/* 412 */         namespace = namespace + "/";
/*     */       }
/*     */     }
/*     */ 
/* 416 */     return finalPrefix + namespace;
/*     */   }
/*     */ 
/*     */   public Object handleUnknownActionMethod(Object action, String methodName)
/*     */     throws NoSuchMethodException
/*     */   {
/* 423 */     throw null;
/*     */   }
/*     */   public static class Resource {
/*     */     final String path;
/*     */     final String ext;
/*     */ 
/* 431 */     public Resource(String path, String ext) { this.path = path;
/* 432 */       this.ext = ext;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-convention-plugin-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.convention.ConventionUnknownHandler
 * JD-Core Version:    0.6.0
 */