/*    */ package org.apache.struts2.convention;
/*    */ 
/*    */ import com.opensymphony.xwork2.inject.Inject;
/*    */ import com.opensymphony.xwork2.util.logging.Logger;
/*    */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*    */ import org.apache.commons.lang3.StringUtils;
/*    */ 
/*    */ public class SEOActionNameBuilder
/*    */   implements ActionNameBuilder
/*    */ {
/* 37 */   private static final Logger LOG = LoggerFactory.getLogger(SEOActionNameBuilder.class);
/* 38 */   private String actionSuffix = "Action";
/*    */   private boolean lowerCase;
/*    */   private String separator;
/*    */ 
/*    */   @Inject
/*    */   public SEOActionNameBuilder(@Inject("struts.convention.action.name.lowercase") String lowerCase, @Inject("struts.convention.action.name.separator") String separator)
/*    */   {
/* 45 */     this.lowerCase = Boolean.parseBoolean(lowerCase);
/* 46 */     this.separator = separator;
/*    */   }
/*    */ 
/*    */   @Inject(value="struts.convention.action.suffix", required=false)
/*    */   public void setActionSuffix(String actionSuffix)
/*    */   {
/* 55 */     if (StringUtils.isNotBlank(actionSuffix))
/* 56 */       this.actionSuffix = actionSuffix;
/*    */   }
/*    */ 
/*    */   public String build(String className)
/*    */   {
/* 61 */     String actionName = className;
/*    */ 
/* 63 */     if (actionName.equals(this.actionSuffix)) {
/* 64 */       throw new IllegalStateException("The action name cannot be the same as the action suffix [" + this.actionSuffix + "]");
/*    */     }
/*    */ 
/* 67 */     if (actionName.endsWith(this.actionSuffix)) {
/* 68 */       actionName = actionName.substring(0, actionName.length() - this.actionSuffix.length());
/*    */     }
/*    */ 
/* 72 */     char[] ca = actionName.toCharArray();
/* 73 */     StringBuilder build = new StringBuilder("" + ca[0]);
/* 74 */     boolean lower = true;
/* 75 */     for (int i = 1; i < ca.length; i++) {
/* 76 */       char c = ca[i];
/* 77 */       if ((Character.isUpperCase(c)) && (lower)) {
/* 78 */         build.append(this.separator);
/* 79 */         lower = false;
/* 80 */       } else if (!Character.isUpperCase(c)) {
/* 81 */         lower = true;
/*    */       }
/*    */ 
/* 84 */       build.append(c);
/*    */     }
/*    */ 
/* 87 */     actionName = build.toString();
/* 88 */     if (this.lowerCase) {
/* 89 */       actionName = actionName.toLowerCase();
/*    */     }
/*    */ 
/* 92 */     if (LOG.isTraceEnabled()) {
/* 93 */       LOG.trace("Changed action name from [#0] to [#1]", new String[] { className, actionName });
/*    */     }
/*    */ 
/* 96 */     return actionName;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-convention-plugin-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.convention.SEOActionNameBuilder
 * JD-Core Version:    0.6.0
 */