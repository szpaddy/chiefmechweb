/*    */ package org.apache.struts2.convention;
/*    */ 
/*    */ import com.opensymphony.xwork2.config.ConfigurationException;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class StringTools
/*    */ {
/*    */   public static boolean contains(String[] strings, String value, boolean ignoreCase)
/*    */   {
/* 35 */     if (strings != null) {
/* 36 */       for (String string : strings) {
/* 37 */         if ((string.equals(value)) || ((ignoreCase) && (string.equalsIgnoreCase(value)))) {
/* 38 */           return true;
/*    */         }
/*    */       }
/*    */     }
/* 42 */     return false;
/*    */   }
/*    */ 
/*    */   public static Map<String, String> createParameterMap(String[] parms) {
/* 46 */     Map map = new HashMap();
/* 47 */     int subtract = parms.length % 2;
/* 48 */     if (subtract != 0) {
/* 49 */       throw new ConfigurationException("'params' is a string array and they must be in a key value pair configuration. It looks like you have specified an odd number of parameters and there should only be an even number. (e.g. params = {\"key\", \"value\"})");
/*    */     }
/*    */ 
/* 56 */     for (int i = 0; i < parms.length; i += 2) {
/* 57 */       String key = parms[i];
/* 58 */       String value = parms[(i + 1)];
/* 59 */       map.put(key, value);
/*    */     }
/*    */ 
/* 62 */     return map;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-convention-plugin-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.convention.StringTools
 * JD-Core Version:    0.6.0
 */