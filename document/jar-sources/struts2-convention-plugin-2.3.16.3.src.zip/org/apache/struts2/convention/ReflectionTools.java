/*    */ package org.apache.struts2.convention;
/*    */ 
/*    */ import java.lang.annotation.Annotation;
/*    */ import java.lang.reflect.Method;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ public class ReflectionTools
/*    */ {
/*    */   public static boolean containsMethod(Class<?> klass, String method, Class<?>[] parameterTypes)
/*    */   {
/*    */     try
/*    */     {
/* 44 */       klass.getMethod(method, parameterTypes);
/* 45 */       return true; } catch (NoSuchMethodException e) {
/*    */     }
/* 47 */     return false;
/*    */   }
/*    */ 
/*    */   public static <T extends Annotation> T getAnnotation(Class<?> klass, String methodName, Class<T> annotationClass)
/*    */   {
/*    */     try
/*    */     {
/* 61 */       Method method = klass.getMethod(methodName, new Class[0]);
/* 62 */       return method.getAnnotation(annotationClass); } catch (NoSuchMethodException e) {
/*    */     }
/* 64 */     throw new RuntimeException(e);
/*    */   }
/*    */ 
/*    */   public static List<Class<?>> getClassHierarchy(Class<?> clazz)
/*    */   {
/* 74 */     List classes = new ArrayList();
/* 75 */     while (clazz != null) {
/* 76 */       classes.add(0, clazz);
/* 77 */       clazz = clazz.getSuperclass();
/*    */     }
/*    */ 
/* 80 */     return classes;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-convention-plugin-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.convention.ReflectionTools
 * JD-Core Version:    0.6.0
 */