package org.apache.struts2.convention;

import com.opensymphony.xwork2.config.entities.PackageConfig;
import com.opensymphony.xwork2.config.entities.ResultConfig;
import java.util.Map;
import org.apache.struts2.convention.annotation.Action;

public abstract interface ResultMapBuilder
{
  public abstract Map<String, ResultConfig> build(Class<?> paramClass, Action paramAction, String paramString, PackageConfig paramPackageConfig);
}

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-convention-plugin-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.convention.ResultMapBuilder
 * JD-Core Version:    0.6.0
 */