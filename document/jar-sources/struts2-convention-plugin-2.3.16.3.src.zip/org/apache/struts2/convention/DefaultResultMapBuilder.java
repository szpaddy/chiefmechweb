/*     */ package org.apache.struts2.convention;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionContext;
/*     */ import com.opensymphony.xwork2.config.ConfigurationException;
/*     */ import com.opensymphony.xwork2.config.entities.PackageConfig;
/*     */ import com.opensymphony.xwork2.config.entities.ResultConfig;
/*     */ import com.opensymphony.xwork2.config.entities.ResultConfig.Builder;
/*     */ import com.opensymphony.xwork2.config.entities.ResultTypeConfig;
/*     */ import com.opensymphony.xwork2.inject.Container;
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import com.opensymphony.xwork2.util.finder.ClassLoaderInterface;
/*     */ import com.opensymphony.xwork2.util.finder.ClassLoaderInterfaceDelegate;
/*     */ import com.opensymphony.xwork2.util.finder.ResourceFinder;
/*     */ import com.opensymphony.xwork2.util.finder.Test;
/*     */ import com.opensymphony.xwork2.util.logging.Logger;
/*     */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*     */ import java.io.IOException;
/*     */ import java.net.URL;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import javax.servlet.ServletContext;
/*     */ import org.apache.commons.lang3.ObjectUtils;
/*     */ import org.apache.commons.lang3.StringUtils;
/*     */ import org.apache.struts2.convention.annotation.Action;
/*     */ import org.apache.struts2.convention.annotation.Result;
/*     */ import org.apache.struts2.convention.annotation.Results;
/*     */ 
/*     */ public class DefaultResultMapBuilder
/*     */   implements ResultMapBuilder
/*     */ {
/* 120 */   private static final Logger LOG = LoggerFactory.getLogger(DefaultResultMapBuilder.class);
/*     */   private final ServletContext servletContext;
/*     */   private Set<String> relativeResultTypes;
/*     */   private ConventionsService conventionsService;
/* 124 */   private boolean flatResultLayout = true;
/*     */ 
/*     */   @Inject
/*     */   public DefaultResultMapBuilder(ServletContext servletContext, Container container, @Inject("struts.convention.relative.result.types") String relativeResultTypes)
/*     */   {
/* 137 */     this.servletContext = servletContext;
/* 138 */     this.relativeResultTypes = new HashSet(Arrays.asList(relativeResultTypes.split("\\s*[,]\\s*")));
/* 139 */     this.conventionsService = ((ConventionsService)container.getInstance(ConventionsService.class, (String)container.getInstance(String.class, "struts.convention.conventionsService")));
/*     */   }
/*     */ 
/*     */   @Inject("struts.convention.result.flatLayout")
/*     */   public void setFlatResultLayout(String flatResultLayout)
/*     */   {
/* 149 */     this.flatResultLayout = "true".equals(flatResultLayout);
/*     */   }
/*     */ 
/*     */   public Map<String, ResultConfig> build(Class<?> actionClass, Action annotation, String actionName, PackageConfig packageConfig)
/*     */   {
/* 160 */     String defaultResultPath = this.conventionsService.determineResultPath(actionClass);
/*     */ 
/* 163 */     if (!defaultResultPath.endsWith("/")) {
/* 164 */       defaultResultPath = defaultResultPath + "/";
/*     */     }
/*     */ 
/* 168 */     String namespace = packageConfig.getNamespace();
/* 169 */     if ((namespace != null) && (namespace.startsWith("/")))
/* 170 */       defaultResultPath = defaultResultPath + namespace.substring(1);
/* 171 */     else if (namespace != null) {
/* 172 */       defaultResultPath = defaultResultPath + namespace;
/*     */     }
/*     */ 
/* 175 */     if (LOG.isTraceEnabled()) {
/* 176 */       LOG.trace("Using final calculated namespace [#0]", new String[] { namespace });
/*     */     }
/*     */ 
/* 180 */     if (!defaultResultPath.endsWith("/")) {
/* 181 */       defaultResultPath = defaultResultPath + "/";
/*     */     }
/*     */ 
/* 184 */     String resultPrefix = defaultResultPath + actionName;
/*     */ 
/* 187 */     Map results = new HashMap();
/* 188 */     Map resultsByExtension = this.conventionsService.getResultTypesByExtension(packageConfig);
/* 189 */     createFromResources(actionClass, results, defaultResultPath, resultPrefix, actionName, packageConfig, resultsByExtension);
/*     */ 
/* 193 */     for (Class clazz : ReflectionTools.getClassHierarchy(actionClass)) {
/* 194 */       createResultsFromAnnotations(clazz, packageConfig, defaultResultPath, results, resultsByExtension);
/*     */     }
/*     */ 
/* 199 */     if ((annotation != null) && (annotation.results() != null) && (annotation.results().length > 0)) {
/* 200 */       createFromAnnotations(results, defaultResultPath, packageConfig, annotation.results(), actionClass, resultsByExtension);
/*     */     }
/*     */ 
/* 203 */     return results;
/*     */   }
/*     */ 
/*     */   protected void createResultsFromAnnotations(Class<?> actionClass, PackageConfig packageConfig, String defaultResultPath, Map<String, ResultConfig> results, Map<String, ResultTypeConfig> resultsByExtension)
/*     */   {
/* 216 */     Results resultsAnn = (Results)actionClass.getAnnotation(Results.class);
/* 217 */     if (resultsAnn != null) {
/* 218 */       createFromAnnotations(results, defaultResultPath, packageConfig, resultsAnn.value(), actionClass, resultsByExtension);
/*     */     }
/*     */ 
/* 222 */     Result resultAnn = (Result)actionClass.getAnnotation(Result.class);
/* 223 */     if (resultAnn != null)
/* 224 */       createFromAnnotations(results, defaultResultPath, packageConfig, new Result[] { resultAnn }, actionClass, resultsByExtension);
/*     */   }
/*     */ 
/*     */   protected void createFromResources(Class<?> actionClass, Map<String, ResultConfig> results, String resultPath, String resultPrefix, String actionName, PackageConfig packageConfig, Map<String, ResultTypeConfig> resultsByExtension)
/*     */   {
/* 245 */     if (LOG.isTraceEnabled()) {
/* 246 */       LOG.trace("Searching for results in the Servlet container at [#0] with result prefix of [#1]", new String[] { resultPath, resultPrefix });
/*     */     }
/*     */ 
/* 252 */     Set paths = this.servletContext.getResourcePaths(this.flatResultLayout ? resultPath : resultPrefix);
/* 253 */     if (paths != null) {
/* 254 */       for (String path : paths) {
/* 255 */         if (LOG.isTraceEnabled()) {
/* 256 */           LOG.trace("Processing resource path [#0]", new String[] { path });
/*     */         }
/*     */ 
/* 259 */         String fileName = StringUtils.substringAfterLast(path, "/");
/* 260 */         if ((StringUtils.isBlank(fileName)) || (StringUtils.startsWith(fileName, "."))) {
/* 261 */           if (LOG.isTraceEnabled()) {
/* 262 */             LOG.trace("Ignoring file without name [#0]", new String[] { path }); continue;
/*     */           }
/*     */         }
/* 265 */         if (fileName.lastIndexOf(".") > 0) {
/* 266 */           String suffix = fileName.substring(fileName.lastIndexOf(".") + 1);
/*     */ 
/* 268 */           if (this.conventionsService.getResultTypesByExtension(packageConfig).get(suffix) == null) {
/* 269 */             if (LOG.isDebugEnabled()) {
/* 270 */               LOG.debug("No result type defined for file suffix : [#0]. Ignoring file #1", new String[] { suffix, fileName }); continue;
/*     */             }
/*     */           }
/*     */         }
/*     */ 
/* 275 */         makeResults(actionClass, path, resultPrefix, results, packageConfig, resultsByExtension);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 280 */     String classPathLocation = resultPath.startsWith("/") ? resultPath.substring(1, resultPath.length()) : resultPath;
/*     */ 
/* 282 */     if (LOG.isTraceEnabled()) {
/* 283 */       LOG.trace("Searching for results in the class path at [#0] with a result prefix of [#1] and action name [#2]", new String[] { classPathLocation, resultPrefix, actionName });
/*     */     }
/*     */ 
/* 288 */     ResourceFinder finder = new ResourceFinder(classPathLocation, getClassLoaderInterface());
/*     */     try {
/* 290 */       Map matches = finder.getResourcesMap("");
/* 291 */       if (matches != null) {
/* 292 */         resourceTest = getResourceTest(resultPath, actionName);
/* 293 */         for (Map.Entry entry : matches.entrySet())
/* 294 */           if (resourceTest.test(entry.getValue())) {
/* 295 */             if (LOG.isTraceEnabled()) {
/* 296 */               LOG.trace("Processing URL [#0]", new String[] { (String)entry.getKey() });
/*     */             }
/*     */ 
/* 299 */             String urlStr = ((URL)entry.getValue()).toString();
/* 300 */             int index = urlStr.lastIndexOf(resultPrefix);
/* 301 */             String path = urlStr.substring(index);
/* 302 */             makeResults(actionClass, path, resultPrefix, results, packageConfig, resultsByExtension);
/*     */           }
/*     */       }
/*     */     }
/*     */     catch (IOException ex)
/*     */     {
/*     */       Test resourceTest;
/* 308 */       if (LOG.isErrorEnabled())
/* 309 */         LOG.error("Unable to scan directory [#0] for results", ex, new String[] { classPathLocation });
/*     */     }
/*     */   }
/*     */ 
/*     */   protected ClassLoaderInterface getClassLoaderInterface()
/*     */   {
/* 323 */     ClassLoaderInterface classLoaderInterface = null;
/* 324 */     ActionContext ctx = ActionContext.getContext();
/* 325 */     if (ctx != null) {
/* 326 */       classLoaderInterface = (ClassLoaderInterface)ctx.get("__current_class_loader_interface");
/*     */     }
/* 328 */     return (ClassLoaderInterface)ObjectUtils.defaultIfNull(classLoaderInterface, new ClassLoaderInterfaceDelegate(Thread.currentThread().getContextClassLoader()));
/*     */   }
/*     */ 
/*     */   private Test<URL> getResourceTest(String resultPath, String actionName)
/*     */   {
/* 333 */     return new Test(resultPath, actionName) {
/*     */       public boolean test(URL url) {
/* 335 */         String urlStr = url.toString();
/* 336 */         int index = urlStr.lastIndexOf(this.val$resultPath);
/* 337 */         String path = urlStr.substring(index + this.val$resultPath.length());
/* 338 */         return path.startsWith(this.val$actionName);
/*     */       }
/*     */     };
/*     */   }
/*     */ 
/*     */   protected void makeResults(Class<?> actionClass, String path, String resultPrefix, Map<String, ResultConfig> results, PackageConfig packageConfig, Map<String, ResultTypeConfig> resultsByExtension)
/*     */   {
/* 358 */     if (path.startsWith(resultPrefix)) {
/* 359 */       int indexOfDot = path.indexOf('.', resultPrefix.length());
/*     */ 
/* 362 */       if (indexOfDot == resultPrefix.length()) {
/* 363 */         if (LOG.isTraceEnabled()) {
/* 364 */           LOG.trace("The result file [#0] has no result code and therefore will be associated with success, input and error by default. This might be overridden by another result file or an annotation.", new String[] { path });
/*     */         }
/*     */ 
/* 369 */         addResult(actionClass, path, results, packageConfig, resultsByExtension, "success");
/* 370 */         addResult(actionClass, path, results, packageConfig, resultsByExtension, "input");
/* 371 */         addResult(actionClass, path, results, packageConfig, resultsByExtension, "error");
/*     */       }
/* 374 */       else if (indexOfDot > resultPrefix.length()) {
/* 375 */         if (LOG.isTraceEnabled()) {
/* 376 */           LOG.trace("The result file [#0] has a result code and therefore will be associated with only that result code.", new String[] { path });
/*     */         }
/*     */ 
/* 380 */         String resultCode = path.substring(resultPrefix.length() + 1, indexOfDot);
/* 381 */         ResultConfig result = createResultConfig(actionClass, new ResultInfo(resultCode, path, packageConfig, resultsByExtension), packageConfig, null);
/*     */ 
/* 384 */         results.put(resultCode, result);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void addResult(Class<?> actionClass, String path, Map<String, ResultConfig> results, PackageConfig packageConfig, Map<String, ResultTypeConfig> resultsByExtension, String resultKey)
/*     */   {
/* 404 */     if (!results.containsKey(resultKey)) {
/* 405 */       Map globalResults = packageConfig.getAllGlobalResults();
/* 406 */       if (globalResults.containsKey(resultKey)) {
/* 407 */         results.put(resultKey, globalResults.get(resultKey));
/*     */       } else {
/* 409 */         ResultConfig resultConfig = createResultConfig(actionClass, new ResultInfo(resultKey, path, packageConfig, resultsByExtension), packageConfig, null);
/*     */ 
/* 412 */         results.put(resultKey, resultConfig);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void createFromAnnotations(Map<String, ResultConfig> resultConfigs, String resultPath, PackageConfig packageConfig, Result[] results, Class<?> actionClass, Map<String, ResultTypeConfig> resultsByExtension)
/*     */   {
/* 421 */     for (Result result : results) {
/* 422 */       ResultConfig config = createResultConfig(actionClass, new ResultInfo(result, packageConfig, resultPath, actionClass, resultsByExtension), packageConfig, result);
/*     */ 
/* 425 */       if (config != null)
/* 426 */         resultConfigs.put(config.getName(), config);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected ResultConfig createResultConfig(Class<?> actionClass, ResultInfo info, PackageConfig packageConfig, Result result)
/*     */   {
/* 448 */     ResultTypeConfig resultTypeConfig = (ResultTypeConfig)packageConfig.getAllResultTypeConfigs().get(info.type);
/* 449 */     if (resultTypeConfig == null) {
/* 450 */       throw new ConfigurationException("The Result type [" + info.type + "] which is" + " defined in the Result annotation on the class [" + actionClass + "] or determined" + " by the file extension or is the default result type for the PackageConfig of the" + " action, could not be found as a result-type defined for the Struts/XWork package [" + packageConfig.getName() + "]");
/*     */     }
/*     */ 
/* 458 */     HashMap params = new HashMap();
/* 459 */     if (resultTypeConfig.getParams() != null) {
/* 460 */       params.putAll(resultTypeConfig.getParams());
/*     */     }
/*     */ 
/* 464 */     if (result != null) {
/* 465 */       params.putAll(StringTools.createParameterMap(result.params()));
/*     */     }
/*     */ 
/* 469 */     if (info.location != null) {
/* 470 */       String defaultParamName = resultTypeConfig.getDefaultResultParam();
/* 471 */       if (!params.containsKey(defaultParamName)) {
/* 472 */         params.put(defaultParamName, info.location);
/*     */       }
/*     */     }
/*     */ 
/* 476 */     return new ResultConfig.Builder(info.name, resultTypeConfig.getClassName()).addParams(params).build();
/*     */   }
/*     */   protected class ResultInfo {
/*     */     public final String name;
/*     */     public final String location;
/*     */     public final String type;
/*     */ 
/* 486 */     public ResultInfo(String name, PackageConfig location, Map<String, ResultTypeConfig> packageConfig) { this.name = name;
/* 487 */       this.location = location;
/* 488 */       this.type = determineType(location, packageConfig, resultsByExtension);
/*     */     }
/*     */ 
/*     */     public ResultInfo(PackageConfig result, String packageConfig, Class<?> resultPath, Map<String, ResultTypeConfig> actionClass)
/*     */     {
/* 493 */       this.name = result.name();
/* 494 */       if (StringUtils.isNotBlank(result.type()))
/* 495 */         this.type = result.type();
/* 496 */       else if (StringUtils.isNotBlank(result.location()))
/* 497 */         this.type = determineType(result.location(), packageConfig, resultsByExtension);
/*     */       else {
/* 499 */         throw new ConfigurationException("The action class [" + actionClass + "] contains a " + "result annotation that has no type parameter and no location parameter. One of " + "these must be defined.");
/*     */       }
/*     */ 
/* 505 */       if (StringUtils.isNotBlank(result.location())) {
/* 506 */         if ((DefaultResultMapBuilder.this.relativeResultTypes.contains(this.type)) && (!result.location().startsWith("/")))
/* 507 */           this.location = (resultPath + result.location());
/*     */         else
/* 509 */           this.location = result.location();
/*     */       }
/*     */       else
/* 512 */         this.location = null;
/*     */     }
/*     */ 
/*     */     String determineType(String location, PackageConfig packageConfig, Map<String, ResultTypeConfig> resultsByExtension)
/*     */     {
/* 518 */       int indexOfDot = location.lastIndexOf(".");
/* 519 */       if (indexOfDot > 0) {
/* 520 */         String extension = location.substring(indexOfDot + 1);
/* 521 */         ResultTypeConfig resultTypeConfig = (ResultTypeConfig)resultsByExtension.get(extension);
/* 522 */         if (resultTypeConfig != null) {
/* 523 */           return resultTypeConfig.getName();
/*     */         }
/* 525 */         throw new ConfigurationException("Unable to find a result type for extension [" + extension + "] " + "in location attribute [" + location + "].");
/*     */       }
/*     */ 
/* 528 */       return packageConfig.getFullDefaultResultType();
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-convention-plugin-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.convention.DefaultResultMapBuilder
 * JD-Core Version:    0.6.0
 */