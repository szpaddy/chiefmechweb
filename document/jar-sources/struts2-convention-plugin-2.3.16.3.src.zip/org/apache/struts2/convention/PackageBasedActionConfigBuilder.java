/*      */ package org.apache.struts2.convention;
/*      */ 
/*      */ import com.opensymphony.xwork2.ActionContext;
/*      */ import com.opensymphony.xwork2.FileManager;
/*      */ import com.opensymphony.xwork2.FileManagerFactory;
/*      */ import com.opensymphony.xwork2.ObjectFactory;
/*      */ import com.opensymphony.xwork2.config.Configuration;
/*      */ import com.opensymphony.xwork2.config.ConfigurationException;
/*      */ import com.opensymphony.xwork2.config.entities.ActionConfig;
/*      */ import com.opensymphony.xwork2.config.entities.ActionConfig.Builder;
/*      */ import com.opensymphony.xwork2.config.entities.ExceptionMappingConfig;
/*      */ import com.opensymphony.xwork2.config.entities.ExceptionMappingConfig.Builder;
/*      */ import com.opensymphony.xwork2.config.entities.PackageConfig;
/*      */ import com.opensymphony.xwork2.config.entities.PackageConfig.Builder;
/*      */ import com.opensymphony.xwork2.inject.Container;
/*      */ import com.opensymphony.xwork2.inject.Inject;
/*      */ import com.opensymphony.xwork2.util.AnnotationUtils;
/*      */ import com.opensymphony.xwork2.util.TextParseUtil;
/*      */ import com.opensymphony.xwork2.util.WildcardHelper;
/*      */ import com.opensymphony.xwork2.util.classloader.ReloadingClassLoader;
/*      */ import com.opensymphony.xwork2.util.finder.ClassFinder;
/*      */ import com.opensymphony.xwork2.util.finder.ClassFinder.ClassInfo;
/*      */ import com.opensymphony.xwork2.util.finder.ClassLoaderInterface;
/*      */ import com.opensymphony.xwork2.util.finder.ClassLoaderInterfaceDelegate;
/*      */ import com.opensymphony.xwork2.util.finder.Test;
/*      */ import com.opensymphony.xwork2.util.finder.UrlSet;
/*      */ import com.opensymphony.xwork2.util.finder.UrlSet.FileProtocolNormalizer;
/*      */ import com.opensymphony.xwork2.util.logging.Logger;
/*      */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*      */ import java.io.IOException;
/*      */ import java.lang.reflect.Method;
/*      */ import java.net.URL;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.regex.Pattern;
/*      */ import org.apache.commons.lang3.ObjectUtils;
/*      */ import org.apache.commons.lang3.StringUtils;
/*      */ import org.apache.struts2.StrutsException;
/*      */ import org.apache.struts2.convention.annotation.Actions;
/*      */ import org.apache.struts2.convention.annotation.DefaultInterceptorRef;
/*      */ import org.apache.struts2.convention.annotation.ExceptionMapping;
/*      */ import org.apache.struts2.convention.annotation.ExceptionMappings;
/*      */ import org.apache.struts2.convention.annotation.Namespace;
/*      */ import org.apache.struts2.convention.annotation.Namespaces;
/*      */ import org.apache.struts2.convention.annotation.ParentPackage;
/*      */ 
/*      */ public class PackageBasedActionConfigBuilder
/*      */   implements ActionConfigBuilder
/*      */ {
/*   83 */   private static final Logger LOG = LoggerFactory.getLogger(PackageBasedActionConfigBuilder.class);
/*      */   private static final boolean EXTRACT_BASE_INTERFACES = true;
/*      */   private final Configuration configuration;
/*      */   private final ActionNameBuilder actionNameBuilder;
/*      */   private final ResultMapBuilder resultMapBuilder;
/*      */   private final InterceptorMapBuilder interceptorMapBuilder;
/*      */   private final ObjectFactory objectFactory;
/*      */   private final String defaultParentPackage;
/*      */   private final boolean redirectToSlash;
/*      */   private String[] actionPackages;
/*      */   private String[] excludePackages;
/*      */   private String[] packageLocators;
/*      */   private String[] includeJars;
/*      */   private String packageLocatorsBasePackage;
/*   98 */   private boolean disableActionScanning = false;
/*   99 */   private boolean disablePackageLocatorsScanning = false;
/*  100 */   private String actionSuffix = "Action";
/*  101 */   private boolean checkImplementsAction = true;
/*  102 */   private boolean mapAllMatches = false;
/*  103 */   private Set<String> loadedFileUrls = new HashSet();
/*      */   private boolean devMode;
/*      */   private ReloadingClassLoader reloadingClassLoader;
/*      */   private boolean reload;
/*      */   private Set<String> fileProtocols;
/*      */   private boolean alwaysMapExecute;
/*      */   private boolean excludeParentClassLoader;
/*      */   private boolean slashesInActionNames;
/*      */   private static final String DEFAULT_METHOD = "execute";
/*  113 */   private boolean eagerLoading = false;
/*      */   private FileManager fileManager;
/*      */ 
/*      */   @Inject
/*      */   public PackageBasedActionConfigBuilder(Configuration configuration, Container container, ObjectFactory objectFactory, @Inject("struts.convention.redirect.to.slash") String redirectToSlash, @Inject("struts.convention.default.parent.package") String defaultParentPackage)
/*      */   {
/*  136 */     this.configuration = configuration;
/*  137 */     this.actionNameBuilder = ((ActionNameBuilder)container.getInstance(ActionNameBuilder.class, (String)container.getInstance(String.class, "struts.convention.actionNameBuilder")));
/*  138 */     this.resultMapBuilder = ((ResultMapBuilder)container.getInstance(ResultMapBuilder.class, (String)container.getInstance(String.class, "struts.convention.resultMapBuilder")));
/*  139 */     this.interceptorMapBuilder = ((InterceptorMapBuilder)container.getInstance(InterceptorMapBuilder.class, (String)container.getInstance(String.class, "struts.convention.interceptorMapBuilder")));
/*  140 */     this.objectFactory = objectFactory;
/*  141 */     this.redirectToSlash = Boolean.parseBoolean(redirectToSlash);
/*      */ 
/*  143 */     if (LOG.isTraceEnabled()) {
/*  144 */       LOG.trace("Setting action default parent package to [#0]", new String[] { defaultParentPackage });
/*      */     }
/*      */ 
/*  147 */     this.defaultParentPackage = defaultParentPackage;
/*      */   }
/*      */   @Inject("struts.devMode")
/*      */   public void setDevMode(String mode) {
/*  152 */     this.devMode = "true".equals(mode);
/*      */   }
/*      */ 
/*      */   @Inject("struts.convention.classes.reload")
/*      */   public void setReload(String reload)
/*      */   {
/*  161 */     this.reload = "true".equals(reload);
/*      */   }
/*      */ 
/*      */   @Inject("struts.enable.SlashesInActionNames")
/*      */   public void setSlashesInActionNames(String slashesInActionNames) {
/*  167 */     this.slashesInActionNames = "true".equals(slashesInActionNames);
/*      */   }
/*      */ 
/*      */   @Inject("struts.convention.exclude.parentClassLoader")
/*      */   public void setExcludeParentClassLoader(String exclude)
/*      */   {
/*  175 */     this.excludeParentClassLoader = "true".equals(exclude);
/*      */   }
/*      */ 
/*      */   @Inject("struts.convention.action.alwaysMapExecute")
/*      */   public void setAlwaysMapExecute(String alwaysMapExecute)
/*      */   {
/*  184 */     this.alwaysMapExecute = "true".equals(alwaysMapExecute);
/*      */   }
/*      */ 
/*      */   @Inject("struts.convention.action.fileProtocols")
/*      */   public void setFileProtocols(String fileProtocols)
/*      */   {
/*  193 */     if (StringUtils.isNotBlank(fileProtocols))
/*  194 */       this.fileProtocols = TextParseUtil.commaDelimitedStringToSet(fileProtocols);
/*      */   }
/*      */ 
/*      */   @Inject(value="struts.convention.action.disableScanning", required=false)
/*      */   public void setDisableActionScanning(String disableActionScanning)
/*      */   {
/*  203 */     this.disableActionScanning = "true".equals(disableActionScanning);
/*      */   }
/*      */ 
/*      */   @Inject(value="struts.convention.action.includeJars", required=false)
/*      */   public void setIncludeJars(String includeJars)
/*      */   {
/*  211 */     if (StringUtils.isNotEmpty(includeJars))
/*  212 */       this.includeJars = includeJars.split("\\s*[,]\\s*");
/*      */   }
/*      */ 
/*      */   @Inject(value="struts.convention.package.locators.disable", required=false)
/*      */   public void setDisablePackageLocatorsScanning(String disablePackageLocatorsScanning)
/*      */   {
/*  220 */     this.disablePackageLocatorsScanning = "true".equals(disablePackageLocatorsScanning);
/*      */   }
/*      */ 
/*      */   @Inject(value="struts.convention.action.packages", required=false)
/*      */   public void setActionPackages(String actionPackages)
/*      */   {
/*  229 */     if (StringUtils.isNotBlank(actionPackages))
/*  230 */       this.actionPackages = actionPackages.split("\\s*[,]\\s*");
/*      */   }
/*      */ 
/*      */   @Inject(value="struts.convention.action.checkImplementsAction", required=false)
/*      */   public void setCheckImplementsAction(String checkImplementsAction)
/*      */   {
/*  240 */     this.checkImplementsAction = "true".equals(checkImplementsAction);
/*      */   }
/*      */ 
/*      */   @Inject(value="struts.convention.action.suffix", required=false)
/*      */   public void setActionSuffix(String actionSuffix)
/*      */   {
/*  249 */     if (StringUtils.isNotBlank(actionSuffix))
/*  250 */       this.actionSuffix = actionSuffix;
/*      */   }
/*      */ 
/*      */   @Inject(value="struts.convention.exclude.packages", required=false)
/*      */   public void setExcludePackages(String excludePackages)
/*      */   {
/*  260 */     if (StringUtils.isNotBlank(excludePackages))
/*  261 */       this.excludePackages = excludePackages.split("\\s*[,]\\s*");
/*      */   }
/*      */ 
/*      */   @Inject(value="struts.convention.package.locators", required=false)
/*      */   public void setPackageLocators(String packageLocators)
/*      */   {
/*  270 */     this.packageLocators = packageLocators.split("\\s*[,]\\s*");
/*      */   }
/*      */ 
/*      */   @Inject(value="struts.convention.package.locators.basePackage", required=false)
/*      */   public void setPackageLocatorsBase(String packageLocatorsBasePackage)
/*      */   {
/*  279 */     this.packageLocatorsBasePackage = packageLocatorsBasePackage;
/*      */   }
/*      */ 
/*      */   @Inject(value="struts.convention.action.mapAllMatches", required=false)
/*      */   public void setMapAllMatches(String mapAllMatches)
/*      */   {
/*  289 */     this.mapAllMatches = "true".equals(mapAllMatches);
/*      */   }
/*      */ 
/*      */   @Inject(value="struts.convention.action.eagerLoading", required=false)
/*      */   public void setEagerLoading(String eagerLoading)
/*      */   {
/*  298 */     this.eagerLoading = "true".equals(eagerLoading);
/*      */   }
/*      */   @Inject
/*      */   public void setFileManagerFactory(FileManagerFactory fileManagerFactory) {
/*  303 */     this.fileManager = fileManagerFactory.getFileManager();
/*      */   }
/*      */ 
/*      */   protected void initReloadClassLoader()
/*      */   {
/*  308 */     if ((isReloadEnabled()) && (this.reloadingClassLoader == null))
/*  309 */       this.reloadingClassLoader = new ReloadingClassLoader(getClassLoader());
/*      */   }
/*      */ 
/*      */   protected ClassLoader getClassLoader() {
/*  313 */     return Thread.currentThread().getContextClassLoader();
/*      */   }
/*      */ 
/*      */   public void buildActionConfigs()
/*      */   {
/*  328 */     initReloadClassLoader();
/*      */ 
/*  330 */     if (!this.disableActionScanning) {
/*  331 */       if ((this.actionPackages == null) && (this.packageLocators == null)) {
/*  332 */         throw new ConfigurationException("At least a list of action packages or action package locators must be given using one of the properties [struts.convention.action.packages] or [struts.convention.package.locators]");
/*      */       }
/*      */ 
/*  337 */       if (LOG.isTraceEnabled()) {
/*  338 */         LOG.trace("Loading action configurations", new String[0]);
/*  339 */         if (this.actionPackages != null)
/*  340 */           LOG.trace("Actions being loaded from action packages " + Arrays.asList(this.actionPackages), new String[0]);
/*  341 */         if (this.packageLocators != null)
/*  342 */           LOG.trace("Actions being loaded using package locators " + Arrays.asList(this.packageLocators), new String[0]);
/*  343 */         if (this.excludePackages != null) {
/*  344 */           LOG.trace("Excluding actions from packages " + Arrays.asList(this.excludePackages), new String[0]);
/*      */         }
/*      */       }
/*  347 */       Set classes = findActions();
/*  348 */       buildConfiguration(classes);
/*      */     }
/*      */   }
/*      */ 
/*      */   protected ClassLoaderInterface getClassLoaderInterface() {
/*  353 */     if (isReloadEnabled()) {
/*  354 */       return new ClassLoaderInterfaceDelegate(this.reloadingClassLoader);
/*      */     }
/*      */ 
/*  364 */     ClassLoaderInterface classLoaderInterface = null;
/*  365 */     ActionContext ctx = ActionContext.getContext();
/*  366 */     if (ctx != null) {
/*  367 */       classLoaderInterface = (ClassLoaderInterface)ctx.get("__current_class_loader_interface");
/*      */     }
/*  369 */     return (ClassLoaderInterface)ObjectUtils.defaultIfNull(classLoaderInterface, new ClassLoaderInterfaceDelegate(getClassLoader()));
/*      */   }
/*      */ 
/*      */   protected boolean isReloadEnabled()
/*      */   {
/*  374 */     return (this.devMode) && (this.reload);
/*      */   }
/*      */ 
/*      */   protected Set<Class> findActions()
/*      */   {
/*  379 */     Set classes = new HashSet();
/*      */     try {
/*  381 */       if ((this.actionPackages != null) || ((this.packageLocators != null) && (!this.disablePackageLocatorsScanning)))
/*      */       {
/*  388 */         Test classPackageTest = getClassPackageTest();
/*  389 */         List urls = readUrls();
/*  390 */         ClassFinder finder = new ClassFinder(getClassLoaderInterface(), urls, true, this.fileProtocols, classPackageTest);
/*      */ 
/*  392 */         Test test = getActionClassTest();
/*  393 */         classes.addAll(finder.findClasses(test));
/*      */       }
/*      */     } catch (Exception ex) {
/*  396 */       if (LOG.isErrorEnabled()) {
/*  397 */         LOG.error("Unable to scan named packages", ex, new String[0]);
/*      */       }
/*      */     }
/*  400 */     return classes;
/*      */   }
/*      */ 
/*      */   private List<URL> readUrls() throws IOException {
/*  404 */     List resourceUrls = new ArrayList();
/*      */ 
/*  406 */     ArrayList classesList = Collections.list(getClassLoaderInterface().getResources(""));
/*  407 */     for (URL url : classesList) {
/*  408 */       resourceUrls.addAll(this.fileManager.getAllPhysicalUrls(url));
/*      */     }
/*  410 */     return buildUrlSet(resourceUrls).getUrls();
/*      */   }
/*      */ 
/*      */   private UrlSet buildUrlSet(List<URL> resourceUrls) throws IOException {
/*  414 */     ClassLoaderInterface classLoaderInterface = getClassLoaderInterface();
/*  415 */     UrlSet urlSet = new UrlSet(resourceUrls);
/*  416 */     urlSet = urlSet.include(new UrlSet(classLoaderInterface, this.fileProtocols));
/*      */ 
/*  419 */     if (this.excludeParentClassLoader)
/*      */     {
/*  421 */       ClassLoaderInterface parent = classLoaderInterface.getParent();
/*      */ 
/*  424 */       if ((parent != null) && (isReloadEnabled())) {
/*  425 */         parent = parent.getParent();
/*      */       }
/*  427 */       if (parent != null) {
/*  428 */         urlSet = urlSet.exclude(parent);
/*      */       }
/*      */       try
/*      */       {
/*  432 */         ClassLoader systemClassLoader = ClassLoader.getSystemClassLoader();
/*  433 */         urlSet = urlSet.exclude(new ClassLoaderInterfaceDelegate(systemClassLoader.getParent()));
/*      */       }
/*      */       catch (SecurityException e) {
/*  436 */         if (LOG.isWarnEnabled()) {
/*  437 */           LOG.warn("Could not get the system classloader due to security constraints, there may be improper urls left to scan", new String[0]);
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*  442 */     urlSet = urlSet.includeClassesUrl(classLoaderInterface, new UrlSet.FileProtocolNormalizer() {
/*      */       public URL normalizeToFileProtocol(URL url) {
/*  444 */         return PackageBasedActionConfigBuilder.this.fileManager.normalizeToFileProtocol(url);
/*      */       }
/*      */     });
/*  449 */     urlSet = urlSet.excludeJavaExtDirs();
/*  450 */     urlSet = urlSet.excludeJavaEndorsedDirs();
/*      */     try {
/*  452 */       urlSet = urlSet.excludeJavaHome();
/*      */     }
/*      */     catch (NullPointerException e) {
/*  455 */       if (LOG.isWarnEnabled())
/*  456 */         LOG.warn("Could not exclude JAVA_HOME, is this a sandbox jvm?", new String[0]);
/*      */     }
/*  458 */     urlSet = urlSet.excludePaths(System.getProperty("sun.boot.class.path", ""));
/*  459 */     urlSet = urlSet.exclude(".*/JavaVM.framework/.*");
/*      */ 
/*  461 */     if (this.includeJars == null) {
/*  462 */       urlSet = urlSet.exclude(".*?\\.jar(!/|/)?");
/*      */     }
/*      */     else {
/*  465 */       List rawIncludedUrls = urlSet.getUrls();
/*  466 */       Set includeUrls = new HashSet();
/*  467 */       boolean[] patternUsed = new boolean[this.includeJars.length];
/*      */ 
/*  469 */       for (URL url : rawIncludedUrls) {
/*  470 */         if (this.fileProtocols.contains(url.getProtocol()))
/*      */         {
/*  472 */           for (int i = 0; i < this.includeJars.length; i++) {
/*  473 */             String includeJar = this.includeJars[i];
/*  474 */             if (Pattern.matches(includeJar, url.toExternalForm())) {
/*  475 */               includeUrls.add(url);
/*  476 */               patternUsed[i] = true;
/*  477 */               break;
/*      */             }
/*      */           }
/*      */         }
/*      */         else {
/*  482 */           includeUrls.add(url);
/*      */         }
/*      */       }
/*      */ 
/*  486 */       if (LOG.isWarnEnabled()) {
/*  487 */         for (int i = 0; i < patternUsed.length; i++) {
/*  488 */           if (patternUsed[i] == 0) {
/*  489 */             LOG.warn("The includeJars pattern [#0] did not match any jars in the classpath", new String[] { this.includeJars[i] });
/*      */           }
/*      */         }
/*      */       }
/*  493 */       return new UrlSet(includeUrls);
/*      */     }
/*      */ 
/*  496 */     return urlSet;
/*      */   }
/*      */ 
/*      */   protected boolean includeClassNameInActionScan(String className)
/*      */   {
/*  513 */     String classPackageName = StringUtils.substringBeforeLast(className, ".");
/*  514 */     return ((checkActionPackages(classPackageName)) || (checkPackageLocators(classPackageName))) && (checkExcludePackages(classPackageName));
/*      */   }
/*      */ 
/*      */   protected boolean checkExcludePackages(String classPackageName)
/*      */   {
/*  524 */     if ((this.excludePackages != null) && (this.excludePackages.length > 0)) {
/*  525 */       WildcardHelper wildcardHelper = new WildcardHelper();
/*      */ 
/*  528 */       Map matchMap = new HashMap();
/*      */ 
/*  530 */       for (String packageExclude : this.excludePackages) {
/*  531 */         int[] packagePattern = wildcardHelper.compilePattern(packageExclude);
/*  532 */         if (wildcardHelper.match(matchMap, classPackageName, packagePattern)) {
/*  533 */           return false;
/*      */         }
/*      */       }
/*      */     }
/*  537 */     return true;
/*      */   }
/*      */ 
/*      */   protected boolean checkActionPackages(String classPackageName)
/*      */   {
/*  547 */     if (this.actionPackages != null)
/*  548 */       for (String packageName : this.actionPackages) {
/*  549 */         String strictPackageName = packageName + ".";
/*  550 */         if ((classPackageName.equals(packageName)) || (classPackageName.startsWith(strictPackageName)))
/*      */         {
/*  552 */           return true;
/*      */         }
/*      */       }
/*  555 */     return false;
/*      */   }
/*      */ 
/*      */   protected boolean checkPackageLocators(String classPackageName)
/*      */   {
/*  565 */     if ((this.packageLocators != null) && (!this.disablePackageLocatorsScanning) && (classPackageName.length() > 0) && ((this.packageLocatorsBasePackage == null) || (classPackageName.startsWith(this.packageLocatorsBasePackage))))
/*      */     {
/*  568 */       for (String packageLocator : this.packageLocators) {
/*  569 */         String[] splitted = classPackageName.split("\\.");
/*      */ 
/*  571 */         if (StringTools.contains(splitted, packageLocator, false))
/*  572 */           return true;
/*      */       }
/*      */     }
/*  575 */     return false;
/*      */   }
/*      */ 
/*      */   protected Test<String> getClassPackageTest()
/*      */   {
/*  589 */     return new Test() {
/*      */       public boolean test(String className) {
/*  591 */         return PackageBasedActionConfigBuilder.this.includeClassNameInActionScan(className);
/*      */       }
/*      */     };
/*      */   }
/*      */ 
/*      */   protected Test<ClassFinder.ClassInfo> getActionClassTest()
/*      */   {
/*  607 */     return new Test()
/*      */     {
/*      */       public boolean test(ClassFinder.ClassInfo classInfo)
/*      */       {
/*  616 */         boolean inPackage = PackageBasedActionConfigBuilder.this.includeClassNameInActionScan(classInfo.getName());
/*  617 */         boolean nameMatches = classInfo.getName().endsWith(PackageBasedActionConfigBuilder.this.actionSuffix);
/*      */         try
/*      */         {
/*  620 */           return (inPackage) && ((nameMatches) || ((PackageBasedActionConfigBuilder.this.checkImplementsAction) && (com.opensymphony.xwork2.Action.class.isAssignableFrom(classInfo.get()))));
/*      */         } catch (ClassNotFoundException ex) {
/*  622 */           if (PackageBasedActionConfigBuilder.LOG.isErrorEnabled())
/*  623 */             PackageBasedActionConfigBuilder.LOG.error("Unable to load class [#0]", ex, new String[] { classInfo.getName() }); 
/*      */         }
/*  624 */         return false;
/*      */       }
/*      */     };
/*      */   }
/*      */ 
/*      */   protected void buildConfiguration(Set<Class> classes)
/*      */   {
/*  632 */     Map packageConfigs = new HashMap();
/*      */ 
/*  634 */     for (Iterator i$ = classes.iterator(); i$.hasNext(); ) { actionClass = (Class)i$.next();
/*  635 */       actionsAnnotation = (Actions)actionClass.getAnnotation(Actions.class);
/*  636 */       actionAnnotation = (org.apache.struts2.convention.annotation.Action)actionClass.getAnnotation(org.apache.struts2.convention.annotation.Action.class);
/*      */ 
/*  639 */       if (cannotInstantiate(actionClass)) {
/*  640 */         if (LOG.isTraceEnabled()) {
/*  641 */           LOG.trace("Class [#0] did not pass the instantiation test and will be ignored", new String[] { actionClass.getName() }); continue;
/*      */         }
/*      */       }
/*      */ 
/*  645 */       if (this.eagerLoading) {
/*      */         try
/*      */         {
/*  648 */           this.objectFactory.getClassInstance(actionClass.getName());
/*      */         } catch (ClassNotFoundException e) {
/*  650 */           if (LOG.isErrorEnabled())
/*  651 */             LOG.error("Object Factory was unable to load class [#0]", e, new String[] { actionClass.getName() });
/*  652 */           throw new StrutsException("Object Factory was unable to load class " + actionClass.getName(), e);
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  657 */       actionPackage = actionClass.getPackage().getName();
/*  658 */       if (LOG.isDebugEnabled()) {
/*  659 */         LOG.debug("Processing class [#0] in package [#1]", new String[] { actionClass.getName(), actionPackage });
/*      */       }
/*      */ 
/*  663 */       List namespaces = determineActionNamespace(actionClass);
/*  664 */       for (String namespace : namespaces) {
/*  665 */         String defaultActionName = determineActionName(actionClass);
/*  666 */         PackageConfig.Builder defaultPackageConfig = getPackageConfig(packageConfigs, namespace, actionPackage, actionClass, null);
/*      */ 
/*  671 */         Map map = getActionAnnotations(actionClass);
/*  672 */         Set actionNames = new HashSet();
/*  673 */         boolean hasDefaultMethod = ReflectionTools.containsMethod(actionClass, "execute", new Class[0]);
/*  674 */         if ((!map.containsKey("execute")) && (hasDefaultMethod) && (actionAnnotation == null) && (actionsAnnotation == null) && ((this.alwaysMapExecute) || (map.isEmpty())))
/*      */         {
/*  678 */           boolean found = false;
/*  679 */           for (String method : map.keySet()) {
/*  680 */             List actions = (List)map.get(method);
/*  681 */             for (org.apache.struts2.convention.annotation.Action action : actions)
/*      */             {
/*  684 */               String actionName = action.value().equals("DEFAULT_VALUE") ? defaultActionName : action.value();
/*  685 */               if (actionNames.contains(actionName)) {
/*  686 */                 throw new ConfigurationException("The action class [" + actionClass + "] contains two methods with an action name annotation whose value " + "is the same (they both might be empty as well).");
/*      */               }
/*      */ 
/*  690 */               actionNames.add(actionName);
/*      */ 
/*  694 */               if (action.value().equals("DEFAULT_VALUE")) {
/*  695 */                 found = true;
/*      */               }
/*      */             }
/*      */ 
/*      */           }
/*      */ 
/*  701 */           if (!found) {
/*  702 */             createActionConfig(defaultPackageConfig, actionClass, defaultActionName, "execute", null);
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/*  707 */         for (Iterator i$ = map.keySet().iterator(); i$.hasNext(); ) { method = (String)i$.next();
/*  708 */           List actions = (List)map.get(method);
/*  709 */           for (org.apache.struts2.convention.annotation.Action action : actions) {
/*  710 */             PackageConfig.Builder pkgCfg = defaultPackageConfig;
/*  711 */             if ((action.value().contains("/")) && (!this.slashesInActionNames)) {
/*  712 */               pkgCfg = getPackageConfig(packageConfigs, namespace, actionPackage, actionClass, action);
/*      */             }
/*      */ 
/*  716 */             createActionConfig(pkgCfg, actionClass, defaultActionName, method, action);
/*      */           }
/*      */         }
/*      */         String method;
/*  722 */         if ((map.isEmpty()) && (this.mapAllMatches) && (actionAnnotation == null) && (actionsAnnotation == null)) {
/*  723 */           createActionConfig(defaultPackageConfig, actionClass, defaultActionName, null, actionAnnotation);
/*      */         }
/*      */ 
/*  727 */         String methodName = hasDefaultMethod ? "execute" : null;
/*  728 */         if (actionsAnnotation != null) {
/*  729 */           List actionAnnotations = checkActionsAnnotation(actionsAnnotation);
/*  730 */           for (org.apache.struts2.convention.annotation.Action actionAnnotation2 : actionAnnotations)
/*  731 */             createActionConfig(defaultPackageConfig, actionClass, defaultActionName, methodName, actionAnnotation2);
/*  732 */         } else if (actionAnnotation != null) {
/*  733 */           createActionConfig(defaultPackageConfig, actionClass, defaultActionName, methodName, actionAnnotation);
/*      */         }
/*      */       }
/*      */     }
/*      */     Class actionClass;
/*      */     Actions actionsAnnotation;
/*      */     org.apache.struts2.convention.annotation.Action actionAnnotation;
/*      */     String actionPackage;
/*  737 */     buildIndexActions(packageConfigs);
/*      */ 
/*  740 */     Set packageNames = packageConfigs.keySet();
/*  741 */     for (String packageName : packageNames)
/*  742 */       this.configuration.addPackageConfig(packageName, ((PackageConfig.Builder)packageConfigs.get(packageName)).build());
/*      */   }
/*      */ 
/*      */   protected boolean cannotInstantiate(Class<?> actionClass)
/*      */   {
/*  752 */     return (actionClass.isAnnotation()) || (actionClass.isInterface()) || (actionClass.isEnum()) || ((actionClass.getModifiers() & 0x400) != 0) || (actionClass.isAnonymousClass());
/*      */   }
/*      */ 
/*      */   protected List<String> determineActionNamespace(Class<?> actionClass)
/*      */   {
/*  768 */     List namespaces = new ArrayList();
/*      */ 
/*  772 */     Namespace namespaceAnnotation = (Namespace)AnnotationUtils.findAnnotation(actionClass, Namespace.class);
/*  773 */     if (namespaceAnnotation != null) {
/*  774 */       if (LOG.isTraceEnabled()) {
/*  775 */         LOG.trace("Using non-default action namespace from Namespace annotation of [#0]", new String[] { namespaceAnnotation.value() });
/*      */       }
/*      */ 
/*  778 */       namespaces.add(namespaceAnnotation.value());
/*      */     }
/*      */ 
/*  782 */     Namespaces namespacesAnnotation = (Namespaces)AnnotationUtils.findAnnotation(actionClass, Namespaces.class);
/*  783 */     if (namespacesAnnotation != null) {
/*  784 */       if (LOG.isTraceEnabled()) {
/*  785 */         StringBuilder sb = new StringBuilder();
/*  786 */         for (Namespace namespace : namespacesAnnotation.value())
/*  787 */           sb.append(namespace.value()).append(",");
/*  788 */         sb.deleteCharAt(sb.length() - 1);
/*  789 */         LOG.trace("Using non-default action namespaces from Namespaces annotation of [#0]", new String[] { sb.toString() });
/*      */       }
/*      */ 
/*  792 */       for (Namespace namespace : namespacesAnnotation.value()) {
/*  793 */         namespaces.add(namespace.value());
/*      */       }
/*      */     }
/*      */ 
/*  797 */     if (!namespaces.isEmpty()) {
/*  798 */       return namespaces;
/*      */     }
/*  800 */     String pkg = actionClass.getPackage().getName();
/*  801 */     String pkgPart = null;
/*  802 */     if (this.actionPackages != null) {
/*  803 */       for (String actionPackage : this.actionPackages) {
/*  804 */         if (pkg.startsWith(actionPackage)) {
/*  805 */           pkgPart = actionClass.getName().substring(actionPackage.length() + 1);
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*  810 */     if ((pkgPart == null) && (this.packageLocators != null)) {
/*  811 */       for (String packageLocator : this.packageLocators)
/*      */       {
/*  813 */         int index = pkg.lastIndexOf("." + packageLocator + ".");
/*      */ 
/*  816 */         if ((index < 0) || ((index + packageLocator.length() != pkg.length()) && (index != 0) && ((pkg.charAt(index) != '.') || (pkg.charAt(index + 1 + packageLocator.length()) != '.'))))
/*      */           continue;
/*  818 */         pkgPart = actionClass.getName().substring(index + packageLocator.length() + 2);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  823 */     if (pkgPart != null) {
/*  824 */       int indexOfDot = pkgPart.lastIndexOf('.');
/*  825 */       if (indexOfDot >= 0) {
/*  826 */         String convertedNamespace = this.actionNameBuilder.build(pkgPart.substring(0, indexOfDot));
/*  827 */         namespaces.add("/" + convertedNamespace.replace('.', '/'));
/*  828 */         return namespaces;
/*      */       }
/*      */     }
/*      */ 
/*  832 */     namespaces.add("");
/*  833 */     return namespaces;
/*      */   }
/*      */ 
/*      */   protected String determineActionName(Class<?> actionClass)
/*      */   {
/*  843 */     String actionName = this.actionNameBuilder.build(actionClass.getSimpleName());
/*  844 */     if (LOG.isTraceEnabled()) {
/*  845 */       LOG.trace("Got actionName for class [#0] of [#1]", new String[] { actionClass.toString(), actionName });
/*      */     }
/*      */ 
/*  848 */     return actionName;
/*      */   }
/*      */ 
/*      */   protected Map<String, List<org.apache.struts2.convention.annotation.Action>> getActionAnnotations(Class<?> actionClass)
/*      */   {
/*  859 */     Method[] methods = actionClass.getMethods();
/*  860 */     Map map = new HashMap();
/*  861 */     for (Method method : methods) {
/*  862 */       Actions actionsAnnotation = (Actions)method.getAnnotation(Actions.class);
/*  863 */       if (actionsAnnotation != null) {
/*  864 */         List actions = checkActionsAnnotation(actionsAnnotation);
/*  865 */         map.put(method.getName(), actions);
/*      */       } else {
/*  867 */         org.apache.struts2.convention.annotation.Action ann = (org.apache.struts2.convention.annotation.Action)method.getAnnotation(org.apache.struts2.convention.annotation.Action.class);
/*  868 */         if (ann != null) {
/*  869 */           map.put(method.getName(), Arrays.asList(new org.apache.struts2.convention.annotation.Action[] { ann }));
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*  874 */     return map;
/*      */   }
/*      */ 
/*      */   protected List<org.apache.struts2.convention.annotation.Action> checkActionsAnnotation(Actions actionsAnnotation)
/*      */   {
/*  883 */     org.apache.struts2.convention.annotation.Action[] actionArray = actionsAnnotation.value();
/*  884 */     boolean valuelessSeen = false;
/*  885 */     List actions = new ArrayList();
/*  886 */     for (org.apache.struts2.convention.annotation.Action ann : actionArray) {
/*  887 */       if ((ann.value().equals("DEFAULT_VALUE")) && (!valuelessSeen))
/*  888 */         valuelessSeen = true;
/*  889 */       else if (ann.value().equals("DEFAULT_VALUE")) {
/*  890 */         throw new ConfigurationException("You may only add a single Action annotation that has no value parameter.");
/*      */       }
/*      */ 
/*  894 */       actions.add(ann);
/*      */     }
/*  896 */     return actions;
/*      */   }
/*      */ 
/*      */   protected void createActionConfig(PackageConfig.Builder pkgCfg, Class<?> actionClass, String actionName, String actionMethod, org.apache.struts2.convention.annotation.Action annotation)
/*      */   {
/*  911 */     String className = actionClass.getName();
/*  912 */     if (annotation != null) {
/*  913 */       actionName = (annotation.value() != null) && (annotation.value().equals("DEFAULT_VALUE")) ? actionName : annotation.value();
/*  914 */       actionName = (StringUtils.contains(actionName, "/")) && (!this.slashesInActionNames) ? StringUtils.substringAfterLast(actionName, "/") : actionName;
/*  915 */       if (!"DEFAULT_VALUE".equals(annotation.className())) {
/*  916 */         className = annotation.className();
/*      */       }
/*      */     }
/*      */ 
/*  920 */     ActionConfig.Builder actionConfig = new ActionConfig.Builder(pkgCfg.getName(), actionName, className);
/*  921 */     actionConfig.methodName(actionMethod);
/*      */ 
/*  923 */     if (LOG.isDebugEnabled()) {
/*  924 */       LOG.debug("Creating action config for class [#0], name [#1] and package name [#2] in namespace [#3]", new String[] { actionClass.toString(), actionName, pkgCfg.getName(), pkgCfg.getNamespace() });
/*      */     }
/*      */ 
/*  929 */     List interceptors = this.interceptorMapBuilder.build(actionClass, pkgCfg, actionName, annotation);
/*  930 */     actionConfig.addInterceptors(interceptors);
/*      */ 
/*  933 */     Map results = this.resultMapBuilder.build(actionClass, annotation, actionName, pkgCfg.build());
/*  934 */     actionConfig.addResultConfigs(results);
/*      */ 
/*  937 */     if (annotation != null) {
/*  938 */       actionConfig.addParams(StringTools.createParameterMap(annotation.params()));
/*      */     }
/*      */ 
/*  941 */     if ((annotation != null) && (annotation.exceptionMappings() != null)) {
/*  942 */       actionConfig.addExceptionMappings(buildExceptionMappings(annotation.exceptionMappings(), actionName));
/*      */     }
/*      */ 
/*  945 */     ExceptionMappings exceptionMappings = (ExceptionMappings)actionClass.getAnnotation(ExceptionMappings.class);
/*  946 */     if (exceptionMappings != null) {
/*  947 */       actionConfig.addExceptionMappings(buildExceptionMappings(exceptionMappings.value(), actionName));
/*      */     }
/*      */ 
/*  950 */     pkgCfg.addActionConfig(actionName, actionConfig.build());
/*      */ 
/*  953 */     PackageConfig existingPkg = this.configuration.getPackageConfig(pkgCfg.getName());
/*  954 */     if (existingPkg != null)
/*      */     {
/*  956 */       ActionConfig existingActionConfig = (ActionConfig)existingPkg.getActionConfigs().get(actionName);
/*  957 */       if ((existingActionConfig != null) && (LOG.isWarnEnabled())) {
/*  958 */         LOG.warn("Duplicated action definition in package [#0] with name [#1].", new String[] { pkgCfg.getName(), actionName });
/*      */       }
/*      */     }
/*      */ 
/*  962 */     if (isReloadEnabled()) {
/*  963 */       URL classFile = actionClass.getResource(actionClass.getSimpleName() + ".class");
/*  964 */       this.fileManager.monitorFile(classFile);
/*  965 */       this.loadedFileUrls.add(classFile.toString());
/*      */     }
/*      */   }
/*      */ 
/*      */   protected List<ExceptionMappingConfig> buildExceptionMappings(ExceptionMapping[] exceptions, String actionName) {
/*  970 */     List exceptionMappings = new ArrayList();
/*      */ 
/*  972 */     for (ExceptionMapping exceptionMapping : exceptions) {
/*  973 */       if (LOG.isTraceEnabled()) {
/*  974 */         LOG.trace("Mapping exception [#0] to result [#1] for action [#2]", new String[] { exceptionMapping.exception(), exceptionMapping.result(), actionName });
/*      */       }
/*  976 */       ExceptionMappingConfig.Builder builder = new ExceptionMappingConfig.Builder(null, exceptionMapping.exception(), exceptionMapping.result());
/*      */ 
/*  978 */       if (exceptionMapping.params() != null)
/*  979 */         builder.addParams(StringTools.createParameterMap(exceptionMapping.params()));
/*  980 */       exceptionMappings.add(builder.build());
/*      */     }
/*      */ 
/*  983 */     return exceptionMappings;
/*      */   }
/*      */ 
/*      */   protected PackageConfig.Builder getPackageConfig(Map<String, PackageConfig.Builder> packageConfigs, String actionNamespace, String actionPackage, Class<?> actionClass, org.apache.struts2.convention.annotation.Action action)
/*      */   {
/*  989 */     if ((action != null) && (!action.value().equals("DEFAULT_VALUE"))) {
/*  990 */       if (LOG.isTraceEnabled()) {
/*  991 */         LOG.trace("Using non-default action namespace from the Action annotation of [#0]", new String[] { action.value() });
/*      */       }
/*  993 */       String actionName = action.value();
/*  994 */       actionNamespace = StringUtils.contains(actionName, "/") ? StringUtils.substringBeforeLast(actionName, "/") : "";
/*      */     }
/*      */ 
/*  998 */     ParentPackage parent = (ParentPackage)AnnotationUtils.findAnnotation(actionClass, ParentPackage.class);
/*  999 */     String parentName = null;
/* 1000 */     if (parent != null) {
/* 1001 */       if (LOG.isTraceEnabled()) {
/* 1002 */         LOG.trace("Using non-default parent package from annotation of [#0]", new String[] { parent.value() });
/*      */       }
/*      */ 
/* 1005 */       parentName = parent.value();
/*      */     }
/*      */ 
/* 1009 */     if (parentName == null) {
/* 1010 */       parentName = this.defaultParentPackage;
/*      */     }
/*      */ 
/* 1013 */     if (parentName == null) {
/* 1014 */       throw new ConfigurationException("Unable to determine the parent XWork package for the action class [" + actionClass.getName() + "]");
/*      */     }
/*      */ 
/* 1018 */     PackageConfig parentPkg = this.configuration.getPackageConfig(parentName);
/* 1019 */     if (parentPkg == null) {
/* 1020 */       throw new ConfigurationException("Unable to locate parent package [" + parentName + "] for [" + actionClass + "]");
/*      */     }
/*      */ 
/* 1025 */     String name = actionPackage + "#" + parentPkg.getName() + "#" + actionNamespace;
/* 1026 */     PackageConfig.Builder pkgConfig = (PackageConfig.Builder)packageConfigs.get(name);
/* 1027 */     if (pkgConfig == null) {
/* 1028 */       pkgConfig = new PackageConfig.Builder(name).namespace(actionNamespace).addParent(parentPkg);
/* 1029 */       packageConfigs.put(name, pkgConfig);
/*      */ 
/* 1032 */       DefaultInterceptorRef defaultInterceptorRef = (DefaultInterceptorRef)AnnotationUtils.findAnnotation(actionClass, DefaultInterceptorRef.class);
/* 1033 */       if (defaultInterceptorRef != null) {
/* 1034 */         pkgConfig.defaultInterceptorRef(defaultInterceptorRef.value());
/*      */ 
/* 1036 */         if (LOG.isTraceEnabled()) {
/* 1037 */           LOG.trace("Setting [#0] as the default interceptor ref for [#1]", new String[] { defaultInterceptorRef.value(), pkgConfig.getName() });
/*      */         }
/*      */       }
/*      */     }
/* 1041 */     if (LOG.isTraceEnabled()) {
/* 1042 */       LOG.trace("Created package config named [#0] with a namespace [#1]", new String[] { name, actionNamespace });
/*      */     }
/*      */ 
/* 1045 */     return pkgConfig;
/*      */   }
/*      */ 
/*      */   protected void buildIndexActions(Map<String, PackageConfig.Builder> packageConfigs)
/*      */   {
/* 1061 */     Map byNamespace = new HashMap();
/* 1062 */     Collection values = packageConfigs.values();
/* 1063 */     for (PackageConfig.Builder packageConfig : values) {
/* 1064 */       byNamespace.put(packageConfig.getNamespace(), packageConfig);
/*      */     }
/*      */ 
/* 1068 */     Set namespaces = byNamespace.keySet();
/* 1069 */     for (String namespace : namespaces)
/*      */     {
/* 1071 */       PackageConfig.Builder pkgConfig = (PackageConfig.Builder)byNamespace.get(namespace);
/* 1072 */       ActionConfig indexActionConfig = (ActionConfig)pkgConfig.build().getAllActionConfigs().get("index");
/* 1073 */       if (indexActionConfig == null)
/*      */       {
/*      */         continue;
/*      */       }
/*      */ 
/* 1078 */       if (!this.redirectToSlash) {
/* 1079 */         int lastSlash = namespace.lastIndexOf('/');
/* 1080 */         if (lastSlash >= 0) {
/* 1081 */           String parentAction = namespace.substring(lastSlash + 1);
/* 1082 */           String parentNamespace = namespace.substring(0, lastSlash);
/* 1083 */           PackageConfig.Builder parent = (PackageConfig.Builder)byNamespace.get(parentNamespace);
/* 1084 */           if ((parent == null) || (parent.build().getAllActionConfigs().get(parentAction) == null)) {
/* 1085 */             if (parent == null) {
/* 1086 */               parent = new PackageConfig.Builder(parentNamespace).namespace(parentNamespace).addParents(pkgConfig.build().getParents());
/*      */ 
/* 1088 */               packageConfigs.put(parentNamespace, parent);
/*      */             }
/*      */ 
/* 1091 */             if (parent.build().getAllActionConfigs().get(parentAction) == null)
/* 1092 */               parent.addActionConfig(parentAction, indexActionConfig);
/*      */           }
/* 1094 */           else if (LOG.isTraceEnabled()) {
/* 1095 */             LOG.trace("The parent namespace [#0] already contains an action [#1]", new String[] { parentNamespace, parentAction });
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1102 */       if (pkgConfig.build().getAllActionConfigs().get("") == null) {
/* 1103 */         if (LOG.isTraceEnabled()) {
/* 1104 */           LOG.trace("Creating index ActionConfig with an action name of [] for the action class [#0]", new String[] { indexActionConfig.getClassName() });
/*      */         }
/*      */ 
/* 1108 */         pkgConfig.addActionConfig("", indexActionConfig);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public void destroy() {
/* 1114 */     this.loadedFileUrls.clear();
/*      */   }
/*      */ 
/*      */   public boolean needsReload() {
/* 1118 */     if ((this.devMode) && (this.reload)) {
/* 1119 */       for (String url : this.loadedFileUrls) {
/* 1120 */         if (this.fileManager.fileNeedsReloading(url)) {
/* 1121 */           if (LOG.isDebugEnabled())
/* 1122 */             LOG.debug("File [#0] changed, configuration will be reloaded", new String[] { url });
/* 1123 */           return true;
/*      */         }
/*      */       }
/*      */ 
/* 1127 */       return false;
/*      */     }
/* 1129 */     return false;
/*      */   }
/*      */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-convention-plugin-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.convention.PackageBasedActionConfigBuilder
 * JD-Core Version:    0.6.0
 */