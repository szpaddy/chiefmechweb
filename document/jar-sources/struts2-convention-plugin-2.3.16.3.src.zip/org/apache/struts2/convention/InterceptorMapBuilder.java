package org.apache.struts2.convention;

import com.opensymphony.xwork2.config.entities.InterceptorMapping;
import com.opensymphony.xwork2.config.entities.PackageConfig.Builder;
import java.util.List;
import org.apache.struts2.convention.annotation.Action;

public abstract interface InterceptorMapBuilder
{
  public abstract List<InterceptorMapping> build(Class<?> paramClass, PackageConfig.Builder paramBuilder, String paramString, Action paramAction);
}

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-convention-plugin-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.convention.InterceptorMapBuilder
 * JD-Core Version:    0.6.0
 */