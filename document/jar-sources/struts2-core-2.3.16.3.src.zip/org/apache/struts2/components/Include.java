/*     */ package org.apache.struts2.components;
/*     */ 
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import com.opensymphony.xwork2.util.logging.Logger;
/*     */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.Writer;
/*     */ import java.net.URLEncoder;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.Stack;
/*     */ import java.util.StringTokenizer;
/*     */ import javax.servlet.RequestDispatcher;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.ServletOutputStream;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.servlet.http.HttpServletResponseWrapper;
/*     */ import org.apache.struts2.RequestUtils;
/*     */ import org.apache.struts2.util.FastByteArrayOutputStream;
/*     */ import org.apache.struts2.views.annotations.StrutsTag;
/*     */ import org.apache.struts2.views.annotations.StrutsTagAttribute;
/*     */ 
/*     */ @StrutsTag(name="include", tldTagClass="org.apache.struts2.views.jsp.IncludeTag", description="Include a servlet's output (result of servlet or a JSP page)")
/*     */ public class Include extends Component
/*     */ {
/* 104 */   private static final Logger LOG = LoggerFactory.getLogger(Include.class);
/*     */ 
/* 106 */   private static String systemEncoding = System.getProperty("file.encoding");
/*     */   protected String value;
/*     */   private HttpServletRequest req;
/*     */   private HttpServletResponse res;
/*     */   private static String defaultEncoding;
/*     */ 
/*     */   public Include(ValueStack stack, HttpServletRequest req, HttpServletResponse res)
/*     */   {
/* 114 */     super(stack);
/* 115 */     this.req = req;
/* 116 */     this.res = res;
/*     */   }
/*     */   @Inject("struts.i18n.encoding")
/*     */   public void setDefaultEncoding(String encoding) {
/* 121 */     defaultEncoding = encoding;
/*     */   }
/*     */ 
/*     */   public boolean end(Writer writer, String body) {
/* 125 */     String page = findString(this.value, "value", "You must specify the URL to include. Example: /foo.jsp");
/* 126 */     StringBuilder urlBuf = new StringBuilder();
/*     */ 
/* 129 */     urlBuf.append(page);
/*     */ 
/* 132 */     if (this.parameters.size() > 0) {
/* 133 */       urlBuf.append('?');
/*     */ 
/* 135 */       String concat = "";
/*     */ 
/* 138 */       Iterator iter = this.parameters.entrySet().iterator();
/*     */ 
/* 140 */       while (iter.hasNext()) {
/* 141 */         Map.Entry entry = (Map.Entry)iter.next();
/* 142 */         Object name = entry.getKey();
/* 143 */         List values = (List)entry.getValue();
/*     */ 
/* 145 */         for (int i = 0; i < values.size(); i++) {
/* 146 */           urlBuf.append(concat);
/* 147 */           urlBuf.append(name);
/* 148 */           urlBuf.append('=');
/*     */           try
/*     */           {
/* 151 */             urlBuf.append(URLEncoder.encode(values.get(i).toString(), "UTF-8"));
/*     */           } catch (Exception e) {
/* 153 */             if (LOG.isWarnEnabled()) {
/* 154 */               LOG.warn("unable to url-encode " + values.get(i).toString() + ", it will be ignored", new String[0]);
/*     */             }
/*     */           }
/*     */ 
/* 158 */           concat = "&";
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 163 */     String result = urlBuf.toString();
/*     */     try
/*     */     {
/* 167 */       include(result, writer, this.req, this.res, defaultEncoding);
/*     */     } catch (Exception e) {
/* 169 */       if (LOG.isWarnEnabled()) {
/* 170 */         LOG.warn("Exception thrown during include of " + result, e, new String[0]);
/*     */       }
/*     */     }
/*     */ 
/* 174 */     return super.end(writer, body);
/*     */   }
/*     */   @StrutsTagAttribute(description="The jsp/servlet output to include", required=true)
/*     */   public void setValue(String value) {
/* 179 */     this.value = value;
/*     */   }
/*     */ 
/*     */   public static String getContextRelativePath(ServletRequest request, String relativePath)
/*     */   {
/*     */     String returnValue;
/*     */     String returnValue;
/* 185 */     if (relativePath.startsWith("/")) {
/* 186 */       returnValue = relativePath;
/*     */     }
/*     */     else
/*     */     {
/*     */       String returnValue;
/* 187 */       if (!(request instanceof HttpServletRequest)) {
/* 188 */         returnValue = relativePath;
/*     */       } else {
/* 190 */         HttpServletRequest hrequest = (HttpServletRequest)request;
/* 191 */         String uri = (String)request.getAttribute("javax.servlet.include.servlet_path");
/*     */ 
/* 193 */         if (uri == null) {
/* 194 */           uri = RequestUtils.getServletPath(hrequest);
/*     */         }
/*     */ 
/* 197 */         returnValue = uri.substring(0, uri.lastIndexOf('/')) + '/' + relativePath;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 202 */     if (returnValue.indexOf("..") != -1) {
/* 203 */       Stack stack = new Stack();
/* 204 */       StringTokenizer pathParts = new StringTokenizer(returnValue.replace('\\', '/'), "/");
/*     */ 
/* 206 */       while (pathParts.hasMoreTokens()) {
/* 207 */         String part = pathParts.nextToken();
/*     */ 
/* 209 */         if (!part.equals(".")) {
/* 210 */           if (part.equals(".."))
/* 211 */             stack.pop();
/*     */           else {
/* 213 */             stack.push(part);
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/* 218 */       StringBuilder flatPathBuffer = new StringBuilder();
/*     */ 
/* 220 */       for (int i = 0; i < stack.size(); i++) {
/* 221 */         flatPathBuffer.append("/").append(stack.elementAt(i));
/*     */       }
/*     */ 
/* 224 */       returnValue = flatPathBuffer.toString();
/*     */     }
/*     */ 
/* 227 */     return returnValue;
/*     */   }
/*     */ 
/*     */   public void addParameter(String key, Object value)
/*     */   {
/* 234 */     if (value != null) {
/* 235 */       List currentValues = (List)this.parameters.get(key);
/*     */ 
/* 237 */       if (currentValues == null) {
/* 238 */         currentValues = new ArrayList();
/* 239 */         this.parameters.put(key, currentValues);
/*     */       }
/*     */ 
/* 242 */       currentValues.add(value);
/*     */     }
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public static void include(String relativePath, Writer writer, ServletRequest request, HttpServletResponse response)
/*     */     throws ServletException, IOException
/*     */   {
/* 252 */     include(relativePath, writer, request, response, null);
/*     */   }
/*     */ 
/*     */   public static void include(String relativePath, Writer writer, ServletRequest request, HttpServletResponse response, String encoding)
/*     */     throws ServletException, IOException
/*     */   {
/* 271 */     String resourcePath = getContextRelativePath(request, relativePath);
/* 272 */     RequestDispatcher rd = request.getRequestDispatcher(resourcePath);
/*     */ 
/* 274 */     if (rd == null) {
/* 275 */       throw new ServletException("Not a valid resource path:" + resourcePath);
/*     */     }
/*     */ 
/* 278 */     PageResponse pageResponse = new PageResponse(response);
/*     */ 
/* 281 */     rd.include(request, pageResponse);
/*     */ 
/* 283 */     if (encoding != null)
/*     */     {
/* 285 */       pageResponse.getContent().writeTo(writer, encoding);
/*     */     }
/*     */     else
/* 288 */       pageResponse.getContent().writeTo(writer, systemEncoding);
/*     */   }
/*     */ 
/*     */   static final class PageResponse extends HttpServletResponseWrapper
/*     */   {
/*     */     protected PrintWriter pagePrintWriter;
/*     */     protected ServletOutputStream outputStream;
/* 358 */     private Include.PageOutputStream pageOutputStream = null;
/*     */ 
/*     */     public PageResponse(HttpServletResponse response)
/*     */     {
/* 365 */       super();
/*     */     }
/*     */ 
/*     */     public FastByteArrayOutputStream getContent()
/*     */       throws IOException
/*     */     {
/* 379 */       if (this.pagePrintWriter != null) {
/* 380 */         this.pagePrintWriter.flush();
/*     */       }
/*     */ 
/* 383 */       return ((Include.PageOutputStream)getOutputStream()).getBuffer();
/*     */     }
/*     */ 
/*     */     public ServletOutputStream getOutputStream()
/*     */       throws IOException
/*     */     {
/* 391 */       if (this.pageOutputStream == null) {
/* 392 */         this.pageOutputStream = new Include.PageOutputStream();
/*     */       }
/*     */ 
/* 395 */       return this.pageOutputStream;
/*     */     }
/*     */ 
/*     */     public PrintWriter getWriter()
/*     */       throws IOException
/*     */     {
/* 402 */       if (this.pagePrintWriter == null) {
/* 403 */         this.pagePrintWriter = new PrintWriter(new OutputStreamWriter(getOutputStream(), getCharacterEncoding()));
/*     */       }
/*     */ 
/* 406 */       return this.pagePrintWriter;
/*     */     }
/*     */   }
/*     */ 
/*     */   static final class PageOutputStream extends ServletOutputStream
/*     */   {
/*     */     private FastByteArrayOutputStream buffer;
/*     */ 
/*     */     public PageOutputStream()
/*     */     {
/* 305 */       this.buffer = new FastByteArrayOutputStream();
/*     */     }
/*     */ 
/*     */     public FastByteArrayOutputStream getBuffer()
/*     */       throws IOException
/*     */     {
/* 313 */       flush();
/*     */ 
/* 315 */       return this.buffer;
/*     */     }
/*     */ 
/*     */     public void close() throws IOException {
/* 319 */       this.buffer.close();
/*     */     }
/*     */ 
/*     */     public void flush() throws IOException {
/* 323 */       this.buffer.flush();
/*     */     }
/*     */ 
/*     */     public void write(byte[] b, int o, int l) throws IOException {
/* 327 */       this.buffer.write(b, o, l);
/*     */     }
/*     */ 
/*     */     public void write(int i) throws IOException {
/* 331 */       this.buffer.write(i);
/*     */     }
/*     */ 
/*     */     public void write(byte[] b) throws IOException {
/* 335 */       this.buffer.write(b);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.components.Include
 * JD-Core Version:    0.6.0
 */