/*     */ package org.apache.struts2.components;
/*     */ 
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import java.io.Writer;
/*     */ import org.apache.struts2.StrutsException;
/*     */ import org.apache.struts2.views.annotations.StrutsTag;
/*     */ import org.apache.struts2.views.annotations.StrutsTagAttribute;
/*     */ 
/*     */ @StrutsTag(name="param", tldTagClass="org.apache.struts2.views.jsp.ParamTag", description="Parametrize other tags")
/*     */ public class Param extends Component
/*     */ {
/*     */   protected String name;
/*     */   protected String value;
/*     */   protected boolean suppressEmptyParameters;
/*     */ 
/*     */   public Param(ValueStack stack)
/*     */   {
/* 112 */     super(stack);
/*     */   }
/*     */ 
/*     */   public boolean end(Writer writer, String body) {
/* 116 */     Component component = findAncestor(Component.class);
/* 117 */     if (this.value != null) {
/* 118 */       if ((component instanceof UnnamedParametric)) {
/* 119 */         ((UnnamedParametric)component).addParameter(findValue(this.value));
/*     */       } else {
/* 121 */         String name = findString(this.name);
/*     */ 
/* 123 */         if (name == null) {
/* 124 */           throw new StrutsException("No name found for following expression: " + this.name);
/*     */         }
/*     */ 
/* 127 */         Object value = findValue(this.value);
/* 128 */         if (this.suppressEmptyParameters) {
/* 129 */           String potentialValue = (String)value;
/* 130 */           if ((potentialValue != null) && (potentialValue.length() > 0))
/* 131 */             component.addParameter(name, value);
/*     */         }
/*     */         else {
/* 134 */           component.addParameter(name, value);
/*     */         }
/*     */       }
/*     */     }
/* 138 */     else if ((component instanceof UnnamedParametric))
/* 139 */       ((UnnamedParametric)component).addParameter(body);
/*     */     else {
/* 141 */       component.addParameter(findString(this.name), body);
/*     */     }
/*     */ 
/* 145 */     return super.end(writer, "");
/*     */   }
/*     */ 
/*     */   public boolean usesBody() {
/* 149 */     return true;
/*     */   }
/*     */   @StrutsTagAttribute(description="Name of Parameter to set")
/*     */   public void setName(String name) {
/* 154 */     this.name = name;
/*     */   }
/*     */   @StrutsTagAttribute(description="Value expression for Parameter to set", defaultValue="The value of evaluating provided name against stack")
/*     */   public void setValue(String value) {
/* 159 */     this.value = value;
/*     */   }
/*     */   @StrutsTagAttribute(description="Whether to suppress empty parameters", type="Boolean", defaultValue="false")
/*     */   public void setSuppressEmptyParameters(boolean suppressEmptyParameters) {
/* 164 */     this.suppressEmptyParameters = suppressEmptyParameters;
/*     */   }
/*     */ 
/*     */   public static abstract interface UnnamedParametric
/*     */   {
/*     */     public abstract void addParameter(Object paramObject);
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.components.Param
 * JD-Core Version:    0.6.0
 */