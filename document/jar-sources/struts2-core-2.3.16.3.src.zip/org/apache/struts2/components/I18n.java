/*     */ package org.apache.struts2.components;
/*     */ 
/*     */ import com.opensymphony.xwork2.LocaleProvider;
/*     */ import com.opensymphony.xwork2.TextProvider;
/*     */ import com.opensymphony.xwork2.TextProviderFactory;
/*     */ import com.opensymphony.xwork2.inject.Container;
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import com.opensymphony.xwork2.util.LocalizedTextUtil;
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import com.opensymphony.xwork2.util.logging.Logger;
/*     */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*     */ import java.io.Writer;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.ResourceBundle;
/*     */ import org.apache.struts2.StrutsException;
/*     */ import org.apache.struts2.views.annotations.StrutsTag;
/*     */ import org.apache.struts2.views.annotations.StrutsTagAttribute;
/*     */ 
/*     */ @StrutsTag(name="i18n", tldTagClass="org.apache.struts2.views.jsp.I18nTag", description="Get a resource bundle and place it on the value stack")
/*     */ public class I18n extends Component
/*     */ {
/*  92 */   private static final Logger LOG = LoggerFactory.getLogger(I18n.class);
/*     */   protected boolean pushed;
/*     */   protected String name;
/*     */   protected Container container;
/*     */   private TextProvider textProvider;
/*     */ 
/*     */   public I18n(ValueStack stack)
/*     */   {
/* 100 */     super(stack);
/*     */   }
/*     */   @Inject
/*     */   public void setContainer(Container container) {
/* 105 */     this.container = container;
/*     */   }
/*     */ 
/*     */   public boolean start(Writer writer) {
/* 109 */     boolean result = super.start(writer);
/*     */     try
/*     */     {
/* 112 */       String name = findString(this.name, "name", "Resource bundle name is required. Example: foo or foo_en");
/* 113 */       ResourceBundle bundle = (ResourceBundle)findValue("getTexts('" + name + "')");
/*     */ 
/* 115 */       if (bundle == null) {
/* 116 */         bundle = LocalizedTextUtil.findResourceBundle(name, (Locale)getStack().getContext().get("com.opensymphony.xwork2.ActionContext.locale"));
/*     */       }
/*     */ 
/* 119 */       if (bundle != null) {
/* 120 */         Locale locale = (Locale)getStack().getContext().get("com.opensymphony.xwork2.ActionContext.locale");
/* 121 */         TextProviderFactory tpf = new TextProviderFactory();
/* 122 */         this.container.inject(tpf);
/* 123 */         this.textProvider = tpf.createInstance(bundle, new LocaleProvider(locale) {
/*     */           public Locale getLocale() {
/* 125 */             return this.val$locale;
/*     */           }
/*     */         });
/* 128 */         getStack().push(this.textProvider);
/* 129 */         this.pushed = true;
/*     */       }
/*     */     } catch (Exception e) {
/* 132 */       String msg = "Could not find the bundle " + this.name;
/* 133 */       throw new StrutsException(msg, e);
/*     */     }
/*     */ 
/* 136 */     return result;
/*     */   }
/*     */ 
/*     */   public boolean end(Writer writer, String body) throws StrutsException {
/* 140 */     if (this.pushed) {
/* 141 */       Object o = getStack().pop();
/* 142 */       if ((o == null) || (!o.equals(this.textProvider))) {
/* 143 */         LOG.error("A closing i18n tag attempted to pop its own TextProvider from the top of the ValueStack but popped an unexpected object (" + (o != null ? o.getClass() : "null") + "). " + "Refactor the page within the i18n tags to ensure no objects are pushed onto the ValueStack without popping them prior to the closing tag. " + "If you see this message it's likely that the i18n's TextProvider is still on the stack and will continue to provide message resources after the closing tag.", new String[0]);
/*     */ 
/* 146 */         throw new StrutsException("A closing i18n tag attempted to pop its TextProvider from the top of the ValueStack but popped an unexpected object (" + (o != null ? o.getClass() : "null") + ")");
/*     */       }
/*     */     }
/*     */ 
/* 150 */     return super.end(writer, body);
/*     */   }
/*     */   @StrutsTagAttribute(description="Name of resource bundle to use (eg foo/bar/customBundle)", required=true, defaultValue="String")
/*     */   public void setName(String name) {
/* 155 */     this.name = name;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.components.I18n
 * JD-Core Version:    0.6.0
 */