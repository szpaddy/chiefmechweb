/*     */ package org.apache.struts2.components;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionContext;
/*     */ import com.opensymphony.xwork2.TextProvider;
/*     */ import com.opensymphony.xwork2.util.CompoundRoot;
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import com.opensymphony.xwork2.util.logging.Logger;
/*     */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import java.text.DateFormat;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Calendar;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.TimeZone;
/*     */ import org.apache.struts2.views.annotations.StrutsTag;
/*     */ import org.apache.struts2.views.annotations.StrutsTagAttribute;
/*     */ 
/*     */ @StrutsTag(name="date", tldBodyContent="empty", tldTagClass="org.apache.struts2.views.jsp.DateTag", description="Render a formatted date.")
/*     */ public class Date extends ContextBean
/*     */ {
/* 146 */   private static final Logger LOG = LoggerFactory.getLogger(Date.class);
/*     */   public static final String DATETAG_PROPERTY = "struts.date.format";
/*     */   public static final String DATETAG_PROPERTY_PAST = "struts.date.format.past";
/*     */   private static final String DATETAG_DEFAULT_PAST = "{0} ago";
/*     */   public static final String DATETAG_PROPERTY_FUTURE = "struts.date.format.future";
/*     */   private static final String DATETAG_DEFAULT_FUTURE = "in {0}";
/*     */   public static final String DATETAG_PROPERTY_SECONDS = "struts.date.format.seconds";
/*     */   private static final String DATETAG_DEFAULT_SECONDS = "an instant";
/*     */   public static final String DATETAG_PROPERTY_MINUTES = "struts.date.format.minutes";
/*     */   private static final String DATETAG_DEFAULT_MINUTES = "{0,choice,1#one minute|1<{0} minutes}";
/*     */   public static final String DATETAG_PROPERTY_HOURS = "struts.date.format.hours";
/*     */   private static final String DATETAG_DEFAULT_HOURS = "{0,choice,1#one hour|1<{0} hours}{1,choice,0#|1#, one minute|1<, {1} minutes}";
/*     */   public static final String DATETAG_PROPERTY_DAYS = "struts.date.format.days";
/*     */   private static final String DATETAG_DEFAULT_DAYS = "{0,choice,1#one day|1<{0} days}{1,choice,0#|1#, one hour|1<, {1} hours}";
/*     */   public static final String DATETAG_PROPERTY_YEARS = "struts.date.format.years";
/*     */   private static final String DATETAG_DEFAULT_YEARS = "{0,choice,1#one year|1<{0} years}{1,choice,0#|1#, one day|1<, {1} days}";
/*     */   private String name;
/*     */   private String format;
/*     */   private boolean nice;
/*     */   private String timezone;
/*     */ 
/*     */   public Date(ValueStack stack)
/*     */   {
/* 199 */     super(stack);
/*     */   }
/*     */ 
/*     */   private TextProvider findProviderInStack() {
/* 203 */     Iterator iterator = getStack().getRoot().iterator();
/* 204 */     while (iterator.hasNext()) {
/* 205 */       Object o = iterator.next();
/*     */ 
/* 207 */       if ((o instanceof TextProvider)) {
/* 208 */         return (TextProvider)o;
/*     */       }
/*     */     }
/* 211 */     return null;
/*     */   }
/*     */ 
/*     */   public String formatTime(TextProvider tp, java.util.Date date)
/*     */   {
/* 223 */     java.util.Date now = new java.util.Date();
/* 224 */     StringBuilder sb = new StringBuilder();
/* 225 */     List args = new ArrayList();
/* 226 */     long secs = Math.abs((now.getTime() - date.getTime()) / 1000L);
/* 227 */     long mins = secs / 60L;
/* 228 */     long sec = secs % 60L;
/* 229 */     int min = (int)mins % 60;
/* 230 */     long hours = mins / 60L;
/* 231 */     int hour = (int)hours % 24;
/* 232 */     int days = (int)hours / 24;
/* 233 */     int day = days % 365;
/* 234 */     int years = days / 365;
/*     */ 
/* 236 */     if (years > 0) {
/* 237 */       args.add(Long.valueOf(years));
/* 238 */       args.add(Long.valueOf(day));
/* 239 */       args.add(sb);
/* 240 */       args.add(null);
/* 241 */       sb.append(tp.getText("struts.date.format.years", "{0,choice,1#one year|1<{0} years}{1,choice,0#|1#, one day|1<, {1} days}", args));
/* 242 */     } else if (day > 0) {
/* 243 */       args.add(Long.valueOf(day));
/* 244 */       args.add(Long.valueOf(hour));
/* 245 */       args.add(sb);
/* 246 */       args.add(null);
/* 247 */       sb.append(tp.getText("struts.date.format.days", "{0,choice,1#one day|1<{0} days}{1,choice,0#|1#, one hour|1<, {1} hours}", args));
/* 248 */     } else if (hour > 0) {
/* 249 */       args.add(Long.valueOf(hour));
/* 250 */       args.add(Long.valueOf(min));
/* 251 */       args.add(sb);
/* 252 */       args.add(null);
/* 253 */       sb.append(tp.getText("struts.date.format.hours", "{0,choice,1#one hour|1<{0} hours}{1,choice,0#|1#, one minute|1<, {1} minutes}", args));
/* 254 */     } else if (min > 0) {
/* 255 */       args.add(Long.valueOf(min));
/* 256 */       args.add(Long.valueOf(sec));
/* 257 */       args.add(sb);
/* 258 */       args.add(null);
/* 259 */       sb.append(tp.getText("struts.date.format.minutes", "{0,choice,1#one minute|1<{0} minutes}", args));
/*     */     } else {
/* 261 */       args.add(Long.valueOf(sec));
/* 262 */       args.add(sb);
/* 263 */       args.add(null);
/* 264 */       sb.append(tp.getText("struts.date.format.seconds", "an instant", args));
/*     */     }
/*     */ 
/* 267 */     args.clear();
/* 268 */     args.add(sb.toString());
/* 269 */     if (date.before(now))
/*     */     {
/* 271 */       return tp.getText("struts.date.format.past", "{0} ago", args);
/*     */     }
/* 273 */     return tp.getText("struts.date.format.future", "in {0}", args);
/*     */   }
/*     */ 
/*     */   public boolean end(Writer writer, String body)
/*     */   {
/* 279 */     java.util.Date date = null;
/*     */     try
/*     */     {
/* 283 */       Object dateObject = findValue(this.name);
/* 284 */       if ((dateObject instanceof java.util.Date))
/* 285 */         date = (java.util.Date)dateObject;
/* 286 */       else if ((dateObject instanceof Calendar))
/* 287 */         date = ((Calendar)dateObject).getTime();
/*     */     }
/*     */     catch (Exception e) {
/* 290 */       LOG.error("Could not convert object with key '#0' to a java.util.Date instance", new String[] { this.name });
/*     */     }
/*     */ 
/* 294 */     if (this.format != null) {
/* 295 */       this.format = findString(this.format);
/*     */     }
/* 297 */     if (date != null) {
/* 298 */       TextProvider tp = findProviderInStack();
/* 299 */       if (tp != null)
/*     */       {
/*     */         String msg;
/*     */         String msg;
/* 300 */         if (this.nice) {
/* 301 */           msg = formatTime(tp, date);
/*     */         } else {
/* 303 */           TimeZone tz = getTimeZone();
/*     */           String msg;
/* 304 */           if (this.format == null) {
/* 305 */             String globalFormat = null;
/*     */ 
/* 309 */             globalFormat = tp.getText("struts.date.format");
/*     */             String msg;
/* 314 */             if ((globalFormat != null) && (!"struts.date.format".equals(globalFormat)))
/*     */             {
/* 316 */               SimpleDateFormat sdf = new SimpleDateFormat(globalFormat, ActionContext.getContext().getLocale());
/*     */ 
/* 318 */               sdf.setTimeZone(tz);
/* 319 */               msg = sdf.format(date);
/*     */             } else {
/* 321 */               DateFormat df = DateFormat.getDateTimeInstance(2, 2, ActionContext.getContext().getLocale());
/*     */ 
/* 324 */               df.setTimeZone(tz);
/* 325 */               msg = df.format(date);
/*     */             }
/*     */           } else {
/* 328 */             SimpleDateFormat sdf = new SimpleDateFormat(this.format, ActionContext.getContext().getLocale());
/*     */ 
/* 330 */             sdf.setTimeZone(tz);
/* 331 */             msg = sdf.format(date);
/*     */           }
/*     */         }
/* 334 */         if (msg != null) {
/*     */           try {
/* 336 */             if (getVar() == null)
/* 337 */               writer.write(msg);
/*     */             else
/* 339 */               putInContext(msg);
/*     */           }
/*     */           catch (IOException e) {
/* 342 */             LOG.error("Could not write out Date tag", e, new String[0]);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 347 */     return super.end(writer, "");
/*     */   }
/*     */ 
/*     */   private TimeZone getTimeZone() {
/* 351 */     TimeZone tz = TimeZone.getDefault();
/* 352 */     if (this.timezone != null) {
/* 353 */       this.timezone = stripExpressionIfAltSyntax(this.timezone);
/* 354 */       String actualTimezone = (String)getStack().findValue(this.timezone, String.class);
/* 355 */       if (actualTimezone != null) {
/* 356 */         this.timezone = actualTimezone;
/*     */       }
/* 358 */       tz = TimeZone.getTimeZone(this.timezone);
/*     */     }
/* 360 */     return tz;
/*     */   }
/*     */   @StrutsTagAttribute(description="Date or DateTime format pattern", rtexprvalue=false)
/*     */   public void setFormat(String format) {
/* 365 */     this.format = format;
/*     */   }
/*     */   @StrutsTagAttribute(description="Whether to print out the date nicely", type="Boolean", defaultValue="false")
/*     */   public void setNice(boolean nice) {
/* 370 */     this.nice = nice;
/*     */   }
/*     */ 
/*     */   public String getName()
/*     */   {
/* 377 */     return this.name;
/*     */   }
/*     */   @StrutsTagAttribute(description="The date value to format", required=true)
/*     */   public void setName(String name) {
/* 382 */     this.name = name;
/*     */   }
/*     */ 
/*     */   public String getFormat()
/*     */   {
/* 389 */     return this.format;
/*     */   }
/*     */ 
/*     */   public boolean isNice()
/*     */   {
/* 396 */     return this.nice;
/*     */   }
/*     */ 
/*     */   public String getTimezone()
/*     */   {
/* 403 */     return this.timezone;
/*     */   }
/*     */   @StrutsTagAttribute(description="The specific timezone in which to format the date", required=false)
/*     */   public void setTimezone(String timezone) {
/* 408 */     this.timezone = timezone;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.components.Date
 * JD-Core Version:    0.6.0
 */