/*     */ package org.apache.struts2.components;
/*     */ 
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import com.opensymphony.xwork2.util.logging.Logger;
/*     */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*     */ import java.io.StringWriter;
/*     */ import java.io.Writer;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.commons.lang3.StringUtils;
/*     */ import org.apache.struts2.views.annotations.StrutsTag;
/*     */ import org.apache.struts2.views.annotations.StrutsTagAttribute;
/*     */ 
/*     */ @StrutsTag(name="a", tldTagClass="org.apache.struts2.views.jsp.ui.AnchorTag", description="Render a HTML href element that when clicked can optionally call a URL via remote XMLHttpRequest and updates its targets", allowDynamicAttributes=true)
/*     */ public class Anchor extends ClosingUIBean
/*     */ {
/*  64 */   private static final Logger LOG = LoggerFactory.getLogger(Anchor.class);
/*     */   public static final String OPEN_TEMPLATE = "a";
/*     */   public static final String TEMPLATE = "a-close";
/*  68 */   public static final String COMPONENT_NAME = Anchor.class.getName();
/*     */   protected String href;
/*     */   protected UrlProvider urlProvider;
/*     */   protected UrlRenderer urlRenderer;
/*  73 */   protected boolean processingTagBody = false;
/*     */ 
/*  76 */   protected Map urlParameters = new LinkedHashMap();
/*     */ 
/*     */   public Anchor(ValueStack stack, HttpServletRequest request, HttpServletResponse response) {
/*  79 */     super(stack, request, response);
/*  80 */     this.urlProvider = new ComponentUrlProvider(this, this.urlParameters);
/*  81 */     this.urlProvider.setHttpServletRequest(request);
/*  82 */     this.urlProvider.setHttpServletResponse(response);
/*     */   }
/*     */ 
/*     */   public String getDefaultOpenTemplate() {
/*  86 */     return "a";
/*     */   }
/*     */ 
/*     */   protected String getDefaultTemplate() {
/*  90 */     return "a-close";
/*     */   }
/*     */ 
/*     */   public boolean usesBody() {
/*  94 */     return true;
/*     */   }
/*     */ 
/*     */   protected void evaluateExtraParams()
/*     */   {
/*  99 */     super.evaluateExtraParams();
/*     */ 
/* 101 */     if (this.href != null) {
/* 102 */       addParameter("href", ensureAttributeSafelyNotEscaped(findString(this.href)));
/*     */     }
/*     */     else {
/* 105 */       StringWriter sw = new StringWriter();
/* 106 */       this.urlRenderer.beforeRenderUrl(this.urlProvider);
/* 107 */       this.urlRenderer.renderUrl(sw, this.urlProvider);
/* 108 */       String builtHref = sw.toString();
/* 109 */       if (StringUtils.isNotEmpty(builtHref))
/* 110 */         addParameter("href", ensureAttributeSafelyNotEscaped(builtHref)); 
/*     */     }
/*     */   }
/*     */ 
/*     */   @Inject("struts.url.includeParams")
/*     */   public void setUrlIncludeParams(String urlIncludeParams) {
/* 116 */     this.urlProvider.setUrlIncludeParams(urlIncludeParams);
/*     */   }
/*     */   @Inject
/*     */   public void setUrlRenderer(UrlRenderer urlRenderer) {
/* 121 */     this.urlProvider.setUrlRenderer(urlRenderer);
/* 122 */     this.urlRenderer = urlRenderer;
/*     */   }
/*     */   @Inject(required=false)
/*     */   public void setExtraParameterProvider(ExtraParameterProvider provider) {
/* 127 */     this.urlProvider.setExtraParameterProvider(provider);
/*     */   }
/*     */ 
/*     */   public boolean start(Writer writer)
/*     */   {
/* 132 */     boolean result = super.start(writer);
/* 133 */     this.processingTagBody = true;
/* 134 */     return result;
/*     */   }
/*     */ 
/*     */   public boolean end(Writer writer, String body)
/*     */   {
/* 141 */     this.processingTagBody = false;
/* 142 */     evaluateParams();
/*     */     try {
/* 144 */       addParameter("body", body);
/* 145 */       mergeTemplate(writer, buildTemplateName(this.template, getDefaultTemplate()));
/*     */     } catch (Exception e) {
/* 147 */       LOG.error("error when rendering", e, new String[0]);
/*     */     }
/*     */     finally {
/* 150 */       popComponentStack();
/*     */     }
/*     */ 
/* 153 */     return false;
/*     */   }
/*     */ 
/*     */   public void addParameter(String key, Object value)
/*     */   {
/* 163 */     if (this.processingTagBody)
/* 164 */       this.urlParameters.put(key, value);
/*     */     else
/* 166 */       super.addParameter(key, value);
/*     */   }
/*     */ 
/*     */   public void addAllParameters(Map params)
/*     */   {
/* 176 */     if (this.processingTagBody)
/* 177 */       this.urlParameters.putAll(params);
/*     */     else
/* 179 */       super.addAllParameters(params);
/*     */   }
/*     */ 
/*     */   public UrlProvider getUrlProvider() {
/* 183 */     return this.urlProvider;
/*     */   }
/*     */   @StrutsTagAttribute(description="The URL.")
/*     */   public void setHref(String href) {
/* 188 */     this.href = href;
/*     */   }
/*     */   @StrutsTagAttribute(description="The includeParams attribute may have the value 'none', 'get' or 'all'", defaultValue="none")
/*     */   public void setIncludeParams(String includeParams) {
/* 193 */     this.urlProvider.setIncludeParams(includeParams);
/*     */   }
/*     */   @StrutsTagAttribute(description="Set scheme attribute")
/*     */   public void setScheme(String scheme) {
/* 198 */     this.urlProvider.setScheme(scheme);
/*     */   }
/*     */   @StrutsTagAttribute(description="The target value to use, if not using action")
/*     */   public void setValue(String value) {
/* 203 */     this.urlProvider.setValue(value);
/*     */   }
/*     */   @StrutsTagAttribute(description="The action to generate the URL for, if not using value")
/*     */   public void setAction(String action) {
/* 208 */     this.urlProvider.setAction(action);
/*     */   }
/*     */   @StrutsTagAttribute(description="The namespace to use")
/*     */   public void setNamespace(String namespace) {
/* 213 */     this.urlProvider.setNamespace(namespace);
/*     */   }
/*     */   @StrutsTagAttribute(description="The method of action to use")
/*     */   public void setMethod(String method) {
/* 218 */     this.urlProvider.setMethod(method);
/*     */   }
/*     */   @StrutsTagAttribute(description="Whether to encode parameters", type="Boolean", defaultValue="true")
/*     */   public void setEncode(boolean encode) {
/* 223 */     this.urlProvider.setEncode(encode);
/*     */   }
/*     */   @StrutsTagAttribute(description="Whether actual context should be included in URL", type="Boolean", defaultValue="true")
/*     */   public void setIncludeContext(boolean includeContext) {
/* 228 */     this.urlProvider.setIncludeContext(includeContext);
/*     */   }
/*     */   @StrutsTagAttribute(description="The resulting portlet mode")
/*     */   public void setPortletMode(String portletMode) {
/* 233 */     this.urlProvider.setPortletMode(portletMode);
/*     */   }
/*     */   @StrutsTagAttribute(description="The resulting portlet window state")
/*     */   public void setWindowState(String windowState) {
/* 238 */     this.urlProvider.setWindowState(windowState);
/*     */   }
/*     */   @StrutsTagAttribute(description="Specifies if this should be a portlet render or action URL. Default is \"render\". To create an action URL, use \"action\".")
/*     */   public void setPortletUrlType(String portletUrlType) {
/* 243 */     this.urlProvider.setPortletUrlType(portletUrlType);
/*     */   }
/*     */   @StrutsTagAttribute(description="The anchor for this URL")
/*     */   public void setAnchor(String anchor) {
/* 248 */     this.urlProvider.setAnchor(anchor);
/*     */   }
/*     */   @StrutsTagAttribute(description="Specifies whether to escape ampersand (&amp;) to (&amp;amp;) or not", type="Boolean", defaultValue="true")
/*     */   public void setEscapeAmp(boolean escapeAmp) {
/* 253 */     this.urlProvider.setEscapeAmp(escapeAmp);
/*     */   }
/*     */   @StrutsTagAttribute(description="Specifies whether to force the addition of scheme, host and port or not", type="Boolean", defaultValue="false")
/*     */   public void setForceAddSchemeHostAndPort(boolean forceAddSchemeHostAndPort) {
/* 258 */     this.urlProvider.setForceAddSchemeHostAndPort(forceAddSchemeHostAndPort);
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.components.Anchor
 * JD-Core Version:    0.6.0
 */