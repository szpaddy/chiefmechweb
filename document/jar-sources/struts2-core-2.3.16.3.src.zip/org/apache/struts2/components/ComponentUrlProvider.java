/*     */ package org.apache.struts2.components;
/*     */ 
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import java.util.Map;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ 
/*     */ public class ComponentUrlProvider
/*     */   implements UrlProvider
/*     */ {
/*     */   protected HttpServletRequest httpServletRequest;
/*     */   protected HttpServletResponse httpServletResponse;
/*     */   protected String includeParams;
/*     */   protected String scheme;
/*     */   protected String value;
/*     */   protected String action;
/*     */   protected String namespace;
/*     */   protected String method;
/*  42 */   protected boolean encode = true;
/*  43 */   protected boolean includeContext = true;
/*  44 */   protected boolean escapeAmp = true;
/*     */   protected String portletMode;
/*     */   protected String windowState;
/*     */   protected String portletUrlType;
/*     */   protected String anchor;
/*     */   protected boolean forceAddSchemeHostAndPort;
/*     */   protected String urlIncludeParams;
/*     */   protected ExtraParameterProvider extraParameterProvider;
/*     */   protected UrlRenderer urlRenderer;
/*     */   protected Component component;
/*     */   private Map parameters;
/*     */ 
/*     */   public ComponentUrlProvider(Component component, Map parameters)
/*     */   {
/*  63 */     this.component = component;
/*  64 */     this.parameters = parameters;
/*     */   }
/*     */ 
/*     */   public String determineActionURL(String action, String namespace, String method, HttpServletRequest req, HttpServletResponse res, Map parameters, String scheme, boolean includeContext, boolean encodeResult, boolean forceAddSchemeHostAndPort, boolean escapeAmp) {
/*  68 */     return this.component.determineActionURL(action, namespace, method, req, res, parameters, scheme, includeContext, encodeResult, forceAddSchemeHostAndPort, escapeAmp);
/*     */   }
/*     */ 
/*     */   public String determineNamespace(String namespace, ValueStack stack, HttpServletRequest req) {
/*  72 */     return this.component.determineNamespace(namespace, stack, req);
/*     */   }
/*     */ 
/*     */   public String findString(String expr) {
/*  76 */     return this.component.findString(expr);
/*     */   }
/*     */ 
/*     */   public Map getParameters() {
/*  80 */     return this.parameters;
/*     */   }
/*     */ 
/*     */   public HttpServletRequest getHttpServletRequest() {
/*  84 */     return this.httpServletRequest;
/*     */   }
/*     */ 
/*     */   public void setHttpServletRequest(HttpServletRequest httpServletRequest) {
/*  88 */     this.httpServletRequest = httpServletRequest;
/*     */   }
/*     */ 
/*     */   public HttpServletResponse getHttpServletResponse() {
/*  92 */     return this.httpServletResponse;
/*     */   }
/*     */ 
/*     */   public void setHttpServletResponse(HttpServletResponse httpServletResponse) {
/*  96 */     this.httpServletResponse = httpServletResponse;
/*     */   }
/*     */ 
/*     */   public String getIncludeParams() {
/* 100 */     return this.includeParams;
/*     */   }
/*     */ 
/*     */   public void setIncludeParams(String includeParams) {
/* 104 */     this.includeParams = includeParams;
/*     */   }
/*     */ 
/*     */   public String getScheme() {
/* 108 */     return this.scheme;
/*     */   }
/*     */ 
/*     */   public void setScheme(String scheme) {
/* 112 */     this.scheme = scheme;
/*     */   }
/*     */ 
/*     */   public boolean isPutInContext() {
/* 116 */     return this.component instanceof ContextBean;
/*     */   }
/*     */ 
/*     */   public String getVar() {
/* 120 */     return isPutInContext() ? ((ContextBean)this.component).getVar() : null;
/*     */   }
/*     */ 
/*     */   public String getValue() {
/* 124 */     return this.value;
/*     */   }
/*     */ 
/*     */   public void setValue(String value) {
/* 128 */     this.value = value;
/*     */   }
/*     */ 
/*     */   public String getAction() {
/* 132 */     return this.action;
/*     */   }
/*     */ 
/*     */   public void setAction(String action) {
/* 136 */     this.action = action;
/*     */   }
/*     */ 
/*     */   public String getNamespace() {
/* 140 */     return this.namespace;
/*     */   }
/*     */ 
/*     */   public void setNamespace(String namespace) {
/* 144 */     this.namespace = namespace;
/*     */   }
/*     */ 
/*     */   public String getMethod() {
/* 148 */     return this.method;
/*     */   }
/*     */ 
/*     */   public void setMethod(String method) {
/* 152 */     this.method = method;
/*     */   }
/*     */ 
/*     */   public boolean isEncode() {
/* 156 */     return this.encode;
/*     */   }
/*     */ 
/*     */   public void setEncode(boolean encode) {
/* 160 */     this.encode = encode;
/*     */   }
/*     */ 
/*     */   public boolean isIncludeContext() {
/* 164 */     return this.includeContext;
/*     */   }
/*     */ 
/*     */   public void setIncludeContext(boolean includeContext) {
/* 168 */     this.includeContext = includeContext;
/*     */   }
/*     */ 
/*     */   public boolean isEscapeAmp() {
/* 172 */     return this.escapeAmp;
/*     */   }
/*     */ 
/*     */   public void setEscapeAmp(boolean escapeAmp) {
/* 176 */     this.escapeAmp = escapeAmp;
/*     */   }
/*     */ 
/*     */   public String getPortletMode() {
/* 180 */     return this.portletMode;
/*     */   }
/*     */ 
/*     */   public void setPortletMode(String portletMode) {
/* 184 */     this.portletMode = portletMode;
/*     */   }
/*     */ 
/*     */   public String getWindowState() {
/* 188 */     return this.windowState;
/*     */   }
/*     */ 
/*     */   public void setWindowState(String windowState) {
/* 192 */     this.windowState = windowState;
/*     */   }
/*     */ 
/*     */   public String getPortletUrlType() {
/* 196 */     return this.portletUrlType;
/*     */   }
/*     */ 
/*     */   public ValueStack getStack() {
/* 200 */     return this.component.getStack();
/*     */   }
/*     */ 
/*     */   public void setPortletUrlType(String portletUrlType) {
/* 204 */     this.portletUrlType = portletUrlType;
/*     */   }
/*     */ 
/*     */   public String getAnchor() {
/* 208 */     return this.anchor;
/*     */   }
/*     */ 
/*     */   public void setAnchor(String anchor) {
/* 212 */     this.anchor = anchor;
/*     */   }
/*     */ 
/*     */   public boolean isForceAddSchemeHostAndPort() {
/* 216 */     return this.forceAddSchemeHostAndPort;
/*     */   }
/*     */ 
/*     */   public void setForceAddSchemeHostAndPort(boolean forceAddSchemeHostAndPort) {
/* 220 */     this.forceAddSchemeHostAndPort = forceAddSchemeHostAndPort;
/*     */   }
/*     */ 
/*     */   public void putInContext(String result) {
/* 224 */     if (isPutInContext())
/* 225 */       ((ContextBean)this.component).putInContext(result);
/*     */   }
/*     */ 
/*     */   public String getUrlIncludeParams()
/*     */   {
/* 230 */     return this.urlIncludeParams;
/*     */   }
/*     */ 
/*     */   public void setUrlIncludeParams(String urlIncludeParams) {
/* 234 */     this.urlIncludeParams = urlIncludeParams;
/*     */   }
/*     */ 
/*     */   public ExtraParameterProvider getExtraParameterProvider() {
/* 238 */     return this.extraParameterProvider;
/*     */   }
/*     */ 
/*     */   public void setExtraParameterProvider(ExtraParameterProvider extraParameterProvider) {
/* 242 */     this.extraParameterProvider = extraParameterProvider;
/*     */   }
/*     */ 
/*     */   public UrlRenderer getUrlRenderer() {
/* 246 */     return this.urlRenderer;
/*     */   }
/*     */ 
/*     */   public void setUrlRenderer(UrlRenderer urlRenderer) {
/* 250 */     this.urlRenderer = urlRenderer;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.components.ComponentUrlProvider
 * JD-Core Version:    0.6.0
 */