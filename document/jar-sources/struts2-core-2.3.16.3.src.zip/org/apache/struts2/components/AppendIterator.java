/*     */ package org.apache.struts2.components;
/*     */ 
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import com.opensymphony.xwork2.util.logging.Logger;
/*     */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*     */ import java.io.Writer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.apache.struts2.util.AppendIteratorFilter;
/*     */ import org.apache.struts2.util.MakeIterator;
/*     */ import org.apache.struts2.views.annotations.StrutsTag;
/*     */ import org.apache.struts2.views.annotations.StrutsTagAttribute;
/*     */ 
/*     */ @StrutsTag(name="append", tldTagClass="org.apache.struts2.views.jsp.iterator.AppendIteratorTag", description="Append the values of a list of iterators to one iterator")
/*     */ public class AppendIterator extends ContextBean
/*     */   implements Param.UnnamedParametric
/*     */ {
/* 122 */   private static final Logger LOG = LoggerFactory.getLogger(AppendIterator.class);
/*     */ 
/* 124 */   private AppendIteratorFilter appendIteratorFilter = null;
/*     */   private List _parameters;
/*     */ 
/*     */   public AppendIterator(ValueStack stack)
/*     */   {
/* 128 */     super(stack);
/*     */   }
/*     */ 
/*     */   public boolean start(Writer writer) {
/* 132 */     this._parameters = new ArrayList();
/* 133 */     this.appendIteratorFilter = new AppendIteratorFilter();
/*     */ 
/* 135 */     return super.start(writer);
/*     */   }
/*     */ 
/*     */   public boolean end(Writer writer, String body)
/*     */   {
/* 140 */     for (Iterator paramEntries = this._parameters.iterator(); paramEntries.hasNext(); )
/*     */     {
/* 142 */       Object iteratorEntryObj = paramEntries.next();
/* 143 */       if (!MakeIterator.isIterable(iteratorEntryObj)) {
/* 144 */         if (LOG.isWarnEnabled()) {
/* 145 */           LOG.warn("param with value resolved as " + iteratorEntryObj + " cannot be make as iterator, it will be ignored and hence will not appear in the merged iterator", new String[0]); continue;
/*     */         }
/*     */       }
/*     */ 
/* 149 */       this.appendIteratorFilter.setSource(MakeIterator.convert(iteratorEntryObj));
/*     */     }
/*     */ 
/* 152 */     this.appendIteratorFilter.execute();
/*     */ 
/* 154 */     putInContext(this.appendIteratorFilter);
/*     */ 
/* 156 */     this.appendIteratorFilter = null;
/*     */ 
/* 158 */     return super.end(writer, body);
/*     */   }
/*     */ 
/*     */   public void addParameter(Object value)
/*     */   {
/* 163 */     this._parameters.add(value);
/*     */   }
/*     */   @StrutsTagAttribute(description="The name of which if supplied will have the resultant appended iterator stored under in the stack's context")
/*     */   public void setVar(String var) {
/* 168 */     super.setVar(var);
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.components.AppendIterator
 * JD-Core Version:    0.6.0
 */