/*     */ package org.apache.struts2.components;
/*     */ 
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import com.opensymphony.xwork2.util.logging.Logger;
/*     */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.struts2.views.annotations.StrutsTag;
/*     */ import org.apache.struts2.views.annotations.StrutsTagAttribute;
/*     */ 
/*     */ @StrutsTag(name="inputtransferselect", tldTagClass="org.apache.struts2.views.jsp.ui.InputTransferSelectTag", description="Renders an input form")
/*     */ public class InputTransferSelect extends ListUIBean
/*     */ {
/*  78 */   private static final Logger LOG = LoggerFactory.getLogger(InputTransferSelect.class);
/*     */   private static final String TEMPLATE = "inputtransferselect";
/*     */   protected String size;
/*     */   protected String multiple;
/*     */   protected String allowRemoveAll;
/*     */   protected String allowUpDown;
/*     */   protected String leftTitle;
/*     */   protected String rightTitle;
/*     */   protected String buttonCssClass;
/*     */   protected String buttonCssStyle;
/*     */   protected String addLabel;
/*     */   protected String removeLabel;
/*     */   protected String removeAllLabel;
/*     */   protected String upLabel;
/*     */   protected String downLabel;
/*     */   protected String headerKey;
/*     */   protected String headerValue;
/*     */ 
/*     */   public InputTransferSelect(ValueStack stack, HttpServletRequest request, HttpServletResponse response)
/*     */   {
/* 105 */     super(stack, request, response);
/*     */   }
/*     */ 
/*     */   protected String getDefaultTemplate() {
/* 109 */     return "inputtransferselect";
/*     */   }
/*     */ 
/*     */   public void evaluateExtraParams()
/*     */   {
/* 114 */     super.evaluateExtraParams();
/*     */ 
/* 116 */     if ((this.size == null) || (this.size.trim().length() <= 0)) {
/* 117 */       addParameter("size", "5");
/*     */     }
/*     */ 
/* 120 */     if ((this.multiple == null) || (this.multiple.trim().length() <= 0)) {
/* 121 */       addParameter("multiple", Boolean.TRUE);
/*     */     }
/*     */ 
/* 125 */     addParameter("allowUpDown", this.allowUpDown != null ? findValue(this.allowUpDown, Boolean.class) : Boolean.TRUE);
/*     */ 
/* 128 */     addParameter("allowRemoveAll", this.allowRemoveAll != null ? findValue(this.allowRemoveAll, Boolean.class) : Boolean.TRUE);
/*     */ 
/* 132 */     if (this.leftTitle != null) {
/* 133 */       addParameter("leftTitle", findValue(this.leftTitle, String.class));
/*     */     }
/*     */ 
/* 137 */     if (this.rightTitle != null) {
/* 138 */       addParameter("rightTitle", findValue(this.rightTitle, String.class));
/*     */     }
/*     */ 
/* 143 */     if ((this.buttonCssClass != null) && (this.buttonCssClass.trim().length() > 0)) {
/* 144 */       addParameter("buttonCssClass", this.buttonCssClass);
/*     */     }
/*     */ 
/* 148 */     if ((this.buttonCssStyle != null) && (this.buttonCssStyle.trim().length() > 0)) {
/* 149 */       addParameter("buttonCssStyle", this.buttonCssStyle);
/*     */     }
/*     */ 
/* 153 */     addParameter("addLabel", this.addLabel != null ? findValue(this.addLabel, String.class) : "->");
/*     */ 
/* 156 */     addParameter("removeLabel", this.removeLabel != null ? findValue(this.removeLabel, String.class) : "<-");
/*     */ 
/* 159 */     addParameter("removeAllLabel", this.removeAllLabel != null ? findValue(this.removeAllLabel, String.class) : "<<--");
/*     */ 
/* 163 */     addParameter("upLabel", this.upLabel != null ? findValue(this.upLabel, String.class) : "^");
/*     */ 
/* 167 */     addParameter("downLabel", this.downLabel != null ? findValue(this.downLabel, String.class) : "v");
/*     */ 
/* 169 */     if ((this.headerKey != null) && (this.headerValue != null)) {
/* 170 */       addParameter("headerKey", findString(this.headerKey));
/* 171 */       addParameter("headerValue", findString(this.headerValue));
/*     */     }
/*     */ 
/* 178 */     Form formAncestor = (Form)findAncestor(Form.class);
/* 179 */     if (formAncestor != null)
/*     */     {
/* 182 */       enableAncestorFormCustomOnsubmit();
/*     */ 
/* 186 */       Map formInputtransferselectIds = (Map)formAncestor.getParameters().get("inputtransferselectIds");
/*     */ 
/* 189 */       if (formInputtransferselectIds == null) {
/* 190 */         formInputtransferselectIds = new LinkedHashMap();
/*     */       }
/*     */ 
/* 194 */       String tmpId = (String)getParameters().get("id");
/* 195 */       String tmpHeaderKey = (String)getParameters().get("headerKey");
/* 196 */       if ((tmpId != null) && (!formInputtransferselectIds.containsKey(tmpId))) {
/* 197 */         formInputtransferselectIds.put(tmpId, tmpHeaderKey);
/*     */       }
/*     */ 
/* 200 */       formAncestor.getParameters().put("inputtransferselectIds", formInputtransferselectIds);
/*     */     }
/* 204 */     else if (LOG.isWarnEnabled()) {
/* 205 */       LOG.warn("form enclosing inputtransferselect " + this + " not found, auto select upon form submit of inputtransferselect will not work", new String[0]);
/*     */     }
/*     */   }
/*     */ 
/*     */   public String getSize()
/*     */   {
/* 211 */     return this.size;
/*     */   }
/*     */   @StrutsTagAttribute(description="the size of the select box")
/*     */   public void setSize(String size) {
/* 216 */     this.size = size;
/*     */   }
/*     */ 
/*     */   public String getMultiple() {
/* 220 */     return this.multiple;
/*     */   }
/*     */   @StrutsTagAttribute(description="Determine whether or not multiple entries are shown")
/*     */   public void setMultiple(String multiple) {
/* 225 */     this.multiple = multiple;
/*     */   }
/*     */ 
/*     */   public String getAllowRemoveAll() {
/* 229 */     return this.allowRemoveAll;
/*     */   }
/*     */   @StrutsTagAttribute(description="Determine whether the remove all button will display")
/*     */   public void setAllowRemoveAll(String allowRemoveAll) {
/* 234 */     this.allowRemoveAll = allowRemoveAll;
/*     */   }
/*     */ 
/*     */   public String getAllowUpDown() {
/* 238 */     return this.allowUpDown;
/*     */   }
/*     */   @StrutsTagAttribute(description="Determine whether items in the list can be reordered")
/*     */   public void setAllowUpDown(String allowUpDown) {
/* 243 */     this.allowUpDown = allowUpDown;
/*     */   }
/*     */ 
/*     */   public String getLeftTitle() {
/* 247 */     return this.leftTitle;
/*     */   }
/*     */   @StrutsTagAttribute(description="the left hand title")
/*     */   public void setLeftTitle(String leftTitle) {
/* 252 */     this.leftTitle = leftTitle;
/*     */   }
/*     */ 
/*     */   public String getRightTitle() {
/* 256 */     return this.rightTitle;
/*     */   }
/*     */   @StrutsTagAttribute(description="the right hand title")
/*     */   public void setRightTitle(String rightTitle) {
/* 261 */     this.rightTitle = rightTitle;
/*     */   }
/*     */ 
/*     */   public String getButtonCssClass() {
/* 265 */     return this.buttonCssClass;
/*     */   }
/*     */   @StrutsTagAttribute(description="the css class used for rendering buttons")
/*     */   public void setButtonCssClass(String buttonCssClass) {
/* 270 */     this.buttonCssClass = buttonCssClass;
/*     */   }
/*     */ 
/*     */   public String getButtonCssStyle() {
/* 274 */     return this.buttonCssStyle;
/*     */   }
/*     */   @StrutsTagAttribute(description="the css style used for rendering buttons")
/*     */   public void setButtonCssStyle(String buttonCssStyle) {
/* 279 */     this.buttonCssStyle = buttonCssStyle;
/*     */   }
/*     */ 
/*     */   public String getAddLabel() {
/* 283 */     return this.addLabel;
/*     */   }
/*     */   @StrutsTagAttribute(description="the label used for the add button")
/*     */   public void setAddLabel(String addLabel) {
/* 288 */     this.addLabel = addLabel;
/*     */   }
/*     */ 
/*     */   public String getRemoveLabel() {
/* 292 */     return this.removeLabel;
/*     */   }
/*     */   @StrutsTagAttribute(description="the label used for the remove button")
/*     */   public void setRemoveLabel(String removeLabel) {
/* 297 */     this.removeLabel = removeLabel;
/*     */   }
/*     */ 
/*     */   public String getRemoveAllLabel() {
/* 301 */     return this.removeAllLabel;
/*     */   }
/*     */   @StrutsTagAttribute(description="the label used for the remove all button")
/*     */   public void setRemoveAllLabel(String removeAllLabel) {
/* 306 */     this.removeAllLabel = removeAllLabel;
/*     */   }
/*     */ 
/*     */   public String getUpLabel() {
/* 310 */     return this.upLabel;
/*     */   }
/*     */   @StrutsTagAttribute(description="the label used for the up button")
/*     */   public void setUpLabel(String upLabel) {
/* 315 */     this.upLabel = upLabel;
/*     */   }
/*     */ 
/*     */   public String getDownLabel() {
/* 319 */     return this.downLabel;
/*     */   }
/*     */   @StrutsTagAttribute(description="the label used for the down button")
/*     */   public void setDownLabel(String downLabel) {
/* 324 */     this.downLabel = downLabel;
/*     */   }
/*     */ 
/*     */   public String getHeaderKey() {
/* 328 */     return this.headerKey;
/*     */   }
/*     */   @StrutsTagAttribute(description="the header key of the select box")
/*     */   public void setHeaderKey(String headerKey) {
/* 333 */     this.headerKey = headerKey;
/*     */   }
/*     */ 
/*     */   public String getHeaderValue() {
/* 337 */     return this.headerValue;
/*     */   }
/*     */   @StrutsTagAttribute(description="the header value of the select box")
/*     */   public void setHeaderValue(String headerValue) {
/* 342 */     this.headerValue = headerValue;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.components.InputTransferSelect
 * JD-Core Version:    0.6.0
 */