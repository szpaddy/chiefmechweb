/*     */ package org.apache.struts2.components;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionContext;
/*     */ import com.opensymphony.xwork2.ActionInvocation;
/*     */ import com.opensymphony.xwork2.ActionProxy;
/*     */ import com.opensymphony.xwork2.ObjectFactory;
/*     */ import com.opensymphony.xwork2.config.Configuration;
/*     */ import com.opensymphony.xwork2.config.RuntimeConfiguration;
/*     */ import com.opensymphony.xwork2.config.entities.ActionConfig;
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import com.opensymphony.xwork2.util.logging.Logger;
/*     */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.apache.commons.lang3.StringUtils;
/*     */ import org.apache.struts2.StrutsException;
/*     */ import org.apache.struts2.dispatcher.mapper.ActionMapper;
/*     */ import org.apache.struts2.dispatcher.mapper.ActionMapping;
/*     */ import org.apache.struts2.views.util.UrlHelper;
/*     */ 
/*     */ public class ServletUrlRenderer
/*     */   implements UrlRenderer
/*     */ {
/*  50 */   private static final Logger LOG = LoggerFactory.getLogger(ServletUrlRenderer.class);
/*     */   private ActionMapper actionMapper;
/*     */   private UrlHelper urlHelper;
/*     */ 
/*     */   @Inject
/*     */   public void setActionMapper(ActionMapper mapper)
/*     */   {
/*  57 */     this.actionMapper = mapper;
/*     */   }
/*     */   @Inject
/*     */   public void setUrlHelper(UrlHelper urlHelper) {
/*  62 */     this.urlHelper = urlHelper;
/*     */   }
/*     */ 
/*     */   public void renderUrl(Writer writer, UrlProvider urlComponent)
/*     */   {
/*  69 */     String scheme = urlComponent.getHttpServletRequest().getScheme();
/*     */ 
/*  71 */     if (urlComponent.getScheme() != null) {
/*  72 */       scheme = urlComponent.getScheme();
/*     */     }
/*     */ 
/*  76 */     ActionInvocation ai = (ActionInvocation)ActionContext.getContext().get("com.opensymphony.xwork2.ActionContext.actionInvocation");
/*     */     String result;
/*     */     String result;
/*  77 */     if ((urlComponent.getValue() == null) && (urlComponent.getAction() != null)) {
/*  78 */       result = urlComponent.determineActionURL(urlComponent.getAction(), urlComponent.getNamespace(), urlComponent.getMethod(), urlComponent.getHttpServletRequest(), urlComponent.getHttpServletResponse(), urlComponent.getParameters(), scheme, urlComponent.isIncludeContext(), urlComponent.isEncode(), urlComponent.isForceAddSchemeHostAndPort(), urlComponent.isEscapeAmp());
/*     */     }
/*     */     else
/*     */     {
/*     */       String result;
/*  79 */       if ((urlComponent.getValue() == null) && (urlComponent.getAction() == null) && (ai != null))
/*     */       {
/*  82 */         String action = ai.getProxy().getActionName();
/*  83 */         String namespace = ai.getProxy().getNamespace();
/*  84 */         String method = (urlComponent.getMethod() != null) || (!ai.getProxy().isMethodSpecified()) ? urlComponent.getMethod() : ai.getProxy().getMethod();
/*  85 */         result = urlComponent.determineActionURL(action, namespace, method, urlComponent.getHttpServletRequest(), urlComponent.getHttpServletResponse(), urlComponent.getParameters(), scheme, urlComponent.isIncludeContext(), urlComponent.isEncode(), urlComponent.isForceAddSchemeHostAndPort(), urlComponent.isEscapeAmp());
/*     */       } else {
/*  87 */         String _value = urlComponent.getValue();
/*     */ 
/*  91 */         if ((_value != null) && (_value.indexOf("?") > 0)) {
/*  92 */           _value = _value.substring(0, _value.indexOf("?"));
/*     */         }
/*  94 */         result = this.urlHelper.buildUrl(_value, urlComponent.getHttpServletRequest(), urlComponent.getHttpServletResponse(), urlComponent.getParameters(), scheme, urlComponent.isIncludeContext(), urlComponent.isEncode(), urlComponent.isForceAddSchemeHostAndPort(), urlComponent.isEscapeAmp());
/*     */       }
/*     */     }
/*  96 */     String anchor = urlComponent.getAnchor();
/*  97 */     if (StringUtils.isNotEmpty(anchor)) {
/*  98 */       result = result + '#' + urlComponent.findString(anchor);
/*     */     }
/*     */ 
/* 101 */     if (urlComponent.isPutInContext()) {
/* 102 */       String var = urlComponent.getVar();
/* 103 */       if (StringUtils.isNotEmpty(var)) {
/* 104 */         urlComponent.putInContext(result);
/*     */ 
/* 107 */         urlComponent.getHttpServletRequest().setAttribute(var, result);
/*     */       } else {
/*     */         try {
/* 110 */           writer.write(result);
/*     */         } catch (IOException e) {
/* 112 */           throw new StrutsException("IOError: " + e.getMessage(), e);
/*     */         }
/*     */       }
/*     */     } else {
/*     */       try {
/* 117 */         writer.write(result);
/*     */       } catch (IOException e) {
/* 119 */         throw new StrutsException("IOError: " + e.getMessage(), e);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void renderFormUrl(Form formComponent)
/*     */   {
/* 128 */     String namespace = formComponent.determineNamespace(formComponent.namespace, formComponent.getStack(), formComponent.request);
/*     */     String action;
/*     */     String action;
/* 131 */     if (formComponent.action != null) {
/* 132 */       action = formComponent.findString(formComponent.action);
/*     */     }
/*     */     else
/*     */     {
/* 136 */       ActionInvocation ai = (ActionInvocation)formComponent.getStack().getContext().get("com.opensymphony.xwork2.ActionContext.actionInvocation");
/*     */ 
/* 138 */       if (ai != null) {
/* 139 */         String action = ai.getProxy().getActionName();
/* 140 */         namespace = ai.getProxy().getNamespace();
/*     */       }
/*     */       else {
/* 143 */         String uri = formComponent.request.getRequestURI();
/* 144 */         action = uri.substring(uri.lastIndexOf('/'));
/*     */       }
/*     */     }
/*     */ 
/* 148 */     Map actionParams = null;
/* 149 */     if ((action != null) && (action.indexOf("?") > 0)) {
/* 150 */       String queryString = action.substring(action.indexOf("?") + 1);
/* 151 */       actionParams = this.urlHelper.parseQueryString(queryString, false);
/* 152 */       action = action.substring(0, action.indexOf("?"));
/*     */     }
/*     */ 
/* 155 */     ActionMapping nameMapping = this.actionMapper.getMappingFromActionName(action);
/* 156 */     String actionName = nameMapping.getName();
/* 157 */     String actionMethod = nameMapping.getMethod();
/*     */ 
/* 159 */     ActionConfig actionConfig = formComponent.configuration.getRuntimeConfiguration().getActionConfig(namespace, actionName);
/*     */ 
/* 161 */     if (actionConfig != null)
/*     */     {
/* 163 */       ActionMapping mapping = new ActionMapping(actionName, namespace, actionMethod, formComponent.parameters);
/* 164 */       String result = this.urlHelper.buildUrl(formComponent.actionMapper.getUriFromActionMapping(mapping), formComponent.request, formComponent.response, actionParams, null, formComponent.includeContext, true);
/*     */ 
/* 166 */       formComponent.addParameter("action", result);
/*     */ 
/* 170 */       formComponent.addParameter("actionName", actionName);
/*     */       try {
/* 172 */         Class clazz = formComponent.objectFactory.getClassInstance(actionConfig.getClassName());
/* 173 */         formComponent.addParameter("actionClass", clazz);
/*     */       }
/*     */       catch (ClassNotFoundException e)
/*     */       {
/*     */       }
/* 178 */       formComponent.addParameter("namespace", namespace);
/*     */ 
/* 181 */       if (formComponent.name == null) {
/* 182 */         formComponent.addParameter("name", actionName);
/*     */       }
/*     */ 
/* 186 */       if ((formComponent.getId() == null) && (actionName != null))
/* 187 */         formComponent.addParameter("id", formComponent.escape(actionName));
/*     */     }
/* 189 */     else if (action != null)
/*     */     {
/* 196 */       if ((namespace != null) && (LOG.isWarnEnabled())) {
/* 197 */         LOG.warn("No configuration found for the specified action: '" + actionName + "' in namespace: '" + namespace + "'. Form action defaulting to 'action' attribute's literal value.", new String[0]);
/*     */       }
/*     */ 
/* 200 */       String result = this.urlHelper.buildUrl(action, formComponent.request, formComponent.response, null, null, formComponent.includeContext, true);
/* 201 */       formComponent.addParameter("action", result);
/*     */ 
/* 204 */       int slash = result.lastIndexOf('/');
/* 205 */       if (slash != -1)
/* 206 */         formComponent.addParameter("namespace", result.substring(0, slash));
/*     */       else {
/* 208 */         formComponent.addParameter("namespace", "");
/*     */       }
/*     */ 
/* 213 */       String id = formComponent.getId();
/* 214 */       if (id == null) {
/* 215 */         slash = result.lastIndexOf('/');
/* 216 */         int dot = result.indexOf('.', slash);
/* 217 */         if (dot != -1)
/* 218 */           id = result.substring(slash + 1, dot);
/*     */         else {
/* 220 */           id = result.substring(slash + 1);
/*     */         }
/* 222 */         formComponent.addParameter("id", formComponent.escape(id));
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 229 */     formComponent.evaluateClientSideJsEnablement(actionName, namespace, actionMethod);
/*     */   }
/*     */ 
/*     */   public void beforeRenderUrl(UrlProvider urlComponent)
/*     */   {
/* 234 */     if (urlComponent.getValue() != null) {
/* 235 */       urlComponent.setValue(urlComponent.findString(urlComponent.getValue()));
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 242 */       String includeParams = urlComponent.getUrlIncludeParams() != null ? urlComponent.getUrlIncludeParams().toLowerCase() : "get";
/*     */ 
/* 244 */       if (urlComponent.getIncludeParams() != null) {
/* 245 */         includeParams = urlComponent.findString(urlComponent.getIncludeParams());
/*     */       }
/*     */ 
/* 248 */       if ("none".equalsIgnoreCase(includeParams)) {
/* 249 */         mergeRequestParameters(urlComponent.getValue(), urlComponent.getParameters(), Collections.emptyMap());
/* 250 */       } else if ("all".equalsIgnoreCase(includeParams)) {
/* 251 */         mergeRequestParameters(urlComponent.getValue(), urlComponent.getParameters(), urlComponent.getHttpServletRequest().getParameterMap());
/*     */ 
/* 254 */         includeGetParameters(urlComponent);
/* 255 */         includeExtraParameters(urlComponent);
/* 256 */       } else if (("get".equalsIgnoreCase(includeParams)) || ((includeParams == null) && (urlComponent.getValue() == null) && (urlComponent.getAction() == null))) {
/* 257 */         includeGetParameters(urlComponent);
/* 258 */         includeExtraParameters(urlComponent);
/* 259 */       } else if ((includeParams != null) && 
/* 260 */         (LOG.isWarnEnabled())) {
/* 261 */         LOG.warn("Unknown value for includeParams parameter to URL tag: " + includeParams, new String[0]);
/*     */       }
/*     */     }
/*     */     catch (Exception e) {
/* 265 */       if (LOG.isWarnEnabled())
/* 266 */         LOG.warn("Unable to put request parameters (" + urlComponent.getHttpServletRequest().getQueryString() + ") into parameter map.", e, new String[0]);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void includeExtraParameters(UrlProvider urlComponent)
/*     */   {
/* 274 */     if (urlComponent.getExtraParameterProvider() != null)
/* 275 */       mergeRequestParameters(urlComponent.getValue(), urlComponent.getParameters(), urlComponent.getExtraParameterProvider().getExtraParameters());
/*     */   }
/*     */ 
/*     */   private void includeGetParameters(UrlProvider urlComponent) {
/* 279 */     String query = extractQueryString(urlComponent);
/* 280 */     mergeRequestParameters(urlComponent.getValue(), urlComponent.getParameters(), this.urlHelper.parseQueryString(query, false));
/*     */   }
/*     */ 
/*     */   private String extractQueryString(UrlProvider urlComponent)
/*     */   {
/* 285 */     String query = urlComponent.getHttpServletRequest().getQueryString();
/* 286 */     if (query == null) {
/* 287 */       query = (String)urlComponent.getHttpServletRequest().getAttribute("javax.servlet.forward.query_string");
/*     */     }
/*     */ 
/* 290 */     if (query != null)
/*     */     {
/* 292 */       int idx = query.lastIndexOf('#');
/*     */ 
/* 294 */       if (idx != -1) {
/* 295 */         query = query.substring(0, idx);
/*     */       }
/*     */     }
/* 298 */     return query;
/*     */   }
/*     */ 
/*     */   protected void mergeRequestParameters(String value, Map<String, Object> parameters, Map<String, Object> contextParameters)
/*     */   {
/* 319 */     Map mergedParams = new LinkedHashMap(contextParameters);
/*     */ 
/* 325 */     if ((value != null) && (value.trim().length() > 0) && (value.indexOf("?") > 0)) {
/* 326 */       String queryString = value.substring(value.indexOf("?") + 1);
/*     */ 
/* 328 */       mergedParams = this.urlHelper.parseQueryString(queryString, false);
/* 329 */       for (Map.Entry entry : contextParameters.entrySet()) {
/* 330 */         if (!mergedParams.containsKey(entry.getKey())) {
/* 331 */           mergedParams.put(entry.getKey(), entry.getValue());
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 342 */     for (Map.Entry entry : mergedParams.entrySet())
/* 343 */       if (!parameters.containsKey(entry.getKey()))
/* 344 */         parameters.put(entry.getKey(), entry.getValue());
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.components.ServletUrlRenderer
 * JD-Core Version:    0.6.0
 */