/*    */ package org.apache.struts2.components;
/*    */ 
/*    */ import com.opensymphony.xwork2.util.ValueStack;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.apache.struts2.views.annotations.StrutsTag;
/*    */ 
/*    */ @StrutsTag(name="div", tldTagClass="org.apache.struts2.views.jsp.ui.DivTag", description="Render an HTML div", allowDynamicAttributes=true)
/*    */ public class Div extends ClosingUIBean
/*    */ {
/*    */   public static final String TEMPLATE = "div";
/*    */   public static final String TEMPLATE_CLOSE = "div-close";
/* 46 */   public static final String COMPONENT_NAME = Div.class.getName();
/*    */ 
/*    */   public Div(ValueStack stack, HttpServletRequest request, HttpServletResponse response) {
/* 49 */     super(stack, request, response);
/*    */   }
/*    */ 
/*    */   public String getDefaultOpenTemplate() {
/* 53 */     return "div";
/*    */   }
/*    */ 
/*    */   protected String getDefaultTemplate() {
/* 57 */     return "div-close";
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.components.Div
 * JD-Core Version:    0.6.0
 */