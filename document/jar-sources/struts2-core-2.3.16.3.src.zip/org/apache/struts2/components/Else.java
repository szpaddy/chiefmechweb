/*    */ package org.apache.struts2.components;
/*    */ 
/*    */ import com.opensymphony.xwork2.util.ValueStack;
/*    */ import java.io.Writer;
/*    */ import java.util.Map;
/*    */ import org.apache.struts2.views.annotations.StrutsTag;
/*    */ 
/*    */ @StrutsTag(name="else", tldTagClass="org.apache.struts2.views.jsp.ElseTag", description="Else tag")
/*    */ public class Else extends Component
/*    */ {
/*    */   public Else(ValueStack stack)
/*    */   {
/* 64 */     super(stack);
/*    */   }
/*    */ 
/*    */   public boolean start(Writer writer) {
/* 68 */     Map context = this.stack.getContext();
/* 69 */     Boolean ifResult = (Boolean)context.get("struts.if.answer");
/*    */ 
/* 71 */     context.remove("struts.if.answer");
/*    */ 
/* 73 */     return (ifResult != null) && (!ifResult.booleanValue());
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.components.Else
 * JD-Core Version:    0.6.0
 */