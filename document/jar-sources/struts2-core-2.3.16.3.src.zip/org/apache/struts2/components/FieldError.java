/*     */ package org.apache.struts2.components;
/*     */ 
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.struts2.views.annotations.StrutsTag;
/*     */ import org.apache.struts2.views.annotations.StrutsTagAttribute;
/*     */ 
/*     */ @StrutsTag(name="fielderror", tldTagClass="org.apache.struts2.views.jsp.ui.FieldErrorTag", description="Render field error (all or partial depending on param tag nested)if they exists")
/*     */ public class FieldError extends UIBean
/*     */   implements Param.UnnamedParametric
/*     */ {
/*  94 */   private List<String> errorFieldNames = new ArrayList();
/*  95 */   private boolean escape = true;
/*     */   private static final String TEMPLATE = "fielderror";
/*     */ 
/*     */   public FieldError(ValueStack stack, HttpServletRequest request, HttpServletResponse response)
/*     */   {
/*  98 */     super(stack, request, response);
/*     */   }
/*     */ 
/*     */   protected String getDefaultTemplate()
/*     */   {
/* 104 */     return "fielderror";
/*     */   }
/*     */ 
/*     */   protected void evaluateExtraParams()
/*     */   {
/* 109 */     super.evaluateExtraParams();
/*     */ 
/* 111 */     if (this.errorFieldNames != null) {
/* 112 */       addParameter("errorFieldNames", this.errorFieldNames);
/*     */     }
/* 114 */     addParameter("escape", Boolean.valueOf(this.escape));
/*     */   }
/*     */ 
/*     */   public void addParameter(Object value) {
/* 118 */     if (value != null)
/* 119 */       this.errorFieldNames.add(value.toString());
/*     */   }
/*     */ 
/*     */   public List<String> getFieldErrorFieldNames()
/*     */   {
/* 124 */     return this.errorFieldNames;
/*     */   }
/*     */   @StrutsTagAttribute(description="Field name for single field attribute usage", type="String")
/*     */   public void setFieldName(String fieldName) {
/* 129 */     addParameter(fieldName);
/*     */   }
/*     */   @StrutsTagAttribute(description=" Whether to escape HTML", type="Boolean", defaultValue="true")
/*     */   public void setEscape(boolean escape) {
/* 134 */     this.escape = escape;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.components.FieldError
 * JD-Core Version:    0.6.0
 */