/*    */ package org.apache.struts2.components;
/*    */ 
/*    */ import com.opensymphony.xwork2.util.ValueStack;
/*    */ import java.util.Map;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.apache.commons.lang3.StringUtils;
/*    */ import org.apache.struts2.views.annotations.StrutsTag;
/*    */ 
/*    */ @StrutsTag(name="doubleselect", tldTagClass="org.apache.struts2.views.jsp.ui.DoubleSelectTag", description="Renders two HTML select elements with second one changing displayed values depending on selected entry of first one.")
/*    */ public class DoubleSelect extends DoubleListUIBean
/*    */ {
/*    */   public static final String TEMPLATE = "doubleselect";
/*    */ 
/*    */   public DoubleSelect(ValueStack stack, HttpServletRequest request, HttpServletResponse response)
/*    */   {
/* 53 */     super(stack, request, response);
/*    */   }
/*    */ 
/*    */   protected String getDefaultTemplate() {
/* 57 */     return "doubleselect";
/*    */   }
/*    */ 
/*    */   public void evaluateExtraParams() {
/* 61 */     super.evaluateExtraParams();
/* 62 */     StringBuilder onchangeParam = new StringBuilder();
/* 63 */     onchangeParam.append(getParameters().get("id")).append("Redirect(this.selectedIndex)");
/* 64 */     if (StringUtils.isNotEmpty(this.onchange)) {
/* 65 */       onchangeParam.append(";").append(this.onchange);
/*    */     }
/*    */ 
/* 68 */     addParameter("onchange", onchangeParam.toString());
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.components.DoubleSelect
 * JD-Core Version:    0.6.0
 */