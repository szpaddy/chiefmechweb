/*    */ package org.apache.struts2.components;
/*    */ 
/*    */ import com.opensymphony.xwork2.util.ValueStack;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.apache.struts2.views.annotations.StrutsTag;
/*    */ 
/*    */ @StrutsTag(name="hidden", tldTagClass="org.apache.struts2.views.jsp.ui.HiddenTag", description="Render a hidden input field", allowDynamicAttributes=true)
/*    */ public class Hidden extends UIBean
/*    */ {
/*    */   public static final String TEMPLATE = "hidden";
/*    */ 
/*    */   public Hidden(ValueStack stack, HttpServletRequest request, HttpServletResponse response)
/*    */   {
/* 62 */     super(stack, request, response);
/*    */   }
/*    */ 
/*    */   protected String getDefaultTemplate() {
/* 66 */     return "hidden";
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.components.Hidden
 * JD-Core Version:    0.6.0
 */