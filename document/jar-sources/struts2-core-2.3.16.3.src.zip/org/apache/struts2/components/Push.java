/*     */ package org.apache.struts2.components;
/*     */ 
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import java.io.Writer;
/*     */ import org.apache.struts2.views.annotations.StrutsTag;
/*     */ import org.apache.struts2.views.annotations.StrutsTagAttribute;
/*     */ 
/*     */ @StrutsTag(name="push", tldTagClass="org.apache.struts2.views.jsp.PushTag", description="Push value on stack for simplified usage.")
/*     */ public class Push extends Component
/*     */ {
/*     */   protected String value;
/*     */   protected boolean pushed;
/*     */ 
/*     */   public Push(ValueStack stack)
/*     */   {
/* 119 */     super(stack);
/*     */   }
/*     */ 
/*     */   public boolean start(Writer writer) {
/* 123 */     boolean result = super.start(writer);
/*     */ 
/* 125 */     ValueStack stack = getStack();
/*     */ 
/* 127 */     if (stack != null) {
/* 128 */       stack.push(findValue(this.value, "value", "You must specify a value to push on the stack. Example: person"));
/* 129 */       this.pushed = true;
/*     */     } else {
/* 131 */       this.pushed = false;
/*     */     }
/*     */ 
/* 134 */     return result;
/*     */   }
/*     */ 
/*     */   public boolean end(Writer writer, String body) {
/* 138 */     ValueStack stack = getStack();
/*     */ 
/* 140 */     if ((this.pushed) && (stack != null)) {
/* 141 */       stack.pop();
/*     */     }
/*     */ 
/* 144 */     return super.end(writer, body);
/*     */   }
/*     */   @StrutsTagAttribute(description="Value to push on stack", required=true)
/*     */   public void setValue(String value) {
/* 149 */     this.value = value;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.components.Push
 * JD-Core Version:    0.6.0
 */