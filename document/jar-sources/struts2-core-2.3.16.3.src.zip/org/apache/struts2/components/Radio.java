/*    */ package org.apache.struts2.components;
/*    */ 
/*    */ import com.opensymphony.xwork2.util.ValueStack;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.apache.struts2.views.annotations.StrutsTag;
/*    */ 
/*    */ @StrutsTag(name="radio", tldTagClass="org.apache.struts2.views.jsp.ui.RadioTag", description="Renders a radio button input field", allowDynamicAttributes=true)
/*    */ public class Radio extends ListUIBean
/*    */ {
/*    */   public static final String TEMPLATE = "radiomap";
/*    */ 
/*    */   public Radio(ValueStack stack, HttpServletRequest request, HttpServletResponse response)
/*    */   {
/* 63 */     super(stack, request, response);
/*    */   }
/*    */ 
/*    */   protected String getDefaultTemplate() {
/* 67 */     return "radiomap";
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.components.Radio
 * JD-Core Version:    0.6.0
 */