/*    */ package org.apache.struts2.components;
/*    */ 
/*    */ import com.opensymphony.xwork2.util.ValueStack;
/*    */ import com.opensymphony.xwork2.util.logging.Logger;
/*    */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*    */ import java.io.Writer;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.apache.struts2.views.annotations.StrutsTagAttribute;
/*    */ 
/*    */ public abstract class ClosingUIBean extends UIBean
/*    */ {
/* 37 */   private static final Logger LOG = LoggerFactory.getLogger(ClosingUIBean.class);
/*    */   String openTemplate;
/*    */ 
/*    */   protected ClosingUIBean(ValueStack stack, HttpServletRequest request, HttpServletResponse response)
/*    */   {
/* 40 */     super(stack, request, response);
/*    */   }
/*    */ 
/*    */   public abstract String getDefaultOpenTemplate();
/*    */ 
/*    */   @StrutsTagAttribute(description="Set template to use for opening the rendered html.")
/*    */   public void setOpenTemplate(String openTemplate) {
/* 49 */     this.openTemplate = openTemplate;
/*    */   }
/*    */ 
/*    */   public boolean start(Writer writer) {
/* 53 */     boolean result = super.start(writer);
/*    */     try {
/* 55 */       evaluateParams();
/*    */ 
/* 57 */       mergeTemplate(writer, buildTemplateName(this.openTemplate, getDefaultOpenTemplate()));
/*    */     } catch (Exception e) {
/* 59 */       LOG.error("Could not open template", e, new String[0]);
/*    */     }
/*    */ 
/* 62 */     return result;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.components.ClosingUIBean
 * JD-Core Version:    0.6.0
 */