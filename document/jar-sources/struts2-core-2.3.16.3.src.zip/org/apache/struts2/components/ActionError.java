/*    */ package org.apache.struts2.components;
/*    */ 
/*    */ import com.opensymphony.xwork2.util.ValueStack;
/*    */ import java.util.Collection;
/*    */ import java.util.List;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.apache.commons.lang3.StringUtils;
/*    */ import org.apache.struts2.views.annotations.StrutsTag;
/*    */ import org.apache.struts2.views.annotations.StrutsTagAttribute;
/*    */ 
/*    */ @StrutsTag(name="actionerror", tldBodyContent="empty", tldTagClass="org.apache.struts2.views.jsp.ui.ActionErrorTag", description="Render action errors if they exists")
/*    */ public class ActionError extends UIBean
/*    */ {
/*    */   public static final String TEMPLATE = "actionerror";
/* 61 */   private boolean escape = true;
/*    */ 
/*    */   public ActionError(ValueStack stack, HttpServletRequest request, HttpServletResponse response) {
/* 64 */     super(stack, request, response);
/*    */   }
/*    */ 
/*    */   protected String getDefaultTemplate() {
/* 68 */     return "actionerror";
/*    */   }
/*    */ 
/*    */   protected void evaluateExtraParams() {
/* 72 */     boolean isEmptyList = true;
/* 73 */     Collection actionMessages = (List)findValue("actionErrors");
/* 74 */     if (actionMessages != null) {
/* 75 */       for (String message : actionMessages) {
/* 76 */         if (StringUtils.isNotBlank(message)) {
/* 77 */           isEmptyList = false;
/* 78 */           break;
/*    */         }
/*    */       }
/*    */     }
/*    */ 
/* 83 */     addParameter("isEmptyList", Boolean.valueOf(isEmptyList));
/* 84 */     addParameter("escape", Boolean.valueOf(this.escape));
/*    */   }
/*    */   @StrutsTagAttribute(description=" Whether to escape HTML", type="Boolean", defaultValue="true")
/*    */   public void setEscape(boolean escape) {
/* 89 */     this.escape = escape;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.components.ActionError
 * JD-Core Version:    0.6.0
 */