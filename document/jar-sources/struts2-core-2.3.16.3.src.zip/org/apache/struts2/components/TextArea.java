/*     */ package org.apache.struts2.components;
/*     */ 
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.struts2.views.annotations.StrutsTag;
/*     */ import org.apache.struts2.views.annotations.StrutsTagAttribute;
/*     */ 
/*     */ @StrutsTag(name="textarea", tldTagClass="org.apache.struts2.views.jsp.ui.TextareaTag", description="Render HTML textarea tag.", allowDynamicAttributes=true)
/*     */ public class TextArea extends UIBean
/*     */ {
/*     */   public static final String TEMPLATE = "textarea";
/*     */   protected String cols;
/*     */   protected String readonly;
/*     */   protected String rows;
/*     */   protected String wrap;
/*     */ 
/*     */   public TextArea(ValueStack stack, HttpServletRequest request, HttpServletResponse response)
/*     */   {
/*  62 */     super(stack, request, response);
/*     */   }
/*     */ 
/*     */   protected String getDefaultTemplate() {
/*  66 */     return "textarea";
/*     */   }
/*     */ 
/*     */   public void evaluateExtraParams() {
/*  70 */     super.evaluateExtraParams();
/*     */ 
/*  72 */     if (this.readonly != null) {
/*  73 */       addParameter("readonly", findValue(this.readonly, Boolean.class));
/*     */     }
/*     */ 
/*  76 */     if (this.cols != null) {
/*  77 */       addParameter("cols", findString(this.cols));
/*     */     }
/*     */ 
/*  80 */     if (this.rows != null) {
/*  81 */       addParameter("rows", findString(this.rows));
/*     */     }
/*     */ 
/*  84 */     if (this.wrap != null)
/*  85 */       addParameter("wrap", findString(this.wrap));
/*     */   }
/*     */ 
/*     */   @StrutsTagAttribute(description="HTML cols attribute", type="Integer")
/*     */   public void setCols(String cols) {
/*  91 */     this.cols = cols;
/*     */   }
/*     */   @StrutsTagAttribute(description="Whether the textarea is readonly", type="Boolean", defaultValue="false")
/*     */   public void setReadonly(String readonly) {
/*  96 */     this.readonly = readonly;
/*     */   }
/*     */   @StrutsTagAttribute(description="HTML rows attribute", type="Integer")
/*     */   public void setRows(String rows) {
/* 101 */     this.rows = rows;
/*     */   }
/*     */   @StrutsTagAttribute(description="HTML wrap attribute")
/*     */   public void setWrap(String wrap) {
/* 106 */     this.wrap = wrap;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.components.TextArea
 * JD-Core Version:    0.6.0
 */