/*     */ package org.apache.struts2.components;
/*     */ 
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import com.opensymphony.xwork2.util.logging.Logger;
/*     */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*     */ import java.io.Writer;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.struts2.views.annotations.StrutsTag;
/*     */ import org.apache.struts2.views.annotations.StrutsTagAttribute;
/*     */ 
/*     */ @StrutsTag(name="url", tldTagClass="org.apache.struts2.views.jsp.URLTag", description="This tag is used to create a URL")
/*     */ public class URL extends ContextBean
/*     */ {
/* 113 */   private static final Logger LOG = LoggerFactory.getLogger(URL.class);
/*     */   private UrlProvider urlProvider;
/*     */   private UrlRenderer urlRenderer;
/*     */ 
/*     */   public URL(ValueStack stack, HttpServletRequest req, HttpServletResponse res)
/*     */   {
/* 118 */     super(stack);
/* 119 */     this.urlProvider = new ComponentUrlProvider(this, this.parameters);
/* 120 */     this.urlProvider.setHttpServletRequest(req);
/* 121 */     this.urlProvider.setHttpServletResponse(res);
/*     */   }
/*     */   @Inject("struts.url.includeParams")
/*     */   public void setUrlIncludeParams(String urlIncludeParams) {
/* 126 */     this.urlProvider.setUrlIncludeParams(urlIncludeParams);
/*     */   }
/*     */   @Inject
/*     */   public void setUrlRenderer(UrlRenderer urlRenderer) {
/* 131 */     this.urlProvider.setUrlRenderer(urlRenderer);
/* 132 */     this.urlRenderer = urlRenderer;
/*     */   }
/*     */   @Inject(required=false)
/*     */   public void setExtraParameterProvider(ExtraParameterProvider provider) {
/* 137 */     this.urlProvider.setExtraParameterProvider(provider);
/*     */   }
/*     */ 
/*     */   public boolean start(Writer writer) {
/* 141 */     boolean result = super.start(writer);
/* 142 */     this.urlRenderer.beforeRenderUrl(this.urlProvider);
/* 143 */     return result;
/*     */   }
/*     */ 
/*     */   public boolean end(Writer writer, String body) {
/* 147 */     this.urlRenderer.renderUrl(writer, this.urlProvider);
/* 148 */     return super.end(writer, body);
/*     */   }
/*     */ 
/*     */   public String findString(String expr) {
/* 152 */     return super.findString(expr);
/*     */   }
/*     */ 
/*     */   public UrlProvider getUrlProvider() {
/* 156 */     return this.urlProvider;
/*     */   }
/*     */   @StrutsTagAttribute(description="The includeParams attribute may have the value 'none', 'get' or 'all'", defaultValue="none")
/*     */   public void setIncludeParams(String includeParams) {
/* 161 */     this.urlProvider.setIncludeParams(includeParams);
/*     */   }
/*     */   @StrutsTagAttribute(description="Set scheme attribute")
/*     */   public void setScheme(String scheme) {
/* 166 */     this.urlProvider.setScheme(scheme);
/*     */   }
/*     */   @StrutsTagAttribute(description="The target value to use, if not using action")
/*     */   public void setValue(String value) {
/* 171 */     this.urlProvider.setValue(value);
/*     */   }
/*     */   @StrutsTagAttribute(description="The action to generate the URL for, if not using value")
/*     */   public void setAction(String action) {
/* 176 */     this.urlProvider.setAction(action);
/*     */   }
/*     */   @StrutsTagAttribute(description="The namespace to use")
/*     */   public void setNamespace(String namespace) {
/* 181 */     this.urlProvider.setNamespace(namespace);
/*     */   }
/*     */   @StrutsTagAttribute(description="The method of action to use")
/*     */   public void setMethod(String method) {
/* 186 */     this.urlProvider.setMethod(method);
/*     */   }
/*     */   @StrutsTagAttribute(description="Whether to encode parameters", type="Boolean", defaultValue="true")
/*     */   public void setEncode(boolean encode) {
/* 191 */     this.urlProvider.setEncode(encode);
/*     */   }
/*     */   @StrutsTagAttribute(description="Whether actual context should be included in URL", type="Boolean", defaultValue="true")
/*     */   public void setIncludeContext(boolean includeContext) {
/* 196 */     this.urlProvider.setIncludeContext(includeContext);
/*     */   }
/*     */   @StrutsTagAttribute(description="The resulting portlet mode")
/*     */   public void setPortletMode(String portletMode) {
/* 201 */     this.urlProvider.setPortletMode(portletMode);
/*     */   }
/*     */   @StrutsTagAttribute(description="The resulting portlet window state")
/*     */   public void setWindowState(String windowState) {
/* 206 */     this.urlProvider.setWindowState(windowState);
/*     */   }
/*     */   @StrutsTagAttribute(description="Specifies if this should be a portlet render or action URL. Default is \"render\". To create an action URL, use \"action\".")
/*     */   public void setPortletUrlType(String portletUrlType) {
/* 211 */     this.urlProvider.setPortletUrlType(portletUrlType);
/*     */   }
/*     */   @StrutsTagAttribute(description="The anchor for this URL")
/*     */   public void setAnchor(String anchor) {
/* 216 */     this.urlProvider.setAnchor(anchor);
/*     */   }
/*     */   @StrutsTagAttribute(description="Specifies whether to escape ampersand (&amp;) to (&amp;amp;) or not", type="Boolean", defaultValue="true")
/*     */   public void setEscapeAmp(boolean escapeAmp) {
/* 221 */     this.urlProvider.setEscapeAmp(escapeAmp);
/*     */   }
/*     */   @StrutsTagAttribute(description="Specifies whether to force the addition of scheme, host and port or not", type="Boolean", defaultValue="false")
/*     */   public void setForceAddSchemeHostAndPort(boolean forceAddSchemeHostAndPort) {
/* 226 */     this.urlProvider.setForceAddSchemeHostAndPort(forceAddSchemeHostAndPort);
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.components.URL
 * JD-Core Version:    0.6.0
 */