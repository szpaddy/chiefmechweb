/*     */ package org.apache.struts2.components;
/*     */ 
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.Collection;
/*     */ import java.util.Map;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.struts2.util.ContainUtil;
/*     */ import org.apache.struts2.util.MakeIterator;
/*     */ import org.apache.struts2.views.annotations.StrutsTagAttribute;
/*     */ 
/*     */ public abstract class ListUIBean extends UIBean
/*     */ {
/*     */   protected Object list;
/*     */   protected String listKey;
/*     */   protected String listValue;
/*     */   protected String listCssClass;
/*     */   protected String listCssStyle;
/*     */   protected String listTitle;
/*  57 */   protected boolean throwExceptionOnNullValueAttribute = false;
/*     */ 
/*     */   protected ListUIBean(ValueStack stack, HttpServletRequest request, HttpServletResponse response) {
/*  60 */     super(stack, request, response);
/*     */   }
/*     */ 
/*     */   public void evaluateExtraParams() {
/*  64 */     Object value = null;
/*     */ 
/*  66 */     if (this.list == null) {
/*  67 */       this.list = this.parameters.get("list");
/*     */     }
/*     */ 
/*  70 */     if ((this.list instanceof String))
/*  71 */       value = findValue((String)this.list);
/*  72 */     else if ((this.list instanceof Collection))
/*  73 */       value = this.list;
/*  74 */     else if (MakeIterator.isIterable(this.list)) {
/*  75 */       value = MakeIterator.convert(this.list);
/*     */     }
/*  77 */     if (value == null) {
/*  78 */       if (this.throwExceptionOnNullValueAttribute)
/*     */       {
/*  80 */         value = findValue(this.list == null ? (String)this.list : this.list.toString(), "list", "The requested list key '" + this.list + "' could not be resolved as a collection/array/map/enumeration/iterator type. " + "Example: people or people.{name}");
/*     */       }
/*     */       else
/*     */       {
/*  86 */         value = findValue(this.list == null ? (String)this.list : this.list.toString());
/*     */       }
/*     */     }
/*     */ 
/*  90 */     if ((value instanceof Collection))
/*  91 */       addParameter("list", value);
/*     */     else {
/*  93 */       addParameter("list", MakeIterator.convert(value));
/*     */     }
/*     */ 
/*  96 */     if ((value instanceof Collection))
/*  97 */       addParameter("listSize", Integer.valueOf(((Collection)value).size()));
/*  98 */     else if ((value instanceof Map))
/*  99 */       addParameter("listSize", Integer.valueOf(((Map)value).size()));
/* 100 */     else if ((value != null) && (value.getClass().isArray())) {
/* 101 */       addParameter("listSize", Integer.valueOf(Array.getLength(value)));
/*     */     }
/*     */ 
/* 104 */     if (this.listKey != null) {
/* 105 */       this.listKey = stripExpressionIfAltSyntax(this.listKey);
/* 106 */       addParameter("listKey", this.listKey);
/* 107 */     } else if ((value instanceof Map)) {
/* 108 */       addParameter("listKey", "key");
/*     */     }
/*     */ 
/* 111 */     if (this.listValue != null) {
/* 112 */       this.listValue = stripExpressionIfAltSyntax(this.listValue);
/* 113 */       addParameter("listValue", this.listValue);
/* 114 */     } else if ((value instanceof Map)) {
/* 115 */       addParameter("listValue", "value");
/*     */     }
/*     */ 
/* 118 */     if ((this.listCssClass != null) && (this.listCssClass.trim().length() > 0)) {
/* 119 */       addParameter("listCssClass", this.listCssClass);
/*     */     }
/*     */ 
/* 122 */     if ((this.listCssStyle != null) && (this.listCssStyle.trim().length() > 0)) {
/* 123 */       addParameter("listCssStyle", this.listCssStyle);
/*     */     }
/*     */ 
/* 126 */     if ((this.listTitle != null) && (this.listTitle.trim().length() > 0))
/* 127 */       addParameter("listTitle", this.listTitle);
/*     */   }
/*     */ 
/*     */   public boolean contains(Object obj1, Object obj2)
/*     */   {
/* 132 */     return ContainUtil.contains(obj1, obj2);
/*     */   }
/*     */ 
/*     */   protected Class getValueClassType() {
/* 136 */     return null;
/*     */   }
/*     */ 
/*     */   @StrutsTagAttribute(description="Iterable source to populate from. If the list is a Map (key, value), the Map key will become the option 'value' parameter and the Map value will become the option body.", required=true)
/*     */   public void setList(Object list) {
/* 142 */     this.list = list;
/*     */   }
/*     */   @StrutsTagAttribute(description=" Property of list objects to get field value from")
/*     */   public void setListKey(String listKey) {
/* 147 */     this.listKey = listKey;
/*     */   }
/*     */   @StrutsTagAttribute(description="Property of list objects to get field content from")
/*     */   public void setListValue(String listValue) {
/* 152 */     this.listValue = listValue;
/*     */   }
/*     */   @StrutsTagAttribute(description="Property of list objects to get css class from")
/*     */   public void setListCssClass(String listCssClass) {
/* 157 */     this.listCssClass = listCssClass;
/*     */   }
/*     */   @StrutsTagAttribute(description="Property of list objects to get css style from")
/*     */   public void setListCssStyle(String listCssStyle) {
/* 162 */     this.listCssStyle = listCssStyle;
/*     */   }
/*     */   @StrutsTagAttribute(description="Property of list objects to get title from")
/*     */   public void setListTitle(String listTitle) {
/* 167 */     this.listTitle = listTitle;
/*     */   }
/*     */ 
/*     */   public void setThrowExceptionOnNullValueAttribute(boolean throwExceptionOnNullValueAttribute)
/*     */   {
/* 172 */     this.throwExceptionOnNullValueAttribute = throwExceptionOnNullValueAttribute;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.components.ListUIBean
 * JD-Core Version:    0.6.0
 */