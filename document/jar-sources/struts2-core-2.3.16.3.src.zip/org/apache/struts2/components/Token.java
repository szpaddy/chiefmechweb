/*     */ package org.apache.struts2.components;
/*     */ 
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import java.util.Map;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.struts2.util.TokenHelper;
/*     */ import org.apache.struts2.views.annotations.StrutsTag;
/*     */ 
/*     */ @StrutsTag(name="token", tldTagClass="org.apache.struts2.views.jsp.ui.TokenTag", description="Stop double-submission of forms")
/*     */ public class Token extends UIBean
/*     */ {
/*     */   public static final String TEMPLATE = "token";
/*     */ 
/*     */   public Token(ValueStack stack, HttpServletRequest request, HttpServletResponse response)
/*     */   {
/*  61 */     super(stack, request, response);
/*     */   }
/*     */ 
/*     */   protected String getDefaultTemplate() {
/*  65 */     return "token";
/*     */   }
/*     */ 
/*     */   protected void evaluateExtraParams()
/*     */   {
/*  75 */     super.evaluateExtraParams();
/*     */ 
/*  78 */     Map parameters = getParameters();
/*     */     String tokenName;
/*     */     String tokenName;
/*  80 */     if (parameters.containsKey("name")) {
/*  81 */       tokenName = (String)parameters.get("name");
/*     */     }
/*     */     else
/*     */     {
/*     */       String tokenName;
/*  83 */       if (this.name == null) {
/*  84 */         tokenName = "token";
/*     */       } else {
/*  86 */         tokenName = findString(this.name);
/*     */ 
/*  88 */         if (tokenName == null) {
/*  89 */           tokenName = this.name;
/*     */         }
/*     */       }
/*     */ 
/*  93 */       addParameter("name", tokenName);
/*     */     }
/*     */ 
/*  96 */     String token = buildToken(tokenName);
/*  97 */     addParameter("token", token);
/*  98 */     addParameter("tokenNameField", "struts.token.name");
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public String getTokenNameField()
/*     */   {
/* 106 */     return "struts.token.name";
/*     */   }
/*     */ 
/*     */   private String buildToken(String name) {
/* 110 */     Map context = this.stack.getContext();
/* 111 */     Object myToken = context.get(name);
/*     */ 
/* 113 */     if (myToken == null) {
/* 114 */       myToken = TokenHelper.setToken(name);
/* 115 */       context.put(name, myToken);
/*     */     }
/*     */ 
/* 118 */     return myToken.toString();
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.components.Token
 * JD-Core Version:    0.6.0
 */