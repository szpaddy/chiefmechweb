/*     */ package org.apache.struts2.components;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionContext;
/*     */ import com.opensymphony.xwork2.ActionInvocation;
/*     */ import com.opensymphony.xwork2.ActionProxy;
/*     */ import com.opensymphony.xwork2.ActionProxyFactory;
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import com.opensymphony.xwork2.util.ValueStackFactory;
/*     */ import com.opensymphony.xwork2.util.logging.Logger;
/*     */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.servlet.jsp.PageContext;
/*     */ import org.apache.struts2.StrutsException;
/*     */ import org.apache.struts2.dispatcher.Dispatcher;
/*     */ import org.apache.struts2.dispatcher.RequestMap;
/*     */ import org.apache.struts2.dispatcher.mapper.ActionMapper;
/*     */ import org.apache.struts2.dispatcher.mapper.ActionMapping;
/*     */ import org.apache.struts2.views.annotations.StrutsTag;
/*     */ import org.apache.struts2.views.annotations.StrutsTagAttribute;
/*     */ import org.apache.struts2.views.jsp.TagUtils;
/*     */ 
/*     */ @StrutsTag(name="action", tldTagClass="org.apache.struts2.views.jsp.ActionTag", description="Execute an action from within a view")
/*     */ public class ActionComponent extends ContextBean
/*     */ {
/* 124 */   private static final Logger LOG = LoggerFactory.getLogger(ActionComponent.class);
/*     */   protected HttpServletResponse res;
/*     */   protected HttpServletRequest req;
/*     */   protected ValueStackFactory valueStackFactory;
/*     */   protected ActionProxyFactory actionProxyFactory;
/*     */   protected ActionProxy proxy;
/*     */   protected String name;
/*     */   protected String namespace;
/*     */   protected boolean executeResult;
/*     */   protected boolean ignoreContextParams;
/* 136 */   protected boolean flush = true;
/*     */   protected boolean rethrowException;
/*     */ 
/*     */   public ActionComponent(ValueStack stack, HttpServletRequest req, HttpServletResponse res)
/*     */   {
/* 140 */     super(stack);
/* 141 */     this.req = req;
/* 142 */     this.res = res;
/*     */   }
/*     */ 
/*     */   @Inject
/*     */   public void setActionProxyFactory(ActionProxyFactory actionProxyFactory)
/*     */   {
/* 150 */     this.actionProxyFactory = actionProxyFactory;
/*     */   }
/*     */   @Inject
/*     */   public void setValueStackFactory(ValueStackFactory valueStackFactory) {
/* 155 */     this.valueStackFactory = valueStackFactory;
/*     */   }
/*     */   @Inject
/*     */   public void setActionMapper(ActionMapper mapper) {
/* 160 */     this.actionMapper = mapper;
/*     */   }
/*     */ 
/*     */   public boolean end(Writer writer, String body) {
/* 164 */     boolean end = super.end(writer, "", false);
/*     */     try {
/* 166 */       if (this.flush) {
/*     */         try {
/* 168 */           writer.flush();
/*     */         } catch (IOException e) {
/* 170 */           if (LOG.isWarnEnabled()) {
/* 171 */             LOG.warn("error while trying to flush writer ", e, new String[0]);
/*     */           }
/*     */         }
/*     */       }
/* 175 */       executeAction();
/*     */ 
/* 177 */       if ((getVar() != null) && (this.proxy != null))
/* 178 */         getStack().setValue("#attr['" + getVar() + "']", this.proxy.getAction());
/*     */     }
/*     */     finally
/*     */     {
/* 182 */       popComponentStack();
/*     */     }
/* 184 */     return end;
/*     */   }
/*     */ 
/*     */   protected Map createExtraContext() {
/* 188 */     Map newParams = createParametersForContext();
/*     */ 
/* 190 */     ActionContext ctx = new ActionContext(this.stack.getContext());
/* 191 */     ServletContext servletContext = (ServletContext)ctx.get("com.opensymphony.xwork2.dispatcher.ServletContext");
/* 192 */     PageContext pageContext = (PageContext)ctx.get("com.opensymphony.xwork2.dispatcher.PageContext");
/* 193 */     Map session = ctx.getSession();
/* 194 */     Map application = ctx.getApplication();
/*     */ 
/* 196 */     Dispatcher du = Dispatcher.getInstance();
/* 197 */     Map extraContext = du.createContextMap(new RequestMap(this.req), newParams, session, application, this.req, this.res, servletContext);
/*     */ 
/* 205 */     ValueStack newStack = this.valueStackFactory.createValueStack(this.stack);
/* 206 */     extraContext.put("com.opensymphony.xwork2.util.ValueStack.ValueStack", newStack);
/*     */ 
/* 209 */     extraContext.put("com.opensymphony.xwork2.dispatcher.PageContext", pageContext);
/*     */ 
/* 211 */     return extraContext;
/*     */   }
/*     */ 
/*     */   protected Map<String, String[]> createParametersForContext()
/*     */   {
/* 221 */     Map parentParams = null;
/*     */ 
/* 223 */     if (!this.ignoreContextParams) {
/* 224 */       parentParams = new ActionContext(getStack().getContext()).getParameters();
/*     */     }
/*     */ 
/* 227 */     Map newParams = parentParams != null ? new HashMap(parentParams) : new HashMap();
/*     */ 
/* 231 */     if (this.parameters != null) {
/* 232 */       Map params = new HashMap();
/* 233 */       for (Iterator i = this.parameters.entrySet().iterator(); i.hasNext(); ) {
/* 234 */         Map.Entry entry = (Map.Entry)i.next();
/* 235 */         String key = (String)entry.getKey();
/* 236 */         Object val = entry.getValue();
/* 237 */         if ((val.getClass().isArray()) && (String.class == val.getClass().getComponentType()))
/* 238 */           params.put(key, (String[])(String[])val);
/*     */         else {
/* 240 */           params.put(key, new String[] { val.toString() });
/*     */         }
/*     */       }
/* 243 */       newParams.putAll(params);
/*     */     }
/* 245 */     return newParams;
/*     */   }
/*     */ 
/*     */   public ActionProxy getProxy() {
/* 249 */     return this.proxy;
/*     */   }
/*     */ 
/*     */   protected void executeAction()
/*     */   {
/* 261 */     String actualName = findString(this.name, "name", "Action name is required. Example: updatePerson");
/*     */ 
/* 263 */     if (actualName == null) {
/* 264 */       throw new StrutsException("Unable to find value for name " + this.name);
/*     */     }
/*     */ 
/* 271 */     ActionMapping mapping = this.actionMapper.getMappingFromActionName(actualName);
/* 272 */     String actionName = mapping.getName();
/* 273 */     String methodName = mapping.getMethod();
/*     */     String namespace;
/*     */     String namespace;
/* 277 */     if (this.namespace == null)
/* 278 */       namespace = TagUtils.buildNamespace(this.actionMapper, getStack(), this.req);
/*     */     else {
/* 280 */       namespace = findString(this.namespace);
/*     */     }
/*     */ 
/* 284 */     ValueStack stack = getStack();
/*     */ 
/* 286 */     ActionInvocation inv = ActionContext.getContext().getActionInvocation();
/*     */     try
/*     */     {
/* 289 */       this.proxy = this.actionProxyFactory.createActionProxy(namespace, actionName, methodName, createExtraContext(), this.executeResult, true);
/*     */ 
/* 291 */       this.req.setAttribute("struts.valueStack", this.proxy.getInvocation().getStack());
/* 292 */       this.req.setAttribute("struts.actiontag.invocation", Boolean.TRUE);
/* 293 */       this.proxy.execute();
/*     */     }
/*     */     catch (Exception e) {
/* 296 */       String message = "Could not execute action: " + namespace + "/" + actualName;
/* 297 */       LOG.error(message, e, new String[0]);
/* 298 */       if (this.rethrowException)
/* 299 */         throw new StrutsException(message, e);
/*     */     }
/*     */     finally {
/* 302 */       this.req.removeAttribute("struts.actiontag.invocation");
/*     */ 
/* 304 */       this.req.setAttribute("struts.valueStack", stack);
/* 305 */       if (inv != null) {
/* 306 */         ActionContext.getContext().setActionInvocation(inv);
/*     */       }
/*     */     }
/*     */ 
/* 310 */     if ((getVar() != null) && (this.proxy != null))
/* 311 */       putInContext(this.proxy.getAction());
/*     */   }
/*     */ 
/*     */   @StrutsTagAttribute(required=true, description="Name of the action to be executed (without the extension suffix eg. .action)")
/*     */   public void setName(String name) {
/* 317 */     this.name = name;
/*     */   }
/*     */   @StrutsTagAttribute(description="Namespace for action to call", defaultValue="namespace from where tag is used")
/*     */   public void setNamespace(String namespace) {
/* 322 */     this.namespace = namespace;
/*     */   }
/*     */   @StrutsTagAttribute(description="Whether the result of this action (probably a view) should be executed/rendered", type="Boolean", defaultValue="false")
/*     */   public void setExecuteResult(boolean executeResult) {
/* 327 */     this.executeResult = executeResult;
/*     */   }
/*     */   @StrutsTagAttribute(description="Whether the request parameters are to be included when the action is invoked", type="Boolean", defaultValue="false")
/*     */   public void setIgnoreContextParams(boolean ignoreContextParams) {
/* 332 */     this.ignoreContextParams = ignoreContextParams;
/*     */   }
/*     */   @StrutsTagAttribute(description="Whether the writer should be flush upon end of action component tag, default to true", type="Boolean", defaultValue="true")
/*     */   public void setFlush(boolean flush) {
/* 337 */     this.flush = flush;
/*     */   }
/*     */   @StrutsTagAttribute(description="Whether an exception should be rethrown, if the target action throws an exception", type="Boolean", defaultValue="false")
/*     */   public void setRethrowException(boolean rethrowException) {
/* 342 */     this.rethrowException = rethrowException;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.components.ActionComponent
 * JD-Core Version:    0.6.0
 */