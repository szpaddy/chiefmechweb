package org.apache.struts2.components;

import java.util.Map;

public abstract interface ExtraParameterProvider
{
  public abstract Map getExtraParameters();
}

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.components.ExtraParameterProvider
 * JD-Core Version:    0.6.0
 */