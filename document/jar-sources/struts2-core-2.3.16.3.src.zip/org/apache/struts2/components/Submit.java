/*     */ package org.apache.struts2.components;
/*     */ 
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import com.opensymphony.xwork2.util.logging.Logger;
/*     */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*     */ import java.io.Writer;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.struts2.views.annotations.StrutsTag;
/*     */ import org.apache.struts2.views.annotations.StrutsTagAttribute;
/*     */ 
/*     */ @StrutsTag(name="submit", tldTagClass="org.apache.struts2.views.jsp.ui.SubmitTag", description="Render a submit button", allowDynamicAttributes=true)
/*     */ public class Submit extends FormButton
/*     */ {
/*  56 */   private static final Logger LOG = LoggerFactory.getLogger(Submit.class);
/*     */   public static final String OPEN_TEMPLATE = "submit";
/*     */   public static final String TEMPLATE = "submit-close";
/*     */   protected String src;
/*     */ 
/*     */   public Submit(ValueStack stack, HttpServletRequest request, HttpServletResponse response)
/*     */   {
/*  62 */     super(stack, request, response);
/*     */   }
/*     */ 
/*     */   public String getDefaultOpenTemplate() {
/*  66 */     return "submit";
/*     */   }
/*     */ 
/*     */   protected String getDefaultTemplate() {
/*  70 */     return "submit-close";
/*     */   }
/*     */ 
/*     */   public void evaluateParams() {
/*  74 */     if ((this.key == null) && (this.value == null)) {
/*  75 */       this.value = "Submit";
/*     */     }
/*     */ 
/*  78 */     if ((this.key != null) && (this.value == null)) {
/*  79 */       this.value = ("%{getText('" + this.key + "')}");
/*     */     }
/*     */ 
/*  82 */     super.evaluateParams();
/*     */   }
/*     */ 
/*     */   public void evaluateExtraParams() {
/*  86 */     super.evaluateExtraParams();
/*     */ 
/*  88 */     if (this.src != null)
/*  89 */       addParameter("src", findString(this.src));
/*     */   }
/*     */ 
/*     */   protected boolean supportsImageType()
/*     */   {
/*  98 */     return true;
/*     */   }
/*     */   @StrutsTagAttribute(description="Supply an image src for <i>image</i> type submit button. Will have no effect for types <i>input</i> and <i>button</i>.")
/*     */   public void setSrc(String src) {
/* 103 */     this.src = src;
/*     */   }
/*     */ 
/*     */   public boolean usesBody()
/*     */   {
/* 109 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean end(Writer writer, String body)
/*     */   {
/* 116 */     evaluateParams();
/*     */     try {
/* 118 */       addParameter("body", body);
/*     */ 
/* 120 */       mergeTemplate(writer, buildTemplateName(this.template, getDefaultTemplate()));
/*     */     } catch (Exception e) {
/* 122 */       LOG.error("error when rendering", e, new String[0]);
/*     */     }
/*     */     finally {
/* 125 */       popComponentStack();
/*     */     }
/*     */ 
/* 128 */     return false;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.components.Submit
 * JD-Core Version:    0.6.0
 */