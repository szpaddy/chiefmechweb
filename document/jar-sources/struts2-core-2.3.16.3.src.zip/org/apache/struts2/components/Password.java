/*    */ package org.apache.struts2.components;
/*    */ 
/*    */ import com.opensymphony.xwork2.util.ValueStack;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.apache.struts2.views.annotations.StrutsTag;
/*    */ import org.apache.struts2.views.annotations.StrutsTagAttribute;
/*    */ 
/*    */ @StrutsTag(name="password", tldTagClass="org.apache.struts2.views.jsp.ui.PasswordTag", description="Render an HTML input tag of type password", allowDynamicAttributes=true)
/*    */ public class Password extends TextField
/*    */ {
/*    */   public static final String TEMPLATE = "password";
/*    */   protected String showPassword;
/*    */ 
/*    */   public Password(ValueStack stack, HttpServletRequest request, HttpServletResponse response)
/*    */   {
/* 61 */     super(stack, request, response);
/*    */   }
/*    */ 
/*    */   protected String getDefaultTemplate() {
/* 65 */     return "password";
/*    */   }
/*    */ 
/*    */   public void evaluateExtraParams() {
/* 69 */     super.evaluateExtraParams();
/*    */ 
/* 71 */     if (this.showPassword != null)
/* 72 */       addParameter("showPassword", findValue(this.showPassword, Boolean.class));
/*    */   }
/*    */ 
/*    */   @StrutsTagAttribute(description="Whether to show input", type="Boolean", defaultValue="false")
/*    */   public void setShowPassword(String showPassword) {
/* 78 */     this.showPassword = showPassword;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.components.Password
 * JD-Core Version:    0.6.0
 */