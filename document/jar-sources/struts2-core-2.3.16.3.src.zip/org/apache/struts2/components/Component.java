/*     */ package org.apache.struts2.components;
/*     */ 
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import com.opensymphony.xwork2.util.TextParseUtil;
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.Writer;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.Stack;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.struts2.StrutsException;
/*     */ import org.apache.struts2.dispatcher.mapper.ActionMapper;
/*     */ import org.apache.struts2.dispatcher.mapper.ActionMapping;
/*     */ import org.apache.struts2.util.ComponentUtils;
/*     */ import org.apache.struts2.util.FastByteArrayOutputStream;
/*     */ import org.apache.struts2.views.jsp.TagUtils;
/*     */ import org.apache.struts2.views.util.UrlHelper;
/*     */ 
/*     */ public class Component
/*     */ {
/*     */   public static final String COMPONENT_STACK = "__component_stack";
/*     */   protected ValueStack stack;
/*     */   protected Map parameters;
/*     */   protected ActionMapper actionMapper;
/*     */   protected boolean throwExceptionOnELFailure;
/*     */   private UrlHelper urlHelper;
/*     */ 
/*     */   public Component(ValueStack stack)
/*     */   {
/*  67 */     this.stack = stack;
/*  68 */     this.parameters = new LinkedHashMap();
/*  69 */     getComponentStack().push(this);
/*     */   }
/*     */ 
/*     */   private String getComponentName()
/*     */   {
/*  77 */     Class c = getClass();
/*  78 */     String name = c.getName();
/*  79 */     int dot = name.lastIndexOf('.');
/*     */ 
/*  81 */     return name.substring(dot + 1).toLowerCase();
/*     */   }
/*     */   @Inject
/*     */   public void setActionMapper(ActionMapper mapper) {
/*  86 */     this.actionMapper = mapper;
/*     */   }
/*     */   @Inject("struts.el.throwExceptionOnFailure")
/*     */   public void setThrowExceptionsOnELFailure(String throwException) {
/*  91 */     this.throwExceptionOnELFailure = "true".equals(throwException);
/*     */   }
/*     */   @Inject
/*     */   public void setUrlHelper(UrlHelper urlHelper) {
/*  96 */     this.urlHelper = urlHelper;
/*     */   }
/*     */ 
/*     */   public ValueStack getStack()
/*     */   {
/* 103 */     return this.stack;
/*     */   }
/*     */ 
/*     */   public Stack<Component> getComponentStack()
/*     */   {
/* 111 */     Stack componentStack = (Stack)this.stack.getContext().get("__component_stack");
/* 112 */     if (componentStack == null) {
/* 113 */       componentStack = new Stack();
/* 114 */       this.stack.getContext().put("__component_stack", componentStack);
/*     */     }
/* 116 */     return componentStack;
/*     */   }
/*     */ 
/*     */   public boolean start(Writer writer)
/*     */   {
/* 127 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean end(Writer writer, String body)
/*     */   {
/* 140 */     return end(writer, body, true);
/*     */   }
/*     */ 
/*     */   protected boolean end(Writer writer, String body, boolean popComponentStack)
/*     */   {
/* 154 */     assert (body != null);
/*     */     try
/*     */     {
/* 157 */       writer.write(body);
/*     */     } catch (IOException e) {
/* 159 */       throw new StrutsException("IOError while writing the body: " + e.getMessage(), e);
/*     */     }
/* 161 */     if (popComponentStack) {
/* 162 */       popComponentStack();
/*     */     }
/* 164 */     return false;
/*     */   }
/*     */ 
/*     */   protected void popComponentStack()
/*     */   {
/* 171 */     getComponentStack().pop();
/*     */   }
/*     */ 
/*     */   protected Component findAncestor(Class clazz)
/*     */   {
/* 180 */     Stack componentStack = getComponentStack();
/* 181 */     int currPosition = componentStack.search(this);
/* 182 */     if (currPosition >= 0) {
/* 183 */       int start = componentStack.size() - currPosition - 1;
/*     */ 
/* 186 */       for (int i = start; i >= 0; i--) {
/* 187 */         Component component = (Component)componentStack.get(i);
/* 188 */         if ((clazz.isAssignableFrom(component.getClass())) && (component != this)) {
/* 189 */           return component;
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 194 */     return null;
/*     */   }
/*     */ 
/*     */   protected String findString(String expr)
/*     */   {
/* 203 */     return (String)findValue(expr, String.class);
/*     */   }
/*     */ 
/*     */   protected String findString(String expr, String field, String errorMsg)
/*     */   {
/* 219 */     if (expr == null) {
/* 220 */       throw fieldError(field, errorMsg, null);
/*     */     }
/* 222 */     return findString(expr);
/*     */   }
/*     */ 
/*     */   protected StrutsException fieldError(String field, String errorMsg, Exception e)
/*     */   {
/* 237 */     String msg = "tag '" + getComponentName() + "', field '" + field + ((this.parameters != null) && (this.parameters.containsKey("name")) ? "', name '" + this.parameters.get("name") : "") + "': " + errorMsg;
/*     */ 
/* 240 */     throw new StrutsException(msg, e);
/*     */   }
/*     */ 
/*     */   protected Object findValue(String expr)
/*     */   {
/* 252 */     if (expr == null) {
/* 253 */       return null;
/*     */     }
/*     */ 
/* 256 */     expr = stripExpressionIfAltSyntax(expr);
/*     */ 
/* 258 */     return getStack().findValue(expr, this.throwExceptionOnELFailure);
/*     */   }
/*     */ 
/*     */   protected String stripExpressionIfAltSyntax(String expr)
/*     */   {
/* 268 */     return ComponentUtils.stripExpressionIfAltSyntax(this.stack, expr);
/*     */   }
/*     */ 
/*     */   public boolean altSyntax()
/*     */   {
/* 277 */     return ComponentUtils.altSyntax(this.stack);
/*     */   }
/*     */ 
/*     */   protected String completeExpressionIfAltSyntax(String expr)
/*     */   {
/* 287 */     if (altSyntax()) {
/* 288 */       return "%{" + expr + "}";
/*     */     }
/* 290 */     return expr;
/*     */   }
/*     */ 
/*     */   protected String findStringIfAltSyntax(String expr)
/*     */   {
/* 300 */     if (altSyntax()) {
/* 301 */       return findString(expr);
/*     */     }
/* 303 */     return expr;
/*     */   }
/*     */ 
/*     */   protected Object findValue(String expr, String field, String errorMsg)
/*     */   {
/* 321 */     if (expr == null) {
/* 322 */       throw fieldError(field, errorMsg, null);
/*     */     }
/* 324 */     Object value = null;
/* 325 */     Exception problem = null;
/*     */     try {
/* 327 */       value = findValue(expr);
/*     */     } catch (Exception e) {
/* 329 */       problem = e;
/*     */     }
/*     */ 
/* 332 */     if (value == null) {
/* 333 */       throw fieldError(field, errorMsg, problem);
/*     */     }
/*     */ 
/* 336 */     return value;
/*     */   }
/*     */ 
/*     */   protected Object findValue(String expr, Class toType)
/*     */   {
/* 352 */     if ((altSyntax()) && (toType == String.class)) {
/* 353 */       return TextParseUtil.translateVariables('%', expr, this.stack);
/*     */     }
/* 355 */     expr = stripExpressionIfAltSyntax(expr);
/*     */ 
/* 357 */     return getStack().findValue(expr, toType, this.throwExceptionOnELFailure);
/*     */   }
/*     */ 
/*     */   protected String determineActionURL(String action, String namespace, String method, HttpServletRequest req, HttpServletResponse res, Map parameters, String scheme, boolean includeContext, boolean encodeResult, boolean forceAddSchemeHostAndPort, boolean escapeAmp)
/*     */   {
/* 380 */     String finalAction = findString(action);
/* 381 */     String finalMethod = method != null ? findString(method) : null;
/* 382 */     String finalNamespace = determineNamespace(namespace, getStack(), req);
/* 383 */     ActionMapping mapping = new ActionMapping(finalAction, finalNamespace, finalMethod, parameters);
/* 384 */     String uri = this.actionMapper.getUriFromActionMapping(mapping);
/* 385 */     return this.urlHelper.buildUrl(uri, req, res, parameters, scheme, includeContext, encodeResult, forceAddSchemeHostAndPort, escapeAmp);
/*     */   }
/*     */ 
/*     */   protected String determineNamespace(String namespace, ValueStack stack, HttpServletRequest req)
/*     */   {
/*     */     String result;
/*     */     String result;
/* 398 */     if (namespace == null)
/* 399 */       result = TagUtils.buildNamespace(this.actionMapper, stack, req);
/*     */     else {
/* 401 */       result = findString(namespace);
/*     */     }
/*     */ 
/* 404 */     if (result == null) {
/* 405 */       result = "";
/*     */     }
/*     */ 
/* 408 */     return result;
/*     */   }
/*     */ 
/*     */   public void copyParams(Map params)
/*     */   {
/* 420 */     this.stack.push(this.parameters);
/* 421 */     this.stack.push(this);
/*     */     try {
/* 423 */       for (i$ = params.entrySet().iterator(); i$.hasNext(); ) { Object o = i$.next();
/* 424 */         Map.Entry entry = (Map.Entry)o;
/* 425 */         String key = (String)entry.getKey();
/* 426 */         this.stack.setValue(key, entry.getValue());
/*     */       }
/*     */     }
/*     */     finally
/*     */     {
/*     */       Iterator i$;
/* 429 */       this.stack.pop();
/* 430 */       this.stack.pop();
/*     */     }
/*     */   }
/*     */ 
/*     */   protected String toString(Throwable t)
/*     */   {
/* 440 */     FastByteArrayOutputStream bout = new FastByteArrayOutputStream();
/* 441 */     PrintWriter wrt = new PrintWriter(bout);
/* 442 */     t.printStackTrace(wrt);
/* 443 */     wrt.close();
/*     */ 
/* 445 */     return bout.toString();
/*     */   }
/*     */ 
/*     */   public Map getParameters()
/*     */   {
/* 453 */     return this.parameters;
/*     */   }
/*     */ 
/*     */   public void addAllParameters(Map params)
/*     */   {
/* 461 */     this.parameters.putAll(params);
/*     */   }
/*     */ 
/*     */   public void addParameter(String key, Object value)
/*     */   {
/* 474 */     if (key != null) {
/* 475 */       Map params = getParameters();
/*     */ 
/* 477 */       if (value == null)
/* 478 */         params.remove(key);
/*     */       else
/* 480 */         params.put(key, value);
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean usesBody()
/*     */   {
/* 490 */     return false;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.components.Component
 * JD-Core Version:    0.6.0
 */