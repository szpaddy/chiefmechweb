/*     */ package org.apache.struts2.components;
/*     */ 
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import java.io.Writer;
/*     */ import java.util.Map;
/*     */ import org.apache.struts2.views.annotations.StrutsTag;
/*     */ import org.apache.struts2.views.annotations.StrutsTagAttribute;
/*     */ 
/*     */ @StrutsTag(name="elseif", tldTagClass="org.apache.struts2.views.jsp.ElseIfTag", description="Elseif tag")
/*     */ public class ElseIf extends Component
/*     */ {
/*     */   protected Boolean answer;
/*     */   protected String test;
/*     */ 
/*     */   public ElseIf(ValueStack stack)
/*     */   {
/*  69 */     super(stack);
/*     */   }
/*     */ 
/*     */   public boolean start(Writer writer)
/*     */   {
/*  76 */     Boolean ifResult = (Boolean)this.stack.getContext().get("struts.if.answer");
/*     */ 
/*  78 */     if ((ifResult == null) || (ifResult.booleanValue())) {
/*  79 */       return false;
/*     */     }
/*     */ 
/*  83 */     this.answer = ((Boolean)findValue(this.test, Boolean.class));
/*     */ 
/*  85 */     if (this.answer == null) {
/*  86 */       this.answer = Boolean.FALSE;
/*     */     }
/*  88 */     if (this.answer.booleanValue()) {
/*  89 */       this.stack.getContext().put("struts.if.answer", this.answer);
/*     */     }
/*  91 */     return this.answer.booleanValue();
/*     */   }
/*     */ 
/*     */   public boolean end(Writer writer, String body) {
/*  95 */     if (this.answer == null) {
/*  96 */       this.answer = Boolean.FALSE;
/*     */     }
/*  98 */     if (this.answer.booleanValue()) {
/*  99 */       this.stack.getContext().put("struts.if.answer", this.answer);
/*     */     }
/* 101 */     return super.end(writer, "");
/*     */   }
/*     */   @StrutsTagAttribute(description="Expression to determine if body of tag is to be displayed", type="Boolean", required=true)
/*     */   public void setTest(String test) {
/* 106 */     this.test = test;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.components.ElseIf
 * JD-Core Version:    0.6.0
 */