/*     */ package org.apache.struts2.components;
/*     */ 
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.struts2.util.ContainUtil;
/*     */ import org.apache.struts2.views.annotations.StrutsTag;
/*     */ 
/*     */ @StrutsTag(name="component", tldTagClass="org.apache.struts2.views.jsp.ui.ComponentTag", description="Render a custom ui widget")
/*     */ public class GenericUIBean extends UIBean
/*     */ {
/*     */   private static final String TEMPLATE = "empty";
/*     */ 
/*     */   public GenericUIBean(ValueStack stack, HttpServletRequest request, HttpServletResponse response)
/*     */   {
/* 119 */     super(stack, request, response);
/*     */   }
/*     */ 
/*     */   public boolean contains(Object obj1, Object obj2) {
/* 123 */     return ContainUtil.contains(obj1, obj2);
/*     */   }
/*     */ 
/*     */   protected String getDefaultTemplate() {
/* 127 */     return "empty";
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.components.GenericUIBean
 * JD-Core Version:    0.6.0
 */