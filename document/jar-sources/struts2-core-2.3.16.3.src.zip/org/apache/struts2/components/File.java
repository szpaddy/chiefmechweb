/*     */ package org.apache.struts2.components;
/*     */ 
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import com.opensymphony.xwork2.util.logging.Logger;
/*     */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*     */ import java.util.Map;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.struts2.views.annotations.StrutsTag;
/*     */ import org.apache.struts2.views.annotations.StrutsTagAttribute;
/*     */ 
/*     */ @StrutsTag(name="file", tldTagClass="org.apache.struts2.views.jsp.ui.FileTag", description="Render a file input field", allowDynamicAttributes=true)
/*     */ public class File extends UIBean
/*     */ {
/*  55 */   private static final Logger LOG = LoggerFactory.getLogger(File.class);
/*     */   public static final String TEMPLATE = "file";
/*     */   protected String accept;
/*     */   protected String size;
/*     */ 
/*     */   public File(ValueStack stack, HttpServletRequest request, HttpServletResponse response)
/*     */   {
/*  63 */     super(stack, request, response);
/*     */   }
/*     */ 
/*     */   protected String getDefaultTemplate() {
/*  67 */     return "file";
/*     */   }
/*     */ 
/*     */   public void evaluateParams() {
/*  71 */     super.evaluateParams();
/*     */ 
/*  73 */     Form form = (Form)findAncestor(Form.class);
/*  74 */     if (form != null) {
/*  75 */       String encType = (String)form.getParameters().get("enctype");
/*  76 */       if (!"multipart/form-data".equals(encType))
/*     */       {
/*  78 */         if (LOG.isWarnEnabled()) {
/*  79 */           LOG.warn("Struts has detected a file upload UI tag (s:file) being used without a form set to enctype 'multipart/form-data'. This is probably an error!", new String[0]);
/*     */         }
/*     */       }
/*     */ 
/*  83 */       String method = (String)form.getParameters().get("method");
/*  84 */       if (!"post".equalsIgnoreCase(method))
/*     */       {
/*  86 */         if (LOG.isWarnEnabled()) {
/*  87 */           LOG.warn("Struts has detected a file upload UI tag (s:file) being used without a form set to method 'POST'. This is probably an error!", new String[0]);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*  92 */     if (this.accept != null) {
/*  93 */       addParameter("accept", findString(this.accept));
/*     */     }
/*     */ 
/*  96 */     if (this.size != null)
/*  97 */       addParameter("size", findString(this.size));
/*     */   }
/*     */ 
/*     */   @StrutsTagAttribute(description="HTML accept attribute to indicate accepted file mimetypes")
/*     */   public void setAccept(String accept) {
/* 103 */     this.accept = accept;
/*     */   }
/*     */   @StrutsTagAttribute(description="HTML size attribute", required=false, type="Integer")
/*     */   public void setSize(String size) {
/* 108 */     this.size = size;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.components.File
 * JD-Core Version:    0.6.0
 */