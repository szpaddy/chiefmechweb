/*     */ package org.apache.struts2.components;
/*     */ 
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import com.opensymphony.xwork2.util.logging.Logger;
/*     */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.struts2.views.annotations.StrutsTag;
/*     */ import org.apache.struts2.views.annotations.StrutsTagAttribute;
/*     */ 
/*     */ @StrutsTag(name="updownselect", tldTagClass="org.apache.struts2.views.jsp.ui.UpDownSelectTag", description="Create a Select component with buttons to move the elements in the select component up and down")
/*     */ public class UpDownSelect extends Select
/*     */ {
/*  85 */   private static final Logger LOG = LoggerFactory.getLogger(UpDownSelect.class);
/*     */   public static final String TEMPLATE = "updownselect";
/*     */   protected String allowMoveUp;
/*     */   protected String allowMoveDown;
/*     */   protected String allowSelectAll;
/*     */   protected String moveUpLabel;
/*     */   protected String moveDownLabel;
/*     */   protected String selectAllLabel;
/*     */ 
/*     */   public String getDefaultTemplate()
/*     */   {
/* 100 */     return "updownselect";
/*     */   }
/*     */ 
/*     */   public UpDownSelect(ValueStack stack, HttpServletRequest request, HttpServletResponse response) {
/* 104 */     super(stack, request, response);
/*     */   }
/*     */ 
/*     */   public void evaluateParams() {
/* 108 */     super.evaluateParams();
/*     */ 
/* 112 */     if ((this.size == null) || (this.size.trim().length() <= 0)) {
/* 113 */       addParameter("size", "5");
/*     */     }
/* 115 */     if ((this.multiple == null) || (this.multiple.trim().length() <= 0)) {
/* 116 */       addParameter("multiple", Boolean.TRUE);
/*     */     }
/*     */ 
/* 121 */     if (this.allowMoveUp != null) {
/* 122 */       addParameter("allowMoveUp", findValue(this.allowMoveUp, Boolean.class));
/*     */     }
/* 124 */     if (this.allowMoveDown != null) {
/* 125 */       addParameter("allowMoveDown", findValue(this.allowMoveDown, Boolean.class));
/*     */     }
/* 127 */     if (this.allowSelectAll != null) {
/* 128 */       addParameter("allowSelectAll", findValue(this.allowSelectAll, Boolean.class));
/*     */     }
/*     */ 
/* 131 */     if (this.moveUpLabel != null) {
/* 132 */       addParameter("moveUpLabel", findString(this.moveUpLabel));
/*     */     }
/* 134 */     if (this.moveDownLabel != null) {
/* 135 */       addParameter("moveDownLabel", findString(this.moveDownLabel));
/*     */     }
/* 137 */     if (this.selectAllLabel != null) {
/* 138 */       addParameter("selectAllLabel", findString(this.selectAllLabel));
/*     */     }
/*     */ 
/* 144 */     Form ancestorForm = (Form)findAncestor(Form.class);
/* 145 */     if (ancestorForm != null)
/*     */     {
/* 148 */       enableAncestorFormCustomOnsubmit();
/*     */ 
/* 150 */       Map m = (Map)ancestorForm.getParameters().get("updownselectIds");
/* 151 */       if (m == null)
/*     */       {
/* 153 */         m = new LinkedHashMap();
/*     */       }
/* 155 */       m.put(getParameters().get("id"), getParameters().get("headerKey"));
/* 156 */       ancestorForm.getParameters().put("updownselectIds", m);
/*     */     }
/* 159 */     else if (LOG.isWarnEnabled()) {
/* 160 */       LOG.warn("no ancestor form found for updownselect " + this + ", therefore autoselect of all elements upon form submission will not work ", new String[0]);
/*     */     }
/*     */   }
/*     */ 
/*     */   public String getAllowMoveUp()
/*     */   {
/* 167 */     return this.allowMoveUp;
/*     */   }
/*     */   @StrutsTagAttribute(description="Whether move up button should be displayed", type="Boolean", defaultValue="true")
/*     */   public void setAllowMoveUp(String allowMoveUp) {
/* 172 */     this.allowMoveUp = allowMoveUp;
/*     */   }
/*     */ 
/*     */   public String getAllowMoveDown()
/*     */   {
/* 178 */     return this.allowMoveDown;
/*     */   }
/*     */   @StrutsTagAttribute(description="Whether move down button should be displayed", type="Boolean", defaultValue="true")
/*     */   public void setAllowMoveDown(String allowMoveDown) {
/* 183 */     this.allowMoveDown = allowMoveDown;
/*     */   }
/*     */ 
/*     */   public String getAllowSelectAll()
/*     */   {
/* 189 */     return this.allowSelectAll;
/*     */   }
/*     */   @StrutsTagAttribute(description="Whether or not select all button should be displayed", type="Boolean", defaultValue="true")
/*     */   public void setAllowSelectAll(String allowSelectAll) {
/* 194 */     this.allowSelectAll = allowSelectAll;
/*     */   }
/*     */ 
/*     */   public String getMoveUpLabel()
/*     */   {
/* 199 */     return this.moveUpLabel;
/*     */   }
/*     */   @StrutsTagAttribute(description="Text to display on the move up button", defaultValue="^")
/*     */   public void setMoveUpLabel(String moveUpLabel) {
/* 204 */     this.moveUpLabel = moveUpLabel;
/*     */   }
/*     */ 
/*     */   public String getMoveDownLabel()
/*     */   {
/* 210 */     return this.moveDownLabel;
/*     */   }
/*     */   @StrutsTagAttribute(description="Text to display on the move down button", defaultValue="v")
/*     */   public void setMoveDownLabel(String moveDownLabel) {
/* 215 */     this.moveDownLabel = moveDownLabel;
/*     */   }
/*     */ 
/*     */   public String getSelectAllLabel()
/*     */   {
/* 221 */     return this.selectAllLabel;
/*     */   }
/*     */   @StrutsTagAttribute(description="Text to display on the select all button", defaultValue="*")
/*     */   public void setSelectAllLabel(String selectAllLabel) {
/* 226 */     this.selectAllLabel = selectAllLabel;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.components.UpDownSelect
 * JD-Core Version:    0.6.0
 */