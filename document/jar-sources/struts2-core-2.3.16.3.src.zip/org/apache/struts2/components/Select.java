/*     */ package org.apache.struts2.components;
/*     */ 
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.struts2.views.annotations.StrutsTag;
/*     */ import org.apache.struts2.views.annotations.StrutsTagAttribute;
/*     */ 
/*     */ @StrutsTag(name="select", tldTagClass="org.apache.struts2.views.jsp.ui.SelectTag", description="Render a select element", allowDynamicAttributes=true)
/*     */ public class Select extends ListUIBean
/*     */ {
/*     */   public static final String TEMPLATE = "select";
/*     */   protected String emptyOption;
/*     */   protected String headerKey;
/*     */   protected String headerValue;
/*     */   protected String multiple;
/*     */   protected String size;
/*     */ 
/*     */   public Select(ValueStack stack, HttpServletRequest request, HttpServletResponse response)
/*     */   {
/*  97 */     super(stack, request, response);
/*     */   }
/*     */ 
/*     */   protected String getDefaultTemplate() {
/* 101 */     return "select";
/*     */   }
/*     */ 
/*     */   public void evaluateExtraParams() {
/* 105 */     super.evaluateExtraParams();
/*     */ 
/* 107 */     if (this.emptyOption != null) {
/* 108 */       addParameter("emptyOption", findValue(this.emptyOption, Boolean.class));
/*     */     }
/*     */ 
/* 111 */     if (this.multiple != null) {
/* 112 */       addParameter("multiple", findValue(this.multiple, Boolean.class));
/*     */     }
/*     */ 
/* 115 */     if (this.size != null) {
/* 116 */       addParameter("size", findString(this.size));
/*     */     }
/*     */ 
/* 119 */     if ((this.headerKey != null) && (this.headerValue != null)) {
/* 120 */       addParameter("headerKey", findString(this.headerKey));
/* 121 */       addParameter("headerValue", findString(this.headerValue));
/*     */     }
/*     */   }
/*     */ 
/*     */   @StrutsTagAttribute(description="Whether or not to add an empty (--) option after the header option", type="Boolean", defaultValue="false")
/*     */   public void setEmptyOption(String emptyOption) {
/* 127 */     this.emptyOption = emptyOption;
/*     */   }
/*     */   @StrutsTagAttribute(description=" Key for first item in list. Must not be empty! '-1' and '' is correct, '' is bad.")
/*     */   public void setHeaderKey(String headerKey) {
/* 132 */     this.headerKey = headerKey;
/*     */   }
/*     */   @StrutsTagAttribute(description="Value expression for first item in list")
/*     */   public void setHeaderValue(String headerValue) {
/* 137 */     this.headerValue = headerValue;
/*     */   }
/*     */ 
/*     */   @StrutsTagAttribute(description=" Creates a multiple select. The tag will pre-select multiple values if the values are passed as an Array or a Collection(of appropriate types) via the value attribute. If one of the keys equals one of the values in the Collection or Array it wil be selected", type="Boolean", defaultValue="false")
/*     */   public void setMultiple(String multiple)
/*     */   {
/* 144 */     this.multiple = multiple;
/*     */   }
/*     */   @StrutsTagAttribute(description="Size of the element box (# of elements to show)", type="Integer")
/*     */   public void setSize(String size) {
/* 149 */     this.size = size;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.components.Select
 * JD-Core Version:    0.6.0
 */