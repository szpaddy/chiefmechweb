/*    */ package org.apache.struts2.components;
/*    */ 
/*    */ import com.opensymphony.xwork2.util.ValueStack;
/*    */ import java.util.Collection;
/*    */ import java.util.List;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.apache.commons.lang3.StringUtils;
/*    */ import org.apache.struts2.views.annotations.StrutsTag;
/*    */ import org.apache.struts2.views.annotations.StrutsTagAttribute;
/*    */ 
/*    */ @StrutsTag(name="actionmessage", tldBodyContent="empty", tldTagClass="org.apache.struts2.views.jsp.ui.ActionMessageTag", description="Render action messages if they exists")
/*    */ public class ActionMessage extends UIBean
/*    */ {
/*    */   private static final String TEMPLATE = "actionmessage";
/* 59 */   protected boolean escape = true;
/*    */ 
/*    */   public ActionMessage(ValueStack stack, HttpServletRequest request, HttpServletResponse response) {
/* 62 */     super(stack, request, response);
/*    */   }
/*    */ 
/*    */   protected String getDefaultTemplate() {
/* 66 */     return "actionmessage";
/*    */   }
/*    */ 
/*    */   protected void evaluateExtraParams() {
/* 70 */     boolean isEmptyList = true;
/* 71 */     Collection actionMessages = (List)findValue("actionMessages");
/* 72 */     if (actionMessages != null) {
/* 73 */       for (String message : actionMessages) {
/* 74 */         if (StringUtils.isNotBlank(message)) {
/* 75 */           isEmptyList = false;
/* 76 */           break;
/*    */         }
/*    */       }
/*    */     }
/*    */ 
/* 81 */     addParameter("isEmptyList", Boolean.valueOf(isEmptyList));
/* 82 */     addParameter("escape", Boolean.valueOf(this.escape));
/*    */   }
/*    */   @StrutsTagAttribute(description=" Whether to escape HTML", type="Boolean", defaultValue="true")
/*    */   public void setEscape(boolean escape) {
/* 87 */     this.escape = escape;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.components.ActionMessage
 * JD-Core Version:    0.6.0
 */