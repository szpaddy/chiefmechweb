/*    */ package org.apache.struts2.components;
/*    */ 
/*    */ import com.opensymphony.xwork2.inject.Inject;
/*    */ import com.opensymphony.xwork2.util.ValueStack;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.apache.struts2.views.annotations.StrutsTag;
/*    */ 
/*    */ @StrutsTag(name="head", tldBodyContent="empty", tldTagClass="org.apache.struts2.views.jsp.ui.HeadTag", description="Render a chunk of HEAD for your HTML file", allowDynamicAttributes=true)
/*    */ public class Head extends UIBean
/*    */ {
/*    */   public static final String TEMPLATE = "head";
/*    */   private String encoding;
/*    */ 
/*    */   public Head(ValueStack stack, HttpServletRequest request, HttpServletResponse response)
/*    */   {
/* 61 */     super(stack, request, response);
/*    */   }
/*    */ 
/*    */   protected String getDefaultTemplate() {
/* 65 */     return "head";
/*    */   }
/*    */   @Inject("struts.i18n.encoding")
/*    */   public void setEncoding(String encoding) {
/* 70 */     this.encoding = encoding;
/*    */   }
/*    */ 
/*    */   public void evaluateParams() {
/* 74 */     super.evaluateParams();
/*    */ 
/* 76 */     addParameter("encoding", this.encoding);
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.components.Head
 * JD-Core Version:    0.6.0
 */