/*     */ package org.apache.struts2.components;
/*     */ 
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import java.util.Map;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.struts2.views.annotations.StrutsTagAttribute;
/*     */ 
/*     */ public abstract class DoubleListUIBean extends ListUIBean
/*     */ {
/*     */   protected String emptyOption;
/*     */   protected String headerKey;
/*     */   protected String headerValue;
/*     */   protected String multiple;
/*     */   protected String size;
/*     */   protected String doubleList;
/*     */   protected String doubleListKey;
/*     */   protected String doubleListValue;
/*     */   protected String doubleListCssClass;
/*     */   protected String doubleListCssStyle;
/*     */   protected String doubleListTitle;
/*     */   protected String doubleName;
/*     */   protected String doubleValue;
/*     */   protected String formName;
/*     */   protected String doubleId;
/*     */   protected String doubleDisabled;
/*     */   protected String doubleMultiple;
/*     */   protected String doubleSize;
/*     */   protected String doubleHeaderKey;
/*     */   protected String doubleHeaderValue;
/*     */   protected String doubleEmptyOption;
/*     */   protected String doubleCssClass;
/*     */   protected String doubleCssStyle;
/*     */   protected String doubleOnclick;
/*     */   protected String doubleOndblclick;
/*     */   protected String doubleOnmousedown;
/*     */   protected String doubleOnmouseup;
/*     */   protected String doubleOnmouseover;
/*     */   protected String doubleOnmousemove;
/*     */   protected String doubleOnmouseout;
/*     */   protected String doubleOnfocus;
/*     */   protected String doubleOnblur;
/*     */   protected String doubleOnkeypress;
/*     */   protected String doubleOnkeydown;
/*     */   protected String doubleOnkeyup;
/*     */   protected String doubleOnselect;
/*     */   protected String doubleOnchange;
/*     */   protected String doubleAccesskey;
/*     */ 
/*     */   public DoubleListUIBean(ValueStack stack, HttpServletRequest request, HttpServletResponse response)
/*     */   {
/*  93 */     super(stack, request, response);
/*     */   }
/*     */ 
/*     */   public void evaluateExtraParams() {
/*  97 */     super.evaluateExtraParams();
/*     */ 
/* 101 */     if (this.emptyOption != null) {
/* 102 */       addParameter("emptyOption", findValue(this.emptyOption, Boolean.class));
/*     */     }
/*     */ 
/* 105 */     if (this.multiple != null) {
/* 106 */       addParameter("multiple", findValue(this.multiple, Boolean.class));
/*     */     }
/*     */ 
/* 109 */     if (this.size != null) {
/* 110 */       addParameter("size", findString(this.size));
/*     */     }
/*     */ 
/* 113 */     if ((this.headerKey != null) && (this.headerValue != null)) {
/* 114 */       addParameter("headerKey", findString(this.headerKey));
/* 115 */       addParameter("headerValue", findString(this.headerValue));
/*     */     }
/*     */ 
/* 119 */     if (this.doubleMultiple != null) {
/* 120 */       addParameter("doubleMultiple", findValue(this.doubleMultiple, Boolean.class));
/*     */     }
/*     */ 
/* 123 */     if (this.doubleSize != null) {
/* 124 */       addParameter("doubleSize", findString(this.doubleSize));
/*     */     }
/*     */ 
/* 127 */     if (this.doubleDisabled != null) {
/* 128 */       addParameter("doubleDisabled", findValue(this.doubleDisabled, Boolean.class));
/*     */     }
/*     */ 
/* 131 */     if (this.doubleName != null) {
/* 132 */       addParameter("doubleName", findString(this.doubleName));
/*     */     }
/*     */ 
/* 135 */     if (this.doubleList != null) {
/* 136 */       addParameter("doubleList", this.doubleList);
/*     */     }
/*     */ 
/* 139 */     Object tmpDoubleList = findValue(this.doubleList);
/* 140 */     if (this.doubleListKey != null)
/* 141 */       addParameter("doubleListKey", this.doubleListKey);
/* 142 */     else if ((tmpDoubleList instanceof Map)) {
/* 143 */       addParameter("doubleListKey", "key");
/*     */     }
/*     */ 
/* 146 */     if (this.doubleListValue != null) {
/* 147 */       this.doubleListValue = stripExpressionIfAltSyntax(this.doubleListValue);
/*     */ 
/* 149 */       addParameter("doubleListValue", this.doubleListValue);
/* 150 */     } else if ((tmpDoubleList instanceof Map)) {
/* 151 */       addParameter("doubleListValue", "value");
/*     */     }
/* 153 */     if (this.doubleListCssClass != null) {
/* 154 */       addParameter("doubleListCssClass", findString(this.doubleListCssClass));
/*     */     }
/* 156 */     if (this.doubleListCssStyle != null) {
/* 157 */       addParameter("doubleListCssStyle", findString(this.doubleListCssStyle));
/*     */     }
/* 159 */     if (this.doubleListTitle != null) {
/* 160 */       addParameter("doubleListTitle", findString(this.doubleListTitle));
/*     */     }
/*     */ 
/* 164 */     if (this.formName != null) {
/* 165 */       addParameter("formName", findString(this.formName));
/*     */     }
/*     */     else {
/* 168 */       Component form = findAncestor(Form.class);
/* 169 */       if (form != null) {
/* 170 */         addParameter("formName", form.getParameters().get("name"));
/*     */       }
/*     */     }
/*     */ 
/* 174 */     Class valueClazz = getValueClassType();
/*     */ 
/* 176 */     if (valueClazz != null) {
/* 177 */       if (this.doubleValue != null)
/* 178 */         addParameter("doubleNameValue", findValue(this.doubleValue, valueClazz));
/* 179 */       else if (this.doubleName != null) {
/* 180 */         addParameter("doubleNameValue", findValue(this.doubleName, valueClazz));
/*     */       }
/*     */     }
/* 183 */     else if (this.doubleValue != null)
/* 184 */       addParameter("doubleNameValue", findValue(this.doubleValue));
/* 185 */     else if (this.doubleName != null) {
/* 186 */       addParameter("doubleNameValue", findValue(this.doubleName));
/*     */     }
/*     */ 
/* 190 */     Form form = (Form)findAncestor(Form.class);
/* 191 */     if (this.doubleId != null)
/*     */     {
/* 193 */       addParameter("doubleId", findStringIfAltSyntax(this.doubleId));
/* 194 */     } else if (form != null)
/* 195 */       addParameter("doubleId", form.getParameters().get("id") + "_" + escape(this.doubleName != null ? findString(this.doubleName) : null));
/*     */     else {
/* 197 */       addParameter("doubleId", escape(this.doubleName != null ? findString(this.doubleName) : null));
/*     */     }
/*     */ 
/* 200 */     if (this.doubleOnclick != null) {
/* 201 */       addParameter("doubleOnclick", findString(this.doubleOnclick));
/*     */     }
/*     */ 
/* 204 */     if (this.doubleOndblclick != null) {
/* 205 */       addParameter("doubleOndblclick", findString(this.doubleOndblclick));
/*     */     }
/*     */ 
/* 208 */     if (this.doubleOnmousedown != null) {
/* 209 */       addParameter("doubleOnmousedown", findString(this.doubleOnmousedown));
/*     */     }
/*     */ 
/* 212 */     if (this.doubleOnmouseup != null) {
/* 213 */       addParameter("doubleOnmouseup", findString(this.doubleOnmouseup));
/*     */     }
/*     */ 
/* 216 */     if (this.doubleOnmouseover != null) {
/* 217 */       addParameter("doubleOnmouseover", findString(this.doubleOnmouseover));
/*     */     }
/*     */ 
/* 220 */     if (this.doubleOnmousemove != null) {
/* 221 */       addParameter("doubleOnmousemove", findString(this.doubleOnmousemove));
/*     */     }
/*     */ 
/* 224 */     if (this.doubleOnmouseout != null) {
/* 225 */       addParameter("doubleOnmouseout", findString(this.doubleOnmouseout));
/*     */     }
/*     */ 
/* 228 */     if (this.doubleOnfocus != null) {
/* 229 */       addParameter("doubleOnfocus", findString(this.doubleOnfocus));
/*     */     }
/*     */ 
/* 232 */     if (this.doubleOnblur != null) {
/* 233 */       addParameter("doubleOnblur", findString(this.doubleOnblur));
/*     */     }
/*     */ 
/* 236 */     if (this.doubleOnkeypress != null) {
/* 237 */       addParameter("doubleOnkeypress", findString(this.doubleOnkeypress));
/*     */     }
/*     */ 
/* 240 */     if (this.doubleOnkeydown != null) {
/* 241 */       addParameter("doubleOnkeydown", findString(this.doubleOnkeydown));
/*     */     }
/*     */ 
/* 244 */     if (this.doubleOnselect != null) {
/* 245 */       addParameter("doubleOnselect", findString(this.doubleOnselect));
/*     */     }
/*     */ 
/* 248 */     if (this.doubleOnchange != null) {
/* 249 */       addParameter("doubleOnchange", findString(this.doubleOnchange));
/*     */     }
/*     */ 
/* 252 */     if (this.doubleCssClass != null) {
/* 253 */       addParameter("doubleCss", findString(this.doubleCssClass));
/*     */     }
/*     */ 
/* 256 */     if (this.doubleCssStyle != null) {
/* 257 */       addParameter("doubleStyle", findString(this.doubleCssStyle));
/*     */     }
/*     */ 
/* 260 */     if ((this.doubleHeaderKey != null) && (this.doubleHeaderValue != null)) {
/* 261 */       addParameter("doubleHeaderKey", findString(this.doubleHeaderKey));
/* 262 */       addParameter("doubleHeaderValue", findString(this.doubleHeaderValue));
/*     */     }
/*     */ 
/* 265 */     if (this.doubleEmptyOption != null) {
/* 266 */       addParameter("doubleEmptyOption", findValue(this.doubleEmptyOption, Boolean.class));
/*     */     }
/*     */ 
/* 269 */     if (this.doubleAccesskey != null)
/* 270 */       addParameter("doubleAccesskey", findString(this.doubleAccesskey));
/*     */   }
/*     */ 
/*     */   @StrutsTagAttribute(description="The second iterable source to populate from.", required=true)
/*     */   public void setDoubleList(String doubleList) {
/* 276 */     this.doubleList = doubleList;
/*     */   }
/*     */   @StrutsTagAttribute(description="The key expression to use for second list")
/*     */   public void setDoubleListKey(String doubleListKey) {
/* 281 */     this.doubleListKey = doubleListKey;
/*     */   }
/*     */   @StrutsTagAttribute(description="The value expression to use for second list")
/*     */   public void setDoubleListValue(String doubleListValue) {
/* 286 */     this.doubleListValue = doubleListValue;
/*     */   }
/*     */   @StrutsTagAttribute(description="Property of second list objects to get css class from")
/*     */   public void setDoubleListCssClass(String doubleListCssClass) {
/* 291 */     this.doubleListCssClass = doubleListCssClass;
/*     */   }
/*     */   @StrutsTagAttribute(description="Property of second list objects to get css style from")
/*     */   public void setDoubleListCssStyle(String doubleListCssStyle) {
/* 296 */     this.doubleListCssStyle = doubleListCssStyle;
/*     */   }
/*     */   @StrutsTagAttribute(description="Property of second list objects to get title from")
/*     */   public void setDoubleListTitle(String doubleListTitle) {
/* 301 */     this.doubleListTitle = doubleListTitle;
/*     */   }
/*     */   @StrutsTagAttribute(description="The name for complete component", required=true)
/*     */   public void setDoubleName(String doubleName) {
/* 306 */     this.doubleName = doubleName;
/*     */   }
/*     */   @StrutsTagAttribute(description="The value expression for complete component")
/*     */   public void setDoubleValue(String doubleValue) {
/* 311 */     this.doubleValue = doubleValue;
/*     */   }
/*     */   @StrutsTagAttribute(description="The form name this component resides in and populates to")
/*     */   public void setFormName(String formName) {
/* 316 */     this.formName = formName;
/*     */   }
/*     */ 
/*     */   public String getFormName() {
/* 320 */     return this.formName;
/*     */   }
/*     */   @StrutsTagAttribute(description="The css class for the second list")
/*     */   public void setDoubleCssClass(String doubleCssClass) {
/* 325 */     this.doubleCssClass = doubleCssClass;
/*     */   }
/*     */ 
/*     */   public String getDoubleCssClass() {
/* 329 */     return this.doubleCssClass;
/*     */   }
/*     */   @StrutsTagAttribute(description="The css style for the second list")
/*     */   public void setDoubleCssStyle(String doubleCssStyle) {
/* 334 */     this.doubleCssStyle = doubleCssStyle;
/*     */   }
/*     */ 
/*     */   public String getDoubleCssStyle() {
/* 338 */     return this.doubleCssStyle;
/*     */   }
/*     */   @StrutsTagAttribute(description="The header key for the second list")
/*     */   public void setDoubleHeaderKey(String doubleHeaderKey) {
/* 343 */     this.doubleHeaderKey = doubleHeaderKey;
/*     */   }
/*     */ 
/*     */   public String getDoubleHeaderKey() {
/* 347 */     return this.doubleHeaderKey;
/*     */   }
/*     */   @StrutsTagAttribute(description="The header value for the second list")
/*     */   public void setDoubleHeaderValue(String doubleHeaderValue) {
/* 352 */     this.doubleHeaderValue = doubleHeaderValue;
/*     */   }
/*     */ 
/*     */   public String getDoubleHeaderValue() {
/* 356 */     return this.doubleHeaderValue;
/*     */   }
/*     */   @StrutsTagAttribute(description="Decides if the second list will add an empty option")
/*     */   public void setDoubleEmptyOption(String doubleEmptyOption) {
/* 361 */     this.doubleEmptyOption = doubleEmptyOption;
/*     */   }
/*     */ 
/*     */   public String getDoubleEmptyOption() {
/* 365 */     return this.doubleEmptyOption;
/*     */   }
/*     */ 
/*     */   public String getDoubleDisabled()
/*     */   {
/* 370 */     return this.doubleDisabled;
/*     */   }
/*     */   @StrutsTagAttribute(description="Decides if a disable attribute should be added to the second list")
/*     */   public void setDoubleDisabled(String doubleDisabled) {
/* 375 */     this.doubleDisabled = doubleDisabled;
/*     */   }
/*     */ 
/*     */   public String getDoubleId() {
/* 379 */     return this.doubleId;
/*     */   }
/*     */   @StrutsTagAttribute(description="The id of the second list")
/*     */   public void setDoubleId(String doubleId) {
/* 384 */     this.doubleId = doubleId;
/*     */   }
/*     */ 
/*     */   public String getDoubleMultiple() {
/* 388 */     return this.doubleMultiple;
/*     */   }
/*     */   @StrutsTagAttribute(description=" Decides if multiple attribute should be set on the second list")
/*     */   public void setDoubleMultiple(String doubleMultiple) {
/* 393 */     this.doubleMultiple = doubleMultiple;
/*     */   }
/*     */ 
/*     */   public String getDoubleOnblur() {
/* 397 */     return this.doubleOnblur;
/*     */   }
/*     */   @StrutsTagAttribute(description="Set the onblur attribute of the second list")
/*     */   public void setDoubleOnblur(String doubleOnblur) {
/* 402 */     this.doubleOnblur = doubleOnblur;
/*     */   }
/*     */ 
/*     */   public String getDoubleOnchange() {
/* 406 */     return this.doubleOnchange;
/*     */   }
/*     */   @StrutsTagAttribute(description="Set the onchange attribute of the second list")
/*     */   public void setDoubleOnchange(String doubleOnchange) {
/* 411 */     this.doubleOnchange = doubleOnchange;
/*     */   }
/*     */ 
/*     */   public String getDoubleOnclick() {
/* 415 */     return this.doubleOnclick;
/*     */   }
/*     */   @StrutsTagAttribute(description="Set the onclick attribute of the second list")
/*     */   public void setDoubleOnclick(String doubleOnclick) {
/* 420 */     this.doubleOnclick = doubleOnclick;
/*     */   }
/*     */ 
/*     */   public String getDoubleOndblclick() {
/* 424 */     return this.doubleOndblclick;
/*     */   }
/*     */   @StrutsTagAttribute(description="Set the ondbclick attribute of the second list")
/*     */   public void setDoubleOndblclick(String doubleOndblclick) {
/* 429 */     this.doubleOndblclick = doubleOndblclick;
/*     */   }
/*     */ 
/*     */   public String getDoubleOnfocus() {
/* 433 */     return this.doubleOnfocus;
/*     */   }
/*     */   @StrutsTagAttribute(description="Set the onfocus attribute of the second list")
/*     */   public void setDoubleOnfocus(String doubleOnfocus) {
/* 438 */     this.doubleOnfocus = doubleOnfocus;
/*     */   }
/*     */ 
/*     */   public String getDoubleOnkeydown() {
/* 442 */     return this.doubleOnkeydown;
/*     */   }
/*     */   @StrutsTagAttribute(description="Set the onkeydown attribute of the second list")
/*     */   public void setDoubleOnkeydown(String doubleOnkeydown) {
/* 447 */     this.doubleOnkeydown = doubleOnkeydown;
/*     */   }
/*     */ 
/*     */   public String getDoubleOnkeypress() {
/* 451 */     return this.doubleOnkeypress;
/*     */   }
/*     */   @StrutsTagAttribute(description="Set the onkeypress attribute of the second list")
/*     */   public void setDoubleOnkeypress(String doubleOnkeypress) {
/* 456 */     this.doubleOnkeypress = doubleOnkeypress;
/*     */   }
/*     */ 
/*     */   public String getDoubleOnkeyup() {
/* 460 */     return this.doubleOnkeyup;
/*     */   }
/*     */   @StrutsTagAttribute(description="Set the onkeyup attribute of the second list")
/*     */   public void setDoubleOnkeyup(String doubleOnkeyup) {
/* 465 */     this.doubleOnkeyup = doubleOnkeyup;
/*     */   }
/*     */ 
/*     */   public String getDoubleOnmousedown() {
/* 469 */     return this.doubleOnmousedown;
/*     */   }
/*     */   @StrutsTagAttribute(description="Set the onmousedown attribute of the second list")
/*     */   public void setDoubleOnmousedown(String doubleOnmousedown) {
/* 474 */     this.doubleOnmousedown = doubleOnmousedown;
/*     */   }
/*     */ 
/*     */   public String getDoubleOnmousemove() {
/* 478 */     return this.doubleOnmousemove;
/*     */   }
/*     */   @StrutsTagAttribute(description="Set the onmousemove attribute of the second list")
/*     */   public void setDoubleOnmousemove(String doubleOnmousemove) {
/* 483 */     this.doubleOnmousemove = doubleOnmousemove;
/*     */   }
/*     */ 
/*     */   public String getDoubleOnmouseout() {
/* 487 */     return this.doubleOnmouseout;
/*     */   }
/*     */   @StrutsTagAttribute(description="Set the onmouseout attribute of the second list")
/*     */   public void setDoubleOnmouseout(String doubleOnmouseout) {
/* 492 */     this.doubleOnmouseout = doubleOnmouseout;
/*     */   }
/*     */ 
/*     */   public String getDoubleOnmouseover() {
/* 496 */     return this.doubleOnmouseover;
/*     */   }
/*     */   @StrutsTagAttribute(description="Set the onmouseover attribute of the second list")
/*     */   public void setDoubleOnmouseover(String doubleOnmouseover) {
/* 501 */     this.doubleOnmouseover = doubleOnmouseover;
/*     */   }
/*     */ 
/*     */   public String getDoubleOnmouseup() {
/* 505 */     return this.doubleOnmouseup;
/*     */   }
/*     */   @StrutsTagAttribute(description="Set the onmouseup attribute of the second list")
/*     */   public void setDoubleOnmouseup(String doubleOnmouseup) {
/* 510 */     this.doubleOnmouseup = doubleOnmouseup;
/*     */   }
/*     */ 
/*     */   public String getDoubleOnselect() {
/* 514 */     return this.doubleOnselect;
/*     */   }
/*     */   @StrutsTagAttribute(description="Set the onselect attribute of the second list")
/*     */   public void setDoubleOnselect(String doubleOnselect) {
/* 519 */     this.doubleOnselect = doubleOnselect;
/*     */   }
/*     */ 
/*     */   public String getDoubleSize() {
/* 523 */     return this.doubleSize;
/*     */   }
/*     */   @StrutsTagAttribute(description="Set the size attribute of the second list")
/*     */   public void setDoubleSize(String doubleSize) {
/* 528 */     this.doubleSize = doubleSize;
/*     */   }
/*     */ 
/*     */   public String getDoubleList() {
/* 532 */     return this.doubleList;
/*     */   }
/*     */ 
/*     */   public String getDoubleListKey() {
/* 536 */     return this.doubleListKey;
/*     */   }
/*     */ 
/*     */   public String getDoubleListValue() {
/* 540 */     return this.doubleListValue;
/*     */   }
/*     */ 
/*     */   public String getDoubleName() {
/* 544 */     return this.doubleName;
/*     */   }
/*     */ 
/*     */   public String getDoubleValue() {
/* 548 */     return this.doubleValue;
/*     */   }
/*     */   @StrutsTagAttribute(description="Decides of an empty option is to be inserted in the second list", type="Boolean", defaultValue="false")
/*     */   public void setEmptyOption(String emptyOption) {
/* 553 */     this.emptyOption = emptyOption;
/*     */   }
/*     */ 
/*     */   @StrutsTagAttribute(description="Set the header key of the second list. Must not be empty! '-1' and '' is correct, '' is bad.")
/*     */   public void setHeaderKey(String headerKey) {
/* 559 */     this.headerKey = headerKey;
/*     */   }
/*     */   @StrutsTagAttribute(description=" Set the header value of the second list")
/*     */   public void setHeaderValue(String headerValue) {
/* 564 */     this.headerValue = headerValue;
/*     */   }
/*     */ 
/*     */   @StrutsTagAttribute(description="Creates a multiple select. The tag will pre-select multiple values if the values are passed as an Array (of appropriate types) via the value attribute.")
/*     */   public void setMultiple(String multiple)
/*     */   {
/* 572 */     this.multiple = multiple;
/*     */   }
/*     */   @StrutsTagAttribute(description="Size of the element box (# of elements to show)", type="Integer")
/*     */   public void setSize(String size) {
/* 577 */     this.size = size;
/*     */   }
/*     */   @StrutsTagAttribute(description="Set the html accesskey attribute.")
/*     */   public void setDoubleAccesskey(String doubleAccesskey) {
/* 582 */     this.doubleAccesskey = doubleAccesskey;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.components.DoubleListUIBean
 * JD-Core Version:    0.6.0
 */