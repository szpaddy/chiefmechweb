/*     */ package org.apache.struts2.components;
/*     */ 
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.struts2.views.annotations.StrutsTag;
/*     */ import org.apache.struts2.views.annotations.StrutsTagAttribute;
/*     */ 
/*     */ @StrutsTag(name="reset", tldTagClass="org.apache.struts2.views.jsp.ui.ResetTag", description="Render a reset button", allowDynamicAttributes=true)
/*     */ public class Reset extends FormButton
/*     */ {
/*     */   public static final String TEMPLATE = "reset";
/*     */   protected String src;
/*     */ 
/*     */   public Reset(ValueStack stack, HttpServletRequest request, HttpServletResponse response)
/*     */   {
/*  70 */     super(stack, request, response);
/*     */   }
/*     */ 
/*     */   public String getDefaultOpenTemplate() {
/*  74 */     return "empty";
/*     */   }
/*     */ 
/*     */   protected String getDefaultTemplate() {
/*  78 */     return "reset";
/*     */   }
/*     */ 
/*     */   public void evaluateExtraParams() {
/*  82 */     super.evaluateExtraParams();
/*  83 */     if (this.src != null)
/*  84 */       addParameter("src", findString(this.src));
/*     */   }
/*     */ 
/*     */   public void evaluateParams() {
/*  88 */     if (this.value == null) {
/*  89 */       this.value = (this.key != null ? "%{getText('" + this.key + "')}" : "Reset");
/*     */     }
/*  91 */     super.evaluateParams();
/*     */   }
/*     */ 
/*     */   protected boolean supportsImageType()
/*     */   {
/* 100 */     return false;
/*     */   }
/*     */ 
/*     */   @StrutsTagAttribute(description="Supply a reset button text apart from reset value. Will have no effect for <i>input</i> type reset, since button text will always be the value parameter.")
/*     */   public void setLabel(String label) {
/* 106 */     super.setLabel(label);
/*     */   }
/*     */   @StrutsTagAttribute(description="Supply an image src for <i>image</i> type reset button. Will have no effect for types <i>input</i> and <i>button</i>.")
/*     */   public void setSrc(String src) {
/* 111 */     this.src = src;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.components.Reset
 * JD-Core Version:    0.6.0
 */