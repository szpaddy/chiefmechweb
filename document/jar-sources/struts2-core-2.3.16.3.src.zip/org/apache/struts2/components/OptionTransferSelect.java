/*     */ package org.apache.struts2.components;
/*     */ 
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import com.opensymphony.xwork2.util.logging.Logger;
/*     */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.struts2.views.annotations.StrutsTag;
/*     */ import org.apache.struts2.views.annotations.StrutsTagAttribute;
/*     */ 
/*     */ @StrutsTag(name="optiontransferselect", tldTagClass="org.apache.struts2.views.jsp.ui.OptionTransferSelectTag", description="Renders an input form")
/*     */ public class OptionTransferSelect extends DoubleListUIBean
/*     */ {
/*  97 */   private static final Logger LOG = LoggerFactory.getLogger(OptionTransferSelect.class);
/*     */   private static final String TEMPLATE = "optiontransferselect";
/*     */   protected String allowAddToLeft;
/*     */   protected String allowAddToRight;
/*     */   protected String allowAddAllToLeft;
/*     */   protected String allowAddAllToRight;
/*     */   protected String allowSelectAll;
/*     */   protected String allowUpDownOnLeft;
/*     */   protected String allowUpDownOnRight;
/*     */   protected String leftTitle;
/*     */   protected String rightTitle;
/*     */   protected String buttonCssClass;
/*     */   protected String buttonCssStyle;
/*     */   protected String addToLeftLabel;
/*     */   protected String addToRightLabel;
/*     */   protected String addAllToLeftLabel;
/*     */   protected String addAllToRightLabel;
/*     */   protected String selectAllLabel;
/*     */   protected String leftUpLabel;
/*     */   protected String leftDownlabel;
/*     */   protected String rightUpLabel;
/*     */   protected String rightDownLabel;
/*     */   protected String addToLeftOnclick;
/*     */   protected String addToRightOnclick;
/*     */   protected String addAllToLeftOnclick;
/*     */   protected String addAllToRightOnclick;
/*     */   protected String selectAllOnclick;
/*     */   protected String upDownOnLeftOnclick;
/*     */   protected String upDownOnRightOnclick;
/*     */ 
/*     */   public OptionTransferSelect(ValueStack stack, HttpServletRequest request, HttpServletResponse response)
/*     */   {
/* 135 */     super(stack, request, response);
/*     */   }
/*     */ 
/*     */   protected String getDefaultTemplate() {
/* 139 */     return "optiontransferselect";
/*     */   }
/*     */ 
/*     */   public void evaluateExtraParams()
/*     */   {
/* 144 */     super.evaluateExtraParams();
/*     */ 
/* 146 */     Object doubleValue = null;
/*     */ 
/* 149 */     if (this.doubleList != null) {
/* 150 */       doubleValue = findValue(this.doubleList);
/* 151 */       addParameter("doubleList", doubleValue);
/*     */     }
/* 153 */     if ((this.size == null) || (this.size.trim().length() <= 0)) {
/* 154 */       addParameter("size", "15");
/*     */     }
/* 156 */     if ((this.doubleSize == null) || (this.doubleSize.trim().length() <= 0)) {
/* 157 */       addParameter("doubleSize", "15");
/*     */     }
/* 159 */     if ((this.multiple == null) || (this.multiple.trim().length() <= 0)) {
/* 160 */       addParameter("multiple", Boolean.TRUE);
/*     */     }
/* 162 */     if ((this.doubleMultiple == null) || (this.doubleMultiple.trim().length() <= 0)) {
/* 163 */       addParameter("doubleMultiple", Boolean.TRUE);
/*     */     }
/*     */ 
/* 171 */     if ((this.buttonCssClass != null) && (this.buttonCssClass.trim().length() > 0)) {
/* 172 */       addParameter("buttonCssClass", this.buttonCssClass);
/*     */     }
/*     */ 
/* 176 */     if ((this.buttonCssStyle != null) && (this.buttonCssStyle.trim().length() > 0)) {
/* 177 */       addParameter("buttonCssStyle", this.buttonCssStyle);
/*     */     }
/*     */ 
/* 183 */     addParameter("allowSelectAll", this.allowSelectAll != null ? findValue(this.allowSelectAll, Boolean.class) : Boolean.TRUE);
/*     */ 
/* 187 */     addParameter("allowAddToLeft", this.allowAddToLeft != null ? findValue(this.allowAddToLeft, Boolean.class) : Boolean.TRUE);
/*     */ 
/* 191 */     addParameter("allowAddToRight", this.allowAddToRight != null ? findValue(this.allowAddToRight, Boolean.class) : Boolean.TRUE);
/*     */ 
/* 195 */     addParameter("allowAddAllToLeft", this.allowAddAllToLeft != null ? findValue(this.allowAddAllToLeft, Boolean.class) : Boolean.TRUE);
/*     */ 
/* 199 */     addParameter("allowAddAllToRight", this.allowAddAllToRight != null ? findValue(this.allowAddAllToRight, Boolean.class) : Boolean.TRUE);
/*     */ 
/* 203 */     addParameter("allowUpDownOnLeft", this.allowUpDownOnLeft != null ? findValue(this.allowUpDownOnLeft, Boolean.class) : Boolean.TRUE);
/*     */ 
/* 207 */     addParameter("allowUpDownOnRight", this.allowUpDownOnRight != null ? findValue(this.allowUpDownOnRight, Boolean.class) : Boolean.TRUE);
/*     */ 
/* 212 */     if (this.leftTitle != null) {
/* 213 */       addParameter("leftTitle", findValue(this.leftTitle, String.class));
/*     */     }
/*     */ 
/* 217 */     if (this.rightTitle != null) {
/* 218 */       addParameter("rightTitle", findValue(this.rightTitle, String.class));
/*     */     }
/*     */ 
/* 223 */     addParameter("addToLeftLabel", this.addToLeftLabel != null ? findValue(this.addToLeftLabel, String.class) : "<-");
/*     */ 
/* 227 */     addParameter("addToRightLabel", this.addToRightLabel != null ? findValue(this.addToRightLabel, String.class) : "->");
/*     */ 
/* 231 */     addParameter("addAllToLeftLabel", this.addAllToLeftLabel != null ? findValue(this.addAllToLeftLabel, String.class) : "<<--");
/*     */ 
/* 235 */     addParameter("addAllToRightLabel", this.addAllToRightLabel != null ? findValue(this.addAllToRightLabel, String.class) : "-->>");
/*     */ 
/* 239 */     addParameter("selectAllLabel", this.selectAllLabel != null ? findValue(this.selectAllLabel, String.class) : "<*>");
/*     */ 
/* 243 */     addParameter("leftUpLabel", this.leftUpLabel != null ? findValue(this.leftUpLabel, String.class) : "^");
/*     */ 
/* 248 */     addParameter("leftDownLabel", this.leftDownlabel != null ? findValue(this.leftDownlabel, String.class) : "v");
/*     */ 
/* 253 */     addParameter("rightUpLabel", this.rightUpLabel != null ? findValue(this.rightUpLabel, String.class) : "^");
/*     */ 
/* 258 */     addParameter("rightDownLabel", this.rightDownLabel != null ? findValue(this.rightDownLabel, String.class) : "v");
/*     */ 
/* 263 */     addParameter("selectAllOnclick", this.selectAllOnclick != null ? findValue(this.selectAllOnclick, String.class) : "");
/*     */ 
/* 267 */     addParameter("addToLeftOnclick", this.addToLeftOnclick != null ? findValue(this.addToLeftOnclick, String.class) : "");
/*     */ 
/* 271 */     addParameter("addToRightOnclick", this.addToRightOnclick != null ? findValue(this.addToRightOnclick, String.class) : "");
/*     */ 
/* 275 */     addParameter("addAllToLeftOnclick", this.addAllToLeftOnclick != null ? findValue(this.addAllToLeftOnclick, String.class) : "");
/*     */ 
/* 279 */     addParameter("addAllToRightOnclick", this.addAllToRightOnclick != null ? findValue(this.addAllToRightOnclick, String.class) : "");
/*     */ 
/* 283 */     addParameter("upDownOnLeftOnclick", this.upDownOnLeftOnclick != null ? findValue(this.upDownOnLeftOnclick, String.class) : "");
/*     */ 
/* 287 */     addParameter("upDownOnRightOnclick", this.upDownOnRightOnclick != null ? findValue(this.upDownOnRightOnclick, String.class) : "");
/*     */ 
/* 294 */     Form formAncestor = (Form)findAncestor(Form.class);
/* 295 */     if (formAncestor != null)
/*     */     {
/* 298 */       enableAncestorFormCustomOnsubmit();
/*     */ 
/* 302 */       Map formOptiontransferselectIds = (Map)formAncestor.getParameters().get("optiontransferselectIds");
/* 303 */       Map formOptiontransferselectDoubleIds = (Map)formAncestor.getParameters().get("optiontransferselectDoubleIds");
/*     */ 
/* 306 */       if (formOptiontransferselectIds == null) {
/* 307 */         formOptiontransferselectIds = new LinkedHashMap();
/*     */       }
/* 309 */       if (formOptiontransferselectDoubleIds == null) {
/* 310 */         formOptiontransferselectDoubleIds = new LinkedHashMap();
/*     */       }
/*     */ 
/* 315 */       String tmpId = (String)getParameters().get("id");
/* 316 */       String tmpHeaderKey = (String)getParameters().get("headerKey");
/* 317 */       if ((tmpId != null) && (!formOptiontransferselectIds.containsKey(tmpId))) {
/* 318 */         formOptiontransferselectIds.put(tmpId, tmpHeaderKey);
/*     */       }
/*     */ 
/* 322 */       String tmpDoubleId = (String)getParameters().get("doubleId");
/* 323 */       String tmpDoubleHeaderKey = (String)getParameters().get("doubleHeaderKey");
/* 324 */       if ((tmpDoubleId != null) && (!formOptiontransferselectDoubleIds.containsKey(tmpDoubleId))) {
/* 325 */         formOptiontransferselectDoubleIds.put(tmpDoubleId, tmpDoubleHeaderKey);
/*     */       }
/*     */ 
/* 328 */       formAncestor.getParameters().put("optiontransferselectIds", formOptiontransferselectIds);
/* 329 */       formAncestor.getParameters().put("optiontransferselectDoubleIds", formOptiontransferselectDoubleIds);
/*     */     }
/* 333 */     else if (LOG.isWarnEnabled()) {
/* 334 */       LOG.warn("form enclosing optiontransferselect " + this + " not found, auto select upon form submit of optiontransferselect will not work", new String[0]);
/*     */     }
/*     */   }
/*     */ 
/*     */   public String getAddAllToLeftLabel()
/*     */   {
/* 342 */     return this.addAllToLeftLabel;
/*     */   }
/*     */   @StrutsTagAttribute(description="Set Add To Left button label")
/*     */   public void setAddAllToLeftLabel(String addAllToLeftLabel) {
/* 347 */     this.addAllToLeftLabel = addAllToLeftLabel;
/*     */   }
/*     */ 
/*     */   public String getAddAllToRightLabel() {
/* 351 */     return this.addAllToRightLabel;
/*     */   }
/*     */   @StrutsTagAttribute(description="Set Add All To Right button label")
/*     */   public void setAddAllToRightLabel(String addAllToRightLabel) {
/* 356 */     this.addAllToRightLabel = addAllToRightLabel;
/*     */   }
/*     */ 
/*     */   public String getAddToLeftLabel() {
/* 360 */     return this.addToLeftLabel;
/*     */   }
/*     */   @StrutsTagAttribute(description="Set Add To Left button label")
/*     */   public void setAddToLeftLabel(String addToLeftLabel) {
/* 365 */     this.addToLeftLabel = addToLeftLabel;
/*     */   }
/*     */ 
/*     */   public String getAddToRightLabel() {
/* 369 */     return this.addToRightLabel;
/*     */   }
/*     */   @StrutsTagAttribute(description="Set Add To Right button label")
/*     */   public void setAddToRightLabel(String addToRightLabel) {
/* 374 */     this.addToRightLabel = addToRightLabel;
/*     */   }
/*     */ 
/*     */   public String getAllowAddAllToLeft() {
/* 378 */     return this.allowAddAllToLeft;
/*     */   }
/*     */   @StrutsTagAttribute(description="Enable Add All To Left button")
/*     */   public void setAllowAddAllToLeft(String allowAddAllToLeft) {
/* 383 */     this.allowAddAllToLeft = allowAddAllToLeft;
/*     */   }
/*     */ 
/*     */   public String getAllowAddAllToRight() {
/* 387 */     return this.allowAddAllToRight;
/*     */   }
/*     */   @StrutsTagAttribute(description="Enable Add All To Right button")
/*     */   public void setAllowAddAllToRight(String allowAddAllToRight) {
/* 392 */     this.allowAddAllToRight = allowAddAllToRight;
/*     */   }
/*     */ 
/*     */   public String getAllowAddToLeft() {
/* 396 */     return this.allowAddToLeft;
/*     */   }
/*     */   @StrutsTagAttribute(description="Enable Add To Left button")
/*     */   public void setAllowAddToLeft(String allowAddToLeft) {
/* 401 */     this.allowAddToLeft = allowAddToLeft;
/*     */   }
/*     */ 
/*     */   public String getAllowAddToRight() {
/* 405 */     return this.allowAddToRight;
/*     */   }
/*     */   @StrutsTagAttribute(description="Enable Add To Right button")
/*     */   public void setAllowAddToRight(String allowAddToRight) {
/* 410 */     this.allowAddToRight = allowAddToRight;
/*     */   }
/*     */ 
/*     */   public String getLeftTitle() {
/* 414 */     return this.leftTitle;
/*     */   }
/*     */   @StrutsTagAttribute(description="Enable up / down on the left side")
/*     */   public void setAllowUpDownOnLeft(String allowUpDownOnLeft) {
/* 419 */     this.allowUpDownOnLeft = allowUpDownOnLeft;
/*     */   }
/*     */ 
/*     */   public String getAllowUpDownOnLeft() {
/* 423 */     return this.allowUpDownOnLeft;
/*     */   }
/*     */   @StrutsTagAttribute(description="Enable up / down on the right side")
/*     */   public void setAllowUpDownOnRight(String allowUpDownOnRight) {
/* 428 */     this.allowUpDownOnRight = allowUpDownOnRight;
/*     */   }
/*     */ 
/*     */   public String getAllowUpDownOnRight() {
/* 432 */     return this.allowUpDownOnRight;
/*     */   }
/*     */   @StrutsTagAttribute(description="Set Left title")
/*     */   public void setLeftTitle(String leftTitle) {
/* 437 */     this.leftTitle = leftTitle;
/*     */   }
/*     */ 
/*     */   public String getRightTitle() {
/* 441 */     return this.rightTitle;
/*     */   }
/*     */   @StrutsTagAttribute(description="Set Right title")
/*     */   public void setRightTitle(String rightTitle) {
/* 446 */     this.rightTitle = rightTitle;
/*     */   }
/*     */   @StrutsTagAttribute(description="Enable Select All button")
/*     */   public void setAllowSelectAll(String allowSelectAll) {
/* 451 */     this.allowSelectAll = allowSelectAll;
/*     */   }
/*     */ 
/*     */   public String getAllowSelectAll() {
/* 455 */     return this.allowSelectAll;
/*     */   }
/*     */   @StrutsTagAttribute(description="Set Select All button label")
/*     */   public void setSelectAllLabel(String selectAllLabel) {
/* 460 */     this.selectAllLabel = selectAllLabel;
/*     */   }
/*     */ 
/*     */   public String getSelectAllLabel() {
/* 464 */     return this.selectAllLabel;
/*     */   }
/*     */   @StrutsTagAttribute(description="Set buttons css class")
/*     */   public void setButtonCssClass(String buttonCssClass) {
/* 469 */     this.buttonCssClass = buttonCssClass;
/*     */   }
/*     */ 
/*     */   public String getButtonCssClass() {
/* 473 */     return this.buttonCssClass;
/*     */   }
/*     */   @StrutsTagAttribute(description="Set button css style")
/*     */   public void setButtonCssStyle(String buttonCssStyle) {
/* 478 */     this.buttonCssStyle = buttonCssStyle;
/*     */   }
/*     */ 
/*     */   public String getButtonCssStyle() {
/* 482 */     return this.buttonCssStyle;
/*     */   }
/*     */   @StrutsTagAttribute(description="Up label for the left side")
/*     */   public void setLeftUpLabel(String leftUpLabel) {
/* 487 */     this.leftUpLabel = leftUpLabel;
/*     */   }
/*     */   public String getLeftUpLabel() {
/* 490 */     return this.leftUpLabel;
/*     */   }
/*     */   @StrutsTagAttribute(description="Down label for the left side.")
/*     */   public void setLeftDownLabel(String leftDownLabel) {
/* 495 */     this.leftDownlabel = leftDownLabel;
/*     */   }
/*     */   public String getLeftDownLabel() {
/* 498 */     return this.leftDownlabel;
/*     */   }
/*     */   @StrutsTagAttribute(description="Up label for the right side.")
/*     */   public void setRightUpLabel(String rightUpLabel) {
/* 503 */     this.rightUpLabel = rightUpLabel;
/*     */   }
/*     */   public String getRightUpLabel() {
/* 506 */     return this.rightUpLabel;
/*     */   }
/*     */   @StrutsTagAttribute(description="Down label for the left side.")
/*     */   public void setRightDownLabel(String rightDownlabel) {
/* 511 */     this.rightDownLabel = rightDownlabel;
/*     */   }
/*     */   public String getRightDownLabel() {
/* 514 */     return this.rightDownLabel;
/*     */   }
/*     */ 
/*     */   public String getAddAllToLeftOnclick() {
/* 518 */     return this.addAllToLeftOnclick;
/*     */   }
/*     */   @StrutsTagAttribute(description="Javascript to run after Add All To Left button pressed")
/*     */   public void setAddAllToLeftOnclick(String addAllToLeftOnclick) {
/* 523 */     this.addAllToLeftOnclick = addAllToLeftOnclick;
/*     */   }
/*     */ 
/*     */   public String getAddAllToRightOnclick() {
/* 527 */     return this.addAllToRightOnclick;
/*     */   }
/*     */   @StrutsTagAttribute(description="Javascript to run after Add All To Right button pressed")
/*     */   public void setAddAllToRightOnclick(String addAllToRightOnclick) {
/* 532 */     this.addAllToRightOnclick = addAllToRightOnclick;
/*     */   }
/*     */ 
/*     */   public String getAddToLeftOnclick() {
/* 536 */     return this.addToLeftOnclick;
/*     */   }
/*     */   @StrutsTagAttribute(description="Javascript to run after Add To Left button pressed")
/*     */   public void setAddToLeftOnclick(String addToLeftOnclick) {
/* 541 */     this.addToLeftOnclick = addToLeftOnclick;
/*     */   }
/*     */ 
/*     */   public String getAddToRightOnclick() {
/* 545 */     return this.addToRightOnclick;
/*     */   }
/*     */   @StrutsTagAttribute(description="Javascript to run after Add To Right button pressed")
/*     */   public void setAddToRightOnclick(String addToRightOnclick) {
/* 550 */     this.addToRightOnclick = addToRightOnclick;
/*     */   }
/*     */   @StrutsTagAttribute(description="Javascript to run after up / down on the left side buttons pressed")
/*     */   public void setUpDownOnLeftOnclick(String upDownOnLeftOnclick) {
/* 555 */     this.upDownOnLeftOnclick = upDownOnLeftOnclick;
/*     */   }
/*     */ 
/*     */   public String getUpDownOnLeftOnclick() {
/* 559 */     return this.upDownOnLeftOnclick;
/*     */   }
/*     */   @StrutsTagAttribute(description="Javascript to run after up / down on the right side buttons pressed")
/*     */   public void setUpDownOnRightOnclick(String upDownOnRightOnclick) {
/* 564 */     this.upDownOnRightOnclick = upDownOnRightOnclick;
/*     */   }
/*     */ 
/*     */   public String getUpDownOnRightOnclick() {
/* 568 */     return this.upDownOnRightOnclick;
/*     */   }
/*     */   @StrutsTagAttribute(description="Javascript to run after Select All button pressed")
/*     */   public void setSelectAllOnclick(String selectAllOnclick) {
/* 573 */     this.selectAllOnclick = selectAllOnclick;
/*     */   }
/*     */ 
/*     */   public String getSelectAllOnclick() {
/* 577 */     return this.selectAllOnclick;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.components.OptionTransferSelect
 * JD-Core Version:    0.6.0
 */