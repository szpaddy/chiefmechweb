package org.apache.struts2.components;

import java.io.Writer;
import org.apache.struts2.dispatcher.mapper.ActionMapper;

public abstract interface UrlRenderer
{
  public abstract void beforeRenderUrl(UrlProvider paramUrlProvider);

  public abstract void renderUrl(Writer paramWriter, UrlProvider paramUrlProvider);

  public abstract void renderFormUrl(Form paramForm);

  public abstract void setActionMapper(ActionMapper paramActionMapper);
}

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.components.UrlRenderer
 * JD-Core Version:    0.6.0
 */