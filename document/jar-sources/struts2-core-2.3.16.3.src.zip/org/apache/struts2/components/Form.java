/*     */ package org.apache.struts2.components;
/*     */ 
/*     */ import com.opensymphony.xwork2.ObjectFactory;
/*     */ import com.opensymphony.xwork2.config.Configuration;
/*     */ import com.opensymphony.xwork2.config.RuntimeConfiguration;
/*     */ import com.opensymphony.xwork2.config.entities.ActionConfig;
/*     */ import com.opensymphony.xwork2.config.entities.InterceptorMapping;
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import com.opensymphony.xwork2.interceptor.MethodFilterInterceptorUtil;
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import com.opensymphony.xwork2.validator.ActionValidatorManager;
/*     */ import com.opensymphony.xwork2.validator.FieldValidator;
/*     */ import com.opensymphony.xwork2.validator.ValidationException;
/*     */ import com.opensymphony.xwork2.validator.ValidationInterceptor;
/*     */ import com.opensymphony.xwork2.validator.Validator;
/*     */ import com.opensymphony.xwork2.validator.ValidatorContext;
/*     */ import com.opensymphony.xwork2.validator.validators.VisitorFieldValidator;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.struts2.dispatcher.mapper.ActionMapper;
/*     */ import org.apache.struts2.dispatcher.mapper.ActionMapping;
/*     */ import org.apache.struts2.views.annotations.StrutsTag;
/*     */ import org.apache.struts2.views.annotations.StrutsTagAttribute;
/*     */ 
/*     */ @StrutsTag(name="form", tldTagClass="org.apache.struts2.views.jsp.ui.FormTag", description="Renders an input form", allowDynamicAttributes=true)
/*     */ public class Form extends ClosingUIBean
/*     */ {
/*     */   public static final String OPEN_TEMPLATE = "form";
/*     */   public static final String TEMPLATE = "form-close";
/* 100 */   private int sequence = 0;
/*     */   protected String onsubmit;
/*     */   protected String onreset;
/*     */   protected String action;
/*     */   protected String target;
/*     */   protected String enctype;
/*     */   protected String method;
/*     */   protected String namespace;
/*     */   protected String validate;
/*     */   protected String portletMode;
/*     */   protected String windowState;
/*     */   protected String acceptcharset;
/* 113 */   protected boolean includeContext = true;
/*     */   protected String focusElement;
/*     */   protected Configuration configuration;
/*     */   protected ObjectFactory objectFactory;
/*     */   protected UrlRenderer urlRenderer;
/*     */   protected ActionValidatorManager actionValidatorManager;
/*     */ 
/*     */   public Form(ValueStack stack, HttpServletRequest request, HttpServletResponse response)
/*     */   {
/* 122 */     super(stack, request, response);
/*     */   }
/*     */ 
/*     */   protected boolean evaluateNameValue()
/*     */   {
/* 127 */     return false;
/*     */   }
/*     */ 
/*     */   public String getDefaultOpenTemplate()
/*     */   {
/* 132 */     return "form";
/*     */   }
/*     */ 
/*     */   protected String getDefaultTemplate()
/*     */   {
/* 137 */     return "form-close";
/*     */   }
/*     */   @Inject
/*     */   public void setConfiguration(Configuration configuration) {
/* 142 */     this.configuration = configuration;
/*     */   }
/*     */   @Inject
/*     */   public void setObjectFactory(ObjectFactory objectFactory) {
/* 147 */     this.objectFactory = objectFactory;
/*     */   }
/*     */   @Inject
/*     */   public void setUrlRenderer(UrlRenderer urlRenderer) {
/* 152 */     this.urlRenderer = urlRenderer;
/*     */   }
/*     */   @Inject
/*     */   public void setActionValidatorManager(ActionValidatorManager mgr) {
/* 157 */     this.actionValidatorManager = mgr;
/*     */   }
/*     */ 
/*     */   protected void evaluateExtraParams()
/*     */   {
/* 167 */     super.evaluateExtraParams();
/* 168 */     if (this.validate != null) {
/* 169 */       addParameter("validate", findValue(this.validate, Boolean.class));
/*     */     }
/*     */ 
/* 172 */     if (this.name == null)
/*     */     {
/* 174 */       String id = (String)getParameters().get("id");
/* 175 */       if (org.apache.commons.lang3.StringUtils.isNotEmpty(id)) {
/* 176 */         addParameter("name", id);
/*     */       }
/*     */     }
/*     */ 
/* 180 */     if (this.onsubmit != null) {
/* 181 */       addParameter("onsubmit", findString(this.onsubmit));
/*     */     }
/*     */ 
/* 184 */     if (this.onreset != null) {
/* 185 */       addParameter("onreset", findString(this.onreset));
/*     */     }
/*     */ 
/* 188 */     if (this.target != null) {
/* 189 */       addParameter("target", findString(this.target));
/*     */     }
/*     */ 
/* 192 */     if (this.enctype != null) {
/* 193 */       addParameter("enctype", findString(this.enctype));
/*     */     }
/*     */ 
/* 196 */     if (this.method != null) {
/* 197 */       addParameter("method", findString(this.method));
/*     */     }
/*     */ 
/* 200 */     if (this.acceptcharset != null) {
/* 201 */       addParameter("acceptcharset", findString(this.acceptcharset));
/*     */     }
/*     */ 
/* 206 */     if (!this.parameters.containsKey("tagNames"))
/*     */     {
/* 208 */       addParameter("tagNames", new ArrayList());
/*     */     }
/*     */ 
/* 211 */     if (this.focusElement != null)
/* 212 */       addParameter("focusElement", findString(this.focusElement));
/*     */   }
/*     */ 
/*     */   protected void populateComponentHtmlId(Form form)
/*     */   {
/* 225 */     if (this.id != null) {
/* 226 */       addParameter("id", escape(this.id));
/*     */     }
/*     */ 
/* 231 */     this.urlRenderer.renderFormUrl(this);
/*     */   }
/*     */ 
/*     */   protected void evaluateClientSideJsEnablement(String actionName, String namespace, String actionMethod)
/*     */   {
/* 243 */     Boolean validate = (Boolean)getParameters().get("validate");
/* 244 */     if ((validate != null) && (validate.booleanValue()))
/*     */     {
/* 246 */       addParameter("performValidation", Boolean.FALSE);
/*     */ 
/* 248 */       RuntimeConfiguration runtimeConfiguration = this.configuration.getRuntimeConfiguration();
/* 249 */       ActionConfig actionConfig = runtimeConfiguration.getActionConfig(namespace, actionName);
/*     */ 
/* 251 */       if (actionConfig != null) {
/* 252 */         List interceptors = actionConfig.getInterceptors();
/* 253 */         for (InterceptorMapping interceptorMapping : interceptors)
/* 254 */           if (ValidationInterceptor.class.isInstance(interceptorMapping.getInterceptor())) {
/* 255 */             ValidationInterceptor validationInterceptor = (ValidationInterceptor)interceptorMapping.getInterceptor();
/*     */ 
/* 257 */             Set excludeMethods = validationInterceptor.getExcludeMethodsSet();
/* 258 */             Set includeMethods = validationInterceptor.getIncludeMethodsSet();
/*     */ 
/* 260 */             if (MethodFilterInterceptorUtil.applyMethod(excludeMethods, includeMethods, actionMethod)) {
/* 261 */               addParameter("performValidation", Boolean.TRUE);
/*     */             }
/* 263 */             return;
/*     */           }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public List getValidators(String name)
/*     */   {
/* 271 */     Class actionClass = (Class)getParameters().get("actionClass");
/* 272 */     if (actionClass == null) {
/* 273 */       return Collections.EMPTY_LIST;
/*     */     }
/*     */ 
/* 276 */     String formActionValue = findString(this.action);
/* 277 */     ActionMapping mapping = this.actionMapper.getMappingFromActionName(formActionValue);
/* 278 */     String actionName = mapping.getName();
/*     */ 
/* 280 */     List actionValidators = this.actionValidatorManager.getValidators(actionClass, actionName);
/* 281 */     List validators = new ArrayList();
/*     */ 
/* 283 */     findFieldValidators(name, actionClass, actionName, actionValidators, validators, "");
/*     */ 
/* 285 */     return validators;
/*     */   }
/*     */ 
/*     */   private void findFieldValidators(String name, Class actionClass, String actionName, List<Validator> validatorList, List<Validator> retultValidators, String prefix)
/*     */   {
/* 291 */     for (Validator validator : validatorList)
/* 292 */       if ((validator instanceof FieldValidator)) {
/* 293 */         FieldValidator fieldValidator = (FieldValidator)validator;
/*     */ 
/* 295 */         if ((validator instanceof VisitorFieldValidator)) {
/* 296 */           VisitorFieldValidator vfValidator = (VisitorFieldValidator)fieldValidator;
/* 297 */           Class clazz = getVisitorReturnType(actionClass, vfValidator.getFieldName());
/* 298 */           if (clazz == null)
/*     */           {
/*     */             continue;
/*     */           }
/* 302 */           List visitorValidators = this.actionValidatorManager.getValidators(clazz, actionName);
/* 303 */           String vPrefix = prefix + (vfValidator.isAppendPrefix() ? vfValidator.getFieldName() + "." : "");
/* 304 */           findFieldValidators(name, clazz, actionName, visitorValidators, retultValidators, vPrefix);
/* 305 */         } else if ((prefix + fieldValidator.getFieldName()).equals(name)) {
/* 306 */           if (org.apache.commons.lang3.StringUtils.isNotBlank(prefix))
/*     */           {
/* 308 */             FieldVisitorValidatorWrapper wrap = new FieldVisitorValidatorWrapper(fieldValidator, prefix);
/* 309 */             retultValidators.add(wrap);
/*     */           } else {
/* 311 */             retultValidators.add(fieldValidator);
/*     */           }
/*     */         }
/*     */       }
/*     */   }
/*     */ 
/*     */   protected Class getVisitorReturnType(Class actionClass, String visitorFieldName)
/*     */   {
/* 400 */     if (visitorFieldName == null) {
/* 401 */       return null;
/*     */     }
/* 403 */     String methodName = "get" + org.apache.commons.lang.StringUtils.capitalize(visitorFieldName);
/*     */     try {
/* 405 */       Method method = actionClass.getMethod(methodName, new Class[0]);
/* 406 */       return method.getReturnType(); } catch (NoSuchMethodException e) {
/*     */     }
/* 408 */     return null;
/*     */   }
/*     */ 
/*     */   protected int getSequence()
/*     */   {
/* 421 */     return this.sequence++;
/*     */   }
/*     */   @StrutsTagAttribute(description="HTML onsubmit attribute")
/*     */   public void setOnsubmit(String onsubmit) {
/* 426 */     this.onsubmit = onsubmit;
/*     */   }
/*     */   @StrutsTagAttribute(description="HTML onreset attribute")
/*     */   public void setOnreset(String onreset) {
/* 431 */     this.onreset = onreset;
/*     */   }
/*     */   @StrutsTagAttribute(description="Set action name to submit to, without .action suffix", defaultValue="current action")
/*     */   public void setAction(String action) {
/* 436 */     this.action = action;
/*     */   }
/*     */   @StrutsTagAttribute(description="HTML form target attribute")
/*     */   public void setTarget(String target) {
/* 441 */     this.target = target;
/*     */   }
/*     */   @StrutsTagAttribute(description="HTML form enctype attribute")
/*     */   public void setEnctype(String enctype) {
/* 446 */     this.enctype = enctype;
/*     */   }
/*     */   @StrutsTagAttribute(description="HTML form method attribute")
/*     */   public void setMethod(String method) {
/* 451 */     this.method = method;
/*     */   }
/*     */   @StrutsTagAttribute(description="Namespace for action to submit to", defaultValue="current namespace")
/*     */   public void setNamespace(String namespace) {
/* 456 */     this.namespace = namespace;
/*     */   }
/*     */ 
/*     */   @StrutsTagAttribute(description="Whether client side/remote validation should be performed. Only useful with theme xhtml/ajax", type="Boolean", defaultValue="false")
/*     */   public void setValidate(String validate) {
/* 462 */     this.validate = validate;
/*     */   }
/*     */   @StrutsTagAttribute(description="The portlet mode to display after the form submit")
/*     */   public void setPortletMode(String portletMode) {
/* 467 */     this.portletMode = portletMode;
/*     */   }
/*     */   @StrutsTagAttribute(description="The window state to display after the form submit")
/*     */   public void setWindowState(String windowState) {
/* 472 */     this.windowState = windowState;
/*     */   }
/*     */   @StrutsTagAttribute(description="The accepted charsets for this form. The values may be comma or blank delimited.")
/*     */   public void setAcceptcharset(String acceptcharset) {
/* 477 */     this.acceptcharset = acceptcharset;
/*     */   }
/*     */   @StrutsTagAttribute(description="Id of element that will receive the focus when page loads.")
/*     */   public void setFocusElement(String focusElement) {
/* 482 */     this.focusElement = focusElement;
/*     */   }
/*     */   @StrutsTagAttribute(description="Whether actual context should be included in URL", type="Boolean", defaultValue="true")
/*     */   public void setIncludeContext(boolean includeContext) {
/* 487 */     this.includeContext = includeContext;
/*     */   }
/*     */ 
/*     */   public static class FieldVisitorValidatorWrapper
/*     */     implements FieldValidator
/*     */   {
/*     */     private FieldValidator fieldValidator;
/*     */     private String namePrefix;
/*     */ 
/*     */     public FieldVisitorValidatorWrapper(FieldValidator fv, String namePrefix)
/*     */     {
/* 330 */       this.fieldValidator = fv;
/* 331 */       this.namePrefix = namePrefix;
/*     */     }
/*     */     public String getValidatorType() {
/* 334 */       return "field-visitor";
/*     */     }
/*     */     public String getFieldName() {
/* 337 */       return this.namePrefix + this.fieldValidator.getFieldName();
/*     */     }
/*     */     public FieldValidator getFieldValidator() {
/* 340 */       return this.fieldValidator;
/*     */     }
/*     */     public void setFieldValidator(FieldValidator fieldValidator) {
/* 343 */       this.fieldValidator = fieldValidator;
/*     */     }
/*     */     public String getDefaultMessage() {
/* 346 */       return this.fieldValidator.getDefaultMessage();
/*     */     }
/*     */     public String getMessage(Object object) {
/* 349 */       return this.fieldValidator.getMessage(object);
/*     */     }
/*     */     public String getMessageKey() {
/* 352 */       return this.fieldValidator.getMessageKey();
/*     */     }
/*     */     public String[] getMessageParameters() {
/* 355 */       return this.fieldValidator.getMessageParameters();
/*     */     }
/*     */     public ValidatorContext getValidatorContext() {
/* 358 */       return this.fieldValidator.getValidatorContext();
/*     */     }
/*     */     public void setDefaultMessage(String message) {
/* 361 */       this.fieldValidator.setDefaultMessage(message);
/*     */     }
/*     */     public void setFieldName(String fieldName) {
/* 364 */       this.fieldValidator.setFieldName(fieldName);
/*     */     }
/*     */     public void setMessageKey(String key) {
/* 367 */       this.fieldValidator.setMessageKey(key);
/*     */     }
/*     */     public void setMessageParameters(String[] messageParameters) {
/* 370 */       this.fieldValidator.setMessageParameters(messageParameters);
/*     */     }
/*     */     public void setValidatorContext(ValidatorContext validatorContext) {
/* 373 */       this.fieldValidator.setValidatorContext(validatorContext);
/*     */     }
/*     */     public void setValidatorType(String type) {
/* 376 */       this.fieldValidator.setValidatorType(type);
/*     */     }
/*     */     public void setValueStack(ValueStack stack) {
/* 379 */       this.fieldValidator.setValueStack(stack);
/*     */     }
/*     */     public void validate(Object object) throws ValidationException {
/* 382 */       this.fieldValidator.validate(object);
/*     */     }
/*     */     public String getNamePrefix() {
/* 385 */       return this.namePrefix;
/*     */     }
/*     */     public void setNamePrefix(String namePrefix) {
/* 388 */       this.namePrefix = namePrefix;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.components.Form
 * JD-Core Version:    0.6.0
 */