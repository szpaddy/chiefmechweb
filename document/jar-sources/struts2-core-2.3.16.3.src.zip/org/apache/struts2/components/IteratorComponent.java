/*     */ package org.apache.struts2.components;
/*     */ 
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import com.opensymphony.xwork2.util.logging.Logger;
/*     */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*     */ import java.io.Writer;
/*     */ import java.util.Arrays;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.struts2.util.MakeIterator;
/*     */ import org.apache.struts2.views.annotations.StrutsTag;
/*     */ import org.apache.struts2.views.annotations.StrutsTagAttribute;
/*     */ import org.apache.struts2.views.jsp.IteratorStatus;
/*     */ import org.apache.struts2.views.jsp.IteratorStatus.StatusState;
/*     */ 
/*     */ @StrutsTag(name="iterator", tldTagClass="org.apache.struts2.views.jsp.IteratorTag", description="Iterate over a iterable value")
/*     */ public class IteratorComponent extends ContextBean
/*     */ {
/* 228 */   private static final Logger LOG = LoggerFactory.getLogger(IteratorComponent.class);
/*     */   protected Iterator iterator;
/*     */   protected IteratorStatus status;
/*     */   protected Object oldStatus;
/*     */   protected IteratorStatus.StatusState statusState;
/*     */   protected String statusAttr;
/*     */   protected String value;
/*     */   protected String beginStr;
/*     */   protected Integer begin;
/*     */   protected String endStr;
/*     */   protected Integer end;
/*     */   protected String stepStr;
/*     */   protected Integer step;
/*     */ 
/*     */   public IteratorComponent(ValueStack stack)
/*     */   {
/* 244 */     super(stack);
/*     */   }
/*     */ 
/*     */   public boolean start(Writer writer)
/*     */   {
/* 249 */     if (this.statusAttr != null) {
/* 250 */       this.statusState = new IteratorStatus.StatusState();
/* 251 */       this.status = new IteratorStatus(this.statusState);
/*     */     }
/*     */ 
/* 254 */     if (this.beginStr != null) {
/* 255 */       this.begin = ((Integer)findValue(this.beginStr, Integer.class));
/*     */     }
/* 257 */     if (this.endStr != null) {
/* 258 */       this.end = ((Integer)findValue(this.endStr, Integer.class));
/*     */     }
/* 260 */     if (this.stepStr != null) {
/* 261 */       this.step = ((Integer)findValue(this.stepStr, Integer.class));
/*     */     }
/* 263 */     ValueStack stack = getStack();
/*     */ 
/* 265 */     if ((this.value == null) && (this.begin == null) && (this.end == null)) {
/* 266 */       this.value = "top";
/*     */     }
/* 268 */     Object iteratorTarget = findValue(this.value);
/* 269 */     this.iterator = MakeIterator.convert(iteratorTarget);
/*     */ 
/* 271 */     if (this.begin != null)
/*     */     {
/* 273 */       if (this.step == null) {
/* 274 */         this.step = Integer.valueOf(1);
/*     */       }
/* 276 */       if (this.iterator == null)
/*     */       {
/* 278 */         this.iterator = new CounterIterator(this.begin, this.end, this.step, null);
/* 279 */       } else if (this.iterator != null)
/*     */       {
/* 281 */         if (iteratorTarget.getClass().isArray()) {
/* 282 */           Object[] values = (Object[])(Object[])iteratorTarget;
/* 283 */           if (this.end == null)
/* 284 */             this.end = Integer.valueOf(this.step.intValue() > 0 ? values.length - 1 : 0);
/* 285 */           this.iterator = new CounterIterator(this.begin, this.end, this.step, Arrays.asList(values));
/* 286 */         } else if ((iteratorTarget instanceof List)) {
/* 287 */           List values = (List)iteratorTarget;
/* 288 */           if (this.end == null)
/* 289 */             this.end = Integer.valueOf(this.step.intValue() > 0 ? values.size() - 1 : 0);
/* 290 */           this.iterator = new CounterIterator(this.begin, this.end, this.step, values);
/*     */         }
/*     */         else {
/* 293 */           LOG.error("Incorrect use of the iterator tag. When 'begin' is set, 'value' must be an Array or a List, or not set at all. 'begin', 'end' and 'step' will be ignored", new String[0]);
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 300 */     if ((this.iterator != null) && (this.iterator.hasNext())) {
/* 301 */       Object currentValue = this.iterator.next();
/* 302 */       stack.push(currentValue);
/*     */ 
/* 304 */       String var = getVar();
/*     */ 
/* 306 */       if ((var != null) && (currentValue != null))
/*     */       {
/* 309 */         putInContext(currentValue);
/*     */       }
/*     */ 
/* 313 */       if (this.statusAttr != null) {
/* 314 */         this.statusState.setLast(!this.iterator.hasNext());
/* 315 */         this.oldStatus = stack.getContext().get(this.statusAttr);
/* 316 */         stack.getContext().put(this.statusAttr, this.status);
/*     */       }
/*     */ 
/* 319 */       return true;
/*     */     }
/* 321 */     super.end(writer, "");
/* 322 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean end(Writer writer, String body)
/*     */   {
/* 327 */     ValueStack stack = getStack();
/* 328 */     if (this.iterator != null) {
/* 329 */       stack.pop();
/*     */     }
/*     */ 
/* 332 */     if ((this.iterator != null) && (this.iterator.hasNext())) {
/* 333 */       Object currentValue = this.iterator.next();
/* 334 */       stack.push(currentValue);
/*     */ 
/* 336 */       putInContext(currentValue);
/*     */ 
/* 339 */       if (this.status != null) {
/* 340 */         this.statusState.next();
/* 341 */         this.statusState.setLast(!this.iterator.hasNext());
/*     */       }
/*     */ 
/* 344 */       return true;
/*     */     }
/*     */ 
/* 347 */     if (this.status != null) {
/* 348 */       if (this.oldStatus == null)
/* 349 */         stack.getContext().put(this.statusAttr, null);
/*     */       else {
/* 351 */         stack.getContext().put(this.statusAttr, this.oldStatus);
/*     */       }
/*     */     }
/* 354 */     super.end(writer, "");
/* 355 */     return false;
/*     */   }
/*     */ 
/*     */   @StrutsTagAttribute(description="If specified, an instanceof IteratorStatus will be pushed into stack upon each iteration", type="Boolean", defaultValue="false")
/*     */   public void setStatus(String status)
/*     */   {
/* 400 */     this.statusAttr = status;
/*     */   }
/*     */   @StrutsTagAttribute(description="the iteratable source to iterate over, else an the object itself will be put into a newly created List")
/*     */   public void setValue(String value) {
/* 405 */     this.value = value;
/*     */   }
/*     */   @StrutsTagAttribute(description="if specified the iteration will start on that index", type="Integer", defaultValue="0")
/*     */   public void setBegin(String begin) {
/* 410 */     this.beginStr = begin;
/*     */   }
/*     */ 
/*     */   @StrutsTagAttribute(description="if specified the iteration will end on that index(inclusive)", type="Integer", defaultValue="Size of the 'values' List or array, or 0 if 'step' is negative")
/*     */   public void setEnd(String end) {
/* 416 */     this.endStr = end;
/*     */   }
/*     */ 
/*     */   @StrutsTagAttribute(description="if specified the iteration index will be increased by this value on each iteration. It can be a negative value, in which case 'begin' must be greater than 'end'", type="Integer", defaultValue="1")
/*     */   public void setStep(String step) {
/* 422 */     this.stepStr = step;
/*     */   }
/*     */ 
/*     */   static class CounterIterator
/*     */     implements Iterator<Object>
/*     */   {
/*     */     private int step;
/*     */     private int end;
/*     */     private int currentIndex;
/*     */     private List<Object> values;
/*     */ 
/*     */     CounterIterator(Integer begin, Integer end, Integer step, List<Object> values)
/*     */     {
/* 366 */       this.end = end.intValue();
/* 367 */       if (step != null)
/* 368 */         this.step = step.intValue();
/* 369 */       this.currentIndex = (begin.intValue() - this.step);
/* 370 */       this.values = values;
/*     */     }
/*     */ 
/*     */     public boolean hasNext() {
/* 374 */       int next = peekNextIndex();
/* 375 */       return next <= this.end;
/*     */     }
/*     */ 
/*     */     public Object next() {
/* 379 */       if (hasNext()) {
/* 380 */         int nextIndex = peekNextIndex();
/* 381 */         this.currentIndex += this.step;
/* 382 */         return this.values != null ? this.values.get(nextIndex) : Integer.valueOf(nextIndex);
/*     */       }
/* 384 */       throw new IndexOutOfBoundsException("Index " + (this.currentIndex + this.step) + " must be less than or equal to " + this.end);
/*     */     }
/*     */ 
/*     */     private int peekNextIndex()
/*     */     {
/* 389 */       return this.currentIndex + this.step;
/*     */     }
/*     */ 
/*     */     public void remove() {
/* 393 */       throw new UnsupportedOperationException("Values cannot be removed from this iterator");
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.components.IteratorComponent
 * JD-Core Version:    0.6.0
 */