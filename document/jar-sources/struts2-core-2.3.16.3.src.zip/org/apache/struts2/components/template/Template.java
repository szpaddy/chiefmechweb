/*    */ package org.apache.struts2.components.template;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class Template
/*    */   implements Cloneable
/*    */ {
/*    */   String dir;
/*    */   String theme;
/*    */   String name;
/*    */ 
/*    */   public Template(String dir, String theme, String name)
/*    */   {
/* 46 */     this.dir = dir;
/* 47 */     this.theme = theme;
/* 48 */     this.name = name;
/*    */   }
/*    */ 
/*    */   public String getDir() {
/* 52 */     return this.dir;
/*    */   }
/*    */ 
/*    */   public String getTheme() {
/* 56 */     return this.theme;
/*    */   }
/*    */ 
/*    */   public String getName() {
/* 60 */     return this.name;
/*    */   }
/*    */ 
/*    */   public List<Template> getPossibleTemplates(TemplateEngine engine) {
/* 64 */     List list = new ArrayList(3);
/* 65 */     Template template = this;
/*    */ 
/* 67 */     list.add(template);
/*    */     String parentTheme;
/* 68 */     while ((parentTheme = (String)engine.getThemeProps(template).get("parent")) != null) {
/*    */       try {
/* 70 */         template = (Template)template.clone();
/* 71 */         template.theme = parentTheme;
/* 72 */         list.add(template);
/*    */       }
/*    */       catch (CloneNotSupportedException e)
/*    */       {
/*    */       }
/*    */     }
/* 78 */     return list;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 86 */     return "/" + this.dir + "/" + this.theme + "/" + this.name;
/*    */   }
/*    */ 
/*    */   protected Object clone() throws CloneNotSupportedException {
/* 90 */     return super.clone();
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.components.template.Template
 * JD-Core Version:    0.6.0
 */