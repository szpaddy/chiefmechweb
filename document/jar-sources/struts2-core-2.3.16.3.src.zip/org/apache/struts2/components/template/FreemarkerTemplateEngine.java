/*     */ package org.apache.struts2.components.template;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionContext;
/*     */ import com.opensymphony.xwork2.ActionInvocation;
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import com.opensymphony.xwork2.util.ClassLoaderUtil;
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import com.opensymphony.xwork2.util.logging.Logger;
/*     */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*     */ import freemarker.core.ParseException;
/*     */ import freemarker.template.Configuration;
/*     */ import freemarker.template.SimpleHash;
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.struts2.views.freemarker.FreemarkerManager;
/*     */ 
/*     */ public class FreemarkerTemplateEngine extends BaseTemplateEngine
/*     */ {
/*  53 */   static Class bodyContent = null;
/*     */   protected FreemarkerManager freemarkerManager;
/*     */   private static final Logger LOG;
/*     */ 
/*     */   @Inject
/*     */   public void setFreemarkerManager(FreemarkerManager mgr)
/*     */   {
/*  72 */     this.freemarkerManager = mgr;
/*     */   }
/*     */ 
/*     */   public void renderTemplate(TemplateRenderingContext templateContext) throws Exception
/*     */   {
/*  77 */     ValueStack stack = templateContext.getStack();
/*  78 */     Map context = stack.getContext();
/*  79 */     ServletContext servletContext = (ServletContext)context.get("com.opensymphony.xwork2.dispatcher.ServletContext");
/*  80 */     HttpServletRequest req = (HttpServletRequest)context.get("com.opensymphony.xwork2.dispatcher.HttpServletRequest");
/*  81 */     HttpServletResponse res = (HttpServletResponse)context.get("com.opensymphony.xwork2.dispatcher.HttpServletResponse");
/*     */ 
/*  84 */     Configuration config = this.freemarkerManager.getConfiguration(servletContext);
/*     */ 
/*  87 */     List templates = templateContext.getTemplate().getPossibleTemplates(this);
/*     */ 
/*  90 */     freemarker.template.Template template = null;
/*  91 */     String templateName = null;
/*  92 */     Exception exception = null;
/*  93 */     for (Template t : templates) {
/*  94 */       templateName = getFinalTemplateName(t);
/*     */       try
/*     */       {
/*  97 */         template = config.getTemplate(templateName);
/*     */       }
/*     */       catch (ParseException e)
/*     */       {
/* 101 */         exception = e;
/*     */       }
/*     */       catch (IOException e)
/*     */       {
/* 105 */         if (exception == null) {
/* 106 */           exception = e;
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 111 */     if (template == null) {
/* 112 */       if (LOG.isErrorEnabled()) {
/* 113 */         LOG.error("Could not load the FreeMarker template named '" + templateContext.getTemplate().getName() + "':", new String[0]);
/* 114 */         for (Template t : templates) {
/* 115 */           LOG.error("Attempted: " + getFinalTemplateName(t), new String[0]);
/*     */         }
/* 117 */         LOG.error("The TemplateLoader provided by the FreeMarker Configuration was a: " + config.getTemplateLoader().getClass().getName(), new String[0]);
/*     */       }
/* 119 */       if (exception != null) {
/* 120 */         throw exception;
/*     */       }
/* 122 */       return;
/*     */     }
/*     */ 
/* 126 */     if (LOG.isDebugEnabled()) {
/* 127 */       LOG.debug("Rendering template " + templateName, new String[0]);
/*     */     }
/*     */ 
/* 130 */     ActionInvocation ai = ActionContext.getContext().getActionInvocation();
/*     */ 
/* 132 */     Object action = ai == null ? null : ai.getAction();
/* 133 */     SimpleHash model = this.freemarkerManager.buildTemplateModel(stack, action, servletContext, req, res, config.getObjectWrapper());
/*     */ 
/* 135 */     model.put("tag", templateContext.getTag());
/* 136 */     model.put("themeProperties", getThemeProps(templateContext.getTemplate()));
/*     */ 
/* 140 */     Writer writer = templateContext.getWriter();
/* 141 */     Writer wrapped = writer;
/* 142 */     writer = new Writer(wrapped) {
/*     */       public void write(char[] cbuf, int off, int len) throws IOException {
/* 144 */         this.val$wrapped.write(cbuf, off, len);
/*     */       }
/*     */ 
/*     */       public void flush() throws IOException
/*     */       {
/*     */       }
/*     */ 
/*     */       public void close() throws IOException {
/* 152 */         this.val$wrapped.close();
/*     */       }
/*     */     };
/*     */     try {
/* 157 */       stack.push(templateContext.getTag());
/* 158 */       template.process(model, writer);
/*     */     } finally {
/* 160 */       stack.pop();
/*     */     }
/*     */   }
/*     */ 
/*     */   protected String getSuffix() {
/* 165 */     return "ftl";
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/*  58 */       bodyContent = ClassLoaderUtil.loadClass("javax.servlet.jsp.tagext.BodyContent", FreemarkerTemplateEngine.class);
/*     */     }
/*     */     catch (ClassNotFoundException e)
/*     */     {
/*     */     }
/*     */ 
/*  68 */     LOG = LoggerFactory.getLogger(FreemarkerTemplateEngine.class);
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.components.template.FreemarkerTemplateEngine
 * JD-Core Version:    0.6.0
 */