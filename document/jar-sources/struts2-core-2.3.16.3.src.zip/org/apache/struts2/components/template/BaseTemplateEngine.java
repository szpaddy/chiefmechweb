/*     */ package org.apache.struts2.components.template;
/*     */ 
/*     */ import com.opensymphony.xwork2.util.ClassLoaderUtil;
/*     */ import com.opensymphony.xwork2.util.logging.Logger;
/*     */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ 
/*     */ public abstract class BaseTemplateEngine
/*     */   implements TemplateEngine
/*     */ {
/*  42 */   private static final Logger LOG = LoggerFactory.getLogger(BaseTemplateEngine.class);
/*     */   public static final String DEFAULT_THEME_PROPERTIES_FILE_NAME = "theme.properties";
/*  49 */   final Map<String, Properties> themeProps = new HashMap();
/*     */ 
/*     */   public Map getThemeProps(Template template) {
/*  52 */     synchronized (this.themeProps) {
/*  53 */       Properties props = (Properties)this.themeProps.get(template.getTheme());
/*  54 */       if (props == null) {
/*  55 */         props = readNewProperties(template);
/*  56 */         this.themeProps.put(template.getTheme(), props);
/*     */       }
/*  58 */       return props;
/*     */     }
/*     */   }
/*     */ 
/*     */   private Properties readNewProperties(Template template) {
/*  63 */     String propName = buildPropertyFilename(template);
/*  64 */     return loadProperties(propName);
/*     */   }
/*     */ 
/*     */   private Properties loadProperties(String propName) {
/*  68 */     InputStream is = readProperty(propName);
/*  69 */     Properties props = new Properties();
/*  70 */     if (is != null) {
/*  71 */       tryToLoadPropertiesFromStream(props, propName, is);
/*     */     }
/*  73 */     return props;
/*     */   }
/*     */ 
/*     */   private InputStream readProperty(String propName) {
/*  77 */     InputStream is = tryReadingPropertyFileFromFileSystem(propName);
/*  78 */     if (is == null) {
/*  79 */       is = readPropertyFromClasspath(propName);
/*     */     }
/*  81 */     return is;
/*     */   }
/*     */ 
/*     */   private InputStream readPropertyFromClasspath(String propName)
/*     */   {
/*  88 */     return ClassLoaderUtil.getResourceAsStream(propName, getClass());
/*     */   }
/*     */ 
/*     */   private void tryToLoadPropertiesFromStream(Properties props, String propName, InputStream is) {
/*     */     try {
/*  93 */       props.load(is);
/*     */     } catch (IOException e) {
/*  95 */       LOG.error("Could not load " + propName, e, new String[0]);
/*     */     } finally {
/*  97 */       tryCloseStream(is);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void tryCloseStream(InputStream is) {
/*     */     try {
/* 103 */       is.close();
/*     */     } catch (IOException io) {
/* 105 */       if (LOG.isWarnEnabled())
/* 106 */         LOG.warn("Unable to close input stream", io, new String[0]);
/*     */     }
/*     */   }
/*     */ 
/*     */   private String buildPropertyFilename(Template template)
/*     */   {
/* 112 */     return template.getDir() + "/" + template.getTheme() + "/" + getThemePropertiesFileName();
/*     */   }
/*     */ 
/*     */   private InputStream tryReadingPropertyFileFromFileSystem(String propName)
/*     */   {
/* 123 */     File propFile = new File(propName);
/*     */     try {
/* 125 */       return createFileInputStream(propFile);
/*     */     } catch (FileNotFoundException e) {
/* 127 */       if (LOG.isWarnEnabled())
/* 128 */         LOG.warn("Unable to find file in filesystem [" + propFile.getAbsolutePath() + "]", new String[0]);
/*     */     }
/* 130 */     return null;
/*     */   }
/*     */ 
/*     */   private InputStream createFileInputStream(File propFile) throws FileNotFoundException
/*     */   {
/* 135 */     InputStream is = null;
/* 136 */     if (propFile.exists()) {
/* 137 */       is = new FileInputStream(propFile);
/*     */     }
/* 139 */     return is;
/*     */   }
/*     */ 
/*     */   protected String getFinalTemplateName(Template template) {
/* 143 */     String t = template.toString();
/* 144 */     if (t.indexOf(".") <= 0) {
/* 145 */       return t + "." + getSuffix();
/*     */     }
/* 147 */     return t;
/*     */   }
/*     */ 
/*     */   protected String getThemePropertiesFileName() {
/* 151 */     return "theme.properties";
/*     */   }
/*     */ 
/*     */   protected abstract String getSuffix();
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.components.template.BaseTemplateEngine
 * JD-Core Version:    0.6.0
 */