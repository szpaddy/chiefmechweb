/*     */ package org.apache.struts2.components.template;
/*     */ 
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import com.opensymphony.xwork2.util.logging.Logger;
/*     */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.struts2.views.velocity.VelocityManager;
/*     */ import org.apache.velocity.app.VelocityEngine;
/*     */ import org.apache.velocity.context.Context;
/*     */ 
/*     */ public class VelocityTemplateEngine extends BaseTemplateEngine
/*     */ {
/*  46 */   private static final Logger LOG = LoggerFactory.getLogger(VelocityTemplateEngine.class);
/*     */   private VelocityManager velocityManager;
/*     */ 
/*     */   @Inject
/*     */   public void setVelocityManager(VelocityManager mgr)
/*     */   {
/*  52 */     this.velocityManager = mgr;
/*     */   }
/*     */ 
/*     */   public void renderTemplate(TemplateRenderingContext templateContext) throws Exception
/*     */   {
/*  57 */     Map actionContext = templateContext.getStack().getContext();
/*  58 */     ServletContext servletContext = (ServletContext)actionContext.get("com.opensymphony.xwork2.dispatcher.ServletContext");
/*  59 */     HttpServletRequest req = (HttpServletRequest)actionContext.get("com.opensymphony.xwork2.dispatcher.HttpServletRequest");
/*  60 */     HttpServletResponse res = (HttpServletResponse)actionContext.get("com.opensymphony.xwork2.dispatcher.HttpServletResponse");
/*     */ 
/*  63 */     this.velocityManager.init(servletContext);
/*  64 */     VelocityEngine velocityEngine = this.velocityManager.getVelocityEngine();
/*     */ 
/*  67 */     List templates = templateContext.getTemplate().getPossibleTemplates(this);
/*     */ 
/*  70 */     org.apache.velocity.Template template = null;
/*  71 */     String templateName = null;
/*  72 */     Exception exception = null;
/*  73 */     for (Template t : templates) {
/*  74 */       templateName = getFinalTemplateName(t);
/*     */       try
/*     */       {
/*  77 */         template = velocityEngine.getTemplate(templateName);
/*     */       }
/*     */       catch (IOException e) {
/*  80 */         if (exception == null) {
/*  81 */           exception = e;
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*  86 */     if (template == null) {
/*  87 */       LOG.error("Could not load template " + templateContext.getTemplate(), new String[0]);
/*  88 */       if (exception != null) {
/*  89 */         throw exception;
/*     */       }
/*  91 */       return;
/*     */     }
/*     */ 
/*  95 */     if (LOG.isDebugEnabled()) {
/*  96 */       LOG.debug("Rendering template " + templateName, new String[0]);
/*     */     }
/*     */ 
/*  99 */     Context context = this.velocityManager.createContext(templateContext.getStack(), req, res);
/*     */ 
/* 101 */     Writer outputWriter = templateContext.getWriter();
/* 102 */     context.put("tag", templateContext.getTag());
/* 103 */     context.put("parameters", templateContext.getParameters());
/*     */ 
/* 105 */     template.merge(context, outputWriter);
/*     */   }
/*     */ 
/*     */   protected String getSuffix() {
/* 109 */     return "vm";
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.components.template.VelocityTemplateEngine
 * JD-Core Version:    0.6.0
 */