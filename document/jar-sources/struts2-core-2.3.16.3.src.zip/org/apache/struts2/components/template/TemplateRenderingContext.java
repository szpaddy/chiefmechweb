/*    */ package org.apache.struts2.components.template;
/*    */ 
/*    */ import com.opensymphony.xwork2.util.ValueStack;
/*    */ import java.io.Writer;
/*    */ import java.util.Map;
/*    */ import org.apache.struts2.components.UIBean;
/*    */ 
/*    */ public class TemplateRenderingContext
/*    */ {
/*    */   Template template;
/*    */   ValueStack stack;
/*    */   Map parameters;
/*    */   UIBean tag;
/*    */   Writer writer;
/*    */ 
/*    */   public TemplateRenderingContext(Template template, Writer writer, ValueStack stack, Map params, UIBean tag)
/*    */   {
/* 51 */     this.template = template;
/* 52 */     this.writer = writer;
/* 53 */     this.stack = stack;
/* 54 */     this.parameters = params;
/* 55 */     this.tag = tag;
/*    */   }
/*    */ 
/*    */   public Template getTemplate() {
/* 59 */     return this.template;
/*    */   }
/*    */ 
/*    */   public ValueStack getStack() {
/* 63 */     return this.stack;
/*    */   }
/*    */ 
/*    */   public Map getParameters() {
/* 67 */     return this.parameters;
/*    */   }
/*    */ 
/*    */   public UIBean getTag() {
/* 71 */     return this.tag;
/*    */   }
/*    */ 
/*    */   public Writer getWriter() {
/* 75 */     return this.writer;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.components.template.TemplateRenderingContext
 * JD-Core Version:    0.6.0
 */