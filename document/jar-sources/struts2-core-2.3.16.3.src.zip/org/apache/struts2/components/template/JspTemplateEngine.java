/*    */ package org.apache.struts2.components.template;
/*    */ 
/*    */ import com.opensymphony.xwork2.inject.Inject;
/*    */ import com.opensymphony.xwork2.util.ValueStack;
/*    */ import com.opensymphony.xwork2.util.logging.Logger;
/*    */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import javax.servlet.jsp.PageContext;
/*    */ import org.apache.struts2.components.Include;
/*    */ import org.apache.struts2.components.UIBean;
/*    */ 
/*    */ public class JspTemplateEngine extends BaseTemplateEngine
/*    */ {
/* 44 */   private static final Logger LOG = LoggerFactory.getLogger(JspTemplateEngine.class);
/*    */   String encoding;
/*    */ 
/*    */   @Inject("struts.i18n.encoding")
/*    */   public void setEncoding(String encoding)
/*    */   {
/* 50 */     this.encoding = encoding;
/*    */   }
/*    */ 
/*    */   public void renderTemplate(TemplateRenderingContext templateContext) throws Exception {
/* 54 */     Template template = templateContext.getTemplate();
/*    */ 
/* 56 */     if (LOG.isDebugEnabled()) {
/* 57 */       LOG.debug("Trying to render template " + template + ", repeating through parents until we succeed", new String[0]);
/*    */     }
/* 59 */     UIBean tag = templateContext.getTag();
/* 60 */     ValueStack stack = templateContext.getStack();
/* 61 */     stack.push(tag);
/* 62 */     PageContext pageContext = (PageContext)stack.getContext().get("com.opensymphony.xwork2.dispatcher.PageContext");
/* 63 */     List templates = template.getPossibleTemplates(this);
/* 64 */     Exception exception = null;
/* 65 */     boolean success = false;
/* 66 */     for (Template t : templates) {
/*    */       try {
/* 68 */         Include.include(getFinalTemplateName(t), pageContext.getOut(), pageContext.getRequest(), (HttpServletResponse)pageContext.getResponse(), this.encoding);
/*    */ 
/* 70 */         success = true;
/*    */       }
/*    */       catch (Exception e) {
/* 73 */         if (exception == null) {
/* 74 */           exception = e;
/*    */         }
/*    */       }
/*    */     }
/*    */ 
/* 79 */     if (!success) {
/* 80 */       LOG.error("Could not render JSP template " + templateContext.getTemplate(), new String[0]);
/*    */ 
/* 82 */       if (exception != null) {
/* 83 */         throw exception;
/*    */       }
/* 85 */       return;
/*    */     }
/*    */ 
/* 89 */     stack.pop();
/*    */   }
/*    */ 
/*    */   protected String getSuffix() {
/* 93 */     return "jsp";
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.components.template.JspTemplateEngine
 * JD-Core Version:    0.6.0
 */