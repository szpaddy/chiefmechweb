/*     */ package org.apache.struts2.components.template;
/*     */ 
/*     */ import com.opensymphony.xwork2.config.ConfigurationException;
/*     */ import com.opensymphony.xwork2.inject.Container;
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class TemplateEngineManager
/*     */ {
/*     */   public static final String DEFAULT_TEMPLATE_TYPE = "ftl";
/*     */   Map<String, EngineFactory> templateEngines;
/*     */   Container container;
/*     */   String defaultTemplateType;
/*     */ 
/*     */   public TemplateEngineManager()
/*     */   {
/*  43 */     this.templateEngines = new HashMap();
/*     */   }
/*     */ 
/*     */   @Inject("struts.ui.templateSuffix")
/*     */   public void setDefaultTemplateType(String type) {
/*  49 */     this.defaultTemplateType = type;
/*     */   }
/*     */   @Inject
/*     */   public void setContainer(Container container) {
/*  54 */     this.container = container;
/*  55 */     Map map = new HashMap();
/*  56 */     Set prefixes = container.getInstanceNames(TemplateEngine.class);
/*  57 */     for (String prefix : prefixes) {
/*  58 */       map.put(prefix, new LazyEngineFactory(prefix));
/*     */     }
/*  60 */     this.templateEngines = Collections.unmodifiableMap(map);
/*     */   }
/*     */ 
/*     */   public void registerTemplateEngine(String templateExtension, TemplateEngine templateEngine)
/*     */   {
/*  72 */     this.templateEngines.put(templateExtension, new EngineFactory(templateEngine) {
/*     */       public TemplateEngine create() {
/*  74 */         return this.val$templateEngine;
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   public TemplateEngine getTemplateEngine(Template template, String templateTypeOverride)
/*     */   {
/*  90 */     String templateType = "ftl";
/*  91 */     String templateName = template.toString();
/*  92 */     if (templateName.indexOf(".") > 0) {
/*  93 */       templateType = templateName.substring(templateName.indexOf(".") + 1);
/*  94 */     } else if ((templateTypeOverride != null) && (templateTypeOverride.length() > 0)) {
/*  95 */       templateType = templateTypeOverride;
/*     */     } else {
/*  97 */       String type = this.defaultTemplateType;
/*  98 */       if (type != null) {
/*  99 */         templateType = type;
/*     */       }
/*     */     }
/* 102 */     return ((EngineFactory)this.templateEngines.get(templateType)).create();
/*     */   }
/*     */ 
/*     */   class LazyEngineFactory
/*     */     implements TemplateEngineManager.EngineFactory
/*     */   {
/*     */     private String name;
/*     */ 
/*     */     public LazyEngineFactory(String name)
/*     */     {
/* 117 */       this.name = name;
/*     */     }
/*     */     public TemplateEngine create() {
/* 120 */       TemplateEngine engine = (TemplateEngine)TemplateEngineManager.this.container.getInstance(TemplateEngine.class, this.name);
/* 121 */       if (engine == null) {
/* 122 */         throw new ConfigurationException("Unable to locate template engine: " + this.name);
/*     */       }
/* 124 */       return engine;
/*     */     }
/*     */   }
/*     */ 
/*     */   static abstract interface EngineFactory
/*     */   {
/*     */     public abstract TemplateEngine create();
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.components.template.TemplateEngineManager
 * JD-Core Version:    0.6.0
 */