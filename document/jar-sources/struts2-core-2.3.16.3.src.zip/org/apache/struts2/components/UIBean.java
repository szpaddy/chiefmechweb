/*      */ package org.apache.struts2.components;
/*      */ 
/*      */ import com.opensymphony.xwork2.config.ConfigurationException;
/*      */ import com.opensymphony.xwork2.inject.Inject;
/*      */ import com.opensymphony.xwork2.util.ValueStack;
/*      */ import com.opensymphony.xwork2.util.logging.Logger;
/*      */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*      */ import java.io.Writer;
/*      */ import java.lang.reflect.Field;
/*      */ import java.lang.reflect.Modifier;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.Set;
/*      */ import java.util.concurrent.ConcurrentHashMap;
/*      */ import java.util.concurrent.ConcurrentMap;
/*      */ import javax.servlet.http.HttpServletRequest;
/*      */ import javax.servlet.http.HttpServletResponse;
/*      */ import org.apache.struts2.StrutsException;
/*      */ import org.apache.struts2.components.template.Template;
/*      */ import org.apache.struts2.components.template.TemplateEngine;
/*      */ import org.apache.struts2.components.template.TemplateEngineManager;
/*      */ import org.apache.struts2.components.template.TemplateRenderingContext;
/*      */ import org.apache.struts2.util.TextProviderHelper;
/*      */ import org.apache.struts2.views.annotations.StrutsTagAttribute;
/*      */ import org.apache.struts2.views.util.ContextUtil;
/*      */ 
/*      */ public abstract class UIBean extends Component
/*      */ {
/*  443 */   private static final Logger LOG = LoggerFactory.getLogger(UIBean.class);
/*      */   protected HttpServletRequest request;
/*      */   protected HttpServletResponse response;
/*      */   protected String templateSuffix;
/*      */   protected String template;
/*      */   protected String templateDir;
/*      */   protected String theme;
/*      */   protected String key;
/*      */   protected String id;
/*      */   protected String cssClass;
/*      */   protected String cssStyle;
/*      */   protected String cssErrorClass;
/*      */   protected String cssErrorStyle;
/*      */   protected String disabled;
/*      */   protected String label;
/*      */   protected String labelPosition;
/*      */   protected String labelSeparator;
/*      */   protected String requiredPosition;
/*      */   protected String errorPosition;
/*      */   protected String name;
/*      */   protected String requiredLabel;
/*      */   protected String tabindex;
/*      */   protected String value;
/*      */   protected String title;
/*      */   protected String onclick;
/*      */   protected String ondblclick;
/*      */   protected String onmousedown;
/*      */   protected String onmouseup;
/*      */   protected String onmouseover;
/*      */   protected String onmousemove;
/*      */   protected String onmouseout;
/*      */   protected String onfocus;
/*      */   protected String onblur;
/*      */   protected String onkeypress;
/*      */   protected String onkeydown;
/*      */   protected String onkeyup;
/*      */   protected String onselect;
/*      */   protected String onchange;
/*      */   protected String accesskey;
/*      */   protected String tooltip;
/*      */   protected String tooltipConfig;
/*      */   protected String javascriptTooltip;
/*      */   protected String tooltipDelay;
/*      */   protected String tooltipCssClass;
/*      */   protected String tooltipIconPath;
/*  513 */   protected Map<String, Object> dynamicAttributes = new HashMap();
/*      */   protected String defaultTemplateDir;
/*      */   protected String defaultUITheme;
/*      */   protected String uiThemeExpansionToken;
/*      */   protected TemplateEngineManager templateEngineManager;
/*  521 */   protected static ConcurrentMap<Class, Set<String>> standardAttributesMap = new ConcurrentHashMap();
/*      */ 
/*      */   public UIBean(ValueStack stack, HttpServletRequest request, HttpServletResponse response)
/*      */   {
/*  449 */     super(stack);
/*  450 */     this.request = request;
/*  451 */     this.response = response;
/*  452 */     this.templateSuffix = ContextUtil.getTemplateSuffix(stack.getContext());
/*      */   }
/*      */ 
/*      */   @Inject("struts.ui.templateDir")
/*      */   public void setDefaultTemplateDir(String dir)
/*      */   {
/*  525 */     this.defaultTemplateDir = dir;
/*      */   }
/*      */   @Inject("struts.ui.theme")
/*      */   public void setDefaultUITheme(String theme) {
/*  530 */     this.defaultUITheme = theme;
/*      */   }
/*      */   @Inject("struts.ui.theme.expansion.token")
/*      */   public void setUIThemeExpansionToken(String uiThemeExpansionToken) {
/*  535 */     this.uiThemeExpansionToken = uiThemeExpansionToken;
/*      */   }
/*      */   @Inject
/*      */   public void setTemplateEngineManager(TemplateEngineManager mgr) {
/*  540 */     this.templateEngineManager = mgr;
/*      */   }
/*      */ 
/*      */   public boolean end(Writer writer, String body) {
/*  544 */     evaluateParams();
/*      */     try {
/*  546 */       super.end(writer, body, false);
/*  547 */       mergeTemplate(writer, buildTemplateName(this.template, getDefaultTemplate()));
/*      */     } catch (Exception e) {
/*  549 */       throw new StrutsException(e);
/*      */     }
/*      */     finally {
/*  552 */       popComponentStack();
/*      */     }
/*      */ 
/*  555 */     return false;
/*      */   }
/*      */ 
/*      */   protected abstract String getDefaultTemplate();
/*      */ 
/*      */   protected Template buildTemplateName(String myTemplate, String myDefaultTemplate)
/*      */   {
/*  569 */     String template = myDefaultTemplate;
/*      */ 
/*  571 */     if (myTemplate != null) {
/*  572 */       template = findString(myTemplate);
/*      */     }
/*      */ 
/*  575 */     String templateDir = getTemplateDir();
/*  576 */     String theme = getTheme();
/*      */ 
/*  578 */     return new Template(templateDir, theme, template);
/*      */   }
/*      */ 
/*      */   protected void mergeTemplate(Writer writer, Template template) throws Exception
/*      */   {
/*  583 */     TemplateEngine engine = this.templateEngineManager.getTemplateEngine(template, this.templateSuffix);
/*  584 */     if (engine == null) {
/*  585 */       throw new ConfigurationException("Unable to find a TemplateEngine for template " + template);
/*      */     }
/*      */ 
/*  588 */     if (LOG.isDebugEnabled()) {
/*  589 */       LOG.debug("Rendering template " + template, new String[0]);
/*      */     }
/*      */ 
/*  592 */     TemplateRenderingContext context = new TemplateRenderingContext(template, writer, getStack(), getParameters(), this);
/*  593 */     engine.renderTemplate(context);
/*      */   }
/*      */ 
/*      */   public String getTemplateDir() {
/*  597 */     String templateDir = null;
/*      */ 
/*  599 */     if (this.templateDir != null) {
/*  600 */       templateDir = findString(this.templateDir);
/*      */     }
/*      */ 
/*  605 */     if ((templateDir == null) || (templateDir.equals(""))) {
/*  606 */       templateDir = this.stack.findString("#attr.templateDir");
/*      */     }
/*      */ 
/*  610 */     if ((templateDir == null) || (templateDir.equals(""))) {
/*  611 */       templateDir = this.defaultTemplateDir;
/*      */     }
/*      */ 
/*  615 */     if ((templateDir == null) || (templateDir.equals(""))) {
/*  616 */       templateDir = "template";
/*      */     }
/*      */ 
/*  619 */     return templateDir;
/*      */   }
/*      */ 
/*      */   public String getTheme() {
/*  623 */     String theme = null;
/*      */ 
/*  625 */     if (this.theme != null) {
/*  626 */       theme = findString(this.theme);
/*      */     }
/*      */ 
/*  629 */     if ((theme == null) || (theme.equals(""))) {
/*  630 */       Form form = (Form)findAncestor(Form.class);
/*  631 */       if (form != null) {
/*  632 */         theme = form.getTheme();
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  638 */     if ((theme == null) || (theme.equals(""))) {
/*  639 */       theme = this.stack.findString("#attr.theme");
/*      */     }
/*      */ 
/*  643 */     if ((theme == null) || (theme.equals(""))) {
/*  644 */       theme = this.defaultUITheme;
/*      */     }
/*      */ 
/*  647 */     return theme;
/*      */   }
/*      */ 
/*      */   public void evaluateParams() {
/*  651 */     String templateDir = getTemplateDir();
/*  652 */     String theme = getTheme();
/*      */ 
/*  654 */     addParameter("templateDir", templateDir);
/*  655 */     addParameter("theme", theme);
/*  656 */     addParameter("template", this.template != null ? findString(this.template) : getDefaultTemplate());
/*  657 */     addParameter("dynamicAttributes", this.dynamicAttributes);
/*  658 */     addParameter("themeExpansionToken", this.uiThemeExpansionToken);
/*  659 */     addParameter("expandTheme", this.uiThemeExpansionToken + theme);
/*      */ 
/*  661 */     String name = null;
/*  662 */     String providedLabel = null;
/*      */ 
/*  664 */     if (this.key != null)
/*      */     {
/*  666 */       if (this.name == null) {
/*  667 */         this.name = this.key;
/*      */       }
/*      */ 
/*  670 */       if (this.label == null)
/*      */       {
/*  672 */         providedLabel = TextProviderHelper.getText(this.key, this.key, this.stack);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  677 */     if (this.name != null) {
/*  678 */       name = findString(this.name);
/*  679 */       addParameter("name", name);
/*      */     }
/*      */ 
/*  682 */     if (this.label != null) {
/*  683 */       addParameter("label", findString(this.label));
/*      */     }
/*  685 */     else if (providedLabel != null)
/*      */     {
/*  687 */       addParameter("label", providedLabel);
/*      */     }
/*      */ 
/*  691 */     if (this.labelSeparator != null) {
/*  692 */       addParameter("labelseparator", findString(this.labelSeparator));
/*      */     }
/*      */ 
/*  695 */     if (this.labelPosition != null) {
/*  696 */       addParameter("labelposition", findString(this.labelPosition));
/*      */     }
/*      */ 
/*  699 */     if (this.requiredPosition != null) {
/*  700 */       addParameter("requiredPosition", findString(this.requiredPosition));
/*      */     }
/*      */ 
/*  703 */     if (this.errorPosition != null) {
/*  704 */       addParameter("errorposition", findString(this.errorPosition));
/*      */     }
/*      */ 
/*  707 */     if (this.requiredLabel != null) {
/*  708 */       addParameter("required", findValue(this.requiredLabel, Boolean.class));
/*      */     }
/*      */ 
/*  711 */     if (this.disabled != null) {
/*  712 */       addParameter("disabled", findValue(this.disabled, Boolean.class));
/*      */     }
/*      */ 
/*  715 */     if (this.tabindex != null) {
/*  716 */       addParameter("tabindex", findString(this.tabindex));
/*      */     }
/*      */ 
/*  719 */     if (this.onclick != null) {
/*  720 */       addParameter("onclick", findString(this.onclick));
/*      */     }
/*      */ 
/*  723 */     if (this.ondblclick != null) {
/*  724 */       addParameter("ondblclick", findString(this.ondblclick));
/*      */     }
/*      */ 
/*  727 */     if (this.onmousedown != null) {
/*  728 */       addParameter("onmousedown", findString(this.onmousedown));
/*      */     }
/*      */ 
/*  731 */     if (this.onmouseup != null) {
/*  732 */       addParameter("onmouseup", findString(this.onmouseup));
/*      */     }
/*      */ 
/*  735 */     if (this.onmouseover != null) {
/*  736 */       addParameter("onmouseover", findString(this.onmouseover));
/*      */     }
/*      */ 
/*  739 */     if (this.onmousemove != null) {
/*  740 */       addParameter("onmousemove", findString(this.onmousemove));
/*      */     }
/*      */ 
/*  743 */     if (this.onmouseout != null) {
/*  744 */       addParameter("onmouseout", findString(this.onmouseout));
/*      */     }
/*      */ 
/*  747 */     if (this.onfocus != null) {
/*  748 */       addParameter("onfocus", findString(this.onfocus));
/*      */     }
/*      */ 
/*  751 */     if (this.onblur != null) {
/*  752 */       addParameter("onblur", findString(this.onblur));
/*      */     }
/*      */ 
/*  755 */     if (this.onkeypress != null) {
/*  756 */       addParameter("onkeypress", findString(this.onkeypress));
/*      */     }
/*      */ 
/*  759 */     if (this.onkeydown != null) {
/*  760 */       addParameter("onkeydown", findString(this.onkeydown));
/*      */     }
/*      */ 
/*  763 */     if (this.onkeyup != null) {
/*  764 */       addParameter("onkeyup", findString(this.onkeyup));
/*      */     }
/*      */ 
/*  767 */     if (this.onselect != null) {
/*  768 */       addParameter("onselect", findString(this.onselect));
/*      */     }
/*      */ 
/*  771 */     if (this.onchange != null) {
/*  772 */       addParameter("onchange", findString(this.onchange));
/*      */     }
/*      */ 
/*  775 */     if (this.accesskey != null) {
/*  776 */       addParameter("accesskey", findString(this.accesskey));
/*      */     }
/*      */ 
/*  779 */     if (this.cssClass != null) {
/*  780 */       addParameter("cssClass", findString(this.cssClass));
/*      */     }
/*      */ 
/*  783 */     if (this.cssStyle != null) {
/*  784 */       addParameter("cssStyle", findString(this.cssStyle));
/*      */     }
/*      */ 
/*  787 */     if (this.cssErrorClass != null) {
/*  788 */       addParameter("cssErrorClass", findString(this.cssErrorClass));
/*      */     }
/*      */ 
/*  791 */     if (this.cssErrorStyle != null) {
/*  792 */       addParameter("cssErrorStyle", findString(this.cssErrorStyle));
/*      */     }
/*      */ 
/*  795 */     if (this.title != null) {
/*  796 */       addParameter("title", findString(this.title));
/*      */     }
/*      */ 
/*  801 */     if (this.parameters.containsKey("value")) {
/*  802 */       this.parameters.put("nameValue", this.parameters.get("value"));
/*      */     }
/*  804 */     else if (evaluateNameValue()) {
/*  805 */       Class valueClazz = getValueClassType();
/*      */ 
/*  807 */       if (valueClazz != null) {
/*  808 */         if (this.value != null) {
/*  809 */           addParameter("nameValue", findValue(this.value, valueClazz));
/*  810 */         } else if (name != null) {
/*  811 */           String expr = completeExpressionIfAltSyntax(name);
/*      */ 
/*  813 */           addParameter("nameValue", findValue(expr, valueClazz));
/*      */         }
/*      */       }
/*  816 */       else if (this.value != null)
/*  817 */         addParameter("nameValue", findValue(this.value));
/*  818 */       else if (name != null) {
/*  819 */         addParameter("nameValue", findValue(name));
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  825 */     Form form = (Form)findAncestor(Form.class);
/*      */ 
/*  828 */     populateComponentHtmlId(form);
/*      */ 
/*  830 */     if (form != null) {
/*  831 */       addParameter("form", form.getParameters());
/*      */ 
/*  833 */       if (name != null)
/*      */       {
/*  835 */         List tags = (List)form.getParameters().get("tagNames");
/*  836 */         tags.add(name);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  842 */     if (this.tooltipConfig != null) {
/*  843 */       addParameter("tooltipConfig", findValue(this.tooltipConfig));
/*      */     }
/*  845 */     if (this.tooltip != null) {
/*  846 */       addParameter("tooltip", findString(this.tooltip));
/*      */ 
/*  848 */       Map tooltipConfigMap = getTooltipConfig(this);
/*      */       Iterator i$;
/*  850 */       if (form != null) {
/*  851 */         form.addParameter("hasTooltip", Boolean.TRUE);
/*      */ 
/*  855 */         Map overallTooltipConfigMap = getTooltipConfig(form);
/*  856 */         overallTooltipConfigMap.putAll(tooltipConfigMap);
/*      */ 
/*  858 */         for (i$ = overallTooltipConfigMap.entrySet().iterator(); i$.hasNext(); ) { Object o = i$.next();
/*  859 */           Map.Entry entry = (Map.Entry)o;
/*  860 */           addParameter((String)entry.getKey(), entry.getValue());
/*      */         }
/*      */ 
/*      */       }
/*  864 */       else if (LOG.isWarnEnabled()) {
/*  865 */         LOG.warn("No ancestor Form found, javascript based tooltip will not work, however standard HTML tooltip using alt and title attribute will still work ", new String[0]);
/*      */       }
/*      */ 
/*  870 */       String jsTooltipEnabled = (String)getParameters().get("jsTooltipEnabled");
/*  871 */       if (jsTooltipEnabled != null) {
/*  872 */         this.javascriptTooltip = jsTooltipEnabled;
/*      */       }
/*      */ 
/*  875 */       String tooltipIcon = (String)getParameters().get("tooltipIcon");
/*  876 */       if (tooltipIcon != null)
/*  877 */         addParameter("tooltipIconPath", tooltipIcon);
/*  878 */       if (this.tooltipIconPath != null) {
/*  879 */         addParameter("tooltipIconPath", findString(this.tooltipIconPath));
/*      */       }
/*      */ 
/*  882 */       String tooltipDelayParam = (String)getParameters().get("tooltipDelay");
/*  883 */       if (tooltipDelayParam != null)
/*  884 */         addParameter("tooltipDelay", tooltipDelayParam);
/*  885 */       if (this.tooltipDelay != null) {
/*  886 */         addParameter("tooltipDelay", findString(this.tooltipDelay));
/*      */       }
/*  888 */       if (this.javascriptTooltip != null) {
/*  889 */         Boolean jsTooltips = (Boolean)findValue(this.javascriptTooltip, Boolean.class);
/*      */ 
/*  891 */         addParameter("jsTooltipEnabled", jsTooltips.toString());
/*      */ 
/*  893 */         if (form != null)
/*  894 */           form.addParameter("hasTooltip", jsTooltips);
/*  895 */         if (this.tooltipCssClass != null) {
/*  896 */           addParameter("tooltipCssClass", findString(this.tooltipCssClass));
/*      */         }
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  902 */     evaluateExtraParams();
/*      */   }
/*      */ 
/*      */   protected String escape(String name)
/*      */   {
/*  907 */     if (name != null) {
/*  908 */       return name.replaceAll("[\\/\\.\\[\\]]", "_");
/*      */     }
/*  910 */     return null;
/*      */   }
/*      */ 
/*      */   protected String ensureAttributeSafelyNotEscaped(String val)
/*      */   {
/*  921 */     if (val != null) {
/*  922 */       return val.replaceAll("\"", "&#34;");
/*      */     }
/*  924 */     return null;
/*      */   }
/*      */ 
/*      */   protected void evaluateExtraParams()
/*      */   {
/*      */   }
/*      */ 
/*      */   protected boolean evaluateNameValue() {
/*  932 */     return true;
/*      */   }
/*      */ 
/*      */   protected Class getValueClassType() {
/*  936 */     return String.class;
/*      */   }
/*      */ 
/*      */   public void addFormParameter(String key, Object value) {
/*  940 */     Form form = (Form)findAncestor(Form.class);
/*  941 */     if (form != null)
/*  942 */       form.addParameter(key, value);
/*      */   }
/*      */ 
/*      */   protected void enableAncestorFormCustomOnsubmit()
/*      */   {
/*  947 */     Form form = (Form)findAncestor(Form.class);
/*  948 */     if (form != null) {
/*  949 */       form.addParameter("customOnsubmitEnabled", Boolean.TRUE);
/*      */     }
/*  951 */     else if (LOG.isWarnEnabled())
/*  952 */       LOG.warn("Cannot find an Ancestor form, custom onsubmit is NOT enabled", new String[0]);
/*      */   }
/*      */ 
/*      */   protected Map getTooltipConfig(UIBean component)
/*      */   {
/*  958 */     Object tooltipConfigObj = component.getParameters().get("tooltipConfig");
/*  959 */     Map tooltipConfig = new LinkedHashMap();
/*      */ 
/*  961 */     if ((tooltipConfigObj instanceof Map))
/*      */     {
/*  966 */       tooltipConfig = new LinkedHashMap((Map)tooltipConfigObj);
/*  967 */     } else if ((tooltipConfigObj instanceof String))
/*      */     {
/*  971 */       String tooltipConfigStr = (String)tooltipConfigObj;
/*  972 */       String[] tooltipConfigArray = tooltipConfigStr.split("\\|");
/*      */ 
/*  974 */       for (String aTooltipConfigArray : tooltipConfigArray) {
/*  975 */         String[] configEntry = aTooltipConfigArray.trim().split("=");
/*  976 */         String key = configEntry[0].trim();
/*      */ 
/*  978 */         if (configEntry.length > 1) {
/*  979 */           String value = configEntry[1].trim();
/*  980 */           tooltipConfig.put(key, value);
/*      */         }
/*  982 */         else if (LOG.isWarnEnabled()) {
/*  983 */           LOG.warn("component " + component + " tooltip config param " + key + " has no value defined, skipped", new String[0]);
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*  988 */     if (component.javascriptTooltip != null)
/*  989 */       tooltipConfig.put("jsTooltipEnabled", component.javascriptTooltip);
/*  990 */     if (component.tooltipIconPath != null)
/*  991 */       tooltipConfig.put("tooltipIcon", component.tooltipIconPath);
/*  992 */     if (component.tooltipDelay != null)
/*  993 */       tooltipConfig.put("tooltipDelay", component.tooltipDelay);
/*  994 */     return tooltipConfig;
/*      */   }
/*      */ 
/*      */   protected void populateComponentHtmlId(Form form)
/*      */   {
/*      */     String tryId;
/*      */     String tryId;
/* 1014 */     if (this.id != null)
/*      */     {
/* 1016 */       tryId = findStringIfAltSyntax(this.id);
/*      */     }
/*      */     else
/*      */     {
/*      */       String generatedId;
/*      */       String tryId;
/* 1017 */       if (null == (generatedId = escape(this.name != null ? findString(this.name) : null))) {
/* 1018 */         if (LOG.isDebugEnabled()) {
/* 1019 */           LOG.debug("Cannot determine id attribute for [#0], consider defining id, name or key attribute!", new Object[] { this });
/*      */         }
/* 1021 */         tryId = null;
/*      */       }
/*      */       else
/*      */       {
/*      */         String tryId;
/* 1022 */         if (form != null)
/* 1023 */           tryId = form.getParameters().get("id") + "_" + generatedId;
/*      */         else
/* 1025 */           tryId = generatedId; 
/*      */       }
/*      */     }
/* 1027 */     addParameter("id", tryId);
/* 1028 */     addParameter("escapedId", escape(tryId));
/*      */   }
/*      */ 
/*      */   public String getId()
/*      */   {
/* 1036 */     return this.id;
/*      */   }
/*      */   @StrutsTagAttribute(description="HTML id attribute")
/*      */   public void setId(String id) {
/* 1041 */     if (id != null)
/* 1042 */       this.id = findString(id);
/*      */   }
/*      */ 
/*      */   @StrutsTagAttribute(description="The template directory.")
/*      */   public void setTemplateDir(String templateDir) {
/* 1048 */     this.templateDir = templateDir;
/*      */   }
/*      */   @StrutsTagAttribute(description="The theme (other than default) to use for rendering the element")
/*      */   public void setTheme(String theme) {
/* 1053 */     this.theme = theme;
/*      */   }
/*      */ 
/*      */   public String getTemplate() {
/* 1057 */     return this.template;
/*      */   }
/*      */   @StrutsTagAttribute(description="The template (other than default) to use for rendering the element")
/*      */   public void setTemplate(String template) {
/* 1062 */     this.template = template;
/*      */   }
/*      */   @StrutsTagAttribute(description="The css class to use for element")
/*      */   public void setCssClass(String cssClass) {
/* 1067 */     this.cssClass = cssClass;
/*      */   }
/*      */   @StrutsTagAttribute(description="The css style definitions for element to use")
/*      */   public void setCssStyle(String cssStyle) {
/* 1072 */     this.cssStyle = cssStyle;
/*      */   }
/*      */   @StrutsTagAttribute(description="The css error class to use for element")
/*      */   public void setCssErrorClass(String cssErrorClass) {
/* 1077 */     this.cssErrorClass = cssErrorClass;
/*      */   }
/*      */   @StrutsTagAttribute(description="The css error style definitions for element to use")
/*      */   public void setCssErrorStyle(String cssErrorStyle) {
/* 1082 */     this.cssErrorStyle = cssErrorStyle;
/*      */   }
/*      */   @StrutsTagAttribute(description="Set the html title attribute on rendered html element")
/*      */   public void setTitle(String title) {
/* 1087 */     this.title = title;
/*      */   }
/*      */   @StrutsTagAttribute(description="Set the html disabled attribute on rendered html element")
/*      */   public void setDisabled(String disabled) {
/* 1092 */     this.disabled = disabled;
/*      */   }
/*      */   @StrutsTagAttribute(description="Label expression used for rendering an element specific label")
/*      */   public void setLabel(String label) {
/* 1097 */     this.label = label;
/*      */   }
/*      */   @StrutsTagAttribute(description="String that will be appended to the label", defaultValue=":")
/*      */   public void setLabelSeparator(String labelseparator) {
/* 1102 */     this.labelSeparator = labelseparator;
/*      */   }
/*      */   @StrutsTagAttribute(description="Define label position of form element (top/left)")
/*      */   public void setLabelposition(String labelPosition) {
/* 1107 */     this.labelPosition = labelPosition;
/*      */   }
/*      */   @StrutsTagAttribute(description="Define required position of required form element (left|right)")
/*      */   public void setRequiredPosition(String requiredPosition) {
/* 1112 */     this.requiredPosition = requiredPosition;
/*      */   }
/*      */   @StrutsTagAttribute(description="Define error position of form element (top|bottom)")
/*      */   public void setErrorPosition(String errorPosition) {
/* 1117 */     this.errorPosition = errorPosition;
/*      */   }
/*      */   @StrutsTagAttribute(description="The name to set for element")
/*      */   public void setName(String name) {
/* 1122 */     this.name = name;
/*      */   }
/*      */   @StrutsTagAttribute(description="If set to true, the rendered element will indicate that input is required", type="Boolean", defaultValue="false")
/*      */   public void setRequiredLabel(String requiredLabel) {
/* 1127 */     this.requiredLabel = requiredLabel;
/*      */   }
/*      */   @StrutsTagAttribute(description="Set the html tabindex attribute on rendered html element")
/*      */   public void setTabindex(String tabindex) {
/* 1132 */     this.tabindex = tabindex;
/*      */   }
/*      */   @StrutsTagAttribute(description="Preset the value of input element.")
/*      */   public void setValue(String value) {
/* 1137 */     this.value = value;
/*      */   }
/*      */   @StrutsTagAttribute(description="Set the html onclick attribute on rendered html element")
/*      */   public void setOnclick(String onclick) {
/* 1142 */     this.onclick = onclick;
/*      */   }
/*      */   @StrutsTagAttribute(description="Set the html ondblclick attribute on rendered html element")
/*      */   public void setOndblclick(String ondblclick) {
/* 1147 */     this.ondblclick = ondblclick;
/*      */   }
/*      */   @StrutsTagAttribute(description="Set the html onmousedown attribute on rendered html element")
/*      */   public void setOnmousedown(String onmousedown) {
/* 1152 */     this.onmousedown = onmousedown;
/*      */   }
/*      */   @StrutsTagAttribute(description="Set the html onmouseup attribute on rendered html element")
/*      */   public void setOnmouseup(String onmouseup) {
/* 1157 */     this.onmouseup = onmouseup;
/*      */   }
/*      */   @StrutsTagAttribute(description="Set the html onmouseover attribute on rendered html element")
/*      */   public void setOnmouseover(String onmouseover) {
/* 1162 */     this.onmouseover = onmouseover;
/*      */   }
/*      */   @StrutsTagAttribute(description="Set the html onmousemove attribute on rendered html element")
/*      */   public void setOnmousemove(String onmousemove) {
/* 1167 */     this.onmousemove = onmousemove;
/*      */   }
/*      */   @StrutsTagAttribute(description="Set the html onmouseout attribute on rendered html element")
/*      */   public void setOnmouseout(String onmouseout) {
/* 1172 */     this.onmouseout = onmouseout;
/*      */   }
/*      */   @StrutsTagAttribute(description="Set the html onfocus attribute on rendered html element")
/*      */   public void setOnfocus(String onfocus) {
/* 1177 */     this.onfocus = onfocus;
/*      */   }
/*      */   @StrutsTagAttribute(description=" Set the html onblur attribute on rendered html element")
/*      */   public void setOnblur(String onblur) {
/* 1182 */     this.onblur = onblur;
/*      */   }
/*      */   @StrutsTagAttribute(description="Set the html onkeypress attribute on rendered html element")
/*      */   public void setOnkeypress(String onkeypress) {
/* 1187 */     this.onkeypress = onkeypress;
/*      */   }
/*      */   @StrutsTagAttribute(description="Set the html onkeydown attribute on rendered html element")
/*      */   public void setOnkeydown(String onkeydown) {
/* 1192 */     this.onkeydown = onkeydown;
/*      */   }
/*      */   @StrutsTagAttribute(description="Set the html onkeyup attribute on rendered html element")
/*      */   public void setOnkeyup(String onkeyup) {
/* 1197 */     this.onkeyup = onkeyup;
/*      */   }
/*      */   @StrutsTagAttribute(description="Set the html onselect attribute on rendered html element")
/*      */   public void setOnselect(String onselect) {
/* 1202 */     this.onselect = onselect;
/*      */   }
/*      */   @StrutsTagAttribute(description="Set the html onchange attribute on rendered html element")
/*      */   public void setOnchange(String onchange) {
/* 1207 */     this.onchange = onchange;
/*      */   }
/*      */   @StrutsTagAttribute(description="Set the html accesskey attribute on rendered html element")
/*      */   public void setAccesskey(String accesskey) {
/* 1212 */     this.accesskey = accesskey;
/*      */   }
/*      */   @StrutsTagAttribute(description="Set the tooltip of this particular component")
/*      */   public void setTooltip(String tooltip) {
/* 1217 */     this.tooltip = tooltip;
/*      */   }
/*      */   @StrutsTagAttribute(description="Deprecated. Use individual tooltip configuration attributes instead.")
/*      */   public void setTooltipConfig(String tooltipConfig) {
/* 1222 */     this.tooltipConfig = tooltipConfig;
/*      */   }
/*      */   @StrutsTagAttribute(description="Set the key (name, value, label) for this particular component")
/*      */   public void setKey(String key) {
/* 1227 */     this.key = key;
/*      */   }
/*      */   @StrutsTagAttribute(description="Use JavaScript to generate tooltips", type="Boolean", defaultValue="false")
/*      */   public void setJavascriptTooltip(String javascriptTooltip) {
/* 1232 */     this.javascriptTooltip = javascriptTooltip;
/*      */   }
/*      */   @StrutsTagAttribute(description="CSS class applied to JavaScrip tooltips", defaultValue="StrutsTTClassic")
/*      */   public void setTooltipCssClass(String tooltipCssClass) {
/* 1237 */     this.tooltipCssClass = tooltipCssClass;
/*      */   }
/*      */ 
/*      */   @StrutsTagAttribute(description="Delay in milliseconds, before showing JavaScript tooltips ", defaultValue="Classic")
/*      */   public void setTooltipDelay(String tooltipDelay) {
/* 1243 */     this.tooltipDelay = tooltipDelay;
/*      */   }
/*      */   @StrutsTagAttribute(description="Icon path used for image that will have the tooltip")
/*      */   public void setTooltipIconPath(String tooltipIconPath) {
/* 1248 */     this.tooltipIconPath = tooltipIconPath;
/*      */   }
/*      */ 
/*      */   public void setDynamicAttributes(Map<String, Object> dynamicAttributes) {
/* 1252 */     this.dynamicAttributes.putAll(dynamicAttributes);
/*      */   }
/*      */ 
/*      */   public void copyParams(Map params)
/*      */   {
/* 1261 */     super.copyParams(params);
/* 1262 */     Set standardAttributes = getStandardAttributes();
/* 1263 */     for (Iterator i$ = params.entrySet().iterator(); i$.hasNext(); ) { Object o = i$.next();
/* 1264 */       Map.Entry entry = (Map.Entry)o;
/* 1265 */       String key = (String)entry.getKey();
/* 1266 */       if ((!key.equals("dynamicAttributes")) && (!standardAttributes.contains(key)))
/* 1267 */         this.dynamicAttributes.put(key, entry.getValue());
/*      */     }
/*      */   }
/*      */ 
/*      */   protected Set<String> getStandardAttributes()
/*      */   {
/* 1273 */     Class clz = getClass();
/* 1274 */     Set standardAttributes = (Set)standardAttributesMap.get(clz);
/* 1275 */     if (standardAttributes == null) {
/* 1276 */       standardAttributes = new HashSet();
/* 1277 */       while (clz != null) {
/* 1278 */         for (Field f : clz.getDeclaredFields()) {
/* 1279 */           if ((!Modifier.isProtected(f.getModifiers())) || ((!f.getType().equals(String.class)) && ((!clz.equals(ListUIBean.class)) || (!f.getName().equals("list"))))) {
/*      */             continue;
/*      */           }
/* 1282 */           standardAttributes.add(f.getName());
/*      */         }
/* 1284 */         if (clz.equals(UIBean.class)) {
/*      */           break;
/*      */         }
/* 1287 */         clz = clz.getSuperclass();
/*      */       }
/*      */ 
/* 1290 */       standardAttributesMap.putIfAbsent(clz, standardAttributes);
/*      */     }
/* 1292 */     return standardAttributes;
/*      */   }
/*      */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.components.UIBean
 * JD-Core Version:    0.6.0
 */