/*     */ package org.apache.struts2.components;
/*     */ 
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import com.opensymphony.xwork2.util.CompoundRoot;
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import com.opensymphony.xwork2.util.reflection.ReflectionProvider;
/*     */ import java.io.Writer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.struts2.StrutsException;
/*     */ import org.apache.struts2.views.annotations.StrutsTag;
/*     */ 
/*     */ @StrutsTag(name="debug", tldTagClass="org.apache.struts2.views.jsp.ui.DebugTag", description="Prints debugging information")
/*     */ public class Debug extends UIBean
/*     */ {
/*     */   public static final String TEMPLATE = "debug";
/*     */   protected ReflectionProvider reflectionProvider;
/*     */ 
/*     */   public Debug(ValueStack stack, HttpServletRequest request, HttpServletResponse response)
/*     */   {
/*  49 */     super(stack, request, response);
/*     */   }
/*     */   @Inject
/*     */   public void setReflectionProvider(ReflectionProvider prov) {
/*  54 */     this.reflectionProvider = prov;
/*     */   }
/*     */ 
/*     */   protected String getDefaultTemplate() {
/*  58 */     return "debug";
/*     */   }
/*     */ 
/*     */   public boolean start(Writer writer) {
/*  62 */     boolean result = super.start(writer);
/*     */ 
/*  64 */     ValueStack stack = getStack();
/*  65 */     Iterator iter = stack.getRoot().iterator();
/*  66 */     List stackValues = new ArrayList(stack.getRoot().size());
/*  67 */     while (iter.hasNext()) { Object o = iter.next();
/*     */       Map values;
/*     */       try { values = this.reflectionProvider.getBeanMap(o);
/*     */       } catch (Exception e) {
/*  73 */         throw new StrutsException("Caught an exception while getting the property values of " + o, e);
/*     */       }
/*  75 */       stackValues.add(new DebugMapEntry(o.getClass().getName(), values));
/*     */     }
/*     */ 
/*  78 */     addParameter("stackValues", stackValues);
/*     */ 
/*  80 */     return result;
/*     */   }
/*     */   private static class DebugMapEntry implements Map.Entry {
/*     */     private Object key;
/*     */     private Object value;
/*     */ 
/*  88 */     DebugMapEntry(Object key, Object value) { this.key = key;
/*  89 */       this.value = value; }
/*     */ 
/*     */     public Object getKey()
/*     */     {
/*  93 */       return this.key;
/*     */     }
/*     */ 
/*     */     public Object getValue() {
/*  97 */       return this.value;
/*     */     }
/*     */ 
/*     */     public Object setValue(Object newVal) {
/* 101 */       Object oldVal = this.value;
/* 102 */       this.value = newVal;
/* 103 */       return oldVal;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.components.Debug
 * JD-Core Version:    0.6.0
 */