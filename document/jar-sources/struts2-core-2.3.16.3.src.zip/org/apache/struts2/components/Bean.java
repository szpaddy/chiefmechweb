/*     */ package org.apache.struts2.components;
/*     */ 
/*     */ import com.opensymphony.xwork2.ObjectFactory;
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import com.opensymphony.xwork2.util.logging.Logger;
/*     */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*     */ import com.opensymphony.xwork2.util.reflection.ReflectionProvider;
/*     */ import java.io.Writer;
/*     */ import org.apache.struts2.views.annotations.StrutsTag;
/*     */ import org.apache.struts2.views.annotations.StrutsTagAttribute;
/*     */ 
/*     */ @StrutsTag(name="bean", tldTagClass="org.apache.struts2.views.jsp.BeanTag", description="Instantiate a JavaBean and place it in the context")
/*     */ public class Bean extends ContextBean
/*     */ {
/*  98 */   protected static final Logger LOG = LoggerFactory.getLogger(Bean.class);
/*     */   protected Object bean;
/*     */   protected String name;
/*     */   protected ObjectFactory objectFactory;
/*     */   protected ReflectionProvider reflectionProvider;
/*     */ 
/*     */   public Bean(ValueStack stack)
/*     */   {
/* 106 */     super(stack);
/*     */   }
/*     */   @Inject
/*     */   public void setObjectFactory(ObjectFactory objectFactory) {
/* 111 */     this.objectFactory = objectFactory;
/*     */   }
/*     */   @Inject
/*     */   public void setReflectionProvider(ReflectionProvider prov) {
/* 116 */     this.reflectionProvider = prov;
/*     */   }
/*     */ 
/*     */   public boolean start(Writer writer) {
/* 120 */     boolean result = super.start(writer);
/*     */ 
/* 122 */     ValueStack stack = getStack();
/*     */     try
/*     */     {
/* 125 */       String beanName = findString(this.name, "name", "Bean name is required. Example: com.acme.FooBean or proper Spring bean ID");
/* 126 */       this.bean = this.objectFactory.buildBean(beanName, stack.getContext(), false);
/*     */     } catch (Exception e) {
/* 128 */       LOG.error("Could not instantiate bean", e, new String[0]);
/* 129 */       return false;
/*     */     }
/*     */ 
/* 133 */     stack.push(this.bean);
/*     */ 
/* 136 */     putInContext(this.bean);
/*     */ 
/* 138 */     return result;
/*     */   }
/*     */ 
/*     */   public boolean end(Writer writer, String body) {
/* 142 */     ValueStack stack = getStack();
/* 143 */     stack.pop();
/*     */ 
/* 145 */     return super.end(writer, body);
/*     */   }
/*     */ 
/*     */   public void addParameter(String key, Object value) {
/* 149 */     this.reflectionProvider.setProperty(key, value, this.bean, getStack().getContext());
/*     */   }
/*     */   @StrutsTagAttribute(description="The class name of the bean to be instantiated (must respect JavaBean specification)", required=true)
/*     */   public void setName(String name) {
/* 154 */     this.name = name;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.components.Bean
 * JD-Core Version:    0.6.0
 */