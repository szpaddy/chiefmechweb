/*     */ package org.apache.struts2.components;
/*     */ 
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import com.opensymphony.xwork2.util.logging.Logger;
/*     */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import org.apache.commons.lang3.StringEscapeUtils;
/*     */ import org.apache.struts2.views.annotations.StrutsTag;
/*     */ import org.apache.struts2.views.annotations.StrutsTagAttribute;
/*     */ 
/*     */ @StrutsTag(name="property", tldBodyContent="empty", tldTagClass="org.apache.struts2.views.jsp.PropertyTag", description="Print out expression which evaluates against the stack")
/*     */ public class Property extends Component
/*     */ {
/*  92 */   private static final Logger LOG = LoggerFactory.getLogger(Property.class);
/*     */   private String defaultValue;
/*     */   private String value;
/* 100 */   private boolean escapeHtml = true;
/* 101 */   private boolean escapeJavaScript = false;
/* 102 */   private boolean escapeXml = false;
/* 103 */   private boolean escapeCsv = false;
/*     */ 
/*     */   public Property(ValueStack stack)
/*     */   {
/*  95 */     super(stack);
/*     */   }
/*     */ 
/*     */   @StrutsTagAttribute(description="The default value to be used if <u>value</u> attribute is null")
/*     */   public void setDefault(String defaultValue)
/*     */   {
/* 107 */     this.defaultValue = defaultValue;
/*     */   }
/*     */   @StrutsTagAttribute(description="Deprecated. Use 'escapeHtml'. Whether to escape HTML", type="Boolean", defaultValue="true")
/*     */   public void setEscape(boolean escape) {
/* 112 */     this.escapeHtml = escape;
/*     */   }
/*     */   @StrutsTagAttribute(description="Whether to escape HTML", type="Boolean", defaultValue="true")
/*     */   public void setEscapeHtml(boolean escape) {
/* 117 */     this.escapeHtml = escape;
/*     */   }
/*     */   @StrutsTagAttribute(description="Whether to escape Javascript", type="Boolean", defaultValue="false")
/*     */   public void setEscapeJavaScript(boolean escapeJavaScript) {
/* 122 */     this.escapeJavaScript = escapeJavaScript;
/*     */   }
/*     */   @StrutsTagAttribute(description="Value to be displayed", type="Object", defaultValue="&lt;top of stack&gt;")
/*     */   public void setValue(String value) {
/* 127 */     this.value = value;
/*     */   }
/*     */ 
/*     */   public void setDefaultValue(String defaultValue) {
/* 131 */     this.defaultValue = defaultValue;
/*     */   }
/*     */   @StrutsTagAttribute(description="Whether to escape CSV (useful to escape a value for a column)", type="Boolean", defaultValue="false")
/*     */   public void setEscapeCsv(boolean escapeCsv) {
/* 136 */     this.escapeCsv = escapeCsv;
/*     */   }
/*     */   @StrutsTagAttribute(description="Whether to escape XML", type="Boolean", defaultValue="false")
/*     */   public void setEscapeXml(boolean escapeXml) {
/* 141 */     this.escapeXml = escapeXml;
/*     */   }
/*     */ 
/*     */   public boolean start(Writer writer) {
/* 145 */     boolean result = super.start(writer);
/*     */ 
/* 147 */     String actualValue = null;
/*     */ 
/* 149 */     if (this.value == null) {
/* 150 */       this.value = "top";
/*     */     }
/*     */     else {
/* 153 */       this.value = stripExpressionIfAltSyntax(this.value);
/*     */     }
/*     */ 
/* 159 */     actualValue = (String)getStack().findValue(this.value, String.class, this.throwExceptionOnELFailure);
/*     */     try
/*     */     {
/* 162 */       if (actualValue != null)
/* 163 */         writer.write(prepare(actualValue));
/* 164 */       else if (this.defaultValue != null)
/* 165 */         writer.write(prepare(this.defaultValue));
/*     */     }
/*     */     catch (IOException e) {
/* 168 */       if (LOG.isInfoEnabled()) {
/* 169 */         LOG.info("Could not print out value '" + this.value + "'", e, new String[0]);
/*     */       }
/*     */     }
/*     */ 
/* 173 */     return result;
/*     */   }
/*     */ 
/*     */   private String prepare(String value) {
/* 177 */     String result = value;
/* 178 */     if (this.escapeHtml) {
/* 179 */       result = StringEscapeUtils.escapeHtml4(result);
/*     */     }
/* 181 */     if (this.escapeJavaScript) {
/* 182 */       result = StringEscapeUtils.escapeEcmaScript(result);
/*     */     }
/* 184 */     if (this.escapeXml) {
/* 185 */       result = StringEscapeUtils.escapeXml(result);
/*     */     }
/* 187 */     if (this.escapeCsv) {
/* 188 */       result = StringEscapeUtils.escapeCsv(result);
/*     */     }
/*     */ 
/* 191 */     return result;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.components.Property
 * JD-Core Version:    0.6.0
 */