/*     */ package org.apache.struts2.components;
/*     */ 
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import java.io.Writer;
/*     */ import java.util.Map;
/*     */ import org.apache.struts2.views.annotations.StrutsTag;
/*     */ import org.apache.struts2.views.annotations.StrutsTagAttribute;
/*     */ 
/*     */ @StrutsTag(name="set", tldBodyContent="JSP", tldTagClass="org.apache.struts2.views.jsp.SetTag", description="Assigns a value to a variable in a specified scope")
/*     */ public class Set extends ContextBean
/*     */ {
/*     */   protected String scope;
/*     */   protected String value;
/*     */ 
/*     */   public Set(ValueStack stack)
/*     */   {
/*  90 */     super(stack);
/*     */   }
/*     */ 
/*     */   public boolean end(Writer writer, String body) {
/*  94 */     ValueStack stack = getStack();
/*     */     Object o;
/*     */     Object o;
/*  97 */     if (this.value == null)
/*     */     {
/*     */       Object o;
/*  98 */       if ((body != null) && (!body.equals("")))
/*  99 */         o = body;
/*     */       else
/* 101 */         o = findValue("top");
/*     */     }
/*     */     else {
/* 104 */       o = findValue(this.value);
/*     */     }
/*     */ 
/* 107 */     body = "";
/*     */ 
/* 109 */     if ("application".equalsIgnoreCase(this.scope)) {
/* 110 */       stack.setValue("#application['" + getVar() + "']", o);
/* 111 */     } else if ("session".equalsIgnoreCase(this.scope)) {
/* 112 */       stack.setValue("#session['" + getVar() + "']", o);
/* 113 */     } else if ("request".equalsIgnoreCase(this.scope)) {
/* 114 */       stack.setValue("#request['" + getVar() + "']", o);
/* 115 */     } else if ("page".equalsIgnoreCase(this.scope)) {
/* 116 */       stack.setValue("#attr['" + getVar() + "']", o, false);
/*     */     } else {
/* 118 */       stack.getContext().put(getVar(), o);
/* 119 */       stack.setValue("#attr['" + getVar() + "']", o, false);
/*     */     }
/*     */ 
/* 122 */     return super.end(writer, body);
/*     */   }
/*     */ 
/*     */   @StrutsTagAttribute(description="Name used to reference the value pushed into the Value Stack")
/*     */   public void setVar(String var)
/*     */   {
/* 130 */     super.setVar(var);
/*     */   }
/*     */   @StrutsTagAttribute(description="Deprecated. Use 'var' instead")
/*     */   public void setName(String name) {
/* 135 */     setVar(name);
/*     */   }
/*     */ 
/*     */   @StrutsTagAttribute(description="The scope in which to assign the variable. Can be <b>application</b>, <b>session</b>, <b>request</b>, <b>page</b>, or <b>action</b>.", defaultValue="action")
/*     */   public void setScope(String scope) {
/* 141 */     this.scope = scope;
/*     */   }
/*     */   @StrutsTagAttribute(description="The value that is assigned to the variable named <i>name</i>")
/*     */   public void setValue(String value) {
/* 146 */     this.value = value;
/*     */   }
/*     */ 
/*     */   public boolean usesBody()
/*     */   {
/* 151 */     return true;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.components.Set
 * JD-Core Version:    0.6.0
 */