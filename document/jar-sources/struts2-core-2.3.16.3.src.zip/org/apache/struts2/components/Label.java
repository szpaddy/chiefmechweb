/*     */ package org.apache.struts2.components;
/*     */ 
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import java.util.Map;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.struts2.util.TextProviderHelper;
/*     */ import org.apache.struts2.views.annotations.StrutsTag;
/*     */ import org.apache.struts2.views.annotations.StrutsTagAttribute;
/*     */ 
/*     */ @StrutsTag(name="label", tldTagClass="org.apache.struts2.views.jsp.ui.LabelTag", description="Render a label that displays read-only information", allowDynamicAttributes=true)
/*     */ public class Label extends UIBean
/*     */ {
/*     */   public static final String TEMPLATE = "label";
/*     */   protected String forAttr;
/*     */ 
/*     */   public Label(ValueStack stack, HttpServletRequest request, HttpServletResponse response)
/*     */   {
/*  69 */     super(stack, request, response);
/*     */   }
/*     */ 
/*     */   protected String getDefaultTemplate() {
/*  73 */     return "label";
/*     */   }
/*     */ 
/*     */   protected void evaluateExtraParams() {
/*  77 */     super.evaluateExtraParams();
/*     */ 
/*  79 */     if (this.forAttr != null) {
/*  80 */       addParameter("for", findString(this.forAttr));
/*     */     }
/*     */ 
/*  84 */     if (this.value != null) {
/*  85 */       addParameter("nameValue", findString(this.value));
/*  86 */     } else if (this.key != null) {
/*  87 */       Object nameValue = this.parameters.get("nameValue");
/*  88 */       if ((nameValue == null) || (nameValue.toString().length() == 0))
/*     */       {
/*  90 */         String providedLabel = TextProviderHelper.getText(this.key, this.key, this.stack);
/*  91 */         addParameter("nameValue", providedLabel);
/*     */       }
/*  93 */     } else if (this.name != null) {
/*  94 */       String expr = completeExpressionIfAltSyntax(this.name);
/*  95 */       addParameter("nameValue", findString(expr));
/*     */     }
/*     */   }
/*     */ 
/*     */   @StrutsTagAttribute(description=" HTML for attribute")
/*     */   public void setFor(String forAttr) {
/* 101 */     this.forAttr = forAttr;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.components.Label
 * JD-Core Version:    0.6.0
 */