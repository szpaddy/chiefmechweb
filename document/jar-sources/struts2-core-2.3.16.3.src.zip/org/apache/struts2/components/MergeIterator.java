/*     */ package org.apache.struts2.components;
/*     */ 
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import com.opensymphony.xwork2.util.logging.Logger;
/*     */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*     */ import java.io.Writer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.apache.struts2.util.MakeIterator;
/*     */ import org.apache.struts2.util.MergeIteratorFilter;
/*     */ import org.apache.struts2.views.annotations.StrutsTag;
/*     */ import org.apache.struts2.views.annotations.StrutsTagAttribute;
/*     */ 
/*     */ @StrutsTag(name="merge", tldTagClass="org.apache.struts2.views.jsp.iterator.MergeIteratorTag", description="Merge the values of a list of iterators into one iterator")
/*     */ public class MergeIterator extends ContextBean
/*     */   implements Param.UnnamedParametric
/*     */ {
/* 136 */   private static final Logger LOG = LoggerFactory.getLogger(MergeIterator.class);
/*     */ 
/* 138 */   private MergeIteratorFilter mergeIteratorFilter = null;
/*     */   private List _parameters;
/*     */ 
/*     */   public MergeIterator(ValueStack stack)
/*     */   {
/* 142 */     super(stack);
/*     */   }
/*     */ 
/*     */   public boolean start(Writer writer)
/*     */   {
/* 147 */     this.mergeIteratorFilter = new MergeIteratorFilter();
/* 148 */     this._parameters = new ArrayList();
/*     */ 
/* 150 */     return super.start(writer);
/*     */   }
/*     */ 
/*     */   public boolean end(Writer writer, String body)
/*     */   {
/* 155 */     for (Iterator parametersIterator = this._parameters.iterator(); parametersIterator.hasNext(); ) {
/* 156 */       Object iteratorEntryObj = parametersIterator.next();
/* 157 */       if (!MakeIterator.isIterable(iteratorEntryObj)) {
/* 158 */         if (LOG.isWarnEnabled()) {
/* 159 */           LOG.warn("param with value resolved as " + iteratorEntryObj + " cannot be make as iterator, it will be ignored and hence will not appear in the merged iterator", new String[0]); continue;
/*     */         }
/*     */       }
/*     */ 
/* 163 */       this.mergeIteratorFilter.setSource(MakeIterator.convert(iteratorEntryObj));
/*     */     }
/*     */ 
/* 166 */     this.mergeIteratorFilter.execute();
/*     */ 
/* 169 */     putInContext(this.mergeIteratorFilter);
/*     */ 
/* 171 */     this.mergeIteratorFilter = null;
/*     */ 
/* 173 */     return super.end(writer, body);
/*     */   }
/*     */   @StrutsTagAttribute(description="The name where the resultant merged iterator will be stored in the stack's context")
/*     */   public void setVar(String var) {
/* 178 */     super.setVar(var);
/*     */   }
/*     */ 
/*     */   public void addParameter(Object value)
/*     */   {
/* 183 */     this._parameters.add(value);
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.components.MergeIterator
 * JD-Core Version:    0.6.0
 */