/*    */ package org.apache.struts2.components;
/*    */ 
/*    */ import com.opensymphony.xwork2.util.ValueStack;
/*    */ import java.util.Map;
/*    */ import org.apache.struts2.views.annotations.StrutsTagAttribute;
/*    */ 
/*    */ public abstract class ContextBean extends Component
/*    */ {
/*    */   protected String var;
/*    */ 
/*    */   public ContextBean(ValueStack stack)
/*    */   {
/* 35 */     super(stack);
/*    */   }
/*    */ 
/*    */   protected void putInContext(Object value) {
/* 39 */     if ((this.var != null) && (this.var.length() > 0))
/* 40 */       this.stack.getContext().put(this.var, value);
/*    */   }
/*    */ 
/*    */   @StrutsTagAttribute(description="Name used to reference the value pushed into the Value Stack")
/*    */   public void setVar(String var) {
/* 46 */     if (var != null)
/* 47 */       this.var = findString(var);
/*    */   }
/*    */ 
/*    */   @StrutsTagAttribute(description="Deprecated. Use 'var' instead")
/*    */   public void setId(String id)
/*    */   {
/* 57 */     setVar(id);
/*    */   }
/*    */ 
/*    */   protected String getVar() {
/* 61 */     return this.var;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.components.ContextBean
 * JD-Core Version:    0.6.0
 */