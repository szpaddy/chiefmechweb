/*     */ package org.apache.struts2.components;
/*     */ 
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.struts2.views.annotations.StrutsTag;
/*     */ import org.apache.struts2.views.annotations.StrutsTagAttribute;
/*     */ 
/*     */ @StrutsTag(name="textfield", tldTagClass="org.apache.struts2.views.jsp.ui.TextFieldTag", description="Render an HTML input field of type text", allowDynamicAttributes=true)
/*     */ public class TextField extends UIBean
/*     */ {
/*     */   public static final String TEMPLATE = "text";
/*     */   protected String maxlength;
/*     */   protected String readonly;
/*     */   protected String size;
/*     */   protected String type;
/*     */ 
/*     */   public TextField(ValueStack stack, HttpServletRequest request, HttpServletResponse response)
/*     */   {
/*  72 */     super(stack, request, response);
/*     */   }
/*     */ 
/*     */   protected String getDefaultTemplate() {
/*  76 */     return "text";
/*     */   }
/*     */ 
/*     */   protected void evaluateExtraParams() {
/*  80 */     super.evaluateExtraParams();
/*     */ 
/*  82 */     if (this.size != null) {
/*  83 */       addParameter("size", findString(this.size));
/*     */     }
/*     */ 
/*  86 */     if (this.maxlength != null) {
/*  87 */       addParameter("maxlength", findString(this.maxlength));
/*     */     }
/*     */ 
/*  90 */     if (this.readonly != null) {
/*  91 */       addParameter("readonly", findValue(this.readonly, Boolean.class));
/*     */     }
/*     */ 
/*  94 */     if (this.type != null)
/*  95 */       addParameter("type", findString(this.type));
/*     */   }
/*     */ 
/*     */   @StrutsTagAttribute(description="HTML maxlength attribute", type="Integer")
/*     */   public void setMaxlength(String maxlength)
/*     */   {
/* 102 */     this.maxlength = maxlength;
/*     */   }
/*     */   @StrutsTagAttribute(description="Deprecated. Use maxlength instead.", type="Integer")
/*     */   public void setMaxLength(String maxlength) {
/* 107 */     this.maxlength = maxlength;
/*     */   }
/*     */   @StrutsTagAttribute(description="Whether the input is readonly", type="Boolean", defaultValue="false")
/*     */   public void setReadonly(String readonly) {
/* 112 */     this.readonly = readonly;
/*     */   }
/*     */   @StrutsTagAttribute(description="HTML size attribute", type="Integer")
/*     */   public void setSize(String size) {
/* 117 */     this.size = size;
/*     */   }
/*     */   @StrutsTagAttribute(description="Specifies the html5 type element to display. e.g. text, email, url", defaultValue="text")
/*     */   public void setType(String type) {
/* 122 */     this.type = type;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.components.TextField
 * JD-Core Version:    0.6.0
 */