package org.apache.struts2.components;

import com.opensymphony.xwork2.util.ValueStack;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public abstract interface UrlProvider
{
  public static final String NONE = "none";
  public static final String GET = "get";
  public static final String ALL = "all";

  public abstract boolean isPutInContext();

  public abstract String getVar();

  public abstract String getValue();

  public abstract String findString(String paramString);

  public abstract void setValue(String paramString);

  public abstract String getUrlIncludeParams();

  public abstract String getIncludeParams();

  public abstract Map getParameters();

  public abstract HttpServletRequest getHttpServletRequest();

  public abstract String getAction();

  public abstract ExtraParameterProvider getExtraParameterProvider();

  public abstract String getScheme();

  public abstract String getNamespace();

  public abstract String getMethod();

  public abstract HttpServletResponse getHttpServletResponse();

  public abstract boolean isIncludeContext();

  public abstract boolean isEncode();

  public abstract boolean isForceAddSchemeHostAndPort();

  public abstract boolean isEscapeAmp();

  public abstract String getPortletMode();

  public abstract String getWindowState();

  public abstract String determineActionURL(String paramString1, String paramString2, String paramString3, HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse, Map paramMap, String paramString4, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4);

  public abstract String determineNamespace(String paramString, ValueStack paramValueStack, HttpServletRequest paramHttpServletRequest);

  public abstract String getAnchor();

  public abstract String getPortletUrlType();

  public abstract ValueStack getStack();

  public abstract void setUrlIncludeParams(String paramString);

  public abstract void setHttpServletRequest(HttpServletRequest paramHttpServletRequest);

  public abstract void setHttpServletResponse(HttpServletResponse paramHttpServletResponse);

  public abstract void setUrlRenderer(UrlRenderer paramUrlRenderer);

  public abstract void setExtraParameterProvider(ExtraParameterProvider paramExtraParameterProvider);

  public abstract void setIncludeParams(String paramString);

  public abstract void setScheme(String paramString);

  public abstract void setAction(String paramString);

  public abstract void setPortletMode(String paramString);

  public abstract void setNamespace(String paramString);

  public abstract void setMethod(String paramString);

  public abstract void setEncode(boolean paramBoolean);

  public abstract void setIncludeContext(boolean paramBoolean);

  public abstract void setWindowState(String paramString);

  public abstract void setPortletUrlType(String paramString);

  public abstract void setAnchor(String paramString);

  public abstract void setEscapeAmp(boolean paramBoolean);

  public abstract void setForceAddSchemeHostAndPort(boolean paramBoolean);

  public abstract void putInContext(String paramString);
}

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.components.UrlProvider
 * JD-Core Version:    0.6.0
 */