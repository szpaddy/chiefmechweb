/*     */ package org.apache.struts2.components;
/*     */ 
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import java.util.Map;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.struts2.dispatcher.mapper.ActionMapper;
/*     */ import org.apache.struts2.dispatcher.mapper.ActionMapping;
/*     */ import org.apache.struts2.views.annotations.StrutsTagAttribute;
/*     */ 
/*     */ public abstract class FormButton extends ClosingUIBean
/*     */ {
/*     */   static final String BUTTONTYPE_INPUT = "input";
/*     */   static final String BUTTONTYPE_BUTTON = "button";
/*     */   static final String BUTTONTYPE_IMAGE = "image";
/*     */   protected String action;
/*     */   protected String method;
/*     */   protected String align;
/*     */   protected String type;
/*     */ 
/*     */   public FormButton(ValueStack stack, HttpServletRequest request, HttpServletResponse response)
/*     */   {
/*  49 */     super(stack, request, response);
/*     */   }
/*     */ 
/*     */   public void evaluateExtraParams()
/*     */   {
/*  54 */     super.evaluateExtraParams();
/*  55 */     if (this.align == null) {
/*  56 */       this.align = "right";
/*     */     }
/*     */ 
/*  59 */     String submitType = "input";
/*  60 */     if ((this.type != null) && (("button".equalsIgnoreCase(this.type)) || ((supportsImageType()) && ("image".equalsIgnoreCase(this.type)))))
/*     */     {
/*  62 */       submitType = this.type;
/*     */     }
/*     */ 
/*  67 */     addParameter("type", submitType);
/*     */ 
/*  69 */     if ((!"input".equals(submitType)) && (this.label == null)) {
/*  70 */       addParameter("label", getParameters().get("nameValue"));
/*     */     }
/*     */ 
/*  73 */     if ((this.action != null) || (this.method != null))
/*     */     {
/*     */       String name;
/*     */       String name;
/*  76 */       if (this.action != null) {
/*  77 */         ActionMapping mapping = new ActionMapping();
/*  78 */         mapping.setName(findString(this.action));
/*  79 */         if (this.method != null) {
/*  80 */           mapping.setMethod(findString(this.method));
/*     */         }
/*  82 */         mapping.setExtension("");
/*  83 */         name = "action:" + this.actionMapper.getUriFromActionMapping(mapping);
/*     */       } else {
/*  85 */         name = "method:" + findString(this.method);
/*     */       }
/*     */ 
/*  88 */       addParameter("name", name);
/*     */     }
/*     */ 
/*  91 */     addParameter("align", findString(this.align));
/*     */   }
/*     */ 
/*     */   protected void populateComponentHtmlId(Form form)
/*     */   {
/* 110 */     String _tmp_id = "";
/* 111 */     if (this.id != null)
/*     */     {
/* 113 */       _tmp_id = findStringIfAltSyntax(this.id);
/*     */     }
/*     */     else {
/* 116 */       if ((form != null) && (form.getParameters().get("id") != null)) {
/* 117 */         _tmp_id = _tmp_id + form.getParameters().get("id").toString() + "_";
/*     */       }
/* 119 */       if (this.name != null) {
/* 120 */         _tmp_id = _tmp_id + escape(this.name);
/* 121 */       } else if ((this.action != null) || (this.method != null)) {
/* 122 */         if (this.action != null) {
/* 123 */           _tmp_id = _tmp_id + escape(this.action);
/*     */         }
/* 125 */         if (this.method != null) {
/* 126 */           _tmp_id = _tmp_id + "_" + escape(this.method);
/*     */         }
/*     */ 
/*     */       }
/* 131 */       else if (form != null) {
/* 132 */         _tmp_id = _tmp_id + form.getSequence();
/*     */       }
/*     */     }
/*     */ 
/* 136 */     addParameter("id", _tmp_id);
/*     */   }
/*     */ 
/*     */   protected abstract boolean supportsImageType();
/*     */ 
/*     */   @Inject
/*     */   public void setActionMapper(ActionMapper mapper)
/*     */   {
/* 148 */     this.actionMapper = mapper;
/*     */   }
/*     */   @StrutsTagAttribute(description="Set action attribute.")
/*     */   public void setAction(String action) {
/* 153 */     this.action = action;
/*     */   }
/*     */   @StrutsTagAttribute(description="Set method attribute.")
/*     */   public void setMethod(String method) {
/* 158 */     this.method = method;
/*     */   }
/*     */   @StrutsTagAttribute(description="HTML align attribute.")
/*     */   public void setAlign(String align) {
/* 163 */     this.align = align;
/*     */   }
/*     */ 
/*     */   @StrutsTagAttribute(description="The type of submit to use. Valid values are <i>input</i>, <i>button</i> and <i>image</i>.", defaultValue="input")
/*     */   public void setType(String type) {
/* 169 */     this.type = type;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.components.FormButton
 * JD-Core Version:    0.6.0
 */