/*     */ package org.apache.struts2.components;
/*     */ 
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import com.opensymphony.xwork2.util.logging.Logger;
/*     */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.apache.commons.lang3.StringUtils;
/*     */ import org.apache.struts2.util.TextProviderHelper;
/*     */ import org.apache.struts2.views.annotations.StrutsTag;
/*     */ import org.apache.struts2.views.annotations.StrutsTagAttribute;
/*     */ 
/*     */ @StrutsTag(name="text", tldTagClass="org.apache.struts2.views.jsp.TextTag", description="Render a I18n text message")
/*     */ public class Text extends ContextBean
/*     */   implements Param.UnnamedParametric
/*     */ {
/* 122 */   private static final Logger LOG = LoggerFactory.getLogger(Text.class);
/*     */ 
/* 124 */   protected List values = Collections.EMPTY_LIST;
/*     */   protected String actualName;
/*     */   protected String name;
/*     */   protected String searchStack;
/*     */ 
/*     */   public Text(ValueStack stack)
/*     */   {
/* 130 */     super(stack);
/*     */   }
/*     */   @StrutsTagAttribute(description=" Name of resource property to fetch", required=true)
/*     */   public void setName(String name) {
/* 135 */     this.name = name;
/*     */   }
/*     */   @StrutsTagAttribute(description="Search the stack if property is not found on resources", type="Boolean", defaultValue="true")
/*     */   public void setSearchValueStack(String searchStack) {
/* 140 */     this.searchStack = searchStack;
/*     */   }
/*     */ 
/*     */   public boolean usesBody()
/*     */   {
/* 147 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean end(Writer writer, String body) {
/* 151 */     this.actualName = findString(this.name, "name", "You must specify the i18n key. Example: welcome.header");
/*     */     String defaultMessage;
/*     */     String defaultMessage;
/* 153 */     if (StringUtils.isNotEmpty(body))
/* 154 */       defaultMessage = body;
/*     */     else {
/* 156 */       defaultMessage = this.actualName;
/*     */     }
/*     */ 
/* 159 */     Boolean doSearchStack = Boolean.valueOf(this.searchStack != null ? ((Boolean)findValue(this.searchStack, Boolean.class)).booleanValue() : true);
/* 160 */     String msg = TextProviderHelper.getText(this.actualName, defaultMessage, this.values, getStack(), (doSearchStack == null) || (doSearchStack.booleanValue()));
/*     */ 
/* 162 */     if (msg != null) {
/*     */       try {
/* 164 */         if (getVar() == null)
/* 165 */           writer.write(msg);
/*     */         else
/* 167 */           putInContext(msg);
/*     */       }
/*     */       catch (IOException e) {
/* 170 */         LOG.error("Could not write out Text tag", e, new String[0]);
/*     */       }
/*     */     }
/*     */ 
/* 174 */     return super.end(writer, "");
/*     */   }
/*     */ 
/*     */   public void addParameter(String key, Object value) {
/* 178 */     addParameter(value);
/*     */   }
/*     */ 
/*     */   public void addParameter(Object value) {
/* 182 */     if (this.values.isEmpty()) {
/* 183 */       this.values = new ArrayList(4);
/*     */     }
/*     */ 
/* 186 */     this.values.add(value);
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.components.Text
 * JD-Core Version:    0.6.0
 */