/*    */ package org.apache.struts2.components;
/*    */ 
/*    */ import com.opensymphony.xwork2.util.ValueStack;
/*    */ import java.io.Writer;
/*    */ import java.util.Map;
/*    */ import org.apache.struts2.views.annotations.StrutsTag;
/*    */ import org.apache.struts2.views.annotations.StrutsTagAttribute;
/*    */ 
/*    */ @StrutsTag(name="if", tldTagClass="org.apache.struts2.views.jsp.IfTag", description="If tag")
/*    */ public class If extends Component
/*    */ {
/*    */   public static final String ANSWER = "struts.if.answer";
/*    */   Boolean answer;
/*    */   String test;
/*    */ 
/*    */   @StrutsTagAttribute(description="Expression to determine if body of tag is to be displayed", type="Boolean", required=true)
/*    */   public void setTest(String test)
/*    */   {
/* 78 */     this.test = test;
/*    */   }
/*    */ 
/*    */   public If(ValueStack stack) {
/* 82 */     super(stack);
/*    */   }
/*    */ 
/*    */   public boolean start(Writer writer) {
/* 86 */     this.answer = ((Boolean)findValue(this.test, Boolean.class));
/*    */ 
/* 88 */     if (this.answer == null) {
/* 89 */       this.answer = Boolean.FALSE;
/*    */     }
/* 91 */     this.stack.getContext().put("struts.if.answer", this.answer);
/* 92 */     return this.answer.booleanValue();
/*    */   }
/*    */ 
/*    */   public boolean end(Writer writer, String body) {
/* 96 */     this.stack.getContext().put("struts.if.answer", this.answer);
/* 97 */     return super.end(writer, body);
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.components.If
 * JD-Core Version:    0.6.0
 */