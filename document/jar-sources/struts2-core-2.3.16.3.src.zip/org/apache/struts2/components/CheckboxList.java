/*    */ package org.apache.struts2.components;
/*    */ 
/*    */ import com.opensymphony.xwork2.util.ValueStack;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.apache.struts2.views.annotations.StrutsTag;
/*    */ 
/*    */ @StrutsTag(name="checkboxlist", tldTagClass="org.apache.struts2.views.jsp.ui.CheckboxListTag", description="Render a list of checkboxes")
/*    */ public class CheckboxList extends ListUIBean
/*    */ {
/*    */   public static final String TEMPLATE = "checkboxlist";
/*    */ 
/*    */   public CheckboxList(ValueStack stack, HttpServletRequest request, HttpServletResponse response)
/*    */   {
/* 52 */     super(stack, request, response);
/*    */   }
/*    */ 
/*    */   protected String getDefaultTemplate() {
/* 56 */     return "checkboxlist";
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.components.CheckboxList
 * JD-Core Version:    0.6.0
 */