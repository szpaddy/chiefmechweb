package org.apache.struts2;

public abstract interface StrutsStatics
{
  public static final String HTTP_REQUEST = "com.opensymphony.xwork2.dispatcher.HttpServletRequest";
  public static final String HTTP_RESPONSE = "com.opensymphony.xwork2.dispatcher.HttpServletResponse";
  public static final String SERVLET_DISPATCHER = "com.opensymphony.xwork2.dispatcher.ServletDispatcher";
  public static final String SERVLET_CONTEXT = "com.opensymphony.xwork2.dispatcher.ServletContext";
  public static final String PAGE_CONTEXT = "com.opensymphony.xwork2.dispatcher.PageContext";
  public static final String STRUTS_PORTLET_CONTEXT = "struts.portlet.context";
  public static final String STRUTS_ACTION_TAG_INVOCATION = "struts.actiontag.invocation";
}

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.StrutsStatics
 * JD-Core Version:    0.6.0
 */