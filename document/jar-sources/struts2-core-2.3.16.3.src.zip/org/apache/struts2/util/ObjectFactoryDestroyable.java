package org.apache.struts2.util;

public abstract interface ObjectFactoryDestroyable
{
  public abstract void destroy();
}

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.util.ObjectFactoryDestroyable
 * JD-Core Version:    0.6.0
 */