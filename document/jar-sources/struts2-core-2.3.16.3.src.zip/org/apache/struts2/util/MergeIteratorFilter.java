/*    */ package org.apache.struts2.util;
/*    */ 
/*    */ import com.opensymphony.xwork2.Action;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ 
/*    */ public class MergeIteratorFilter extends IteratorFilterSupport
/*    */   implements Iterator, Action
/*    */ {
/* 40 */   List iterators = new ArrayList();
/*    */ 
/* 43 */   List sources = new ArrayList();
/* 44 */   int idx = 0;
/*    */ 
/*    */   public void setSource(Object anIterator)
/*    */   {
/* 49 */     this.sources.add(anIterator);
/*    */   }
/*    */ 
/*    */   public String execute()
/*    */   {
/* 55 */     for (int i = 0; i < this.sources.size(); i++) {
/* 56 */       Object source = this.sources.get(i);
/* 57 */       this.iterators.add(getIterator(source));
/*    */     }
/*    */ 
/* 60 */     return "success";
/*    */   }
/*    */ 
/*    */   public boolean hasNext()
/*    */   {
/* 65 */     while (this.iterators.size() > 0) {
/* 66 */       if (((Action)this.iterators.get(this.idx)).hasNext()) {
/* 67 */         return true;
/*    */       }
/* 69 */       this.iterators.remove(this.idx);
/*    */ 
/* 71 */       if (this.iterators.size() > 0) {
/* 72 */         this.idx %= this.iterators.size();
/*    */       }
/*    */ 
/*    */     }
/*    */ 
/* 77 */     return false;
/*    */   }
/*    */ 
/*    */   public Object next() {
/*    */     try {
/* 82 */       Object localObject1 = ((Action)this.iterators.get(this.idx)).next();
/*    */       return localObject1; } finally { this.idx = ((this.idx + 1) % this.iterators.size()); } throw localObject2;
/*    */   }
/*    */ 
/*    */   public void remove()
/*    */   {
/* 89 */     throw new UnsupportedOperationException("Remove is not supported in MergeIteratorFilter.");
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.util.MergeIteratorFilter
 * JD-Core Version:    0.6.0
 */