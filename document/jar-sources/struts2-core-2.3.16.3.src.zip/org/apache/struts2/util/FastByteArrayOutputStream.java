/*     */ package org.apache.struts2.util;
/*     */ 
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.RandomAccessFile;
/*     */ import java.io.Writer;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.CharBuffer;
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.CharsetDecoder;
/*     */ import java.nio.charset.CharsetEncoder;
/*     */ import java.nio.charset.CoderResult;
/*     */ import java.nio.charset.CodingErrorAction;
/*     */ import java.util.LinkedList;
/*     */ import javax.servlet.jsp.JspWriter;
/*     */ 
/*     */ public class FastByteArrayOutputStream extends OutputStream
/*     */ {
/*     */   private static final int DEFAULT_BLOCK_SIZE = 8192;
/*     */   private LinkedList<byte[]> buffers;
/*     */   private byte[] buffer;
/*     */   private int index;
/*     */   private int size;
/*     */   private int blockSize;
/*     */   private boolean closed;
/*     */ 
/*     */   public FastByteArrayOutputStream()
/*     */   {
/*  53 */     this(8192);
/*     */   }
/*     */ 
/*     */   public FastByteArrayOutputStream(int blockSize) {
/*  57 */     this.buffer = new byte[this.blockSize = blockSize];
/*     */   }
/*     */ 
/*     */   public void writeTo(OutputStream out) throws IOException {
/*  61 */     if (this.buffers != null) {
/*  62 */       for (byte[] bytes : this.buffers) {
/*  63 */         out.write(bytes, 0, this.blockSize);
/*     */       }
/*     */     }
/*  66 */     out.write(this.buffer, 0, this.index);
/*     */   }
/*     */ 
/*     */   public void writeTo(RandomAccessFile out) throws IOException {
/*  70 */     if (this.buffers != null) {
/*  71 */       for (byte[] bytes : this.buffers) {
/*  72 */         out.write(bytes, 0, this.blockSize);
/*     */       }
/*     */     }
/*  75 */     out.write(this.buffer, 0, this.index);
/*     */   }
/*     */ 
/*     */   public void writeTo(Writer out, String encoding)
/*     */     throws IOException
/*     */   {
/*  85 */     if (encoding != null) {
/*  86 */       CharsetDecoder decoder = getDecoder(encoding);
/*     */ 
/*  88 */       CharBuffer charBuffer = CharBuffer.allocate(this.buffer.length);
/*     */ 
/*  90 */       float bytesPerChar = decoder.charset().newEncoder().maxBytesPerChar();
/*  91 */       ByteBuffer byteBuffer = ByteBuffer.allocate((int)(this.buffer.length + bytesPerChar));
/*  92 */       if (this.buffers != null) {
/*  93 */         for (byte[] bytes : this.buffers) {
/*  94 */           decodeAndWriteOut(out, bytes, bytes.length, byteBuffer, charBuffer, decoder, false);
/*     */         }
/*     */       }
/*  97 */       decodeAndWriteOut(out, this.buffer, this.index, byteBuffer, charBuffer, decoder, true);
/*     */     } else {
/*  99 */       if (this.buffers != null) {
/* 100 */         for (byte[] bytes : this.buffers) {
/* 101 */           writeOut(out, bytes, bytes.length);
/*     */         }
/*     */       }
/* 104 */       writeOut(out, this.buffer, this.index);
/*     */     }
/*     */   }
/*     */ 
/*     */   private CharsetDecoder getDecoder(String encoding) {
/* 109 */     Charset charset = Charset.forName(encoding);
/* 110 */     return charset.newDecoder().onMalformedInput(CodingErrorAction.REPORT).onUnmappableCharacter(CodingErrorAction.REPLACE);
/*     */   }
/*     */ 
/*     */   public void writeTo(JspWriter out, String encoding)
/*     */     throws IOException
/*     */   {
/*     */     try
/*     */     {
/* 123 */       writeTo(out, encoding);
/*     */     } catch (IOException e) {
/* 125 */       writeToFile();
/* 126 */       throw e;
/*     */     } catch (Throwable e) {
/* 128 */       writeToFile();
/* 129 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void writeToFile()
/*     */   {
/* 137 */     FileOutputStream fileOutputStream = null;
/*     */     try {
/* 139 */       fileOutputStream = new FileOutputStream("/tmp/" + getClass().getName() + System.currentTimeMillis() + ".log");
/* 140 */       writeTo(fileOutputStream);
/*     */     } catch (IOException e) {
/*     */     }
/*     */     finally {
/* 144 */       if (fileOutputStream != null)
/*     */         try {
/* 146 */           fileOutputStream.close();
/*     */         }
/*     */         catch (IOException e)
/*     */         {
/*     */         }
/*     */     }
/*     */   }
/*     */ 
/*     */   private void writeOut(Writer out, byte[] bytes, int length) throws IOException {
/* 155 */     out.write(new String(bytes, 0, length));
/*     */   }
/*     */ 
/*     */   private static void decodeAndWriteOut(Writer writer, byte[] bytes, int length, ByteBuffer in, CharBuffer out, CharsetDecoder decoder, boolean endOfInput)
/*     */     throws IOException
/*     */   {
/* 161 */     in.put(bytes, 0, length);
/*     */ 
/* 163 */     in.flip();
/* 164 */     decodeAndWriteBuffered(writer, in, out, decoder, endOfInput);
/*     */   }
/*     */ 
/*     */   private static void decodeAndWriteBuffered(Writer writer, ByteBuffer in, CharBuffer out, CharsetDecoder decoder, boolean endOfInput) throws IOException {
/*     */     CoderResult result;
/*     */     do {
/* 171 */       result = decodeAndWrite(writer, in, out, decoder, endOfInput);
/*     */ 
/* 173 */       if (in.hasRemaining())
/*     */       {
/* 175 */         in.compact();
/* 176 */         if ((!result.isOverflow()) || (result.isError()) || (result.isMalformed())) {
/*     */           continue;
/*     */         }
/* 179 */         in.flip();
/*     */       }
/*     */       else
/*     */       {
/* 183 */         in.clear();
/*     */       }
/*     */     }
/* 185 */     while ((in.hasRemaining()) && (result.isOverflow()) && (!result.isError()) && (!result.isMalformed()));
/*     */   }
/*     */ 
/*     */   private static CoderResult decodeAndWrite(Writer writer, ByteBuffer in, CharBuffer out, CharsetDecoder decoder, boolean endOfInput) throws IOException {
/* 189 */     CoderResult result = decoder.decode(in, out, endOfInput);
/*     */ 
/* 191 */     out.flip();
/*     */ 
/* 193 */     writer.write(out.toString());
/* 194 */     return result;
/*     */   }
/*     */ 
/*     */   public int getSize() {
/* 198 */     return this.size + this.index;
/*     */   }
/*     */ 
/*     */   public byte[] toByteArray() {
/* 202 */     byte[] data = new byte[getSize()];
/* 203 */     int position = 0;
/* 204 */     if (this.buffers != null) {
/* 205 */       for (byte[] bytes : this.buffers) {
/* 206 */         System.arraycopy(bytes, 0, data, position, this.blockSize);
/* 207 */         position += this.blockSize;
/*     */       }
/*     */     }
/* 210 */     System.arraycopy(this.buffer, 0, data, position, this.index);
/* 211 */     return data;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 215 */     return new String(toByteArray());
/*     */   }
/*     */ 
/*     */   protected void addBuffer() {
/* 219 */     if (this.buffers == null) {
/* 220 */       this.buffers = new LinkedList();
/*     */     }
/* 222 */     this.buffers.addLast(this.buffer);
/* 223 */     this.buffer = new byte[this.blockSize];
/* 224 */     this.size += this.index;
/* 225 */     this.index = 0;
/*     */   }
/*     */ 
/*     */   public void write(int datum) throws IOException {
/* 229 */     if (this.closed) {
/* 230 */       throw new IOException("Stream closed");
/*     */     }
/* 232 */     if (this.index == this.blockSize) {
/* 233 */       addBuffer();
/*     */     }
/* 235 */     this.buffer[(this.index++)] = (byte)datum;
/*     */   }
/*     */ 
/*     */   public void write(byte[] data, int offset, int length) throws IOException {
/* 239 */     if (data == null) {
/* 240 */       throw new NullPointerException();
/*     */     }
/* 242 */     if ((offset < 0) || (offset + length > data.length) || (length < 0)) {
/* 243 */       throw new IndexOutOfBoundsException();
/*     */     }
/* 245 */     if (this.closed) {
/* 246 */       throw new IOException("Stream closed");
/*     */     }
/* 248 */     if (this.index + length > this.blockSize) {
/*     */       do {
/* 250 */         if (this.index == this.blockSize) {
/* 251 */           addBuffer();
/*     */         }
/* 253 */         int copyLength = this.blockSize - this.index;
/* 254 */         if (length < copyLength) {
/* 255 */           copyLength = length;
/*     */         }
/* 257 */         System.arraycopy(data, offset, this.buffer, this.index, copyLength);
/* 258 */         offset += copyLength;
/* 259 */         this.index += copyLength;
/* 260 */         length -= copyLength;
/* 261 */       }while (length > 0);
/*     */     } else {
/* 263 */       System.arraycopy(data, offset, this.buffer, this.index, length);
/* 264 */       this.index += length;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void close() {
/* 269 */     this.closed = true;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.util.FastByteArrayOutputStream
 * JD-Core Version:    0.6.0
 */