/*    */ package org.apache.struts2.util;
/*    */ 
/*    */ import java.util.Map;
/*    */ import java.util.regex.Pattern;
/*    */ 
/*    */ public class RegexPatternMatcherExpression
/*    */ {
/*    */   private final Pattern pattern;
/*    */   private final Map<Integer, String> params;
/*    */ 
/*    */   public RegexPatternMatcherExpression(Pattern pattern, Map<Integer, String> params)
/*    */   {
/* 38 */     this.pattern = pattern;
/* 39 */     this.params = params;
/*    */   }
/*    */ 
/*    */   public Pattern getPattern() {
/* 43 */     return this.pattern;
/*    */   }
/*    */ 
/*    */   public Map<Integer, String> getParams() {
/* 47 */     return this.params;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.util.RegexPatternMatcherExpression
 * JD-Core Version:    0.6.0
 */