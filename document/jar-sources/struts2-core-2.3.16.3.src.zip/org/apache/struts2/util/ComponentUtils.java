/*    */ package org.apache.struts2.util;
/*    */ 
/*    */ import com.opensymphony.xwork2.util.ValueStack;
/*    */ import org.apache.struts2.views.util.ContextUtil;
/*    */ 
/*    */ public class ComponentUtils
/*    */ {
/*    */   public static String stripExpressionIfAltSyntax(ValueStack stack, String expr)
/*    */   {
/* 20 */     if (altSyntax(stack))
/*    */     {
/* 22 */       if (isExpression(expr)) {
/* 23 */         return expr.substring(2, expr.length() - 1);
/*    */       }
/*    */     }
/* 26 */     return expr;
/*    */   }
/*    */ 
/*    */   public static boolean altSyntax(ValueStack stack)
/*    */   {
/* 37 */     return ContextUtil.isUseAltSyntax(stack.getContext());
/*    */   }
/*    */ 
/*    */   public static boolean isExpression(Object value)
/*    */   {
/* 47 */     String expr = value.toString();
/* 48 */     return (expr.startsWith("%{")) && (expr.endsWith("}"));
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.util.ComponentUtils
 * JD-Core Version:    0.6.0
 */