/*    */ package org.apache.struts2.util;
/*    */ 
/*    */ import java.lang.reflect.Array;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Arrays;
/*    */ import java.util.Enumeration;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class MakeIterator
/*    */ {
/*    */   public static boolean isIterable(Object object)
/*    */   {
/* 47 */     if (object == null) {
/* 48 */       return false;
/*    */     }
/*    */ 
/* 51 */     if ((object instanceof Map))
/* 52 */       return true;
/* 53 */     if ((object instanceof Iterable))
/* 54 */       return true;
/* 55 */     if (object.getClass().isArray())
/* 56 */       return true;
/* 57 */     if ((object instanceof Enumeration)) {
/* 58 */       return true;
/*    */     }
/* 60 */     return (object instanceof Iterator);
/*    */   }
/*    */ 
/*    */   public static Iterator convert(Object value)
/*    */   {
/* 69 */     if ((value instanceof Iterator)) {
/* 70 */       return (Iterator)value;
/*    */     }
/*    */ 
/* 73 */     if ((value instanceof Map)) {
/* 74 */       value = ((Map)value).entrySet();
/*    */     }
/*    */ 
/* 77 */     if (value == null)
/* 78 */       return null;
/*    */     Iterator iterator;
/*    */     Iterator iterator;
/* 81 */     if ((value instanceof Iterable)) {
/* 82 */       iterator = ((Iterable)value).iterator();
/*    */     }
/*    */     else
/*    */     {
/*    */       Iterator iterator;
/* 83 */       if (value.getClass().isArray())
/*    */       {
/* 86 */         ArrayList list = new ArrayList(Array.getLength(value));
/*    */ 
/* 88 */         for (int j = 0; j < Array.getLength(value); j++) {
/* 89 */           list.add(Array.get(value, j));
/*    */         }
/*    */ 
/* 92 */         iterator = list.iterator();
/*    */       }
/*    */       else
/*    */       {
/*    */         Iterator iterator;
/* 93 */         if ((value instanceof Enumeration))
/* 94 */           iterator = new IteratorFilterSupport.EnumerationIterator((Enumeration)value);
/*    */         else
/* 96 */           iterator = Arrays.asList(new Object[] { value }).iterator();
/*    */       }
/*    */     }
/* 99 */     return iterator;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.util.MakeIterator
 * JD-Core Version:    0.6.0
 */