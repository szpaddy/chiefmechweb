/*     */ package org.apache.struts2.util;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionContext;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.struts2.ServletActionContext;
/*     */ import org.apache.struts2.views.util.DefaultUrlHelper;
/*     */ import org.apache.struts2.views.util.UrlHelper;
/*     */ 
/*     */ public class URLBean
/*     */ {
/*     */   HashMap<String, String> params;
/*     */   HttpServletRequest request;
/*     */   HttpServletResponse response;
/*     */   String page;
/*     */   private UrlHelper urlHelper;
/*     */ 
/*     */   public URLBean setPage(String page)
/*     */   {
/*  48 */     this.page = page;
/*  49 */     return this;
/*     */   }
/*     */ 
/*     */   public void setRequest(HttpServletRequest request) {
/*  53 */     this.request = request;
/*  54 */     this.urlHelper = ((UrlHelper)ServletActionContext.getContext().getInstance(DefaultUrlHelper.class));
/*     */   }
/*     */ 
/*     */   public void setResponse(HttpServletResponse response) {
/*  58 */     this.response = response;
/*     */   }
/*     */ 
/*     */   public String getURL()
/*     */   {
/*  63 */     Map fullParams = null;
/*     */ 
/*  65 */     if (this.params != null) {
/*  66 */       fullParams = new HashMap();
/*     */     }
/*     */ 
/*  69 */     if (this.page == null)
/*     */     {
/*  72 */       if (fullParams != null)
/*  73 */         fullParams.putAll(this.request.getParameterMap());
/*     */       else {
/*  75 */         fullParams = this.request.getParameterMap();
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/*  80 */     if (this.params != null) {
/*  81 */       fullParams.putAll(this.params);
/*     */     }
/*     */ 
/*  84 */     return this.urlHelper.buildUrl(this.page, this.request, this.response, fullParams);
/*     */   }
/*     */ 
/*     */   public URLBean addParameter(String name, Object value) {
/*  88 */     if (this.params == null) {
/*  89 */       this.params = new HashMap();
/*     */     }
/*     */ 
/*  92 */     if (value == null)
/*  93 */       this.params.remove(name);
/*     */     else {
/*  95 */       this.params.put(name, value.toString());
/*     */     }
/*     */ 
/*  98 */     return this;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 102 */     return getURL();
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.util.URLBean
 * JD-Core Version:    0.6.0
 */