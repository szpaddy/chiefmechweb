/*     */ package org.apache.struts2.util;
/*     */ 
/*     */ import com.opensymphony.xwork2.TextProvider;
/*     */ import com.opensymphony.xwork2.util.CompoundRoot;
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import com.opensymphony.xwork2.util.logging.Logger;
/*     */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ public class TextProviderHelper
/*     */ {
/*  37 */   private static final Logger LOG = LoggerFactory.getLogger(TextProviderHelper.class);
/*     */ 
/*     */   public static String getText(String key, String defaultMessage, List<Object> args, ValueStack stack)
/*     */   {
/*  51 */     return getText(key, defaultMessage, args, stack, true);
/*     */   }
/*     */ 
/*     */   public static String getText(String key, String defaultMessage, List<Object> args, ValueStack stack, boolean searchStack)
/*     */   {
/*  69 */     String msg = null;
/*  70 */     TextProvider tp = null;
/*     */ 
/*  72 */     for (Iterator i$ = stack.getRoot().iterator(); i$.hasNext(); ) { Object o = i$.next();
/*  73 */       if ((o instanceof TextProvider)) {
/*  74 */         tp = (TextProvider)o;
/*  75 */         msg = tp.getText(key, null, args, stack);
/*     */ 
/*  77 */         break;
/*     */       }
/*     */     }
/*     */ 
/*  81 */     if (msg == null)
/*     */     {
/*  83 */       if (searchStack) {
/*  84 */         msg = stack.findString(defaultMessage);
/*     */       }
/*  86 */       if (msg == null)
/*     */       {
/*  88 */         msg = defaultMessage;
/*     */       }
/*     */ 
/*  91 */       if (LOG.isWarnEnabled()) {
/*  92 */         if (tp != null)
/*  93 */           LOG.warn("The first TextProvider in the ValueStack (" + tp.getClass().getName() + ") could not locate the message resource with key '" + key + "'", new String[0]);
/*     */         else {
/*  95 */           LOG.warn("Could not locate the message resource '" + key + "' as there is no TextProvider in the ValueStack.", new String[0]);
/*     */         }
/*  97 */         if (defaultMessage.equals(msg))
/*  98 */           LOG.warn("The default value expression '" + defaultMessage + "' was evaluated and did not match a property.  The literal value '" + defaultMessage + "' will be used.", new String[0]);
/*     */         else {
/* 100 */           LOG.warn("The default value expression '" + defaultMessage + "' evaluated to '" + msg + "'", new String[0]);
/*     */         }
/*     */       }
/*     */     }
/* 104 */     return msg;
/*     */   }
/*     */ 
/*     */   public static String getText(String key, String defaultMessage, ValueStack stack)
/*     */   {
/* 120 */     return getText(key, defaultMessage, Collections.emptyList(), stack);
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.util.TextProviderHelper
 * JD-Core Version:    0.6.0
 */