/*     */ package org.apache.struts2.util;
/*     */ 
/*     */ import com.opensymphony.xwork2.Action;
/*     */ import com.opensymphony.xwork2.util.logging.Logger;
/*     */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ public class SortIteratorFilter extends IteratorFilterSupport
/*     */   implements Iterator, Action
/*     */ {
/*     */   Comparator comparator;
/*     */   Iterator iterator;
/*     */   List list;
/*     */   Object source;
/*     */ 
/*     */   public void setComparator(Comparator aComparator)
/*     */   {
/*  51 */     this.comparator = aComparator;
/*     */   }
/*     */ 
/*     */   public List getList() {
/*  55 */     return this.list;
/*     */   }
/*     */ 
/*     */   public void setSource(Object anIterator)
/*     */   {
/*  60 */     this.source = anIterator;
/*     */   }
/*     */ 
/*     */   public String execute()
/*     */   {
/*  65 */     if (this.source == null)
/*  66 */       return "error";
/*     */     try
/*     */     {
/*  69 */       if (!MakeIterator.isIterable(this.source)) {
/*  70 */         LoggerFactory.getLogger(SortIteratorFilter.class.getName()).warn("Cannot create SortIterator for source " + this.source, new String[0]);
/*     */ 
/*  72 */         return "error";
/*     */       }
/*     */ 
/*  75 */       this.list = new ArrayList();
/*     */ 
/*  77 */       Iterator i = MakeIterator.convert(this.source);
/*     */ 
/*  79 */       while (i.hasNext()) {
/*  80 */         this.list.add(i.next());
/*     */       }
/*     */ 
/*  84 */       Collections.sort(this.list, this.comparator);
/*  85 */       this.iterator = this.list.iterator();
/*     */ 
/*  87 */       return "success";
/*     */     } catch (Exception e) {
/*  89 */       LoggerFactory.getLogger(SortIteratorFilter.class.getName()).warn("Error creating sort iterator.", e, new String[0]);
/*     */     }
/*  91 */     return "error";
/*     */   }
/*     */ 
/*     */   public boolean hasNext()
/*     */   {
/*  98 */     return this.source == null ? false : this.iterator.hasNext();
/*     */   }
/*     */ 
/*     */   public Object next() {
/* 102 */     return this.iterator.next();
/*     */   }
/*     */ 
/*     */   public void remove() {
/* 106 */     throw new UnsupportedOperationException("Remove is not supported in SortIteratorFilter.");
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.util.SortIteratorFilter
 * JD-Core Version:    0.6.0
 */