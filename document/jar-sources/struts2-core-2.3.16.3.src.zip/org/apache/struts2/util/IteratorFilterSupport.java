/*    */ package org.apache.struts2.util;
/*    */ 
/*    */ import java.util.Enumeration;
/*    */ import java.util.Iterator;
/*    */ 
/*    */ public abstract class IteratorFilterSupport
/*    */ {
/*    */   protected Object getIterator(Object source)
/*    */   {
/* 36 */     return MakeIterator.convert(source);
/*    */   }
/*    */ 
/*    */   public static class EnumerationIterator implements Iterator
/*    */   {
/*    */     Enumeration enumeration;
/*    */ 
/*    */     public EnumerationIterator(Enumeration aEnum) {
/* 45 */       this.enumeration = aEnum;
/*    */     }
/*    */ 
/*    */     public boolean hasNext() {
/* 49 */       return this.enumeration.hasMoreElements();
/*    */     }
/*    */ 
/*    */     public Object next() {
/* 53 */       return this.enumeration.nextElement();
/*    */     }
/*    */ 
/*    */     public void remove() {
/* 57 */       throw new UnsupportedOperationException("Remove is not supported in IteratorFilterSupport.");
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.util.IteratorFilterSupport
 * JD-Core Version:    0.6.0
 */