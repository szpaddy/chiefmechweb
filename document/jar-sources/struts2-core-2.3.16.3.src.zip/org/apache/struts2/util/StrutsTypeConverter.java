/*    */ package org.apache.struts2.util;
/*    */ 
/*    */ import com.opensymphony.xwork2.conversion.impl.DefaultTypeConverter;
/*    */ import java.util.Map;
/*    */ 
/*    */ public abstract class StrutsTypeConverter extends DefaultTypeConverter
/*    */ {
/*    */   public Object convertValue(Map context, Object o, Class toClass)
/*    */   {
/* 49 */     if (toClass.equals(String.class))
/* 50 */       return convertToString(context, o);
/* 51 */     if ((o instanceof String[]))
/* 52 */       return convertFromString(context, (String[])(String[])o, toClass);
/* 53 */     if ((o instanceof String)) {
/* 54 */       return convertFromString(context, new String[] { (String)o }, toClass);
/*    */     }
/* 56 */     return performFallbackConversion(context, o, toClass);
/*    */   }
/*    */ 
/*    */   protected Object performFallbackConversion(Map context, Object o, Class toClass)
/*    */   {
/* 71 */     return super.convertValue(context, o, toClass);
/*    */   }
/*    */ 
/*    */   public abstract Object convertFromString(Map paramMap, String[] paramArrayOfString, Class paramClass);
/*    */ 
/*    */   public abstract String convertToString(Map paramMap, Object paramObject);
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.util.StrutsTypeConverter
 * JD-Core Version:    0.6.0
 */