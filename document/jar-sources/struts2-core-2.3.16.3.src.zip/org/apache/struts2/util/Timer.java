/*    */ package org.apache.struts2.util;
/*    */ 
/*    */ public class Timer
/*    */ {
/* 32 */   long current = System.currentTimeMillis();
/* 33 */   long start = this.current;
/*    */ 
/*    */   public long getTime()
/*    */   {
/* 39 */     long now = System.currentTimeMillis();
/* 40 */     long time = now - this.current;
/*    */ 
/* 43 */     this.current = now;
/*    */ 
/* 45 */     return time;
/*    */   }
/*    */ 
/*    */   public long getTotal()
/*    */   {
/* 50 */     return System.currentTimeMillis() - this.start;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.util.Timer
 * JD-Core Version:    0.6.0
 */