/*    */ package org.apache.struts2.util;
/*    */ 
/*    */ import com.opensymphony.xwork2.Action;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ 
/*    */ public class AppendIteratorFilter extends IteratorFilterSupport
/*    */   implements Iterator, Action
/*    */ {
/* 39 */   List iterators = new ArrayList();
/*    */ 
/* 42 */   List sources = new ArrayList();
/*    */ 
/*    */   public void setSource(Object anIterator)
/*    */   {
/* 47 */     this.sources.add(anIterator);
/*    */   }
/*    */ 
/*    */   public String execute()
/*    */   {
/* 53 */     for (int i = 0; i < this.sources.size(); i++) {
/* 54 */       Object source = this.sources.get(i);
/* 55 */       this.iterators.add(getIterator(source));
/*    */     }
/*    */ 
/* 58 */     return "success";
/*    */   }
/*    */ 
/*    */   public boolean hasNext()
/*    */   {
/* 63 */     if (this.iterators.size() > 0) {
/* 64 */       return ((Action)this.iterators.get(0)).hasNext();
/*    */     }
/* 66 */     return false;
/*    */   }
/*    */ 
/*    */   public Object next()
/*    */   {
/*    */     try {
/* 72 */       Object localObject1 = ((Action)this.iterators.get(0)).next();
/*    */       return localObject1;
/*    */     }
/*    */     finally
/*    */     {
/* 74 */       if ((this.iterators.size() > 0) && 
/* 75 */         (!((Action)this.iterators.get(0)).hasNext()))
/* 76 */         this.iterators.remove(0); 
/* 76 */     }throw localObject2;
/*    */   }
/*    */ 
/*    */   public void remove()
/*    */   {
/* 83 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.util.AppendIteratorFilter
 * JD-Core Version:    0.6.0
 */