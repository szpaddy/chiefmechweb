/*    */ package org.apache.struts2.util;
/*    */ 
/*    */ public class PrefixTrie
/*    */ {
/*    */   private static final int SIZE = 128;
/*    */   Node root;
/*    */ 
/*    */   public PrefixTrie()
/*    */   {
/* 33 */     this.root = new Node();
/*    */   }
/*    */   public void put(String prefix, Object value) {
/* 36 */     Node current = this.root;
/* 37 */     for (int i = 0; i < prefix.length(); i++) {
/* 38 */       char c = prefix.charAt(i);
/* 39 */       if (c > '')
/* 40 */         throw new IllegalArgumentException("'" + c + "' is too big.");
/* 41 */       if (current.next[c] == null)
/* 42 */         current.next[c] = new Node();
/* 43 */       current = current.next[c];
/*    */     }
/* 45 */     current.value = value;
/*    */   }
/*    */ 
/*    */   public Object get(String key) {
/* 49 */     Node current = this.root;
/* 50 */     for (int i = 0; i < key.length(); i++) {
/* 51 */       char c = key.charAt(i);
/* 52 */       if (c > '')
/* 53 */         return null;
/* 54 */       current = current.next[c];
/* 55 */       if (current == null)
/* 56 */         return null;
/* 57 */       if (current.value != null)
/* 58 */         return current.value;
/*    */     }
/* 60 */     return null;
/*    */   }
/*    */ 
/*    */   static class Node
/*    */   {
/*    */     Object value;
/* 65 */     Node[] next = new Node[''];
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.util.PrefixTrie
 * JD-Core Version:    0.6.0
 */