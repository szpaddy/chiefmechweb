/*     */ package org.apache.struts2.util;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionContext;
/*     */ import com.opensymphony.xwork2.util.LocalizedTextUtil;
/*     */ import com.opensymphony.xwork2.util.logging.Logger;
/*     */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*     */ import java.math.BigInteger;
/*     */ import java.util.Map;
/*     */ import java.util.Random;
/*     */ 
/*     */ public class TokenHelper
/*     */ {
/*     */   public static final String TOKEN_NAMESPACE = "struts.tokens";
/*     */   public static final String DEFAULT_TOKEN_NAME = "token";
/*     */   public static final String TOKEN_NAME_FIELD = "struts.token.name";
/*  53 */   private static final Logger LOG = LoggerFactory.getLogger(TokenHelper.class);
/*  54 */   private static final Random RANDOM = new Random();
/*     */ 
/*     */   public static String setToken()
/*     */   {
/*  63 */     return setToken("token");
/*     */   }
/*     */ 
/*     */   public static String setToken(String tokenName)
/*     */   {
/*  75 */     String token = generateGUID();
/*  76 */     setSessionToken(tokenName, token);
/*  77 */     return token;
/*     */   }
/*     */ 
/*     */   public static void setSessionToken(String tokenName, String token)
/*     */   {
/*  88 */     Map session = ActionContext.getContext().getSession();
/*     */     try {
/*  90 */       session.put(buildTokenSessionAttributeName(tokenName), token);
/*     */     }
/*     */     catch (IllegalStateException e) {
/*  93 */       String msg = "Error creating HttpSession due response is commited to client. You can use the CreateSessionInterceptor or create the HttpSession from your action before the result is rendered to the client: " + e.getMessage();
/*  94 */       if (LOG.isErrorEnabled()) {
/*  95 */         LOG.error(msg, e, new String[0]);
/*     */       }
/*  97 */       throw new IllegalArgumentException(msg);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static String buildTokenSessionAttributeName(String tokenName)
/*     */   {
/* 110 */     return "struts.tokens." + tokenName;
/*     */   }
/*     */ 
/*     */   public static String getToken()
/*     */   {
/* 119 */     return getToken("token");
/*     */   }
/*     */ 
/*     */   public static String getToken(String tokenName)
/*     */   {
/* 129 */     if (tokenName == null) {
/* 130 */       return null;
/*     */     }
/* 132 */     Map params = ActionContext.getContext().getParameters();
/* 133 */     String[] tokens = (String[])(String[])params.get(tokenName);
/*     */ 
/* 136 */     if ((tokens == null) || (tokens.length < 1)) {
/* 137 */       if (LOG.isWarnEnabled()) {
/* 138 */         LOG.warn("Could not find token mapped to token name " + tokenName, new String[0]);
/*     */       }
/*     */ 
/* 141 */       return null;
/*     */     }
/*     */ 
/* 144 */     String token = tokens[0];
/*     */ 
/* 146 */     return token;
/*     */   }
/*     */ 
/*     */   public static String getTokenName()
/*     */   {
/* 155 */     Map params = ActionContext.getContext().getParameters();
/*     */ 
/* 157 */     if (!params.containsKey("struts.token.name")) {
/* 158 */       if (LOG.isWarnEnabled()) {
/* 159 */         LOG.warn("Could not find token name in params.", new String[0]);
/*     */       }
/*     */ 
/* 162 */       return null;
/*     */     }
/*     */ 
/* 165 */     String[] tokenNames = (String[])(String[])params.get("struts.token.name");
/*     */ 
/* 168 */     if ((tokenNames == null) || (tokenNames.length < 1)) {
/* 169 */       if (LOG.isWarnEnabled()) {
/* 170 */         LOG.warn("Got a null or empty token name.", new String[0]);
/*     */       }
/*     */ 
/* 173 */       return null;
/*     */     }
/*     */ 
/* 176 */     String tokenName = tokenNames[0];
/*     */ 
/* 178 */     return tokenName;
/*     */   }
/*     */ 
/*     */   public static boolean validToken()
/*     */   {
/* 188 */     String tokenName = getTokenName();
/*     */ 
/* 190 */     if (tokenName == null) {
/* 191 */       if (LOG.isDebugEnabled()) {
/* 192 */         LOG.debug("no token name found -> Invalid token ", new String[0]);
/*     */       }
/* 194 */       return false;
/*     */     }
/*     */ 
/* 197 */     String token = getToken(tokenName);
/*     */ 
/* 199 */     if (token == null) {
/* 200 */       if (LOG.isDebugEnabled()) {
/* 201 */         LOG.debug("no token found for token name " + tokenName + " -> Invalid token ", new String[0]);
/*     */       }
/* 203 */       return false;
/*     */     }
/*     */ 
/* 206 */     Map session = ActionContext.getContext().getSession();
/* 207 */     String tokenSessionName = buildTokenSessionAttributeName(tokenName);
/* 208 */     String sessionToken = (String)session.get(tokenSessionName);
/*     */ 
/* 210 */     if (!token.equals(sessionToken)) {
/* 211 */       if (LOG.isWarnEnabled()) {
/* 212 */         LOG.warn(LocalizedTextUtil.findText(TokenHelper.class, "struts.internal.invalid.token", ActionContext.getContext().getLocale(), "Form token {0} does not match the session token {1}.", new Object[] { token, sessionToken }), new String[0]);
/*     */       }
/*     */ 
/* 217 */       return false;
/*     */     }
/*     */ 
/* 221 */     session.remove(tokenSessionName);
/*     */ 
/* 223 */     return true;
/*     */   }
/*     */ 
/*     */   public static String generateGUID() {
/* 227 */     return new BigInteger(165, RANDOM).toString(36).toUpperCase();
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.util.TokenHelper
 * JD-Core Version:    0.6.0
 */