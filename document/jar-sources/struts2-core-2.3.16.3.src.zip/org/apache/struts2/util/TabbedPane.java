/*    */ package org.apache.struts2.util;
/*    */ 
/*    */ import java.util.Vector;
/*    */ 
/*    */ public class TabbedPane
/*    */ {
/* 33 */   protected String tabAlign = null;
/*    */ 
/* 36 */   protected Vector content = null;
/* 37 */   protected int selectedIndex = 0;
/*    */ 
/*    */   public TabbedPane(int defaultIndex)
/*    */   {
/* 42 */     this.selectedIndex = defaultIndex;
/*    */   }
/*    */ 
/*    */   public void setContent(Vector content)
/*    */   {
/* 47 */     this.content = content;
/*    */   }
/*    */ 
/*    */   public Vector getContent() {
/* 51 */     return this.content;
/*    */   }
/*    */ 
/*    */   public void setSelectedIndex(int selectedIndex) {
/* 55 */     this.selectedIndex = selectedIndex;
/*    */   }
/*    */ 
/*    */   public int getSelectedIndex() {
/* 59 */     return this.selectedIndex;
/*    */   }
/*    */ 
/*    */   public void setTabAlign(String tabAlign) {
/* 63 */     this.tabAlign = tabAlign;
/*    */   }
/*    */ 
/*    */   public String getTabAlign() {
/* 67 */     return this.tabAlign;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.util.TabbedPane
 * JD-Core Version:    0.6.0
 */