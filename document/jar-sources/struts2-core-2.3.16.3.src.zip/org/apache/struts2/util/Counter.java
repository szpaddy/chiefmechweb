/*     */ package org.apache.struts2.util;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ public class Counter
/*     */   implements Iterator, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 2796965884308060179L;
/*  37 */   boolean wrap = false;
/*     */ 
/*  40 */   long first = 1L;
/*  41 */   long current = this.first;
/*  42 */   long interval = 1L;
/*  43 */   long last = -1L;
/*     */ 
/*     */   public void setAdd(long addition)
/*     */   {
/*  47 */     this.current += addition;
/*     */   }
/*     */ 
/*     */   public void setCurrent(long current) {
/*  51 */     this.current = current;
/*     */   }
/*     */ 
/*     */   public long getCurrent() {
/*  55 */     return this.current;
/*     */   }
/*     */ 
/*     */   public void setFirst(long first) {
/*  59 */     this.first = first;
/*  60 */     this.current = first;
/*     */   }
/*     */ 
/*     */   public long getFirst() {
/*  64 */     return this.first;
/*     */   }
/*     */ 
/*     */   public void setInterval(long interval) {
/*  68 */     this.interval = interval;
/*     */   }
/*     */ 
/*     */   public long getInterval() {
/*  72 */     return this.interval;
/*     */   }
/*     */ 
/*     */   public void setLast(long last) {
/*  76 */     this.last = last;
/*     */   }
/*     */ 
/*     */   public long getLast() {
/*  80 */     return this.last;
/*     */   }
/*     */ 
/*     */   public long getNext()
/*     */   {
/*  85 */     long next = this.current;
/*  86 */     this.current += this.interval;
/*     */ 
/*  88 */     if ((this.wrap) && (this.current > this.last)) {
/*  89 */       this.current -= 1L + this.last - this.first;
/*     */     }
/*     */ 
/*  92 */     return next;
/*     */   }
/*     */ 
/*     */   public long getPrevious() {
/*  96 */     this.current -= this.interval;
/*     */ 
/*  98 */     if ((this.wrap) && (this.current < this.first)) {
/*  99 */       this.current += this.last - this.first + 1L;
/*     */     }
/*     */ 
/* 102 */     return this.current;
/*     */   }
/*     */ 
/*     */   public void setWrap(boolean wrap) {
/* 106 */     this.wrap = wrap;
/*     */   }
/*     */ 
/*     */   public boolean isWrap() {
/* 110 */     return this.wrap;
/*     */   }
/*     */ 
/*     */   public boolean hasNext() {
/* 114 */     return (this.last == -1L) || (this.wrap);
/*     */   }
/*     */ 
/*     */   public Object next() {
/* 118 */     return Long.valueOf(getNext());
/*     */   }
/*     */ 
/*     */   public void remove()
/*     */   {
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.util.Counter
 * JD-Core Version:    0.6.0
 */