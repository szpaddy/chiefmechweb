/*     */ package org.apache.struts2.util;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionContext;
/*     */ import com.opensymphony.xwork2.ActionInvocation;
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import java.io.Serializable;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class InvocationSessionStore
/*     */ {
/*     */   private static final String INVOCATION_MAP_KEY = "org.apache.struts2.util.InvocationSessionStore.invocationMap";
/*     */ 
/*     */   public static ActionInvocation loadInvocation(String key, String token)
/*     */   {
/*  56 */     InvocationContext invocationContext = (InvocationContext)getInvocationMap().get(key);
/*     */ 
/*  58 */     if ((invocationContext == null) || (!invocationContext.token.equals(token))) {
/*  59 */       return null;
/*     */     }
/*     */ 
/*  62 */     ValueStack stack = invocationContext.invocation.getStack();
/*  63 */     ActionContext.getContext().setValueStack(stack);
/*     */ 
/*  65 */     return invocationContext.invocation.deserialize(ActionContext.getContext());
/*     */   }
/*     */ 
/*     */   public static void storeInvocation(String key, String token, ActionInvocation invocation)
/*     */   {
/*  76 */     InvocationContext invocationContext = new InvocationContext(invocation.serialize(), token);
/*  77 */     Map invocationMap = getInvocationMap();
/*  78 */     invocationMap.put(key, invocationContext);
/*  79 */     setInvocationMap(invocationMap);
/*     */   }
/*     */ 
/*     */   static void setInvocationMap(Map invocationMap) {
/*  83 */     Map session = ActionContext.getContext().getSession();
/*     */ 
/*  85 */     if (session == null) {
/*  86 */       throw new IllegalStateException("Unable to access the session.");
/*     */     }
/*     */ 
/*  89 */     session.put("org.apache.struts2.util.InvocationSessionStore.invocationMap", invocationMap);
/*     */   }
/*     */ 
/*     */   static Map getInvocationMap() {
/*  93 */     Map session = ActionContext.getContext().getSession();
/*     */ 
/*  95 */     if (session == null) {
/*  96 */       throw new IllegalStateException("Unable to access the session.");
/*     */     }
/*     */ 
/*  99 */     Map invocationMap = (Map)session.get("org.apache.struts2.util.InvocationSessionStore.invocationMap");
/*     */ 
/* 101 */     if (invocationMap == null) {
/* 102 */       invocationMap = new HashMap();
/* 103 */       setInvocationMap(invocationMap);
/*     */     }
/*     */ 
/* 106 */     return invocationMap;
/*     */   }
/*     */ 
/*     */   private static class InvocationContext implements Serializable {
/*     */     private static final long serialVersionUID = -286697666275777888L;
/*     */     ActionInvocation invocation;
/*     */     String token;
/*     */ 
/*     */     public InvocationContext(ActionInvocation invocation, String token) {
/* 118 */       this.invocation = invocation;
/* 119 */       this.token = token;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.util.InvocationSessionStore
 * JD-Core Version:    0.6.0
 */