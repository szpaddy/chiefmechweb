/*     */ package org.apache.struts2.util;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.servlet.jsp.PageContext;
/*     */ 
/*     */ public class AttributeMap
/*     */   implements Map
/*     */ {
/*     */   protected static final String UNSUPPORTED = "method makes no sense for a simplified map";
/*     */   Map context;
/*     */ 
/*     */   public AttributeMap(Map context)
/*     */   {
/*  53 */     this.context = context;
/*     */   }
/*     */ 
/*     */   public boolean isEmpty() {
/*  57 */     throw new UnsupportedOperationException("method makes no sense for a simplified map");
/*     */   }
/*     */ 
/*     */   public void clear() {
/*  61 */     throw new UnsupportedOperationException("method makes no sense for a simplified map");
/*     */   }
/*     */ 
/*     */   public boolean containsKey(Object key) {
/*  65 */     return get(key) != null;
/*     */   }
/*     */ 
/*     */   public boolean containsValue(Object value) {
/*  69 */     throw new UnsupportedOperationException("method makes no sense for a simplified map");
/*     */   }
/*     */ 
/*     */   public Set entrySet() {
/*  73 */     return Collections.EMPTY_SET;
/*     */   }
/*     */ 
/*     */   public Object get(Object key) {
/*  77 */     PageContext pc = getPageContext();
/*     */ 
/*  79 */     if (pc == null) {
/*  80 */       Map request = (Map)this.context.get("request");
/*  81 */       Map session = (Map)this.context.get("session");
/*  82 */       Map application = (Map)this.context.get("application");
/*     */ 
/*  84 */       if ((request != null) && (request.get(key) != null))
/*  85 */         return request.get(key);
/*  86 */       if ((session != null) && (session.get(key) != null))
/*  87 */         return session.get(key);
/*  88 */       if ((application != null) && (application.get(key) != null))
/*  89 */         return application.get(key);
/*     */     }
/*     */     else {
/*     */       try {
/*  93 */         return pc.findAttribute(key.toString());
/*     */       } catch (NullPointerException npe) {
/*  95 */         return null;
/*     */       }
/*     */     }
/*     */ 
/*  99 */     return null;
/*     */   }
/*     */ 
/*     */   public Set keySet() {
/* 103 */     return Collections.EMPTY_SET;
/*     */   }
/*     */ 
/*     */   public Object put(Object key, Object value) {
/* 107 */     PageContext pc = getPageContext();
/* 108 */     if (pc != null) {
/* 109 */       pc.setAttribute(key.toString(), value);
/*     */     }
/*     */ 
/* 112 */     return null;
/*     */   }
/*     */ 
/*     */   public void putAll(Map t) {
/* 116 */     throw new UnsupportedOperationException("method makes no sense for a simplified map");
/*     */   }
/*     */ 
/*     */   public Object remove(Object key) {
/* 120 */     throw new UnsupportedOperationException("method makes no sense for a simplified map");
/*     */   }
/*     */ 
/*     */   public int size() {
/* 124 */     throw new UnsupportedOperationException("method makes no sense for a simplified map");
/*     */   }
/*     */ 
/*     */   public Collection values() {
/* 128 */     return Collections.EMPTY_SET;
/*     */   }
/*     */ 
/*     */   private PageContext getPageContext() {
/* 132 */     return (PageContext)this.context.get("com.opensymphony.xwork2.dispatcher.PageContext");
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 137 */     return "AttributeMap {request=" + toStringSafe(this.context.get("request")) + ", session=" + toStringSafe(this.context.get("session")) + ", application=" + toStringSafe(this.context.get("application")) + '}';
/*     */   }
/*     */ 
/*     */   private String toStringSafe(Object obj)
/*     */   {
/*     */     try
/*     */     {
/* 146 */       if (obj != null) {
/* 147 */         return String.valueOf(obj);
/*     */       }
/* 149 */       return ""; } catch (Exception e) {
/*     */     }
/* 151 */     return "Exception thrown: " + e;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.util.AttributeMap
 * JD-Core Version:    0.6.0
 */