/*     */ package org.apache.struts2.util;
/*     */ 
/*     */ import com.opensymphony.xwork2.Action;
/*     */ import com.opensymphony.xwork2.util.logging.Logger;
/*     */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.StringTokenizer;
/*     */ 
/*     */ public class IteratorGenerator
/*     */   implements Iterator, Action
/*     */ {
/*  41 */   private static final Logger LOG = LoggerFactory.getLogger(IteratorGenerator.class);
/*     */   List values;
/*     */   Object value;
/*     */   String separator;
/*     */   Converter converter;
/*     */   int count;
/*     */   int currentCount;
/*     */ 
/*     */   public IteratorGenerator()
/*     */   {
/*  49 */     this.count = 0;
/*  50 */     this.currentCount = 0;
/*     */   }
/*     */ 
/*     */   public void setCount(int aCount) {
/*  54 */     this.count = aCount;
/*     */   }
/*     */ 
/*     */   public boolean getHasNext() {
/*  58 */     return hasNext();
/*     */   }
/*     */ 
/*     */   public Object getNext() {
/*  62 */     return next();
/*     */   }
/*     */ 
/*     */   public void setSeparator(String aChar) {
/*  66 */     this.separator = aChar;
/*     */   }
/*     */ 
/*     */   public void setConverter(Converter aConverter) {
/*  70 */     this.converter = aConverter;
/*     */   }
/*     */ 
/*     */   public void setValues(Object aValue)
/*     */   {
/*  75 */     this.value = aValue;
/*     */   }
/*     */ 
/*     */   public String execute()
/*     */   {
/*  80 */     if (this.value == null) {
/*  81 */       return "error";
/*     */     }
/*  83 */     this.values = new ArrayList();
/*     */ 
/*  85 */     if (this.separator != null) {
/*  86 */       StringTokenizer tokens = new StringTokenizer(this.value.toString(), this.separator);
/*     */ 
/*  88 */       while (tokens.hasMoreTokens()) {
/*  89 */         String token = tokens.nextToken().trim();
/*  90 */         if (this.converter != null) {
/*     */           try {
/*  92 */             Object convertedObj = this.converter.convert(token);
/*  93 */             this.values.add(convertedObj);
/*     */           }
/*     */           catch (Exception e) {
/*  96 */             if (LOG.isWarnEnabled()) {
/*  97 */               LOG.warn("unable to convert [" + token + "], skipping this token, it will not appear in the generated iterator", e, new String[0]);
/*     */             }
/*     */           }
/*     */         }
/*     */         else
/* 102 */           this.values.add(token);
/*     */       }
/*     */     }
/*     */     else {
/* 106 */       this.values.add(this.value.toString());
/*     */     }
/*     */ 
/* 110 */     if (this.count == 0) {
/* 111 */       this.count = this.values.size();
/*     */     }
/*     */ 
/* 114 */     return "success";
/*     */   }
/*     */ 
/*     */   public boolean hasNext()
/*     */   {
/* 120 */     return this.value != null;
/*     */   }
/*     */ 
/*     */   public Object next() {
/*     */     try {
/* 125 */       Object localObject1 = this.values.get(this.currentCount % this.values.size());
/*     */       return localObject1; } finally { this.currentCount += 1; } throw localObject2;
/*     */   }
/*     */ 
/*     */   public void remove()
/*     */   {
/* 132 */     throw new UnsupportedOperationException("Remove is not supported in IteratorGenerator.");
/*     */   }
/*     */ 
/*     */   public static abstract interface Converter
/*     */   {
/*     */     public abstract Object convert(String paramString)
/*     */       throws Exception;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.util.IteratorGenerator
 * JD-Core Version:    0.6.0
 */