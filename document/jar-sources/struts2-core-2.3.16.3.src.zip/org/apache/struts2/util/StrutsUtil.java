/*     */ package org.apache.struts2.util;
/*     */ 
/*     */ import com.opensymphony.xwork2.ObjectFactory;
/*     */ import com.opensymphony.xwork2.inject.Container;
/*     */ import com.opensymphony.xwork2.util.ClassLoaderUtil;
/*     */ import com.opensymphony.xwork2.util.TextParseUtil;
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import com.opensymphony.xwork2.util.logging.Logger;
/*     */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.StringWriter;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.net.URLEncoder;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.servlet.RequestDispatcher;
/*     */ import javax.servlet.ServletOutputStream;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.servlet.http.HttpServletResponseWrapper;
/*     */ import org.apache.struts2.views.jsp.ui.OgnlTool;
/*     */ import org.apache.struts2.views.util.UrlHelper;
/*     */ 
/*     */ public class StrutsUtil
/*     */ {
/*  57 */   protected static final Logger LOG = LoggerFactory.getLogger(StrutsUtil.class);
/*     */   protected HttpServletRequest request;
/*     */   protected HttpServletResponse response;
/*  61 */   protected Map<String, Class> classes = new Hashtable();
/*     */   protected OgnlTool ognl;
/*     */   protected ValueStack stack;
/*     */   private UrlHelper urlHelper;
/*     */   private ObjectFactory objectFactory;
/*     */ 
/*     */   public StrutsUtil(ValueStack stack, HttpServletRequest request, HttpServletResponse response)
/*     */   {
/*  69 */     this.stack = stack;
/*  70 */     this.request = request;
/*  71 */     this.response = response;
/*  72 */     this.ognl = ((OgnlTool)((Container)stack.getContext().get("com.opensymphony.xwork2.ActionContext.container")).getInstance(OgnlTool.class));
/*  73 */     this.urlHelper = ((UrlHelper)((Container)stack.getContext().get("com.opensymphony.xwork2.ActionContext.container")).getInstance(UrlHelper.class));
/*  74 */     this.objectFactory = ((ObjectFactory)((Container)stack.getContext().get("com.opensymphony.xwork2.ActionContext.container")).getInstance(ObjectFactory.class));
/*     */   }
/*     */ 
/*     */   public Object bean(Object aName) throws Exception {
/*  78 */     String name = aName.toString();
/*  79 */     Class c = (Class)this.classes.get(name);
/*     */ 
/*  81 */     if (c == null) {
/*  82 */       c = ClassLoaderUtil.loadClass(name, StrutsUtil.class);
/*  83 */       this.classes.put(name, c);
/*     */     }
/*     */ 
/*  86 */     return this.objectFactory.buildBean(c, this.stack.getContext());
/*     */   }
/*     */ 
/*     */   public boolean isTrue(String expression) {
/*  90 */     Boolean retVal = (Boolean)this.stack.findValue(expression, Boolean.class);
/*  91 */     return (retVal != null) && (retVal.booleanValue());
/*     */   }
/*     */ 
/*     */   public Object findString(String name) {
/*  95 */     return this.stack.findValue(name, String.class);
/*     */   }
/*     */ 
/*     */   public String include(Object aName) throws Exception {
/*  99 */     return include(aName, this.request, this.response);
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public String include(Object aName, HttpServletRequest aRequest, HttpServletResponse aResponse) throws Exception
/*     */   {
/*     */     try {
/* 107 */       RequestDispatcher dispatcher = aRequest.getRequestDispatcher(aName.toString());
/*     */ 
/* 109 */       if (dispatcher == null) {
/* 110 */         throw new IllegalArgumentException("Cannot find included file " + aName);
/*     */       }
/*     */ 
/* 113 */       ResponseWrapper responseWrapper = new ResponseWrapper(aResponse);
/*     */ 
/* 115 */       dispatcher.include(aRequest, responseWrapper);
/*     */ 
/* 117 */       return responseWrapper.getData();
/*     */     }
/*     */     catch (Exception e) {
/* 120 */       if (LOG.isDebugEnabled())
/* 121 */         LOG.debug("Cannot include #0", e, new String[] { aName.toString() });
/*     */     }
/* 123 */     throw e;
/*     */   }
/*     */ 
/*     */   public String urlEncode(String s)
/*     */   {
/*     */     try {
/* 129 */       return URLEncoder.encode(s, "UTF-8");
/*     */     } catch (UnsupportedEncodingException e) {
/* 131 */       if (LOG.isDebugEnabled())
/* 132 */         LOG.debug("Cannot encode URL [#0]", e, new String[] { s });
/*     */     }
/* 134 */     return s;
/*     */   }
/*     */ 
/*     */   public String buildUrl(String url)
/*     */   {
/* 139 */     return this.urlHelper.buildUrl(url, this.request, this.response, null);
/*     */   }
/*     */ 
/*     */   public Object findValue(String expression, String className) throws ClassNotFoundException {
/* 143 */     return this.stack.findValue(expression, Class.forName(className));
/*     */   }
/*     */ 
/*     */   public String getText(String text) {
/* 147 */     return (String)this.stack.findValue("getText('" + text + "')");
/*     */   }
/*     */ 
/*     */   public String getContext()
/*     */   {
/* 154 */     return this.request == null ? "" : this.request.getContextPath();
/*     */   }
/*     */ 
/*     */   public String translateVariables(String expression) {
/* 158 */     return TextParseUtil.translateVariables(expression, this.stack);
/*     */   }
/*     */ 
/*     */   public List makeSelectList(String selectedList, String list, String listKey, String listValue)
/*     */   {
/* 178 */     List selectList = new ArrayList();
/*     */ 
/* 180 */     Collection selectedItems = null;
/*     */ 
/* 182 */     Object i = this.stack.findValue(selectedList);
/*     */ 
/* 184 */     if (i != null) {
/* 185 */       if (i.getClass().isArray()) {
/* 186 */         selectedItems = Arrays.asList((Object[])(Object[])i);
/* 187 */       } else if ((i instanceof Collection)) {
/* 188 */         selectedItems = (Collection)i;
/*     */       }
/*     */       else {
/* 191 */         selectedItems = new ArrayList();
/* 192 */         selectedItems.add(i);
/*     */       }
/*     */     }
/*     */ 
/* 196 */     Collection items = (Collection)this.stack.findValue(list);
/*     */     Iterator i$;
/* 198 */     if (items != null) {
/* 199 */       for (i$ = items.iterator(); i$.hasNext(); ) { Object element = i$.next();
/*     */         Object key;
/*     */         Object key;
/* 202 */         if ((listKey == null) || (listKey.length() == 0))
/* 203 */           key = element;
/*     */         else {
/* 205 */           key = this.ognl.findValue(listKey, element);
/*     */         }
/*     */ 
/* 208 */         Object value = null;
/*     */ 
/* 210 */         if ((listValue == null) || (listValue.length() == 0))
/* 211 */           value = element;
/*     */         else {
/* 213 */           value = this.ognl.findValue(listValue, element);
/*     */         }
/*     */ 
/* 216 */         boolean isSelected = false;
/*     */ 
/* 218 */         if ((value != null) && (selectedItems != null) && (selectedItems.contains(value))) {
/* 219 */           isSelected = true;
/*     */         }
/*     */ 
/* 222 */         selectList.add(new ListEntry(key, value, isSelected));
/*     */       }
/*     */     }
/*     */ 
/* 226 */     return selectList;
/*     */   }
/*     */ 
/*     */   public int toInt(long aLong) {
/* 230 */     return (int)aLong;
/*     */   }
/*     */ 
/*     */   public long toLong(int anInt) {
/* 234 */     return anInt;
/*     */   }
/*     */ 
/*     */   public long toLong(String aLong) {
/* 238 */     if (aLong == null) {
/* 239 */       return 0L;
/*     */     }
/*     */ 
/* 242 */     return Long.parseLong(aLong);
/*     */   }
/*     */ 
/*     */   public String toString(long aLong) {
/* 246 */     return Long.toString(aLong);
/*     */   }
/*     */ 
/*     */   public String toString(int anInt) {
/* 250 */     return Integer.toString(anInt);
/*     */   }
/*     */ 
/*     */   public String toStringSafe(Object obj) {
/*     */     try {
/* 255 */       if (obj != null) {
/* 256 */         return String.valueOf(obj);
/*     */       }
/* 258 */       return ""; } catch (Exception e) {
/*     */     }
/* 260 */     return "Exception thrown: " + e;
/*     */   }
/*     */ 
/*     */   static class ServletOutputStreamWrapper extends ServletOutputStream
/*     */   {
/*     */     StringWriter writer;
/*     */ 
/*     */     ServletOutputStreamWrapper(StringWriter aWriter)
/*     */     {
/* 295 */       this.writer = aWriter;
/*     */     }
/*     */ 
/*     */     public void write(int aByte) {
/* 299 */       this.writer.write(aByte);
/*     */     }
/*     */   }
/*     */ 
/*     */   static class ResponseWrapper extends HttpServletResponseWrapper
/*     */   {
/*     */     StringWriter strout;
/*     */     PrintWriter writer;
/*     */     ServletOutputStream sout;
/*     */ 
/*     */     ResponseWrapper(HttpServletResponse aResponse)
/*     */     {
/* 270 */       super();
/* 271 */       this.strout = new StringWriter();
/* 272 */       this.sout = new StrutsUtil.ServletOutputStreamWrapper(this.strout);
/* 273 */       this.writer = new PrintWriter(this.strout);
/*     */     }
/*     */ 
/*     */     public String getData() {
/* 277 */       this.writer.flush();
/*     */ 
/* 279 */       return this.strout.toString();
/*     */     }
/*     */ 
/*     */     public ServletOutputStream getOutputStream() {
/* 283 */       return this.sout;
/*     */     }
/*     */ 
/*     */     public PrintWriter getWriter() throws IOException {
/* 287 */       return this.writer;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.util.StrutsUtil
 * JD-Core Version:    0.6.0
 */