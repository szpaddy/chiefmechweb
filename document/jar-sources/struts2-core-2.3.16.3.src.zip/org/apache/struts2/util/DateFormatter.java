/*    */ package org.apache.struts2.util;
/*    */ 
/*    */ import java.text.DateFormat;
/*    */ import java.text.ParseException;
/*    */ import java.text.SimpleDateFormat;
/*    */ import java.util.Date;
/*    */ 
/*    */ public class DateFormatter
/*    */ {
/*    */   Date date;
/*    */   DateFormat format;
/*    */   DateFormat parser;
/*    */ 
/*    */   public DateFormatter()
/*    */   {
/* 45 */     this.parser = new SimpleDateFormat();
/* 46 */     this.format = new SimpleDateFormat();
/* 47 */     this.date = new Date();
/*    */   }
/*    */ 
/*    */   public void setDate(String date)
/*    */   {
/*    */     try {
/* 53 */       this.date = this.parser.parse(date);
/*    */     } catch (ParseException e) {
/* 55 */       throw new IllegalArgumentException(e.getMessage());
/*    */     }
/*    */   }
/*    */ 
/*    */   public void setDate(Date date) {
/* 60 */     this.date = (date == null ? null : (Date)date.clone());
/*    */   }
/*    */ 
/*    */   public void setDate(int date) {
/* 64 */     setDate(Integer.toString(date));
/*    */   }
/*    */ 
/*    */   public Date getDate() {
/* 68 */     return this.date;
/*    */   }
/*    */ 
/*    */   public void setFormat(String format) {
/* 72 */     this.format = new SimpleDateFormat(format);
/*    */   }
/*    */ 
/*    */   public void setFormat(DateFormat format) {
/* 76 */     this.format = format;
/*    */   }
/*    */ 
/*    */   public String getFormattedDate() {
/* 80 */     return this.format.format(this.date);
/*    */   }
/*    */ 
/*    */   public void setParseFormat(String format) {
/* 84 */     this.parser = new SimpleDateFormat(format);
/*    */   }
/*    */ 
/*    */   public void setParser(DateFormat parser) {
/* 88 */     this.parser = parser;
/*    */   }
/*    */ 
/*    */   public void setTime(long time) {
/* 92 */     this.date.setTime(time);
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.util.DateFormatter
 * JD-Core Version:    0.6.0
 */