/*     */ package org.apache.struts2.util;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class ContainUtil
/*     */ {
/*     */   public static boolean contains(Object obj1, Object obj2)
/*     */   {
/*  72 */     if ((obj1 == null) || (obj2 == null))
/*     */     {
/*  74 */       return false;
/*     */     }
/*     */ 
/*  77 */     if (((obj1 instanceof Map)) && 
/*  78 */       (((Map)obj1).containsKey(obj2)))
/*     */     {
/*  80 */       return true;
/*     */     }
/*     */     Iterator i$;
/*  82 */     if ((obj1 instanceof Iterable)) {
/*  83 */       for (i$ = ((Iterable)obj1).iterator(); i$.hasNext(); ) { Object value = i$.next();
/*  84 */         if ((obj2.equals(value)) || (obj2.toString().equals(value)))
/*  85 */           return true;
/*     */       }
/*     */     }
/*  88 */     else if (obj1.getClass().isArray()) {
/*  89 */       for (int i = 0; i < Array.getLength(obj1); i++) {
/*  90 */         Object value = Array.get(obj1, i);
/*     */ 
/*  92 */         if (obj2.equals(value))
/*     */         {
/*  94 */           return true;
/*     */         }
/*     */       }
/*     */     } else {
/*  97 */       if (obj1.toString().equals(obj2.toString()))
/*     */       {
/*  99 */         return true;
/* 100 */       }if (obj1.equals(obj2))
/*     */       {
/* 102 */         return true;
/*     */       }
/*     */     }
/*     */ 
/* 106 */     return false;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.util.ContainUtil
 * JD-Core Version:    0.6.0
 */