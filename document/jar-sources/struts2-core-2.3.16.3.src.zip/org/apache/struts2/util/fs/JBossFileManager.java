/*     */ package org.apache.struts2.util.fs;
/*     */ 
/*     */ import com.opensymphony.xwork2.util.fs.DefaultFileManager;
/*     */ import com.opensymphony.xwork2.util.fs.FileRevision;
/*     */ import com.opensymphony.xwork2.util.fs.JarEntryRevision;
/*     */ import com.opensymphony.xwork2.util.fs.Revision;
/*     */ import com.opensymphony.xwork2.util.logging.Logger;
/*     */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URI;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class JBossFileManager extends DefaultFileManager
/*     */ {
/*  25 */   private static final Logger LOG = LoggerFactory.getLogger(JBossFileManager.class);
/*     */   private static final String JBOSS5_VFS = "vfs";
/*     */   private static final String JBOSS5_VFSZIP = "vfszip";
/*     */   private static final String JBOSS5_VFSMEMORY = "vfsmemory";
/*     */   private static final String JBOSS5_VFSFILE = "vfsfile";
/*     */   private static final String VFS_JBOSS7 = "org.jboss.vfs.VirtualFile";
/*     */   private static final String VFS_JBOSS5 = "org.jboss.virtual.VirtualFile";
/*     */ 
/*     */   public boolean support()
/*     */   {
/*  37 */     boolean supports = (isJBoss7()) || (isJBoss5());
/*  38 */     if ((supports) && (LOG.isDebugEnabled())) {
/*  39 */       LOG.debug("JBoss server detected, Struts 2 will use [#0] to support file system operations!", new String[] { JBossFileManager.class.getSimpleName() });
/*     */     }
/*  41 */     return supports;
/*     */   }
/*     */ 
/*     */   private boolean isJBoss5() {
/*     */     try {
/*  46 */       Class.forName("org.jboss.virtual.VirtualFile");
/*  47 */       return true;
/*     */     } catch (ClassNotFoundException e) {
/*  49 */       if (LOG.isDebugEnabled())
/*  50 */         LOG.debug("Cannot load [#0] class, not a JBoss 5!", new String[] { "org.jboss.virtual.VirtualFile" });
/*     */     }
/*  52 */     return false;
/*     */   }
/*     */ 
/*     */   private boolean isJBoss7()
/*     */   {
/*     */     try {
/*  58 */       Class.forName("org.jboss.vfs.VirtualFile");
/*  59 */       return true;
/*     */     } catch (ClassNotFoundException e) {
/*  61 */       if (LOG.isDebugEnabled())
/*  62 */         LOG.debug("Cannot load [#0] class, not a JBoss 7!", new String[] { "org.jboss.vfs.VirtualFile" });
/*     */     }
/*  64 */     return false;
/*     */   }
/*     */ 
/*     */   public void monitorFile(URL fileUrl)
/*     */   {
/*  70 */     if (isJBossUrl(fileUrl)) {
/*  71 */       String fileName = fileUrl.toString();
/*  72 */       if (LOG.isDebugEnabled()) {
/*  73 */         LOG.debug("Creating revision for URL: " + fileName, new String[0]);
/*     */       }
/*  75 */       URL normalizedUrl = normalizeToFileProtocol(fileUrl);
/*  76 */       if (LOG.isDebugEnabled())
/*  77 */         LOG.debug("Normalized URL for [#0] is [#1]", new String[] { fileName, normalizedUrl.toString() });
/*     */       Revision revision;
/*     */       Revision revision;
/*  80 */       if ("file".equals(normalizedUrl.getProtocol())) {
/*  81 */         revision = FileRevision.build(normalizedUrl);
/*     */       }
/*     */       else
/*     */       {
/*     */         Revision revision;
/*  82 */         if ("jar".equals(normalizedUrl.getProtocol()))
/*  83 */           revision = JarEntryRevision.build(normalizedUrl);
/*     */         else
/*  85 */           revision = Revision.build(normalizedUrl);
/*     */       }
/*  87 */       files.put(fileName, revision);
/*     */     } else {
/*  89 */       super.monitorFile(fileUrl);
/*     */     }
/*     */   }
/*     */ 
/*     */   public URL normalizeToFileProtocol(URL url)
/*     */   {
/*  95 */     if (isJBossUrl(url)) {
/*     */       try {
/*  97 */         return getJBossPhysicalUrl(url);
/*     */       } catch (IOException e) {
/*  99 */         if (LOG.isErrorEnabled()) {
/* 100 */           LOG.error(e.getMessage(), e, new String[0]);
/*     */         }
/* 102 */         return null;
/*     */       }
/*     */     }
/* 105 */     return super.normalizeToFileProtocol(url);
/*     */   }
/*     */ 
/*     */   public Collection<? extends URL> getAllPhysicalUrls(URL url)
/*     */     throws IOException
/*     */   {
/* 111 */     if (isJBossUrl(url)) {
/* 112 */       return getAllJBossPhysicalUrls(url);
/*     */     }
/* 114 */     return super.getAllPhysicalUrls(url);
/*     */   }
/*     */ 
/*     */   protected boolean isJBossUrl(URL fileUrl)
/*     */   {
/* 124 */     String protocol = fileUrl.getProtocol();
/* 125 */     return ("vfszip".equals(protocol)) || ("vfsmemory".equals(protocol)) || ("vfs".equals(protocol)) || (("true".equals(System.getProperty("jboss.vfs.forceVfsJar"))) && ("vfsfile".equals(protocol)));
/*     */   }
/*     */ 
/*     */   protected URL getJBossPhysicalUrl(URL url)
/*     */     throws IOException
/*     */   {
/* 137 */     Object content = url.openConnection().getContent();
/* 138 */     String classContent = content.getClass().toString();
/* 139 */     if (LOG.isDebugEnabled()) {
/* 140 */       LOG.debug("Reading physical URL for [#0]", new String[] { url.toString() });
/*     */     }
/* 142 */     if (classContent.startsWith("class org.jboss.vfs.VirtualFile")) {
/* 143 */       File physicalFile = readJBossPhysicalFile(content);
/* 144 */       return physicalFile.toURI().toURL();
/* 145 */     }if (classContent.startsWith("class org.jboss.virtual.VirtualFile")) {
/* 146 */       return readJBoss5Url(content);
/*     */     }
/* 148 */     return url;
/*     */   }
/*     */ 
/*     */   private List<URL> getAllJBossPhysicalUrls(URL url) throws IOException {
/* 152 */     List urls = new ArrayList();
/* 153 */     Object content = url.openConnection().getContent();
/* 154 */     String classContent = content.getClass().toString();
/* 155 */     if (classContent.startsWith("class org.jboss.vfs.VirtualFile")) {
/* 156 */       File physicalFile = readJBossPhysicalFile(content);
/* 157 */       if (physicalFile != null) {
/* 158 */         readFile(urls, physicalFile);
/* 159 */         readFile(urls, physicalFile.getParentFile());
/*     */       }
/* 161 */     } else if (classContent.startsWith("class org.jboss.virtual.VirtualFile")) {
/* 162 */       URL physicalUrl = readJBoss5Url(content);
/* 163 */       if (physicalUrl != null)
/* 164 */         urls.add(physicalUrl);
/*     */     }
/*     */     else {
/* 167 */       urls.add(url);
/*     */     }
/* 169 */     return urls;
/*     */   }
/*     */ 
/*     */   private File readJBossPhysicalFile(Object content) {
/*     */     try {
/* 174 */       Method method = content.getClass().getDeclaredMethod("getPhysicalFile", new Class[0]);
/* 175 */       return (File)method.invoke(content, new Object[0]);
/*     */     } catch (NoSuchMethodException e) {
/* 177 */       LOG.error("Provided class content [#0] is not a JBoss VirtualFile, getPhysicalFile() method not found!", e, new String[] { content.getClass().getSimpleName() });
/*     */     } catch (InvocationTargetException e) {
/* 179 */       LOG.error("Cannot invoke getPhysicalFile() method!", e, new String[0]);
/*     */     } catch (IllegalAccessException e) {
/* 181 */       LOG.error("Cannot access getPhysicalFile() method!", e, new String[0]);
/*     */     }
/* 183 */     return null;
/*     */   }
/*     */ 
/*     */   private URL readJBoss5Url(Object content) {
/*     */     try {
/* 188 */       Method method = content.getClass().getDeclaredMethod("getHandler", new Class[0]);
/* 189 */       method.setAccessible(true);
/* 190 */       Object handler = method.invoke(content, new Object[0]);
/* 191 */       method = handler.getClass().getMethod("getRealURL", new Class[0]);
/* 192 */       return (URL)method.invoke(handler, new Object[0]);
/*     */     } catch (NoSuchMethodException e) {
/* 194 */       LOG.error("Provided class content [#0] is not a JBoss VirtualFile, getHandler() or getRealURL() method not found!", e, new String[] { content.getClass().getSimpleName() });
/*     */     } catch (InvocationTargetException e) {
/* 196 */       LOG.error("Cannot invoke getHandler() or getRealURL() method!", e, new String[0]);
/*     */     } catch (IllegalAccessException e) {
/* 198 */       LOG.error("Cannot access getHandler() or getRealURL() method!", e, new String[0]);
/*     */     }
/* 200 */     return null;
/*     */   }
/*     */ 
/*     */   private void readFile(List<URL> urls, File physicalFile) throws MalformedURLException {
/* 204 */     File[] files = physicalFile.listFiles();
/* 205 */     if ((physicalFile.isDirectory()) && (files != null))
/* 206 */       for (File file : files)
/* 207 */         if (file.isFile())
/* 208 */           addIfAbsent(urls, file.toURI().toURL());
/* 209 */         else if (file.isDirectory())
/* 210 */           readFile(urls, file);
/*     */   }
/*     */ 
/*     */   private void addIfAbsent(List<URL> urls, URL fileUrl)
/*     */   {
/* 217 */     if (!urls.contains(fileUrl))
/* 218 */       urls.add(fileUrl);
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.util.fs.JBossFileManager
 * JD-Core Version:    0.6.0
 */