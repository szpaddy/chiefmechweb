/*     */ package org.apache.struts2.util;
/*     */ 
/*     */ import com.opensymphony.xwork2.util.PatternMatcher;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.apache.commons.lang3.StringUtils;
/*     */ 
/*     */ public class RegexPatternMatcher
/*     */   implements PatternMatcher<RegexPatternMatcherExpression>
/*     */ {
/*  49 */   private static final Pattern PATTERN = Pattern.compile("\\{(.*?)\\}");
/*     */ 
/*     */   public RegexPatternMatcherExpression compilePattern(String data) {
/*  52 */     Map params = new HashMap();
/*     */ 
/*  54 */     Matcher matcher = PATTERN.matcher(data);
/*  55 */     int count = 0;
/*  56 */     while (matcher.find()) {
/*  57 */       String expression = matcher.group(1);
/*     */ 
/*  59 */       int index = expression.indexOf(':');
/*  60 */       if (index > 0) {
/*  61 */         String paramName = expression.substring(0, index);
/*  62 */         String regex = StringUtils.substring(expression, index + 1);
/*  63 */         if (StringUtils.isBlank(regex)) {
/*  64 */           throw new IllegalArgumentException("invalid expression [" + expression + "], named parameter regular exression " + "must be in the format {PARAM_NAME:REGEX}");
/*     */         }
/*     */ 
/*  68 */         count++; params.put(Integer.valueOf(count), paramName);
/*     */       }
/*     */       else {
/*  71 */         count++; params.put(Integer.valueOf(count), expression);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/*  77 */     String newPattern = data.replaceAll("(\\{[^\\}]*?:(.*?)\\})", "($2)");
/*     */ 
/*  80 */     newPattern = newPattern.replaceAll("(\\{.*?\\})", "(.*?)");
/*  81 */     return new RegexPatternMatcherExpression(Pattern.compile(newPattern), params);
/*     */   }
/*     */ 
/*     */   public boolean isLiteral(String pattern) {
/*  85 */     return (pattern == null) || (pattern.indexOf('{') == -1);
/*     */   }
/*     */ 
/*     */   public boolean match(Map<String, String> map, String data, RegexPatternMatcherExpression expr) {
/*  89 */     Matcher matcher = expr.getPattern().matcher(data);
/*  90 */     Map params = expr.getParams();
/*     */ 
/*  92 */     if (matcher.matches()) {
/*  93 */       map.put("0", data);
/*     */ 
/*  96 */       for (int i = 1; i <= matcher.groupCount(); i++) {
/*  97 */         String paramName = (String)params.get(Integer.valueOf(i));
/*  98 */         String value = matcher.group(i);
/*     */ 
/* 101 */         map.put(paramName, value);
/*     */ 
/* 103 */         map.put(String.valueOf(i), value);
/*     */       }
/*     */ 
/* 106 */       return true;
/*     */     }
/* 108 */     return false;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.util.RegexPatternMatcher
 * JD-Core Version:    0.6.0
 */