package org.apache.struts2.util;

import javax.servlet.ServletContext;

public abstract interface ServletContextAware
{
  public abstract void setServletContext(ServletContext paramServletContext);
}

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.util.ServletContextAware
 * JD-Core Version:    0.6.0
 */