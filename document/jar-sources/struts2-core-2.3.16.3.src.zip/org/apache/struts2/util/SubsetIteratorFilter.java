/*     */ package org.apache.struts2.util;
/*     */ 
/*     */ import com.opensymphony.xwork2.Action;
/*     */ import com.opensymphony.xwork2.util.logging.Logger;
/*     */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ public class SubsetIteratorFilter extends IteratorFilterSupport
/*     */   implements Iterator, Action
/*     */ {
/*  39 */   private static final Logger LOG = LoggerFactory.getLogger(SubsetIteratorFilter.class);
/*     */   Iterator iterator;
/*     */   Object source;
/*     */   int count;
/*     */   int currentCount;
/*     */   Decider decider;
/*     */   int start;
/*     */ 
/*     */   public SubsetIteratorFilter()
/*     */   {
/*  43 */     this.count = -1;
/*  44 */     this.currentCount = 0;
/*     */ 
/*  49 */     this.start = 0;
/*     */   }
/*     */ 
/*     */   public void setCount(int aCount) {
/*  53 */     this.count = aCount;
/*     */   }
/*     */ 
/*     */   public void setSource(Object anIterator)
/*     */   {
/*  58 */     this.source = anIterator;
/*     */   }
/*     */ 
/*     */   public void setStart(int aStart) {
/*  62 */     this.start = aStart;
/*     */   }
/*     */ 
/*     */   public void setDecider(Decider aDecider) {
/*  66 */     this.decider = aDecider;
/*     */   }
/*     */ 
/*     */   public String execute()
/*     */   {
/*  71 */     if (this.source == null) {
/*  72 */       LoggerFactory.getLogger(SubsetIteratorFilter.class.getName()).warn("Source is null returning empty set.", new String[0]);
/*     */ 
/*  74 */       return "error";
/*     */     }
/*     */ 
/*  78 */     this.source = getIterator(this.source);
/*     */ 
/*  81 */     if ((this.source instanceof Action)) {
/*  82 */       this.iterator = ((Action)this.source);
/*     */ 
/*  86 */       for (int i = 0; (i < this.start) && (this.iterator.hasNext()); i++) {
/*  87 */         this.iterator.next();
/*     */       }
/*     */ 
/*  92 */       if (this.decider != null) {
/*  93 */         List list = new ArrayList();
/*  94 */         while (this.iterator.hasNext()) {
/*  95 */           Object currentElement = this.iterator.next();
/*  96 */           if (decide(currentElement)) {
/*  97 */             list.add(currentElement);
/*     */           }
/*     */         }
/* 100 */         this.iterator = list.iterator();
/*     */       }
/*     */     }
/* 103 */     else if (this.source.getClass().isArray()) {
/* 104 */       ArrayList list = new ArrayList(((Object[])(Object[])this.source).length);
/* 105 */       Object[] objects = (Object[])(Object[])this.source;
/* 106 */       int len = objects.length;
/*     */ 
/* 108 */       if (this.count >= 0) {
/* 109 */         len = this.start + this.count;
/* 110 */         if (len > objects.length) {
/* 111 */           len = objects.length;
/*     */         }
/*     */       }
/*     */ 
/* 115 */       for (int j = this.start; j < len; j++) {
/* 116 */         if (decide(objects[j])) {
/* 117 */           list.add(objects[j]);
/*     */         }
/*     */       }
/*     */ 
/* 121 */       this.count = -1;
/* 122 */       this.iterator = list.iterator();
/*     */     }
/*     */ 
/* 125 */     if (this.iterator == null) {
/* 126 */       throw new IllegalArgumentException("Source is not an iterator:" + this.source);
/*     */     }
/*     */ 
/* 129 */     return "success";
/*     */   }
/*     */ 
/*     */   public boolean hasNext()
/*     */   {
/* 134 */     return this.iterator != null;
/*     */   }
/*     */ 
/*     */   public Object next() {
/* 138 */     this.currentCount += 1;
/*     */ 
/* 140 */     return this.iterator.next();
/*     */   }
/*     */ 
/*     */   public void remove() {
/* 144 */     this.iterator.remove();
/*     */   }
/*     */ 
/*     */   protected boolean decide(Object element)
/*     */   {
/* 164 */     if (this.decider != null) {
/*     */       try {
/* 166 */         boolean okToAdd = this.decider.decide(element);
/* 167 */         return okToAdd;
/*     */       }
/*     */       catch (Exception e) {
/* 170 */         if (LOG.isWarnEnabled()) {
/* 171 */           LOG.warn("Decider [#0] encountered an error while decide adding element [#1], element will be ignored, it will not appeared in subseted iterator", e, new String[] { this.decider.toString(), element.toString() });
/*     */         }
/*     */ 
/* 174 */         return false;
/*     */       }
/*     */     }
/* 177 */     return true;
/*     */   }
/*     */ 
/*     */   public static abstract interface Decider
/*     */   {
/*     */     public abstract boolean decide(Object paramObject)
/*     */       throws Exception;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.util.SubsetIteratorFilter
 * JD-Core Version:    0.6.0
 */