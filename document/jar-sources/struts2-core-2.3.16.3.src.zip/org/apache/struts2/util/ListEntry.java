/*    */ package org.apache.struts2.util;
/*    */ 
/*    */ public class ListEntry
/*    */ {
/*    */   private final Object key;
/*    */   private final Object value;
/*    */   private final boolean isSelected;
/*    */ 
/*    */   public ListEntry(Object key, Object value, boolean isSelected)
/*    */   {
/* 36 */     this.key = key;
/* 37 */     this.value = value;
/* 38 */     this.isSelected = isSelected;
/*    */   }
/*    */ 
/*    */   public boolean getIsSelected()
/*    */   {
/* 43 */     return this.isSelected;
/*    */   }
/*    */ 
/*    */   public Object getKey() {
/* 47 */     return this.key;
/*    */   }
/*    */ 
/*    */   public Object getValue() {
/* 51 */     return this.value;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.util.ListEntry
 * JD-Core Version:    0.6.0
 */