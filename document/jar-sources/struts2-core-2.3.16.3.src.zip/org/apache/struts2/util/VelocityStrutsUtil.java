/*    */ package org.apache.struts2.util;
/*    */ 
/*    */ import com.opensymphony.xwork2.util.ValueStack;
/*    */ import java.io.CharArrayWriter;
/*    */ import java.io.IOException;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.apache.velocity.app.VelocityEngine;
/*    */ import org.apache.velocity.context.Context;
/*    */ import org.apache.velocity.exception.MethodInvocationException;
/*    */ import org.apache.velocity.exception.ParseErrorException;
/*    */ import org.apache.velocity.exception.ResourceNotFoundException;
/*    */ 
/*    */ public class VelocityStrutsUtil extends StrutsUtil
/*    */ {
/*    */   private Context ctx;
/*    */   private VelocityEngine velocityEngine;
/*    */ 
/*    */   public VelocityStrutsUtil(VelocityEngine engine, Context ctx, ValueStack stack, HttpServletRequest request, HttpServletResponse response)
/*    */   {
/* 49 */     super(stack, request, response);
/* 50 */     this.ctx = ctx;
/* 51 */     this.velocityEngine = engine;
/*    */   }
/*    */ 
/*    */   public String evaluate(String expression) throws IOException, ResourceNotFoundException, MethodInvocationException, ParseErrorException {
/* 55 */     CharArrayWriter writer = new CharArrayWriter();
/* 56 */     this.velocityEngine.evaluate(this.ctx, writer, "Error parsing " + expression, expression);
/*    */ 
/* 58 */     return writer.toString();
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.util.VelocityStrutsUtil
 * JD-Core Version:    0.6.0
 */