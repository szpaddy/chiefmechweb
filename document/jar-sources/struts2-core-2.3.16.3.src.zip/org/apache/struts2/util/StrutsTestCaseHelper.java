/*    */ package org.apache.struts2.util;
/*    */ 
/*    */ import com.opensymphony.xwork2.ActionContext;
/*    */ import com.opensymphony.xwork2.inject.Container;
/*    */ import com.opensymphony.xwork2.util.LocalizedTextUtil;
/*    */ import com.opensymphony.xwork2.util.ValueStack;
/*    */ import com.opensymphony.xwork2.util.ValueStackFactory;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import javax.servlet.ServletContext;
/*    */ import org.apache.struts2.dispatcher.Dispatcher;
/*    */ 
/*    */ public class StrutsTestCaseHelper
/*    */ {
/*    */   public static void setUp()
/*    */     throws Exception
/*    */   {
/* 46 */     LocalizedTextUtil.clearDefaultResourceBundles();
/*    */   }
/*    */ 
/*    */   public static Dispatcher initDispatcher(ServletContext ctx, Map<String, String> params) {
/* 50 */     if (params == null) {
/* 51 */       params = new HashMap();
/*    */     }
/* 53 */     Dispatcher du = new Dispatcher(ctx, params);
/* 54 */     du.init();
/* 55 */     Dispatcher.setInstance(du);
/*    */ 
/* 58 */     ValueStack stack = ((ValueStackFactory)du.getContainer().getInstance(ValueStackFactory.class)).createValueStack();
/* 59 */     stack.getContext().put("com.opensymphony.xwork2.ActionContext.container", du.getContainer());
/* 60 */     ActionContext.setContext(new ActionContext(stack.getContext()));
/*    */ 
/* 62 */     return du;
/*    */   }
/*    */ 
/*    */   public static void tearDown() throws Exception {
/* 66 */     Dispatcher.setInstance(null);
/* 67 */     ActionContext.setContext(null);
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.util.StrutsTestCaseHelper
 * JD-Core Version:    0.6.0
 */