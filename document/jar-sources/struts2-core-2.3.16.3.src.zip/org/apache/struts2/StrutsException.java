/*     */ package org.apache.struts2;
/*     */ 
/*     */ import com.opensymphony.xwork2.XWorkException;
/*     */ import com.opensymphony.xwork2.util.location.Locatable;
/*     */ 
/*     */ public class StrutsException extends XWorkException
/*     */   implements Locatable
/*     */ {
/*     */   private static final long serialVersionUID = 888724366243600135L;
/*     */ 
/*     */   public StrutsException()
/*     */   {
/*     */   }
/*     */ 
/*     */   public StrutsException(String s)
/*     */   {
/*  49 */     this(s, null, null);
/*     */   }
/*     */ 
/*     */   public StrutsException(String s, Object target)
/*     */   {
/*  60 */     this(s, (Throwable)null, target);
/*     */   }
/*     */ 
/*     */   public StrutsException(Throwable cause)
/*     */   {
/*  69 */     this(null, cause, null);
/*     */   }
/*     */ 
/*     */   public StrutsException(Throwable cause, Object target)
/*     */   {
/*  79 */     this(null, cause, target);
/*     */   }
/*     */ 
/*     */   public StrutsException(String s, Throwable cause)
/*     */   {
/*  90 */     this(s, cause, null);
/*     */   }
/*     */ 
/*     */   public StrutsException(String s, Throwable cause, Object target)
/*     */   {
/* 103 */     super(s, cause, target);
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.StrutsException
 * JD-Core Version:    0.6.0
 */