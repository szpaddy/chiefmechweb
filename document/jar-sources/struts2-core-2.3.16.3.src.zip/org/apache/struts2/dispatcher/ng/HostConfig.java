package org.apache.struts2.dispatcher.ng;

import java.util.Iterator;
import javax.servlet.ServletContext;

public abstract interface HostConfig
{
  public abstract String getInitParameter(String paramString);

  public abstract Iterator<String> getInitParameterNames();

  public abstract ServletContext getServletContext();
}

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.dispatcher.ng.HostConfig
 * JD-Core Version:    0.6.0
 */