/*    */ package org.apache.struts2.dispatcher.ng.filter;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ import javax.servlet.FilterConfig;
/*    */ import javax.servlet.ServletContext;
/*    */ import org.apache.struts2.dispatcher.ng.HostConfig;
/*    */ import org.apache.struts2.util.MakeIterator;
/*    */ 
/*    */ public class FilterHostConfig
/*    */   implements HostConfig
/*    */ {
/*    */   private FilterConfig config;
/*    */ 
/*    */   public FilterHostConfig(FilterConfig config)
/*    */   {
/* 39 */     this.config = config;
/*    */   }
/*    */   public String getInitParameter(String key) {
/* 42 */     return this.config.getInitParameter(key);
/*    */   }
/*    */ 
/*    */   public Iterator<String> getInitParameterNames() {
/* 46 */     return MakeIterator.convert(this.config.getInitParameterNames());
/*    */   }
/*    */ 
/*    */   public ServletContext getServletContext() {
/* 50 */     return this.config.getServletContext();
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.dispatcher.ng.filter.FilterHostConfig
 * JD-Core Version:    0.6.0
 */