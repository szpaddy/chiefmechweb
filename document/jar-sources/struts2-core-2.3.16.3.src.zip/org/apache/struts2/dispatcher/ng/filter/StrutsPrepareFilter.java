/*    */ package org.apache.struts2.dispatcher.ng.filter;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.List;
/*    */ import java.util.regex.Pattern;
/*    */ import javax.servlet.Filter;
/*    */ import javax.servlet.FilterChain;
/*    */ import javax.servlet.FilterConfig;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.ServletRequest;
/*    */ import javax.servlet.ServletResponse;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.apache.struts2.StrutsStatics;
/*    */ import org.apache.struts2.dispatcher.Dispatcher;
/*    */ import org.apache.struts2.dispatcher.ng.InitOperations;
/*    */ import org.apache.struts2.dispatcher.ng.PrepareOperations;
/*    */ 
/*    */ public class StrutsPrepareFilter
/*    */   implements StrutsStatics, Filter
/*    */ {
/* 45 */   protected static final String REQUEST_EXCLUDED_FROM_ACTION_MAPPING = StrutsPrepareFilter.class.getName() + ".REQUEST_EXCLUDED_FROM_ACTION_MAPPING";
/*    */   protected PrepareOperations prepare;
/* 48 */   protected List<Pattern> excludedPatterns = null;
/*    */ 
/*    */   public void init(FilterConfig filterConfig) throws ServletException {
/* 51 */     InitOperations init = new InitOperations();
/* 52 */     Dispatcher dispatcher = null;
/*    */     try {
/* 54 */       FilterHostConfig config = new FilterHostConfig(filterConfig);
/* 55 */       init.initLogging(config);
/* 56 */       dispatcher = init.initDispatcher(config);
/*    */ 
/* 58 */       this.prepare = new PrepareOperations(filterConfig.getServletContext(), dispatcher);
/* 59 */       this.excludedPatterns = init.buildExcludedPatternsList(dispatcher);
/*    */ 
/* 61 */       postInit(dispatcher, filterConfig);
/*    */     } finally {
/* 63 */       if (dispatcher != null) {
/* 64 */         dispatcher.cleanUpAfterInit();
/*    */       }
/* 66 */       init.cleanup();
/*    */     }
/*    */   }
/*    */ 
/*    */   protected void postInit(Dispatcher dispatcher, FilterConfig filterConfig)
/*    */   {
/*    */   }
/*    */ 
/*    */   public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
/*    */     throws IOException, ServletException
/*    */   {
/* 78 */     HttpServletRequest request = (HttpServletRequest)req;
/* 79 */     HttpServletResponse response = (HttpServletResponse)res;
/*    */     try
/*    */     {
/* 82 */       if ((this.excludedPatterns != null) && (this.prepare.isUrlExcluded(request, this.excludedPatterns))) {
/* 83 */         request.setAttribute(REQUEST_EXCLUDED_FROM_ACTION_MAPPING, new Object());
/*    */       } else {
/* 85 */         this.prepare.setEncodingAndLocale(request, response);
/* 86 */         this.prepare.createActionContext(request, response);
/* 87 */         this.prepare.assignDispatcherToThread();
/* 88 */         request = this.prepare.wrapRequest(request);
/* 89 */         this.prepare.findActionMapping(request, response);
/*    */       }
/* 91 */       chain.doFilter(request, response);
/*    */     } finally {
/* 93 */       this.prepare.cleanupRequest(request);
/*    */     }
/*    */   }
/*    */ 
/*    */   public void destroy() {
/* 98 */     this.prepare.cleanupDispatcher();
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.dispatcher.ng.filter.StrutsPrepareFilter
 * JD-Core Version:    0.6.0
 */