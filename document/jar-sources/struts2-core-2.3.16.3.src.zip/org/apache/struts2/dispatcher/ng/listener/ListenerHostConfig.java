/*    */ package org.apache.struts2.dispatcher.ng.listener;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import javax.servlet.ServletContext;
/*    */ import org.apache.struts2.dispatcher.ng.HostConfig;
/*    */ 
/*    */ public class ListenerHostConfig
/*    */   implements HostConfig
/*    */ {
/*    */   private ServletContext servletContext;
/*    */ 
/*    */   public ListenerHostConfig(ServletContext servletContext)
/*    */   {
/* 36 */     this.servletContext = servletContext;
/*    */   }
/*    */ 
/*    */   public String getInitParameter(String key) {
/* 40 */     return null;
/*    */   }
/*    */ 
/*    */   public Iterator<String> getInitParameterNames() {
/* 44 */     return Collections.emptyList().iterator();
/*    */   }
/*    */ 
/*    */   public ServletContext getServletContext() {
/* 48 */     return this.servletContext;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.dispatcher.ng.listener.ListenerHostConfig
 * JD-Core Version:    0.6.0
 */