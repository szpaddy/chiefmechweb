/*    */ package org.apache.struts2.dispatcher.ng;
/*    */ 
/*    */ import com.opensymphony.xwork2.inject.Container;
/*    */ import java.io.IOException;
/*    */ import javax.servlet.ServletContext;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.apache.struts2.RequestUtils;
/*    */ import org.apache.struts2.dispatcher.Dispatcher;
/*    */ import org.apache.struts2.dispatcher.StaticContentLoader;
/*    */ import org.apache.struts2.dispatcher.mapper.ActionMapping;
/*    */ 
/*    */ public class ExecuteOperations
/*    */ {
/*    */   private ServletContext servletContext;
/*    */   private Dispatcher dispatcher;
/*    */ 
/*    */   public ExecuteOperations(ServletContext servletContext, Dispatcher dispatcher)
/*    */   {
/* 42 */     this.dispatcher = dispatcher;
/* 43 */     this.servletContext = servletContext;
/*    */   }
/*    */ 
/*    */   public boolean executeStaticResourceRequest(HttpServletRequest request, HttpServletResponse response)
/*    */     throws IOException, ServletException
/*    */   {
/* 54 */     String resourcePath = RequestUtils.getServletPath(request);
/*    */ 
/* 56 */     if (("".equals(resourcePath)) && (null != request.getPathInfo())) {
/* 57 */       resourcePath = request.getPathInfo();
/*    */     }
/*    */ 
/* 60 */     StaticContentLoader staticResourceLoader = (StaticContentLoader)this.dispatcher.getContainer().getInstance(StaticContentLoader.class);
/* 61 */     if (staticResourceLoader.canHandle(resourcePath)) {
/* 62 */       staticResourceLoader.findStaticResource(resourcePath, request, response);
/*    */ 
/* 64 */       return true;
/*    */     }
/*    */ 
/* 68 */     return false;
/*    */   }
/*    */ 
/*    */   public void executeAction(HttpServletRequest request, HttpServletResponse response, ActionMapping mapping)
/*    */     throws ServletException
/*    */   {
/* 77 */     this.dispatcher.serviceAction(request, response, this.servletContext, mapping);
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.dispatcher.ng.ExecuteOperations
 * JD-Core Version:    0.6.0
 */