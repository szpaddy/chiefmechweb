/*     */ package org.apache.struts2.dispatcher.ng;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionContext;
/*     */ import com.opensymphony.xwork2.inject.Container;
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import com.opensymphony.xwork2.util.ValueStackFactory;
/*     */ import com.opensymphony.xwork2.util.logging.Logger;
/*     */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*     */ import java.io.IOException;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.struts2.RequestUtils;
/*     */ import org.apache.struts2.StrutsException;
/*     */ import org.apache.struts2.dispatcher.Dispatcher;
/*     */ import org.apache.struts2.dispatcher.mapper.ActionMapper;
/*     */ import org.apache.struts2.dispatcher.mapper.ActionMapping;
/*     */ 
/*     */ public class PrepareOperations
/*     */ {
/*  48 */   private static final Logger LOG = LoggerFactory.getLogger(PrepareOperations.class);
/*     */   private ServletContext servletContext;
/*     */   private Dispatcher dispatcher;
/*     */   private static final String STRUTS_ACTION_MAPPING_KEY = "struts.actionMapping";
/*     */   public static final String CLEANUP_RECURSION_COUNTER = "__cleanup_recursion_counter";
/*  54 */   private Logger log = LoggerFactory.getLogger(PrepareOperations.class);
/*     */ 
/*     */   public PrepareOperations(ServletContext servletContext, Dispatcher dispatcher) {
/*  57 */     this.dispatcher = dispatcher;
/*  58 */     this.servletContext = servletContext;
/*     */   }
/*     */ 
/*     */   public ActionContext createActionContext(HttpServletRequest request, HttpServletResponse response)
/*     */   {
/*  66 */     Integer counter = Integer.valueOf(1);
/*  67 */     Integer oldCounter = (Integer)request.getAttribute("__cleanup_recursion_counter");
/*  68 */     if (oldCounter != null) {
/*  69 */       counter = Integer.valueOf(oldCounter.intValue() + 1);
/*     */     }
/*     */ 
/*  72 */     ActionContext oldContext = ActionContext.getContext();
/*     */     ActionContext ctx;
/*     */     ActionContext ctx;
/*  73 */     if (oldContext != null)
/*     */     {
/*  75 */       ctx = new ActionContext(new HashMap(oldContext.getContextMap()));
/*     */     } else {
/*  77 */       ValueStack stack = ((ValueStackFactory)this.dispatcher.getContainer().getInstance(ValueStackFactory.class)).createValueStack();
/*  78 */       stack.getContext().putAll(this.dispatcher.createContextMap(request, response, null, this.servletContext));
/*  79 */       ctx = new ActionContext(stack.getContext());
/*     */     }
/*  81 */     request.setAttribute("__cleanup_recursion_counter", counter);
/*  82 */     ActionContext.setContext(ctx);
/*  83 */     return ctx;
/*     */   }
/*     */ 
/*     */   public void cleanupRequest(HttpServletRequest request)
/*     */   {
/*  90 */     Integer counterVal = (Integer)request.getAttribute("__cleanup_recursion_counter");
/*  91 */     if (counterVal != null) {
/*  92 */       counterVal = Integer.valueOf(counterVal.intValue() - 1);
/*  93 */       request.setAttribute("__cleanup_recursion_counter", counterVal);
/*  94 */       if (counterVal.intValue() > 0) {
/*  95 */         if (this.log.isDebugEnabled()) {
/*  96 */           this.log.debug("skipping cleanup counter=" + counterVal, new String[0]);
/*     */         }
/*  98 */         return;
/*     */       }
/*     */     }
/*     */     try
/*     */     {
/* 103 */       this.dispatcher.cleanUpRequest(request);
/*     */     } finally {
/* 105 */       ActionContext.setContext(null);
/* 106 */       Dispatcher.setInstance(null);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void assignDispatcherToThread()
/*     */   {
/* 114 */     Dispatcher.setInstance(this.dispatcher);
/*     */   }
/*     */ 
/*     */   public void setEncodingAndLocale(HttpServletRequest request, HttpServletResponse response)
/*     */   {
/* 121 */     this.dispatcher.prepare(request, response);
/*     */   }
/*     */ 
/*     */   public HttpServletRequest wrapRequest(HttpServletRequest oldRequest)
/*     */     throws ServletException
/*     */   {
/* 130 */     HttpServletRequest request = oldRequest;
/*     */     try
/*     */     {
/* 134 */       request = this.dispatcher.wrapRequest(request, this.servletContext);
/*     */     } catch (IOException e) {
/* 136 */       throw new ServletException("Could not wrap servlet request with MultipartRequestWrapper!", e);
/*     */     }
/* 138 */     return request;
/*     */   }
/*     */ 
/*     */   public ActionMapping findActionMapping(HttpServletRequest request, HttpServletResponse response)
/*     */   {
/* 147 */     return findActionMapping(request, response, false);
/*     */   }
/*     */ 
/*     */   public ActionMapping findActionMapping(HttpServletRequest request, HttpServletResponse response, boolean forceLookup)
/*     */   {
/* 158 */     ActionMapping mapping = (ActionMapping)request.getAttribute("struts.actionMapping");
/* 159 */     if ((mapping == null) || (forceLookup)) {
/*     */       try {
/* 161 */         mapping = ((ActionMapper)this.dispatcher.getContainer().getInstance(ActionMapper.class)).getMapping(request, this.dispatcher.getConfigurationManager());
/* 162 */         if (mapping != null)
/* 163 */           request.setAttribute("struts.actionMapping", mapping);
/*     */       }
/*     */       catch (Exception ex) {
/* 166 */         this.dispatcher.sendError(request, response, this.servletContext, 500, ex);
/*     */       }
/*     */     }
/*     */ 
/* 170 */     return mapping;
/*     */   }
/*     */ 
/*     */   public void cleanupDispatcher()
/*     */   {
/* 177 */     if (this.dispatcher == null)
/* 178 */       throw new StrutsException("Something is seriously wrong, Dispatcher is not initialized (null) ");
/*     */     try
/*     */     {
/* 181 */       this.dispatcher.cleanup();
/*     */     } finally {
/* 183 */       ActionContext.setContext(null);
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean isUrlExcluded(HttpServletRequest request, List<Pattern> excludedPatterns)
/*     */   {
/*     */     String uri;
/* 197 */     if (excludedPatterns != null) {
/* 198 */       uri = RequestUtils.getUri(request);
/* 199 */       for (Pattern pattern : excludedPatterns) {
/* 200 */         if (pattern.matcher(uri).matches()) {
/* 201 */           return true;
/*     */         }
/*     */       }
/*     */     }
/* 205 */     return false;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.dispatcher.ng.PrepareOperations
 * JD-Core Version:    0.6.0
 */