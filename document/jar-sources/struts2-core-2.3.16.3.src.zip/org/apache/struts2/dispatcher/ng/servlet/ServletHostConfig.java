/*    */ package org.apache.struts2.dispatcher.ng.servlet;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ import javax.servlet.ServletConfig;
/*    */ import javax.servlet.ServletContext;
/*    */ import org.apache.struts2.dispatcher.ng.HostConfig;
/*    */ import org.apache.struts2.util.MakeIterator;
/*    */ 
/*    */ public class ServletHostConfig
/*    */   implements HostConfig
/*    */ {
/*    */   private ServletConfig config;
/*    */ 
/*    */   public ServletHostConfig(ServletConfig config)
/*    */   {
/* 38 */     this.config = config;
/*    */   }
/*    */   public String getInitParameter(String key) {
/* 41 */     return this.config.getInitParameter(key);
/*    */   }
/*    */ 
/*    */   public Iterator<String> getInitParameterNames() {
/* 45 */     return MakeIterator.convert(this.config.getInitParameterNames());
/*    */   }
/*    */ 
/*    */   public ServletContext getServletContext() {
/* 49 */     return this.config.getServletContext();
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.dispatcher.ng.servlet.ServletHostConfig
 * JD-Core Version:    0.6.0
 */