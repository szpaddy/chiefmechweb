/*     */ package org.apache.struts2.dispatcher.ng;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionContext;
/*     */ import com.opensymphony.xwork2.inject.Container;
/*     */ import com.opensymphony.xwork2.util.ClassLoaderUtil;
/*     */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*     */ import java.io.PrintStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.regex.Pattern;
/*     */ import org.apache.struts2.dispatcher.Dispatcher;
/*     */ import org.apache.struts2.dispatcher.StaticContentLoader;
/*     */ 
/*     */ public class InitOperations
/*     */ {
/*     */   public void initLogging(HostConfig filterConfig)
/*     */   {
/*  50 */     String factoryName = filterConfig.getInitParameter("loggerFactory");
/*  51 */     if (factoryName != null)
/*     */       try {
/*  53 */         Class cls = ClassLoaderUtil.loadClass(factoryName, getClass());
/*  54 */         LoggerFactory fac = (LoggerFactory)cls.newInstance();
/*  55 */         LoggerFactory.setLoggerFactory(fac);
/*     */       } catch (InstantiationException e) {
/*  57 */         System.err.println("Unable to instantiate logger factory: " + factoryName + ", using default");
/*  58 */         e.printStackTrace();
/*     */       } catch (IllegalAccessException e) {
/*  60 */         System.err.println("Unable to access logger factory: " + factoryName + ", using default");
/*  61 */         e.printStackTrace();
/*     */       } catch (ClassNotFoundException e) {
/*  63 */         System.err.println("Unable to locate logger factory class: " + factoryName + ", using default");
/*  64 */         e.printStackTrace();
/*     */       }
/*     */   }
/*     */ 
/*     */   public Dispatcher initDispatcher(HostConfig filterConfig)
/*     */   {
/*  73 */     Dispatcher dispatcher = createDispatcher(filterConfig);
/*  74 */     dispatcher.init();
/*  75 */     return dispatcher;
/*     */   }
/*     */ 
/*     */   public StaticContentLoader initStaticContentLoader(HostConfig filterConfig, Dispatcher dispatcher)
/*     */   {
/*  82 */     StaticContentLoader loader = (StaticContentLoader)dispatcher.getContainer().getInstance(StaticContentLoader.class);
/*  83 */     loader.setHostConfig(filterConfig);
/*  84 */     return loader;
/*     */   }
/*     */ 
/*     */   public Dispatcher findDispatcherOnThread()
/*     */   {
/*  93 */     Dispatcher dispatcher = Dispatcher.getInstance();
/*  94 */     if (dispatcher == null) {
/*  95 */       throw new IllegalStateException("Must have the StrutsPrepareFilter execute before this one");
/*     */     }
/*  97 */     return dispatcher;
/*     */   }
/*     */ 
/*     */   private Dispatcher createDispatcher(HostConfig filterConfig)
/*     */   {
/* 104 */     Map params = new HashMap();
/* 105 */     for (Iterator e = filterConfig.getInitParameterNames(); e.hasNext(); ) {
/* 106 */       String name = (String)e.next();
/* 107 */       String value = filterConfig.getInitParameter(name);
/* 108 */       params.put(name, value);
/*     */     }
/* 110 */     return new Dispatcher(filterConfig.getServletContext(), params);
/*     */   }
/*     */ 
/*     */   public void cleanup() {
/* 114 */     ActionContext.setContext(null);
/*     */   }
/*     */ 
/*     */   public List<Pattern> buildExcludedPatternsList(Dispatcher dispatcher)
/*     */   {
/* 127 */     return buildExcludedPatternsList((String)dispatcher.getContainer().getInstance(String.class, "struts.action.excludePattern"));
/*     */   }
/*     */ 
/*     */   private List<Pattern> buildExcludedPatternsList(String patterns) {
/* 131 */     if ((null != patterns) && (patterns.trim().length() != 0)) {
/* 132 */       List list = new ArrayList();
/* 133 */       String[] tokens = patterns.split(",");
/* 134 */       for (String token : tokens) {
/* 135 */         list.add(Pattern.compile(token.trim()));
/*     */       }
/* 137 */       return Collections.unmodifiableList(list);
/*     */     }
/* 139 */     return null;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.dispatcher.ng.InitOperations
 * JD-Core Version:    0.6.0
 */