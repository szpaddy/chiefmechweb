/*    */ package org.apache.struts2.dispatcher.ng.listener;
/*    */ 
/*    */ import javax.servlet.ServletContext;
/*    */ import javax.servlet.ServletContextEvent;
/*    */ import javax.servlet.ServletContextListener;
/*    */ import org.apache.struts2.dispatcher.Dispatcher;
/*    */ import org.apache.struts2.dispatcher.ng.InitOperations;
/*    */ import org.apache.struts2.dispatcher.ng.PrepareOperations;
/*    */ 
/*    */ public class StrutsListener
/*    */   implements ServletContextListener
/*    */ {
/*    */   private PrepareOperations prepare;
/*    */ 
/*    */   public void contextInitialized(ServletContextEvent sce)
/*    */   {
/* 41 */     InitOperations init = new InitOperations();
/* 42 */     Dispatcher dispatcher = null;
/*    */     try {
/* 44 */       ListenerHostConfig config = new ListenerHostConfig(sce.getServletContext());
/* 45 */       init.initLogging(config);
/* 46 */       dispatcher = init.initDispatcher(config);
/* 47 */       init.initStaticContentLoader(config, dispatcher);
/*    */ 
/* 49 */       this.prepare = new PrepareOperations(config.getServletContext(), dispatcher);
/* 50 */       sce.getServletContext().setAttribute("com.opensymphony.xwork2.dispatcher.ServletDispatcher", dispatcher);
/*    */     } finally {
/* 52 */       if (dispatcher != null) {
/* 53 */         dispatcher.cleanUpAfterInit();
/*    */       }
/* 55 */       init.cleanup();
/*    */     }
/*    */   }
/*    */ 
/*    */   public void contextDestroyed(ServletContextEvent sce) {
/* 60 */     this.prepare.cleanupDispatcher();
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.dispatcher.ng.listener.StrutsListener
 * JD-Core Version:    0.6.0
 */