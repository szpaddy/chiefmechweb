/*     */ package org.apache.struts2.dispatcher.ng.filter;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.List;
/*     */ import java.util.regex.Pattern;
/*     */ import javax.servlet.Filter;
/*     */ import javax.servlet.FilterChain;
/*     */ import javax.servlet.FilterConfig;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.ServletResponse;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.struts2.StrutsStatics;
/*     */ import org.apache.struts2.dispatcher.Dispatcher;
/*     */ import org.apache.struts2.dispatcher.mapper.ActionMapping;
/*     */ import org.apache.struts2.dispatcher.ng.ExecuteOperations;
/*     */ import org.apache.struts2.dispatcher.ng.InitOperations;
/*     */ import org.apache.struts2.dispatcher.ng.PrepareOperations;
/*     */ 
/*     */ public class StrutsPrepareAndExecuteFilter
/*     */   implements StrutsStatics, Filter
/*     */ {
/*     */   protected PrepareOperations prepare;
/*     */   protected ExecuteOperations execute;
/*  49 */   protected List<Pattern> excludedPatterns = null;
/*     */ 
/*     */   public void init(FilterConfig filterConfig) throws ServletException {
/*  52 */     InitOperations init = new InitOperations();
/*  53 */     Dispatcher dispatcher = null;
/*     */     try {
/*  55 */       FilterHostConfig config = new FilterHostConfig(filterConfig);
/*  56 */       init.initLogging(config);
/*  57 */       dispatcher = init.initDispatcher(config);
/*  58 */       init.initStaticContentLoader(config, dispatcher);
/*     */ 
/*  60 */       this.prepare = new PrepareOperations(filterConfig.getServletContext(), dispatcher);
/*  61 */       this.execute = new ExecuteOperations(filterConfig.getServletContext(), dispatcher);
/*  62 */       this.excludedPatterns = init.buildExcludedPatternsList(dispatcher);
/*     */ 
/*  64 */       postInit(dispatcher, filterConfig);
/*     */     } finally {
/*  66 */       if (dispatcher != null) {
/*  67 */         dispatcher.cleanUpAfterInit();
/*     */       }
/*  69 */       init.cleanup();
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void postInit(Dispatcher dispatcher, FilterConfig filterConfig)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
/*     */     throws IOException, ServletException
/*     */   {
/*  81 */     HttpServletRequest request = (HttpServletRequest)req;
/*  82 */     HttpServletResponse response = (HttpServletResponse)res;
/*     */     try
/*     */     {
/*  85 */       if ((this.excludedPatterns != null) && (this.prepare.isUrlExcluded(request, this.excludedPatterns))) {
/*  86 */         chain.doFilter(request, response);
/*     */       } else {
/*  88 */         this.prepare.setEncodingAndLocale(request, response);
/*  89 */         this.prepare.createActionContext(request, response);
/*  90 */         this.prepare.assignDispatcherToThread();
/*  91 */         request = this.prepare.wrapRequest(request);
/*  92 */         ActionMapping mapping = this.prepare.findActionMapping(request, response, true);
/*  93 */         if (mapping == null) {
/*  94 */           boolean handled = this.execute.executeStaticResourceRequest(request, response);
/*  95 */           if (!handled)
/*  96 */             chain.doFilter(request, response);
/*     */         }
/*     */         else {
/*  99 */           this.execute.executeAction(request, response, mapping);
/*     */         }
/*     */       }
/*     */     } finally {
/* 103 */       this.prepare.cleanupRequest(request);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void destroy() {
/* 108 */     this.prepare.cleanupDispatcher();
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.dispatcher.ng.filter.StrutsPrepareAndExecuteFilter
 * JD-Core Version:    0.6.0
 */