/*     */ package org.apache.struts2.dispatcher.ng.filter;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import javax.servlet.Filter;
/*     */ import javax.servlet.FilterChain;
/*     */ import javax.servlet.FilterConfig;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.ServletResponse;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.struts2.StrutsStatics;
/*     */ import org.apache.struts2.dispatcher.Dispatcher;
/*     */ import org.apache.struts2.dispatcher.mapper.ActionMapping;
/*     */ import org.apache.struts2.dispatcher.ng.ExecuteOperations;
/*     */ import org.apache.struts2.dispatcher.ng.InitOperations;
/*     */ import org.apache.struts2.dispatcher.ng.PrepareOperations;
/*     */ 
/*     */ public class StrutsExecuteFilter
/*     */   implements StrutsStatics, Filter
/*     */ {
/*     */   protected PrepareOperations prepare;
/*     */   protected ExecuteOperations execute;
/*     */   protected FilterConfig filterConfig;
/*     */ 
/*     */   public void init(FilterConfig filterConfig)
/*     */     throws ServletException
/*     */   {
/*  51 */     this.filterConfig = filterConfig;
/*     */   }
/*     */ 
/*     */   protected synchronized void lazyInit() {
/*  55 */     if (this.execute == null) {
/*  56 */       InitOperations init = new InitOperations();
/*  57 */       Dispatcher dispatcher = init.findDispatcherOnThread();
/*  58 */       init.initStaticContentLoader(new FilterHostConfig(this.filterConfig), dispatcher);
/*     */ 
/*  60 */       this.prepare = new PrepareOperations(this.filterConfig.getServletContext(), dispatcher);
/*  61 */       this.execute = new ExecuteOperations(this.filterConfig.getServletContext(), dispatcher);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
/*     */     throws IOException, ServletException
/*     */   {
/*  68 */     HttpServletRequest request = (HttpServletRequest)req;
/*  69 */     HttpServletResponse response = (HttpServletResponse)res;
/*     */ 
/*  71 */     if (excludeUrl(request)) {
/*  72 */       chain.doFilter(request, response);
/*  73 */       return;
/*     */     }
/*     */ 
/*  77 */     if (this.execute == null) {
/*  78 */       lazyInit();
/*     */     }
/*     */ 
/*  81 */     ActionMapping mapping = this.prepare.findActionMapping(request, response);
/*     */ 
/*  85 */     Integer recursionCounter = (Integer)request.getAttribute("__cleanup_recursion_counter");
/*     */ 
/*  87 */     if ((mapping == null) || (recursionCounter.intValue() > 1)) {
/*  88 */       boolean handled = this.execute.executeStaticResourceRequest(request, response);
/*  89 */       if (!handled)
/*  90 */         chain.doFilter(request, response);
/*     */     }
/*     */     else {
/*  93 */       this.execute.executeAction(request, response, mapping);
/*     */     }
/*     */   }
/*     */ 
/*     */   private boolean excludeUrl(HttpServletRequest request) {
/*  98 */     return request.getAttribute(StrutsPrepareFilter.REQUEST_EXCLUDED_FROM_ACTION_MAPPING) != null;
/*     */   }
/*     */ 
/*     */   public void destroy() {
/* 102 */     this.prepare = null;
/* 103 */     this.execute = null;
/* 104 */     this.filterConfig = null;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.dispatcher.ng.filter.StrutsExecuteFilter
 * JD-Core Version:    0.6.0
 */