/*    */ package org.apache.struts2.dispatcher.ng.servlet;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import javax.servlet.ServletConfig;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.http.HttpServlet;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.apache.struts2.dispatcher.Dispatcher;
/*    */ import org.apache.struts2.dispatcher.mapper.ActionMapping;
/*    */ import org.apache.struts2.dispatcher.ng.ExecuteOperations;
/*    */ import org.apache.struts2.dispatcher.ng.InitOperations;
/*    */ import org.apache.struts2.dispatcher.ng.PrepareOperations;
/*    */ 
/*    */ public class StrutsServlet extends HttpServlet
/*    */ {
/*    */   private PrepareOperations prepare;
/*    */   private ExecuteOperations execute;
/*    */ 
/*    */   public void init(ServletConfig filterConfig)
/*    */     throws ServletException
/*    */   {
/* 49 */     InitOperations init = new InitOperations();
/* 50 */     Dispatcher dispatcher = null;
/*    */     try {
/* 52 */       ServletHostConfig config = new ServletHostConfig(filterConfig);
/* 53 */       init.initLogging(config);
/* 54 */       dispatcher = init.initDispatcher(config);
/* 55 */       init.initStaticContentLoader(config, dispatcher);
/*    */ 
/* 57 */       this.prepare = new PrepareOperations(filterConfig.getServletContext(), dispatcher);
/* 58 */       this.execute = new ExecuteOperations(filterConfig.getServletContext(), dispatcher);
/*    */     } finally {
/* 60 */       if (dispatcher != null) {
/* 61 */         dispatcher.cleanUpAfterInit();
/*    */       }
/* 63 */       init.cleanup();
/*    */     }
/*    */   }
/*    */ 
/*    */   public void service(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException
/*    */   {
/*    */     try
/*    */     {
/* 71 */       this.prepare.createActionContext(request, response);
/* 72 */       this.prepare.assignDispatcherToThread();
/* 73 */       this.prepare.setEncodingAndLocale(request, response);
/* 74 */       request = this.prepare.wrapRequest(request);
/* 75 */       ActionMapping mapping = this.prepare.findActionMapping(request, response);
/* 76 */       if (mapping == null) {
/* 77 */         boolean handled = this.execute.executeStaticResourceRequest(request, response);
/* 78 */         if (!handled)
/* 79 */           throw new ServletException("Resource loading not supported, use the StrutsPrepareAndExecuteFilter instead.");
/*    */       } else {
/* 81 */         this.execute.executeAction(request, response, mapping);
/*    */       }
/*    */     } finally {
/* 84 */       this.prepare.cleanupRequest(request);
/*    */     }
/*    */   }
/*    */ 
/*    */   public void destroy()
/*    */   {
/* 90 */     this.prepare.cleanupDispatcher();
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.dispatcher.ng.servlet.StrutsServlet
 * JD-Core Version:    0.6.0
 */