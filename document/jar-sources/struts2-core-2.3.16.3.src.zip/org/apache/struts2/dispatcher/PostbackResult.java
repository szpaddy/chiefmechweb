/*     */ package org.apache.struts2.dispatcher;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionContext;
/*     */ import com.opensymphony.xwork2.ActionInvocation;
/*     */ import com.opensymphony.xwork2.ActionProxy;
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.net.URLEncoder;
/*     */ import java.util.Map;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.struts2.dispatcher.mapper.ActionMapper;
/*     */ import org.apache.struts2.dispatcher.mapper.ActionMapping;
/*     */ 
/*     */ public class PostbackResult extends StrutsResultSupport
/*     */ {
/*     */   private String actionName;
/*     */   private String namespace;
/*     */   private String method;
/*  78 */   private boolean prependServletContext = true;
/*  79 */   private boolean cache = true;
/*     */   protected ActionMapper actionMapper;
/*     */ 
/*     */   protected void doExecute(String finalLocation, ActionInvocation invocation)
/*     */     throws Exception
/*     */   {
/*  85 */     ActionContext ctx = invocation.getInvocationContext();
/*  86 */     HttpServletRequest request = (HttpServletRequest)ctx.get("com.opensymphony.xwork2.dispatcher.HttpServletRequest");
/*  87 */     HttpServletResponse response = (HttpServletResponse)ctx.get("com.opensymphony.xwork2.dispatcher.HttpServletResponse");
/*     */ 
/*  90 */     if (!this.cache) {
/*  91 */       response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
/*  92 */       response.setHeader("Pragma", "no-cache");
/*  93 */       response.setDateHeader("Expires", 0L);
/*     */     }
/*     */ 
/*  97 */     PrintWriter pw = new PrintWriter(response.getOutputStream());
/*  98 */     pw.write("<!DOCTYPE html><html><body><form action=\"" + finalLocation + "\" method=\"POST\">");
/*  99 */     writeFormElements(request, pw);
/* 100 */     writePrologueScript(pw);
/* 101 */     pw.write("</html>");
/* 102 */     pw.flush();
/*     */   }
/*     */ 
/*     */   public void execute(ActionInvocation invocation) throws Exception
/*     */   {
/* 107 */     String postbackUri = makePostbackUri(invocation);
/* 108 */     setLocation(postbackUri);
/* 109 */     super.execute(invocation);
/*     */   }
/*     */ 
/*     */   protected boolean isElementIncluded(String name, String[] values)
/*     */   {
/* 120 */     return !name.startsWith("action:");
/*     */   }
/*     */ 
/*     */   protected String makePostbackUri(ActionInvocation invocation) {
/* 124 */     ActionContext ctx = invocation.getInvocationContext();
/* 125 */     HttpServletRequest request = (HttpServletRequest)ctx.get("com.opensymphony.xwork2.dispatcher.HttpServletRequest");
/*     */     String postbackUri;
/*     */     String postbackUri;
/* 128 */     if (this.actionName != null) {
/* 129 */       this.actionName = conditionalParse(this.actionName, invocation);
/* 130 */       if (this.namespace == null)
/* 131 */         this.namespace = invocation.getProxy().getNamespace();
/*     */       else {
/* 133 */         this.namespace = conditionalParse(this.namespace, invocation);
/*     */       }
/* 135 */       if (this.method == null)
/* 136 */         this.method = "";
/*     */       else {
/* 138 */         this.method = conditionalParse(this.method, invocation);
/*     */       }
/* 140 */       postbackUri = request.getContextPath() + this.actionMapper.getUriFromActionMapping(new ActionMapping(this.actionName, this.namespace, this.method, null));
/*     */     } else {
/* 142 */       String location = getLocation();
/*     */ 
/* 144 */       if (!location.matches("^([a-zA-z]+:)?//.*"))
/*     */       {
/* 146 */         if ((this.prependServletContext) && (request.getContextPath() != null) && (request.getContextPath().length() > 0)) {
/* 147 */           location = request.getContextPath() + location;
/*     */         }
/*     */       }
/* 150 */       postbackUri = location;
/*     */     }
/*     */ 
/* 153 */     return postbackUri;
/*     */   }
/*     */   @Inject
/*     */   public final void setActionMapper(ActionMapper mapper) {
/* 158 */     this.actionMapper = mapper;
/*     */   }
/*     */ 
/*     */   public final void setActionName(String actionName)
/*     */   {
/* 167 */     this.actionName = actionName;
/*     */   }
/*     */ 
/*     */   public final void setCache(boolean cache)
/*     */   {
/* 177 */     this.cache = cache;
/*     */   }
/*     */ 
/*     */   public final void setMethod(String method)
/*     */   {
/* 186 */     this.method = method;
/*     */   }
/*     */ 
/*     */   public final void setNamespace(String namespace)
/*     */   {
/* 195 */     this.namespace = namespace;
/*     */   }
/*     */ 
/*     */   public final void setPrependServletContext(boolean prependServletContext) {
/* 199 */     this.prependServletContext = prependServletContext;
/*     */   }
/*     */ 
/*     */   protected void writeFormElement(PrintWriter pw, String name, String[] values) throws UnsupportedEncodingException {
/* 203 */     for (String value : values) {
/* 204 */       String encName = URLEncoder.encode(name, "UTF-8");
/* 205 */       String encValue = URLEncoder.encode(value, "UTF-8");
/* 206 */       pw.write("<input type=\"hidden\" name=\"" + encName + "\" value=\"" + encValue + "\"/>");
/*     */     }
/*     */   }
/*     */ 
/*     */   private void writeFormElements(HttpServletRequest request, PrintWriter pw) throws UnsupportedEncodingException {
/* 211 */     Map params = request.getParameterMap();
/* 212 */     for (String name : params.keySet()) {
/* 213 */       String[] values = (String[])params.get(name);
/* 214 */       if (isElementIncluded(name, values))
/* 215 */         writeFormElement(pw, name, values);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void writePrologueScript(PrintWriter pw)
/*     */   {
/* 227 */     pw.write("<script>");
/* 228 */     pw.write("setTimeout(function(){document.forms[0].submit();},0);");
/* 229 */     pw.write("</script>");
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.dispatcher.PostbackResult
 * JD-Core Version:    0.6.0
 */