package org.apache.struts2.dispatcher.mapper;

import com.opensymphony.xwork2.config.ConfigurationManager;
import javax.servlet.http.HttpServletRequest;

public abstract interface ActionMapper
{
  public abstract ActionMapping getMapping(HttpServletRequest paramHttpServletRequest, ConfigurationManager paramConfigurationManager);

  public abstract ActionMapping getMappingFromActionName(String paramString);

  public abstract String getUriFromActionMapping(ActionMapping paramActionMapping);
}

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.dispatcher.mapper.ActionMapper
 * JD-Core Version:    0.6.0
 */