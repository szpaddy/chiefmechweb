/*     */ package org.apache.struts2.dispatcher.mapper;
/*     */ 
/*     */ import com.opensymphony.xwork2.config.ConfigurationManager;
/*     */ import com.opensymphony.xwork2.util.logging.Logger;
/*     */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*     */ import java.net.URLDecoder;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.StringTokenizer;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.apache.struts2.RequestUtils;
/*     */ 
/*     */ public class RestfulActionMapper
/*     */   implements ActionMapper
/*     */ {
/*  41 */   protected static final Logger LOG = LoggerFactory.getLogger(RestfulActionMapper.class);
/*     */ 
/*     */   public ActionMapping getMapping(HttpServletRequest request, ConfigurationManager configManager)
/*     */   {
/*  47 */     String uri = RequestUtils.getServletPath(request);
/*     */ 
/*  49 */     int nextSlash = uri.indexOf('/', 1);
/*  50 */     if (nextSlash == -1) {
/*  51 */       return null;
/*     */     }
/*     */ 
/*  54 */     String actionName = uri.substring(1, nextSlash);
/*  55 */     Map parameters = new HashMap();
/*     */     try {
/*  57 */       StringTokenizer st = new StringTokenizer(uri.substring(nextSlash), "/");
/*  58 */       boolean isNameTok = true;
/*  59 */       String paramName = null;
/*     */ 
/*  63 */       if (st.countTokens() % 2 != 0) {
/*  64 */         isNameTok = false;
/*  65 */         paramName = actionName + "Id";
/*     */       }
/*     */ 
/*  68 */       while (st.hasMoreTokens()) {
/*  69 */         if (isNameTok) {
/*  70 */           paramName = URLDecoder.decode(st.nextToken(), "UTF-8");
/*  71 */           isNameTok = false; continue;
/*     */         }
/*  73 */         String paramValue = URLDecoder.decode(st.nextToken(), "UTF-8");
/*     */ 
/*  75 */         if ((paramName != null) && (paramName.length() > 0)) {
/*  76 */           parameters.put(paramName, paramValue);
/*     */         }
/*     */ 
/*  79 */         isNameTok = true;
/*     */       }
/*     */     }
/*     */     catch (Exception e) {
/*  83 */       if (LOG.isWarnEnabled()) {
/*  84 */         LOG.warn("Cannot determine url parameters", e, new String[0]);
/*     */       }
/*     */     }
/*     */ 
/*  88 */     return new ActionMapping(actionName, "", "", parameters);
/*     */   }
/*     */ 
/*     */   public ActionMapping getMappingFromActionName(String actionName) {
/*  92 */     return new ActionMapping(actionName, null, null, null);
/*     */   }
/*     */ 
/*     */   public String getUriFromActionMapping(ActionMapping mapping)
/*     */   {
/*  99 */     StringBuilder retVal = new StringBuilder();
/* 100 */     retVal.append(mapping.getNamespace());
/* 101 */     retVal.append(mapping.getName());
/* 102 */     Object value = mapping.getParams().get(mapping.getName() + "Id");
/* 103 */     if (value != null) {
/* 104 */       retVal.append("/");
/* 105 */       retVal.append(value);
/*     */     }
/*     */ 
/* 108 */     return retVal.toString();
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.dispatcher.mapper.RestfulActionMapper
 * JD-Core Version:    0.6.0
 */