/*     */ package org.apache.struts2.dispatcher.mapper;
/*     */ 
/*     */ import com.opensymphony.xwork2.config.ConfigurationManager;
/*     */ import com.opensymphony.xwork2.inject.Container;
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import com.opensymphony.xwork2.util.logging.Logger;
/*     */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.apache.struts2.RequestUtils;
/*     */ 
/*     */ public class PrefixBasedActionMapper extends DefaultActionMapper
/*     */   implements ActionMapper
/*     */ {
/*  44 */   private static final Logger LOG = LoggerFactory.getLogger(PrefixBasedActionMapper.class);
/*     */   protected Container container;
/*  47 */   protected Map<String, ActionMapper> actionMappers = new HashMap();
/*     */ 
/*  51 */   @Inject
/*     */   public void setContainer(Container container) { this.container = container; }
/*     */ 
/*     */   @Inject("struts.mapper.prefixMapping")
/*     */   public void setPrefixBasedActionMappers(String list) {
/*  56 */     if (list != null) {
/*  57 */       String[] mappers = list.split(",");
/*  58 */       for (String mapper : mappers) {
/*  59 */         String[] thisMapper = mapper.split(":");
/*  60 */         if ((thisMapper != null) && (thisMapper.length == 2)) {
/*  61 */           String mapperPrefix = thisMapper[0].trim();
/*  62 */           String mapperName = thisMapper[1].trim();
/*  63 */           Object obj = this.container.getInstance(ActionMapper.class, mapperName);
/*  64 */           if (obj != null)
/*  65 */             this.actionMappers.put(mapperPrefix, (ActionMapper)obj);
/*  66 */           else if (LOG.isDebugEnabled())
/*  67 */             LOG.debug("invalid PrefixBasedActionMapper config entry: [#0]", new String[] { mapper });
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public ActionMapping getMapping(HttpServletRequest request, ConfigurationManager configManager)
/*     */   {
/*  77 */     String uri = RequestUtils.getUri(request);
/*  78 */     for (int lastIndex = uri.lastIndexOf('/'); lastIndex > -1; lastIndex = uri.lastIndexOf('/', lastIndex - 1)) {
/*  79 */       ActionMapper actionMapper = (ActionMapper)this.actionMappers.get(uri.substring(0, lastIndex));
/*  80 */       if (actionMapper != null) {
/*  81 */         ActionMapping actionMapping = actionMapper.getMapping(request, configManager);
/*  82 */         if (LOG.isDebugEnabled()) {
/*  83 */           LOG.debug("Using ActionMapper [#0]", new String[] { actionMapper.toString() });
/*     */         }
/*  85 */         if (actionMapping != null) {
/*  86 */           if ((LOG.isDebugEnabled()) && 
/*  87 */             (actionMapping.getParams() != null)) {
/*  88 */             LOG.debug("ActionMapper found mapping. Parameters: [#0]", new String[] { actionMapping.getParams().toString() });
/*  89 */             for (Map.Entry mappingParameterEntry : actionMapping.getParams().entrySet()) {
/*  90 */               Object paramValue = mappingParameterEntry.getValue();
/*  91 */               if (paramValue == null)
/*  92 */                 LOG.debug("[#0] : null!", new String[] { (String)mappingParameterEntry.getKey() });
/*  93 */               else if ((paramValue instanceof String[]))
/*  94 */                 LOG.debug("[#0] : (String[]) #1", new String[] { (String)mappingParameterEntry.getKey(), Arrays.toString((String[])(String[])paramValue) });
/*  95 */               else if ((paramValue instanceof String))
/*  96 */                 LOG.debug("[#0] : (String) [#1]", new String[] { (String)mappingParameterEntry.getKey(), paramValue.toString() });
/*     */               else {
/*  98 */                 LOG.debug("[#0] : (Object) [#1]", new String[] { (String)mappingParameterEntry.getKey(), paramValue.toString() });
/*     */               }
/*     */             }
/*     */           }
/*     */ 
/* 103 */           return actionMapping;
/* 104 */         }if (LOG.isDebugEnabled()) {
/* 105 */           LOG.debug("ActionMapper [#0] failed to return an ActionMapping", new String[] { actionMapper.toString() });
/*     */         }
/*     */       }
/*     */     }
/* 109 */     if (LOG.isDebugEnabled()) {
/* 110 */       LOG.debug("No ActionMapper found", new String[0]);
/*     */     }
/* 112 */     return null;
/*     */   }
/*     */ 
/*     */   public String getUriFromActionMapping(ActionMapping mapping) {
/* 116 */     String namespace = mapping.getNamespace();
/* 117 */     for (int lastIndex = namespace.length(); lastIndex > -1; lastIndex = namespace.lastIndexOf('/', lastIndex - 1)) {
/* 118 */       ActionMapper actionMapper = (ActionMapper)this.actionMappers.get(namespace.substring(0, lastIndex));
/* 119 */       if (actionMapper != null) {
/* 120 */         String uri = actionMapper.getUriFromActionMapping(mapping);
/* 121 */         if (LOG.isDebugEnabled()) {
/* 122 */           LOG.debug("Using ActionMapper [#0]", new String[] { actionMapper.toString() });
/*     */         }
/* 124 */         if (uri != null)
/* 125 */           return uri;
/* 126 */         if (LOG.isDebugEnabled()) {
/* 127 */           LOG.debug("ActionMapper [#0] failed to return an ActionMapping (null)", new String[] { actionMapper.toString() });
/*     */         }
/*     */       }
/*     */     }
/* 131 */     if (LOG.isDebugEnabled()) {
/* 132 */       LOG.debug("ActionMapper failed to return a uri", new String[0]);
/*     */     }
/* 134 */     return null;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.dispatcher.mapper.PrefixBasedActionMapper
 * JD-Core Version:    0.6.0
 */