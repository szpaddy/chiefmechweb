/*     */ package org.apache.struts2.dispatcher.mapper;
/*     */ 
/*     */ import com.opensymphony.xwork2.config.ConfigurationManager;
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import com.opensymphony.xwork2.util.logging.Logger;
/*     */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*     */ import java.net.URLDecoder;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.StringTokenizer;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ 
/*     */ public class Restful2ActionMapper extends DefaultActionMapper
/*     */ {
/*  41 */   protected static final Logger LOG = LoggerFactory.getLogger(Restful2ActionMapper.class);
/*     */   public static final String HTTP_METHOD_PARAM = "__http_method";
/*  43 */   private String idParameterName = null;
/*     */ 
/*     */   public Restful2ActionMapper() {
/*  46 */     setSlashesInActionNames("true");
/*     */   }
/*     */ 
/*     */   public ActionMapping getMapping(HttpServletRequest request, ConfigurationManager configManager)
/*     */   {
/*  55 */     if (!isSlashesInActionNames()) {
/*  56 */       throw new IllegalStateException("This action mapper requires the setting 'slashesInActionNames' to be set to 'true'");
/*     */     }
/*  58 */     ActionMapping mapping = super.getMapping(request, configManager);
/*     */ 
/*  60 */     if (mapping == null) {
/*  61 */       return null;
/*     */     }
/*     */ 
/*  64 */     String actionName = mapping.getName();
/*     */ 
/*  66 */     String id = null;
/*     */ 
/*  69 */     if ((actionName != null) && (actionName.length() > 0))
/*     */     {
/*  71 */       int lastSlashPos = actionName.lastIndexOf('/');
/*  72 */       if (lastSlashPos > -1) {
/*  73 */         id = actionName.substring(lastSlashPos + 1);
/*     */       }
/*     */ 
/*  78 */       if (mapping.getMethod() == null)
/*     */       {
/*  80 */         if (lastSlashPos == actionName.length() - 1)
/*     */         {
/*  83 */           if (isGet(request)) {
/*  84 */             mapping.setMethod("index");
/*     */           }
/*  87 */           else if (isPost(request)) {
/*  88 */             mapping.setMethod("create");
/*     */           }
/*     */         }
/*  91 */         else if (lastSlashPos > -1)
/*     */         {
/*  93 */           if ((isGet(request)) && ("new".equals(id))) {
/*  94 */             mapping.setMethod("editNew");
/*     */           }
/*  97 */           else if (isGet(request)) {
/*  98 */             mapping.setMethod("view");
/*     */           }
/* 101 */           else if (isDelete(request)) {
/* 102 */             mapping.setMethod("remove");
/*     */           }
/* 105 */           else if (isPut(request)) {
/* 106 */             mapping.setMethod("update");
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/* 111 */         if ((this.idParameterName != null) && (lastSlashPos > -1)) {
/* 112 */           actionName = actionName.substring(0, lastSlashPos);
/*     */         }
/*     */       }
/*     */ 
/* 116 */       if ((this.idParameterName != null) && (id != null)) {
/* 117 */         if (mapping.getParams() == null) {
/* 118 */           mapping.setParams(new HashMap());
/*     */         }
/* 120 */         mapping.getParams().put(this.idParameterName, id);
/*     */       }
/*     */ 
/* 124 */       int actionSlashPos = actionName.lastIndexOf('/', lastSlashPos - 1);
/* 125 */       if ((actionSlashPos > 0) && (actionSlashPos < lastSlashPos)) {
/* 126 */         String params = actionName.substring(0, actionSlashPos);
/* 127 */         HashMap parameters = new HashMap();
/*     */         try {
/* 129 */           StringTokenizer st = new StringTokenizer(params, "/");
/* 130 */           boolean isNameTok = true;
/* 131 */           String paramName = null;
/*     */ 
/* 134 */           while (st.hasMoreTokens()) {
/* 135 */             if (isNameTok) {
/* 136 */               paramName = URLDecoder.decode(st.nextToken(), "UTF-8");
/* 137 */               isNameTok = false; continue;
/*     */             }
/* 139 */             String paramValue = URLDecoder.decode(st.nextToken(), "UTF-8");
/*     */ 
/* 141 */             if ((paramName != null) && (paramName.length() > 0)) {
/* 142 */               parameters.put(paramName, paramValue);
/*     */             }
/*     */ 
/* 145 */             isNameTok = true;
/*     */           }
/*     */ 
/* 148 */           if (parameters.size() > 0) {
/* 149 */             if (mapping.getParams() == null) {
/* 150 */               mapping.setParams(new HashMap());
/*     */             }
/* 152 */             mapping.getParams().putAll(parameters);
/*     */           }
/*     */         } catch (Exception e) {
/* 155 */           if (LOG.isWarnEnabled()) {
/* 156 */             LOG.warn("Unable to determine parameters from the url", e, new String[0]);
/*     */           }
/*     */         }
/* 159 */         mapping.setName(actionName.substring(actionSlashPos + 1));
/*     */       }
/*     */     }
/*     */ 
/* 163 */     return mapping;
/*     */   }
/*     */ 
/*     */   protected boolean isGet(HttpServletRequest request) {
/* 167 */     return "get".equalsIgnoreCase(request.getMethod());
/*     */   }
/*     */ 
/*     */   protected boolean isPost(HttpServletRequest request) {
/* 171 */     return "post".equalsIgnoreCase(request.getMethod());
/*     */   }
/*     */ 
/*     */   protected boolean isPut(HttpServletRequest request) {
/* 175 */     if ("put".equalsIgnoreCase(request.getMethod())) {
/* 176 */       return true;
/*     */     }
/* 178 */     return (isPost(request)) && ("put".equalsIgnoreCase(request.getParameter("__http_method")));
/*     */   }
/*     */ 
/*     */   protected boolean isDelete(HttpServletRequest request)
/*     */   {
/* 183 */     if ("delete".equalsIgnoreCase(request.getMethod())) {
/* 184 */       return true;
/*     */     }
/* 186 */     return (isPost(request)) && ("delete".equalsIgnoreCase(request.getParameter("__http_method")));
/*     */   }
/*     */ 
/*     */   public String getIdParameterName()
/*     */   {
/* 191 */     return this.idParameterName;
/*     */   }
/*     */   @Inject(required=false, value="struts.mapper.idParameterName")
/*     */   public void setIdParameterName(String idParameterName) {
/* 196 */     this.idParameterName = idParameterName;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.dispatcher.mapper.Restful2ActionMapper
 * JD-Core Version:    0.6.0
 */