/*     */ package org.apache.struts2.dispatcher.mapper;
/*     */ 
/*     */ import com.opensymphony.xwork2.Result;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class ActionMapping
/*     */ {
/*     */   private String name;
/*     */   private String namespace;
/*     */   private String method;
/*     */   private String extension;
/*     */   private Map<String, Object> params;
/*     */   private Result result;
/*     */ 
/*     */   public ActionMapping()
/*     */   {
/*     */   }
/*     */ 
/*     */   public ActionMapping(Result result)
/*     */   {
/*  55 */     this.result = result;
/*     */   }
/*     */ 
/*     */   public ActionMapping(String name, String namespace, String method, Map<String, Object> params)
/*     */   {
/*  67 */     this.name = name;
/*  68 */     this.namespace = namespace;
/*  69 */     this.method = method;
/*  70 */     this.params = params;
/*     */   }
/*     */ 
/*     */   public String getName()
/*     */   {
/*  77 */     return this.name;
/*     */   }
/*     */ 
/*     */   public String getNamespace()
/*     */   {
/*  84 */     return this.namespace;
/*     */   }
/*     */ 
/*     */   public Map<String, Object> getParams()
/*     */   {
/*  91 */     return this.params;
/*     */   }
/*     */ 
/*     */   public String getMethod()
/*     */   {
/*  98 */     if ((null != this.method) && ("".equals(this.method))) {
/*  99 */       return null;
/*     */     }
/* 101 */     return this.method;
/*     */   }
/*     */ 
/*     */   public Result getResult()
/*     */   {
/* 109 */     return this.result;
/*     */   }
/*     */ 
/*     */   public String getExtension()
/*     */   {
/* 116 */     return this.extension;
/*     */   }
/*     */ 
/*     */   public void setResult(Result result)
/*     */   {
/* 123 */     this.result = result;
/*     */   }
/*     */ 
/*     */   public void setName(String name)
/*     */   {
/* 130 */     this.name = name;
/*     */   }
/*     */ 
/*     */   public void setNamespace(String namespace)
/*     */   {
/* 137 */     this.namespace = namespace;
/*     */   }
/*     */ 
/*     */   public void setMethod(String method)
/*     */   {
/* 144 */     this.method = method;
/*     */   }
/*     */ 
/*     */   public void setParams(Map<String, Object> params)
/*     */   {
/* 151 */     this.params = params;
/*     */   }
/*     */ 
/*     */   public void setExtension(String extension)
/*     */   {
/* 158 */     this.extension = extension;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 163 */     return "ActionMapping{name='" + this.name + '\'' + ", namespace='" + this.namespace + '\'' + ", method='" + this.method + '\'' + ", extension='" + this.extension + '\'' + ", params=" + this.params + ", result=" + (this.result != null ? this.result.getClass().getName() : "null") + '}';
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.dispatcher.mapper.ActionMapping
 * JD-Core Version:    0.6.0
 */