/*     */ package org.apache.struts2.dispatcher.mapper;
/*     */ 
/*     */ import com.opensymphony.xwork2.config.ConfigurationManager;
/*     */ import com.opensymphony.xwork2.inject.Container;
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import com.opensymphony.xwork2.util.logging.Logger;
/*     */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ 
/*     */ public class CompositeActionMapper
/*     */   implements ActionMapper
/*     */ {
/*  50 */   private static final Logger LOG = LoggerFactory.getLogger(CompositeActionMapper.class);
/*     */ 
/*  52 */   protected List<ActionMapper> actionMappers = new LinkedList();
/*     */ 
/*     */   @Inject
/*     */   public CompositeActionMapper(Container container, @Inject("struts.mapper.composite") String list) {
/*  57 */     if (list != null) {
/*  58 */       String[] arr = list.split(",");
/*  59 */       for (String name : arr) {
/*  60 */         Object obj = container.getInstance(ActionMapper.class, name);
/*  61 */         if (obj != null)
/*  62 */           this.actionMappers.add((ActionMapper)obj);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public ActionMapping getMapping(HttpServletRequest request, ConfigurationManager configManager)
/*     */   {
/*  70 */     for (ActionMapper actionMapper : this.actionMappers) {
/*  71 */       ActionMapping actionMapping = actionMapper.getMapping(request, configManager);
/*  72 */       if (LOG.isDebugEnabled()) {
/*  73 */         LOG.debug("Using ActionMapper " + actionMapper, new String[0]);
/*     */       }
/*  75 */       if (actionMapping == null) {
/*  76 */         if (LOG.isDebugEnabled()) {
/*  77 */           LOG.debug("ActionMapper " + actionMapper + " failed to return an ActionMapping (null)", new String[0]);
/*     */         }
/*     */       }
/*     */       else {
/*  81 */         return actionMapping;
/*     */       }
/*     */     }
/*  84 */     if (LOG.isDebugEnabled()) {
/*  85 */       LOG.debug("exhausted from ActionMapper that could return an ActionMapping", new String[0]);
/*     */     }
/*  87 */     return null;
/*     */   }
/*     */ 
/*     */   public ActionMapping getMappingFromActionName(String actionName)
/*     */   {
/*  92 */     for (ActionMapper actionMapper : this.actionMappers) {
/*  93 */       ActionMapping actionMapping = actionMapper.getMappingFromActionName(actionName);
/*  94 */       if (LOG.isDebugEnabled()) {
/*  95 */         LOG.debug("Using ActionMapper " + actionMapper, new String[0]);
/*     */       }
/*  97 */       if (actionMapping == null) {
/*  98 */         if (LOG.isDebugEnabled()) {
/*  99 */           LOG.debug("ActionMapper " + actionMapper + " failed to return an ActionMapping (null)", new String[0]);
/*     */         }
/*     */       }
/*     */       else {
/* 103 */         return actionMapping;
/*     */       }
/*     */     }
/* 106 */     if (LOG.isDebugEnabled()) {
/* 107 */       LOG.debug("exhausted from ActionMapper that could return an ActionMapping", new String[0]);
/*     */     }
/* 109 */     return null;
/*     */   }
/*     */ 
/*     */   public String getUriFromActionMapping(ActionMapping mapping)
/*     */   {
/* 114 */     for (ActionMapper actionMapper : this.actionMappers) {
/* 115 */       String uri = actionMapper.getUriFromActionMapping(mapping);
/* 116 */       if (LOG.isDebugEnabled()) {
/* 117 */         LOG.debug("Using ActionMapper " + actionMapper, new String[0]);
/*     */       }
/* 119 */       if (uri == null) {
/* 120 */         if (LOG.isDebugEnabled()) {
/* 121 */           LOG.debug("ActionMapper " + actionMapper + " failed to return an ActionMapping (null)", new String[0]);
/*     */         }
/*     */       }
/*     */       else {
/* 125 */         return uri;
/*     */       }
/*     */     }
/* 128 */     if (LOG.isDebugEnabled()) {
/* 129 */       LOG.debug("exhausted from ActionMapper that could return a uri", new String[0]);
/*     */     }
/* 131 */     return null;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.dispatcher.mapper.CompositeActionMapper
 * JD-Core Version:    0.6.0
 */