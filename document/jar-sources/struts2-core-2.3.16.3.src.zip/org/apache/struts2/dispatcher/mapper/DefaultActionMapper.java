/*     */ package org.apache.struts2.dispatcher.mapper;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionContext;
/*     */ import com.opensymphony.xwork2.config.Configuration;
/*     */ import com.opensymphony.xwork2.config.ConfigurationManager;
/*     */ import com.opensymphony.xwork2.config.entities.PackageConfig;
/*     */ import com.opensymphony.xwork2.inject.Container;
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import com.opensymphony.xwork2.util.logging.Logger;
/*     */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.apache.commons.lang3.StringUtils;
/*     */ import org.apache.struts2.RequestUtils;
/*     */ import org.apache.struts2.util.PrefixTrie;
/*     */ 
/*     */ public class DefaultActionMapper
/*     */   implements ActionMapper
/*     */ {
/* 113 */   private static final Logger LOG = LoggerFactory.getLogger(DefaultActionMapper.class);
/*     */   protected static final String METHOD_PREFIX = "method:";
/*     */   protected static final String ACTION_PREFIX = "action:";
/* 118 */   protected boolean allowDynamicMethodCalls = false;
/* 119 */   protected boolean allowSlashesInActionNames = false;
/* 120 */   protected boolean alwaysSelectFullNamespace = false;
/* 121 */   protected PrefixTrie prefixTrie = null;
/* 122 */   protected Pattern allowedActionNames = Pattern.compile("[a-zA-Z0-9._!/\\-]*");
/* 123 */   private boolean allowActionPrefix = false;
/* 124 */   private boolean allowActionCrossNamespaceAccess = false;
/*     */ 
/* 126 */   protected List<String> extensions = new ArrayList() { } ;
/*     */   protected Container container;
/*     */ 
/*     */   public DefaultActionMapper()
/*     */   {
/* 134 */     this.prefixTrie = new PrefixTrie()
/*     */     {
/*     */     };
/*     */   }
/*     */ 
/*     */   protected void addParameterAction(String prefix, ParameterAction parameterAction)
/*     */   {
/* 184 */     this.prefixTrie.put(prefix, parameterAction);
/*     */   }
/*     */   @Inject("struts.enable.DynamicMethodInvocation")
/*     */   public void setAllowDynamicMethodCalls(String allow) {
/* 189 */     this.allowDynamicMethodCalls = "true".equalsIgnoreCase(allow);
/*     */   }
/*     */   @Inject("struts.enable.SlashesInActionNames")
/*     */   public void setSlashesInActionNames(String allow) {
/* 194 */     this.allowSlashesInActionNames = "true".equals(allow);
/*     */   }
/*     */   @Inject("struts.mapper.alwaysSelectFullNamespace")
/*     */   public void setAlwaysSelectFullNamespace(String val) {
/* 199 */     this.alwaysSelectFullNamespace = "true".equals(val);
/*     */   }
/*     */   @Inject(value="struts.allowed.action.names", required=false)
/*     */   public void setAllowedActionNames(String allowedActionNames) {
/* 204 */     this.allowedActionNames = Pattern.compile(allowedActionNames);
/*     */   }
/*     */   @Inject("struts.mapper.action.prefix.enabled")
/*     */   public void setAllowActionPrefix(String allowActionPrefix) {
/* 209 */     this.allowActionPrefix = "true".equalsIgnoreCase(allowActionPrefix);
/*     */   }
/*     */   @Inject("struts.mapper.action.prefix.crossNamespaces")
/*     */   public void setAllowActionCrossNamespaceAccess(String allowActionCrossNamespaceAccess) {
/* 214 */     this.allowActionCrossNamespaceAccess = "true".equalsIgnoreCase(allowActionCrossNamespaceAccess);
/*     */   }
/*     */   @Inject
/*     */   public void setContainer(Container container) {
/* 219 */     this.container = container;
/*     */   }
/*     */   @Inject("struts.action.extension")
/*     */   public void setExtensions(String extensions) {
/* 224 */     if ((extensions != null) && (!"".equals(extensions))) {
/* 225 */       List list = new ArrayList();
/* 226 */       String[] tokens = extensions.split(",");
/* 227 */       Collections.addAll(list, tokens);
/* 228 */       if (extensions.endsWith(",")) {
/* 229 */         list.add("");
/*     */       }
/* 231 */       this.extensions = Collections.unmodifiableList(list);
/*     */     } else {
/* 233 */       this.extensions = null;
/*     */     }
/*     */   }
/*     */ 
/*     */   public ActionMapping getMappingFromActionName(String actionName) {
/* 238 */     ActionMapping mapping = new ActionMapping();
/* 239 */     mapping.setName(actionName);
/* 240 */     return parseActionName(mapping);
/*     */   }
/*     */ 
/*     */   public boolean isSlashesInActionNames() {
/* 244 */     return this.allowSlashesInActionNames;
/*     */   }
/*     */ 
/*     */   public ActionMapping getMapping(HttpServletRequest request, ConfigurationManager configManager)
/*     */   {
/* 253 */     ActionMapping mapping = new ActionMapping();
/* 254 */     String uri = RequestUtils.getUri(request);
/*     */ 
/* 256 */     int indexOfSemicolon = uri.indexOf(";");
/* 257 */     uri = indexOfSemicolon > -1 ? uri.substring(0, indexOfSemicolon) : uri;
/*     */ 
/* 259 */     uri = dropExtension(uri, mapping);
/* 260 */     if (uri == null) {
/* 261 */       return null;
/*     */     }
/*     */ 
/* 264 */     parseNameAndNamespace(uri, mapping, configManager);
/* 265 */     handleSpecialParameters(request, mapping);
/* 266 */     return parseActionName(mapping);
/*     */   }
/*     */ 
/*     */   protected ActionMapping parseActionName(ActionMapping mapping) {
/* 270 */     if (mapping.getName() == null) {
/* 271 */       return null;
/*     */     }
/* 273 */     if (this.allowDynamicMethodCalls)
/*     */     {
/* 275 */       String name = mapping.getName();
/* 276 */       int exclamation = name.lastIndexOf("!");
/* 277 */       if (exclamation != -1) {
/* 278 */         mapping.setName(name.substring(0, exclamation));
/*     */ 
/* 280 */         mapping.setMethod(name.substring(exclamation + 1));
/*     */       }
/*     */     }
/* 283 */     return mapping;
/*     */   }
/*     */ 
/*     */   public void handleSpecialParameters(HttpServletRequest request, ActionMapping mapping)
/*     */   {
/* 295 */     Set uniqueParameters = new HashSet();
/* 296 */     Map parameterMap = request.getParameterMap();
/* 297 */     for (Iterator i$ = parameterMap.keySet().iterator(); i$.hasNext(); ) { Object o = i$.next();
/* 298 */       String key = (String)o;
/*     */ 
/* 301 */       if ((key.endsWith(".x")) || (key.endsWith(".y"))) {
/* 302 */         key = key.substring(0, key.length() - 2);
/*     */       }
/*     */ 
/* 306 */       if (!uniqueParameters.contains(key)) {
/* 307 */         ParameterAction parameterAction = (ParameterAction)this.prefixTrie.get(key);
/* 308 */         if (parameterAction != null) {
/* 309 */           parameterAction.execute(key, mapping);
/* 310 */           uniqueParameters.add(key);
/* 311 */           break;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void parseNameAndNamespace(String uri, ActionMapping mapping, ConfigurationManager configManager)
/*     */   {
/* 325 */     int lastSlash = uri.lastIndexOf("/");
/*     */     String name;
/*     */     String namespace;
/*     */     String name;
/* 326 */     if (lastSlash == -1) {
/* 327 */       String namespace = "";
/* 328 */       name = uri;
/*     */     }
/*     */     else
/*     */     {
/*     */       String name;
/* 329 */       if (lastSlash == 0)
/*     */       {
/* 333 */         String namespace = "/";
/* 334 */         name = uri.substring(lastSlash + 1);
/*     */       }
/*     */       else
/*     */       {
/*     */         String name;
/* 335 */         if (this.alwaysSelectFullNamespace)
/*     */         {
/* 337 */           String namespace = uri.substring(0, lastSlash);
/* 338 */           name = uri.substring(lastSlash + 1);
/*     */         }
/*     */         else {
/* 341 */           Configuration config = configManager.getConfiguration();
/* 342 */           String prefix = uri.substring(0, lastSlash);
/* 343 */           namespace = "";
/* 344 */           boolean rootAvailable = false;
/*     */ 
/* 346 */           for (PackageConfig cfg : config.getPackageConfigs().values()) {
/* 347 */             String ns = cfg.getNamespace();
/* 348 */             if ((ns != null) && (prefix.startsWith(ns)) && ((prefix.length() == ns.length()) || (prefix.charAt(ns.length()) == '/')) && 
/* 349 */               (ns.length() > namespace.length())) {
/* 350 */               namespace = ns;
/*     */             }
/*     */ 
/* 353 */             if ("/".equals(ns)) {
/* 354 */               rootAvailable = true;
/*     */             }
/*     */           }
/*     */ 
/* 358 */           name = uri.substring(namespace.length() + 1);
/*     */ 
/* 361 */           if ((rootAvailable) && ("".equals(namespace)))
/* 362 */             namespace = "/";
/*     */         }
/*     */       }
/*     */     }
/* 366 */     if (!this.allowSlashesInActionNames) {
/* 367 */       int pos = name.lastIndexOf('/');
/* 368 */       if ((pos > -1) && (pos < name.length() - 1)) {
/* 369 */         name = name.substring(pos + 1);
/*     */       }
/*     */     }
/*     */ 
/* 373 */     mapping.setNamespace(namespace);
/* 374 */     mapping.setName(cleanupActionName(name));
/*     */   }
/*     */ 
/*     */   protected String cleanupActionName(String rawActionName)
/*     */   {
/* 384 */     if (this.allowedActionNames.matcher(rawActionName).matches()) {
/* 385 */       return rawActionName;
/*     */     }
/* 387 */     if (LOG.isWarnEnabled()) {
/* 388 */       LOG.warn("Action [#0] does not match allowed action names pattern [#1], cleaning it up!", new Object[] { rawActionName, this.allowedActionNames });
/*     */     }
/*     */ 
/* 391 */     String cleanActionName = rawActionName;
/* 392 */     for (String chunk : this.allowedActionNames.split(rawActionName)) {
/* 393 */       cleanActionName = cleanActionName.replace(chunk, "");
/*     */     }
/* 395 */     if (LOG.isDebugEnabled()) {
/* 396 */       LOG.debug("Cleaned action name [#0]", new String[] { cleanActionName });
/*     */     }
/* 398 */     return cleanActionName;
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   protected String dropExtension(String name)
/*     */   {
/* 410 */     return dropExtension(name, new ActionMapping());
/*     */   }
/*     */ 
/*     */   protected String dropExtension(String name, ActionMapping mapping)
/*     */   {
/* 421 */     if (this.extensions == null) {
/* 422 */       return name;
/*     */     }
/* 424 */     for (String ext : this.extensions) {
/* 425 */       if ("".equals(ext))
/*     */       {
/* 429 */         int index = name.lastIndexOf('.');
/* 430 */         if ((index == -1) || (name.indexOf('/', index) >= 0))
/* 431 */           return name;
/*     */       }
/*     */       else {
/* 434 */         String extension = "." + ext;
/* 435 */         if (name.endsWith(extension)) {
/* 436 */           name = name.substring(0, name.length() - extension.length());
/* 437 */           mapping.setExtension(ext);
/* 438 */           return name;
/*     */         }
/*     */       }
/*     */     }
/* 442 */     return null;
/*     */   }
/*     */ 
/*     */   protected String getDefaultExtension()
/*     */   {
/* 449 */     if (this.extensions == null) {
/* 450 */       return null;
/*     */     }
/* 452 */     return (String)this.extensions.get(0);
/*     */   }
/*     */ 
/*     */   public String getUriFromActionMapping(ActionMapping mapping)
/*     */   {
/* 462 */     StringBuilder uri = new StringBuilder();
/*     */ 
/* 464 */     handleNamespace(mapping, uri);
/* 465 */     handleName(mapping, uri);
/* 466 */     handleDynamicMethod(mapping, uri);
/* 467 */     handleExtension(mapping, uri);
/* 468 */     handleParams(mapping, uri);
/*     */ 
/* 470 */     return uri.toString();
/*     */   }
/*     */ 
/*     */   protected void handleNamespace(ActionMapping mapping, StringBuilder uri) {
/* 474 */     if (mapping.getNamespace() != null) {
/* 475 */       uri.append(mapping.getNamespace());
/* 476 */       if (!"/".equals(mapping.getNamespace()))
/* 477 */         uri.append("/");
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void handleName(ActionMapping mapping, StringBuilder uri)
/*     */   {
/* 483 */     String name = mapping.getName();
/* 484 */     if (name.indexOf('?') != -1) {
/* 485 */       name = name.substring(0, name.indexOf('?'));
/*     */     }
/* 487 */     uri.append(name);
/*     */   }
/*     */ 
/*     */   protected void handleDynamicMethod(ActionMapping mapping, StringBuilder uri)
/*     */   {
/* 492 */     if (StringUtils.isNotEmpty(mapping.getMethod()))
/* 493 */       if (this.allowDynamicMethodCalls)
/*     */       {
/* 495 */         String name = mapping.getName();
/* 496 */         if (!name.contains("!"))
/*     */         {
/* 498 */           uri.append("!").append(mapping.getMethod());
/*     */         }
/*     */       } else {
/* 501 */         uri.append("!").append(mapping.getMethod());
/*     */       }
/*     */   }
/*     */ 
/*     */   protected void handleExtension(ActionMapping mapping, StringBuilder uri)
/*     */   {
/* 507 */     String extension = lookupExtension(mapping.getExtension());
/*     */ 
/* 509 */     if ((extension != null) && 
/* 510 */       ((extension.length() == 0) || ((extension.length() > 0) && (uri.indexOf('.' + extension) == -1))) && 
/* 511 */       (extension.length() > 0))
/* 512 */       uri.append(".").append(extension);
/*     */   }
/*     */ 
/*     */   protected String lookupExtension(String extension)
/*     */   {
/* 519 */     if (extension == null)
/*     */     {
/* 521 */       ActionContext context = ActionContext.getContext();
/* 522 */       if (context != null) {
/* 523 */         ActionMapping orig = (ActionMapping)context.get("struts.actionMapping");
/* 524 */         if (orig != null) {
/* 525 */           extension = orig.getExtension();
/*     */         }
/*     */       }
/* 528 */       if (extension == null) {
/* 529 */         extension = getDefaultExtension();
/*     */       }
/*     */     }
/* 532 */     return extension;
/*     */   }
/*     */ 
/*     */   protected void handleParams(ActionMapping mapping, StringBuilder uri) {
/* 536 */     String name = mapping.getName();
/* 537 */     String params = "";
/* 538 */     if (name.indexOf('?') != -1) {
/* 539 */       params = name.substring(name.indexOf('?'));
/*     */     }
/* 541 */     if (params.length() > 0)
/* 542 */       uri.append(params);
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.dispatcher.mapper.DefaultActionMapper
 * JD-Core Version:    0.6.0
 */