/*     */ package org.apache.struts2.dispatcher;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionContext;
/*     */ import com.opensymphony.xwork2.ActionInvocation;
/*     */ import com.opensymphony.xwork2.util.logging.Logger;
/*     */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.PrintWriter;
/*     */ import java.nio.charset.Charset;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ 
/*     */ public class PlainTextResult extends StrutsResultSupport
/*     */ {
/*     */   public static final int BUFFER_SIZE = 1024;
/*  80 */   private static final Logger LOG = LoggerFactory.getLogger(PlainTextResult.class);
/*     */   private static final long serialVersionUID = 3633371605905583950L;
/*     */   private String charSet;
/*     */ 
/*     */   public PlainTextResult()
/*     */   {
/*     */   }
/*     */ 
/*     */   public PlainTextResult(String location)
/*     */   {
/*  91 */     super(location);
/*     */   }
/*     */ 
/*     */   public String getCharSet()
/*     */   {
/* 100 */     return this.charSet;
/*     */   }
/*     */ 
/*     */   public void setCharSet(String charSet)
/*     */   {
/* 109 */     this.charSet = charSet;
/*     */   }
/*     */ 
/*     */   protected void doExecute(String finalLocation, ActionInvocation invocation)
/*     */     throws Exception
/*     */   {
/* 117 */     Charset charset = readCharset();
/*     */ 
/* 119 */     HttpServletResponse response = (HttpServletResponse)invocation.getInvocationContext().get("com.opensymphony.xwork2.dispatcher.HttpServletResponse");
/*     */ 
/* 121 */     applyCharset(charset, response);
/* 122 */     applyAdditionalHeaders(response);
/* 123 */     String location = adjustLocation(finalLocation);
/*     */ 
/* 125 */     PrintWriter writer = response.getWriter();
/* 126 */     InputStreamReader reader = null;
/*     */     try {
/* 128 */       InputStream resourceAsStream = readStream(invocation, location);
/* 129 */       logWrongStream(finalLocation, resourceAsStream);
/* 130 */       if (charset != null)
/* 131 */         reader = new InputStreamReader(resourceAsStream, charset);
/*     */       else {
/* 133 */         reader = new InputStreamReader(resourceAsStream);
/*     */       }
/* 135 */       if (resourceAsStream != null)
/* 136 */         sendStream(writer, reader);
/*     */     }
/*     */     finally {
/* 139 */       if (reader != null)
/* 140 */         reader.close();
/* 141 */       if (writer != null) {
/* 142 */         writer.flush();
/* 143 */         writer.close();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   protected InputStream readStream(ActionInvocation invocation, String location) {
/* 149 */     ServletContext servletContext = (ServletContext)invocation.getInvocationContext().get("com.opensymphony.xwork2.dispatcher.ServletContext");
/* 150 */     return servletContext.getResourceAsStream(location);
/*     */   }
/*     */ 
/*     */   protected void logWrongStream(String finalLocation, InputStream resourceAsStream) {
/* 154 */     if ((resourceAsStream == null) && 
/* 155 */       (LOG.isWarnEnabled()))
/* 156 */       LOG.warn("Resource at location [" + finalLocation + "] cannot be obtained (return null) from ServletContext !!! ", new String[0]);
/*     */   }
/*     */ 
/*     */   protected void sendStream(PrintWriter writer, InputStreamReader reader)
/*     */     throws IOException
/*     */   {
/* 162 */     char[] buffer = new char[1024];
/*     */     int charRead;
/* 164 */     while ((charRead = reader.read(buffer)) != -1)
/* 165 */       writer.write(buffer, 0, charRead);
/*     */   }
/*     */ 
/*     */   protected String adjustLocation(String location)
/*     */   {
/* 170 */     if (location.charAt(0) != '/') {
/* 171 */       return "/" + location;
/*     */     }
/* 173 */     return location;
/*     */   }
/*     */ 
/*     */   protected void applyAdditionalHeaders(HttpServletResponse response) {
/* 177 */     response.setHeader("Content-Disposition", "inline");
/*     */   }
/*     */ 
/*     */   protected void applyCharset(Charset charset, HttpServletResponse response) {
/* 181 */     if (charset != null)
/* 182 */       response.setContentType("text/plain; charset=" + this.charSet);
/*     */     else
/* 184 */       response.setContentType("text/plain");
/*     */   }
/*     */ 
/*     */   protected Charset readCharset()
/*     */   {
/* 189 */     Charset charset = null;
/* 190 */     if (this.charSet != null) {
/* 191 */       if (Charset.isSupported(this.charSet)) {
/* 192 */         charset = Charset.forName(this.charSet);
/*     */       } else {
/* 194 */         if (LOG.isWarnEnabled()) {
/* 195 */           LOG.warn("charset [" + this.charSet + "] is not recognized ", new String[0]);
/*     */         }
/* 197 */         charset = null;
/*     */       }
/*     */     }
/* 200 */     return charset;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.dispatcher.PlainTextResult
 * JD-Core Version:    0.6.0
 */