/*     */ package org.apache.struts2.dispatcher;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionContext;
/*     */ import com.opensymphony.xwork2.ActionInvocation;
/*     */ import com.opensymphony.xwork2.ActionProxy;
/*     */ import com.opensymphony.xwork2.ActionProxyFactory;
/*     */ import com.opensymphony.xwork2.LocaleProvider;
/*     */ import com.opensymphony.xwork2.ObjectFactory;
/*     */ import com.opensymphony.xwork2.Result;
/*     */ import com.opensymphony.xwork2.config.ConfigurationException;
/*     */ import com.opensymphony.xwork2.config.ConfigurationManager;
/*     */ import com.opensymphony.xwork2.config.ConfigurationProvider;
/*     */ import com.opensymphony.xwork2.config.FileManagerFactoryProvider;
/*     */ import com.opensymphony.xwork2.config.FileManagerProvider;
/*     */ import com.opensymphony.xwork2.config.entities.InterceptorMapping;
/*     */ import com.opensymphony.xwork2.config.entities.InterceptorStackConfig;
/*     */ import com.opensymphony.xwork2.config.entities.PackageConfig;
/*     */ import com.opensymphony.xwork2.config.providers.XmlConfigurationProvider;
/*     */ import com.opensymphony.xwork2.inject.Container;
/*     */ import com.opensymphony.xwork2.inject.ContainerBuilder;
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import com.opensymphony.xwork2.interceptor.Interceptor;
/*     */ import com.opensymphony.xwork2.util.ClassLoaderUtil;
/*     */ import com.opensymphony.xwork2.util.LocalizedTextUtil;
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import com.opensymphony.xwork2.util.ValueStackFactory;
/*     */ import com.opensymphony.xwork2.util.location.LocatableProperties;
/*     */ import com.opensymphony.xwork2.util.location.Location;
/*     */ import com.opensymphony.xwork2.util.location.LocationUtils;
/*     */ import com.opensymphony.xwork2.util.logging.Logger;
/*     */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*     */ import com.opensymphony.xwork2.util.profiling.UtilTimerStack;
/*     */ import freemarker.template.Template;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.StringWriter;
/*     */ import java.io.Writer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.CopyOnWriteArrayList;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.struts2.StrutsException;
/*     */ import org.apache.struts2.config.DefaultBeanSelectionProvider;
/*     */ import org.apache.struts2.config.DefaultPropertiesProvider;
/*     */ import org.apache.struts2.config.PropertiesConfigurationProvider;
/*     */ import org.apache.struts2.config.StrutsXmlConfigurationProvider;
/*     */ import org.apache.struts2.dispatcher.mapper.ActionMapping;
/*     */ import org.apache.struts2.dispatcher.multipart.MultiPartRequest;
/*     */ import org.apache.struts2.dispatcher.multipart.MultiPartRequestWrapper;
/*     */ import org.apache.struts2.util.AttributeMap;
/*     */ import org.apache.struts2.util.ObjectFactoryDestroyable;
/*     */ import org.apache.struts2.util.fs.JBossFileManager;
/*     */ import org.apache.struts2.views.freemarker.FreemarkerManager;
/*     */ 
/*     */ public class Dispatcher
/*     */ {
/* 103 */   private static final Logger LOG = LoggerFactory.getLogger(Dispatcher.class);
/*     */ 
/* 108 */   private static ThreadLocal<Dispatcher> instance = new ThreadLocal();
/*     */ 
/* 113 */   private static List<DispatcherListener> dispatcherListeners = new CopyOnWriteArrayList();
/*     */   private ConfigurationManager configurationManager;
/*     */   private boolean devMode;
/*     */   private boolean disableRequestAttributeValueStackLookup;
/*     */   private String defaultEncoding;
/*     */   private String defaultLocale;
/*     */   private String multipartSaveDir;
/*     */   private String multipartHandlerName;
/*     */   private static final String DEFAULT_CONFIGURATION_PATHS = "struts-default.xml,struts-plugin.xml,struts.xml";
/* 163 */   private boolean paramsWorkaroundEnabled = false;
/*     */   private boolean handleException;
/*     */   private ServletContext servletContext;
/*     */   private Map<String, String> initParams;
/*     */   private ValueStackFactory valueStackFactory;
/*     */ 
/*     */   public static Dispatcher getInstance()
/*     */   {
/* 177 */     return (Dispatcher)instance.get();
/*     */   }
/*     */ 
/*     */   public static void setInstance(Dispatcher instance)
/*     */   {
/* 186 */     instance.set(instance);
/*     */   }
/*     */ 
/*     */   public static void addDispatcherListener(DispatcherListener listener)
/*     */   {
/* 195 */     dispatcherListeners.add(listener);
/*     */   }
/*     */ 
/*     */   public static void removeDispatcherListener(DispatcherListener listener)
/*     */   {
/* 204 */     dispatcherListeners.remove(listener);
/*     */   }
/*     */ 
/*     */   public Dispatcher(ServletContext servletContext, Map<String, String> initParams)
/*     */   {
/* 219 */     this.servletContext = servletContext;
/* 220 */     this.initParams = initParams;
/*     */   }
/*     */ 
/*     */   @Inject("struts.devMode")
/*     */   public void setDevMode(String mode)
/*     */   {
/* 229 */     this.devMode = "true".equals(mode);
/*     */   }
/*     */ 
/*     */   @Inject(value="struts.disableRequestAttributeValueStackLookup", required=false)
/*     */   public void setDisableRequestAttributeValueStackLookup(String disableRequestAttributeValueStackLookup)
/*     */   {
/* 238 */     this.disableRequestAttributeValueStackLookup = "true".equalsIgnoreCase(disableRequestAttributeValueStackLookup);
/*     */   }
/*     */ 
/*     */   @Inject(value="struts.locale", required=false)
/*     */   public void setDefaultLocale(String val)
/*     */   {
/* 247 */     this.defaultLocale = val;
/*     */   }
/*     */ 
/*     */   @Inject("struts.i18n.encoding")
/*     */   public void setDefaultEncoding(String val)
/*     */   {
/* 256 */     this.defaultEncoding = val;
/*     */   }
/*     */ 
/*     */   @Inject("struts.multipart.saveDir")
/*     */   public void setMultipartSaveDir(String val)
/*     */   {
/* 265 */     this.multipartSaveDir = val;
/*     */   }
/*     */   @Inject("struts.multipart.parser")
/*     */   public void setMultipartHandler(String val) {
/* 270 */     this.multipartHandlerName = val;
/*     */   }
/*     */   @Inject
/*     */   public void setValueStackFactory(ValueStackFactory valueStackFactory) {
/* 275 */     this.valueStackFactory = valueStackFactory;
/*     */   }
/*     */   @Inject("struts.handle.exception")
/*     */   public void setHandleException(String handleException) {
/* 280 */     this.handleException = Boolean.parseBoolean(handleException);
/*     */   }
/*     */ 
/*     */   public void cleanup()
/*     */   {
/* 289 */     ObjectFactory objectFactory = (ObjectFactory)getContainer().getInstance(ObjectFactory.class);
/* 290 */     if ((objectFactory == null) && 
/* 291 */       (LOG.isWarnEnabled())) {
/* 292 */       LOG.warn("Object Factory is null, something is seriously wrong, no clean up will be performed", new String[0]);
/*     */     }
/*     */ 
/* 295 */     if ((objectFactory instanceof ObjectFactoryDestroyable)) {
/*     */       try {
/* 297 */         ((ObjectFactoryDestroyable)objectFactory).destroy();
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/* 301 */         LOG.error("exception occurred while destroying ObjectFactory [#0]", e, new String[] { objectFactory.toString() });
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 306 */     instance.set(null);
/*     */ 
/* 309 */     if (!dispatcherListeners.isEmpty()) {
/* 310 */       for (DispatcherListener l : dispatcherListeners) {
/* 311 */         l.dispatcherDestroyed(this);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 316 */     Set interceptors = new HashSet();
/* 317 */     Collection packageConfigs = this.configurationManager.getConfiguration().getPackageConfigs().values();
/* 318 */     for (PackageConfig packageConfig : packageConfigs)
/* 319 */       for (i$ = packageConfig.getAllInterceptorConfigs().values().iterator(); i$.hasNext(); ) { Object config = i$.next();
/* 320 */         if ((config instanceof InterceptorStackConfig))
/* 321 */           for (InterceptorMapping interceptorMapping : ((InterceptorStackConfig)config).getInterceptors())
/* 322 */             interceptors.add(interceptorMapping.getInterceptor());
/*     */       }
/*     */     Iterator i$;
/* 327 */     for (Interceptor interceptor : interceptors) {
/* 328 */       interceptor.destroy();
/*     */     }
/*     */ 
/* 332 */     ContainerHolder.clear();
/*     */ 
/* 335 */     ActionContext.setContext(null);
/*     */ 
/* 338 */     this.configurationManager.destroyConfiguration();
/* 339 */     this.configurationManager = null;
/*     */   }
/*     */ 
/*     */   private void init_FileManager() throws ClassNotFoundException {
/* 343 */     if (this.initParams.containsKey("struts.fileManager")) {
/* 344 */       String fileManagerClassName = (String)this.initParams.get("struts.fileManager");
/* 345 */       Class fileManagerClass = Class.forName(fileManagerClassName);
/* 346 */       if (LOG.isInfoEnabled()) {
/* 347 */         LOG.info("Custom FileManager specified: #0", new String[] { fileManagerClassName });
/*     */       }
/* 349 */       this.configurationManager.addContainerProvider(new FileManagerProvider(fileManagerClass, fileManagerClass.getSimpleName()));
/*     */     }
/*     */     else {
/* 352 */       this.configurationManager.addContainerProvider(new FileManagerProvider(JBossFileManager.class, "jboss"));
/*     */     }
/* 354 */     if (this.initParams.containsKey("struts.fileManagerFactory")) {
/* 355 */       String fileManagerFactoryClassName = (String)this.initParams.get("struts.fileManagerFactory");
/* 356 */       Class fileManagerFactoryClass = Class.forName(fileManagerFactoryClassName);
/* 357 */       if (LOG.isInfoEnabled()) {
/* 358 */         LOG.info("Custom FileManagerFactory specified: #0", new String[] { fileManagerFactoryClassName });
/*     */       }
/* 360 */       this.configurationManager.addContainerProvider(new FileManagerFactoryProvider(fileManagerFactoryClass));
/*     */     }
/*     */   }
/*     */ 
/*     */   private void init_DefaultProperties() {
/* 365 */     this.configurationManager.addContainerProvider(new DefaultPropertiesProvider());
/*     */   }
/*     */ 
/*     */   private void init_LegacyStrutsProperties() {
/* 369 */     this.configurationManager.addContainerProvider(new PropertiesConfigurationProvider());
/*     */   }
/*     */ 
/*     */   private void init_TraditionalXmlConfigurations() {
/* 373 */     String configPaths = (String)this.initParams.get("config");
/* 374 */     if (configPaths == null) {
/* 375 */       configPaths = "struts-default.xml,struts-plugin.xml,struts.xml";
/*     */     }
/* 377 */     String[] files = configPaths.split("\\s*[,]\\s*");
/* 378 */     for (String file : files)
/* 379 */       if (file.endsWith(".xml")) {
/* 380 */         if ("xwork.xml".equals(file))
/* 381 */           this.configurationManager.addContainerProvider(createXmlConfigurationProvider(file, false));
/*     */         else
/* 383 */           this.configurationManager.addContainerProvider(createStrutsXmlConfigurationProvider(file, false, this.servletContext));
/*     */       }
/*     */       else
/* 386 */         throw new IllegalArgumentException("Invalid configuration file name");
/*     */   }
/*     */ 
/*     */   protected XmlConfigurationProvider createXmlConfigurationProvider(String filename, boolean errorIfMissing)
/*     */   {
/* 392 */     return new XmlConfigurationProvider(filename, errorIfMissing);
/*     */   }
/*     */ 
/*     */   protected XmlConfigurationProvider createStrutsXmlConfigurationProvider(String filename, boolean errorIfMissing, ServletContext ctx) {
/* 396 */     return new StrutsXmlConfigurationProvider(filename, errorIfMissing, ctx);
/*     */   }
/*     */ 
/*     */   private void init_CustomConfigurationProviders() {
/* 400 */     String configProvs = (String)this.initParams.get("configProviders");
/* 401 */     if (configProvs != null) {
/* 402 */       String[] classes = configProvs.split("\\s*[,]\\s*");
/* 403 */       for (String cname : classes)
/*     */         try {
/* 405 */           Class cls = ClassLoaderUtil.loadClass(cname, getClass());
/* 406 */           ConfigurationProvider prov = (ConfigurationProvider)cls.newInstance();
/* 407 */           this.configurationManager.addContainerProvider(prov);
/*     */         } catch (InstantiationException e) {
/* 409 */           throw new ConfigurationException("Unable to instantiate provider: " + cname, e);
/*     */         } catch (IllegalAccessException e) {
/* 411 */           throw new ConfigurationException("Unable to access provider: " + cname, e);
/*     */         } catch (ClassNotFoundException e) {
/* 413 */           throw new ConfigurationException("Unable to locate provider class: " + cname, e);
/*     */         }
/*     */     }
/*     */   }
/*     */ 
/*     */   private void init_FilterInitParameters()
/*     */   {
/* 420 */     this.configurationManager.addContainerProvider(new ConfigurationProvider() {
/*     */       public void destroy() {
/*     */       }
/*     */ 
/*     */       public void init(com.opensymphony.xwork2.config.Configuration configuration) throws ConfigurationException {
/*     */       }
/*     */ 
/*     */       public void loadPackages() throws ConfigurationException {
/*     */       }
/*     */ 
/*     */       public boolean needsReload() {
/* 431 */         return false;
/*     */       }
/*     */ 
/*     */       public void register(ContainerBuilder builder, LocatableProperties props) throws ConfigurationException {
/* 435 */         props.putAll(Dispatcher.this.initParams);
/*     */       } } );
/*     */   }
/*     */ 
/*     */   private void init_AliasStandardObjects() {
/* 441 */     this.configurationManager.addContainerProvider(new DefaultBeanSelectionProvider());
/*     */   }
/*     */ 
/*     */   private Container init_PreloadConfiguration() {
/* 445 */     com.opensymphony.xwork2.config.Configuration config = this.configurationManager.getConfiguration();
/* 446 */     Container container = config.getContainer();
/*     */ 
/* 448 */     boolean reloadi18n = Boolean.valueOf((String)container.getInstance(String.class, "struts.i18n.reload")).booleanValue();
/* 449 */     LocalizedTextUtil.setReloadBundles(reloadi18n);
/*     */ 
/* 451 */     ContainerHolder.store(container);
/*     */ 
/* 453 */     return container;
/*     */   }
/*     */ 
/*     */   private void init_CheckWebLogicWorkaround(Container container)
/*     */   {
/* 458 */     if ((this.servletContext != null) && (this.servletContext.getServerInfo() != null) && (this.servletContext.getServerInfo().contains("WebLogic")))
/*     */     {
/* 460 */       if (LOG.isInfoEnabled()) {
/* 461 */         LOG.info("WebLogic server detected. Enabling Struts parameter access work-around.", new String[0]);
/*     */       }
/* 463 */       this.paramsWorkaroundEnabled = true;
/*     */     } else {
/* 465 */       this.paramsWorkaroundEnabled = "true".equals(container.getInstance(String.class, "struts.dispatcher.parametersWorkaround"));
/*     */     }
/*     */   }
/*     */ 
/*     */   public void init()
/*     */   {
/* 476 */     if (this.configurationManager == null) {
/* 477 */       this.configurationManager = createConfigurationManager("struts");
/*     */     }
/*     */     try
/*     */     {
/* 481 */       init_FileManager();
/* 482 */       init_DefaultProperties();
/* 483 */       init_TraditionalXmlConfigurations();
/* 484 */       init_LegacyStrutsProperties();
/* 485 */       init_CustomConfigurationProviders();
/* 486 */       init_FilterInitParameters();
/* 487 */       init_AliasStandardObjects();
/*     */ 
/* 489 */       Container container = init_PreloadConfiguration();
/* 490 */       container.inject(this);
/* 491 */       init_CheckWebLogicWorkaround(container);
/*     */ 
/* 493 */       if (!dispatcherListeners.isEmpty())
/* 494 */         for (DispatcherListener l : dispatcherListeners)
/* 495 */           l.dispatcherInitialized(this);
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/* 499 */       if (LOG.isErrorEnabled())
/* 500 */         LOG.error("Dispatcher initialization failed", ex, new String[0]);
/* 501 */       throw new StrutsException(ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected ConfigurationManager createConfigurationManager(String name) {
/* 506 */     return new ConfigurationManager(name);
/*     */   }
/*     */ 
/*     */   public void serviceAction(HttpServletRequest request, HttpServletResponse response, ServletContext context, ActionMapping mapping)
/*     */     throws ServletException
/*     */   {
/* 529 */     Map extraContext = createContextMap(request, response, mapping, context);
/*     */ 
/* 532 */     ValueStack stack = (ValueStack)request.getAttribute("struts.valueStack");
/* 533 */     boolean nullStack = stack == null;
/* 534 */     if (nullStack) {
/* 535 */       ActionContext ctx = ActionContext.getContext();
/* 536 */       if (ctx != null) {
/* 537 */         stack = ctx.getValueStack();
/*     */       }
/*     */     }
/* 540 */     if (stack != null) {
/* 541 */       extraContext.put("com.opensymphony.xwork2.util.ValueStack.ValueStack", this.valueStackFactory.createValueStack(stack));
/*     */     }
/*     */ 
/* 544 */     String timerKey = "Handling request from Dispatcher";
/*     */     try {
/* 546 */       UtilTimerStack.push(timerKey);
/* 547 */       String namespace = mapping.getNamespace();
/* 548 */       String name = mapping.getName();
/* 549 */       String method = mapping.getMethod();
/*     */ 
/* 551 */       com.opensymphony.xwork2.config.Configuration config = this.configurationManager.getConfiguration();
/* 552 */       ActionProxy proxy = ((ActionProxyFactory)config.getContainer().getInstance(ActionProxyFactory.class)).createActionProxy(namespace, name, method, extraContext, true, false);
/*     */ 
/* 555 */       request.setAttribute("struts.valueStack", proxy.getInvocation().getStack());
/*     */ 
/* 558 */       if (mapping.getResult() != null) {
/* 559 */         Result result = mapping.getResult();
/* 560 */         result.execute(proxy.getInvocation());
/*     */       } else {
/* 562 */         proxy.execute();
/*     */       }
/*     */ 
/* 566 */       if (!nullStack)
/* 567 */         request.setAttribute("struts.valueStack", stack);
/*     */     }
/*     */     catch (ConfigurationException e) {
/* 570 */       logConfigurationException(request, e);
/* 571 */       sendError(request, response, context, 404, e);
/*     */     } catch (Exception e) {
/* 573 */       if ((this.handleException) || (this.devMode))
/* 574 */         sendError(request, response, context, 500, e);
/*     */       else
/* 576 */         throw new ServletException(e);
/*     */     }
/*     */     finally {
/* 579 */       UtilTimerStack.pop(timerKey);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void logConfigurationException(HttpServletRequest request, ConfigurationException e)
/*     */   {
/* 591 */     String uri = request.getRequestURI();
/* 592 */     if (request.getQueryString() != null) {
/* 593 */       uri = uri + "?" + request.getQueryString();
/*     */     }
/* 595 */     if (this.devMode)
/* 596 */       LOG.error("Could not find action or result\n#0", e, new String[] { uri });
/* 597 */     else if (LOG.isWarnEnabled())
/* 598 */       LOG.warn("Could not find action or result: #0", e, new String[] { uri });
/*     */   }
/*     */ 
/*     */   public Map<String, Object> createContextMap(HttpServletRequest request, HttpServletResponse response, ActionMapping mapping, ServletContext context)
/*     */   {
/* 615 */     Map requestMap = new RequestMap(request);
/*     */ 
/* 618 */     Map params = new HashMap(request.getParameterMap());
/*     */ 
/* 621 */     Map session = new SessionMap(request);
/*     */ 
/* 624 */     Map application = new ApplicationMap(context);
/*     */ 
/* 626 */     Map extraContext = createContextMap(requestMap, params, session, application, request, response, context);
/*     */ 
/* 628 */     if (mapping != null) {
/* 629 */       extraContext.put("struts.actionMapping", mapping);
/*     */     }
/* 631 */     return extraContext;
/*     */   }
/*     */ 
/*     */   public HashMap<String, Object> createContextMap(Map requestMap, Map parameterMap, Map sessionMap, Map applicationMap, HttpServletRequest request, HttpServletResponse response, ServletContext servletContext)
/*     */   {
/* 654 */     HashMap extraContext = new HashMap();
/* 655 */     extraContext.put("com.opensymphony.xwork2.ActionContext.parameters", new HashMap(parameterMap));
/* 656 */     extraContext.put("com.opensymphony.xwork2.ActionContext.session", sessionMap);
/* 657 */     extraContext.put("com.opensymphony.xwork2.ActionContext.application", applicationMap);
/*     */     Locale locale;
/*     */     Locale locale;
/* 660 */     if (this.defaultLocale != null)
/* 661 */       locale = LocalizedTextUtil.localeFromString(this.defaultLocale, request.getLocale());
/*     */     else {
/* 663 */       locale = request.getLocale();
/*     */     }
/*     */ 
/* 666 */     extraContext.put("com.opensymphony.xwork2.ActionContext.locale", locale);
/*     */ 
/* 669 */     extraContext.put("com.opensymphony.xwork2.dispatcher.HttpServletRequest", request);
/* 670 */     extraContext.put("com.opensymphony.xwork2.dispatcher.HttpServletResponse", response);
/* 671 */     extraContext.put("com.opensymphony.xwork2.dispatcher.ServletContext", servletContext);
/*     */ 
/* 674 */     extraContext.put("request", requestMap);
/* 675 */     extraContext.put("session", sessionMap);
/* 676 */     extraContext.put("application", applicationMap);
/* 677 */     extraContext.put("parameters", parameterMap);
/*     */ 
/* 679 */     AttributeMap attrMap = new AttributeMap(extraContext);
/* 680 */     extraContext.put("attr", attrMap);
/*     */ 
/* 682 */     return extraContext;
/*     */   }
/*     */ 
/*     */   private String getSaveDir(ServletContext servletContext)
/*     */   {
/* 692 */     String saveDir = this.multipartSaveDir.trim();
/*     */ 
/* 694 */     if (saveDir.equals("")) {
/* 695 */       File tempdir = (File)servletContext.getAttribute("javax.servlet.context.tempdir");
/* 696 */       if (LOG.isInfoEnabled()) {
/* 697 */         LOG.info("Unable to find 'struts.multipart.saveDir' property setting. Defaulting to javax.servlet.context.tempdir", new String[0]);
/*     */       }
/*     */ 
/* 700 */       if (tempdir != null) {
/* 701 */         saveDir = tempdir.toString();
/* 702 */         setMultipartSaveDir(saveDir);
/*     */       }
/*     */     } else {
/* 705 */       File multipartSaveDir = new File(saveDir);
/*     */ 
/* 707 */       if ((!multipartSaveDir.exists()) && 
/* 708 */         (!multipartSaveDir.mkdirs())) {
/*     */         String logMessage;
/*     */         try { logMessage = "Could not find create multipart save directory '" + multipartSaveDir.getCanonicalPath() + "'.";
/*     */         } catch (IOException e) {
/* 713 */           logMessage = "Could not find create multipart save directory '" + multipartSaveDir.toString() + "'.";
/*     */         }
/* 715 */         if (this.devMode) {
/* 716 */           LOG.error(logMessage, new String[0]);
/*     */         }
/* 718 */         else if (LOG.isWarnEnabled()) {
/* 719 */           LOG.warn(logMessage, new String[0]);
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 726 */     if (LOG.isDebugEnabled()) {
/* 727 */       LOG.debug("saveDir=" + saveDir, new String[0]);
/*     */     }
/*     */ 
/* 730 */     return saveDir;
/*     */   }
/*     */ 
/*     */   public void prepare(HttpServletRequest request, HttpServletResponse response)
/*     */   {
/* 740 */     String encoding = null;
/* 741 */     if (this.defaultEncoding != null) {
/* 742 */       encoding = this.defaultEncoding;
/*     */     }
/*     */ 
/* 745 */     if ("XMLHttpRequest".equals(request.getHeader("X-Requested-With"))) {
/* 746 */       encoding = "UTF-8";
/*     */     }
/*     */ 
/* 749 */     Locale locale = null;
/* 750 */     if (this.defaultLocale != null) {
/* 751 */       locale = LocalizedTextUtil.localeFromString(this.defaultLocale, request.getLocale());
/*     */     }
/*     */ 
/* 754 */     if (encoding != null) {
/* 755 */       applyEncoding(request, encoding);
/*     */     }
/*     */ 
/* 758 */     if (locale != null) {
/* 759 */       response.setLocale(locale);
/*     */     }
/*     */ 
/* 762 */     if (this.paramsWorkaroundEnabled)
/* 763 */       request.getParameter("foo");
/*     */   }
/*     */ 
/*     */   private void applyEncoding(HttpServletRequest request, String encoding)
/*     */   {
/*     */     try {
/* 769 */       if (!encoding.equals(request.getCharacterEncoding()))
/*     */       {
/* 772 */         request.setCharacterEncoding(encoding);
/*     */       }
/*     */     } catch (Exception e) {
/* 775 */       LOG.error("Error setting character encoding to '" + encoding + "' - ignoring.", e, new String[0]);
/*     */     }
/*     */   }
/*     */ 
/*     */   public HttpServletRequest wrapRequest(HttpServletRequest request, ServletContext servletContext)
/*     */     throws IOException
/*     */   {
/* 795 */     if ((request instanceof StrutsRequestWrapper)) {
/* 796 */       return request;
/*     */     }
/*     */ 
/* 799 */     String content_type = request.getContentType();
/* 800 */     if ((content_type != null) && (content_type.contains("multipart/form-data"))) {
/* 801 */       MultiPartRequest mpr = getMultiPartRequest();
/* 802 */       LocaleProvider provider = (LocaleProvider)getContainer().getInstance(LocaleProvider.class);
/* 803 */       request = new MultiPartRequestWrapper(mpr, request, getSaveDir(servletContext), provider);
/*     */     } else {
/* 805 */       request = new StrutsRequestWrapper(request, this.disableRequestAttributeValueStackLookup);
/*     */     }
/*     */ 
/* 808 */     return request;
/*     */   }
/*     */ 
/*     */   protected MultiPartRequest getMultiPartRequest()
/*     */   {
/* 818 */     MultiPartRequest mpr = null;
/*     */ 
/* 820 */     Set multiNames = getContainer().getInstanceNames(MultiPartRequest.class);
/* 821 */     for (String multiName : multiNames) {
/* 822 */       if (multiName.equals(this.multipartHandlerName)) {
/* 823 */         mpr = (MultiPartRequest)getContainer().getInstance(MultiPartRequest.class, multiName);
/*     */       }
/*     */     }
/* 826 */     if (mpr == null) {
/* 827 */       mpr = (MultiPartRequest)getContainer().getInstance(MultiPartRequest.class);
/*     */     }
/* 829 */     return mpr;
/*     */   }
/*     */ 
/*     */   public void cleanUpRequest(HttpServletRequest request)
/*     */   {
/* 839 */     ContainerHolder.clear();
/* 840 */     if (!(request instanceof MultiPartRequestWrapper)) {
/* 841 */       return;
/*     */     }
/* 843 */     MultiPartRequestWrapper multiWrapper = (MultiPartRequestWrapper)request;
/* 844 */     multiWrapper.cleanUp();
/*     */   }
/*     */ 
/*     */   public void sendError(HttpServletRequest request, HttpServletResponse response, ServletContext ctx, int code, Exception e)
/*     */   {
/* 857 */     Boolean devModeOverride = FilterDispatcher.getDevModeOverride();
/* 858 */     if (devModeOverride != null ? devModeOverride.booleanValue() : this.devMode) {
/* 859 */       if (LOG.isDebugEnabled())
/* 860 */         LOG.debug("Exception occurred during processing request: #0", e, new String[] { e.getMessage() });
/*     */       try
/*     */       {
/* 863 */         FreemarkerManager mgr = (FreemarkerManager)getContainer().getInstance(FreemarkerManager.class);
/*     */ 
/* 865 */         freemarker.template.Configuration config = mgr.getConfiguration(ctx);
/* 866 */         Template template = config.getTemplate("/org/apache/struts2/dispatcher/error.ftl");
/*     */ 
/* 868 */         List chain = new ArrayList();
/* 869 */         Throwable cur = e;
/* 870 */         chain.add(cur);
/* 871 */         while ((cur = cur.getCause()) != null) {
/* 872 */           chain.add(cur);
/*     */         }
/*     */ 
/* 875 */         HashMap data = new HashMap();
/* 876 */         data.put("exception", e);
/* 877 */         data.put("unknown", Location.UNKNOWN);
/* 878 */         data.put("chain", chain);
/* 879 */         data.put("locator", new Locator());
/*     */ 
/* 881 */         Writer writer = new StringWriter();
/* 882 */         template.process(data, writer);
/*     */ 
/* 884 */         response.setContentType("text/html");
/* 885 */         response.getWriter().write(writer.toString());
/* 886 */         response.getWriter().close();
/*     */       } catch (Exception exp) {
/*     */         try {
/* 889 */           if (LOG.isDebugEnabled()) {
/* 890 */             LOG.debug("Cannot show problem report!", exp, new String[0]);
/*     */           }
/* 892 */           response.sendError(code, "Unable to show problem report:\n" + exp + "\n\n" + LocationUtils.getLocation(exp));
/*     */         }
/*     */         catch (IOException ex) {
/*     */         }
/*     */       }
/*     */     }
/*     */     else {
/*     */       try {
/* 900 */         if (code == 500)
/*     */         {
/* 902 */           if (LOG.isErrorEnabled()) {
/* 903 */             LOG.error("Exception occurred during processing request: #0", e, new String[] { e.getMessage() });
/*     */           }
/*     */ 
/* 907 */           request.setAttribute("javax.servlet.error.exception", e);
/*     */ 
/* 910 */           request.setAttribute("javax.servlet.jsp.jspException", e);
/*     */         }
/*     */ 
/* 914 */         response.sendError(code, e.getMessage());
/*     */       }
/*     */       catch (IOException e1)
/*     */       {
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void cleanUpAfterInit()
/*     */   {
/* 925 */     if (LOG.isDebugEnabled()) {
/* 926 */       LOG.debug("Cleaning up resources used to init Dispatcher", new String[0]);
/*     */     }
/* 928 */     ContainerHolder.clear();
/*     */   }
/*     */ 
/*     */   public ConfigurationManager getConfigurationManager()
/*     */   {
/* 950 */     return this.configurationManager;
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public void setConfigurationManager(ConfigurationManager mgr)
/*     */   {
/* 960 */     ContainerHolder.clear();
/* 961 */     this.configurationManager = mgr;
/*     */   }
/*     */ 
/*     */   public Container getContainer()
/*     */   {
/* 969 */     if (ContainerHolder.get() != null) {
/* 970 */       return ContainerHolder.get();
/*     */     }
/* 972 */     ConfigurationManager mgr = getConfigurationManager();
/* 973 */     if (mgr == null) {
/* 974 */       throw new IllegalStateException("The configuration manager shouldn't be null");
/*     */     }
/* 976 */     com.opensymphony.xwork2.config.Configuration config = mgr.getConfiguration();
/* 977 */     if (config == null) {
/* 978 */       throw new IllegalStateException("Unable to load configuration");
/*     */     }
/* 980 */     Container container = config.getContainer();
/* 981 */     ContainerHolder.store(container);
/* 982 */     return container;
/*     */   }
/*     */ 
/*     */   public static class Locator
/*     */   {
/*     */     public Location getLocation(Object obj)
/*     */     {
/* 936 */       Location loc = LocationUtils.getLocation(obj);
/* 937 */       if (loc == null) {
/* 938 */         return Location.UNKNOWN;
/*     */       }
/* 940 */       return loc;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.dispatcher.Dispatcher
 * JD-Core Version:    0.6.0
 */