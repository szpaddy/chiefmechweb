/*     */ package org.apache.struts2.dispatcher;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionContext;
/*     */ import com.opensymphony.xwork2.ActionInvocation;
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import com.opensymphony.xwork2.util.logging.Logger;
/*     */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*     */ import java.util.Map;
/*     */ import javax.servlet.RequestDispatcher;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.servlet.jsp.PageContext;
/*     */ import org.apache.commons.lang3.ObjectUtils;
/*     */ import org.apache.commons.lang3.StringUtils;
/*     */ import org.apache.struts2.ServletActionContext;
/*     */ import org.apache.struts2.views.util.UrlHelper;
/*     */ 
/*     */ public class ServletDispatcherResult extends StrutsResultSupport
/*     */ {
/*     */   private static final long serialVersionUID = -1970659272360685627L;
/*  98 */   private static final Logger LOG = LoggerFactory.getLogger(ServletDispatcherResult.class);
/*     */   private UrlHelper urlHelper;
/*     */ 
/*     */   public ServletDispatcherResult()
/*     */   {
/*     */   }
/*     */ 
/*     */   public ServletDispatcherResult(String location)
/*     */   {
/* 107 */     super(location);
/*     */   }
/*     */   @Inject
/*     */   public void setUrlHelper(UrlHelper urlHelper) {
/* 112 */     this.urlHelper = urlHelper;
/*     */   }
/*     */ 
/*     */   public void doExecute(String finalLocation, ActionInvocation invocation)
/*     */     throws Exception
/*     */   {
/* 125 */     if (LOG.isDebugEnabled()) {
/* 126 */       LOG.debug("Forwarding to location " + finalLocation, new String[0]);
/*     */     }
/*     */ 
/* 129 */     PageContext pageContext = ServletActionContext.getPageContext();
/*     */ 
/* 131 */     if (pageContext != null) {
/* 132 */       pageContext.include(finalLocation);
/*     */     } else {
/* 134 */       HttpServletRequest request = ServletActionContext.getRequest();
/* 135 */       HttpServletResponse response = ServletActionContext.getResponse();
/* 136 */       RequestDispatcher dispatcher = request.getRequestDispatcher(finalLocation);
/*     */ 
/* 140 */       if ((StringUtils.isNotEmpty(finalLocation)) && (finalLocation.indexOf("?") > 0)) {
/* 141 */         String queryString = finalLocation.substring(finalLocation.indexOf("?") + 1);
/* 142 */         Map parameters = getParameters(invocation);
/* 143 */         Map queryParams = this.urlHelper.parseQueryString(queryString, true);
/* 144 */         if ((queryParams != null) && (!queryParams.isEmpty())) {
/* 145 */           parameters.putAll(queryParams);
/*     */         }
/*     */       }
/*     */ 
/* 149 */       if (dispatcher == null) {
/* 150 */         response.sendError(404, "result '" + finalLocation + "' not found");
/* 151 */         return;
/*     */       }
/*     */ 
/* 155 */       Boolean insideActionTag = (Boolean)ObjectUtils.defaultIfNull(request.getAttribute("struts.actiontag.invocation"), Boolean.FALSE);
/*     */ 
/* 160 */       if ((!insideActionTag.booleanValue()) && (!response.isCommitted()) && (request.getAttribute("javax.servlet.include.servlet_path") == null)) {
/* 161 */         request.setAttribute("struts.view_uri", finalLocation);
/* 162 */         request.setAttribute("struts.request_uri", request.getRequestURI());
/*     */ 
/* 164 */         dispatcher.forward(request, response);
/*     */       } else {
/* 166 */         dispatcher.include(request, response);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private Map<String, Object> getParameters(ActionInvocation invocation)
/*     */   {
/* 173 */     return (Map)invocation.getInvocationContext().getContextMap().get("parameters");
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.dispatcher.ServletDispatcherResult
 * JD-Core Version:    0.6.0
 */