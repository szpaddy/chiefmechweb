/*     */ package org.apache.struts2.dispatcher;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionContext;
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletRequestWrapper;
/*     */ import org.apache.commons.lang3.BooleanUtils;
/*     */ 
/*     */ public class StrutsRequestWrapper extends HttpServletRequestWrapper
/*     */ {
/*     */   private static final String REQUEST_WRAPPER_GET_ATTRIBUTE = "__requestWrapper.getAttribute";
/*     */   private final boolean disableRequestAttributeValueStackLookup;
/*     */ 
/*     */   public StrutsRequestWrapper(HttpServletRequest req)
/*     */   {
/*  54 */     this(req, false);
/*     */   }
/*     */ 
/*     */   public StrutsRequestWrapper(HttpServletRequest req, boolean disableRequestAttributeValueStackLookup)
/*     */   {
/*  63 */     super(req);
/*  64 */     this.disableRequestAttributeValueStackLookup = disableRequestAttributeValueStackLookup;
/*     */   }
/*     */ 
/*     */   public Object getAttribute(String key)
/*     */   {
/*  73 */     if (key == null) {
/*  74 */       throw new NullPointerException("You must specify a key value");
/*     */     }
/*     */ 
/*  77 */     if ((this.disableRequestAttributeValueStackLookup) || (key.startsWith("javax.servlet")))
/*     */     {
/*  80 */       return super.getAttribute(key);
/*     */     }
/*     */ 
/*  83 */     ActionContext ctx = ActionContext.getContext();
/*  84 */     Object attribute = super.getAttribute(key);
/*     */ 
/*  86 */     if ((ctx != null) && (attribute == null)) {
/*  87 */       boolean alreadyIn = BooleanUtils.isTrue((Boolean)ctx.get("__requestWrapper.getAttribute"));
/*     */ 
/*  91 */       if ((!alreadyIn) && (!key.contains("#"))) {
/*     */         try
/*     */         {
/*  94 */           ctx.put("__requestWrapper.getAttribute", Boolean.TRUE);
/*  95 */           ValueStack stack = ctx.getValueStack();
/*  96 */           if (stack != null)
/*  97 */             attribute = stack.findValue(key);
/*     */         }
/*     */         finally {
/* 100 */           ctx.put("__requestWrapper.getAttribute", Boolean.FALSE);
/*     */         }
/*     */       }
/*     */     }
/* 104 */     return attribute;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.dispatcher.StrutsRequestWrapper
 * JD-Core Version:    0.6.0
 */