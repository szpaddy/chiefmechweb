/*     */ package org.apache.struts2.dispatcher;
/*     */ 
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import com.opensymphony.xwork2.util.ClassLoaderUtil;
/*     */ import com.opensymphony.xwork2.util.logging.Logger;
/*     */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.net.URL;
/*     */ import java.net.URLDecoder;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Calendar;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.StringTokenizer;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.struts2.dispatcher.ng.HostConfig;
/*     */ 
/*     */ public class DefaultStaticContentLoader
/*     */   implements StaticContentLoader
/*     */ {
/*  69 */   private Logger LOG = LoggerFactory.getLogger(DefaultStaticContentLoader.class);
/*     */   protected List<String> pathPrefixes;
/*     */   protected boolean serveStatic;
/*     */   protected boolean serveStaticBrowserCache;
/*  89 */   protected final Calendar lastModifiedCal = Calendar.getInstance();
/*     */   protected String encoding;
/*     */ 
/*     */   @Inject("struts.serve.static")
/*     */   public void setServeStaticContent(String val)
/*     */   {
/* 105 */     this.serveStatic = "true".equals(val);
/*     */   }
/*     */ 
/*     */   @Inject("struts.serve.static.browserCache")
/*     */   public void setServeStaticBrowserCache(String val)
/*     */   {
/* 117 */     this.serveStaticBrowserCache = "true".equals(val);
/*     */   }
/*     */ 
/*     */   @Inject("struts.i18n.encoding")
/*     */   public void setEncoding(String val)
/*     */   {
/* 126 */     this.encoding = val;
/*     */   }
/*     */ 
/*     */   public void setHostConfig(HostConfig filterConfig)
/*     */   {
/* 135 */     String param = filterConfig.getInitParameter("packages");
/* 136 */     String packages = getAdditionalPackages();
/* 137 */     if (param != null) {
/* 138 */       packages = param + " " + packages;
/*     */     }
/* 140 */     this.pathPrefixes = parse(packages);
/*     */   }
/*     */ 
/*     */   protected String getAdditionalPackages() {
/* 144 */     return "org.apache.struts2.static template org.apache.struts2.interceptor.debugging static";
/*     */   }
/*     */ 
/*     */   protected List<String> parse(String packages)
/*     */   {
/* 155 */     if (packages == null) {
/* 156 */       return Collections.emptyList();
/*     */     }
/* 158 */     List pathPrefixes = new ArrayList();
/*     */ 
/* 160 */     StringTokenizer st = new StringTokenizer(packages, ", \n\t");
/* 161 */     while (st.hasMoreTokens()) {
/* 162 */       String pathPrefix = st.nextToken().replace('.', '/');
/* 163 */       if (!pathPrefix.endsWith("/")) {
/* 164 */         pathPrefix = pathPrefix + "/";
/*     */       }
/* 166 */       pathPrefixes.add(pathPrefix);
/*     */     }
/*     */ 
/* 169 */     return pathPrefixes;
/*     */   }
/*     */ 
/*     */   public void findStaticResource(String path, HttpServletRequest request, HttpServletResponse response)
/*     */     throws IOException
/*     */   {
/* 181 */     String name = cleanupPath(path);
/* 182 */     for (String pathPrefix : this.pathPrefixes) {
/* 183 */       URL resourceUrl = findResource(buildPath(name, pathPrefix));
/* 184 */       if (resourceUrl != null) {
/* 185 */         InputStream is = null;
/*     */         try
/*     */         {
/* 188 */           String pathEnding = buildPath(name, pathPrefix);
/* 189 */           if (resourceUrl.getFile().endsWith(pathEnding))
/* 190 */             is = resourceUrl.openStream();
/*     */         } catch (IOException ex) {
/*     */         }
/* 193 */         continue;
/*     */ 
/* 197 */         if (is != null) {
/* 198 */           process(is, path, request, response);
/* 199 */           return;
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 204 */     response.sendError(404);
/*     */   }
/*     */ 
/*     */   protected void process(InputStream is, String path, HttpServletRequest request, HttpServletResponse response) throws IOException {
/* 208 */     if (is != null) {
/* 209 */       Calendar cal = Calendar.getInstance();
/*     */ 
/* 212 */       long ifModifiedSince = 0L;
/*     */       try {
/* 214 */         ifModifiedSince = request.getDateHeader("If-Modified-Since");
/*     */       } catch (Exception e) {
/* 216 */         if (this.LOG.isWarnEnabled()) {
/* 217 */           this.LOG.warn("Invalid If-Modified-Since header value: '#0', ignoring", new String[] { request.getHeader("If-Modified-Since") });
/*     */         }
/*     */       }
/* 220 */       long lastModifiedMillis = this.lastModifiedCal.getTimeInMillis();
/* 221 */       long now = cal.getTimeInMillis();
/* 222 */       cal.add(5, 1);
/* 223 */       long expires = cal.getTimeInMillis();
/*     */ 
/* 225 */       if ((ifModifiedSince > 0L) && (ifModifiedSince <= lastModifiedMillis))
/*     */       {
/* 228 */         response.setDateHeader("Expires", expires);
/* 229 */         response.setStatus(304);
/* 230 */         is.close();
/* 231 */         return;
/*     */       }
/*     */ 
/* 235 */       String contentType = getContentType(path);
/* 236 */       if (contentType != null) {
/* 237 */         response.setContentType(contentType);
/*     */       }
/*     */ 
/* 240 */       if (this.serveStaticBrowserCache)
/*     */       {
/* 242 */         response.setDateHeader("Date", now);
/* 243 */         response.setDateHeader("Expires", expires);
/* 244 */         response.setDateHeader("Retry-After", expires);
/* 245 */         response.setHeader("Cache-Control", "public");
/* 246 */         response.setDateHeader("Last-Modified", lastModifiedMillis);
/*     */       } else {
/* 248 */         response.setHeader("Cache-Control", "no-cache");
/* 249 */         response.setHeader("Pragma", "no-cache");
/* 250 */         response.setHeader("Expires", "-1");
/*     */       }
/*     */       try
/*     */       {
/* 254 */         copy(is, response.getOutputStream());
/*     */       } finally {
/* 256 */         is.close();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   protected URL findResource(String path)
/*     */     throws IOException
/*     */   {
/* 269 */     return ClassLoaderUtil.getResource(path, getClass());
/*     */   }
/*     */ 
/*     */   protected String buildPath(String name, String packagePrefix)
/*     */     throws UnsupportedEncodingException
/*     */   {
/*     */     String resourcePath;
/*     */     String resourcePath;
/* 280 */     if ((packagePrefix.endsWith("/")) && (name.startsWith("/")))
/* 281 */       resourcePath = packagePrefix + name.substring(1);
/*     */     else {
/* 283 */       resourcePath = packagePrefix + name;
/*     */     }
/*     */ 
/* 286 */     return URLDecoder.decode(resourcePath, this.encoding);
/*     */   }
/*     */ 
/*     */   protected String getContentType(String name)
/*     */   {
/* 300 */     if (name.endsWith(".js"))
/* 301 */       return "text/javascript";
/* 302 */     if (name.endsWith(".css"))
/* 303 */       return "text/css";
/* 304 */     if (name.endsWith(".html"))
/* 305 */       return "text/html";
/* 306 */     if (name.endsWith(".txt"))
/* 307 */       return "text/plain";
/* 308 */     if (name.endsWith(".gif"))
/* 309 */       return "image/gif";
/* 310 */     if ((name.endsWith(".jpg")) || (name.endsWith(".jpeg")))
/* 311 */       return "image/jpeg";
/* 312 */     if (name.endsWith(".png")) {
/* 313 */       return "image/png";
/*     */     }
/* 315 */     return null;
/*     */   }
/*     */ 
/*     */   protected void copy(InputStream input, OutputStream output)
/*     */     throws IOException
/*     */   {
/* 330 */     byte[] buffer = new byte[4096];
/*     */     int n;
/* 332 */     while (-1 != (n = input.read(buffer))) {
/* 333 */       output.write(buffer, 0, n);
/*     */     }
/* 335 */     output.flush();
/*     */   }
/*     */ 
/*     */   public boolean canHandle(String resourcePath) {
/* 339 */     return (this.serveStatic) && ((resourcePath.startsWith("/struts/")) || (resourcePath.startsWith("/static/")));
/*     */   }
/*     */ 
/*     */   protected String cleanupPath(String path)
/*     */   {
/* 348 */     return path.substring(7);
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.dispatcher.DefaultStaticContentLoader
 * JD-Core Version:    0.6.0
 */