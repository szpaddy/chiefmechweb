/*    */ package org.apache.struts2.dispatcher;
/*    */ 
/*    */ import com.opensymphony.xwork2.inject.Container;
/*    */ 
/*    */ class ContainerHolder
/*    */ {
/* 15 */   private static ThreadLocal<Container> instance = new ThreadLocal();
/*    */ 
/*    */   public static void store(Container instance) {
/* 18 */     instance.set(instance);
/*    */   }
/*    */ 
/*    */   public static Container get() {
/* 22 */     return (Container)instance.get();
/*    */   }
/*    */ 
/*    */   public static void clear() {
/* 26 */     instance.remove();
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.dispatcher.ContainerHolder
 * JD-Core Version:    0.6.0
 */