/*     */ package org.apache.struts2.dispatcher;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionContext;
/*     */ import com.opensymphony.xwork2.inject.Container;
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import com.opensymphony.xwork2.util.ClassLoaderUtil;
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import com.opensymphony.xwork2.util.ValueStackFactory;
/*     */ import com.opensymphony.xwork2.util.logging.Logger;
/*     */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*     */ import com.opensymphony.xwork2.util.profiling.UtilTimerStack;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.servlet.Filter;
/*     */ import javax.servlet.FilterChain;
/*     */ import javax.servlet.FilterConfig;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.ServletResponse;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.struts2.RequestUtils;
/*     */ import org.apache.struts2.StrutsStatics;
/*     */ import org.apache.struts2.dispatcher.mapper.ActionMapper;
/*     */ import org.apache.struts2.dispatcher.mapper.ActionMapping;
/*     */ import org.apache.struts2.dispatcher.ng.filter.FilterHostConfig;
/*     */ 
/*     */ /** @deprecated */
/*     */ public class FilterDispatcher
/*     */   implements StrutsStatics, Filter
/*     */ {
/*     */   private Logger log;
/*     */   private ActionMapper actionMapper;
/*     */   private FilterConfig filterConfig;
/*     */   protected Dispatcher dispatcher;
/*     */   protected StaticContentLoader staticResourceLoader;
/* 178 */   private static ThreadLocal<Boolean> devModeOverride = new InheritableThreadLocal();
/*     */ 
/*     */   public void init(FilterConfig filterConfig)
/*     */     throws ServletException
/*     */   {
/*     */     try
/*     */     {
/* 188 */       this.filterConfig = filterConfig;
/*     */ 
/* 190 */       initLogging();
/*     */ 
/* 192 */       this.dispatcher = createDispatcher(filterConfig);
/* 193 */       this.dispatcher.init();
/* 194 */       this.dispatcher.getContainer().inject(this);
/*     */ 
/* 196 */       this.staticResourceLoader.setHostConfig(new FilterHostConfig(filterConfig));
/*     */     } finally {
/* 198 */       ActionContext.setContext(null);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void initLogging() {
/* 203 */     String factoryName = this.filterConfig.getInitParameter("loggerFactory");
/* 204 */     if (factoryName != null) {
/*     */       try {
/* 206 */         Class cls = ClassLoaderUtil.loadClass(factoryName, getClass());
/* 207 */         LoggerFactory fac = (LoggerFactory)cls.newInstance();
/* 208 */         LoggerFactory.setLoggerFactory(fac);
/*     */       } catch (InstantiationException e) {
/* 210 */         System.err.println("Unable to instantiate logger factory: " + factoryName + ", using default");
/* 211 */         e.printStackTrace();
/*     */       } catch (IllegalAccessException e) {
/* 213 */         System.err.println("Unable to access logger factory: " + factoryName + ", using default");
/* 214 */         e.printStackTrace();
/*     */       } catch (ClassNotFoundException e) {
/* 216 */         System.err.println("Unable to locate logger factory class: " + factoryName + ", using default");
/* 217 */         e.printStackTrace();
/*     */       }
/*     */     }
/*     */ 
/* 221 */     this.log = LoggerFactory.getLogger(FilterDispatcher.class);
/*     */   }
/*     */ 
/*     */   public void destroy()
/*     */   {
/* 232 */     if (this.dispatcher == null)
/* 233 */       this.log.warn("something is seriously wrong, Dispatcher is not initialized (null) ", new String[0]);
/*     */     else
/*     */       try {
/* 236 */         this.dispatcher.cleanup();
/*     */       } finally {
/* 238 */         ActionContext.setContext(null);
/*     */       }
/*     */   }
/*     */ 
/*     */   public static void overrideDevMode(boolean devMode)
/*     */   {
/* 253 */     devModeOverride.set(Boolean.valueOf(devMode));
/*     */   }
/*     */ 
/*     */   public static Boolean getDevModeOverride()
/*     */   {
/* 261 */     return (Boolean)devModeOverride.get();
/*     */   }
/*     */ 
/*     */   protected Dispatcher createDispatcher(FilterConfig filterConfig)
/*     */   {
/* 272 */     Map params = new HashMap();
/* 273 */     for (Enumeration e = filterConfig.getInitParameterNames(); e.hasMoreElements(); ) {
/* 274 */       String name = (String)e.nextElement();
/* 275 */       String value = filterConfig.getInitParameter(name);
/* 276 */       params.put(name, value);
/*     */     }
/* 278 */     return createDispatcher(filterConfig.getServletContext(), params);
/*     */   }
/*     */ 
/*     */   protected Dispatcher createDispatcher(ServletContext ctx, Map<String, String> params)
/*     */   {
/* 291 */     return new Dispatcher(ctx, params);
/*     */   }
/*     */ 
/*     */   @Inject
/*     */   public void setStaticResourceLoader(StaticContentLoader staticResourceLoader)
/*     */   {
/* 300 */     this.staticResourceLoader = staticResourceLoader;
/*     */   }
/*     */ 
/*     */   @Inject
/*     */   public void setActionMapper(ActionMapper mapper)
/*     */   {
/* 309 */     this.actionMapper = mapper;
/*     */   }
/*     */ 
/*     */   protected ServletContext getServletContext()
/*     */   {
/* 322 */     return this.filterConfig.getServletContext();
/*     */   }
/*     */ 
/*     */   protected FilterConfig getFilterConfig()
/*     */   {
/* 331 */     return this.filterConfig;
/*     */   }
/*     */ 
/*     */   protected HttpServletRequest prepareDispatcherAndWrapRequest(HttpServletRequest request, HttpServletResponse response)
/*     */     throws ServletException
/*     */   {
/* 345 */     Dispatcher du = Dispatcher.getInstance();
/*     */ 
/* 350 */     if (du == null)
/*     */     {
/* 352 */       Dispatcher.setInstance(this.dispatcher);
/*     */ 
/* 356 */       this.dispatcher.prepare(request, response);
/*     */     } else {
/* 358 */       this.dispatcher = du;
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 364 */       request = this.dispatcher.wrapRequest(request, getServletContext());
/*     */     } catch (IOException e) {
/* 366 */       String message = "Could not wrap servlet request with MultipartRequestWrapper!";
/* 367 */       this.log.error(message, e, new String[0]);
/* 368 */       throw new ServletException(message, e);
/*     */     }
/*     */ 
/* 371 */     return request;
/*     */   }
/*     */ 
/*     */   public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
/*     */     throws IOException, ServletException
/*     */   {
/* 391 */     showDeprecatedWarning();
/*     */ 
/* 393 */     HttpServletRequest request = (HttpServletRequest)req;
/* 394 */     HttpServletResponse response = (HttpServletResponse)res;
/* 395 */     ServletContext servletContext = getServletContext();
/*     */ 
/* 397 */     String timerKey = "FilterDispatcher_doFilter: ";
/*     */     try { ValueStack stack = ((ValueStackFactory)this.dispatcher.getContainer().getInstance(ValueStackFactory.class)).createValueStack();
/* 402 */       ActionContext ctx = new ActionContext(stack.getContext());
/* 403 */       ActionContext.setContext(ctx);
/*     */ 
/* 405 */       UtilTimerStack.push(timerKey);
/* 406 */       request = prepareDispatcherAndWrapRequest(request, response);
/*     */       ActionMapping mapping;
/*     */       try { mapping = this.actionMapper.getMapping(request, this.dispatcher.getConfigurationManager());
/*     */       } catch (Exception ex) {
/* 411 */         this.log.error("error getting ActionMapping", ex, new String[0]);
/* 412 */         this.dispatcher.sendError(request, response, servletContext, 500, ex);
/*     */ 
/* 437 */         this.dispatcher.cleanUpRequest(request);
/*     */         try {
/* 439 */           ActionContextCleanUp.cleanUp(req);
/*     */         } finally {
/* 441 */           UtilTimerStack.pop(timerKey);
/*     */         }
/* 443 */         devModeOverride.remove(); return;
/*     */       }
/* 416 */       if (mapping == null)
/*     */       {
/* 418 */         String resourcePath = RequestUtils.getServletPath(request);
/*     */ 
/* 420 */         if (("".equals(resourcePath)) && (null != request.getPathInfo())) {
/* 421 */           resourcePath = request.getPathInfo();
/*     */         }
/*     */ 
/* 424 */         if (this.staticResourceLoader.canHandle(resourcePath)) {
/* 425 */           this.staticResourceLoader.findStaticResource(resourcePath, request, response);
/*     */         }
/*     */         else {
/* 428 */           chain.doFilter(request, response);
/*     */         }
/*     */         return;
/*     */       }
/*     */ 
/* 434 */       this.dispatcher.serviceAction(request, response, servletContext, mapping);
/*     */     } finally
/*     */     {
/* 437 */       this.dispatcher.cleanUpRequest(request);
/*     */       try {
/* 439 */         ActionContextCleanUp.cleanUp(req);
/*     */       } finally {
/* 441 */         UtilTimerStack.pop(timerKey);
/*     */       }
/* 443 */       devModeOverride.remove();
/*     */     }
/*     */   }
/*     */ 
/*     */   private void showDeprecatedWarning() {
/* 448 */     String msg = "\n\n***********************************************************************\n*                               WARNING!!!                            *\n*                                                                     *\n* >>> FilterDispatcher <<< is deprecated! Please use the new filters! *\n*                                                                     *\n*           This can be a source of unpredictable problems!           *\n*                                                                     *\n*              Please refer to the docs for more details!             *\n*            http://struts.apache.org/2.x/docs/webxml.html            *\n*                                                                     *\n***********************************************************************\n\n";
/*     */ 
/* 461 */     System.out.println(msg);
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.dispatcher.FilterDispatcher
 * JD-Core Version:    0.6.0
 */