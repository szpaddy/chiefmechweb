/*     */ package org.apache.struts2.dispatcher;
/*     */ 
/*     */ import com.opensymphony.xwork2.util.logging.Logger;
/*     */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*     */ import javax.servlet.FilterConfig;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import org.apache.struts2.config.ServletContextSingleton;
/*     */ 
/*     */ /** @deprecated */
/*     */ public class FilterDispatcherCompatWeblogic61 extends FilterDispatcher
/*     */ {
/*  55 */   private static Logger LOG = LoggerFactory.getLogger(FilterDispatcherCompatWeblogic61.class);
/*     */ 
/*     */   public void setFilterConfig(FilterConfig filterConfig)
/*     */   {
/*     */     try
/*     */     {
/*  71 */       init(filterConfig);
/*     */     } catch (ServletException se) {
/*  73 */       LOG.error("Couldn't set the filter configuration in this filter", se, new String[0]);
/*     */     }
/*     */ 
/*  76 */     ServletContextSingleton singleton = ServletContextSingleton.getInstance();
/*  77 */     singleton.setServletContext(filterConfig.getServletContext());
/*     */   }
/*     */ 
/*     */   protected ServletContext getServletContext(HttpSession session)
/*     */   {
/*  93 */     ServletContextSingleton singleton = ServletContextSingleton.getInstance();
/*     */ 
/*  95 */     return singleton.getServletContext();
/*     */   }
/*     */ 
/*     */   public FilterConfig getFilterConfig()
/*     */   {
/* 106 */     return super.getFilterConfig();
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.dispatcher.FilterDispatcherCompatWeblogic61
 * JD-Core Version:    0.6.0
 */