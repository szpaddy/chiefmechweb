/*     */ package org.apache.struts2.dispatcher;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionContext;
/*     */ import com.opensymphony.xwork2.ActionInvocation;
/*     */ import com.opensymphony.xwork2.ActionProxy;
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import com.opensymphony.xwork2.util.logging.Logger;
/*     */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.Writer;
/*     */ import javax.servlet.Servlet;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.servlet.jsp.JspFactory;
/*     */ import javax.servlet.jsp.PageContext;
/*     */ import org.apache.struts2.ServletActionContext;
/*     */ import org.apache.struts2.views.JspSupportServlet;
/*     */ import org.apache.struts2.views.velocity.VelocityManager;
/*     */ import org.apache.velocity.Template;
/*     */ import org.apache.velocity.app.VelocityEngine;
/*     */ import org.apache.velocity.context.Context;
/*     */ 
/*     */ public class VelocityResult extends StrutsResultSupport
/*     */ {
/*     */   private static final long serialVersionUID = 7268830767762559424L;
/*  88 */   private static final Logger LOG = LoggerFactory.getLogger(VelocityResult.class);
/*     */   private String defaultEncoding;
/*     */   private VelocityManager velocityManager;
/*  92 */   private JspFactory jspFactory = JspFactory.getDefaultFactory();
/*     */ 
/*     */   public VelocityResult()
/*     */   {
/*     */   }
/*     */ 
/*     */   public VelocityResult(String location) {
/*  99 */     super(location);
/*     */   }
/*     */   @Inject("struts.i18n.encoding")
/*     */   public void setDefaultEncoding(String val) {
/* 104 */     this.defaultEncoding = val;
/*     */   }
/*     */   @Inject
/*     */   public void setVelocityManager(VelocityManager mgr) {
/* 109 */     this.velocityManager = mgr;
/*     */   }
/*     */ 
/*     */   public void doExecute(String finalLocation, ActionInvocation invocation)
/*     */     throws Exception
/*     */   {
/* 122 */     ValueStack stack = ActionContext.getContext().getValueStack();
/*     */ 
/* 124 */     HttpServletRequest request = ServletActionContext.getRequest();
/* 125 */     HttpServletResponse response = ServletActionContext.getResponse();
/* 126 */     ServletContext servletContext = ServletActionContext.getServletContext();
/* 127 */     Servlet servlet = JspSupportServlet.jspSupportServlet;
/*     */ 
/* 129 */     this.velocityManager.init(servletContext);
/*     */ 
/* 131 */     boolean usedJspFactory = false;
/* 132 */     PageContext pageContext = (PageContext)ActionContext.getContext().get("com.opensymphony.xwork2.dispatcher.PageContext");
/*     */ 
/* 134 */     if ((pageContext == null) && (servlet != null)) {
/* 135 */       pageContext = this.jspFactory.getPageContext(servlet, request, response, null, true, 8192, true);
/* 136 */       ActionContext.getContext().put("com.opensymphony.xwork2.dispatcher.PageContext", pageContext);
/* 137 */       usedJspFactory = true;
/*     */     }
/*     */     try
/*     */     {
/* 141 */       String encoding = getEncoding(finalLocation);
/* 142 */       String contentType = getContentType(finalLocation);
/*     */ 
/* 144 */       if (encoding != null) {
/* 145 */         contentType = contentType + ";charset=" + encoding;
/*     */       }
/*     */ 
/* 148 */       Template t = getTemplate(stack, this.velocityManager.getVelocityEngine(), invocation, finalLocation, encoding);
/*     */ 
/* 150 */       Context context = createContext(this.velocityManager, stack, request, response, finalLocation);
/* 151 */       Writer writer = new OutputStreamWriter(response.getOutputStream(), encoding);
/*     */ 
/* 154 */       response.setContentType(contentType);
/*     */ 
/* 156 */       t.merge(context, writer);
/*     */ 
/* 160 */       writer.flush();
/*     */     } catch (Exception e) {
/* 162 */       if (LOG.isErrorEnabled()) {
/* 163 */         LOG.error("Unable to render Velocity Template, '#0'", e, new String[] { finalLocation });
/*     */       }
/* 165 */       throw e;
/*     */     } finally {
/* 167 */       if (usedJspFactory)
/* 168 */         this.jspFactory.releasePageContext(pageContext);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected String getContentType(String templateLocation)
/*     */   {
/* 181 */     return "text/html";
/*     */   }
/*     */ 
/*     */   protected String getEncoding(String templateLocation)
/*     */   {
/* 192 */     String encoding = this.defaultEncoding;
/* 193 */     if (encoding == null) {
/* 194 */       encoding = System.getProperty("file.encoding");
/*     */     }
/* 196 */     if (encoding == null) {
/* 197 */       encoding = "UTF-8";
/*     */     }
/* 199 */     return encoding;
/*     */   }
/*     */ 
/*     */   protected Template getTemplate(ValueStack stack, VelocityEngine velocity, ActionInvocation invocation, String location, String encoding)
/*     */     throws Exception
/*     */   {
/* 215 */     if (!location.startsWith("/")) {
/* 216 */       location = invocation.getProxy().getNamespace() + "/" + location;
/*     */     }
/*     */ 
/* 219 */     Template template = velocity.getTemplate(location, encoding);
/*     */ 
/* 221 */     return template;
/*     */   }
/*     */ 
/*     */   protected Context createContext(VelocityManager velocityManager, ValueStack stack, HttpServletRequest request, HttpServletResponse response, String location)
/*     */   {
/* 233 */     return velocityManager.createContext(stack, request, response);
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.dispatcher.VelocityResult
 * JD-Core Version:    0.6.0
 */