/*     */ package org.apache.struts2.dispatcher;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.AbstractMap;
/*     */ import java.util.Collections;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpSession;
/*     */ 
/*     */ public class SessionMap<K, V> extends AbstractMap<K, V>
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 4678843241638046854L;
/*     */   protected HttpSession session;
/*     */   protected Set<Map.Entry<K, V>> entries;
/*     */   protected HttpServletRequest request;
/*     */ 
/*     */   public SessionMap(HttpServletRequest request)
/*     */   {
/*  59 */     this.request = request;
/*  60 */     this.session = request.getSession(false);
/*     */   }
/*     */ 
/*     */   public void invalidate()
/*     */   {
/*  67 */     if (this.session == null) {
/*  68 */       return;
/*     */     }
/*     */ 
/*  71 */     synchronized (this.session) {
/*  72 */       this.session.invalidate();
/*  73 */       this.session = null;
/*  74 */       this.entries = null;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void clear()
/*     */   {
/*  83 */     if (this.session == null) {
/*  84 */       return;
/*     */     }
/*     */ 
/*  87 */     synchronized (this.session) {
/*  88 */       this.entries = null;
/*  89 */       Enumeration attributeNamesEnum = this.session.getAttributeNames();
/*  90 */       while (attributeNamesEnum.hasMoreElements())
/*  91 */         this.session.removeAttribute((String)attributeNamesEnum.nextElement());
/*     */     }
/*     */   }
/*     */ 
/*     */   public Set<Map.Entry<K, V>> entrySet()
/*     */   {
/* 103 */     if (this.session == null) {
/* 104 */       return Collections.emptySet();
/*     */     }
/*     */ 
/* 107 */     synchronized (this.session) {
/* 108 */       if (this.entries == null) {
/* 109 */         this.entries = new HashSet();
/*     */ 
/* 111 */         Enumeration enumeration = this.session.getAttributeNames();
/*     */ 
/* 113 */         while (enumeration.hasMoreElements()) {
/* 114 */           String key = enumeration.nextElement().toString();
/* 115 */           Object value = this.session.getAttribute(key);
/* 116 */           this.entries.add(new Map.Entry(key, value) {
/*     */             public boolean equals(Object obj) {
/* 118 */               if (!(obj instanceof Map.Entry)) {
/* 119 */                 return false;
/*     */               }
/* 121 */               Map.Entry entry = (Map.Entry)obj;
/*     */ 
/* 123 */               return (this.val$key == null ? entry.getKey() == null : this.val$key.equals(entry.getKey())) && (this.val$value == null ? entry.getValue() == null : this.val$value.equals(entry.getValue()));
/*     */             }
/*     */ 
/*     */             public int hashCode() {
/* 127 */               return (this.val$key == null ? 0 : this.val$key.hashCode()) ^ (this.val$value == null ? 0 : this.val$value.hashCode());
/*     */             }
/*     */ 
/*     */             public K getKey() {
/* 131 */               return this.val$key;
/*     */             }
/*     */ 
/*     */             public V getValue() {
/* 135 */               return this.val$value;
/*     */             }
/*     */ 
/*     */             public V setValue(Object obj) {
/* 139 */               SessionMap.this.session.setAttribute(this.val$key, obj);
/*     */ 
/* 141 */               return this.val$value;
/*     */             }
/*     */           });
/*     */         }
/*     */       }
/*     */     }
/* 148 */     return this.entries;
/*     */   }
/*     */ 
/*     */   public V get(Object key)
/*     */   {
/* 158 */     if (this.session == null) {
/* 159 */       return null;
/*     */     }
/*     */ 
/* 162 */     synchronized (this.session) {
/* 163 */       return this.session.getAttribute(key.toString());
/*     */     }
/*     */   }
/*     */ 
/*     */   public V put(K key, V value)
/*     */   {
/* 175 */     synchronized (this) {
/* 176 */       if (this.session == null) {
/* 177 */         this.session = this.request.getSession(true);
/*     */       }
/*     */     }
/* 180 */     synchronized (this.session) {
/* 181 */       Object oldValue = get(key);
/* 182 */       this.entries = null;
/* 183 */       this.session.setAttribute(key.toString(), value);
/* 184 */       return oldValue;
/*     */     }
/*     */   }
/*     */ 
/*     */   public V remove(Object key)
/*     */   {
/* 195 */     if (this.session == null) {
/* 196 */       return null;
/*     */     }
/*     */ 
/* 199 */     synchronized (this.session) {
/* 200 */       this.entries = null;
/*     */ 
/* 202 */       Object value = get(key);
/* 203 */       this.session.removeAttribute(key.toString());
/*     */ 
/* 205 */       return value;
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean containsKey(Object key)
/*     */   {
/* 217 */     if (this.session == null) {
/* 218 */       return false;
/*     */     }
/*     */ 
/* 221 */     synchronized (this.session) {
/* 222 */       return this.session.getAttribute(key.toString()) != null;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.dispatcher.SessionMap
 * JD-Core Version:    0.6.0
 */