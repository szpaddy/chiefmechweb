/*     */ package org.apache.struts2.dispatcher;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionContext;
/*     */ import com.opensymphony.xwork2.util.logging.Logger;
/*     */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*     */ import com.opensymphony.xwork2.util.profiling.UtilTimerStack;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import javax.servlet.Filter;
/*     */ import javax.servlet.FilterChain;
/*     */ import javax.servlet.FilterConfig;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.ServletResponse;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ 
/*     */ /** @deprecated */
/*     */ public class ActionContextCleanUp
/*     */   implements Filter
/*     */ {
/*  73 */   private static final Logger LOG = LoggerFactory.getLogger(ActionContextCleanUp.class);
/*     */   private static final String COUNTER = "__cleanup_recursion_counter";
/*     */ 
/*     */   public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
/*     */     throws IOException, ServletException
/*     */   {
/*  82 */     showDeprecatedWarning();
/*     */ 
/*  84 */     HttpServletRequest request = (HttpServletRequest)req;
/*  85 */     HttpServletResponse response = (HttpServletResponse)res;
/*     */ 
/*  87 */     String timerKey = "ActionContextCleanUp_doFilter: ";
/*     */     try {
/*  89 */       UtilTimerStack.push(timerKey);
/*     */       try
/*     */       {
/*  92 */         Integer count = (Integer)request.getAttribute("__cleanup_recursion_counter");
/*  93 */         if (count == null) {
/*  94 */           count = Integer.valueOf(1);
/*     */         }
/*     */         else {
/*  97 */           count = Integer.valueOf(count.intValue() + 1);
/*     */         }
/*  99 */         request.setAttribute("__cleanup_recursion_counter", count);
/*     */ 
/* 103 */         chain.doFilter(request, response);
/*     */       }
/*     */       finally
/*     */       {
/*     */         int counterVal;
/* 105 */         int counterVal = ((Integer)request.getAttribute("__cleanup_recursion_counter")).intValue();
/* 106 */         counterVal--;
/* 107 */         request.setAttribute("__cleanup_recursion_counter", Integer.valueOf(counterVal));
/* 108 */         cleanUp(request);
/*     */       }
/*     */     }
/*     */     finally {
/* 112 */       UtilTimerStack.pop(timerKey);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected static void cleanUp(ServletRequest req)
/*     */   {
/* 123 */     Integer count = (Integer)req.getAttribute("__cleanup_recursion_counter");
/* 124 */     if ((count != null) && (count.intValue() > 0)) {
/* 125 */       if (LOG.isDebugEnabled()) {
/* 126 */         LOG.debug("skipping cleanup counter=" + count, new String[0]);
/*     */       }
/* 128 */       return;
/*     */     }
/*     */ 
/* 132 */     ActionContext.setContext(null);
/* 133 */     Dispatcher.setInstance(null);
/*     */   }
/*     */ 
/*     */   public void destroy() {
/*     */   }
/*     */ 
/*     */   public void init(FilterConfig arg0) throws ServletException {
/*     */   }
/*     */ 
/*     */   private void showDeprecatedWarning() {
/* 143 */     String msg = "\n\n***************************************************************************\n*                                 WARNING!!!                              *\n*                                                                         *\n* >>> ActionContextCleanUp <<< is deprecated! Please use the new filters! *\n*                                                                         *\n*             This can be a source of unpredictable problems!             *\n*                                                                         *\n*                Please refer to the docs for more details!               *\n*              http://struts.apache.org/2.x/docs/webxml.html              *\n*                                                                         *\n***************************************************************************\n\n";
/*     */ 
/* 156 */     System.out.println(msg);
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.dispatcher.ActionContextCleanUp
 * JD-Core Version:    0.6.0
 */