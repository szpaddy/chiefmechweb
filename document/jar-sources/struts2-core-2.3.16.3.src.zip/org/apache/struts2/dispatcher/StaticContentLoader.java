package org.apache.struts2.dispatcher;

import java.io.IOException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.struts2.dispatcher.ng.HostConfig;

public abstract interface StaticContentLoader
{
  public abstract boolean canHandle(String paramString);

  public abstract void setHostConfig(HostConfig paramHostConfig);

  public abstract void findStaticResource(String paramString, HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse)
    throws IOException;
}

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.dispatcher.StaticContentLoader
 * JD-Core Version:    0.6.0
 */