/*     */ package org.apache.struts2.dispatcher;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionContext;
/*     */ import com.opensymphony.xwork2.ActionInvocation;
/*     */ import com.opensymphony.xwork2.ActionProxy;
/*     */ import com.opensymphony.xwork2.config.entities.ActionConfig;
/*     */ import com.opensymphony.xwork2.config.entities.ResultConfig;
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import com.opensymphony.xwork2.util.logging.Logger;
/*     */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*     */ import com.opensymphony.xwork2.util.reflection.ReflectionException;
/*     */ import com.opensymphony.xwork2.util.reflection.ReflectionExceptionHandler;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import java.util.Arrays;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.struts2.dispatcher.mapper.ActionMapper;
/*     */ import org.apache.struts2.dispatcher.mapper.ActionMapping;
/*     */ import org.apache.struts2.views.util.UrlHelper;
/*     */ 
/*     */ public class ServletRedirectResult extends StrutsResultSupport
/*     */   implements ReflectionExceptionHandler
/*     */ {
/*     */   private static final long serialVersionUID = 6316947346435301270L;
/* 100 */   private static final Logger LOG = LoggerFactory.getLogger(ServletRedirectResult.class);
/*     */ 
/* 102 */   protected boolean prependServletContext = true;
/*     */   protected ActionMapper actionMapper;
/* 104 */   protected int statusCode = 302;
/* 105 */   protected boolean suppressEmptyParameters = false;
/* 106 */   protected Map<String, Object> requestParameters = new LinkedHashMap();
/*     */   protected String anchor;
/*     */   private UrlHelper urlHelper;
/*     */ 
/*     */   public ServletRedirectResult()
/*     */   {
/*     */   }
/*     */ 
/*     */   public ServletRedirectResult(String location)
/*     */   {
/* 116 */     this(location, null);
/*     */   }
/*     */ 
/*     */   public ServletRedirectResult(String location, String anchor) {
/* 120 */     super(location);
/* 121 */     this.anchor = anchor;
/*     */   }
/*     */   @Inject
/*     */   public void setActionMapper(ActionMapper mapper) {
/* 126 */     this.actionMapper = mapper;
/*     */   }
/*     */   @Inject
/*     */   public void setUrlHelper(UrlHelper urlHelper) {
/* 131 */     this.urlHelper = urlHelper;
/*     */   }
/*     */ 
/*     */   public void setStatusCode(int code) {
/* 135 */     this.statusCode = code;
/*     */   }
/*     */ 
/*     */   public void setAnchor(String anchor)
/*     */   {
/* 144 */     this.anchor = anchor;
/*     */   }
/*     */ 
/*     */   public void setPrependServletContext(boolean prependServletContext)
/*     */   {
/* 154 */     this.prependServletContext = prependServletContext;
/*     */   }
/*     */ 
/*     */   public void execute(ActionInvocation invocation) throws Exception {
/* 158 */     if (this.anchor != null) {
/* 159 */       this.anchor = conditionalParse(this.anchor, invocation);
/*     */     }
/* 161 */     super.execute(invocation);
/*     */   }
/*     */ 
/*     */   protected void doExecute(String finalLocation, ActionInvocation invocation)
/*     */     throws Exception
/*     */   {
/* 173 */     ActionContext ctx = invocation.getInvocationContext();
/* 174 */     HttpServletRequest request = (HttpServletRequest)ctx.get("com.opensymphony.xwork2.dispatcher.HttpServletRequest");
/* 175 */     HttpServletResponse response = (HttpServletResponse)ctx.get("com.opensymphony.xwork2.dispatcher.HttpServletResponse");
/*     */ 
/* 177 */     if (isPathUrl(finalLocation)) {
/* 178 */       if (!finalLocation.startsWith("/")) {
/* 179 */         ActionMapping mapping = this.actionMapper.getMapping(request, Dispatcher.getInstance().getConfigurationManager());
/* 180 */         String namespace = null;
/* 181 */         if (mapping != null) {
/* 182 */           namespace = mapping.getNamespace();
/*     */         }
/*     */ 
/* 185 */         if ((namespace != null) && (namespace.length() > 0) && (!"/".equals(namespace)))
/* 186 */           finalLocation = namespace + "/" + finalLocation;
/*     */         else {
/* 188 */           finalLocation = "/" + finalLocation;
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 193 */       if ((this.prependServletContext) && (request.getContextPath() != null) && (request.getContextPath().length() > 0)) {
/* 194 */         finalLocation = request.getContextPath() + finalLocation;
/*     */       }
/*     */ 
/* 197 */       ResultConfig resultConfig = (ResultConfig)invocation.getProxy().getConfig().getResults().get(invocation.getResultCode());
/*     */       List prohibitedResultParams;
/* 198 */       if (resultConfig != null) {
/* 199 */         Map resultConfigParams = resultConfig.getParams();
/*     */ 
/* 201 */         prohibitedResultParams = getProhibitedResultParams();
/* 202 */         for (Map.Entry e : resultConfigParams.entrySet()) {
/* 203 */           if (!prohibitedResultParams.contains(e.getKey())) {
/* 204 */             String potentialValue = e.getValue() == null ? "" : conditionalParse((String)e.getValue(), invocation);
/* 205 */             if ((!this.suppressEmptyParameters) || ((potentialValue != null) && (potentialValue.length() > 0))) {
/* 206 */               this.requestParameters.put(e.getKey(), potentialValue);
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/* 212 */       StringBuilder tmpLocation = new StringBuilder(finalLocation);
/* 213 */       this.urlHelper.buildParametersString(this.requestParameters, tmpLocation, "&");
/*     */ 
/* 216 */       if (this.anchor != null) {
/* 217 */         tmpLocation.append('#').append(this.anchor);
/*     */       }
/*     */ 
/* 220 */       finalLocation = response.encodeRedirectURL(tmpLocation.toString());
/*     */     }
/*     */ 
/* 223 */     if (LOG.isDebugEnabled()) {
/* 224 */       LOG.debug("Redirecting to finalLocation " + finalLocation, new String[0]);
/*     */     }
/*     */ 
/* 227 */     sendRedirect(response, finalLocation);
/*     */   }
/*     */ 
/*     */   protected List<String> getProhibitedResultParams() {
/* 231 */     return Arrays.asList(new String[] { "location", "namespace", "method", "encode", "parse", "location", "prependServletContext", "suppressEmptyParameters", "anchor", "statusCode" });
/*     */   }
/*     */ 
/*     */   protected void sendRedirect(HttpServletResponse response, String finalLocation)
/*     */     throws IOException
/*     */   {
/* 254 */     if (302 == this.statusCode) {
/* 255 */       response.sendRedirect(finalLocation);
/*     */     } else {
/* 257 */       response.setStatus(this.statusCode);
/* 258 */       response.setHeader("Location", finalLocation);
/* 259 */       response.getWriter().write(finalLocation);
/* 260 */       response.getWriter().close();
/*     */     }
/*     */   }
/*     */ 
/*     */   private boolean isPathUrl(String url)
/*     */   {
/* 267 */     return (!url.startsWith("http:")) && (!url.startsWith("https:")) && (!url.startsWith("mailto:")) && (!url.startsWith("file:")) && (!url.startsWith("ftp:"));
/*     */   }
/*     */ 
/*     */   public void setSuppressEmptyParameters(boolean suppressEmptyParameters)
/*     */   {
/* 280 */     this.suppressEmptyParameters = suppressEmptyParameters;
/*     */   }
/*     */ 
/*     */   public ServletRedirectResult addParameter(String key, Object value)
/*     */   {
/* 290 */     this.requestParameters.put(key, String.valueOf(value));
/* 291 */     return this;
/*     */   }
/*     */ 
/*     */   public void handle(ReflectionException ex)
/*     */   {
/* 296 */     if (LOG.isDebugEnabled())
/* 297 */       LOG.debug(ex.getMessage(), ex, new String[0]);
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.dispatcher.ServletRedirectResult
 * JD-Core Version:    0.6.0
 */