/*     */ package org.apache.struts2.dispatcher;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionContext;
/*     */ import com.opensymphony.xwork2.ActionInvocation;
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import com.opensymphony.xwork2.util.logging.Logger;
/*     */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ 
/*     */ public class StreamResult extends StrutsResultSupport
/*     */ {
/*     */   private static final long serialVersionUID = -1468409635999059850L;
/*  94 */   protected static final Logger LOG = LoggerFactory.getLogger(StreamResult.class);
/*     */   public static final String DEFAULT_PARAM = "inputName";
/*  98 */   protected String contentType = "text/plain";
/*     */   protected String contentLength;
/* 100 */   protected String contentDisposition = "inline";
/*     */   protected String contentCharSet;
/* 102 */   protected String inputName = "inputStream";
/*     */   protected InputStream inputStream;
/* 104 */   protected int bufferSize = 1024;
/* 105 */   protected boolean allowCaching = true;
/*     */ 
/*     */   public StreamResult()
/*     */   {
/*     */   }
/*     */ 
/*     */   public StreamResult(InputStream in) {
/* 112 */     this.inputStream = in;
/*     */   }
/*     */ 
/*     */   public boolean getAllowCaching()
/*     */   {
/* 119 */     return this.allowCaching;
/*     */   }
/*     */ 
/*     */   public void setAllowCaching(boolean allowCaching)
/*     */   {
/* 129 */     this.allowCaching = allowCaching;
/*     */   }
/*     */ 
/*     */   public int getBufferSize()
/*     */   {
/* 137 */     return this.bufferSize;
/*     */   }
/*     */ 
/*     */   public void setBufferSize(int bufferSize)
/*     */   {
/* 144 */     this.bufferSize = bufferSize;
/*     */   }
/*     */ 
/*     */   public String getContentType()
/*     */   {
/* 151 */     return this.contentType;
/*     */   }
/*     */ 
/*     */   public void setContentType(String contentType)
/*     */   {
/* 158 */     this.contentType = contentType;
/*     */   }
/*     */ 
/*     */   public String getContentLength()
/*     */   {
/* 165 */     return this.contentLength;
/*     */   }
/*     */ 
/*     */   public void setContentLength(String contentLength)
/*     */   {
/* 172 */     this.contentLength = contentLength;
/*     */   }
/*     */ 
/*     */   public String getContentDisposition()
/*     */   {
/* 179 */     return this.contentDisposition;
/*     */   }
/*     */ 
/*     */   public void setContentDisposition(String contentDisposition)
/*     */   {
/* 186 */     this.contentDisposition = contentDisposition;
/*     */   }
/*     */ 
/*     */   public String getContentCharSet()
/*     */   {
/* 193 */     return this.contentCharSet;
/*     */   }
/*     */ 
/*     */   public void setContentCharSet(String contentCharSet)
/*     */   {
/* 200 */     this.contentCharSet = contentCharSet;
/*     */   }
/*     */ 
/*     */   public String getInputName()
/*     */   {
/* 207 */     return this.inputName;
/*     */   }
/*     */ 
/*     */   public void setInputName(String inputName)
/*     */   {
/* 214 */     this.inputName = inputName;
/*     */   }
/*     */ 
/*     */   protected void doExecute(String finalLocation, ActionInvocation invocation)
/*     */     throws Exception
/*     */   {
/* 223 */     resolveParamsFromStack(invocation.getStack(), invocation);
/*     */ 
/* 225 */     OutputStream oOutput = null;
/*     */     try
/*     */     {
/* 228 */       if (this.inputStream == null)
/*     */       {
/* 230 */         this.inputStream = ((InputStream)invocation.getStack().findValue(conditionalParse(this.inputName, invocation)));
/*     */       }
/*     */ 
/* 233 */       if (this.inputStream == null) {
/* 234 */         String msg = "Can not find a java.io.InputStream with the name [" + this.inputName + "] in the invocation stack. " + "Check the <param name=\"inputName\"> tag specified for this action.";
/*     */ 
/* 236 */         LOG.error(msg, new String[0]);
/* 237 */         throw new IllegalArgumentException(msg);
/*     */       }
/*     */ 
/* 241 */       HttpServletResponse oResponse = (HttpServletResponse)invocation.getInvocationContext().get("com.opensymphony.xwork2.dispatcher.HttpServletResponse");
/*     */ 
/* 244 */       if ((this.contentCharSet != null) && (!this.contentCharSet.equals(""))) {
/* 245 */         oResponse.setContentType(conditionalParse(this.contentType, invocation) + ";charset=" + this.contentCharSet);
/*     */       }
/*     */       else {
/* 248 */         oResponse.setContentType(conditionalParse(this.contentType, invocation));
/*     */       }
/*     */ 
/* 252 */       if (this.contentLength != null) {
/* 253 */         String _contentLength = conditionalParse(this.contentLength, invocation);
/* 254 */         int _contentLengthAsInt = -1;
/*     */         try {
/* 256 */           _contentLengthAsInt = Integer.parseInt(_contentLength);
/* 257 */           if (_contentLengthAsInt >= 0)
/* 258 */             oResponse.setContentLength(_contentLengthAsInt);
/*     */         }
/*     */         catch (NumberFormatException e)
/*     */         {
/* 262 */           if (LOG.isWarnEnabled()) {
/* 263 */             LOG.warn("failed to recongnize " + _contentLength + " as a number, contentLength header will not be set", e, new String[0]);
/*     */           }
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 269 */       if (this.contentDisposition != null) {
/* 270 */         oResponse.addHeader("Content-Disposition", conditionalParse(this.contentDisposition, invocation));
/*     */       }
/*     */ 
/* 274 */       if (!this.allowCaching) {
/* 275 */         oResponse.addHeader("Pragma", "no-cache");
/* 276 */         oResponse.addHeader("Cache-Control", "no-cache");
/*     */       }
/*     */ 
/* 280 */       oOutput = oResponse.getOutputStream();
/*     */ 
/* 282 */       if (LOG.isDebugEnabled()) {
/* 283 */         LOG.debug("Streaming result [" + this.inputName + "] type=[" + this.contentType + "] length=[" + this.contentLength + "] content-disposition=[" + this.contentDisposition + "] charset=[" + this.contentCharSet + "]", new String[0]);
/*     */       }
/*     */ 
/* 288 */       if (LOG.isDebugEnabled()) {
/* 289 */         LOG.debug("Streaming to output buffer +++ START +++", new String[0]);
/*     */       }
/* 291 */       byte[] oBuff = new byte[this.bufferSize];
/*     */       int iSize;
/* 293 */       while (-1 != (iSize = this.inputStream.read(oBuff))) {
/* 294 */         oOutput.write(oBuff, 0, iSize);
/*     */       }
/* 296 */       if (LOG.isDebugEnabled()) {
/* 297 */         LOG.debug("Streaming to output buffer +++ END +++", new String[0]);
/*     */       }
/*     */ 
/* 301 */       oOutput.flush();
/*     */     }
/*     */     finally {
/* 304 */       if (this.inputStream != null) this.inputStream.close();
/* 305 */       if (oOutput != null) oOutput.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void resolveParamsFromStack(ValueStack stack, ActionInvocation invocation)
/*     */   {
/* 315 */     String disposition = stack.findString("contentDisposition");
/* 316 */     if (disposition != null) {
/* 317 */       setContentDisposition(disposition);
/*     */     }
/*     */ 
/* 320 */     String contentType = stack.findString("contentType");
/* 321 */     if (contentType != null) {
/* 322 */       setContentType(contentType);
/*     */     }
/*     */ 
/* 325 */     String inputName = stack.findString("inputName");
/* 326 */     if (inputName != null) {
/* 327 */       setInputName(inputName);
/*     */     }
/*     */ 
/* 330 */     String contentLength = stack.findString("contentLength");
/* 331 */     if (contentLength != null) {
/* 332 */       setContentLength(contentLength);
/*     */     }
/*     */ 
/* 335 */     Integer bufferSize = (Integer)stack.findValue("bufferSize", Integer.class);
/* 336 */     if (bufferSize != null) {
/* 337 */       setBufferSize(bufferSize.intValue());
/*     */     }
/*     */ 
/* 340 */     if (this.contentCharSet != null) {
/* 341 */       this.contentCharSet = conditionalParse(this.contentCharSet, invocation);
/*     */     }
/*     */     else
/* 344 */       this.contentCharSet = stack.findString("contentCharSet");
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.dispatcher.StreamResult
 * JD-Core Version:    0.6.0
 */