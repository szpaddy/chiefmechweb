/*     */ package org.apache.struts2.dispatcher.multipart;
/*     */ 
/*     */ import com.opensymphony.xwork2.LocaleProvider;
/*     */ import com.opensymphony.xwork2.util.LocalizedTextUtil;
/*     */ import com.opensymphony.xwork2.util.logging.Logger;
/*     */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Vector;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.apache.struts2.dispatcher.StrutsRequestWrapper;
/*     */ 
/*     */ public class MultiPartRequestWrapper extends StrutsRequestWrapper
/*     */ {
/*  60 */   protected static final Logger LOG = LoggerFactory.getLogger(MultiPartRequestWrapper.class);
/*     */   private Collection<String> errors;
/*     */   private MultiPartRequest multi;
/*  64 */   private Locale defaultLocale = Locale.ENGLISH;
/*     */ 
/*     */   public MultiPartRequestWrapper(MultiPartRequest multiPartRequest, HttpServletRequest request, String saveDir, LocaleProvider provider)
/*     */   {
/*  75 */     super(request);
/*  76 */     this.errors = new ArrayList();
/*  77 */     this.multi = multiPartRequest;
/*  78 */     this.defaultLocale = provider.getLocale();
/*  79 */     setLocale(request);
/*     */     try {
/*  81 */       this.multi.parse(request, saveDir);
/*  82 */       for (String error : this.multi.getErrors())
/*  83 */         addError(error);
/*     */     }
/*     */     catch (IOException e) {
/*  86 */       if (LOG.isWarnEnabled()) {
/*  87 */         LOG.warn(e.getMessage(), e, new String[0]);
/*     */       }
/*  89 */       addError(buildErrorMessage(e, new Object[] { e.getMessage() }));
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void setLocale(HttpServletRequest request) {
/*  94 */     if (this.defaultLocale == null)
/*  95 */       this.defaultLocale = request.getLocale();
/*     */   }
/*     */ 
/*     */   protected String buildErrorMessage(Throwable e, Object[] args)
/*     */   {
/* 100 */     String errorKey = "struts.messages.upload.error." + e.getClass().getSimpleName();
/* 101 */     if (LOG.isDebugEnabled()) {
/* 102 */       LOG.debug("Preparing error message for key: [#0]", new String[] { errorKey });
/*     */     }
/* 104 */     return LocalizedTextUtil.findText(getClass(), errorKey, this.defaultLocale, e.getMessage(), args);
/*     */   }
/*     */ 
/*     */   public Enumeration<String> getFileParameterNames()
/*     */   {
/* 113 */     if (this.multi == null) {
/* 114 */       return null;
/*     */     }
/*     */ 
/* 117 */     return this.multi.getFileParameterNames();
/*     */   }
/*     */ 
/*     */   public String[] getContentTypes(String name)
/*     */   {
/* 128 */     if (this.multi == null) {
/* 129 */       return null;
/*     */     }
/*     */ 
/* 132 */     return this.multi.getContentType(name);
/*     */   }
/*     */ 
/*     */   public File[] getFiles(String fieldName)
/*     */   {
/* 142 */     if (this.multi == null) {
/* 143 */       return null;
/*     */     }
/*     */ 
/* 146 */     return this.multi.getFile(fieldName);
/*     */   }
/*     */ 
/*     */   public String[] getFileNames(String fieldName)
/*     */   {
/* 156 */     if (this.multi == null) {
/* 157 */       return null;
/*     */     }
/*     */ 
/* 160 */     return this.multi.getFileNames(fieldName);
/*     */   }
/*     */ 
/*     */   public String[] getFileSystemNames(String fieldName)
/*     */   {
/* 172 */     if (this.multi == null) {
/* 173 */       return null;
/*     */     }
/*     */ 
/* 176 */     return this.multi.getFilesystemName(fieldName);
/*     */   }
/*     */ 
/*     */   public String getParameter(String name)
/*     */   {
/* 183 */     return (this.multi == null) || (this.multi.getParameter(name) == null) ? super.getParameter(name) : this.multi.getParameter(name);
/*     */   }
/*     */ 
/*     */   public Map getParameterMap()
/*     */   {
/* 190 */     Map map = new HashMap();
/* 191 */     Enumeration enumeration = getParameterNames();
/*     */ 
/* 193 */     while (enumeration.hasMoreElements()) {
/* 194 */       String name = (String)enumeration.nextElement();
/* 195 */       map.put(name, getParameterValues(name));
/*     */     }
/*     */ 
/* 198 */     return map;
/*     */   }
/*     */ 
/*     */   public Enumeration getParameterNames()
/*     */   {
/* 205 */     if (this.multi == null) {
/* 206 */       return super.getParameterNames();
/*     */     }
/* 208 */     return mergeParams(this.multi.getParameterNames(), super.getParameterNames());
/*     */   }
/*     */ 
/*     */   public String[] getParameterValues(String name)
/*     */   {
/* 216 */     return (this.multi == null) || (this.multi.getParameterValues(name) == null) ? super.getParameterValues(name) : this.multi.getParameterValues(name);
/*     */   }
/*     */ 
/*     */   public boolean hasErrors()
/*     */   {
/* 225 */     return !this.errors.isEmpty();
/*     */   }
/*     */ 
/*     */   public Collection<String> getErrors()
/*     */   {
/* 234 */     return this.errors;
/*     */   }
/*     */ 
/*     */   protected void addError(String anErrorMessage)
/*     */   {
/* 243 */     if (!this.errors.contains(anErrorMessage))
/* 244 */       this.errors.add(anErrorMessage);
/*     */   }
/*     */ 
/*     */   protected Enumeration mergeParams(Enumeration params1, Enumeration params2)
/*     */   {
/* 256 */     Vector temp = new Vector();
/*     */ 
/* 258 */     while (params1.hasMoreElements()) {
/* 259 */       temp.add(params1.nextElement());
/*     */     }
/*     */ 
/* 262 */     while (params2.hasMoreElements()) {
/* 263 */       temp.add(params2.nextElement());
/*     */     }
/*     */ 
/* 266 */     return temp.elements();
/*     */   }
/*     */ 
/*     */   public void cleanUp() {
/* 270 */     if (this.multi != null)
/* 271 */       this.multi.cleanUp();
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.dispatcher.multipart.MultiPartRequestWrapper
 * JD-Core Version:    0.6.0
 */