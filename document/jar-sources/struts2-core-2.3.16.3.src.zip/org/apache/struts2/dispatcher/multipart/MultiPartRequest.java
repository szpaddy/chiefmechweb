package org.apache.struts2.dispatcher.multipart;

import java.io.File;
import java.io.IOException;
import java.util.Enumeration;
import java.util.List;
import javax.servlet.http.HttpServletRequest;

public abstract interface MultiPartRequest
{
  public abstract void parse(HttpServletRequest paramHttpServletRequest, String paramString)
    throws IOException;

  public abstract Enumeration<String> getFileParameterNames();

  public abstract String[] getContentType(String paramString);

  public abstract File[] getFile(String paramString);

  public abstract String[] getFileNames(String paramString);

  public abstract String[] getFilesystemName(String paramString);

  public abstract String getParameter(String paramString);

  public abstract Enumeration<String> getParameterNames();

  public abstract String[] getParameterValues(String paramString);

  public abstract List<String> getErrors();

  public abstract void cleanUp();
}

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.dispatcher.multipart.MultiPartRequest
 * JD-Core Version:    0.6.0
 */