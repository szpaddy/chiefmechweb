/*     */ package org.apache.struts2.dispatcher.multipart;
/*     */ 
/*     */ import com.opensymphony.xwork2.LocaleProvider;
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import com.opensymphony.xwork2.util.LocalizedTextUtil;
/*     */ import com.opensymphony.xwork2.util.logging.Logger;
/*     */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.apache.commons.fileupload.FileItem;
/*     */ import org.apache.commons.fileupload.FileUploadBase.SizeLimitExceededException;
/*     */ import org.apache.commons.fileupload.FileUploadException;
/*     */ import org.apache.commons.fileupload.RequestContext;
/*     */ import org.apache.commons.fileupload.disk.DiskFileItem;
/*     */ import org.apache.commons.fileupload.disk.DiskFileItemFactory;
/*     */ import org.apache.commons.fileupload.servlet.ServletFileUpload;
/*     */ 
/*     */ public class JakartaMultiPartRequest
/*     */   implements MultiPartRequest
/*     */ {
/*  57 */   static final Logger LOG = LoggerFactory.getLogger(JakartaMultiPartRequest.class);
/*     */ 
/*  60 */   protected Map<String, List<FileItem>> files = new HashMap();
/*     */ 
/*  63 */   protected Map<String, List<String>> params = new HashMap();
/*     */ 
/*  66 */   protected List<String> errors = new ArrayList();
/*     */   protected long maxSize;
/*  69 */   private Locale defaultLocale = Locale.ENGLISH;
/*     */ 
/*  73 */   @Inject("struts.multipart.maxSize")
/*     */   public void setMaxSize(String maxSize) { this.maxSize = Long.parseLong(maxSize); }
/*     */ 
/*     */   @Inject
/*     */   public void setLocaleProvider(LocaleProvider provider) {
/*  78 */     this.defaultLocale = provider.getLocale();
/*     */   }
/*     */ 
/*     */   public void parse(HttpServletRequest request, String saveDir)
/*     */     throws IOException
/*     */   {
/*     */     try
/*     */     {
/*  91 */       setLocale(request);
/*  92 */       processUpload(request, saveDir);
/*     */     } catch (FileUploadBase.SizeLimitExceededException e) {
/*  94 */       if (LOG.isWarnEnabled()) {
/*  95 */         LOG.warn("Request exceeded size limit!", e, new String[0]);
/*     */       }
/*  97 */       String errorMessage = buildErrorMessage(e, new Object[] { Long.valueOf(e.getPermittedSize()), Long.valueOf(e.getActualSize()) });
/*  98 */       if (!this.errors.contains(errorMessage))
/*  99 */         this.errors.add(errorMessage);
/*     */     }
/*     */     catch (Exception e) {
/* 102 */       if (LOG.isWarnEnabled()) {
/* 103 */         LOG.warn("Unable to parse request", e, new String[0]);
/*     */       }
/* 105 */       String errorMessage = buildErrorMessage(e, new Object[0]);
/* 106 */       if (!this.errors.contains(errorMessage))
/* 107 */         this.errors.add(errorMessage);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void setLocale(HttpServletRequest request)
/*     */   {
/* 113 */     if (this.defaultLocale == null)
/* 114 */       this.defaultLocale = request.getLocale();
/*     */   }
/*     */ 
/*     */   protected String buildErrorMessage(Throwable e, Object[] args)
/*     */   {
/* 119 */     String errorKey = "struts.messages.upload.error." + e.getClass().getSimpleName();
/* 120 */     if (LOG.isDebugEnabled()) {
/* 121 */       LOG.debug("Preparing error message for key: [#0]", new String[] { errorKey });
/*     */     }
/* 123 */     return LocalizedTextUtil.findText(getClass(), errorKey, this.defaultLocale, e.getMessage(), args);
/*     */   }
/*     */ 
/*     */   private void processUpload(HttpServletRequest request, String saveDir) throws FileUploadException, UnsupportedEncodingException {
/* 127 */     for (FileItem item : parseRequest(request, saveDir)) {
/* 128 */       if (LOG.isDebugEnabled()) {
/* 129 */         LOG.debug("Found item " + item.getFieldName(), new String[0]);
/*     */       }
/* 131 */       if (item.isFormField())
/* 132 */         processNormalFormField(item, request.getCharacterEncoding());
/*     */       else
/* 134 */         processFileField(item);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void processFileField(FileItem item)
/*     */   {
/* 140 */     if (LOG.isDebugEnabled()) {
/* 141 */       LOG.debug("Item is a file upload", new String[0]);
/*     */     }
/*     */ 
/* 145 */     if ((item.getName() == null) || (item.getName().trim().length() < 1)) {
/* 146 */       LOG.debug("No file has been uploaded for the field: " + item.getFieldName(), new String[0]);
/* 147 */       return;
/*     */     }
/*     */     List values;
/*     */     List values;
/* 151 */     if (this.files.get(item.getFieldName()) != null)
/* 152 */       values = (List)this.files.get(item.getFieldName());
/*     */     else {
/* 154 */       values = new ArrayList();
/*     */     }
/*     */ 
/* 157 */     values.add(item);
/* 158 */     this.files.put(item.getFieldName(), values);
/*     */   }
/*     */ 
/*     */   private void processNormalFormField(FileItem item, String charset) throws UnsupportedEncodingException {
/* 162 */     if (LOG.isDebugEnabled())
/* 163 */       LOG.debug("Item is a normal form field", new String[0]);
/*     */     List values;
/*     */     List values;
/* 166 */     if (this.params.get(item.getFieldName()) != null)
/* 167 */       values = (List)this.params.get(item.getFieldName());
/*     */     else {
/* 169 */       values = new ArrayList();
/*     */     }
/*     */ 
/* 176 */     if (charset != null)
/* 177 */       values.add(item.getString(charset));
/*     */     else {
/* 179 */       values.add(item.getString());
/*     */     }
/* 181 */     this.params.put(item.getFieldName(), values);
/* 182 */     item.delete();
/*     */   }
/*     */ 
/*     */   private List<FileItem> parseRequest(HttpServletRequest servletRequest, String saveDir) throws FileUploadException {
/* 186 */     DiskFileItemFactory fac = createDiskFileItemFactory(saveDir);
/* 187 */     ServletFileUpload upload = new ServletFileUpload(fac);
/* 188 */     upload.setSizeMax(this.maxSize);
/* 189 */     return upload.parseRequest(createRequestContext(servletRequest));
/*     */   }
/*     */ 
/*     */   private DiskFileItemFactory createDiskFileItemFactory(String saveDir) {
/* 193 */     DiskFileItemFactory fac = new DiskFileItemFactory();
/*     */ 
/* 195 */     fac.setSizeThreshold(0);
/* 196 */     if (saveDir != null) {
/* 197 */       fac.setRepository(new File(saveDir));
/*     */     }
/* 199 */     return fac;
/*     */   }
/*     */ 
/*     */   public Enumeration<String> getFileParameterNames()
/*     */   {
/* 206 */     return Collections.enumeration(this.files.keySet());
/*     */   }
/*     */ 
/*     */   public String[] getContentType(String fieldName)
/*     */   {
/* 213 */     List items = (List)this.files.get(fieldName);
/*     */ 
/* 215 */     if (items == null) {
/* 216 */       return null;
/*     */     }
/*     */ 
/* 219 */     List contentTypes = new ArrayList(items.size());
/* 220 */     for (FileItem fileItem : items) {
/* 221 */       contentTypes.add(fileItem.getContentType());
/*     */     }
/*     */ 
/* 224 */     return (String[])contentTypes.toArray(new String[contentTypes.size()]);
/*     */   }
/*     */ 
/*     */   public File[] getFile(String fieldName)
/*     */   {
/* 231 */     List items = (List)this.files.get(fieldName);
/*     */ 
/* 233 */     if (items == null) {
/* 234 */       return null;
/*     */     }
/*     */ 
/* 237 */     List fileList = new ArrayList(items.size());
/* 238 */     for (FileItem fileItem : items) {
/* 239 */       File storeLocation = ((DiskFileItem)fileItem).getStoreLocation();
/* 240 */       if ((fileItem.isInMemory()) && (storeLocation != null) && (!storeLocation.exists())) {
/*     */         try {
/* 242 */           storeLocation.createNewFile();
/*     */         } catch (IOException e) {
/* 244 */           if (LOG.isErrorEnabled()) {
/* 245 */             LOG.error("Cannot write uploaded empty file to disk: " + storeLocation.getAbsolutePath(), e, new String[0]);
/*     */           }
/*     */         }
/*     */       }
/* 249 */       fileList.add(storeLocation);
/*     */     }
/*     */ 
/* 252 */     return (File[])fileList.toArray(new File[fileList.size()]);
/*     */   }
/*     */ 
/*     */   public String[] getFileNames(String fieldName)
/*     */   {
/* 259 */     List items = (List)this.files.get(fieldName);
/*     */ 
/* 261 */     if (items == null) {
/* 262 */       return null;
/*     */     }
/*     */ 
/* 265 */     List fileNames = new ArrayList(items.size());
/* 266 */     for (FileItem fileItem : items) {
/* 267 */       fileNames.add(getCanonicalName(fileItem.getName()));
/*     */     }
/*     */ 
/* 270 */     return (String[])fileNames.toArray(new String[fileNames.size()]);
/*     */   }
/*     */ 
/*     */   public String[] getFilesystemName(String fieldName)
/*     */   {
/* 277 */     List items = (List)this.files.get(fieldName);
/*     */ 
/* 279 */     if (items == null) {
/* 280 */       return null;
/*     */     }
/*     */ 
/* 283 */     List fileNames = new ArrayList(items.size());
/* 284 */     for (FileItem fileItem : items) {
/* 285 */       fileNames.add(((DiskFileItem)fileItem).getStoreLocation().getName());
/*     */     }
/*     */ 
/* 288 */     return (String[])fileNames.toArray(new String[fileNames.size()]);
/*     */   }
/*     */ 
/*     */   public String getParameter(String name)
/*     */   {
/* 295 */     List v = (List)this.params.get(name);
/* 296 */     if ((v != null) && (v.size() > 0)) {
/* 297 */       return (String)v.get(0);
/*     */     }
/*     */ 
/* 300 */     return null;
/*     */   }
/*     */ 
/*     */   public Enumeration<String> getParameterNames()
/*     */   {
/* 307 */     return Collections.enumeration(this.params.keySet());
/*     */   }
/*     */ 
/*     */   public String[] getParameterValues(String name)
/*     */   {
/* 314 */     List v = (List)this.params.get(name);
/* 315 */     if ((v != null) && (v.size() > 0)) {
/* 316 */       return (String[])v.toArray(new String[v.size()]);
/*     */     }
/*     */ 
/* 319 */     return null;
/*     */   }
/*     */ 
/*     */   public List<String> getErrors()
/*     */   {
/* 326 */     return this.errors;
/*     */   }
/*     */ 
/*     */   private String getCanonicalName(String filename)
/*     */   {
/* 336 */     int forwardSlash = filename.lastIndexOf("/");
/* 337 */     int backwardSlash = filename.lastIndexOf("\\");
/* 338 */     if ((forwardSlash != -1) && (forwardSlash > backwardSlash))
/* 339 */       filename = filename.substring(forwardSlash + 1, filename.length());
/* 340 */     else if ((backwardSlash != -1) && (backwardSlash >= forwardSlash)) {
/* 341 */       filename = filename.substring(backwardSlash + 1, filename.length());
/*     */     }
/*     */ 
/* 344 */     return filename;
/*     */   }
/*     */ 
/*     */   private RequestContext createRequestContext(HttpServletRequest req)
/*     */   {
/* 354 */     return new RequestContext(req) {
/*     */       public String getCharacterEncoding() {
/* 356 */         return this.val$req.getCharacterEncoding();
/*     */       }
/*     */ 
/*     */       public String getContentType() {
/* 360 */         return this.val$req.getContentType();
/*     */       }
/*     */ 
/*     */       public int getContentLength() {
/* 364 */         return this.val$req.getContentLength();
/*     */       }
/*     */ 
/*     */       public InputStream getInputStream() throws IOException {
/* 368 */         InputStream in = this.val$req.getInputStream();
/* 369 */         if (in == null) {
/* 370 */           throw new IOException("Missing content in the request");
/*     */         }
/* 372 */         return this.val$req.getInputStream();
/*     */       }
/*     */     };
/*     */   }
/*     */ 
/*     */   public void cleanUp()
/*     */   {
/* 381 */     Set names = this.files.keySet();
/* 382 */     for (Iterator i$ = names.iterator(); i$.hasNext(); ) { name = (String)i$.next();
/* 383 */       List items = (List)this.files.get(name);
/* 384 */       for (FileItem item : items) {
/* 385 */         if (LOG.isDebugEnabled()) {
/* 386 */           String msg = LocalizedTextUtil.findText(getClass(), "struts.messages.removing.file", Locale.ENGLISH, "no.message.found", new Object[] { name, item });
/*     */ 
/* 388 */           LOG.debug(msg, new String[0]);
/*     */         }
/* 390 */         if (!item.isInMemory())
/* 391 */           item.delete();
/*     */       }
/*     */     }
/*     */     String name;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.dispatcher.multipart.JakartaMultiPartRequest
 * JD-Core Version:    0.6.0
 */