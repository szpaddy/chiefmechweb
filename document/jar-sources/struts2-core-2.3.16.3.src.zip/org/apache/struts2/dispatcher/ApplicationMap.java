/*     */ package org.apache.struts2.dispatcher;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.AbstractMap;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import javax.servlet.ServletContext;
/*     */ 
/*     */ public class ApplicationMap extends AbstractMap
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 9136809763083228202L;
/*     */   private ServletContext context;
/*     */   private Set<Object> entries;
/*     */ 
/*     */   public ApplicationMap(ServletContext ctx)
/*     */   {
/*  53 */     this.context = ctx;
/*     */   }
/*     */ 
/*     */   public void clear()
/*     */   {
/*  61 */     this.entries = null;
/*     */ 
/*  63 */     Enumeration e = this.context.getAttributeNames();
/*     */ 
/*  65 */     while (e.hasMoreElements())
/*  66 */       this.context.removeAttribute(e.nextElement().toString());
/*     */   }
/*     */ 
/*     */   public Set entrySet()
/*     */   {
/*  76 */     if (this.entries == null) {
/*  77 */       this.entries = new HashSet();
/*     */ 
/*  80 */       Enumeration enumeration = this.context.getAttributeNames();
/*     */ 
/*  82 */       while (enumeration.hasMoreElements()) {
/*  83 */         String key = enumeration.nextElement().toString();
/*  84 */         Object value = this.context.getAttribute(key);
/*  85 */         this.entries.add(new Map.Entry(key, value) {
/*     */           public boolean equals(Object obj) {
/*  87 */             if (!(obj instanceof Map.Entry)) {
/*  88 */               return false;
/*     */             }
/*  90 */             Map.Entry entry = (Map.Entry)obj;
/*     */ 
/*  92 */             return (this.val$key == null ? entry.getKey() == null : this.val$key.equals(entry.getKey())) && (this.val$value == null ? entry.getValue() == null : this.val$value.equals(entry.getValue()));
/*     */           }
/*     */ 
/*     */           public int hashCode() {
/*  96 */             return (this.val$key == null ? 0 : this.val$key.hashCode()) ^ (this.val$value == null ? 0 : this.val$value.hashCode());
/*     */           }
/*     */ 
/*     */           public Object getKey() {
/* 100 */             return this.val$key;
/*     */           }
/*     */ 
/*     */           public Object getValue() {
/* 104 */             return this.val$value;
/*     */           }
/*     */ 
/*     */           public Object setValue(Object obj) {
/* 108 */             ApplicationMap.this.context.setAttribute(this.val$key, obj);
/*     */ 
/* 110 */             return this.val$value;
/*     */           }
/*     */         });
/*     */       }
/*     */ 
/* 116 */       enumeration = this.context.getInitParameterNames();
/*     */ 
/* 118 */       while (enumeration.hasMoreElements()) {
/* 119 */         String key = enumeration.nextElement().toString();
/* 120 */         Object value = this.context.getInitParameter(key);
/* 121 */         this.entries.add(new Map.Entry(key, value) {
/*     */           public boolean equals(Object obj) {
/* 123 */             if (!(obj instanceof Map.Entry)) {
/* 124 */               return false;
/*     */             }
/* 126 */             Map.Entry entry = (Map.Entry)obj;
/*     */ 
/* 128 */             return (this.val$key == null ? entry.getKey() == null : this.val$key.equals(entry.getKey())) && (this.val$value == null ? entry.getValue() == null : this.val$value.equals(entry.getValue()));
/*     */           }
/*     */ 
/*     */           public int hashCode() {
/* 132 */             return (this.val$key == null ? 0 : this.val$key.hashCode()) ^ (this.val$value == null ? 0 : this.val$value.hashCode());
/*     */           }
/*     */ 
/*     */           public Object getKey() {
/* 136 */             return this.val$key;
/*     */           }
/*     */ 
/*     */           public Object getValue() {
/* 140 */             return this.val$value;
/*     */           }
/*     */ 
/*     */           public Object setValue(Object obj) {
/* 144 */             ApplicationMap.this.context.setAttribute(this.val$key, obj);
/*     */ 
/* 146 */             return this.val$value;
/*     */           }
/*     */         });
/*     */       }
/*     */     }
/* 152 */     return this.entries;
/*     */   }
/*     */ 
/*     */   public Object get(Object key)
/*     */   {
/* 165 */     String keyString = key.toString();
/* 166 */     Object value = this.context.getAttribute(keyString);
/*     */ 
/* 168 */     return value == null ? this.context.getInitParameter(keyString) : value;
/*     */   }
/*     */ 
/*     */   public Object put(Object key, Object value)
/*     */   {
/* 179 */     Object oldValue = get(key);
/* 180 */     this.entries = null;
/* 181 */     this.context.setAttribute(key.toString(), value);
/* 182 */     return oldValue;
/*     */   }
/*     */ 
/*     */   public Object remove(Object key)
/*     */   {
/* 192 */     this.entries = null;
/*     */ 
/* 194 */     Object value = get(key);
/* 195 */     this.context.removeAttribute(key.toString());
/*     */ 
/* 197 */     return value;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.dispatcher.ApplicationMap
 * JD-Core Version:    0.6.0
 */