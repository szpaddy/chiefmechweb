/*     */ package org.apache.struts2.dispatcher;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionContext;
/*     */ import com.opensymphony.xwork2.ActionInvocation;
/*     */ import com.opensymphony.xwork2.Result;
/*     */ import com.opensymphony.xwork2.util.TextParseUtil;
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import com.opensymphony.xwork2.util.logging.Logger;
/*     */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.struts2.ServletActionContext;
/*     */ 
/*     */ public class HttpHeaderResult
/*     */   implements Result
/*     */ {
/*     */   private static final long serialVersionUID = 195648957144219214L;
/*  83 */   private static final Logger LOG = LoggerFactory.getLogger(HttpHeaderResult.class);
/*     */ 
/*  88 */   public static final String DEFAULT_PARAM = null;
/*     */ 
/*  90 */   private boolean parse = true;
/*     */   private Map<String, String> headers;
/*  92 */   private int status = -1;
/*  93 */   private String error = null;
/*     */   private String errorMessage;
/*     */ 
/*     */   public HttpHeaderResult()
/*     */   {
/*  98 */     this.headers = new HashMap();
/*     */   }
/*     */ 
/*     */   public HttpHeaderResult(int status) {
/* 102 */     this();
/* 103 */     this.status = status;
/* 104 */     this.parse = false;
/*     */   }
/*     */ 
/*     */   public void setError(String error)
/*     */   {
/* 114 */     this.error = error;
/*     */   }
/*     */ 
/*     */   public void setErrorMessage(String errorMessage)
/*     */   {
/* 124 */     this.errorMessage = errorMessage;
/*     */   }
/*     */ 
/*     */   public Map<String, String> getHeaders()
/*     */   {
/* 133 */     return this.headers;
/*     */   }
/*     */ 
/*     */   public void setParse(boolean parse)
/*     */   {
/* 143 */     this.parse = parse;
/*     */   }
/*     */ 
/*     */   public void setStatus(int status)
/*     */   {
/* 153 */     this.status = status;
/*     */   }
/*     */ 
/*     */   public int getStatus() {
/* 157 */     return this.status;
/*     */   }
/*     */ 
/*     */   public void addHeader(String name, String value)
/*     */   {
/* 167 */     this.headers.put(name, value);
/*     */   }
/*     */ 
/*     */   public void execute(ActionInvocation invocation)
/*     */     throws Exception
/*     */   {
/* 178 */     HttpServletResponse response = ServletActionContext.getResponse();
/* 179 */     ValueStack stack = ActionContext.getContext().getValueStack();
/*     */ 
/* 181 */     if (this.status != -1) {
/* 182 */       response.setStatus(this.status);
/*     */     }
/*     */ 
/* 185 */     if (this.headers != null) {
/* 186 */       for (Map.Entry entry : this.headers.entrySet()) {
/* 187 */         String value = (String)entry.getValue();
/* 188 */         String finalValue = this.parse ? TextParseUtil.translateVariables(value, stack) : value;
/* 189 */         response.addHeader((String)entry.getKey(), finalValue);
/*     */       }
/*     */     }
/*     */ 
/* 193 */     if ((this.status == -1) && (this.error != null)) {
/* 194 */       int errorCode = -1;
/*     */       try {
/* 196 */         errorCode = Integer.parseInt(this.parse ? TextParseUtil.translateVariables(this.error, stack) : this.error);
/*     */       } catch (Exception e) {
/* 198 */         if (LOG.isErrorEnabled()) {
/* 199 */           LOG.error("Cannot parse errorCode [#0] value as Integer!", e, new String[] { this.error });
/*     */         }
/*     */       }
/* 202 */       if (errorCode != -1)
/* 203 */         if (this.errorMessage != null) {
/* 204 */           String finalMessage = this.parse ? TextParseUtil.translateVariables(this.errorMessage, stack) : this.errorMessage;
/* 205 */           response.sendError(errorCode, finalMessage);
/*     */         } else {
/* 207 */           response.sendError(errorCode);
/*     */         }
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.dispatcher.HttpHeaderResult
 * JD-Core Version:    0.6.0
 */