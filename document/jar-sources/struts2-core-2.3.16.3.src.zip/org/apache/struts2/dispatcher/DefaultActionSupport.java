/*    */ package org.apache.struts2.dispatcher;
/*    */ 
/*    */ import com.opensymphony.xwork2.ActionSupport;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import org.apache.struts2.ServletActionContext;
/*    */ 
/*    */ public class DefaultActionSupport extends ActionSupport
/*    */ {
/*    */   private static final long serialVersionUID = -2426166391283746095L;
/*    */   private String successResultValue;
/*    */ 
/*    */   public String execute()
/*    */     throws Exception
/*    */   {
/* 52 */     HttpServletRequest request = ServletActionContext.getRequest();
/* 53 */     String requestedUrl = request.getPathInfo();
/* 54 */     if (this.successResultValue == null) this.successResultValue = requestedUrl;
/* 55 */     return "success";
/*    */   }
/*    */ 
/*    */   public String getSuccessResultValue()
/*    */   {
/* 62 */     return this.successResultValue;
/*    */   }
/*    */ 
/*    */   public void setSuccessResultValue(String successResultValue)
/*    */   {
/* 69 */     this.successResultValue = successResultValue;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.dispatcher.DefaultActionSupport
 * JD-Core Version:    0.6.0
 */