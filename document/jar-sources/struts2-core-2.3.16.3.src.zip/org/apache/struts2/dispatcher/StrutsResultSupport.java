/*     */ package org.apache.struts2.dispatcher;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionInvocation;
/*     */ import com.opensymphony.xwork2.Result;
/*     */ import com.opensymphony.xwork2.util.TextParseUtil;
/*     */ import com.opensymphony.xwork2.util.TextParseUtil.ParsedValueEvaluator;
/*     */ import com.opensymphony.xwork2.util.logging.Logger;
/*     */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.net.URLEncoder;
/*     */ import org.apache.struts2.StrutsStatics;
/*     */ 
/*     */ public abstract class StrutsResultSupport
/*     */   implements Result, StrutsStatics
/*     */ {
/* 106 */   private static final Logger LOG = LoggerFactory.getLogger(StrutsResultSupport.class);
/*     */   public static final String DEFAULT_PARAM = "location";
/*     */   private boolean parse;
/*     */   private boolean encode;
/*     */   private String location;
/*     */   private String lastFinalLocation;
/*     */ 
/*     */   public StrutsResultSupport()
/*     */   {
/* 117 */     this(null, true, false);
/*     */   }
/*     */ 
/*     */   public StrutsResultSupport(String location) {
/* 121 */     this(location, true, false);
/*     */   }
/*     */ 
/*     */   public StrutsResultSupport(String location, boolean parse, boolean encode) {
/* 125 */     this.location = location;
/* 126 */     this.parse = parse;
/* 127 */     this.encode = encode;
/*     */   }
/*     */ 
/*     */   public void setLocation(String location)
/*     */   {
/* 139 */     this.location = location;
/*     */   }
/*     */ 
/*     */   public String getLocation()
/*     */   {
/* 146 */     return this.location;
/*     */   }
/*     */ 
/*     */   public String getLastFinalLocation()
/*     */   {
/* 153 */     return this.lastFinalLocation;
/*     */   }
/*     */ 
/*     */   public void setParse(boolean parse)
/*     */   {
/* 163 */     this.parse = parse;
/*     */   }
/*     */ 
/*     */   public void setEncode(boolean encode)
/*     */   {
/* 173 */     this.encode = encode;
/*     */   }
/*     */ 
/*     */   public void execute(ActionInvocation invocation)
/*     */     throws Exception
/*     */   {
/* 185 */     this.lastFinalLocation = conditionalParse(this.location, invocation);
/* 186 */     doExecute(this.lastFinalLocation, invocation);
/*     */   }
/*     */ 
/*     */   protected String conditionalParse(String param, ActionInvocation invocation)
/*     */   {
/* 197 */     if ((this.parse) && (param != null) && (invocation != null))
/* 198 */       return TextParseUtil.translateVariables(param, invocation.getStack(), new TextParseUtil.ParsedValueEvaluator()
/*     */       {
/*     */         public Object evaluate(String parsedValue) {
/* 201 */           if ((StrutsResultSupport.this.encode) && 
/* 202 */             (parsedValue != null))
/*     */           {
/*     */             try
/*     */             {
/* 206 */               return URLEncoder.encode(parsedValue, "UTF-8");
/*     */             }
/*     */             catch (UnsupportedEncodingException e) {
/* 209 */               if (StrutsResultSupport.LOG.isWarnEnabled()) {
/* 210 */                 StrutsResultSupport.LOG.warn("error while trying to encode [" + parsedValue + "]", e, new String[0]);
/*     */               }
/*     */             }
/*     */           }
/*     */ 
/* 215 */           return parsedValue;
/*     */         }
/*     */       });
/* 219 */     return param;
/*     */   }
/*     */ 
/*     */   protected abstract void doExecute(String paramString, ActionInvocation paramActionInvocation)
/*     */     throws Exception;
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.dispatcher.StrutsResultSupport
 * JD-Core Version:    0.6.0
 */