/*     */ package org.apache.struts2.dispatcher;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionInvocation;
/*     */ import com.opensymphony.xwork2.ActionProxy;
/*     */ import com.opensymphony.xwork2.util.reflection.ReflectionExceptionHandler;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import org.apache.struts2.dispatcher.mapper.ActionMapper;
/*     */ import org.apache.struts2.dispatcher.mapper.ActionMapping;
/*     */ 
/*     */ public class ServletActionRedirectResult extends ServletRedirectResult
/*     */   implements ReflectionExceptionHandler
/*     */ {
/*     */   private static final long serialVersionUID = -9042425229314584066L;
/*     */   public static final String DEFAULT_PARAM = "actionName";
/*     */   protected String actionName;
/*     */   protected String namespace;
/*     */   protected String method;
/*     */ 
/*     */   public ServletActionRedirectResult()
/*     */   {
/*     */   }
/*     */ 
/*     */   public ServletActionRedirectResult(String actionName)
/*     */   {
/* 144 */     this(null, actionName, null, null);
/*     */   }
/*     */ 
/*     */   public ServletActionRedirectResult(String actionName, String method) {
/* 148 */     this(null, actionName, method, null);
/*     */   }
/*     */ 
/*     */   public ServletActionRedirectResult(String namespace, String actionName, String method) {
/* 152 */     this(namespace, actionName, method, null);
/*     */   }
/*     */ 
/*     */   public ServletActionRedirectResult(String namespace, String actionName, String method, String anchor) {
/* 156 */     super(null, anchor);
/* 157 */     this.namespace = namespace;
/* 158 */     this.actionName = actionName;
/* 159 */     this.method = method;
/*     */   }
/*     */ 
/*     */   public void execute(ActionInvocation invocation)
/*     */     throws Exception
/*     */   {
/* 166 */     this.actionName = conditionalParse(this.actionName, invocation);
/* 167 */     if (this.namespace == null)
/* 168 */       this.namespace = invocation.getProxy().getNamespace();
/*     */     else {
/* 170 */       this.namespace = conditionalParse(this.namespace, invocation);
/*     */     }
/* 172 */     if (this.method == null)
/* 173 */       this.method = "";
/*     */     else {
/* 175 */       this.method = conditionalParse(this.method, invocation);
/*     */     }
/*     */ 
/* 178 */     String tmpLocation = this.actionMapper.getUriFromActionMapping(new ActionMapping(this.actionName, this.namespace, this.method, null));
/*     */ 
/* 180 */     setLocation(tmpLocation);
/*     */ 
/* 182 */     super.execute(invocation);
/*     */   }
/*     */ 
/*     */   public void setActionName(String actionName)
/*     */   {
/* 191 */     this.actionName = actionName;
/*     */   }
/*     */ 
/*     */   public void setNamespace(String namespace)
/*     */   {
/* 200 */     this.namespace = namespace;
/*     */   }
/*     */ 
/*     */   public void setMethod(String method)
/*     */   {
/* 209 */     this.method = method;
/*     */   }
/*     */ 
/*     */   protected List<String> getProhibitedResultParams() {
/* 213 */     return Arrays.asList(new String[] { "actionName", "namespace", "method", "encode", "parse", "location", "prependServletContext", "suppressEmptyParameters", "anchor" });
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.dispatcher.ServletActionRedirectResult
 * JD-Core Version:    0.6.0
 */