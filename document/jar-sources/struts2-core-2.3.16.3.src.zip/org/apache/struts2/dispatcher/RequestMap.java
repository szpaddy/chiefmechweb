/*     */ package org.apache.struts2.dispatcher;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.AbstractMap;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ 
/*     */ public class RequestMap extends AbstractMap
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = -7675640869293787926L;
/*     */   private Set<Object> entries;
/*     */   private HttpServletRequest request;
/*     */ 
/*     */   public RequestMap(HttpServletRequest request)
/*     */   {
/*  49 */     this.request = request;
/*     */   }
/*     */ 
/*     */   public void clear()
/*     */   {
/*  57 */     this.entries = null;
/*  58 */     Enumeration keys = this.request.getAttributeNames();
/*     */ 
/*  60 */     while (keys.hasMoreElements()) {
/*  61 */       String key = (String)keys.nextElement();
/*  62 */       this.request.removeAttribute(key);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Set entrySet()
/*     */   {
/*  72 */     if (this.entries == null) {
/*  73 */       this.entries = new HashSet();
/*     */ 
/*  75 */       Enumeration enumeration = this.request.getAttributeNames();
/*     */ 
/*  77 */       while (enumeration.hasMoreElements()) {
/*  78 */         String key = enumeration.nextElement().toString();
/*  79 */         Object value = this.request.getAttribute(key);
/*  80 */         this.entries.add(new Map.Entry(key, value) {
/*     */           public boolean equals(Object obj) {
/*  82 */             if (!(obj instanceof Map.Entry)) {
/*  83 */               return false;
/*     */             }
/*  85 */             Map.Entry entry = (Map.Entry)obj;
/*     */ 
/*  87 */             return (this.val$key == null ? entry.getKey() == null : this.val$key.equals(entry.getKey())) && (this.val$value == null ? entry.getValue() == null : this.val$value.equals(entry.getValue()));
/*     */           }
/*     */ 
/*     */           public int hashCode() {
/*  91 */             return (this.val$key == null ? 0 : this.val$key.hashCode()) ^ (this.val$value == null ? 0 : this.val$value.hashCode());
/*     */           }
/*     */ 
/*     */           public Object getKey() {
/*  95 */             return this.val$key;
/*     */           }
/*     */ 
/*     */           public Object getValue() {
/*  99 */             return this.val$value;
/*     */           }
/*     */ 
/*     */           public Object setValue(Object obj) {
/* 103 */             RequestMap.this.request.setAttribute(this.val$key, obj);
/*     */ 
/* 105 */             return this.val$value;
/*     */           }
/*     */         });
/*     */       }
/*     */     }
/* 111 */     return this.entries;
/*     */   }
/*     */ 
/*     */   public Object get(Object key)
/*     */   {
/* 121 */     return this.request.getAttribute(key.toString());
/*     */   }
/*     */ 
/*     */   public Object put(Object key, Object value)
/*     */   {
/* 132 */     Object oldValue = get(key);
/* 133 */     this.entries = null;
/* 134 */     this.request.setAttribute(key.toString(), value);
/* 135 */     return oldValue;
/*     */   }
/*     */ 
/*     */   public Object remove(Object key)
/*     */   {
/* 145 */     this.entries = null;
/*     */ 
/* 147 */     Object value = get(key);
/* 148 */     this.request.removeAttribute(key.toString());
/*     */ 
/* 150 */     return value;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.dispatcher.RequestMap
 * JD-Core Version:    0.6.0
 */