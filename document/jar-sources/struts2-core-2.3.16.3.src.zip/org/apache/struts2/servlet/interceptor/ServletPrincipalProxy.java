/*    */ package org.apache.struts2.servlet.interceptor;
/*    */ 
/*    */ import java.security.Principal;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import org.apache.struts2.interceptor.PrincipalProxy;
/*    */ 
/*    */ public class ServletPrincipalProxy
/*    */   implements PrincipalProxy
/*    */ {
/*    */   private HttpServletRequest request;
/*    */ 
/*    */   public ServletPrincipalProxy(HttpServletRequest request)
/*    */   {
/* 41 */     this.request = request;
/*    */   }
/*    */ 
/*    */   public boolean isUserInRole(String role)
/*    */   {
/* 51 */     return this.request.isUserInRole(role);
/*    */   }
/*    */ 
/*    */   public Principal getUserPrincipal()
/*    */   {
/* 60 */     return this.request.getUserPrincipal();
/*    */   }
/*    */ 
/*    */   public String getRemoteUser()
/*    */   {
/* 69 */     return this.request.getRemoteUser();
/*    */   }
/*    */ 
/*    */   public boolean isRequestSecure()
/*    */   {
/* 78 */     return this.request.isSecure();
/*    */   }
/*    */ 
/*    */   /** @deprecated */
/*    */   public HttpServletRequest getRequest()
/*    */   {
/* 89 */     return this.request;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.servlet.interceptor.ServletPrincipalProxy
 * JD-Core Version:    0.6.0
 */