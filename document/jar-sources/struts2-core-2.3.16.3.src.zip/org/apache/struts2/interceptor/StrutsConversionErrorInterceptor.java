/*     */ package org.apache.struts2.interceptor;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionInvocation;
/*     */ import com.opensymphony.xwork2.interceptor.ConversionErrorInterceptor;
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ 
/*     */ public class StrutsConversionErrorInterceptor extends ConversionErrorInterceptor
/*     */ {
/*     */   private static final long serialVersionUID = 2759744840082921602L;
/*     */ 
/*     */   protected Object getOverrideExpr(ActionInvocation invocation, Object value)
/*     */   {
/*  78 */     ValueStack stack = invocation.getStack();
/*     */     try
/*     */     {
/*  81 */       stack.push(value);
/*     */ 
/*  83 */       String str = escape(stack.findString("top"));
/*     */       return str; } finally { stack.pop(); } throw localObject;
/*     */   }
/*     */ 
/*     */   protected boolean shouldAddError(String propertyName, Object value)
/*     */   {
/*  98 */     if (value == null) {
/*  99 */       return false;
/*     */     }
/*     */ 
/* 102 */     if ("".equals(value)) {
/* 103 */       return false;
/*     */     }
/*     */ 
/* 106 */     if ((value instanceof String[])) {
/* 107 */       String[] array = (String[])(String[])value;
/*     */ 
/* 109 */       if (array.length == 0) {
/* 110 */         return false;
/*     */       }
/*     */ 
/* 113 */       if (array.length > 1) {
/* 114 */         return true;
/*     */       }
/*     */ 
/* 117 */       String str = array[0];
/*     */ 
/* 119 */       if ("".equals(str)) {
/* 120 */         return false;
/*     */       }
/*     */     }
/*     */ 
/* 124 */     return true;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.interceptor.StrutsConversionErrorInterceptor
 * JD-Core Version:    0.6.0
 */