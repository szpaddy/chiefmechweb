/*    */ package org.apache.struts2.interceptor.validation;
/*    */ 
/*    */ import com.opensymphony.xwork2.ActionInvocation;
/*    */ import com.opensymphony.xwork2.ActionProxy;
/*    */ import com.opensymphony.xwork2.util.AnnotationUtils;
/*    */ import com.opensymphony.xwork2.validator.ValidationInterceptor;
/*    */ import java.lang.reflect.Method;
/*    */ import java.util.Arrays;
/*    */ import java.util.Collection;
/*    */ 
/*    */ public class AnnotationValidationInterceptor extends ValidationInterceptor
/*    */ {
/*    */   private static final long serialVersionUID = 1813272797367431184L;
/*    */ 
/*    */   protected String doIntercept(ActionInvocation invocation)
/*    */     throws Exception
/*    */   {
/* 45 */     Object action = invocation.getAction();
/* 46 */     if (action != null) {
/* 47 */       Method method = getActionMethod(action.getClass(), invocation.getProxy().getMethod());
/* 48 */       Collection annotatedMethods = AnnotationUtils.getAnnotatedMethods(action.getClass(), new Class[] { SkipValidation.class });
/* 49 */       if (annotatedMethods.contains(method)) {
/* 50 */         return invocation.invoke();
/*    */       }
/*    */ 
/* 53 */       Class clazz = action.getClass().getSuperclass();
/* 54 */       while (clazz != null) {
/* 55 */         annotatedMethods = AnnotationUtils.getAnnotatedMethods(clazz, new Class[] { SkipValidation.class });
/* 56 */         if (annotatedMethods != null) {
/* 57 */           for (Method annotatedMethod : annotatedMethods)
/* 58 */             if ((annotatedMethod.getName().equals(method.getName())) && (Arrays.equals(annotatedMethod.getParameterTypes(), method.getParameterTypes())) && (Arrays.equals(annotatedMethod.getExceptionTypes(), method.getExceptionTypes())))
/*    */             {
/* 61 */               return invocation.invoke();
/*    */             }
/*    */         }
/* 64 */         clazz = clazz.getSuperclass();
/*    */       }
/*    */     }
/*    */ 
/* 68 */     return super.doIntercept(invocation);
/*    */   }
/*    */ 
/*    */   protected Method getActionMethod(Class actionClass, String methodName) throws NoSuchMethodException {
/*    */     Method method;
/*    */     try {
/* 75 */       method = actionClass.getMethod(methodName, new Class[0]);
/*    */     }
/*    */     catch (NoSuchMethodException e) {
/*    */       try {
/* 79 */         String altMethodName = "do" + methodName.substring(0, 1).toUpperCase() + methodName.substring(1);
/* 80 */         method = actionClass.getMethod(altMethodName, new Class[0]);
/*    */       }
/*    */       catch (NoSuchMethodException e1) {
/* 83 */         throw e;
/*    */       }
/*    */     }
/* 86 */     return method;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.interceptor.validation.AnnotationValidationInterceptor
 * JD-Core Version:    0.6.0
 */