/*     */ package org.apache.struts2.interceptor;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionContext;
/*     */ import com.opensymphony.xwork2.ActionInvocation;
/*     */ import com.opensymphony.xwork2.ActionProxy;
/*     */ import com.opensymphony.xwork2.Result;
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import java.util.Map;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import org.apache.struts2.ServletActionContext;
/*     */ import org.apache.struts2.util.InvocationSessionStore;
/*     */ import org.apache.struts2.util.TokenHelper;
/*     */ 
/*     */ public class TokenSessionStoreInterceptor extends TokenInterceptor
/*     */ {
/*     */   private static final long serialVersionUID = -9032347965469098195L;
/*     */ 
/*     */   protected String handleToken(ActionInvocation invocation)
/*     */     throws Exception
/*     */   {
/* 111 */     HttpSession session = ServletActionContext.getRequest().getSession(true);
/* 112 */     synchronized (session) {
/* 113 */       if (!TokenHelper.validToken()) {
/* 114 */         return handleInvalidToken(invocation);
/*     */       }
/* 116 */       return handleValidToken(invocation);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected String handleInvalidToken(ActionInvocation invocation) throws Exception
/*     */   {
/* 122 */     ActionContext ac = invocation.getInvocationContext();
/*     */ 
/* 124 */     HttpServletRequest request = (HttpServletRequest)ac.get("com.opensymphony.xwork2.dispatcher.HttpServletRequest");
/* 125 */     HttpServletResponse response = (HttpServletResponse)ac.get("com.opensymphony.xwork2.dispatcher.HttpServletResponse");
/* 126 */     String tokenName = TokenHelper.getTokenName();
/* 127 */     String token = TokenHelper.getToken(tokenName);
/*     */ 
/* 129 */     if ((tokenName != null) && (token != null)) {
/* 130 */       Map params = ac.getParameters();
/* 131 */       params.remove(tokenName);
/* 132 */       params.remove("struts.token.name");
/*     */ 
/* 134 */       String sessionTokenName = TokenHelper.buildTokenSessionAttributeName(tokenName);
/* 135 */       ActionInvocation savedInvocation = InvocationSessionStore.loadInvocation(sessionTokenName, token);
/*     */ 
/* 137 */       if (savedInvocation != null)
/*     */       {
/* 139 */         ValueStack stack = savedInvocation.getStack();
/* 140 */         request.setAttribute("struts.valueStack", stack);
/*     */ 
/* 142 */         ActionContext savedContext = savedInvocation.getInvocationContext();
/* 143 */         savedContext.getContextMap().put("com.opensymphony.xwork2.dispatcher.HttpServletRequest", request);
/* 144 */         savedContext.getContextMap().put("com.opensymphony.xwork2.dispatcher.HttpServletResponse", response);
/* 145 */         Result result = savedInvocation.getResult();
/*     */ 
/* 147 */         if ((result != null) && (savedInvocation.getProxy().getExecuteResult())) {
/* 148 */           result.execute(savedInvocation);
/*     */         }
/*     */ 
/* 152 */         invocation.getProxy().setExecuteResult(false);
/*     */ 
/* 154 */         return savedInvocation.getResultCode();
/*     */       }
/*     */     }
/*     */ 
/* 158 */     return "invalid.token";
/*     */   }
/*     */ 
/*     */   protected String handleValidToken(ActionInvocation invocation)
/*     */     throws Exception
/*     */   {
/* 164 */     String key = TokenHelper.getTokenName();
/* 165 */     String token = TokenHelper.getToken(key);
/* 166 */     String sessionTokenName = TokenHelper.buildTokenSessionAttributeName(key);
/* 167 */     InvocationSessionStore.storeInvocation(sessionTokenName, token, invocation);
/*     */ 
/* 169 */     return invocation.invoke();
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.interceptor.TokenSessionStoreInterceptor
 * JD-Core Version:    0.6.0
 */