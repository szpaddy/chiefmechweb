package org.apache.struts2.interceptor;

public abstract interface NoParameters extends com.opensymphony.xwork2.interceptor.NoParameters
{
}

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.interceptor.NoParameters
 * JD-Core Version:    0.6.0
 */