package org.apache.struts2.interceptor;

import javax.servlet.http.HttpServletResponse;

public abstract interface ServletResponseAware
{
  public abstract void setServletResponse(HttpServletResponse paramHttpServletResponse);
}

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.interceptor.ServletResponseAware
 * JD-Core Version:    0.6.0
 */