/*    */ package org.apache.struts2.interceptor;
/*    */ 
/*    */ import com.opensymphony.xwork2.ActionContext;
/*    */ import com.opensymphony.xwork2.ActionInvocation;
/*    */ import com.opensymphony.xwork2.interceptor.AbstractInterceptor;
/*    */ import com.opensymphony.xwork2.util.logging.Logger;
/*    */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class ClearSessionInterceptor extends AbstractInterceptor
/*    */ {
/*    */   private static final long serialVersionUID = -2102199238428329238L;
/* 80 */   private static final Logger LOG = LoggerFactory.getLogger(ClearSessionInterceptor.class);
/*    */ 
/*    */   public String intercept(ActionInvocation invocation)
/*    */     throws Exception
/*    */   {
/* 86 */     if (LOG.isDebugEnabled()) {
/* 87 */       LOG.debug("Clearing HttpSession", new String[0]);
/*    */     }
/*    */ 
/* 90 */     ActionContext ac = invocation.getInvocationContext();
/* 91 */     Map session = ac.getSession();
/*    */ 
/* 93 */     if (null != session) {
/* 94 */       session.clear();
/*    */     }
/* 96 */     return invocation.invoke();
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.interceptor.ClearSessionInterceptor
 * JD-Core Version:    0.6.0
 */