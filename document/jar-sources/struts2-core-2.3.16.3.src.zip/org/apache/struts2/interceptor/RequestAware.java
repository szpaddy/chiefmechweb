package org.apache.struts2.interceptor;

import java.util.Map;

public abstract interface RequestAware
{
  public abstract void setRequest(Map<String, Object> paramMap);
}

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.interceptor.RequestAware
 * JD-Core Version:    0.6.0
 */