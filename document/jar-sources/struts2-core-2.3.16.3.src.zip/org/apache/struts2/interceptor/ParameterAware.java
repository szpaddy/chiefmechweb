package org.apache.struts2.interceptor;

import java.util.Map;

public abstract interface ParameterAware
{
  public abstract void setParameters(Map<String, String[]> paramMap);
}

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.interceptor.ParameterAware
 * JD-Core Version:    0.6.0
 */