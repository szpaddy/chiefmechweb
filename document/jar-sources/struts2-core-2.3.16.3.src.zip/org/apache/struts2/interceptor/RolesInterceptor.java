/*     */ package org.apache.struts2.interceptor;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionInvocation;
/*     */ import com.opensymphony.xwork2.interceptor.AbstractInterceptor;
/*     */ import com.opensymphony.xwork2.util.logging.Logger;
/*     */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.struts2.ServletActionContext;
/*     */ 
/*     */ public class RolesInterceptor extends AbstractInterceptor
/*     */ {
/*  91 */   private static final Logger LOG = LoggerFactory.getLogger(RolesInterceptor.class);
/*     */ 
/*  93 */   private boolean isProperlyConfigured = true;
/*     */ 
/*  95 */   protected List<String> allowedRoles = Collections.emptyList();
/*  96 */   protected List<String> disallowedRoles = Collections.emptyList();
/*     */ 
/*     */   public void setAllowedRoles(String roles) {
/*  99 */     this.allowedRoles = stringToList(roles);
/* 100 */     checkRoles(this.allowedRoles);
/*     */   }
/*     */ 
/*     */   public void setDisallowedRoles(String roles) {
/* 104 */     this.disallowedRoles = stringToList(roles);
/* 105 */     checkRoles(this.disallowedRoles);
/*     */   }
/*     */ 
/*     */   private void checkRoles(List<String> roles) {
/* 109 */     if (!areRolesValid(roles)) {
/* 110 */       LOG.fatal("An unknown Role was configured: #0", new String[] { roles.toString() });
/* 111 */       this.isProperlyConfigured = false;
/* 112 */       throw new IllegalArgumentException("An unknown role was configured: " + roles);
/*     */     }
/*     */   }
/*     */ 
/*     */   public String intercept(ActionInvocation invocation) throws Exception {
/* 117 */     HttpServletRequest request = ServletActionContext.getRequest();
/* 118 */     HttpServletResponse response = ServletActionContext.getResponse();
/* 119 */     if (!this.isProperlyConfigured) {
/* 120 */       throw new IllegalArgumentException("RolesInterceptor is misconfigured, check logs for erroneous configuration!");
/*     */     }
/* 122 */     if (!isAllowed(request, invocation.getAction())) {
/* 123 */       return handleRejection(invocation, response);
/*     */     }
/* 125 */     return invocation.invoke();
/*     */   }
/*     */ 
/*     */   protected List<String> stringToList(String val)
/*     */   {
/* 133 */     if (val != null) {
/* 134 */       String[] list = val.split("[ ]*,[ ]*");
/* 135 */       return Arrays.asList(list);
/*     */     }
/* 137 */     return Collections.emptyList();
/*     */   }
/*     */ 
/*     */   protected boolean isAllowed(HttpServletRequest request, Object action)
/*     */   {
/* 149 */     for (String role : this.disallowedRoles) {
/* 150 */       if (request.isUserInRole(role)) {
/* 151 */         return false;
/*     */       }
/*     */     }
/*     */ 
/* 155 */     if (this.allowedRoles.isEmpty()) {
/* 156 */       return true;
/*     */     }
/*     */ 
/* 159 */     for (String role : this.allowedRoles) {
/* 160 */       if (request.isUserInRole(role)) {
/* 161 */         return true;
/*     */       }
/*     */     }
/*     */ 
/* 165 */     return false;
/*     */   }
/*     */ 
/*     */   protected String handleRejection(ActionInvocation invocation, HttpServletResponse response)
/*     */     throws Exception
/*     */   {
/* 178 */     response.sendError(403);
/* 179 */     return null;
/*     */   }
/*     */ 
/*     */   protected boolean areRolesValid(List<String> roles)
/*     */   {
/* 191 */     return true;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.interceptor.RolesInterceptor
 * JD-Core Version:    0.6.0
 */