/*     */ package org.apache.struts2.interceptor;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionContext;
/*     */ import com.opensymphony.xwork2.ActionInvocation;
/*     */ import com.opensymphony.xwork2.ActionProxy;
/*     */ import com.opensymphony.xwork2.interceptor.AbstractInterceptor;
/*     */ import com.opensymphony.xwork2.interceptor.PreResultListener;
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import com.opensymphony.xwork2.util.logging.Logger;
/*     */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*     */ import java.io.Serializable;
/*     */ import java.util.IdentityHashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.struts2.ServletActionContext;
/*     */ import org.apache.struts2.StrutsException;
/*     */ import org.apache.struts2.dispatcher.SessionMap;
/*     */ 
/*     */ public class ScopeInterceptor extends AbstractInterceptor
/*     */   implements PreResultListener
/*     */ {
/*     */   private static final long serialVersionUID = 9120762699600054395L;
/* 147 */   private static final Logger LOG = LoggerFactory.getLogger(ScopeInterceptor.class);
/*     */ 
/* 149 */   private String[] application = null;
/* 150 */   private String[] session = null;
/*     */   private String key;
/* 152 */   private String type = null;
/* 153 */   private boolean autoCreateSession = true;
/* 154 */   private String sessionReset = "session.reset";
/* 155 */   private boolean reset = false;
/*     */ 
/* 220 */   private static final Object NULL = new NULLClass(null);
/*     */ 
/* 234 */   private static Map locks = new IdentityHashMap();
/*     */ 
/*     */   public void setApplication(String s)
/*     */   {
/* 163 */     if (s != null)
/* 164 */       this.application = s.split(" *, *");
/*     */   }
/*     */ 
/*     */   public void setSession(String s)
/*     */   {
/* 174 */     if (s != null)
/* 175 */       this.session = s.split(" *, *");
/*     */   }
/*     */ 
/*     */   public void setAutoCreateSession(String value)
/*     */   {
/* 185 */     if ((value != null) && (value.length() > 0))
/* 186 */       this.autoCreateSession = Boolean.valueOf(value).booleanValue();
/*     */   }
/*     */ 
/*     */   private String getKey(ActionInvocation invocation)
/*     */   {
/* 191 */     ActionProxy proxy = invocation.getProxy();
/* 192 */     if ((this.key == null) || ("CLASS".equals(this.key)))
/* 193 */       return "struts.ScopeInterceptor:" + proxy.getAction().getClass();
/* 194 */     if ("ACTION".equals(this.key)) {
/* 195 */       return "struts.ScopeInterceptor:" + proxy.getNamespace() + ":" + proxy.getActionName();
/*     */     }
/* 197 */     return this.key;
/*     */   }
/*     */ 
/*     */   private static final Object nullConvert(Object o)
/*     */   {
/* 223 */     if (o == null) {
/* 224 */       return NULL;
/*     */     }
/*     */ 
/* 227 */     if ((o == NULL) || (NULL.equals(o))) {
/* 228 */       return null;
/*     */     }
/*     */ 
/* 231 */     return o;
/*     */   }
/*     */ 
/*     */   static final void lock(Object o, ActionInvocation invocation)
/*     */     throws Exception
/*     */   {
/* 237 */     synchronized (o) {
/* 238 */       int count = 3;
/* 239 */       Object previous = null;
/* 240 */       while ((previous = locks.get(o)) != null) {
/* 241 */         if (previous == invocation) {
/* 242 */           return;
/*     */         }
/* 244 */         if (count-- <= 0) {
/* 245 */           locks.remove(o);
/* 246 */           o.notify();
/*     */ 
/* 248 */           throw new StrutsException("Deadlock in session lock");
/*     */         }
/* 250 */         o.wait(10000L);
/*     */       }
/*     */ 
/* 253 */       locks.put(o, invocation);
/*     */     }
/*     */   }
/*     */ 
/*     */   static final void unlock(Object o) {
/* 258 */     synchronized (o) {
/* 259 */       locks.remove(o);
/* 260 */       o.notify();
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void after(ActionInvocation invocation, String result) throws Exception {
/* 265 */     Map ses = ActionContext.getContext().getSession();
/* 266 */     if (ses != null)
/* 267 */       unlock(ses);
/*     */   }
/*     */ 
/*     */   protected void before(ActionInvocation invocation)
/*     */     throws Exception
/*     */   {
/* 273 */     invocation.addPreResultListener(this);
/* 274 */     Map ses = ActionContext.getContext().getSession();
/* 275 */     if ((ses == null) && (this.autoCreateSession)) {
/* 276 */       ses = new SessionMap(ServletActionContext.getRequest());
/* 277 */       ActionContext.getContext().setSession(ses);
/*     */     }
/*     */ 
/* 280 */     if (ses != null) {
/* 281 */       lock(ses, invocation);
/*     */     }
/*     */ 
/* 284 */     String key = getKey(invocation);
/* 285 */     Map app = ActionContext.getContext().getApplication();
/* 286 */     ValueStack stack = ActionContext.getContext().getValueStack();
/*     */ 
/* 288 */     if (LOG.isDebugEnabled()) {
/* 289 */       LOG.debug("scope interceptor before", new String[0]);
/*     */     }
/*     */ 
/* 292 */     if (this.application != null) {
/* 293 */       for (int i = 0; i < this.application.length; i++) {
/* 294 */         String string = this.application[i];
/* 295 */         Object attribute = app.get(key + string);
/* 296 */         if (attribute != null) {
/* 297 */           if (LOG.isDebugEnabled()) {
/* 298 */             LOG.debug("application scoped variable set " + string + " = " + String.valueOf(attribute), new String[0]);
/*     */           }
/*     */ 
/* 301 */           stack.setValue(string, nullConvert(attribute));
/*     */         }
/*     */       }
/*     */     }
/* 305 */     if (ActionContext.getContext().getParameters().get(this.sessionReset) != null) {
/* 306 */       return;
/*     */     }
/*     */ 
/* 309 */     if (this.reset) {
/* 310 */       return;
/*     */     }
/*     */ 
/* 313 */     if (ses == null) {
/* 314 */       LOG.debug("No HttpSession created... Cannot set session scoped variables", new String[0]);
/* 315 */       return;
/*     */     }
/*     */ 
/* 318 */     if ((this.session != null) && (!"start".equals(this.type)))
/* 319 */       for (int i = 0; i < this.session.length; i++) {
/* 320 */         String string = this.session[i];
/* 321 */         Object attribute = ses.get(key + string);
/* 322 */         if (attribute != null) {
/* 323 */           if (LOG.isDebugEnabled()) {
/* 324 */             LOG.debug("session scoped variable set " + string + " = " + String.valueOf(attribute), new String[0]);
/*     */           }
/* 326 */           stack.setValue(string, nullConvert(attribute));
/*     */         }
/*     */       }
/*     */   }
/*     */ 
/*     */   public void setKey(String key)
/*     */   {
/* 333 */     this.key = key;
/*     */   }
/*     */ 
/*     */   public void beforeResult(ActionInvocation invocation, String resultCode)
/*     */   {
/* 340 */     String key = getKey(invocation);
/* 341 */     Map app = ActionContext.getContext().getApplication();
/* 342 */     ValueStack stack = ActionContext.getContext().getValueStack();
/*     */ 
/* 344 */     if (this.application != null) {
/* 345 */       for (int i = 0; i < this.application.length; i++) {
/* 346 */         String string = this.application[i];
/* 347 */         Object value = stack.findValue(string);
/* 348 */         if (LOG.isDebugEnabled()) {
/* 349 */           LOG.debug("application scoped variable saved " + string + " = " + String.valueOf(value), new String[0]);
/*     */         }
/*     */ 
/* 353 */         app.put(key + string, nullConvert(value));
/*     */       }
/*     */     }
/* 356 */     boolean ends = "end".equals(this.type);
/*     */ 
/* 358 */     Map ses = ActionContext.getContext().getSession();
/* 359 */     if (ses != null)
/*     */     {
/* 361 */       if (this.session != null) {
/* 362 */         for (int i = 0; i < this.session.length; i++) {
/* 363 */           String string = this.session[i];
/* 364 */           if (ends) {
/* 365 */             ses.remove(key + string);
/*     */           } else {
/* 367 */             Object value = stack.findValue(string);
/*     */ 
/* 369 */             if (LOG.isDebugEnabled()) {
/* 370 */               LOG.debug("session scoped variable saved " + string + " = " + String.valueOf(value), new String[0]);
/*     */             }
/*     */ 
/* 375 */             ses.put(key + string, nullConvert(value));
/*     */           }
/*     */         }
/*     */       }
/* 379 */       unlock(ses);
/*     */     } else {
/* 381 */       LOG.debug("No HttpSession created... Cannot save session scoped variables.", new String[0]);
/*     */     }
/* 383 */     if (LOG.isDebugEnabled())
/* 384 */       LOG.debug("scope interceptor after (before result)", new String[0]);
/*     */   }
/*     */ 
/*     */   public String getType()
/*     */   {
/* 392 */     return this.type;
/*     */   }
/*     */ 
/*     */   public void setType(String type)
/*     */   {
/* 401 */     type = type.toLowerCase();
/* 402 */     if (("start".equals(type)) || ("end".equals(type)))
/* 403 */       this.type = type;
/*     */     else
/* 405 */       throw new IllegalArgumentException("Only start or end are allowed arguments for type");
/*     */   }
/*     */ 
/*     */   public String getSessionReset()
/*     */   {
/* 413 */     return this.sessionReset;
/*     */   }
/*     */ 
/*     */   public void setSessionReset(String sessionReset)
/*     */   {
/* 420 */     this.sessionReset = sessionReset;
/*     */   }
/*     */ 
/*     */   public String intercept(ActionInvocation invocation)
/*     */     throws Exception
/*     */   {
/* 427 */     String result = null;
/* 428 */     Map ses = ActionContext.getContext().getSession();
/* 429 */     before(invocation);
/*     */     try {
/* 431 */       result = invocation.invoke();
/* 432 */       after(invocation, result);
/*     */     } finally {
/* 434 */       if (ses != null) {
/* 435 */         unlock(ses);
/*     */       }
/*     */     }
/*     */ 
/* 439 */     return result;
/*     */   }
/*     */ 
/*     */   public boolean isReset()
/*     */   {
/* 446 */     return this.reset;
/*     */   }
/*     */ 
/*     */   public void setReset(boolean reset)
/*     */   {
/* 453 */     this.reset = reset;
/*     */   }
/*     */ 
/*     */   private static class NULLClass
/*     */     implements Serializable
/*     */   {
/*     */     public String toString()
/*     */     {
/* 210 */       return "NULL";
/*     */     }
/*     */     public int hashCode() {
/* 213 */       return 1;
/*     */     }
/*     */     public boolean equals(Object obj) {
/* 216 */       return (obj == null) || ((obj instanceof NULLClass));
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.interceptor.ScopeInterceptor
 * JD-Core Version:    0.6.0
 */