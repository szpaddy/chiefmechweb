/*     */ package org.apache.struts2.interceptor;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionContext;
/*     */ import com.opensymphony.xwork2.ActionInvocation;
/*     */ import com.opensymphony.xwork2.ActionProxy;
/*     */ import com.opensymphony.xwork2.config.entities.ActionConfig;
/*     */ import com.opensymphony.xwork2.inject.Container;
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import com.opensymphony.xwork2.interceptor.MethodFilterInterceptor;
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import com.opensymphony.xwork2.util.logging.Logger;
/*     */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*     */ import java.util.Map;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import org.apache.struts2.ServletActionContext;
/*     */ import org.apache.struts2.util.TokenHelper;
/*     */ import org.apache.struts2.views.freemarker.FreemarkerResult;
/*     */ 
/*     */ public class ExecuteAndWaitInterceptor extends MethodFilterInterceptor
/*     */ {
/*     */   private static final long serialVersionUID = -2754639196749652512L;
/* 178 */   private static final Logger LOG = LoggerFactory.getLogger(ExecuteAndWaitInterceptor.class);
/*     */   public static final String KEY = "__execWait";
/*     */   public static final String WAIT = "wait";
/*     */   protected int delay;
/* 183 */   protected int delaySleepInterval = 100;
/* 184 */   protected boolean executeAfterValidationPass = false;
/*     */ 
/* 186 */   private int threadPriority = 5;
/*     */   private Container container;
/*     */ 
/*     */   @Inject
/*     */   public void setContainer(Container container)
/*     */   {
/* 192 */     this.container = container;
/*     */   }
/*     */ 
/*     */   public void init()
/*     */   {
/*     */   }
/*     */ 
/*     */   protected BackgroundProcess getNewBackgroundProcess(String name, ActionInvocation actionInvocation, int threadPriority)
/*     */   {
/* 210 */     return new BackgroundProcess(name + "BackgroundThread", actionInvocation, threadPriority);
/*     */   }
/*     */ 
/*     */   protected String getBackgroundProcessName(ActionProxy proxy)
/*     */   {
/* 220 */     return proxy.getActionName();
/*     */   }
/*     */ 
/*     */   protected String doIntercept(ActionInvocation actionInvocation)
/*     */     throws Exception
/*     */   {
/* 227 */     ActionProxy proxy = actionInvocation.getProxy();
/* 228 */     String name = getBackgroundProcessName(proxy);
/* 229 */     ActionContext context = actionInvocation.getInvocationContext();
/* 230 */     Map session = context.getSession();
/* 231 */     HttpSession httpSession = ServletActionContext.getRequest().getSession(true);
/*     */ 
/* 233 */     Boolean secondTime = Boolean.valueOf(true);
/* 234 */     if (this.executeAfterValidationPass) {
/* 235 */       secondTime = (Boolean)context.get("__execWait");
/* 236 */       if (secondTime == null) {
/* 237 */         context.put("__execWait", Boolean.valueOf(true));
/* 238 */         secondTime = Boolean.valueOf(false);
/*     */       } else {
/* 240 */         secondTime = Boolean.valueOf(true);
/* 241 */         context.put("__execWait", null);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 247 */     synchronized (httpSession) {
/* 248 */       BackgroundProcess bp = (BackgroundProcess)session.get("__execWait" + name);
/*     */ 
/* 250 */       if (((!this.executeAfterValidationPass) || (secondTime.booleanValue())) && (bp == null)) {
/* 251 */         bp = getNewBackgroundProcess(name, actionInvocation, this.threadPriority);
/* 252 */         session.put("__execWait" + name, bp);
/* 253 */         performInitialDelay(bp);
/* 254 */         secondTime = Boolean.valueOf(false);
/*     */       }
/*     */ 
/* 257 */       if (((!this.executeAfterValidationPass) || (!secondTime.booleanValue())) && (bp != null) && (!bp.isDone())) {
/* 258 */         actionInvocation.getStack().push(bp.getAction());
/*     */ 
/* 260 */         String token = TokenHelper.getToken();
/* 261 */         if (token != null) {
/* 262 */           TokenHelper.setSessionToken(TokenHelper.getTokenName(), token);
/*     */         }
/*     */ 
/* 265 */         Map results = proxy.getConfig().getResults();
/* 266 */         if (!results.containsKey("wait")) {
/* 267 */           if (LOG.isWarnEnabled()) {
/* 268 */             LOG.warn("ExecuteAndWait interceptor has detected that no result named 'wait' is available. Defaulting to a plain built-in wait page. It is highly recommend you provide an action-specific or global result named 'wait'.", new String[0]);
/*     */           }
/*     */ 
/* 277 */           FreemarkerResult waitResult = new FreemarkerResult();
/* 278 */           this.container.inject(waitResult);
/* 279 */           waitResult.setLocation("/org/apache/struts2/interceptor/wait.ftl");
/* 280 */           waitResult.execute(actionInvocation);
/*     */ 
/* 282 */           return "none";
/*     */         }
/*     */ 
/* 285 */         return "wait";
/* 286 */       }if (((!this.executeAfterValidationPass) || (!secondTime.booleanValue())) && (bp != null) && (bp.isDone())) {
/* 287 */         session.remove("__execWait" + name);
/* 288 */         actionInvocation.getStack().push(bp.getAction());
/*     */ 
/* 291 */         if (bp.getException() != null) {
/* 292 */           throw bp.getException();
/*     */         }
/*     */ 
/* 295 */         return bp.getResult();
/*     */       }
/*     */ 
/* 301 */       return actionInvocation.invoke();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void destroy()
/*     */   {
/*     */   }
/*     */ 
/*     */   protected void performInitialDelay(BackgroundProcess bp)
/*     */     throws InterruptedException
/*     */   {
/* 326 */     if ((this.delay <= 0) || (this.delaySleepInterval <= 0)) {
/* 327 */       return;
/*     */     }
/*     */ 
/* 330 */     int steps = this.delay / this.delaySleepInterval;
/* 331 */     if (LOG.isDebugEnabled()) {
/* 332 */       LOG.debug("Delaying for " + this.delay + " millis. (using " + steps + " steps)", new String[0]);
/*     */     }
/*     */ 
/* 335 */     for (int step = 0; (step < steps) && (!bp.isDone()); step++) {
/* 336 */       Thread.sleep(this.delaySleepInterval);
/*     */     }
/* 338 */     if (LOG.isDebugEnabled())
/* 339 */       LOG.debug("Sleeping ended after " + step + " steps and the background process is " + (bp.isDone() ? " done" : " not done"), new String[0]);
/*     */   }
/*     */ 
/*     */   public void setThreadPriority(int threadPriority)
/*     */   {
/* 349 */     this.threadPriority = threadPriority;
/*     */   }
/*     */ 
/*     */   public void setDelay(int delay)
/*     */   {
/* 358 */     this.delay = delay;
/*     */   }
/*     */ 
/*     */   public void setDelaySleepInterval(int delaySleepInterval)
/*     */   {
/* 367 */     this.delaySleepInterval = delaySleepInterval;
/*     */   }
/*     */ 
/*     */   public void setExecuteAfterValidationPass(boolean executeAfterValidationPass)
/*     */   {
/* 377 */     this.executeAfterValidationPass = executeAfterValidationPass;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.interceptor.ExecuteAndWaitInterceptor
 * JD-Core Version:    0.6.0
 */