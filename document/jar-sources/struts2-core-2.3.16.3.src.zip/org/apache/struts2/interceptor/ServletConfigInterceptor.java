/*     */ package org.apache.struts2.interceptor;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionContext;
/*     */ import com.opensymphony.xwork2.ActionInvocation;
/*     */ import com.opensymphony.xwork2.interceptor.AbstractInterceptor;
/*     */ import java.util.Map;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.struts2.StrutsStatics;
/*     */ import org.apache.struts2.servlet.interceptor.ServletPrincipalProxy;
/*     */ import org.apache.struts2.util.ServletContextAware;
/*     */ 
/*     */ public class ServletConfigInterceptor extends AbstractInterceptor
/*     */   implements StrutsStatics
/*     */ {
/*     */   private static final long serialVersionUID = 605261777858676638L;
/*     */ 
/*     */   public String intercept(ActionInvocation invocation)
/*     */     throws Exception
/*     */   {
/* 124 */     Object action = invocation.getAction();
/* 125 */     ActionContext context = invocation.getInvocationContext();
/*     */ 
/* 127 */     if ((action instanceof ServletRequestAware)) {
/* 128 */       HttpServletRequest request = (HttpServletRequest)context.get("com.opensymphony.xwork2.dispatcher.HttpServletRequest");
/* 129 */       ((ServletRequestAware)action).setServletRequest(request);
/*     */     }
/*     */ 
/* 132 */     if ((action instanceof ServletResponseAware)) {
/* 133 */       HttpServletResponse response = (HttpServletResponse)context.get("com.opensymphony.xwork2.dispatcher.HttpServletResponse");
/* 134 */       ((ServletResponseAware)action).setServletResponse(response);
/*     */     }
/*     */ 
/* 137 */     if ((action instanceof ParameterAware)) {
/* 138 */       ((ParameterAware)action).setParameters(context.getParameters());
/*     */     }
/*     */ 
/* 141 */     if ((action instanceof ApplicationAware)) {
/* 142 */       ((ApplicationAware)action).setApplication(context.getApplication());
/*     */     }
/*     */ 
/* 145 */     if ((action instanceof SessionAware)) {
/* 146 */       ((SessionAware)action).setSession(context.getSession());
/*     */     }
/*     */ 
/* 149 */     if ((action instanceof RequestAware)) {
/* 150 */       ((RequestAware)action).setRequest((Map)context.get("request"));
/*     */     }
/*     */ 
/* 153 */     if ((action instanceof PrincipalAware)) {
/* 154 */       HttpServletRequest request = (HttpServletRequest)context.get("com.opensymphony.xwork2.dispatcher.HttpServletRequest");
/* 155 */       if (request != null)
/*     */       {
/* 157 */         ((PrincipalAware)action).setPrincipalProxy(new ServletPrincipalProxy(request));
/*     */       }
/*     */     }
/* 160 */     if ((action instanceof ServletContextAware)) {
/* 161 */       ServletContext servletContext = (ServletContext)context.get("com.opensymphony.xwork2.dispatcher.ServletContext");
/* 162 */       ((ServletContextAware)action).setServletContext(servletContext);
/*     */     }
/* 164 */     return invocation.invoke();
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.interceptor.ServletConfigInterceptor
 * JD-Core Version:    0.6.0
 */