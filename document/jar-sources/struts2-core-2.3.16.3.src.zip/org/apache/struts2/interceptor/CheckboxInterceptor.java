/*     */ package org.apache.struts2.interceptor;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionContext;
/*     */ import com.opensymphony.xwork2.ActionInvocation;
/*     */ import com.opensymphony.xwork2.interceptor.AbstractInterceptor;
/*     */ import com.opensymphony.xwork2.util.logging.Logger;
/*     */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class CheckboxInterceptor extends AbstractInterceptor
/*     */ {
/*     */   private static final long serialVersionUID = -586878104807229585L;
/*  56 */   private String uncheckedValue = Boolean.FALSE.toString();
/*     */ 
/*  58 */   private static final Logger LOG = LoggerFactory.getLogger(CheckboxInterceptor.class);
/*     */ 
/*     */   public String intercept(ActionInvocation ai) throws Exception {
/*  61 */     Map parameters = ai.getInvocationContext().getParameters();
/*  62 */     Map newParams = new HashMap();
/*  63 */     Set entries = parameters.entrySet();
/*     */ 
/*  65 */     for (Iterator iterator = entries.iterator(); iterator.hasNext(); ) {
/*  66 */       Map.Entry entry = (Map.Entry)iterator.next();
/*  67 */       String key = (String)entry.getKey();
/*     */ 
/*  69 */       if (key.startsWith("__checkbox_")) {
/*  70 */         String name = key.substring("__checkbox_".length());
/*     */ 
/*  72 */         Object values = entry.getValue();
/*  73 */         iterator.remove();
/*  74 */         if ((values != null) && ((values instanceof String[])) && (((String[])(String[])values).length > 1)) {
/*  75 */           if (LOG.isDebugEnabled()) {
/*  76 */             LOG.debug("Bypassing automatic checkbox detection due to multiple checkboxes of the same name: #0", new String[] { name }); continue;
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/*  82 */         if (!parameters.containsKey(name))
/*     */         {
/*  84 */           newParams.put(name, new String[] { this.uncheckedValue });
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*  89 */     parameters.putAll(newParams);
/*     */ 
/*  91 */     return ai.invoke();
/*     */   }
/*     */ 
/*     */   public void setUncheckedValue(String uncheckedValue)
/*     */   {
/* 100 */     this.uncheckedValue = uncheckedValue;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.interceptor.CheckboxInterceptor
 * JD-Core Version:    0.6.0
 */