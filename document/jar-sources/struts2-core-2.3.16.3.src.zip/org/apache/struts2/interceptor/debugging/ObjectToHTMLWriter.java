/*     */ package org.apache.struts2.interceptor.debugging;
/*     */ 
/*     */ import com.opensymphony.xwork2.util.reflection.ReflectionException;
/*     */ import com.opensymphony.xwork2.util.reflection.ReflectionProvider;
/*     */ import java.beans.IntrospectionException;
/*     */ import java.io.Writer;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ 
/*     */ class ObjectToHTMLWriter
/*     */ {
/*     */   private PrettyPrintWriter prettyWriter;
/*     */ 
/*     */   ObjectToHTMLWriter(Writer writer)
/*     */   {
/*  43 */     this.prettyWriter = new PrettyPrintWriter(writer);
/*  44 */     this.prettyWriter.setEscape(false);
/*     */   }
/*     */ 
/*     */   public void write(ReflectionProvider reflectionProvider, Object root, String expr)
/*     */     throws IntrospectionException, ReflectionException
/*     */   {
/*  50 */     this.prettyWriter.startNode("table");
/*  51 */     this.prettyWriter.addAttribute("class", "debugTable");
/*     */ 
/*  53 */     if ((root instanceof Map)) {
/*  54 */       Iterator iterator = ((Map)root).entrySet().iterator();
/*  55 */       while (iterator.hasNext()) {
/*  56 */         Map.Entry property = (Map.Entry)iterator.next();
/*  57 */         String key = property.getKey().toString();
/*  58 */         Object value = property.getValue();
/*  59 */         writeProperty(key, value, expr);
/*     */       }
/*  61 */     } else if ((root instanceof List)) {
/*  62 */       List list = (List)root;
/*  63 */       for (int i = 0; i < list.size(); i++) {
/*  64 */         Object element = list.get(i);
/*  65 */         writeProperty(String.valueOf(i), element, expr);
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/*     */       Iterator iterator;
/*  67 */       if ((root instanceof Set)) {
/*  68 */         Set set = (Set)root;
/*  69 */         for (iterator = set.iterator(); iterator.hasNext(); )
/*  70 */           writeProperty("", iterator.next(), expr);
/*     */       }
/*  72 */       else if (root.getClass().isArray()) {
/*  73 */         Object[] objects = (Object[])(Object[])root;
/*  74 */         for (int i = 0; i < objects.length; i++)
/*  75 */           writeProperty(String.valueOf(i), objects[i], expr);
/*     */       }
/*     */       else
/*     */       {
/*  79 */         Map properties = reflectionProvider.getBeanMap(root);
/*  80 */         for (Map.Entry property : properties.entrySet()) {
/*  81 */           String name = (String)property.getKey();
/*  82 */           Object value = property.getValue();
/*     */ 
/*  84 */           if ("class".equals(name)) {
/*     */             continue;
/*     */           }
/*  87 */           writeProperty(name, value, expr);
/*     */         }
/*     */       }
/*     */     }
/*  91 */     this.prettyWriter.endNode();
/*     */   }
/*     */ 
/*     */   private void writeProperty(String name, Object value, String expr) {
/*  95 */     this.prettyWriter.startNode("tr");
/*     */ 
/*  98 */     this.prettyWriter.startNode("td");
/*  99 */     this.prettyWriter.addAttribute("class", "nameColumn");
/* 100 */     this.prettyWriter.setValue(name);
/* 101 */     this.prettyWriter.endNode();
/*     */ 
/* 104 */     this.prettyWriter.startNode("td");
/* 105 */     if (value != null)
/*     */     {
/* 107 */       if ((value != null) && ((isEmptyCollection(value)) || (isEmptyMap(value)) || ((value.getClass().isArray()) && (((Object[])(Object[])value).length == 0))))
/*     */       {
/* 110 */         this.prettyWriter.addAttribute("class", "emptyCollection");
/* 111 */         this.prettyWriter.setValue("empty");
/*     */       } else {
/* 113 */         this.prettyWriter.addAttribute("class", "valueColumn");
/* 114 */         writeValue(name, value, expr);
/*     */       }
/*     */     } else {
/* 117 */       this.prettyWriter.addAttribute("class", "nullValue");
/* 118 */       this.prettyWriter.setValue("null");
/*     */     }
/* 120 */     this.prettyWriter.endNode();
/*     */ 
/* 123 */     this.prettyWriter.startNode("td");
/* 124 */     if (value != null) {
/* 125 */       this.prettyWriter.addAttribute("class", "typeColumn");
/* 126 */       Class clazz = value.getClass();
/* 127 */       this.prettyWriter.setValue(clazz.getName());
/*     */     } else {
/* 129 */       this.prettyWriter.addAttribute("class", "nullValue");
/* 130 */       this.prettyWriter.setValue("unknown");
/*     */     }
/* 132 */     this.prettyWriter.endNode();
/*     */ 
/* 135 */     this.prettyWriter.endNode();
/*     */   }
/*     */ 
/*     */   private boolean isEmptyMap(Object value)
/*     */   {
/*     */     try
/*     */     {
/* 143 */       return ((value instanceof Map)) && (((Map)value).isEmpty()); } catch (Exception e) {
/*     */     }
/* 145 */     return true;
/*     */   }
/*     */ 
/*     */   private boolean isEmptyCollection(Object value)
/*     */   {
/*     */     try
/*     */     {
/* 154 */       return ((value instanceof Collection)) && (((Collection)value).isEmpty()); } catch (Exception e) {
/*     */     }
/* 156 */     return true;
/*     */   }
/*     */ 
/*     */   private void writeValue(String name, Object value, String expr)
/*     */   {
/* 161 */     Class clazz = value.getClass();
/* 162 */     if ((clazz.isPrimitive()) || (Number.class.isAssignableFrom(clazz)) || (clazz.equals(String.class)) || (Boolean.class.equals(clazz)))
/*     */     {
/* 164 */       this.prettyWriter.setValue(String.valueOf(value));
/*     */     } else {
/* 166 */       this.prettyWriter.startNode("a");
/* 167 */       String path = expr.replaceAll("#", "%23") + "[\"" + name.replaceAll("#", "%23") + "\"]";
/*     */ 
/* 169 */       this.prettyWriter.addAttribute("onclick", "expand(this, '" + path + "')");
/* 170 */       this.prettyWriter.addAttribute("href", "javascript://nop/");
/* 171 */       this.prettyWriter.setValue("Expand");
/* 172 */       this.prettyWriter.endNode();
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.interceptor.debugging.ObjectToHTMLWriter
 * JD-Core Version:    0.6.0
 */