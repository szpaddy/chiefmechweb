/*     */ package org.apache.struts2.interceptor.debugging;
/*     */ 
/*     */ import java.io.PrintWriter;
/*     */ import java.io.Writer;
/*     */ import java.util.Stack;
/*     */ 
/*     */ public class PrettyPrintWriter
/*     */ {
/*     */   private final PrintWriter writer;
/*  31 */   private final Stack<String> elementStack = new Stack();
/*     */   private final char[] lineIndenter;
/*     */   private boolean tagInProgress;
/*     */   private int depth;
/*     */   private boolean readyForNewLine;
/*     */   private boolean tagIsEmpty;
/*     */   private String newLine;
/*  39 */   private boolean escape = true;
/*     */ 
/*  41 */   private static final char[] NULL = "&#x0;".toCharArray();
/*  42 */   private static final char[] AMP = "&amp;".toCharArray();
/*  43 */   private static final char[] LT = "&lt;".toCharArray();
/*  44 */   private static final char[] GT = "&gt;".toCharArray();
/*  45 */   private static final char[] SLASH_R = "&#x0D;".toCharArray();
/*  46 */   private static final char[] QUOT = "&quot;".toCharArray();
/*  47 */   private static final char[] APOS = "&apos;".toCharArray();
/*  48 */   private static final char[] CLOSE = "</".toCharArray();
/*     */ 
/*     */   public PrettyPrintWriter(Writer writer, char[] lineIndenter, String newLine) {
/*  51 */     this.writer = new PrintWriter(writer);
/*  52 */     this.lineIndenter = lineIndenter;
/*  53 */     this.newLine = newLine;
/*     */   }
/*     */ 
/*     */   public PrettyPrintWriter(Writer writer, char[] lineIndenter) {
/*  57 */     this(writer, lineIndenter, "\n");
/*     */   }
/*     */ 
/*     */   public PrettyPrintWriter(Writer writer, String lineIndenter, String newLine) {
/*  61 */     this(writer, lineIndenter.toCharArray(), newLine);
/*     */   }
/*     */ 
/*     */   public PrettyPrintWriter(Writer writer, String lineIndenter) {
/*  65 */     this(writer, lineIndenter.toCharArray());
/*     */   }
/*     */ 
/*     */   public PrettyPrintWriter(Writer writer) {
/*  69 */     this(writer, new char[] { ' ', ' ' });
/*     */   }
/*     */ 
/*     */   public void startNode(String name) {
/*  73 */     this.tagIsEmpty = false;
/*  74 */     finishTag();
/*  75 */     this.writer.write(60);
/*  76 */     this.writer.write(name);
/*  77 */     this.elementStack.push(name);
/*  78 */     this.tagInProgress = true;
/*  79 */     this.depth += 1;
/*  80 */     this.readyForNewLine = true;
/*  81 */     this.tagIsEmpty = true;
/*     */   }
/*     */ 
/*     */   public void setValue(String text) {
/*  85 */     this.readyForNewLine = false;
/*  86 */     this.tagIsEmpty = false;
/*  87 */     finishTag();
/*     */ 
/*  89 */     writeText(this.writer, text);
/*     */   }
/*     */ 
/*     */   public void addAttribute(String key, String value) {
/*  93 */     this.writer.write(32);
/*  94 */     this.writer.write(key);
/*  95 */     this.writer.write(61);
/*  96 */     this.writer.write(34);
/*  97 */     writeAttributeValue(this.writer, value);
/*  98 */     this.writer.write(34);
/*     */   }
/*     */ 
/*     */   protected void writeAttributeValue(PrintWriter writer, String text) {
/* 102 */     writeText(text);
/*     */   }
/*     */ 
/*     */   protected void writeText(PrintWriter writer, String text) {
/* 106 */     writeText(text);
/*     */   }
/*     */ 
/*     */   private void writeText(String text) {
/* 110 */     int length = text.length();
/* 111 */     for (int i = 0; i < length; i++) {
/* 112 */       char c = text.charAt(i);
/* 113 */       switch (c) {
/*     */       case '\000':
/* 115 */         this.writer.write(NULL);
/* 116 */         break;
/*     */       case '&':
/* 118 */         this.writer.write(AMP);
/* 119 */         break;
/*     */       case '<':
/* 121 */         this.writer.write(LT);
/* 122 */         break;
/*     */       case '>':
/* 124 */         this.writer.write(GT);
/* 125 */         break;
/*     */       case '"':
/* 127 */         this.writer.write(QUOT);
/* 128 */         break;
/*     */       case '\'':
/* 132 */         if (this.escape)
/* 133 */           this.writer.write(APOS);
/*     */         else
/* 135 */           this.writer.write(c);
/* 136 */         break;
/*     */       case '\r':
/* 138 */         this.writer.write(SLASH_R);
/* 139 */         break;
/*     */       default:
/* 141 */         this.writer.write(c);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void endNode() {
/* 147 */     this.depth -= 1;
/* 148 */     if (this.tagIsEmpty) {
/* 149 */       this.writer.write(47);
/* 150 */       this.readyForNewLine = false;
/* 151 */       finishTag();
/* 152 */       this.elementStack.pop();
/*     */     } else {
/* 154 */       finishTag();
/* 155 */       this.writer.write(CLOSE);
/* 156 */       this.writer.write((String)this.elementStack.pop());
/* 157 */       this.writer.write(62);
/*     */     }
/* 159 */     this.readyForNewLine = true;
/* 160 */     if (this.depth == 0)
/* 161 */       this.writer.flush();
/*     */   }
/*     */ 
/*     */   private void finishTag()
/*     */   {
/* 166 */     if (this.tagInProgress) {
/* 167 */       this.writer.write(62);
/*     */     }
/* 169 */     this.tagInProgress = false;
/* 170 */     if (this.readyForNewLine) {
/* 171 */       endOfLine();
/*     */     }
/* 173 */     this.readyForNewLine = false;
/* 174 */     this.tagIsEmpty = false;
/*     */   }
/*     */ 
/*     */   protected void endOfLine() {
/* 178 */     this.writer.write(this.newLine);
/* 179 */     for (int i = 0; i < this.depth; i++)
/* 180 */       this.writer.write(this.lineIndenter);
/*     */   }
/*     */ 
/*     */   public void flush()
/*     */   {
/* 185 */     this.writer.flush();
/*     */   }
/*     */ 
/*     */   public void close() {
/* 189 */     this.writer.close();
/*     */   }
/*     */ 
/*     */   public boolean isEscape() {
/* 193 */     return this.escape;
/*     */   }
/*     */ 
/*     */   public void setEscape(boolean escape) {
/* 197 */     this.escape = escape;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.interceptor.debugging.PrettyPrintWriter
 * JD-Core Version:    0.6.0
 */