/*     */ package org.apache.struts2.interceptor.debugging;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionContext;
/*     */ import com.opensymphony.xwork2.ActionInvocation;
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import com.opensymphony.xwork2.interceptor.AbstractInterceptor;
/*     */ import com.opensymphony.xwork2.interceptor.PreResultListener;
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import com.opensymphony.xwork2.util.logging.Logger;
/*     */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*     */ import com.opensymphony.xwork2.util.reflection.ReflectionProvider;
/*     */ import java.beans.BeanInfo;
/*     */ import java.beans.Introspector;
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.StringWriter;
/*     */ import java.lang.reflect.Array;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.struts2.ServletActionContext;
/*     */ import org.apache.struts2.dispatcher.FilterDispatcher;
/*     */ import org.apache.struts2.views.freemarker.FreemarkerManager;
/*     */ import org.apache.struts2.views.freemarker.FreemarkerResult;
/*     */ 
/*     */ public class DebuggingInterceptor extends AbstractInterceptor
/*     */ {
/*     */   private static final long serialVersionUID = -3097324155953078783L;
/*  96 */   private static final Logger LOG = LoggerFactory.getLogger(DebuggingInterceptor.class);
/*     */ 
/*  98 */   private String[] ignorePrefixes = { "org.apache.struts.", "com.opensymphony.xwork2.", "xwork." };
/*     */ 
/* 100 */   private String[] _ignoreKeys = { "application", "session", "parameters", "request" };
/*     */ 
/* 102 */   private HashSet<String> ignoreKeys = new HashSet(Arrays.asList(this._ignoreKeys));
/*     */   private static final String XML_MODE = "xml";
/*     */   private static final String CONSOLE_MODE = "console";
/*     */   private static final String COMMAND_MODE = "command";
/*     */   private static final String BROWSER_MODE = "browser";
/*     */   private static final String SESSION_KEY = "org.apache.struts2.interceptor.debugging.VALUE_STACK";
/*     */   private static final String DEBUG_PARAM = "debug";
/*     */   private static final String OBJECT_PARAM = "object";
/*     */   private static final String EXPRESSION_PARAM = "expression";
/*     */   private static final String DECORATE_PARAM = "decorate";
/* 116 */   private boolean enableXmlWithConsole = false;
/*     */   private boolean devMode;
/*     */   private FreemarkerManager freemarkerManager;
/* 121 */   private boolean consoleEnabled = false;
/*     */   private ReflectionProvider reflectionProvider;
/*     */ 
/*     */   @Inject("struts.devMode")
/*     */   public void setDevMode(String mode)
/*     */   {
/* 126 */     this.devMode = "true".equals(mode);
/*     */   }
/*     */   @Inject
/*     */   public void setFreemarkerManager(FreemarkerManager mgr) {
/* 131 */     this.freemarkerManager = mgr;
/*     */   }
/*     */   @Inject
/*     */   public void setReflectionProvider(ReflectionProvider reflectionProvider) {
/* 136 */     this.reflectionProvider = reflectionProvider;
/*     */   }
/*     */ 
/*     */   public String intercept(ActionInvocation inv)
/*     */     throws Exception
/*     */   {
/* 145 */     boolean actionOnly = false;
/* 146 */     boolean cont = true;
/* 147 */     Boolean devModeOverride = FilterDispatcher.getDevModeOverride();
/* 148 */     boolean devMode = devModeOverride != null ? devModeOverride.booleanValue() : this.devMode;
/*     */     ActionContext ctx;
/* 149 */     if (devMode) {
/* 150 */       ctx = ActionContext.getContext();
/* 151 */       String type = getParameter("debug");
/* 152 */       ctx.getParameters().remove("debug");
/* 153 */       if ("xml".equals(type)) {
/* 154 */         inv.addPreResultListener(new PreResultListener()
/*     */         {
/*     */           public void beforeResult(ActionInvocation inv, String result) {
/* 157 */             DebuggingInterceptor.this.printContext();
/*     */           } } );
/* 160 */       } else if ("console".equals(type)) {
/* 161 */         this.consoleEnabled = true;
/* 162 */         inv.addPreResultListener(new PreResultListener()
/*     */         {
/*     */           public void beforeResult(ActionInvocation inv, String actionResult) {
/* 165 */             String xml = "";
/* 166 */             if (DebuggingInterceptor.this.enableXmlWithConsole) {
/* 167 */               StringWriter writer = new StringWriter();
/* 168 */               DebuggingInterceptor.this.printContext(new PrettyPrintWriter(writer));
/* 169 */               xml = writer.toString();
/* 170 */               xml = xml.replaceAll("&", "&amp;");
/* 171 */               xml = xml.replaceAll(">", "&gt;");
/* 172 */               xml = xml.replaceAll("<", "&lt;");
/*     */             }
/* 174 */             ActionContext.getContext().put("debugXML", xml);
/*     */ 
/* 176 */             FreemarkerResult result = new FreemarkerResult();
/* 177 */             result.setFreemarkerManager(DebuggingInterceptor.this.freemarkerManager);
/* 178 */             result.setContentType("text/html");
/* 179 */             result.setLocation("/org/apache/struts2/interceptor/debugging/console.ftl");
/* 180 */             result.setParse(false);
/*     */             try {
/* 182 */               result.execute(inv);
/*     */             } catch (Exception ex) {
/* 184 */               DebuggingInterceptor.LOG.error("Unable to create debugging console", ex, new String[0]);
/*     */             }
/*     */           } } );
/*     */       }
/* 189 */       else if ("command".equals(type)) {
/* 190 */         ValueStack stack = (ValueStack)ctx.getSession().get("org.apache.struts2.interceptor.debugging.VALUE_STACK");
/* 191 */         if (stack == null)
/*     */         {
/* 193 */           stack = (ValueStack)ctx.get("com.opensymphony.xwork2.util.ValueStack.ValueStack");
/* 194 */           ctx.getSession().put("org.apache.struts2.interceptor.debugging.VALUE_STACK", stack);
/*     */         }
/* 196 */         String cmd = getParameter("expression");
/*     */ 
/* 198 */         ServletActionContext.getRequest().setAttribute("decorator", "none");
/* 199 */         HttpServletResponse res = ServletActionContext.getResponse();
/* 200 */         res.setContentType("text/plain");
/*     */         try
/*     */         {
/* 203 */           PrintWriter writer = ServletActionContext.getResponse().getWriter();
/*     */ 
/* 205 */           writer.print(stack.findValue(cmd));
/* 206 */           writer.close();
/*     */         } catch (IOException ex) {
/* 208 */           ex.printStackTrace();
/*     */         }
/* 210 */         cont = false;
/* 211 */       } else if ("browser".equals(type)) {
/* 212 */         actionOnly = true;
/* 213 */         inv.addPreResultListener(new PreResultListener(ctx)
/*     */         {
/*     */           public void beforeResult(ActionInvocation inv, String actionResult) {
/* 216 */             String rootObjectExpression = DebuggingInterceptor.this.getParameter("object");
/* 217 */             if (rootObjectExpression == null)
/* 218 */               rootObjectExpression = "#context";
/* 219 */             String decorate = DebuggingInterceptor.this.getParameter("decorate");
/* 220 */             ValueStack stack = (ValueStack)this.val$ctx.get("com.opensymphony.xwork2.util.ValueStack.ValueStack");
/* 221 */             Object rootObject = stack.findValue(rootObjectExpression);
/*     */             try
/*     */             {
/* 224 */               StringWriter writer = new StringWriter();
/* 225 */               ObjectToHTMLWriter htmlWriter = new ObjectToHTMLWriter(writer);
/* 226 */               htmlWriter.write(DebuggingInterceptor.this.reflectionProvider, rootObject, rootObjectExpression);
/* 227 */               String html = writer.toString();
/* 228 */               writer.close();
/*     */ 
/* 230 */               stack.set("debugHtml", html);
/*     */ 
/* 234 */               if ("false".equals(decorate)) {
/* 235 */                 ServletActionContext.getRequest().setAttribute("decorator", "none");
/*     */               }
/* 237 */               FreemarkerResult result = new FreemarkerResult();
/* 238 */               result.setFreemarkerManager(DebuggingInterceptor.this.freemarkerManager);
/* 239 */               result.setContentType("text/html");
/* 240 */               result.setLocation("/org/apache/struts2/interceptor/debugging/browser.ftl");
/* 241 */               result.execute(inv);
/*     */             } catch (Exception ex) {
/* 243 */               DebuggingInterceptor.LOG.error("Unable to create debugging console", ex, new String[0]);
/*     */             }
/*     */           }
/*     */         });
/*     */       }
/*     */     }
/* 250 */     if (cont) {
/*     */       try {
/* 252 */         if (actionOnly) {
/* 253 */           inv.invokeActionOnly();
/* 254 */           ctx = null;
/*     */           ActionContext ctx;
/*     */           return ctx;
/*     */         }
/* 256 */         ctx = inv.invoke();
/*     */         ActionContext ctx;
/*     */         return ctx;
/*     */       }
/*     */       finally
/*     */       {
/* 259 */         if ((devMode) && (this.consoleEnabled)) {
/* 260 */           ActionContext ctx = ActionContext.getContext();
/* 261 */           ctx.getSession().put("org.apache.struts2.interceptor.debugging.VALUE_STACK", ctx.get("com.opensymphony.xwork2.util.ValueStack.ValueStack"));
/*     */         }
/*     */       }
/*     */     }
/* 265 */     return null;
/*     */   }
/*     */ 
/*     */   private String getParameter(String key)
/*     */   {
/* 277 */     String[] arr = (String[])(String[])ActionContext.getContext().getParameters().get(key);
/* 278 */     if ((arr != null) && (arr.length > 0)) {
/* 279 */       return arr[0];
/*     */     }
/* 281 */     return null;
/*     */   }
/*     */ 
/*     */   protected void printContext()
/*     */   {
/* 289 */     HttpServletResponse res = ServletActionContext.getResponse();
/* 290 */     res.setContentType("text/xml");
/*     */     try
/*     */     {
/* 293 */       PrettyPrintWriter writer = new PrettyPrintWriter(ServletActionContext.getResponse().getWriter());
/*     */ 
/* 295 */       printContext(writer);
/* 296 */       writer.close();
/*     */     } catch (IOException ex) {
/* 298 */       ex.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void printContext(PrettyPrintWriter writer)
/*     */   {
/* 309 */     ActionContext ctx = ActionContext.getContext();
/* 310 */     writer.startNode("debug");
/* 311 */     serializeIt(ctx.getParameters(), "parameters", writer, new ArrayList());
/*     */ 
/* 313 */     writer.startNode("context");
/*     */ 
/* 315 */     Map ctxMap = ctx.getContextMap();
/* 316 */     for (Iterator i$ = ctxMap.keySet().iterator(); i$.hasNext(); ) { Object o = i$.next();
/* 317 */       String key = o.toString();
/* 318 */       boolean print = !this.ignoreKeys.contains(key);
/*     */ 
/* 320 */       for (String ignorePrefixe : this.ignorePrefixes) {
/* 321 */         if (key.startsWith(ignorePrefixe)) {
/* 322 */           print = false;
/* 323 */           break;
/*     */         }
/*     */       }
/* 326 */       if (print) {
/* 327 */         serializeIt(ctxMap.get(key), key, writer, new ArrayList());
/*     */       }
/*     */     }
/* 330 */     writer.endNode();
/* 331 */     Map requestMap = (Map)ctx.get("request");
/* 332 */     serializeIt(requestMap, "request", writer, filterValueStack(requestMap));
/* 333 */     serializeIt(ctx.getSession(), "session", writer, new ArrayList());
/*     */ 
/* 335 */     ValueStack stack = (ValueStack)ctx.get("com.opensymphony.xwork2.util.ValueStack.ValueStack");
/* 336 */     serializeIt(stack.getRoot(), "valueStack", writer, new ArrayList());
/* 337 */     writer.endNode();
/*     */   }
/*     */ 
/*     */   protected void serializeIt(Object bean, String name, PrettyPrintWriter writer, List<Object> stack)
/*     */   {
/* 356 */     writer.flush();
/*     */ 
/* 358 */     if ((bean != null) && (stack.contains(bean))) {
/* 359 */       if (LOG.isInfoEnabled()) {
/* 360 */         LOG.info("Circular reference detected, not serializing object: " + name, new String[0]);
/*     */       }
/*     */ 
/* 363 */       return;
/* 364 */     }if (bean != null)
/*     */     {
/* 367 */       stack.add(bean);
/*     */     }
/* 369 */     if (bean == null) {
/* 370 */       return;
/*     */     }
/* 372 */     String clsName = bean.getClass().getName();
/*     */ 
/* 374 */     writer.startNode(name);
/*     */     Iterator i$;
/* 377 */     if ((bean instanceof Collection)) {
/* 378 */       Collection col = (Collection)bean;
/*     */ 
/* 382 */       for (i$ = col.iterator(); i$.hasNext(); ) { Object aCol = i$.next();
/* 383 */         serializeIt(aCol, "value", writer, stack); }
/*     */     }
/* 385 */     else if ((bean instanceof Map))
/*     */     {
/* 387 */       Map map = (Map)bean;
/*     */ 
/* 390 */       for (Map.Entry entry : map.entrySet()) {
/* 391 */         Object objValue = entry.getValue();
/* 392 */         serializeIt(objValue, entry.getKey().toString(), writer, stack);
/*     */       }
/* 394 */     } else if (bean.getClass().isArray())
/*     */     {
/* 396 */       for (int i = 0; i < Array.getLength(bean); i++) {
/* 397 */         serializeIt(Array.get(bean, i), "arrayitem", writer, stack);
/*     */       }
/*     */     }
/* 400 */     else if (clsName.startsWith("java.lang")) {
/* 401 */       writer.setValue(bean.toString());
/*     */     }
/*     */     else
/*     */     {
/*     */       try {
/* 406 */         BeanInfo info = Introspector.getBeanInfo(bean.getClass());
/* 407 */         PropertyDescriptor[] props = info.getPropertyDescriptors();
/*     */ 
/* 409 */         for (PropertyDescriptor prop : props) {
/* 410 */           String n = prop.getName();
/* 411 */           Method m = prop.getReadMethod();
/*     */ 
/* 415 */           if (m != null)
/* 416 */             serializeIt(m.invoke(bean, new Object[0]), n, writer, stack);
/*     */         }
/*     */       }
/*     */       catch (Exception e) {
/* 420 */         LOG.error(e.toString(), e, new String[0]);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 425 */     writer.endNode();
/*     */ 
/* 428 */     stack.remove(bean);
/*     */   }
/*     */ 
/*     */   public void setEnableXmlWithConsole(boolean enableXmlWithConsole)
/*     */   {
/* 436 */     this.enableXmlWithConsole = enableXmlWithConsole;
/*     */   }
/*     */ 
/*     */   private List<Object> filterValueStack(Map requestMap)
/*     */   {
/* 441 */     List filter = new ArrayList();
/* 442 */     Object valueStack = requestMap.get("struts.valueStack");
/* 443 */     if (valueStack != null) {
/* 444 */       filter.add(valueStack);
/*     */     }
/* 446 */     return filter;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.interceptor.debugging.DebuggingInterceptor
 * JD-Core Version:    0.6.0
 */