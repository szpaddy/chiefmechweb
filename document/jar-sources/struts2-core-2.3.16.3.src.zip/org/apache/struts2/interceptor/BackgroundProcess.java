/*     */ package org.apache.struts2.interceptor;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionInvocation;
/*     */ import java.io.Serializable;
/*     */ 
/*     */ public class BackgroundProcess
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 3884464776311686443L;
/*     */   protected Object action;
/*     */   protected ActionInvocation invocation;
/*     */   protected String result;
/*     */   protected Exception exception;
/*     */   protected boolean done;
/*     */ 
/*     */   public BackgroundProcess(String threadName, ActionInvocation invocation, int threadPriority)
/*     */   {
/*  50 */     this.invocation = invocation;
/*  51 */     this.action = invocation.getAction();
/*     */     try {
/*  53 */       Thread t = new Thread(new Runnable(invocation) {
/*     */         public void run() {
/*     */           try {
/*  56 */             BackgroundProcess.this.beforeInvocation();
/*  57 */             BackgroundProcess.this.result = this.val$invocation.invokeActionOnly();
/*  58 */             BackgroundProcess.this.afterInvocation();
/*     */           } catch (Exception e) {
/*  60 */             BackgroundProcess.this.exception = e;
/*     */           }
/*     */ 
/*  63 */           BackgroundProcess.this.done = true;
/*     */         }
/*     */       });
/*  66 */       t.setName(threadName);
/*  67 */       t.setPriority(threadPriority);
/*  68 */       t.start();
/*     */     } catch (Exception e) {
/*  70 */       this.exception = e;
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void beforeInvocation()
/*     */     throws Exception
/*     */   {
/*     */   }
/*     */ 
/*     */   protected void afterInvocation()
/*     */     throws Exception
/*     */   {
/*     */   }
/*     */ 
/*     */   public Object getAction()
/*     */   {
/*  99 */     return this.action;
/*     */   }
/*     */ 
/*     */   public ActionInvocation getInvocation()
/*     */   {
/* 108 */     return this.invocation;
/*     */   }
/*     */ 
/*     */   public String getResult()
/*     */   {
/* 117 */     return this.result;
/*     */   }
/*     */ 
/*     */   public Exception getException()
/*     */   {
/* 126 */     return this.exception;
/*     */   }
/*     */ 
/*     */   public boolean isDone()
/*     */   {
/* 135 */     return this.done;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.interceptor.BackgroundProcess
 * JD-Core Version:    0.6.0
 */