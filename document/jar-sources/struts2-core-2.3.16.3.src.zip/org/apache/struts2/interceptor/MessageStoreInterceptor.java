/*     */ package org.apache.struts2.interceptor;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionContext;
/*     */ import com.opensymphony.xwork2.ActionInvocation;
/*     */ import com.opensymphony.xwork2.ValidationAware;
/*     */ import com.opensymphony.xwork2.interceptor.AbstractInterceptor;
/*     */ import com.opensymphony.xwork2.util.logging.Logger;
/*     */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.struts2.dispatcher.ServletRedirectResult;
/*     */ 
/*     */ public class MessageStoreInterceptor extends AbstractInterceptor
/*     */ {
/*     */   private static final long serialVersionUID = 9161650888603380164L;
/* 155 */   private static final Logger LOG = LoggerFactory.getLogger(MessageStoreInterceptor.class);
/*     */   public static final String AUTOMATIC_MODE = "AUTOMATIC";
/*     */   public static final String STORE_MODE = "STORE";
/*     */   public static final String RETRIEVE_MODE = "RETRIEVE";
/*     */   public static final String NONE = "NONE";
/* 162 */   private boolean allowRequestParameterSwitch = true;
/* 163 */   private String requestParameterSwitch = "operationMode";
/* 164 */   private String operationMode = "NONE";
/*     */   public static final String fieldErrorsSessionKey = "__MessageStoreInterceptor_FieldErrors_SessionKey";
/*     */   public static final String actionErrorsSessionKey = "__MessageStoreInterceptor_ActionErrors_SessionKey";
/*     */   public static final String actionMessagesSessionKey = "__MessageStoreInterceptor_ActionMessages_SessionKey";
/*     */ 
/*     */   public void setAllowRequestParameterSwitch(boolean allowRequestParameterSwitch)
/*     */   {
/* 171 */     this.allowRequestParameterSwitch = allowRequestParameterSwitch;
/*     */   }
/*     */   public boolean getAllowRequestParameterSwitch() {
/* 174 */     return this.allowRequestParameterSwitch;
/*     */   }
/*     */ 
/*     */   public void setRequestParameterSwitch(String requestParameterSwitch) {
/* 178 */     this.requestParameterSwitch = requestParameterSwitch;
/*     */   }
/*     */   public String getRequestParameterSwitch() {
/* 181 */     return this.requestParameterSwitch;
/*     */   }
/*     */ 
/*     */   public void setOperationMode(String operationMode) {
/* 185 */     this.operationMode = operationMode;
/*     */   }
/*     */   public String getOperationModel() {
/* 188 */     return this.operationMode;
/*     */   }
/*     */ 
/*     */   public String intercept(ActionInvocation invocation) throws Exception {
/* 192 */     if (LOG.isDebugEnabled()) {
/* 193 */       LOG.debug("entering MessageStoreInterceptor ...", new String[0]);
/*     */     }
/*     */ 
/* 196 */     before(invocation);
/* 197 */     String result = invocation.invoke();
/* 198 */     after(invocation, result);
/*     */ 
/* 200 */     if (LOG.isDebugEnabled()) {
/* 201 */       LOG.debug("exit executing MessageStoreInterceptor", new String[0]);
/*     */     }
/*     */ 
/* 204 */     return result;
/*     */   }
/*     */ 
/*     */   protected void before(ActionInvocation invocation)
/*     */     throws Exception
/*     */   {
/* 215 */     String reqOperationMode = getRequestOperationMode(invocation);
/*     */ 
/* 217 */     if (("RETRIEVE".equalsIgnoreCase(reqOperationMode)) || ("RETRIEVE".equalsIgnoreCase(this.operationMode)) || ("AUTOMATIC".equalsIgnoreCase(this.operationMode)))
/*     */     {
/* 221 */       Object action = invocation.getAction();
/* 222 */       if ((action instanceof ValidationAware))
/*     */       {
/* 224 */         Map session = (Map)invocation.getInvocationContext().get("com.opensymphony.xwork2.ActionContext.session");
/*     */ 
/* 226 */         if (session == null) {
/* 227 */           if (LOG.isDebugEnabled()) {
/* 228 */             LOG.debug("Session is not open, no errors / messages could be retrieve for action [" + action + "]", new String[0]);
/*     */           }
/* 230 */           return;
/*     */         }
/*     */ 
/* 233 */         ValidationAware validationAwareAction = (ValidationAware)action;
/*     */ 
/* 235 */         if (LOG.isDebugEnabled()) {
/* 236 */           LOG.debug("retrieve error / message from session to populate into action [" + action + "]", new String[0]);
/*     */         }
/*     */ 
/* 239 */         Collection actionErrors = (Collection)session.get("__MessageStoreInterceptor_ActionErrors_SessionKey");
/* 240 */         Collection actionMessages = (Collection)session.get("__MessageStoreInterceptor_ActionMessages_SessionKey");
/* 241 */         Map fieldErrors = (Map)session.get("__MessageStoreInterceptor_FieldErrors_SessionKey");
/*     */ 
/* 243 */         if ((actionErrors != null) && (actionErrors.size() > 0)) {
/* 244 */           Collection mergedActionErrors = mergeCollection(validationAwareAction.getActionErrors(), actionErrors);
/* 245 */           validationAwareAction.setActionErrors(mergedActionErrors);
/*     */         }
/*     */ 
/* 248 */         if ((actionMessages != null) && (actionMessages.size() > 0)) {
/* 249 */           Collection mergedActionMessages = mergeCollection(validationAwareAction.getActionMessages(), actionMessages);
/* 250 */           validationAwareAction.setActionMessages(mergedActionMessages);
/*     */         }
/*     */ 
/* 253 */         if ((fieldErrors != null) && (fieldErrors.size() > 0)) {
/* 254 */           Map mergedFieldErrors = mergeMap(validationAwareAction.getFieldErrors(), fieldErrors);
/* 255 */           validationAwareAction.setFieldErrors(mergedFieldErrors);
/*     */         }
/* 257 */         session.remove("__MessageStoreInterceptor_ActionErrors_SessionKey");
/* 258 */         session.remove("__MessageStoreInterceptor_ActionMessages_SessionKey");
/* 259 */         session.remove("__MessageStoreInterceptor_FieldErrors_SessionKey");
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void after(ActionInvocation invocation, String result)
/*     */     throws Exception
/*     */   {
/* 274 */     String reqOperationMode = getRequestOperationMode(invocation);
/* 275 */     boolean isRedirect = invocation.getResult() instanceof ServletRedirectResult;
/* 276 */     if (("STORE".equalsIgnoreCase(reqOperationMode)) || ("STORE".equalsIgnoreCase(this.operationMode)) || (("AUTOMATIC".equalsIgnoreCase(this.operationMode)) && (isRedirect)))
/*     */     {
/* 280 */       Object action = invocation.getAction();
/* 281 */       if ((action instanceof ValidationAware))
/*     */       {
/* 283 */         Map session = (Map)invocation.getInvocationContext().get("com.opensymphony.xwork2.ActionContext.session");
/*     */ 
/* 285 */         if (session == null) {
/* 286 */           if (LOG.isDebugEnabled()) {
/* 287 */             LOG.debug("Could not store action [" + action + "] error/messages into session, because session hasn't been opened yet.", new String[0]);
/*     */           }
/* 289 */           return;
/*     */         }
/*     */ 
/* 292 */         if (LOG.isDebugEnabled()) {
/* 293 */           LOG.debug("store action [" + action + "] error/messages into session ", new String[0]);
/*     */         }
/*     */ 
/* 296 */         ValidationAware validationAwareAction = (ValidationAware)action;
/* 297 */         session.put("__MessageStoreInterceptor_ActionErrors_SessionKey", validationAwareAction.getActionErrors());
/* 298 */         session.put("__MessageStoreInterceptor_ActionMessages_SessionKey", validationAwareAction.getActionMessages());
/* 299 */         session.put("__MessageStoreInterceptor_FieldErrors_SessionKey", validationAwareAction.getFieldErrors());
/*     */       }
/* 301 */       else if (LOG.isDebugEnabled()) {
/* 302 */         LOG.debug("Action [" + action + "] is not ValidationAware, no message / error that are storeable", new String[0]);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   protected String getRequestOperationMode(ActionInvocation invocation)
/*     */   {
/* 316 */     String reqOperationMode = "NONE";
/* 317 */     if (this.allowRequestParameterSwitch) {
/* 318 */       Map reqParams = (Map)invocation.getInvocationContext().get("com.opensymphony.xwork2.ActionContext.parameters");
/* 319 */       boolean containsParameter = reqParams.containsKey(this.requestParameterSwitch);
/* 320 */       if (containsParameter) {
/* 321 */         String[] reqParamsArr = (String[])(String[])reqParams.get(this.requestParameterSwitch);
/* 322 */         if ((reqParamsArr != null) && (reqParamsArr.length > 0)) {
/* 323 */           reqOperationMode = reqParamsArr[0];
/*     */         }
/*     */       }
/*     */     }
/* 327 */     return reqOperationMode;
/*     */   }
/*     */ 
/*     */   protected Collection mergeCollection(Collection col1, Collection col2)
/*     */   {
/* 339 */     Collection _col1 = col1 == null ? new ArrayList() : col1;
/* 340 */     Collection _col2 = col2 == null ? new ArrayList() : col2;
/* 341 */     _col1.addAll(_col2);
/* 342 */     return _col1;
/*     */   }
/*     */ 
/*     */   protected Map mergeMap(Map map1, Map map2)
/*     */   {
/* 354 */     Map _map1 = map1 == null ? new LinkedHashMap() : map1;
/* 355 */     Map _map2 = map2 == null ? new LinkedHashMap() : map2;
/* 356 */     _map1.putAll(_map2);
/* 357 */     return _map1;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.interceptor.MessageStoreInterceptor
 * JD-Core Version:    0.6.0
 */