/*    */ package org.apache.struts2.interceptor;
/*    */ 
/*    */ import com.opensymphony.xwork2.ActionContext;
/*    */ import com.opensymphony.xwork2.ActionInvocation;
/*    */ import com.opensymphony.xwork2.interceptor.AbstractInterceptor;
/*    */ import com.opensymphony.xwork2.interceptor.PreResultListener;
/*    */ import com.opensymphony.xwork2.util.logging.Logger;
/*    */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*    */ import java.util.Set;
/*    */ import javax.servlet.http.Cookie;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ 
/*    */ public class CookieProviderInterceptor extends AbstractInterceptor
/*    */   implements PreResultListener
/*    */ {
/* 71 */   private static final Logger LOG = LoggerFactory.getLogger(CookieProviderInterceptor.class);
/*    */ 
/*    */   public String intercept(ActionInvocation invocation) throws Exception {
/* 74 */     invocation.addPreResultListener(this);
/* 75 */     return invocation.invoke();
/*    */   }
/*    */ 
/*    */   protected void addCookiesToResponse(CookieProvider action, HttpServletResponse response)
/*    */   {
/* 85 */     Set cookies = action.getCookies();
/* 86 */     if (cookies != null)
/* 87 */       for (Cookie cookie : cookies) {
/* 88 */         if (LOG.isDebugEnabled()) {
/* 89 */           LOG.debug("Sending cookie [#0] with value [#1] for domain [#2]", new String[] { cookie.getName(), cookie.getValue(), cookie.getDomain() != null ? cookie.getDomain() : "no domain" });
/*    */         }
/*    */ 
/* 92 */         response.addCookie(cookie);
/*    */       }
/*    */   }
/*    */ 
/*    */   public void beforeResult(ActionInvocation invocation, String resultCode)
/*    */   {
/*    */     try {
/* 99 */       if (LOG.isTraceEnabled()) {
/* 100 */         LOG.trace("beforeResult start", new String[0]);
/*    */       }
/* 102 */       ActionContext ac = invocation.getInvocationContext();
/* 103 */       if ((invocation.getAction() instanceof CookieProvider)) {
/* 104 */         HttpServletResponse response = (HttpServletResponse)ac.get("com.opensymphony.xwork2.dispatcher.HttpServletResponse");
/* 105 */         addCookiesToResponse((CookieProvider)invocation.getAction(), response);
/*    */       }
/* 107 */       if (LOG.isTraceEnabled())
/* 108 */         LOG.trace("beforeResult end", new String[0]);
/*    */     }
/*    */     catch (Exception ex) {
/* 111 */       LOG.error("Unable to setup cookies", ex, new String[0]);
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.interceptor.CookieProviderInterceptor
 * JD-Core Version:    0.6.0
 */