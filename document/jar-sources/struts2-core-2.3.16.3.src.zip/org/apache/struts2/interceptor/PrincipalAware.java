package org.apache.struts2.interceptor;

public abstract interface PrincipalAware
{
  public abstract void setPrincipalProxy(PrincipalProxy paramPrincipalProxy);
}

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.interceptor.PrincipalAware
 * JD-Core Version:    0.6.0
 */