package org.apache.struts2.interceptor;

import java.util.Map;

public abstract interface CookiesAware
{
  public abstract void setCookiesMap(Map<String, String> paramMap);
}

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.interceptor.CookiesAware
 * JD-Core Version:    0.6.0
 */