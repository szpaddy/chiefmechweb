/*     */ package org.apache.struts2.interceptor;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionContext;
/*     */ import com.opensymphony.xwork2.ActionInvocation;
/*     */ import com.opensymphony.xwork2.ActionProxy;
/*     */ import com.opensymphony.xwork2.interceptor.I18nInterceptor.LocaleFinder;
/*     */ import com.opensymphony.xwork2.interceptor.I18nInterceptor.Storage;
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import com.opensymphony.xwork2.util.logging.Logger;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import javax.servlet.http.Cookie;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.struts2.ServletActionContext;
/*     */ 
/*     */ public class I18nInterceptor extends com.opensymphony.xwork2.interceptor.I18nInterceptor
/*     */ {
/*     */   private static final long serialVersionUID = 4587460933182760358L;
/*     */   public static final String DEFAULT_COOKIE_ATTRIBUTE = "WW_TRANS_I18N_LOCALE";
/*     */   public static final String COOKIE_STORAGE = "cookie";
/*     */   public static final String DEFAULT_COOKIE_PARAMETER = "request_cookie_locale";
/*     */   protected String requestCookieParameterName;
/*     */ 
/*     */   public I18nInterceptor()
/*     */   {
/*  78 */     this.requestCookieParameterName = "request_cookie_locale";
/*     */   }
/*     */ 
/*     */   public String intercept(ActionInvocation invocation)
/*     */     throws Exception
/*     */   {
/* 113 */     if (LOG.isDebugEnabled()) {
/* 114 */       LOG.debug("intercept '#0/#1' {", new String[] { invocation.getProxy().getNamespace(), invocation.getProxy().getActionName() });
/*     */     }
/*     */ 
/* 118 */     I18nInterceptor.LocaleFinder localeFinder = new CookieLocaleFinder(invocation);
/* 119 */     Locale locale = getLocaleFromParam(localeFinder.getRequestedLocale());
/* 120 */     locale = storeLocale(invocation, locale, localeFinder.getStorage());
/* 121 */     saveLocale(invocation, locale);
/*     */ 
/* 123 */     if (LOG.isDebugEnabled()) {
/* 124 */       LOG.debug("before Locale=#0", new Object[] { invocation.getStack().findValue("locale") });
/*     */     }
/*     */ 
/* 127 */     String result = invocation.invoke();
/*     */ 
/* 129 */     if (LOG.isDebugEnabled()) {
/* 130 */       LOG.debug("after Locale=#0", new Object[] { invocation.getStack().findValue("locale") });
/* 131 */       LOG.debug("intercept } ", new String[0]);
/*     */     }
/*     */ 
/* 134 */     return result;
/*     */   }
/*     */ 
/*     */   protected Locale storeLocale(ActionInvocation invocation, Locale locale, String storage)
/*     */   {
/* 139 */     if ("cookie".equals(storage)) {
/* 140 */       ActionContext ac = invocation.getInvocationContext();
/* 141 */       HttpServletResponse response = (HttpServletResponse)ac.get("com.opensymphony.xwork2.dispatcher.HttpServletResponse");
/*     */ 
/* 143 */       Cookie cookie = new Cookie("WW_TRANS_I18N_LOCALE", locale.toString());
/* 144 */       cookie.setMaxAge(1209600);
/* 145 */       response.addCookie(cookie);
/*     */ 
/* 147 */       storage = I18nInterceptor.Storage.SESSION.toString();
/*     */     }
/*     */ 
/* 150 */     return super.storeLocale(invocation, locale, storage);
/*     */   }
/*     */ 
/*     */   protected Locale readStoredLocale(ActionInvocation invocation, Map<String, Object> session)
/*     */   {
/* 155 */     Locale locale = readStoredLocalFromSession(invocation, session);
/*     */ 
/* 157 */     if (locale != null) {
/* 158 */       return locale;
/*     */     }
/*     */ 
/* 161 */     Cookie[] cookies = ServletActionContext.getRequest().getCookies();
/* 162 */     if (cookies != null) {
/* 163 */       for (Cookie cookie : cookies) {
/* 164 */         if ("WW_TRANS_I18N_LOCALE".equals(cookie.getName())) {
/* 165 */           return getLocaleFromParam(cookie.getValue());
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 170 */     return readStoredLocalFromCurrentInvocation(invocation);
/*     */   }
/*     */ 
/*     */   public void setRequestCookieParameterName(String requestCookieParameterName) {
/* 174 */     this.requestCookieParameterName = requestCookieParameterName;
/*     */   }
/*     */ 
/*     */   protected class CookieLocaleFinder extends I18nInterceptor.LocaleFinder
/*     */   {
/*     */     protected CookieLocaleFinder(ActionInvocation invocation)
/*     */     {
/*  82 */       super(invocation);
/*     */     }
/*     */ 
/*     */     protected void find()
/*     */     {
/*  88 */       Map params = this.actionInvocation.getInvocationContext().getParameters();
/*  89 */       this.storage = I18nInterceptor.Storage.SESSION.toString();
/*     */ 
/*  91 */       this.requestedLocale = I18nInterceptor.this.findLocaleParameter(params, I18nInterceptor.this.parameterName);
/*     */ 
/*  93 */       if (this.requestedLocale != null) {
/*  94 */         return;
/*     */       }
/*     */ 
/*  97 */       this.requestedLocale = I18nInterceptor.this.findLocaleParameter(params, I18nInterceptor.this.requestCookieParameterName);
/*  98 */       if (this.requestedLocale != null) {
/*  99 */         this.storage = "cookie";
/* 100 */         return;
/*     */       }
/*     */ 
/* 103 */       this.requestedLocale = I18nInterceptor.this.findLocaleParameter(params, I18nInterceptor.this.requestOnlyParameterName);
/* 104 */       if (this.requestedLocale != null)
/* 105 */         this.storage = I18nInterceptor.Storage.NONE.toString();
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.interceptor.I18nInterceptor
 * JD-Core Version:    0.6.0
 */