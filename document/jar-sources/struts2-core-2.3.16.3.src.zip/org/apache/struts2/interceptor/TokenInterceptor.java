/*     */ package org.apache.struts2.interceptor;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionInvocation;
/*     */ import com.opensymphony.xwork2.TextProvider;
/*     */ import com.opensymphony.xwork2.ValidationAware;
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import com.opensymphony.xwork2.interceptor.MethodFilterInterceptor;
/*     */ import com.opensymphony.xwork2.util.logging.Logger;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import org.apache.struts2.ServletActionContext;
/*     */ import org.apache.struts2.util.TokenHelper;
/*     */ 
/*     */ public class TokenInterceptor extends MethodFilterInterceptor
/*     */ {
/*     */   private static final long serialVersionUID = -6680894220590585506L;
/*     */   public static final String INVALID_TOKEN_CODE = "invalid.token";
/*     */   private static final String INVALID_TOKEN_MESSAGE_KEY = "struts.messages.invalid.token";
/*     */   private static final String DEFAULT_ERROR_MESSAGE = "The form has already been processed or no token was supplied, please try again.";
/*     */   private TextProvider textProvider;
/*     */ 
/*     */   @Inject
/*     */   public void setTextProvider(TextProvider textProvider)
/*     */   {
/* 131 */     this.textProvider = textProvider;
/*     */   }
/*     */ 
/*     */   protected String doIntercept(ActionInvocation invocation)
/*     */     throws Exception
/*     */   {
/* 139 */     if (this.log.isDebugEnabled()) {
/* 140 */       this.log.debug("Intercepting invocation to check for valid transaction token.", new String[0]);
/*     */     }
/* 142 */     return handleToken(invocation);
/*     */   }
/*     */ 
/*     */   protected String handleToken(ActionInvocation invocation)
/*     */     throws Exception
/*     */   {
/* 148 */     HttpSession session = ServletActionContext.getRequest().getSession(true);
/* 149 */     synchronized (session) {
/* 150 */       if (!TokenHelper.validToken()) {
/* 151 */         return handleInvalidToken(invocation);
/*     */       }
/*     */     }
/* 154 */     return handleValidToken(invocation);
/*     */   }
/*     */ 
/*     */   protected String handleInvalidToken(ActionInvocation invocation)
/*     */     throws Exception
/*     */   {
/* 165 */     Object action = invocation.getAction();
/* 166 */     String errorMessage = getErrorMessage(invocation);
/*     */ 
/* 168 */     if ((action instanceof ValidationAware))
/* 169 */       ((ValidationAware)action).addActionError(errorMessage);
/*     */     else {
/* 171 */       this.log.warn(errorMessage, new String[0]);
/*     */     }
/*     */ 
/* 174 */     return "invalid.token";
/*     */   }
/*     */ 
/*     */   protected String getErrorMessage(ActionInvocation invocation) {
/* 178 */     Object action = invocation.getAction();
/* 179 */     if ((action instanceof TextProvider)) {
/* 180 */       return ((TextProvider)action).getText("struts.messages.invalid.token", "The form has already been processed or no token was supplied, please try again.");
/*     */     }
/* 182 */     return this.textProvider.getText("struts.messages.invalid.token", "The form has already been processed or no token was supplied, please try again.");
/*     */   }
/*     */ 
/*     */   protected String handleValidToken(ActionInvocation invocation)
/*     */     throws Exception
/*     */   {
/* 193 */     return invocation.invoke();
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.interceptor.TokenInterceptor
 * JD-Core Version:    0.6.0
 */