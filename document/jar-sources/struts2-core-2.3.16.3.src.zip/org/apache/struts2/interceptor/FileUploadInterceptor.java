/*     */ package org.apache.struts2.interceptor;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionContext;
/*     */ import com.opensymphony.xwork2.ActionInvocation;
/*     */ import com.opensymphony.xwork2.ActionProxy;
/*     */ import com.opensymphony.xwork2.LocaleProvider;
/*     */ import com.opensymphony.xwork2.TextProvider;
/*     */ import com.opensymphony.xwork2.TextProviderFactory;
/*     */ import com.opensymphony.xwork2.ValidationAware;
/*     */ import com.opensymphony.xwork2.inject.Container;
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import com.opensymphony.xwork2.interceptor.AbstractInterceptor;
/*     */ import com.opensymphony.xwork2.util.PatternMatcher;
/*     */ import com.opensymphony.xwork2.util.TextParseUtil;
/*     */ import com.opensymphony.xwork2.util.logging.Logger;
/*     */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*     */ import java.io.File;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.apache.struts2.dispatcher.multipart.MultiPartRequestWrapper;
/*     */ 
/*     */ public class FileUploadInterceptor extends AbstractInterceptor
/*     */ {
/*     */   private static final long serialVersionUID = -4764627478894962478L;
/* 191 */   protected static final Logger LOG = LoggerFactory.getLogger(FileUploadInterceptor.class);
/*     */   protected Long maximumSize;
/* 194 */   protected Set<String> allowedTypesSet = Collections.emptySet();
/* 195 */   protected Set<String> allowedExtensionsSet = Collections.emptySet();
/*     */   private PatternMatcher matcher;
/*     */   private Container container;
/*     */ 
/*     */   @Inject
/*     */   public void setMatcher(PatternMatcher matcher)
/*     */   {
/* 202 */     this.matcher = matcher;
/*     */   }
/*     */   @Inject
/*     */   public void setContainer(Container container) {
/* 207 */     this.container = container;
/*     */   }
/*     */ 
/*     */   public void setAllowedExtensions(String allowedExtensions)
/*     */   {
/* 216 */     this.allowedExtensionsSet = TextParseUtil.commaDelimitedStringToSet(allowedExtensions);
/*     */   }
/*     */ 
/*     */   public void setAllowedTypes(String allowedTypes)
/*     */   {
/* 225 */     this.allowedTypesSet = TextParseUtil.commaDelimitedStringToSet(allowedTypes);
/*     */   }
/*     */ 
/*     */   public void setMaximumSize(Long maximumSize)
/*     */   {
/* 234 */     this.maximumSize = maximumSize;
/*     */   }
/*     */ 
/*     */   public String intercept(ActionInvocation invocation)
/*     */     throws Exception
/*     */   {
/* 242 */     ActionContext ac = invocation.getInvocationContext();
/*     */ 
/* 244 */     HttpServletRequest request = (HttpServletRequest)ac.get("com.opensymphony.xwork2.dispatcher.HttpServletRequest");
/*     */ 
/* 246 */     if (!(request instanceof MultiPartRequestWrapper)) {
/* 247 */       if (LOG.isDebugEnabled()) {
/* 248 */         ActionProxy proxy = invocation.getProxy();
/* 249 */         LOG.debug(getTextMessage("struts.messages.bypass.request", new String[] { proxy.getNamespace(), proxy.getActionName() }), new String[0]);
/*     */       }
/*     */ 
/* 252 */       return invocation.invoke();
/*     */     }
/*     */ 
/* 255 */     ValidationAware validation = null;
/*     */ 
/* 257 */     Object action = invocation.getAction();
/*     */ 
/* 259 */     if ((action instanceof ValidationAware)) {
/* 260 */       validation = (ValidationAware)action;
/*     */     }
/*     */ 
/* 263 */     MultiPartRequestWrapper multiWrapper = (MultiPartRequestWrapper)request;
/*     */ 
/* 265 */     if (multiWrapper.hasErrors()) {
/* 266 */       for (String error : multiWrapper.getErrors()) {
/* 267 */         if (validation != null) {
/* 268 */           validation.addActionError(error);
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 274 */     Enumeration fileParameterNames = multiWrapper.getFileParameterNames();
/* 275 */     while ((fileParameterNames != null) && (fileParameterNames.hasMoreElements()))
/*     */     {
/* 277 */       String inputName = (String)fileParameterNames.nextElement();
/*     */ 
/* 280 */       String[] contentType = multiWrapper.getContentTypes(inputName);
/*     */ 
/* 282 */       if (isNonEmpty(contentType))
/*     */       {
/* 284 */         String[] fileName = multiWrapper.getFileNames(inputName);
/*     */ 
/* 286 */         if (isNonEmpty(fileName))
/*     */         {
/* 288 */           File[] files = multiWrapper.getFiles(inputName);
/* 289 */           if ((files != null) && (files.length > 0)) {
/* 290 */             List acceptedFiles = new ArrayList(files.length);
/* 291 */             List acceptedContentTypes = new ArrayList(files.length);
/* 292 */             List acceptedFileNames = new ArrayList(files.length);
/* 293 */             String contentTypeName = inputName + "ContentType";
/* 294 */             String fileNameName = inputName + "FileName";
/*     */ 
/* 296 */             for (int index = 0; index < files.length; index++) {
/* 297 */               if (acceptFile(action, files[index], fileName[index], contentType[index], inputName, validation)) {
/* 298 */                 acceptedFiles.add(files[index]);
/* 299 */                 acceptedContentTypes.add(contentType[index]);
/* 300 */                 acceptedFileNames.add(fileName[index]);
/*     */               }
/*     */             }
/*     */ 
/* 304 */             if (!acceptedFiles.isEmpty()) {
/* 305 */               Map params = ac.getParameters();
/*     */ 
/* 307 */               params.put(inputName, acceptedFiles.toArray(new File[acceptedFiles.size()]));
/* 308 */               params.put(contentTypeName, acceptedContentTypes.toArray(new String[acceptedContentTypes.size()]));
/* 309 */               params.put(fileNameName, acceptedFileNames.toArray(new String[acceptedFileNames.size()]));
/*     */             }
/*     */           }
/*     */         }
/* 313 */         else if (LOG.isWarnEnabled()) {
/* 314 */           LOG.warn(getTextMessage(action, "struts.messages.invalid.file", new String[] { inputName }), new String[0]);
/*     */         }
/*     */ 
/*     */       }
/* 318 */       else if (LOG.isWarnEnabled()) {
/* 319 */         LOG.warn(getTextMessage(action, "struts.messages.invalid.content.type", new String[] { inputName }), new String[0]);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 325 */     return invocation.invoke();
/*     */   }
/*     */ 
/*     */   protected boolean acceptFile(Object action, File file, String filename, String contentType, String inputName, ValidationAware validation)
/*     */   {
/* 340 */     boolean fileIsAcceptable = false;
/*     */ 
/* 343 */     if (file == null) {
/* 344 */       String errMsg = getTextMessage(action, "struts.messages.error.uploading", new String[] { inputName });
/* 345 */       if (validation != null) {
/* 346 */         validation.addFieldError(inputName, errMsg);
/*     */       }
/*     */ 
/* 349 */       if (LOG.isWarnEnabled())
/* 350 */         LOG.warn(errMsg, new String[0]);
/*     */     }
/* 352 */     else if ((this.maximumSize != null) && (this.maximumSize.longValue() < file.length())) {
/* 353 */       String errMsg = getTextMessage(action, "struts.messages.error.file.too.large", new String[] { inputName, filename, file.getName(), "" + file.length() });
/* 354 */       if (validation != null) {
/* 355 */         validation.addFieldError(inputName, errMsg);
/*     */       }
/*     */ 
/* 358 */       if (LOG.isWarnEnabled())
/* 359 */         LOG.warn(errMsg, new String[0]);
/*     */     }
/* 361 */     else if ((!this.allowedTypesSet.isEmpty()) && (!containsItem(this.allowedTypesSet, contentType))) {
/* 362 */       String errMsg = getTextMessage(action, "struts.messages.error.content.type.not.allowed", new String[] { inputName, filename, file.getName(), contentType });
/* 363 */       if (validation != null) {
/* 364 */         validation.addFieldError(inputName, errMsg);
/*     */       }
/*     */ 
/* 367 */       if (LOG.isWarnEnabled())
/* 368 */         LOG.warn(errMsg, new String[0]);
/*     */     }
/* 370 */     else if ((!this.allowedExtensionsSet.isEmpty()) && (!hasAllowedExtension(this.allowedExtensionsSet, filename))) {
/* 371 */       String errMsg = getTextMessage(action, "struts.messages.error.file.extension.not.allowed", new String[] { inputName, filename, file.getName(), contentType });
/* 372 */       if (validation != null) {
/* 373 */         validation.addFieldError(inputName, errMsg);
/*     */       }
/*     */ 
/* 376 */       if (LOG.isWarnEnabled())
/* 377 */         LOG.warn(errMsg, new String[0]);
/*     */     }
/*     */     else {
/* 380 */       fileIsAcceptable = true;
/*     */     }
/*     */ 
/* 383 */     return fileIsAcceptable;
/*     */   }
/*     */ 
/*     */   private boolean hasAllowedExtension(Collection<String> extensionCollection, String filename)
/*     */   {
/* 392 */     if (filename == null) {
/* 393 */       return false;
/*     */     }
/*     */ 
/* 396 */     String lowercaseFilename = filename.toLowerCase();
/* 397 */     for (String extension : extensionCollection) {
/* 398 */       if (lowercaseFilename.endsWith(extension)) {
/* 399 */         return true;
/*     */       }
/*     */     }
/*     */ 
/* 403 */     return false;
/*     */   }
/*     */ 
/*     */   private boolean containsItem(Collection<String> itemCollection, String item)
/*     */   {
/* 412 */     for (String pattern : itemCollection)
/* 413 */       if (matchesWildcard(pattern, item))
/* 414 */         return true;
/* 415 */     return false;
/*     */   }
/*     */ 
/*     */   private boolean matchesWildcard(String pattern, String text) {
/* 419 */     Object o = this.matcher.compilePattern(pattern);
/* 420 */     return this.matcher.match(new HashMap(), text, o);
/*     */   }
/*     */ 
/*     */   private boolean isNonEmpty(Object[] objArray) {
/* 424 */     boolean result = false;
/* 425 */     for (int index = 0; (index < objArray.length) && (!result); index++) {
/* 426 */       if (objArray[index] != null) {
/* 427 */         result = true;
/*     */       }
/*     */     }
/* 430 */     return result;
/*     */   }
/*     */ 
/*     */   protected String getTextMessage(String messageKey, String[] args) {
/* 434 */     return getTextMessage(this, messageKey, args);
/*     */   }
/*     */ 
/*     */   protected String getTextMessage(Object action, String messageKey, String[] args) {
/* 438 */     if ((action instanceof TextProvider)) {
/* 439 */       return ((TextProvider)action).getText(messageKey, args);
/*     */     }
/* 441 */     return getTextProvider(action).getText(messageKey, args);
/*     */   }
/*     */ 
/*     */   private TextProvider getTextProvider(Object action) {
/* 445 */     TextProviderFactory tpf = new TextProviderFactory();
/* 446 */     if (this.container != null) {
/* 447 */       this.container.inject(tpf);
/*     */     }
/* 449 */     LocaleProvider localeProvider = getLocaleProvider(action);
/* 450 */     return tpf.createInstance(action.getClass(), localeProvider);
/*     */   }
/*     */ 
/*     */   private LocaleProvider getLocaleProvider(Object action)
/*     */   {
/*     */     LocaleProvider localeProvider;
/*     */     LocaleProvider localeProvider;
/* 455 */     if ((action instanceof LocaleProvider))
/* 456 */       localeProvider = (LocaleProvider)action;
/*     */     else {
/* 458 */       localeProvider = (LocaleProvider)this.container.getInstance(LocaleProvider.class);
/*     */     }
/* 460 */     return localeProvider;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.interceptor.FileUploadInterceptor
 * JD-Core Version:    0.6.0
 */