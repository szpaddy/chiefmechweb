/*     */ package org.apache.struts2.interceptor;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionContext;
/*     */ import com.opensymphony.xwork2.ActionInvocation;
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import com.opensymphony.xwork2.interceptor.AbstractInterceptor;
/*     */ import com.opensymphony.xwork2.util.profiling.UtilTimerStack;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class ProfilingActivationInterceptor extends AbstractInterceptor
/*     */ {
/*  71 */   private String profilingKey = "profiling";
/*     */   private boolean devMode;
/*     */ 
/*     */   public String getProfilingKey()
/*     */   {
/*  78 */     return this.profilingKey;
/*     */   }
/*     */ 
/*     */   public void setProfilingKey(String profilingKey)
/*     */   {
/*  85 */     this.profilingKey = profilingKey;
/*     */   }
/*     */   @Inject("struts.devMode")
/*     */   public void setDevMode(String mode) {
/*  90 */     this.devMode = "true".equals(mode);
/*     */   }
/*     */ 
/*     */   public String intercept(ActionInvocation invocation) throws Exception
/*     */   {
/*  95 */     if (this.devMode) {
/*  96 */       Object val = invocation.getInvocationContext().getParameters().get(this.profilingKey);
/*  97 */       if (val != null) {
/*  98 */         String sval = (val instanceof String) ? (String)val : ((String[])(String[])val)[0];
/*  99 */         boolean enable = ("yes".equalsIgnoreCase(sval)) || ("true".equalsIgnoreCase(sval));
/* 100 */         UtilTimerStack.setActive(enable);
/* 101 */         invocation.getInvocationContext().getParameters().remove(this.profilingKey);
/*     */       }
/*     */     }
/* 104 */     return invocation.invoke();
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.interceptor.ProfilingActivationInterceptor
 * JD-Core Version:    0.6.0
 */