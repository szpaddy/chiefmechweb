/*     */ package org.apache.struts2.interceptor;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionContext;
/*     */ import com.opensymphony.xwork2.ActionInvocation;
/*     */ import com.opensymphony.xwork2.ExcludedPatterns;
/*     */ import com.opensymphony.xwork2.interceptor.AbstractInterceptor;
/*     */ import com.opensymphony.xwork2.util.TextParseUtil;
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import com.opensymphony.xwork2.util.logging.Logger;
/*     */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import javax.servlet.http.Cookie;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.apache.struts2.ServletActionContext;
/*     */ 
/*     */ public class CookieInterceptor extends AbstractInterceptor
/*     */ {
/*     */   private static final long serialVersionUID = 4153142432948747305L;
/* 170 */   private static final Logger LOG = LoggerFactory.getLogger(CookieInterceptor.class);
/*     */   private static final String ACCEPTED_PATTERN = "[a-zA-Z0-9\\.\\]\\[_'\\s]+";
/* 174 */   private Set<String> cookiesNameSet = Collections.emptySet();
/* 175 */   private Set<String> cookiesValueSet = Collections.emptySet();
/*     */ 
/* 178 */   private Pattern acceptedPattern = Pattern.compile("[a-zA-Z0-9\\.\\]\\[_'\\s]+", 2);
/* 179 */   private Set<Pattern> excludedPatterns = new HashSet();
/*     */ 
/*     */   public CookieInterceptor() {
/* 182 */     for (String pattern : ExcludedPatterns.EXCLUDED_PATTERNS)
/* 183 */       this.excludedPatterns.add(Pattern.compile(pattern, 2));
/*     */   }
/*     */ 
/*     */   public void setCookiesName(String cookiesName)
/*     */   {
/* 194 */     if (cookiesName != null)
/* 195 */       this.cookiesNameSet = TextParseUtil.commaDelimitedStringToSet(cookiesName);
/*     */   }
/*     */ 
/*     */   public void setCookiesValue(String cookiesValue)
/*     */   {
/* 206 */     if (cookiesValue != null)
/* 207 */       this.cookiesValueSet = TextParseUtil.commaDelimitedStringToSet(cookiesValue);
/*     */   }
/*     */ 
/*     */   public void setAcceptCookieNames(String pattern)
/*     */   {
/* 216 */     this.acceptedPattern = Pattern.compile(pattern);
/*     */   }
/*     */ 
/*     */   public String intercept(ActionInvocation invocation) throws Exception {
/* 220 */     if (LOG.isDebugEnabled()) {
/* 221 */       LOG.debug("start interception", new String[0]);
/*     */     }
/*     */ 
/* 225 */     Map cookiesMap = new LinkedHashMap();
/*     */ 
/* 227 */     Cookie[] cookies = ServletActionContext.getRequest().getCookies();
/* 228 */     if (cookies != null) {
/* 229 */       ValueStack stack = ActionContext.getContext().getValueStack();
/*     */ 
/* 231 */       for (Cookie cookie : cookies) {
/* 232 */         String name = cookie.getName();
/* 233 */         String value = cookie.getValue();
/*     */ 
/* 235 */         if ((isAcceptableName(name)) && (isAcceptableValue(value))) {
/* 236 */           if (this.cookiesNameSet.contains("*")) {
/* 237 */             if (LOG.isDebugEnabled()) {
/* 238 */               LOG.debug("contains cookie name [*] in configured cookies name set, cookie with name [" + name + "] with value [" + value + "] will be injected", new String[0]);
/*     */             }
/* 240 */             populateCookieValueIntoStack(name, value, cookiesMap, stack);
/* 241 */           } else if (this.cookiesNameSet.contains(cookie.getName())) {
/* 242 */             populateCookieValueIntoStack(name, value, cookiesMap, stack);
/*     */           }
/*     */         }
/* 245 */         else LOG.warn("Cookie name [#0] with value [#1] was rejected!", new String[] { name, value });
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 251 */     injectIntoCookiesAwareAction(invocation.getAction(), cookiesMap);
/*     */ 
/* 253 */     return invocation.invoke();
/*     */   }
/*     */ 
/*     */   protected boolean isAcceptableValue(String value)
/*     */   {
/* 263 */     for (Pattern excludedPattern : this.excludedPatterns) {
/* 264 */       boolean matches = !excludedPattern.matcher(value).matches();
/* 265 */       if (!matches) {
/* 266 */         if (LOG.isTraceEnabled()) {
/* 267 */           LOG.trace("Cookie value [#0] matches excludedPattern [#1]", new String[] { value, excludedPattern.toString() });
/*     */         }
/* 269 */         return false;
/*     */       }
/*     */     }
/* 272 */     return true;
/*     */   }
/*     */ 
/*     */   protected boolean isAcceptableName(String name)
/*     */   {
/* 282 */     return (!isExcluded(name)) && (isAccepted(name));
/*     */   }
/*     */ 
/*     */   protected boolean isAccepted(String name)
/*     */   {
/* 292 */     boolean matches = this.acceptedPattern.matcher(name).matches();
/* 293 */     if (matches) {
/* 294 */       if (LOG.isTraceEnabled()) {
/* 295 */         LOG.trace("Cookie [#0] matches acceptedPattern [#1]", new String[] { name, "[a-zA-Z0-9\\.\\]\\[_'\\s]+" });
/*     */       }
/*     */     }
/* 298 */     else if (LOG.isTraceEnabled()) {
/* 299 */       LOG.trace("Cookie [#0] doesn't match acceptedPattern [#1]", new String[] { name, "[a-zA-Z0-9\\.\\]\\[_'\\s]+" });
/*     */     }
/*     */ 
/* 302 */     return matches;
/*     */   }
/*     */ 
/*     */   protected boolean isExcluded(String name)
/*     */   {
/* 312 */     for (Pattern excludedPattern : this.excludedPatterns) {
/* 313 */       boolean matches = excludedPattern.matcher(name).matches();
/* 314 */       if (matches) {
/* 315 */         if (LOG.isTraceEnabled()) {
/* 316 */           LOG.trace("Cookie [#0] matches excludedPattern [#1]", new String[] { name, excludedPattern.toString() });
/*     */         }
/* 318 */         return true;
/*     */       }
/* 320 */       if (LOG.isTraceEnabled()) {
/* 321 */         LOG.trace("Cookie [#0] doesn't match excludedPattern [#1]", new String[] { name, excludedPattern.toString() });
/*     */       }
/*     */     }
/*     */ 
/* 325 */     return false;
/*     */   }
/*     */ 
/*     */   protected void populateCookieValueIntoStack(String cookieName, String cookieValue, Map<String, String> cookiesMap, ValueStack stack)
/*     */   {
/* 338 */     if ((this.cookiesValueSet.isEmpty()) || (this.cookiesValueSet.contains("*")))
/*     */     {
/* 343 */       if (LOG.isDebugEnabled()) {
/* 344 */         if (this.cookiesValueSet.isEmpty())
/* 345 */           LOG.debug("no cookie value is configured, cookie with name [" + cookieName + "] with value [" + cookieValue + "] will be injected", new String[0]);
/* 346 */         else if (this.cookiesValueSet.contains("*"))
/* 347 */           LOG.debug("interceptor is configured to accept any value, cookie with name [" + cookieName + "] with value [" + cookieValue + "] will be injected", new String[0]);
/*     */       }
/* 349 */       cookiesMap.put(cookieName, cookieValue);
/* 350 */       stack.setValue(cookieName, cookieValue);
/*     */     }
/* 355 */     else if (this.cookiesValueSet.contains(cookieValue)) {
/* 356 */       if (LOG.isDebugEnabled()) {
/* 357 */         LOG.debug("both configured cookie name and value matched, cookie [" + cookieName + "] with value [" + cookieValue + "] will be injected", new String[0]);
/*     */       }
/*     */ 
/* 360 */       cookiesMap.put(cookieName, cookieValue);
/* 361 */       stack.setValue(cookieName, cookieValue);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void injectIntoCookiesAwareAction(Object action, Map<String, String> cookiesMap)
/*     */   {
/* 374 */     if ((action instanceof CookiesAware)) {
/* 375 */       if (LOG.isDebugEnabled()) {
/* 376 */         LOG.debug("action [" + action + "] implements CookiesAware, injecting cookies map [" + cookiesMap + "]", new String[0]);
/*     */       }
/* 378 */       ((CookiesAware)action).setCookiesMap(cookiesMap);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.interceptor.CookieInterceptor
 * JD-Core Version:    0.6.0
 */