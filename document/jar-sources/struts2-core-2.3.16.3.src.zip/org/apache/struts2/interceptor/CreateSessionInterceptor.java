/*     */ package org.apache.struts2.interceptor;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionContext;
/*     */ import com.opensymphony.xwork2.ActionInvocation;
/*     */ import com.opensymphony.xwork2.interceptor.AbstractInterceptor;
/*     */ import com.opensymphony.xwork2.util.logging.Logger;
/*     */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import org.apache.struts2.ServletActionContext;
/*     */ import org.apache.struts2.dispatcher.SessionMap;
/*     */ 
/*     */ public class CreateSessionInterceptor extends AbstractInterceptor
/*     */ {
/*     */   private static final long serialVersionUID = -4590322556118858869L;
/*  86 */   private static final Logger LOG = LoggerFactory.getLogger(CreateSessionInterceptor.class);
/*     */ 
/*     */   public String intercept(ActionInvocation invocation)
/*     */     throws Exception
/*     */   {
/*  93 */     HttpSession httpSession = ServletActionContext.getRequest().getSession(false);
/*  94 */     if (httpSession == null) {
/*  95 */       if (LOG.isDebugEnabled()) {
/*  96 */         LOG.debug("Creating new HttpSession and new SessionMap in ServletActionContext", new String[0]);
/*     */       }
/*  98 */       ServletActionContext.getRequest().getSession(true);
/*  99 */       ServletActionContext.getContext().setSession(new SessionMap(ServletActionContext.getRequest()));
/*     */     }
/* 101 */     return invocation.invoke();
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.interceptor.CreateSessionInterceptor
 * JD-Core Version:    0.6.0
 */