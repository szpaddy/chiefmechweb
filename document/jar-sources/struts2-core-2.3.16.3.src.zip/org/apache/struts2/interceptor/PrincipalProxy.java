package org.apache.struts2.interceptor;

import java.security.Principal;
import javax.servlet.http.HttpServletRequest;

public abstract interface PrincipalProxy
{
  public abstract boolean isUserInRole(String paramString);

  public abstract Principal getUserPrincipal();

  public abstract String getRemoteUser();

  public abstract boolean isRequestSecure();

  /** @deprecated */
  public abstract HttpServletRequest getRequest();
}

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.interceptor.PrincipalProxy
 * JD-Core Version:    0.6.0
 */