/*    */ package org.apache.struts2.interceptor;
/*    */ 
/*    */ import com.opensymphony.xwork2.ActionContext;
/*    */ import com.opensymphony.xwork2.ActionInvocation;
/*    */ import com.opensymphony.xwork2.interceptor.AbstractInterceptor;
/*    */ import java.util.HashMap;
/*    */ import java.util.Iterator;
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ 
/*    */ public class MultiselectInterceptor extends AbstractInterceptor
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public String intercept(ActionInvocation actionInvocation)
/*    */     throws Exception
/*    */   {
/* 50 */     Map parameters = actionInvocation.getInvocationContext().getParameters();
/* 51 */     Map newParams = new HashMap();
/* 52 */     Set keys = parameters.keySet();
/*    */ 
/* 54 */     for (Iterator iterator = keys.iterator(); iterator.hasNext(); ) {
/* 55 */       String key = (String)iterator.next();
/*    */ 
/* 57 */       if (key.startsWith("__multiselect_")) {
/* 58 */         String name = key.substring("__multiselect_".length());
/*    */ 
/* 60 */         iterator.remove();
/*    */ 
/* 63 */         if (!parameters.containsKey(name))
/*    */         {
/* 66 */           newParams.put(name, new String[0]);
/*    */         }
/*    */       }
/*    */     }
/*    */ 
/* 71 */     parameters.putAll(newParams);
/*    */ 
/* 73 */     return actionInvocation.invoke();
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.interceptor.MultiselectInterceptor
 * JD-Core Version:    0.6.0
 */