/*     */ package org.apache.struts2.interceptor;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionInvocation;
/*     */ import com.opensymphony.xwork2.XWorkConstants;
/*     */ import com.opensymphony.xwork2.inject.Container;
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import com.opensymphony.xwork2.interceptor.AbstractInterceptor;
/*     */ import com.opensymphony.xwork2.util.logging.Logger;
/*     */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*     */ import java.lang.reflect.Field;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import org.apache.struts2.StrutsConstants;
/*     */ 
/*     */ public class DeprecationInterceptor extends AbstractInterceptor
/*     */ {
/*  28 */   private static final Logger LOG = LoggerFactory.getLogger(DeprecationInterceptor.class);
/*     */   private Container container;
/*     */   private boolean devMode;
/*     */ 
/*     */   public String intercept(ActionInvocation invocation)
/*     */     throws Exception
/*     */   {
/*  35 */     if (this.devMode) {
/*  36 */       String message = validate();
/*  37 */       if (message != null) {
/*  38 */         LOG.debug(message, new String[0]);
/*     */       }
/*     */     }
/*  41 */     return invocation.invoke();
/*     */   }
/*     */ 
/*     */   private String validate()
/*     */     throws Exception
/*     */   {
/*  50 */     Set constants = new HashSet();
/*     */ 
/*  52 */     readConstants(constants, StrutsConstants.class);
/*  53 */     readConstants(constants, XWorkConstants.class);
/*     */ 
/*  55 */     Set applicationConstants = this.container.getInstanceNames(String.class);
/*  56 */     String message = null;
/*  57 */     if (!constants.containsAll(applicationConstants)) {
/*  58 */       Set deprecated = new HashSet(applicationConstants);
/*  59 */       deprecated.removeAll(constants);
/*  60 */       message = prepareMessage(deprecated);
/*     */     }
/*  62 */     return message;
/*     */   }
/*     */ 
/*     */   private void readConstants(Set<String> constants, Class clazz) throws IllegalAccessException {
/*  66 */     for (Field field : clazz.getDeclaredFields())
/*  67 */       if (String.class.equals(field.getType()))
/*  68 */         constants.add((String)field.get(clazz));
/*     */   }
/*     */ 
/*     */   private String prepareMessage(Set<String> deprecated)
/*     */   {
/*  79 */     StringBuilder sb = new StringBuilder("\n");
/*  80 */     sb.append("*******************************************************************************\n");
/*  81 */     sb.append("**                                                                           **\n");
/*  82 */     sb.append("**                               WARNING                                     **\n");
/*  83 */     sb.append("**                YOU USE DEPRECATED / UNKNOWN CONSTANTS                     **\n");
/*  84 */     sb.append("**                                                                           **\n");
/*     */ 
/*  86 */     for (String dep : deprecated) {
/*  87 */       sb.append(String.format("**  -> %-69s **\n", new Object[] { dep }));
/*     */     }
/*     */ 
/*  90 */     sb.append("*******************************************************************************\n");
/*     */ 
/*  92 */     return sb.toString();
/*     */   }
/*     */   @Inject("struts.devMode")
/*     */   public void setDevMode(String state) {
/*  97 */     this.devMode = "true".equals(state);
/*     */   }
/*     */   @Inject
/*     */   public void setContainer(Container container) {
/* 102 */     this.container = container;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.interceptor.DeprecationInterceptor
 * JD-Core Version:    0.6.0
 */