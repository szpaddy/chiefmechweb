/*     */ package org.apache.struts2.interceptor;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionContext;
/*     */ import com.opensymphony.xwork2.interceptor.ParametersInterceptor;
/*     */ import java.util.Collections;
/*     */ import java.util.Map;
/*     */ import java.util.TreeMap;
/*     */ import org.apache.struts2.dispatcher.mapper.ActionMapping;
/*     */ 
/*     */ public class ActionMappingParametersInteceptor extends ParametersInterceptor
/*     */ {
/*     */   protected Map<String, Object> retrieveParameters(ActionContext ac)
/*     */   {
/*  83 */     ActionMapping mapping = (ActionMapping)ac.get("struts.actionMapping");
/*  84 */     if (mapping != null) {
/*  85 */       return mapping.getParams();
/*     */     }
/*  87 */     return Collections.emptyMap();
/*     */   }
/*     */ 
/*     */   protected void addParametersToContext(ActionContext ac, Map newParams)
/*     */   {
/* 102 */     Map previousParams = ac.getParameters();
/* 103 */     Map combinedParams = null;
/* 104 */     if (previousParams != null)
/* 105 */       combinedParams = new TreeMap(previousParams);
/*     */     else {
/* 107 */       combinedParams = new TreeMap();
/*     */     }
/* 109 */     combinedParams.putAll(newParams);
/*     */ 
/* 111 */     ac.setParameters(combinedParams);
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.interceptor.ActionMappingParametersInteceptor
 * JD-Core Version:    0.6.0
 */