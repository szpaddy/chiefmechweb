package org.apache.struts2.interceptor;

import java.util.Set;
import javax.servlet.http.Cookie;

public abstract interface CookieProvider
{
  public abstract Set<Cookie> getCookies();
}

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.interceptor.CookieProvider
 * JD-Core Version:    0.6.0
 */