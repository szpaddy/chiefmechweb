/*     */ package org.apache.struts2.views.freemarker;
/*     */ 
/*     */ import com.opensymphony.xwork2.FileManager;
/*     */ import com.opensymphony.xwork2.FileManagerFactory;
/*     */ import com.opensymphony.xwork2.inject.Container;
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import com.opensymphony.xwork2.util.ClassLoaderUtil;
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import com.opensymphony.xwork2.util.logging.Logger;
/*     */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*     */ import freemarker.cache.ClassTemplateLoader;
/*     */ import freemarker.cache.FileTemplateLoader;
/*     */ import freemarker.cache.MultiTemplateLoader;
/*     */ import freemarker.cache.TemplateLoader;
/*     */ import freemarker.cache.WebappTemplateLoader;
/*     */ import freemarker.ext.jsp.TaglibFactory;
/*     */ import freemarker.ext.servlet.HttpRequestHashModel;
/*     */ import freemarker.ext.servlet.HttpRequestParametersHashModel;
/*     */ import freemarker.ext.servlet.HttpSessionHashModel;
/*     */ import freemarker.ext.servlet.ServletContextHashModel;
/*     */ import freemarker.template.Configuration;
/*     */ import freemarker.template.ObjectWrapper;
/*     */ import freemarker.template.TemplateException;
/*     */ import freemarker.template.TemplateExceptionHandler;
/*     */ import freemarker.template.TemplateModel;
/*     */ import freemarker.template.utility.StringUtil;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Collections;
/*     */ import java.util.GregorianCalendar;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import javax.servlet.GenericServlet;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import org.apache.struts2.views.JspSupportServlet;
/*     */ import org.apache.struts2.views.TagLibraryModelProvider;
/*     */ import org.apache.struts2.views.util.ContextUtil;
/*     */ 
/*     */ public class FreemarkerManager
/*     */ {
/*     */   public static final String INITPARAM_TEMPLATE_PATH = "TemplatePath";
/*     */   public static final String INITPARAM_NOCACHE = "NoCache";
/*     */   public static final String INITPARAM_CONTENT_TYPE = "ContentType";
/*     */   public static final String DEFAULT_CONTENT_TYPE = "text/html";
/*     */   public static final String INITPARAM_DEBUG = "Debug";
/*     */   public static final String KEY_REQUEST = "Request";
/*     */   public static final String KEY_INCLUDE = "include_page";
/*     */   public static final String KEY_REQUEST_PRIVATE = "__FreeMarkerServlet.Request__";
/*     */   public static final String KEY_REQUEST_PARAMETERS = "RequestParameters";
/*     */   public static final String KEY_SESSION = "Session";
/*     */   public static final String KEY_APPLICATION = "Application";
/*     */   public static final String KEY_APPLICATION_PRIVATE = "__FreeMarkerServlet.Application__";
/*     */   public static final String KEY_JSP_TAGLIBS = "JspTaglibs";
/*     */   private static final String ATTR_REQUEST_MODEL = ".freemarker.Request";
/*     */   private static final String ATTR_REQUEST_PARAMETERS_MODEL = ".freemarker.RequestParameters";
/*     */   private static final String ATTR_APPLICATION_MODEL = ".freemarker.Application";
/*     */   private static final String ATTR_JSP_TAGLIBS_MODEL = ".freemarker.JspTaglibs";
/*     */   public static final String ATTR_TEMPLATE_MODEL = ".freemarker.TemplateModel";
/*     */   public static final String KEY_REQUEST_PARAMETERS_STRUTS = "Parameters";
/*     */   public static final String KEY_HASHMODEL_PRIVATE = "__FreeMarkerManager.Request__";
/*     */   public static final String EXPIRATION_DATE;
/* 145 */   boolean contentTypeEvaluated = false;
/*     */   private static final Logger LOG;
/*     */   public static final String CONFIG_SERVLET_CONTEXT_KEY = "freemarker.Configuration";
/*     */   public static final String KEY_EXCEPTION = "exception";
/*     */   protected String templatePath;
/*     */   protected boolean nocache;
/*     */   protected boolean debug;
/*     */   protected Configuration config;
/*     */   protected ObjectWrapper wrapper;
/* 171 */   protected String contentType = null;
/* 172 */   protected boolean noCharsetInContentType = true;
/*     */   protected String encoding;
/*     */   protected boolean altMapWrapper;
/*     */   protected boolean cacheBeanWrapper;
/*     */   protected int mruMaxStrongSize;
/*     */   protected String templateUpdateDelay;
/*     */   protected Map<String, TagLibraryModelProvider> tagLibraries;
/*     */   private FileManager fileManager;
/*     */   private FreemarkerThemeTemplateLoader themeTemplateLoader;
/*     */ 
/*     */   @Inject("struts.i18n.encoding")
/*     */   public void setEncoding(String encoding)
/*     */   {
/* 186 */     this.encoding = encoding;
/*     */   }
/*     */   @Inject("struts.freemarker.wrapper.altMap")
/*     */   public void setWrapperAltMap(String val) {
/* 191 */     this.altMapWrapper = "true".equals(val);
/*     */   }
/*     */   @Inject("struts.freemarker.beanwrapperCache")
/*     */   public void setCacheBeanWrapper(String val) {
/* 196 */     this.cacheBeanWrapper = "true".equals(val);
/*     */   }
/*     */   @Inject("struts.freemarker.mru.max.strong.size")
/*     */   public void setMruMaxStrongSize(String size) {
/* 201 */     this.mruMaxStrongSize = Integer.parseInt(size);
/*     */   }
/*     */   @Inject(value="struts.freemarker.templatesCache.updateDelay", required=false)
/*     */   public void setTemplateUpdateDelay(String delay) {
/* 206 */     this.templateUpdateDelay = delay;
/*     */   }
/*     */   @Inject
/*     */   public void setContainer(Container container) {
/* 211 */     Map map = new HashMap();
/* 212 */     Set prefixes = container.getInstanceNames(TagLibraryModelProvider.class);
/* 213 */     for (String prefix : prefixes) {
/* 214 */       map.put(prefix, container.getInstance(TagLibraryModelProvider.class, prefix));
/*     */     }
/* 216 */     this.tagLibraries = Collections.unmodifiableMap(map);
/*     */   }
/*     */   @Inject
/*     */   public void setFileManagerFactory(FileManagerFactory fileManagerFactory) {
/* 221 */     this.fileManager = fileManagerFactory.getFileManager();
/*     */   }
/*     */   @Inject
/*     */   public void setThemeTemplateLoader(FreemarkerThemeTemplateLoader themeTemplateLoader) {
/* 226 */     this.themeTemplateLoader = themeTemplateLoader;
/*     */   }
/*     */ 
/*     */   public boolean getNoCharsetInContentType() {
/* 230 */     return this.noCharsetInContentType;
/*     */   }
/*     */ 
/*     */   public String getTemplatePath() {
/* 234 */     return this.templatePath;
/*     */   }
/*     */ 
/*     */   public boolean getNocache() {
/* 238 */     return this.nocache;
/*     */   }
/*     */ 
/*     */   public boolean getDebug() {
/* 242 */     return this.debug;
/*     */   }
/*     */ 
/*     */   public Configuration getConfig() {
/* 246 */     return this.config;
/*     */   }
/*     */ 
/*     */   public ObjectWrapper getWrapper() {
/* 250 */     return this.wrapper;
/*     */   }
/*     */ 
/*     */   public String getContentType() {
/* 254 */     return this.contentType;
/*     */   }
/*     */ 
/*     */   public synchronized Configuration getConfiguration(ServletContext servletContext) {
/* 258 */     if (this.config == null) {
/*     */       try {
/* 260 */         init(servletContext);
/*     */       } catch (TemplateException e) {
/* 262 */         if (LOG.isErrorEnabled()) {
/* 263 */           LOG.error("Cannot load freemarker configuration: ", e, new String[0]);
/*     */         }
/*     */       }
/*     */ 
/* 267 */       servletContext.setAttribute("freemarker.Configuration", this.config);
/*     */     }
/* 269 */     return this.config;
/*     */   }
/*     */ 
/*     */   public void init(ServletContext servletContext) throws TemplateException {
/* 273 */     this.config = createConfiguration(servletContext);
/*     */ 
/* 276 */     this.config.setTemplateExceptionHandler(TemplateExceptionHandler.HTML_DEBUG_HANDLER);
/* 277 */     this.contentType = "text/html";
/*     */ 
/* 280 */     this.wrapper = createObjectWrapper(servletContext);
/* 281 */     if (LOG.isDebugEnabled()) {
/* 282 */       LOG.debug("Using object wrapper of class " + this.wrapper.getClass().getName(), new String[0]);
/*     */     }
/* 284 */     this.config.setObjectWrapper(this.wrapper);
/*     */ 
/* 287 */     this.templatePath = servletContext.getInitParameter("TemplatePath");
/* 288 */     if (this.templatePath == null) {
/* 289 */       this.templatePath = servletContext.getInitParameter("templatePath");
/*     */     }
/*     */ 
/* 292 */     configureTemplateLoader(createTemplateLoader(servletContext, this.templatePath));
/*     */ 
/* 294 */     loadSettings(servletContext);
/*     */   }
/*     */ 
/*     */   protected void configureTemplateLoader(TemplateLoader templateLoader)
/*     */   {
/* 304 */     this.themeTemplateLoader.init(templateLoader);
/* 305 */     this.config.setTemplateLoader(this.themeTemplateLoader);
/*     */   }
/*     */ 
/*     */   protected Configuration createConfiguration(ServletContext servletContext)
/*     */     throws TemplateException
/*     */   {
/* 322 */     Configuration configuration = new Configuration();
/*     */ 
/* 324 */     configuration.setTemplateExceptionHandler(TemplateExceptionHandler.HTML_DEBUG_HANDLER);
/*     */ 
/* 326 */     if (this.mruMaxStrongSize > 0) {
/* 327 */       configuration.setSetting("cache_storage", "strong:" + this.mruMaxStrongSize);
/*     */     }
/* 329 */     if (this.templateUpdateDelay != null) {
/* 330 */       configuration.setSetting("template_update_delay", this.templateUpdateDelay);
/*     */     }
/* 332 */     if (this.encoding != null) {
/* 333 */       configuration.setDefaultEncoding(this.encoding);
/*     */     }
/* 335 */     configuration.setLocalizedLookup(false);
/* 336 */     configuration.setWhitespaceStripping(true);
/*     */ 
/* 338 */     return configuration;
/*     */   }
/*     */ 
/*     */   protected ScopesHashModel buildScopesHashModel(ServletContext servletContext, HttpServletRequest request, HttpServletResponse response, ObjectWrapper wrapper, ValueStack stack)
/*     */   {
/* 343 */     ScopesHashModel model = new ScopesHashModel(wrapper, servletContext, request, stack);
/*     */ 
/* 346 */     synchronized (servletContext) {
/* 347 */       ServletContextHashModel servletContextModel = (ServletContextHashModel)servletContext.getAttribute(".freemarker.Application");
/* 348 */       if (servletContextModel == null)
/*     */       {
/* 350 */         GenericServlet servlet = JspSupportServlet.jspSupportServlet;
/* 351 */         if (servlet != null) {
/* 352 */           servletContextModel = new ServletContextHashModel(servlet, wrapper);
/* 353 */           servletContext.setAttribute(".freemarker.Application", servletContextModel);
/*     */         } else {
/* 355 */           servletContextModel = new ServletContextHashModel(servletContext, wrapper);
/* 356 */           servletContext.setAttribute(".freemarker.Application", servletContextModel);
/*     */         }
/* 358 */         TaglibFactory taglibs = new TaglibFactory(servletContext);
/* 359 */         servletContext.setAttribute(".freemarker.JspTaglibs", taglibs);
/*     */       }
/* 361 */       model.put("Application", servletContextModel);
/* 362 */       model.putUnlistedModel("__FreeMarkerServlet.Application__", servletContextModel);
/*     */     }
/* 364 */     model.put("JspTaglibs", (TemplateModel)servletContext.getAttribute(".freemarker.JspTaglibs"));
/*     */ 
/* 367 */     HttpSession session = request.getSession(false);
/* 368 */     if (session != null) {
/* 369 */       model.put("Session", new HttpSessionHashModel(session, wrapper));
/*     */     }
/*     */ 
/* 373 */     HttpRequestHashModel requestModel = (HttpRequestHashModel)request.getAttribute(".freemarker.Request");
/*     */ 
/* 375 */     if ((requestModel == null) || (requestModel.getRequest() != request)) {
/* 376 */       requestModel = new HttpRequestHashModel(request, response, wrapper);
/* 377 */       request.setAttribute(".freemarker.Request", requestModel);
/*     */     }
/*     */ 
/* 380 */     model.put("Request", requestModel);
/*     */ 
/* 384 */     HttpRequestParametersHashModel reqParametersModel = (HttpRequestParametersHashModel)request.getAttribute(".freemarker.RequestParameters");
/* 385 */     if ((reqParametersModel == null) || (requestModel.getRequest() != request)) {
/* 386 */       reqParametersModel = new HttpRequestParametersHashModel(request);
/* 387 */       request.setAttribute(".freemarker.RequestParameters", reqParametersModel);
/*     */     }
/* 389 */     model.put(".freemarker.RequestParameters", reqParametersModel);
/* 390 */     model.put("Parameters", reqParametersModel);
/*     */ 
/* 392 */     return model;
/*     */   }
/*     */ 
/*     */   protected ObjectWrapper createObjectWrapper(ServletContext servletContext) {
/* 396 */     StrutsBeanWrapper wrapper = new StrutsBeanWrapper(this.altMapWrapper);
/* 397 */     wrapper.setUseCache(this.cacheBeanWrapper);
/* 398 */     return wrapper;
/*     */   }
/*     */ 
/*     */   protected TemplateLoader createTemplateLoader(ServletContext servletContext, String templatePath)
/*     */   {
/* 412 */     TemplateLoader templatePathLoader = null;
/*     */     try
/*     */     {
/* 415 */       if (templatePath != null)
/* 416 */         if (templatePath.startsWith("class://"))
/*     */         {
/* 418 */           templatePathLoader = new ClassTemplateLoader(getClass(), templatePath.substring(7));
/* 419 */         } else if (templatePath.startsWith("file://"))
/* 420 */           templatePathLoader = new FileTemplateLoader(new File(templatePath.substring(7)));
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/* 424 */       if (LOG.isErrorEnabled()) {
/* 425 */         LOG.error("Invalid template path specified: #0", e, new String[] { e.getMessage() });
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 431 */     return templatePathLoader != null ? new MultiTemplateLoader(new TemplateLoader[] { templatePathLoader, new WebappTemplateLoader(servletContext), new StrutsClassTemplateLoader() }) : new MultiTemplateLoader(new TemplateLoader[] { new WebappTemplateLoader(servletContext), new StrutsClassTemplateLoader() });
/*     */   }
/*     */ 
/*     */   protected void loadSettings(ServletContext servletContext)
/*     */   {
/* 450 */     InputStream in = null;
/*     */     try
/*     */     {
/* 454 */       in = this.fileManager.loadFile(ClassLoaderUtil.getResource("freemarker.properties", getClass()));
/*     */ 
/* 456 */       if (in != null) {
/* 457 */         p = new Properties();
/* 458 */         p.load(in);
/*     */ 
/* 460 */         for (i$ = p.keySet().iterator(); i$.hasNext(); ) { Object o = i$.next();
/* 461 */           String name = (String)o;
/* 462 */           String value = (String)p.get(name);
/*     */ 
/* 464 */           if (name == null) {
/* 465 */             throw new IOException("init-param without param-name.  Maybe the freemarker.properties is not well-formed?");
/*     */           }
/*     */ 
/* 468 */           if (value == null) {
/* 469 */             throw new IOException("init-param without param-value.  Maybe the freemarker.properties is not well-formed?");
/*     */           }
/*     */ 
/* 472 */           addSetting(name, value);
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (IOException io)
/*     */     {
/*     */       Properties p;
/*     */       Iterator i$;
/* 476 */       if (LOG.isErrorEnabled())
/* 477 */         LOG.error("Error while loading freemarker settings from /freemarker.properties", e, new String[0]);
/*     */     }
/*     */     catch (TemplateException io) {
/* 480 */       if (LOG.isErrorEnabled())
/* 481 */         LOG.error("Error while loading freemarker settings from /freemarker.properties", e, new String[0]);
/*     */     }
/*     */     finally {
/* 484 */       if (in != null)
/*     */         try {
/* 486 */           in.close();
/*     */         } catch (IOException io) {
/* 488 */           if (LOG.isWarnEnabled())
/* 489 */             LOG.warn("Unable to close input stream", io, new String[0]);
/*     */         }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void addSetting(String name, String value)
/*     */     throws TemplateException
/*     */   {
/* 498 */     if (name.equals("NoCache"))
/* 499 */       this.nocache = StringUtil.getYesNo(value);
/* 500 */     else if (name.equals("Debug"))
/* 501 */       this.debug = StringUtil.getYesNo(value);
/* 502 */     else if (name.equals("ContentType"))
/* 503 */       this.contentType = value;
/*     */     else {
/* 505 */       this.config.setSetting(name, value);
/*     */     }
/*     */ 
/* 508 */     if ((this.contentType != null) && (!this.contentTypeEvaluated)) {
/* 509 */       int i = this.contentType.toLowerCase().indexOf("charset=");
/* 510 */       this.contentTypeEvaluated = true;
/* 511 */       if (i != -1) {
/* 512 */         char c = ' ';
/* 513 */         i--;
/* 514 */         while (i >= 0) {
/* 515 */           c = this.contentType.charAt(i);
/* 516 */           if (!Character.isWhitespace(c)) break;
/* 517 */           i--;
/*     */         }
/* 519 */         if ((i == -1) || (c == ';'))
/* 520 */           this.noCharsetInContentType = false;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public ScopesHashModel buildTemplateModel(ValueStack stack, Object action, ServletContext servletContext, HttpServletRequest request, HttpServletResponse response, ObjectWrapper wrapper)
/*     */   {
/* 529 */     ScopesHashModel model = buildScopesHashModel(servletContext, request, response, wrapper, stack);
/* 530 */     populateContext(model, stack, action, request, response);
/* 531 */     if (this.tagLibraries != null) {
/* 532 */       for (String prefix : this.tagLibraries.keySet()) {
/* 533 */         model.put(prefix, ((TagLibraryModelProvider)this.tagLibraries.get(prefix)).getModels(stack, request, response));
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 538 */     request.setAttribute(".freemarker.TemplateModel", model);
/*     */ 
/* 540 */     return model;
/*     */   }
/*     */ 
/*     */   protected void populateContext(ScopesHashModel model, ValueStack stack, Object action, HttpServletRequest request, HttpServletResponse response)
/*     */   {
/* 546 */     Map standard = ContextUtil.getStandardContext(stack, request, response);
/* 547 */     model.putAll(standard);
/*     */ 
/* 550 */     Throwable exception = (Throwable)request.getAttribute("javax.servlet.error.exception");
/*     */ 
/* 552 */     if (exception == null) {
/* 553 */       exception = (Throwable)request.getAttribute("javax.servlet.error.JspException");
/*     */     }
/*     */ 
/* 556 */     if (exception != null)
/* 557 */       model.put("exception", exception);
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/* 149 */     GregorianCalendar expiration = new GregorianCalendar();
/* 150 */     expiration.roll(1, -1);
/* 151 */     SimpleDateFormat httpDate = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss z", Locale.US);
/*     */ 
/* 155 */     EXPIRATION_DATE = httpDate.format(expiration.getTime());
/*     */ 
/* 160 */     LOG = LoggerFactory.getLogger(FreemarkerManager.class);
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.views.freemarker.FreemarkerManager
 * JD-Core Version:    0.6.0
 */