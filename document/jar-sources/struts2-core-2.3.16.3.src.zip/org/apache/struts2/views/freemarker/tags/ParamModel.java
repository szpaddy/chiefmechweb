/*    */ package org.apache.struts2.views.freemarker.tags;
/*    */ 
/*    */ import com.opensymphony.xwork2.util.ValueStack;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.apache.struts2.components.Component;
/*    */ import org.apache.struts2.components.Param;
/*    */ 
/*    */ public class ParamModel extends TagModel
/*    */ {
/*    */   public ParamModel(ValueStack stack, HttpServletRequest req, HttpServletResponse res)
/*    */   {
/* 37 */     super(stack, req, res);
/*    */   }
/*    */ 
/*    */   protected Component getBean() {
/* 41 */     return new Param(this.stack);
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.views.freemarker.tags.ParamModel
 * JD-Core Version:    0.6.0
 */