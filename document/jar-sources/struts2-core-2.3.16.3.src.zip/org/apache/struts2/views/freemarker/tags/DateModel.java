/*    */ package org.apache.struts2.views.freemarker.tags;
/*    */ 
/*    */ import com.opensymphony.xwork2.util.ValueStack;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.apache.struts2.components.Component;
/*    */ import org.apache.struts2.components.Date;
/*    */ 
/*    */ public class DateModel extends TagModel
/*    */ {
/*    */   public DateModel(ValueStack stack, HttpServletRequest req, HttpServletResponse res)
/*    */   {
/* 39 */     super(stack, req, res);
/*    */   }
/*    */ 
/*    */   protected Component getBean() {
/* 43 */     return new Date(this.stack);
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.views.freemarker.tags.DateModel
 * JD-Core Version:    0.6.0
 */