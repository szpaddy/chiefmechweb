/*     */ package org.apache.struts2.views.freemarker.tags;
/*     */ 
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ 
/*     */ public class StrutsModels
/*     */ {
/*     */   protected ValueStack stack;
/*     */   protected HttpServletRequest req;
/*     */   protected HttpServletResponse res;
/*     */   protected ActionModel action;
/*     */   protected BeanModel bean;
/*     */   protected CheckboxModel checkbox;
/*     */   protected CheckboxListModel checkboxlist;
/*     */   protected ComboBoxModel comboBox;
/*     */   protected ComponentModel component;
/*     */   protected DateModel date;
/*     */   protected DivModel div;
/*     */   protected DoubleSelectModel doubleselect;
/*     */   protected FileModel file;
/*     */   protected FormModel form;
/*     */   protected HeadModel head;
/*     */   protected HiddenModel hidden;
/*     */   protected AnchorModel a;
/*     */   protected I18nModel i18n;
/*     */   protected IncludeModel include;
/*     */   protected LabelModel label;
/*     */   protected PasswordModel password;
/*     */   protected PushModel push;
/*     */   protected ParamModel param;
/*     */   protected RadioModel radio;
/*     */   protected SelectModel select;
/*     */   protected SetModel set;
/*     */   protected SubmitModel submit;
/*     */   protected ResetModel reset;
/*     */   protected TextAreaModel textarea;
/*     */   protected TextModel text;
/*     */   protected TextFieldModel textfield;
/*     */   protected TokenModel token;
/*     */   protected URLModel url;
/*     */   protected PropertyModel property;
/*     */   protected IteratorModel iterator;
/*     */   protected ActionErrorModel actionerror;
/*     */   protected ActionMessageModel actionmessage;
/*     */   protected FieldErrorModel fielderror;
/*     */   protected OptionTransferSelectModel optiontransferselect;
/*     */   protected UpDownSelectModel updownselect;
/*     */   protected OptGroupModel optGroupModel;
/*     */   protected IfModel ifModel;
/*     */   protected ElseModel elseModel;
/*     */   protected ElseIfModel elseIfModel;
/*     */   protected InputTransferSelectModel inputtransferselect;
/*     */ 
/*     */   public StrutsModels(ValueStack stack, HttpServletRequest req, HttpServletResponse res)
/*     */   {
/*  83 */     this.stack = stack;
/*  84 */     this.req = req;
/*  85 */     this.res = res;
/*     */   }
/*     */ 
/*     */   public CheckboxListModel getCheckboxlist() {
/*  89 */     if (this.checkboxlist == null) {
/*  90 */       this.checkboxlist = new CheckboxListModel(this.stack, this.req, this.res);
/*     */     }
/*     */ 
/*  93 */     return this.checkboxlist;
/*     */   }
/*     */ 
/*     */   public CheckboxModel getCheckbox() {
/*  97 */     if (this.checkbox == null) {
/*  98 */       this.checkbox = new CheckboxModel(this.stack, this.req, this.res);
/*     */     }
/*     */ 
/* 101 */     return this.checkbox;
/*     */   }
/*     */ 
/*     */   public ComboBoxModel getCombobox() {
/* 105 */     if (this.comboBox == null) {
/* 106 */       this.comboBox = new ComboBoxModel(this.stack, this.req, this.res);
/*     */     }
/*     */ 
/* 109 */     return this.comboBox;
/*     */   }
/*     */ 
/*     */   public ComponentModel getComponent() {
/* 113 */     if (this.component == null) {
/* 114 */       this.component = new ComponentModel(this.stack, this.req, this.res);
/*     */     }
/*     */ 
/* 117 */     return this.component;
/*     */   }
/*     */ 
/*     */   public DoubleSelectModel getDoubleselect() {
/* 121 */     if (this.doubleselect == null) {
/* 122 */       this.doubleselect = new DoubleSelectModel(this.stack, this.req, this.res);
/*     */     }
/*     */ 
/* 125 */     return this.doubleselect;
/*     */   }
/*     */ 
/*     */   public FileModel getFile() {
/* 129 */     if (this.file == null) {
/* 130 */       this.file = new FileModel(this.stack, this.req, this.res);
/*     */     }
/*     */ 
/* 133 */     return this.file;
/*     */   }
/*     */ 
/*     */   public FormModel getForm() {
/* 137 */     if (this.form == null) {
/* 138 */       this.form = new FormModel(this.stack, this.req, this.res);
/*     */     }
/*     */ 
/* 141 */     return this.form;
/*     */   }
/*     */ 
/*     */   public HeadModel getHead() {
/* 145 */     if (this.head == null) {
/* 146 */       this.head = new HeadModel(this.stack, this.req, this.res);
/*     */     }
/*     */ 
/* 149 */     return this.head;
/*     */   }
/*     */ 
/*     */   public HiddenModel getHidden() {
/* 153 */     if (this.hidden == null) {
/* 154 */       this.hidden = new HiddenModel(this.stack, this.req, this.res);
/*     */     }
/*     */ 
/* 157 */     return this.hidden;
/*     */   }
/*     */   public LabelModel getLabel() {
/* 160 */     if (this.label == null) {
/* 161 */       this.label = new LabelModel(this.stack, this.req, this.res);
/*     */     }
/*     */ 
/* 164 */     return this.label;
/*     */   }
/*     */ 
/*     */   public PasswordModel getPassword() {
/* 168 */     if (this.password == null) {
/* 169 */       this.password = new PasswordModel(this.stack, this.req, this.res);
/*     */     }
/*     */ 
/* 172 */     return this.password;
/*     */   }
/*     */ 
/*     */   public RadioModel getRadio() {
/* 176 */     if (this.radio == null) {
/* 177 */       this.radio = new RadioModel(this.stack, this.req, this.res);
/*     */     }
/*     */ 
/* 180 */     return this.radio;
/*     */   }
/*     */ 
/*     */   public SelectModel getSelect() {
/* 184 */     if (this.select == null) {
/* 185 */       this.select = new SelectModel(this.stack, this.req, this.res);
/*     */     }
/*     */ 
/* 188 */     return this.select;
/*     */   }
/*     */ 
/*     */   public SubmitModel getSubmit() {
/* 192 */     if (this.submit == null) {
/* 193 */       this.submit = new SubmitModel(this.stack, this.req, this.res);
/*     */     }
/*     */ 
/* 196 */     return this.submit;
/*     */   }
/*     */ 
/*     */   public ResetModel getReset() {
/* 200 */     if (this.reset == null) {
/* 201 */       this.reset = new ResetModel(this.stack, this.req, this.res);
/*     */     }
/*     */ 
/* 204 */     return this.reset;
/*     */   }
/*     */ 
/*     */   public TextAreaModel getTextarea() {
/* 208 */     if (this.textarea == null) {
/* 209 */       this.textarea = new TextAreaModel(this.stack, this.req, this.res);
/*     */     }
/*     */ 
/* 212 */     return this.textarea;
/*     */   }
/*     */ 
/*     */   public TextFieldModel getTextfield() {
/* 216 */     if (this.textfield == null) {
/* 217 */       this.textfield = new TextFieldModel(this.stack, this.req, this.res);
/*     */     }
/*     */ 
/* 220 */     return this.textfield;
/*     */   }
/*     */ 
/*     */   public DateModel getDate() {
/* 224 */     if (this.date == null) {
/* 225 */       this.date = new DateModel(this.stack, this.req, this.res);
/*     */     }
/*     */ 
/* 228 */     return this.date;
/*     */   }
/*     */ 
/*     */   public TokenModel getToken() {
/* 232 */     if (this.token == null) {
/* 233 */       this.token = new TokenModel(this.stack, this.req, this.res);
/*     */     }
/*     */ 
/* 236 */     return this.token;
/*     */   }
/*     */ 
/*     */   public URLModel getUrl() {
/* 240 */     if (this.url == null) {
/* 241 */       this.url = new URLModel(this.stack, this.req, this.res);
/*     */     }
/*     */ 
/* 244 */     return this.url;
/*     */   }
/*     */ 
/*     */   public IncludeModel getInclude() {
/* 248 */     if (this.include == null) {
/* 249 */       this.include = new IncludeModel(this.stack, this.req, this.res);
/*     */     }
/*     */ 
/* 252 */     return this.include;
/*     */   }
/*     */ 
/*     */   public ParamModel getParam() {
/* 256 */     if (this.param == null) {
/* 257 */       this.param = new ParamModel(this.stack, this.req, this.res);
/*     */     }
/*     */ 
/* 260 */     return this.param;
/*     */   }
/*     */ 
/*     */   public ActionModel getAction() {
/* 264 */     if (this.action == null) {
/* 265 */       this.action = new ActionModel(this.stack, this.req, this.res);
/*     */     }
/*     */ 
/* 268 */     return this.action;
/*     */   }
/*     */ 
/*     */   public AnchorModel getA() {
/* 272 */     if (this.a == null) {
/* 273 */       this.a = new AnchorModel(this.stack, this.req, this.res);
/*     */     }
/*     */ 
/* 276 */     return this.a;
/*     */   }
/*     */ 
/*     */   public AnchorModel getHref() {
/* 280 */     if (this.a == null) {
/* 281 */       this.a = new AnchorModel(this.stack, this.req, this.res);
/*     */     }
/*     */ 
/* 284 */     return this.a;
/*     */   }
/*     */ 
/*     */   public DivModel getDiv() {
/* 288 */     if (this.div == null) {
/* 289 */       this.div = new DivModel(this.stack, this.req, this.res);
/*     */     }
/*     */ 
/* 292 */     return this.div;
/*     */   }
/*     */ 
/*     */   public TextModel getText() {
/* 296 */     if (this.text == null) {
/* 297 */       this.text = new TextModel(this.stack, this.req, this.res);
/*     */     }
/*     */ 
/* 300 */     return this.text;
/*     */   }
/*     */ 
/*     */   public BeanModel getBean() {
/* 304 */     if (this.bean == null) {
/* 305 */       this.bean = new BeanModel(this.stack, this.req, this.res);
/*     */     }
/*     */ 
/* 308 */     return this.bean;
/*     */   }
/*     */ 
/*     */   public I18nModel getI18n() {
/* 312 */     if (this.i18n == null) {
/* 313 */       this.i18n = new I18nModel(this.stack, this.req, this.res);
/*     */     }
/*     */ 
/* 316 */     return this.i18n;
/*     */   }
/*     */ 
/*     */   public PushModel getPush() {
/* 320 */     if (this.push == null) {
/* 321 */       this.push = new PushModel(this.stack, this.req, this.res);
/*     */     }
/*     */ 
/* 324 */     return this.push;
/*     */   }
/*     */ 
/*     */   public SetModel getSet() {
/* 328 */     if (this.set == null) {
/* 329 */       this.set = new SetModel(this.stack, this.req, this.res);
/*     */     }
/*     */ 
/* 332 */     return this.set;
/*     */   }
/*     */ 
/*     */   public PropertyModel getProperty() {
/* 336 */     if (this.property == null) {
/* 337 */       this.property = new PropertyModel(this.stack, this.req, this.res);
/*     */     }
/*     */ 
/* 340 */     return this.property;
/*     */   }
/*     */ 
/*     */   public IteratorModel getIterator() {
/* 344 */     if (this.iterator == null) {
/* 345 */       this.iterator = new IteratorModel(this.stack, this.req, this.res);
/*     */     }
/*     */ 
/* 348 */     return this.iterator;
/*     */   }
/*     */ 
/*     */   public ActionErrorModel getActionerror() {
/* 352 */     if (this.actionerror == null) {
/* 353 */       this.actionerror = new ActionErrorModel(this.stack, this.req, this.res);
/*     */     }
/*     */ 
/* 356 */     return this.actionerror;
/*     */   }
/*     */ 
/*     */   public ActionMessageModel getActionmessage() {
/* 360 */     if (this.actionmessage == null) {
/* 361 */       this.actionmessage = new ActionMessageModel(this.stack, this.req, this.res);
/*     */     }
/*     */ 
/* 364 */     return this.actionmessage;
/*     */   }
/*     */ 
/*     */   public FieldErrorModel getFielderror() {
/* 368 */     if (this.fielderror == null) {
/* 369 */       this.fielderror = new FieldErrorModel(this.stack, this.req, this.res);
/*     */     }
/*     */ 
/* 372 */     return this.fielderror;
/*     */   }
/*     */ 
/*     */   public OptionTransferSelectModel getOptiontransferselect() {
/* 376 */     if (this.optiontransferselect == null) {
/* 377 */       this.optiontransferselect = new OptionTransferSelectModel(this.stack, this.req, this.res);
/*     */     }
/* 379 */     return this.optiontransferselect;
/*     */   }
/*     */ 
/*     */   public UpDownSelectModel getUpdownselect() {
/* 383 */     if (this.updownselect == null) {
/* 384 */       this.updownselect = new UpDownSelectModel(this.stack, this.req, this.res);
/*     */     }
/* 386 */     return this.updownselect;
/*     */   }
/*     */ 
/*     */   public OptGroupModel getOptgroup() {
/* 390 */     if (this.optGroupModel == null) {
/* 391 */       this.optGroupModel = new OptGroupModel(this.stack, this.req, this.res);
/*     */     }
/* 393 */     return this.optGroupModel;
/*     */   }
/*     */ 
/*     */   public IfModel getIf() {
/* 397 */     if (this.ifModel == null) {
/* 398 */       this.ifModel = new IfModel(this.stack, this.req, this.res);
/*     */     }
/* 400 */     return this.ifModel;
/*     */   }
/*     */ 
/*     */   public ElseModel getElse() {
/* 404 */     if (this.elseModel == null) {
/* 405 */       this.elseModel = new ElseModel(this.stack, this.req, this.res);
/*     */     }
/* 407 */     return this.elseModel;
/*     */   }
/*     */ 
/*     */   public ElseIfModel getElseif() {
/* 411 */     if (this.elseIfModel == null) {
/* 412 */       this.elseIfModel = new ElseIfModel(this.stack, this.req, this.res);
/*     */     }
/* 414 */     return this.elseIfModel;
/*     */   }
/*     */ 
/*     */   public InputTransferSelectModel getInputtransferselect()
/*     */   {
/* 419 */     if (this.inputtransferselect == null) {
/* 420 */       this.inputtransferselect = new InputTransferSelectModel(this.stack, this.req, this.res);
/*     */     }
/* 422 */     return this.inputtransferselect;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.views.freemarker.tags.StrutsModels
 * JD-Core Version:    0.6.0
 */