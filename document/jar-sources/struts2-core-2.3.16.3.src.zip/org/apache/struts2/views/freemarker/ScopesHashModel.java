/*     */ package org.apache.struts2.views.freemarker;
/*     */ 
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import freemarker.template.ObjectWrapper;
/*     */ import freemarker.template.SimpleHash;
/*     */ import freemarker.template.TemplateModel;
/*     */ import freemarker.template.TemplateModelException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpSession;
/*     */ 
/*     */ public class ScopesHashModel extends SimpleHash
/*     */   implements TemplateModel
/*     */ {
/*     */   private static final long serialVersionUID = 5551686380141886764L;
/*     */   private HttpServletRequest request;
/*     */   private ServletContext servletContext;
/*     */   private ValueStack stack;
/*  53 */   private final Map<String, TemplateModel> unlistedModels = new HashMap();
/*     */   private volatile Object parametersCache;
/*     */ 
/*     */   public ScopesHashModel(ObjectWrapper objectWrapper, ServletContext context, HttpServletRequest request, ValueStack stack)
/*     */   {
/*  57 */     super(objectWrapper);
/*  58 */     this.servletContext = context;
/*  59 */     this.request = request;
/*  60 */     this.stack = stack;
/*     */   }
/*     */ 
/*     */   public ScopesHashModel(ObjectWrapper objectWrapper, ServletContext context, HttpServletRequest request)
/*     */   {
/*  65 */     super(objectWrapper);
/*  66 */     this.servletContext = context;
/*  67 */     this.request = request;
/*     */   }
/*     */ 
/*     */   public void putUnlistedModel(String key, TemplateModel model)
/*     */   {
/*  78 */     this.unlistedModels.put(key, model);
/*     */   }
/*     */ 
/*     */   public TemplateModel get(String key) throws TemplateModelException
/*     */   {
/*  83 */     TemplateModel model = super.get(key);
/*     */ 
/*  85 */     if (model != null) {
/*  86 */       return model;
/*     */     }
/*     */ 
/*  90 */     if (this.stack != null) {
/*  91 */       Object obj = findValueOnStack(key);
/*     */ 
/*  93 */       if (obj != null) {
/*  94 */         return wrap(obj);
/*     */       }
/*     */ 
/*  98 */       obj = this.stack.getContext().get(key);
/*  99 */       if (obj != null) {
/* 100 */         return wrap(obj);
/*     */       }
/*     */     }
/*     */ 
/* 104 */     if (this.request != null)
/*     */     {
/* 106 */       Object obj = this.request.getAttribute(key);
/*     */ 
/* 108 */       if (obj != null) {
/* 109 */         return wrap(obj);
/*     */       }
/*     */ 
/* 113 */       HttpSession session = this.request.getSession(false);
/*     */ 
/* 115 */       if (session != null) {
/* 116 */         obj = session.getAttribute(key);
/*     */ 
/* 118 */         if (obj != null) {
/* 119 */           return wrap(obj);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 124 */     if (this.servletContext != null)
/*     */     {
/* 126 */       Object obj = this.servletContext.getAttribute(key);
/*     */ 
/* 128 */       if (obj != null) {
/* 129 */         return wrap(obj);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 134 */     model = (TemplateModel)this.unlistedModels.get(key);
/* 135 */     if (model != null) {
/* 136 */       return wrap(model);
/*     */     }
/*     */ 
/* 140 */     return null;
/*     */   }
/*     */ 
/*     */   private Object findValueOnStack(String key) {
/* 144 */     if ("parameters".equals(key)) {
/* 145 */       if (this.parametersCache != null) {
/* 146 */         return this.parametersCache;
/*     */       }
/* 148 */       Object parametersLocal = this.stack.findValue(key);
/* 149 */       this.parametersCache = parametersLocal;
/* 150 */       return parametersLocal;
/*     */     }
/* 152 */     return this.stack.findValue(key);
/*     */   }
/*     */ 
/*     */   public void put(String string, boolean b) {
/* 156 */     super.put(string, b);
/*     */   }
/*     */ 
/*     */   public void put(String string, Object object) {
/* 160 */     super.put(string, object);
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.views.freemarker.ScopesHashModel
 * JD-Core Version:    0.6.0
 */