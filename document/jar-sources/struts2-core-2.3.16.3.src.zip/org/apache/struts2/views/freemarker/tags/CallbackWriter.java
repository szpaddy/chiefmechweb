/*    */ package org.apache.struts2.views.freemarker.tags;
/*    */ 
/*    */ import freemarker.template.TemplateModelException;
/*    */ import freemarker.template.TransformControl;
/*    */ import java.io.IOException;
/*    */ import java.io.StringWriter;
/*    */ import java.io.Writer;
/*    */ import org.apache.struts2.components.Component;
/*    */ 
/*    */ public class CallbackWriter extends Writer
/*    */   implements TransformControl
/*    */ {
/*    */   private Component bean;
/*    */   private Writer writer;
/*    */   private StringWriter body;
/* 39 */   private boolean afterBody = false;
/*    */ 
/*    */   public CallbackWriter(Component bean, Writer writer) {
/* 42 */     this.bean = bean;
/* 43 */     this.writer = writer;
/*    */ 
/* 45 */     if (bean.usesBody())
/* 46 */       this.body = new StringWriter();
/*    */   }
/*    */ 
/*    */   public void close() throws IOException
/*    */   {
/* 51 */     if (this.bean.usesBody())
/* 52 */       this.body.close();
/*    */   }
/*    */ 
/*    */   public void flush() throws IOException
/*    */   {
/* 57 */     this.writer.flush();
/*    */ 
/* 59 */     if (this.bean.usesBody())
/* 60 */       this.body.flush();
/*    */   }
/*    */ 
/*    */   public void write(char[] cbuf, int off, int len) throws IOException
/*    */   {
/* 65 */     if ((this.bean.usesBody()) && (!this.afterBody))
/* 66 */       this.body.write(cbuf, off, len);
/*    */     else
/* 68 */       this.writer.write(cbuf, off, len);
/*    */   }
/*    */ 
/*    */   public int onStart() throws TemplateModelException, IOException
/*    */   {
/* 73 */     boolean result = this.bean.start(this);
/*    */ 
/* 75 */     if (result) {
/* 76 */       return 1;
/*    */     }
/* 78 */     return 0;
/*    */   }
/*    */ 
/*    */   public int afterBody() throws TemplateModelException, IOException
/*    */   {
/* 83 */     this.afterBody = true;
/* 84 */     boolean result = this.bean.end(this, this.bean.usesBody() ? this.body.toString() : "");
/*    */ 
/* 86 */     if (result) {
/* 87 */       return 0;
/*    */     }
/* 89 */     return 1;
/*    */   }
/*    */ 
/*    */   public void onError(Throwable throwable) throws Throwable
/*    */   {
/* 94 */     throw throwable;
/*    */   }
/*    */ 
/*    */   public Component getBean() {
/* 98 */     return this.bean;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.views.freemarker.tags.CallbackWriter
 * JD-Core Version:    0.6.0
 */