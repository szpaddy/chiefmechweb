/*    */ package org.apache.struts2.views.freemarker;
/*    */ 
/*    */ import freemarker.core.CollectionAndSequence;
/*    */ import freemarker.ext.beans.BeansWrapper;
/*    */ import freemarker.ext.beans.MapModel;
/*    */ import freemarker.ext.util.ModelFactory;
/*    */ import freemarker.template.ObjectWrapper;
/*    */ import freemarker.template.SimpleSequence;
/*    */ import freemarker.template.TemplateCollectionModel;
/*    */ import freemarker.template.TemplateHashModelEx;
/*    */ import freemarker.template.TemplateModel;
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ 
/*    */ public class StrutsBeanWrapper extends BeansWrapper
/*    */ {
/*    */   private boolean altMapWrapper;
/*    */ 
/*    */   public StrutsBeanWrapper(boolean altMapWrapper)
/*    */   {
/* 56 */     this.altMapWrapper = altMapWrapper;
/*    */   }
/*    */ 
/*    */   protected ModelFactory getModelFactory(Class clazz)
/*    */   {
/* 61 */     if ((this.altMapWrapper) && (Map.class.isAssignableFrom(clazz))) {
/* 62 */       return FriendlyMapModel.FACTORY;
/*    */     }
/*    */ 
/* 65 */     return super.getModelFactory(clazz);
/*    */   }
/*    */ 
/*    */   private static final class FriendlyMapModel extends MapModel
/*    */     implements TemplateHashModelEx
/*    */   {
/* 74 */     static final ModelFactory FACTORY = new ModelFactory() {
/*    */       public TemplateModel create(Object object, ObjectWrapper wrapper) {
/* 76 */         return new StrutsBeanWrapper.FriendlyMapModel((Map)object, (BeansWrapper)wrapper);
/*    */       }
/* 74 */     };
/*    */ 
/*    */     public FriendlyMapModel(Map map, BeansWrapper wrapper)
/*    */     {
/* 81 */       super(wrapper);
/*    */     }
/*    */ 
/*    */     public boolean isEmpty() {
/* 85 */       return ((Map)this.object).isEmpty();
/*    */     }
/*    */ 
/*    */     protected Set keySet() {
/* 89 */       return ((Map)this.object).keySet();
/*    */     }
/*    */ 
/*    */     public TemplateCollectionModel values() {
/* 93 */       return new CollectionAndSequence(new SimpleSequence(((Map)this.object).values(), this.wrapper));
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.views.freemarker.StrutsBeanWrapper
 * JD-Core Version:    0.6.0
 */