/*    */ package org.apache.struts2.views.freemarker;
/*    */ 
/*    */ import com.opensymphony.xwork2.inject.Inject;
/*    */ import freemarker.cache.TemplateLoader;
/*    */ import java.io.IOException;
/*    */ import java.io.Reader;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import org.apache.struts2.components.template.Template;
/*    */ import org.apache.struts2.components.template.TemplateEngine;
/*    */ 
/*    */ public class FreemarkerThemeTemplateLoader
/*    */   implements TemplateLoader
/*    */ {
/*    */   private TemplateLoader parentTemplateLoader;
/*    */   private String themeExpansionToken;
/*    */   private TemplateEngine templateEngine;
/*    */ 
/*    */   public void init(TemplateLoader parent)
/*    */   {
/* 30 */     this.parentTemplateLoader = parent;
/*    */   }
/*    */ 
/*    */   public Object findTemplateSource(String name) throws IOException
/*    */   {
/* 35 */     int tokenIndex = name == null ? -1 : name.indexOf(this.themeExpansionToken);
/* 36 */     if (tokenIndex < 0) {
/* 37 */       return this.parentTemplateLoader.findTemplateSource(name);
/*    */     }
/*    */ 
/* 40 */     int themeEndIndex = name.indexOf('/', tokenIndex);
/* 41 */     if (themeEndIndex < 0) {
/* 42 */       return this.parentTemplateLoader.findTemplateSource(name);
/*    */     }
/*    */ 
/* 45 */     Template template = new Template(name.substring(0, tokenIndex - 1), name.substring(tokenIndex + this.themeExpansionToken.length(), themeEndIndex), name.substring(themeEndIndex + 1));
/*    */ 
/* 50 */     List possibleTemplates = template.getPossibleTemplates(this.templateEngine);
/* 51 */     for (Template possibleTemplate : possibleTemplates) {
/* 52 */       Object templateSource = this.parentTemplateLoader.findTemplateSource(possibleTemplate.toString().substring(1));
/*    */ 
/* 54 */       if (templateSource != null) {
/* 55 */         return templateSource;
/*    */       }
/*    */     }
/* 58 */     String parentTheme = (String)this.templateEngine.getThemeProps(template).get("parent");
/* 59 */     if (parentTheme == null)
/*    */     {
/* 61 */       return null;
/*    */     }
/* 63 */     String parentName = "/" + template.getDir() + "/" + this.themeExpansionToken + parentTheme + "/" + template.getName();
/* 64 */     return findTemplateSource(parentName);
/*    */   }
/*    */ 
/*    */   public long getLastModified(Object templateSource)
/*    */   {
/* 69 */     return this.parentTemplateLoader.getLastModified(templateSource);
/*    */   }
/*    */ 
/*    */   public Reader getReader(Object templateSource, String encoding) throws IOException
/*    */   {
/* 74 */     return this.parentTemplateLoader.getReader(templateSource, encoding);
/*    */   }
/*    */ 
/*    */   public void closeTemplateSource(Object templateSource) throws IOException
/*    */   {
/* 79 */     this.parentTemplateLoader.closeTemplateSource(templateSource);
/*    */   }
/*    */   @Inject("struts.ui.theme.expansion.token")
/*    */   public void setUIThemeExpansionToken(String token) {
/* 84 */     this.themeExpansionToken = token;
/*    */   }
/*    */   @Inject("ftl")
/*    */   public void setTemplateEngine(TemplateEngine templateEngine) {
/* 89 */     this.templateEngine = templateEngine;
/*    */   }
/*    */ 
/*    */   public TemplateLoader getParentTemplateLoader() {
/* 93 */     return this.parentTemplateLoader;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.views.freemarker.FreemarkerThemeTemplateLoader
 * JD-Core Version:    0.6.0
 */