/*     */ package org.apache.struts2.views.freemarker.tags;
/*     */ 
/*     */ import com.opensymphony.xwork2.inject.Container;
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import com.opensymphony.xwork2.util.logging.Logger;
/*     */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*     */ import freemarker.ext.beans.BeanModel;
/*     */ import freemarker.ext.beans.BeansWrapper;
/*     */ import freemarker.template.SimpleNumber;
/*     */ import freemarker.template.SimpleSequence;
/*     */ import freemarker.template.TemplateModel;
/*     */ import freemarker.template.TemplateModelException;
/*     */ import freemarker.template.TemplateTransformModel;
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.struts2.components.Component;
/*     */ 
/*     */ public abstract class TagModel
/*     */   implements TemplateTransformModel
/*     */ {
/*  46 */   private static final Logger LOG = LoggerFactory.getLogger(TagModel.class);
/*     */   protected ValueStack stack;
/*     */   protected HttpServletRequest req;
/*     */   protected HttpServletResponse res;
/*     */ 
/*     */   public TagModel(ValueStack stack, HttpServletRequest req, HttpServletResponse res)
/*     */   {
/*  53 */     this.stack = stack;
/*  54 */     this.req = req;
/*  55 */     this.res = res;
/*     */   }
/*     */ 
/*     */   public Writer getWriter(Writer writer, Map params) throws TemplateModelException, IOException
/*     */   {
/*  60 */     Component bean = getBean();
/*  61 */     Container container = (Container)this.stack.getContext().get("com.opensymphony.xwork2.ActionContext.container");
/*  62 */     container.inject(bean);
/*     */ 
/*  64 */     Map unwrappedParameters = unwrapParameters(params);
/*  65 */     bean.copyParams(unwrappedParameters);
/*     */ 
/*  67 */     return new CallbackWriter(bean, writer);
/*     */   }
/*     */   protected abstract Component getBean();
/*     */ 
/*     */   protected Map unwrapParameters(Map params) {
/*  73 */     Map map = new HashMap(params.size());
/*  74 */     BeansWrapper objectWrapper = BeansWrapper.getDefaultInstance();
/*  75 */     for (Iterator iterator = params.entrySet().iterator(); iterator.hasNext(); ) {
/*  76 */       Map.Entry entry = (Map.Entry)iterator.next();
/*     */ 
/*  78 */       Object value = entry.getValue();
/*     */ 
/*  80 */       if (value != null)
/*     */       {
/*  82 */         if ((value instanceof TemplateModel)) {
/*     */           try {
/*  84 */             map.put(entry.getKey(), objectWrapper.unwrap((TemplateModel)value));
/*     */           } catch (TemplateModelException e) {
/*  86 */             if (LOG.isErrorEnabled()) {
/*  87 */               LOG.error("failed to unwrap [#0] it will be ignored", e, new String[] { value.toString() });
/*     */             }
/*     */           }
/*     */         }
/*     */         else
/*     */         {
/*  93 */           map.put(entry.getKey(), value.toString());
/*     */         }
/*     */       }
/*     */     }
/*  97 */     return map;
/*     */   }
/*     */ 
/*     */   protected Map convertParams(Map params) {
/* 101 */     HashMap map = new HashMap(params.size());
/* 102 */     for (Iterator iterator = params.entrySet().iterator(); iterator.hasNext(); ) {
/* 103 */       Map.Entry entry = (Map.Entry)iterator.next();
/* 104 */       Object value = entry.getValue();
/* 105 */       if ((value != null) && (!complexType(value))) {
/* 106 */         map.put(entry.getKey(), value.toString());
/*     */       }
/*     */     }
/* 109 */     return map;
/*     */   }
/*     */ 
/*     */   protected Map getComplexParams(Map params) {
/* 113 */     HashMap map = new HashMap(params.size());
/* 114 */     for (Iterator iterator = params.entrySet().iterator(); iterator.hasNext(); ) {
/* 115 */       Map.Entry entry = (Map.Entry)iterator.next();
/* 116 */       Object value = entry.getValue();
/* 117 */       if ((value != null) && (complexType(value))) {
/* 118 */         if ((value instanceof BeanModel))
/* 119 */           map.put(entry.getKey(), ((BeanModel)value).getWrappedObject());
/* 120 */         else if ((value instanceof SimpleNumber))
/* 121 */           map.put(entry.getKey(), ((SimpleNumber)value).getAsNumber());
/* 122 */         else if ((value instanceof SimpleSequence)) {
/*     */           try {
/* 124 */             map.put(entry.getKey(), ((SimpleSequence)value).toList());
/*     */           } catch (TemplateModelException e) {
/* 126 */             if (LOG.isErrorEnabled()) {
/* 127 */               LOG.error("There was a problem converting a SimpleSequence to a list", e, new String[0]);
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 133 */     return map;
/*     */   }
/*     */ 
/*     */   protected boolean complexType(Object value) {
/* 137 */     return ((value instanceof BeanModel)) || ((value instanceof SimpleNumber)) || ((value instanceof SimpleSequence));
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.views.freemarker.tags.TagModel
 * JD-Core Version:    0.6.0
 */