/*    */ package org.apache.struts2.views.freemarker.tags;
/*    */ 
/*    */ import com.opensymphony.xwork2.util.ValueStack;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.apache.struts2.components.Component;
/*    */ import org.apache.struts2.components.Select;
/*    */ 
/*    */ public class SelectModel extends TagModel
/*    */ {
/*    */   public SelectModel(ValueStack stack, HttpServletRequest req, HttpServletResponse res)
/*    */   {
/* 37 */     super(stack, req, res);
/*    */   }
/*    */ 
/*    */   protected Component getBean() {
/* 41 */     return new Select(this.stack, this.req, this.res);
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.views.freemarker.tags.SelectModel
 * JD-Core Version:    0.6.0
 */