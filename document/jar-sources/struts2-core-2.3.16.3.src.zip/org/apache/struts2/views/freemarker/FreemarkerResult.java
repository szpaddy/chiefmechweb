/*     */ package org.apache.struts2.views.freemarker;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionContext;
/*     */ import com.opensymphony.xwork2.ActionInvocation;
/*     */ import com.opensymphony.xwork2.LocaleProvider;
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import com.opensymphony.xwork2.util.logging.Logger;
/*     */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*     */ import freemarker.template.Configuration;
/*     */ import freemarker.template.ObjectWrapper;
/*     */ import freemarker.template.Template;
/*     */ import freemarker.template.TemplateException;
/*     */ import freemarker.template.TemplateExceptionHandler;
/*     */ import freemarker.template.TemplateModel;
/*     */ import freemarker.template.TemplateModelException;
/*     */ import java.io.CharArrayWriter;
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import java.util.Locale;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.commons.lang3.ObjectUtils;
/*     */ import org.apache.struts2.ServletActionContext;
/*     */ import org.apache.struts2.dispatcher.StrutsResultSupport;
/*     */ import org.apache.struts2.views.util.ResourceUtil;
/*     */ 
/*     */ public class FreemarkerResult extends StrutsResultSupport
/*     */ {
/*     */   private static final long serialVersionUID = -3778230771704661631L;
/* 108 */   private static final Logger LOG = LoggerFactory.getLogger(FreemarkerResult.class);
/*     */   protected ActionInvocation invocation;
/*     */   protected Configuration configuration;
/*     */   protected ObjectWrapper wrapper;
/*     */   protected FreemarkerManager freemarkerManager;
/*     */   private Writer writer;
/* 115 */   private boolean writeIfCompleted = false;
/*     */   protected String location;
/* 122 */   private String pContentType = "text/html";
/* 123 */   private static final String PARENT_TEMPLATE_WRITER = FreemarkerResult.class.getName() + ".parentWriter";
/*     */ 
/*     */   public FreemarkerResult()
/*     */   {
/*     */   }
/*     */ 
/*     */   public FreemarkerResult(String location) {
/* 130 */     super(location);
/*     */   }
/*     */   @Inject
/*     */   public void setFreemarkerManager(FreemarkerManager mgr) {
/* 135 */     this.freemarkerManager = mgr;
/*     */   }
/*     */ 
/*     */   public void setContentType(String aContentType) {
/* 139 */     this.pContentType = aContentType;
/*     */   }
/*     */ 
/*     */   public String getContentType()
/*     */   {
/* 147 */     return this.pContentType;
/*     */   }
/*     */ 
/*     */   public void doExecute(String locationArg, ActionInvocation invocation)
/*     */     throws IOException, TemplateException
/*     */   {
/* 160 */     this.location = locationArg;
/* 161 */     this.invocation = invocation;
/* 162 */     this.configuration = getConfiguration();
/* 163 */     this.wrapper = getObjectWrapper();
/*     */ 
/* 165 */     ActionContext ctx = invocation.getInvocationContext();
/* 166 */     HttpServletRequest req = (HttpServletRequest)ctx.get("com.opensymphony.xwork2.dispatcher.HttpServletRequest");
/*     */ 
/* 168 */     if (!locationArg.startsWith("/")) {
/* 169 */       String base = ResourceUtil.getResourceBase(req);
/* 170 */       locationArg = base + "/" + locationArg;
/*     */     }
/*     */ 
/* 173 */     Template template = this.configuration.getTemplate(locationArg, deduceLocale());
/* 174 */     TemplateModel model = createModel();
/*     */ 
/* 177 */     if (preTemplateProcess(template, model))
/*     */       try
/*     */       {
/* 180 */         Writer writer = getWriter();
/* 181 */         if ((isWriteIfCompleted()) || (this.configuration.getTemplateExceptionHandler() == TemplateExceptionHandler.RETHROW_HANDLER)) {
/* 182 */           CharArrayWriter parentCharArrayWriter = (CharArrayWriter)req.getAttribute(PARENT_TEMPLATE_WRITER);
/* 183 */           boolean isTopTemplate = false;
/* 184 */           if ((isTopTemplate = parentCharArrayWriter == null ? 1 : 0) != 0)
/*     */           {
/* 186 */             parentCharArrayWriter = new CharArrayWriter();
/*     */ 
/* 188 */             req.setAttribute(PARENT_TEMPLATE_WRITER, parentCharArrayWriter);
/*     */           }
/*     */           try
/*     */           {
/* 192 */             template.process(model, parentCharArrayWriter);
/*     */ 
/* 194 */             if (isTopTemplate) {
/* 195 */               parentCharArrayWriter.flush();
/* 196 */               parentCharArrayWriter.writeTo(writer);
/*     */             }
/*     */           } catch (TemplateException e) {
/* 199 */             if (LOG.isErrorEnabled()) {
/* 200 */               LOG.error("Error processing Freemarker result!", e, new String[0]);
/*     */             }
/* 202 */             throw e;
/*     */           } catch (IOException e) {
/* 204 */             if (LOG.isErrorEnabled()) {
/* 205 */               LOG.error("Error processing Freemarker result!", e, new String[0]);
/*     */             }
/* 207 */             throw e;
/*     */           } finally {
/* 209 */             if ((isTopTemplate) && (parentCharArrayWriter != null)) {
/* 210 */               req.removeAttribute(PARENT_TEMPLATE_WRITER);
/* 211 */               parentCharArrayWriter.close();
/*     */             }
/*     */           }
/*     */         } else {
/* 215 */           template.process(model, writer);
/*     */         }
/*     */       }
/*     */       finally {
/* 219 */         postTemplateProcess(template, model);
/*     */       }
/*     */   }
/*     */ 
/*     */   protected Configuration getConfiguration()
/*     */     throws TemplateException
/*     */   {
/* 235 */     return this.freemarkerManager.getConfiguration(ServletActionContext.getServletContext());
/*     */   }
/*     */ 
/*     */   protected ObjectWrapper getObjectWrapper()
/*     */   {
/* 248 */     return this.configuration.getObjectWrapper();
/*     */   }
/*     */ 
/*     */   public void setWriter(Writer writer)
/*     */   {
/* 253 */     this.writer = writer;
/*     */   }
/*     */ 
/*     */   protected Writer getWriter()
/*     */     throws IOException
/*     */   {
/* 260 */     if (this.writer != null) {
/* 261 */       return this.writer;
/*     */     }
/* 263 */     return ServletActionContext.getResponse().getWriter();
/*     */   }
/*     */ 
/*     */   protected TemplateModel createModel()
/*     */     throws TemplateModelException
/*     */   {
/* 286 */     ServletContext servletContext = ServletActionContext.getServletContext();
/* 287 */     HttpServletRequest request = ServletActionContext.getRequest();
/* 288 */     HttpServletResponse response = ServletActionContext.getResponse();
/* 289 */     ValueStack stack = ServletActionContext.getContext().getValueStack();
/*     */ 
/* 291 */     Object action = null;
/* 292 */     if (this.invocation != null) action = this.invocation.getAction();
/* 293 */     return this.freemarkerManager.buildTemplateModel(stack, action, servletContext, request, response, this.wrapper);
/*     */   }
/*     */ 
/*     */   protected Locale deduceLocale()
/*     */   {
/* 302 */     if ((this.invocation.getAction() instanceof LocaleProvider)) {
/* 303 */       return ((LocaleProvider)this.invocation.getAction()).getLocale();
/*     */     }
/* 305 */     return this.configuration.getLocale();
/*     */   }
/*     */ 
/*     */   protected void postTemplateProcess(Template template, TemplateModel data)
/*     */     throws IOException
/*     */   {
/*     */   }
/*     */ 
/*     */   protected boolean preTemplateProcess(Template template, TemplateModel model)
/*     */     throws IOException
/*     */   {
/* 325 */     Object attrContentType = template.getCustomAttribute("content_type");
/*     */ 
/* 327 */     HttpServletResponse response = ServletActionContext.getResponse();
/* 328 */     if (response.getContentType() == null) {
/* 329 */       if (attrContentType != null) {
/* 330 */         response.setContentType(attrContentType.toString());
/*     */       } else {
/* 332 */         String contentType = getContentType();
/*     */ 
/* 334 */         if (contentType == null) {
/* 335 */           contentType = "text/html";
/*     */         }
/*     */ 
/* 338 */         String encoding = template.getEncoding();
/*     */ 
/* 340 */         if (encoding != null) {
/* 341 */           contentType = contentType + "; charset=" + encoding;
/*     */         }
/*     */ 
/* 344 */         response.setContentType(contentType);
/*     */       }
/* 346 */     } else if (isInsideActionTag())
/*     */     {
/* 348 */       response.setContentType(response.getContentType());
/*     */     }
/*     */ 
/* 351 */     return true;
/*     */   }
/*     */ 
/*     */   private boolean isInsideActionTag() {
/* 355 */     Object attribute = ServletActionContext.getRequest().getAttribute("struts.actiontag.invocation");
/* 356 */     return ((Boolean)ObjectUtils.defaultIfNull(attribute, Boolean.FALSE)).booleanValue();
/*     */   }
/*     */ 
/*     */   public boolean isWriteIfCompleted()
/*     */   {
/* 363 */     return this.writeIfCompleted;
/*     */   }
/*     */ 
/*     */   public void setWriteIfCompleted(boolean writeIfCompleted)
/*     */   {
/* 370 */     this.writeIfCompleted = writeIfCompleted;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.views.freemarker.FreemarkerResult
 * JD-Core Version:    0.6.0
 */