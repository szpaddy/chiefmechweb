/*    */ package org.apache.struts2.views.freemarker.tags;
/*    */ 
/*    */ import com.opensymphony.xwork2.util.ValueStack;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.apache.struts2.components.Bean;
/*    */ import org.apache.struts2.components.Component;
/*    */ 
/*    */ public class BeanModel extends TagModel
/*    */ {
/*    */   public BeanModel(ValueStack stack, HttpServletRequest req, HttpServletResponse res)
/*    */   {
/* 37 */     super(stack, req, res);
/*    */   }
/*    */ 
/*    */   protected Component getBean() {
/* 41 */     return new Bean(this.stack);
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.views.freemarker.tags.BeanModel
 * JD-Core Version:    0.6.0
 */