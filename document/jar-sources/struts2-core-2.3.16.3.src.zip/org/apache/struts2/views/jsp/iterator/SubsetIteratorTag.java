/*     */ package org.apache.struts2.views.jsp.iterator;
/*     */ 
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import com.opensymphony.xwork2.util.logging.Logger;
/*     */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.PageContext;
/*     */ import org.apache.struts2.util.SubsetIteratorFilter;
/*     */ import org.apache.struts2.util.SubsetIteratorFilter.Decider;
/*     */ import org.apache.struts2.views.annotations.StrutsTag;
/*     */ import org.apache.struts2.views.annotations.StrutsTagAttribute;
/*     */ import org.apache.struts2.views.jsp.StrutsBodyTagSupport;
/*     */ 
/*     */ @StrutsTag(name="subset", tldTagClass="org.apache.struts2.views.jsp.iterator.SubsetIteratorTag", description="Takes an iterator and outputs a subset of it.")
/*     */ public class SubsetIteratorTag extends StrutsBodyTagSupport
/*     */ {
/*     */   private static final long serialVersionUID = -6252696081713080102L;
/* 158 */   private static final Logger LOG = LoggerFactory.getLogger(SubsetIteratorTag.class);
/*     */   String countAttr;
/*     */   String sourceAttr;
/*     */   String startAttr;
/*     */   String deciderAttr;
/*     */   String var;
/* 165 */   SubsetIteratorFilter subsetIteratorFilter = null;
/*     */ 
/*     */   @StrutsTagAttribute(type="Integer", description="Indicate the number of entries to be in the resulting subset iterator")
/*     */   public void setCount(String count) {
/* 170 */     this.countAttr = count;
/*     */   }
/*     */   @StrutsTagAttribute(description="Indicate the source of which the resulting subset iterator is to be derived base on")
/*     */   public void setSource(String source) {
/* 175 */     this.sourceAttr = source;
/*     */   }
/*     */ 
/*     */   @StrutsTagAttribute(type="Integer", description="Indicate the starting index (eg. first entry is 0) of entries in the source to be available as the first entry in the resulting subset iterator")
/*     */   public void setStart(String start)
/*     */   {
/* 185 */     this.startAttr = start;
/*     */   }
/*     */ 
/*     */   @StrutsTagAttribute(type="org.apache.struts2.util.SubsetIteratorFilter.Decider", description="Extension to plug-in a decider to determine if that particular entry is to be included in the resulting subset iterator")
/*     */   public void setDecider(String decider) {
/* 191 */     this.deciderAttr = decider;
/*     */   }
/*     */   @StrutsTagAttribute(description="Deprecated. Use 'var' instead")
/*     */   public void setId(String string) {
/* 196 */     setVar(string);
/*     */   }
/*     */   @StrutsTagAttribute(description="The name to store the resultant iterator into page context, if such name is supplied")
/*     */   public void setVar(String var) {
/* 201 */     this.var = var;
/*     */   }
/*     */ 
/*     */   public int doStartTag()
/*     */     throws JspException
/*     */   {
/* 207 */     Object source = null;
/* 208 */     if ((this.sourceAttr == null) || (this.sourceAttr.length() == 0))
/* 209 */       source = findValue("top");
/*     */     else {
/* 211 */       source = findValue(this.sourceAttr);
/*     */     }
/*     */ 
/* 215 */     int count = -1;
/* 216 */     if ((this.countAttr != null) && (this.countAttr.length() > 0)) {
/* 217 */       Object countObj = findValue(this.countAttr);
/* 218 */       if ((countObj instanceof Number)) {
/* 219 */         count = ((Number)countObj).intValue();
/*     */       }
/* 221 */       else if ((countObj instanceof String)) {
/*     */         try {
/* 223 */           count = Integer.parseInt((String)countObj);
/*     */         }
/*     */         catch (NumberFormatException e) {
/* 226 */           if (LOG.isWarnEnabled()) {
/* 227 */             LOG.warn("unable to convert count attribute [" + countObj + "] to number, ignore count attribute", e, new String[0]);
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 234 */     int start = 0;
/* 235 */     if ((this.startAttr != null) && (this.startAttr.length() > 0)) {
/* 236 */       Object startObj = findValue(this.startAttr);
/* 237 */       if ((startObj instanceof Integer)) {
/* 238 */         start = ((Integer)startObj).intValue();
/*     */       }
/* 240 */       else if ((startObj instanceof Float)) {
/* 241 */         start = ((Float)startObj).intValue();
/*     */       }
/* 243 */       else if ((startObj instanceof Long)) {
/* 244 */         start = ((Long)startObj).intValue();
/*     */       }
/* 246 */       else if ((startObj instanceof Double)) {
/* 247 */         start = ((Double)startObj).intValue();
/*     */       }
/* 249 */       else if ((startObj instanceof String)) {
/*     */         try {
/* 251 */           start = Integer.parseInt((String)startObj);
/*     */         }
/*     */         catch (NumberFormatException e) {
/* 254 */           if (LOG.isWarnEnabled()) {
/* 255 */             LOG.warn("unable to convert count attribute [" + startObj + "] to number, ignore count attribute", e, new String[0]);
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 262 */     SubsetIteratorFilter.Decider decider = null;
/* 263 */     if ((this.deciderAttr != null) && (this.deciderAttr.length() > 0)) {
/* 264 */       Object deciderObj = findValue(this.deciderAttr);
/* 265 */       if (!(deciderObj instanceof SubsetIteratorFilter.Decider)) {
/* 266 */         throw new JspException("decider found from stack [" + deciderObj + "] does not implement " + SubsetIteratorFilter.Decider.class);
/*     */       }
/* 268 */       decider = (SubsetIteratorFilter.Decider)deciderObj;
/*     */     }
/*     */ 
/* 272 */     this.subsetIteratorFilter = new SubsetIteratorFilter();
/* 273 */     this.subsetIteratorFilter.setCount(count);
/* 274 */     this.subsetIteratorFilter.setDecider(decider);
/* 275 */     this.subsetIteratorFilter.setSource(source);
/* 276 */     this.subsetIteratorFilter.setStart(start);
/* 277 */     this.subsetIteratorFilter.execute();
/*     */ 
/* 279 */     getStack().push(this.subsetIteratorFilter);
/* 280 */     if ((this.var != null) && (this.var.length() > 0)) {
/* 281 */       this.pageContext.setAttribute(this.var, this.subsetIteratorFilter);
/*     */     }
/*     */ 
/* 284 */     return 1;
/*     */   }
/*     */ 
/*     */   public int doEndTag() throws JspException
/*     */   {
/* 289 */     getStack().pop();
/*     */ 
/* 291 */     this.subsetIteratorFilter = null;
/*     */ 
/* 293 */     return 6;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.views.jsp.iterator.SubsetIteratorTag
 * JD-Core Version:    0.6.0
 */