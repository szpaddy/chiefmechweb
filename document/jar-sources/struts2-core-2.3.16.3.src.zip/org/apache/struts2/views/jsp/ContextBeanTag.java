/*    */ package org.apache.struts2.views.jsp;
/*    */ 
/*    */ import org.apache.struts2.components.ContextBean;
/*    */ 
/*    */ public abstract class ContextBeanTag extends ComponentTagSupport
/*    */ {
/*    */   private String var;
/*    */ 
/*    */   protected void populateParams()
/*    */   {
/* 31 */     super.populateParams();
/*    */ 
/* 33 */     ContextBean bean = (ContextBean)this.component;
/* 34 */     bean.setVar(this.var);
/*    */   }
/*    */ 
/*    */   public void setVar(String var) {
/* 38 */     this.var = var;
/*    */   }
/*    */ 
/*    */   public void setId(String id)
/*    */   {
/* 46 */     setVar(id);
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.views.jsp.ContextBeanTag
 * JD-Core Version:    0.6.0
 */