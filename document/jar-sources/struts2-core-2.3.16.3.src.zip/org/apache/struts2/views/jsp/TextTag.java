/*    */ package org.apache.struts2.views.jsp;
/*    */ 
/*    */ import com.opensymphony.xwork2.util.ValueStack;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.apache.struts2.components.Component;
/*    */ import org.apache.struts2.components.Text;
/*    */ 
/*    */ public class TextTag extends ContextBeanTag
/*    */ {
/*    */   private static final long serialVersionUID = -3075088084198264581L;
/*    */   protected String name;
/*    */   protected String searchValueStack;
/*    */ 
/*    */   public Component getBean(ValueStack stack, HttpServletRequest req, HttpServletResponse res)
/*    */   {
/* 44 */     return new Text(stack);
/*    */   }
/*    */ 
/*    */   protected void populateParams() {
/* 48 */     super.populateParams();
/*    */ 
/* 50 */     Text text = (Text)this.component;
/* 51 */     text.setName(this.name);
/* 52 */     text.setSearchValueStack(this.searchValueStack);
/*    */   }
/*    */ 
/*    */   public void setName(String name) {
/* 56 */     this.name = name;
/*    */   }
/*    */ 
/*    */   public void setSearchValueStack(String searchStack) {
/* 60 */     this.searchValueStack = searchStack;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.views.jsp.TextTag
 * JD-Core Version:    0.6.0
 */