/*    */ package org.apache.struts2.views.jsp;
/*    */ 
/*    */ import com.opensymphony.xwork2.util.ValueStack;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.apache.struts2.components.ActionComponent;
/*    */ import org.apache.struts2.components.Component;
/*    */ 
/*    */ public class ActionTag extends ContextBeanTag
/*    */ {
/*    */   private static final long serialVersionUID = -5384167073331678855L;
/*    */   protected String name;
/*    */   protected String namespace;
/*    */   protected boolean executeResult;
/*    */   protected boolean ignoreContextParams;
/* 42 */   protected boolean flush = true;
/*    */   protected boolean rethrowException;
/*    */ 
/*    */   public Component getBean(ValueStack stack, HttpServletRequest req, HttpServletResponse res)
/*    */   {
/* 46 */     return new ActionComponent(stack, req, res);
/*    */   }
/*    */ 
/*    */   protected void populateParams() {
/* 50 */     super.populateParams();
/*    */ 
/* 52 */     ActionComponent action = (ActionComponent)this.component;
/* 53 */     action.setName(this.name);
/* 54 */     action.setNamespace(this.namespace);
/* 55 */     action.setExecuteResult(this.executeResult);
/* 56 */     action.setIgnoreContextParams(this.ignoreContextParams);
/* 57 */     action.setFlush(this.flush);
/* 58 */     action.setRethrowException(this.rethrowException);
/*    */   }
/*    */ 
/*    */   protected void addParameter(String name, Object value) {
/* 62 */     ActionComponent ac = (ActionComponent)this.component;
/* 63 */     ac.addParameter(name, value);
/*    */   }
/*    */ 
/*    */   public void setName(String name) {
/* 67 */     this.name = name;
/*    */   }
/*    */ 
/*    */   public void setNamespace(String namespace) {
/* 71 */     this.namespace = namespace;
/*    */   }
/*    */ 
/*    */   public void setExecuteResult(boolean executeResult) {
/* 75 */     this.executeResult = executeResult;
/*    */   }
/*    */ 
/*    */   public void setIgnoreContextParams(boolean ignoreContextParams) {
/* 79 */     this.ignoreContextParams = ignoreContextParams;
/*    */   }
/*    */ 
/*    */   public void setFlush(boolean flush) {
/* 83 */     this.flush = flush;
/*    */   }
/*    */ 
/*    */   public boolean getFlush() {
/* 87 */     return this.flush;
/*    */   }
/*    */ 
/*    */   public void setRethrowException(boolean rethrowException) {
/* 91 */     this.rethrowException = rethrowException;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.views.jsp.ActionTag
 * JD-Core Version:    0.6.0
 */