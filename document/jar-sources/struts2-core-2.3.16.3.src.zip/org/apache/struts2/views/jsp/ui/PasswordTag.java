/*    */ package org.apache.struts2.views.jsp.ui;
/*    */ 
/*    */ import com.opensymphony.xwork2.util.ValueStack;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.apache.struts2.components.Component;
/*    */ import org.apache.struts2.components.Password;
/*    */ 
/*    */ public class PasswordTag extends TextFieldTag
/*    */ {
/*    */   private static final long serialVersionUID = 6802043323617377573L;
/*    */   protected String showPassword;
/*    */ 
/*    */   public Component getBean(ValueStack stack, HttpServletRequest req, HttpServletResponse res)
/*    */   {
/* 43 */     return new Password(stack, req, res);
/*    */   }
/*    */ 
/*    */   protected void populateParams() {
/* 47 */     super.populateParams();
/*    */ 
/* 49 */     ((Password)this.component).setShowPassword(this.showPassword);
/*    */   }
/*    */ 
/*    */   public void setShow(String showPassword) {
/* 53 */     this.showPassword = showPassword;
/*    */   }
/*    */ 
/*    */   public void setShowPassword(String showPassword) {
/* 57 */     this.showPassword = showPassword;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.views.jsp.ui.PasswordTag
 * JD-Core Version:    0.6.0
 */