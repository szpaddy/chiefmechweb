/*     */ package org.apache.struts2.views.jsp;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionContext;
/*     */ import com.opensymphony.xwork2.ActionInvocation;
/*     */ import com.opensymphony.xwork2.ActionProxy;
/*     */ import com.opensymphony.xwork2.config.ConfigurationException;
/*     */ import com.opensymphony.xwork2.inject.Container;
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import com.opensymphony.xwork2.util.ValueStackFactory;
/*     */ import java.util.Map;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.servlet.jsp.PageContext;
/*     */ import org.apache.struts2.RequestUtils;
/*     */ import org.apache.struts2.dispatcher.ApplicationMap;
/*     */ import org.apache.struts2.dispatcher.Dispatcher;
/*     */ import org.apache.struts2.dispatcher.RequestMap;
/*     */ import org.apache.struts2.dispatcher.SessionMap;
/*     */ import org.apache.struts2.dispatcher.mapper.ActionMapper;
/*     */ import org.apache.struts2.dispatcher.mapper.ActionMapping;
/*     */ import org.apache.struts2.util.AttributeMap;
/*     */ 
/*     */ public class TagUtils
/*     */ {
/*     */   public static ValueStack getStack(PageContext pageContext)
/*     */   {
/*  52 */     HttpServletRequest req = (HttpServletRequest)pageContext.getRequest();
/*  53 */     ValueStack stack = (ValueStack)req.getAttribute("struts.valueStack");
/*     */ 
/*  55 */     if (stack == null)
/*     */     {
/*  57 */       HttpServletResponse res = (HttpServletResponse)pageContext.getResponse();
/*  58 */       Dispatcher du = Dispatcher.getInstance();
/*  59 */       if (du == null) {
/*  60 */         throw new ConfigurationException("The Struts dispatcher cannot be found.  This is usually caused by using Struts tags without the associated filter. Struts tags are only usable when the request has passed through its servlet filter, which initializes the Struts dispatcher needed for this tag.");
/*     */       }
/*     */ 
/*  64 */       stack = ((ValueStackFactory)du.getContainer().getInstance(ValueStackFactory.class)).createValueStack();
/*  65 */       Map extraContext = du.createContextMap(new RequestMap(req), req.getParameterMap(), new SessionMap(req), new ApplicationMap(pageContext.getServletContext()), req, res, pageContext.getServletContext());
/*     */ 
/*  72 */       extraContext.put("com.opensymphony.xwork2.dispatcher.PageContext", pageContext);
/*  73 */       stack.getContext().putAll(extraContext);
/*  74 */       req.setAttribute("struts.valueStack", stack);
/*     */ 
/*  77 */       ActionContext.setContext(new ActionContext(stack.getContext()));
/*     */     }
/*     */     else {
/*  80 */       Map context = stack.getContext();
/*  81 */       context.put("com.opensymphony.xwork2.dispatcher.PageContext", pageContext);
/*     */ 
/*  83 */       AttributeMap attrMap = new AttributeMap(context);
/*  84 */       context.put("attr", attrMap);
/*     */     }
/*     */ 
/*  87 */     return stack;
/*     */   }
/*     */ 
/*     */   public static String buildNamespace(ActionMapper mapper, ValueStack stack, HttpServletRequest request) {
/*  91 */     ActionContext context = new ActionContext(stack.getContext());
/*  92 */     ActionInvocation invocation = context.getActionInvocation();
/*     */ 
/*  94 */     if (invocation == null) {
/*  95 */       ActionMapping mapping = mapper.getMapping(request, Dispatcher.getInstance().getConfigurationManager());
/*     */ 
/*  98 */       if (mapping != null) {
/*  99 */         return mapping.getNamespace();
/*     */       }
/*     */ 
/* 105 */       String path = RequestUtils.getServletPath(request);
/* 106 */       return path.substring(0, path.lastIndexOf("/"));
/*     */     }
/*     */ 
/* 109 */     return invocation.getProxy().getNamespace();
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.views.jsp.TagUtils
 * JD-Core Version:    0.6.0
 */