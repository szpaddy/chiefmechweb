/*     */ package org.apache.struts2.views.jsp.iterator;
/*     */ 
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import com.opensymphony.xwork2.util.logging.Logger;
/*     */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*     */ import java.util.Map;
/*     */ import javax.servlet.jsp.JspException;
/*     */ import org.apache.struts2.util.IteratorGenerator;
/*     */ import org.apache.struts2.util.IteratorGenerator.Converter;
/*     */ import org.apache.struts2.views.annotations.StrutsTag;
/*     */ import org.apache.struts2.views.annotations.StrutsTagAttribute;
/*     */ import org.apache.struts2.views.jsp.StrutsBodyTagSupport;
/*     */ 
/*     */ @StrutsTag(name="generator", tldTagClass="org.apache.struts2.views.jsp.iterator.IteratorGeneratorTag", description="Generate an iterator for a iterable source.")
/*     */ public class IteratorGeneratorTag extends StrutsBodyTagSupport
/*     */ {
/*     */   private static final long serialVersionUID = 2968037295463973936L;
/*     */   public static final String DEFAULT_SEPARATOR = ",";
/* 137 */   private static final Logger LOG = LoggerFactory.getLogger(IteratorGeneratorTag.class);
/*     */   String countAttr;
/*     */   String separatorAttr;
/*     */   String valueAttr;
/*     */   String converterAttr;
/*     */   String var;
/* 144 */   IteratorGenerator iteratorGenerator = null;
/*     */ 
/* 148 */   @StrutsTagAttribute(type="Integer", description="The max number entries to be in the iterator")
/*     */   public void setCount(String count) { this.countAttr = count;
/*     */   }
/*     */ 
/*     */   @StrutsTagAttribute(required=true, description="The separator to be used in separating the <i>val</i> into entries of the iterator")
/*     */   public void setSeparator(String separator)
/*     */   {
/* 157 */     this.separatorAttr = separator;
/*     */   }
/*     */ 
/*     */   @StrutsTagAttribute(required=true, description="The source to be parsed into an iterator")
/*     */   public void setVal(String val)
/*     */   {
/* 166 */     this.valueAttr = val;
/*     */   }
/*     */ 
/*     */   @StrutsTagAttribute(type="org.apache.struts2.util.IteratorGenerator.Converter", description="The converter to convert the String entry parsed from <i>val</i> into an object")
/*     */   public void setConverter(String aConverter) {
/* 172 */     this.converterAttr = aConverter;
/*     */   }
/*     */   @StrutsTagAttribute(description="Deprecated. Use 'var' instead")
/*     */   public void setId(String string) {
/* 177 */     setVar(string);
/*     */   }
/*     */   @StrutsTagAttribute(description="The name to store the resultant iterator into page context, if such name is supplied")
/*     */   public void setVar(String var) {
/* 182 */     this.var = var;
/*     */   }
/*     */ 
/*     */   public int doStartTag()
/*     */     throws JspException
/*     */   {
/* 188 */     Object value = findValue(this.valueAttr);
/*     */ 
/* 191 */     String separator = ",";
/* 192 */     if ((this.separatorAttr != null) && (this.separatorAttr.length() > 0)) {
/* 193 */       separator = findString(this.separatorAttr);
/*     */     }
/*     */ 
/* 198 */     int count = 0;
/* 199 */     if ((this.countAttr != null) && (this.countAttr.length() > 0)) {
/* 200 */       Object countObj = findValue(this.countAttr);
/* 201 */       if ((countObj instanceof Number)) {
/* 202 */         count = ((Number)countObj).intValue();
/*     */       }
/* 204 */       else if ((countObj instanceof String)) {
/*     */         try {
/* 206 */           count = Integer.parseInt((String)countObj);
/*     */         }
/*     */         catch (NumberFormatException e) {
/* 209 */           if (LOG.isWarnEnabled()) {
/* 210 */             LOG.warn("unable to convert count attribute [" + countObj + "] to number, ignore count attribute", e, new String[0]);
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 217 */     IteratorGenerator.Converter converter = null;
/* 218 */     if ((this.converterAttr != null) && (this.converterAttr.length() > 0)) {
/* 219 */       converter = (IteratorGenerator.Converter)findValue(this.converterAttr);
/*     */     }
/*     */ 
/* 223 */     this.iteratorGenerator = new IteratorGenerator();
/* 224 */     this.iteratorGenerator.setValues(value);
/* 225 */     this.iteratorGenerator.setCount(count);
/* 226 */     this.iteratorGenerator.setSeparator(separator);
/* 227 */     this.iteratorGenerator.setConverter(converter);
/*     */ 
/* 229 */     this.iteratorGenerator.execute();
/*     */ 
/* 233 */     getStack().push(this.iteratorGenerator);
/* 234 */     if ((this.var != null) && (this.var.length() > 0)) {
/* 235 */       getStack().getContext().put(this.var, this.iteratorGenerator);
/*     */     }
/*     */ 
/* 238 */     return 1;
/*     */   }
/*     */ 
/*     */   public int doEndTag() throws JspException
/*     */   {
/* 243 */     getStack().pop();
/* 244 */     this.iteratorGenerator = null;
/*     */ 
/* 246 */     return 6;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.views.jsp.iterator.IteratorGeneratorTag
 * JD-Core Version:    0.6.0
 */