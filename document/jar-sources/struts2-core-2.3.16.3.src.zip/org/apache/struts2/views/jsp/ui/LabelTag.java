/*    */ package org.apache.struts2.views.jsp.ui;
/*    */ 
/*    */ import com.opensymphony.xwork2.util.ValueStack;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.apache.struts2.components.Component;
/*    */ import org.apache.struts2.components.Label;
/*    */ 
/*    */ public class LabelTag extends AbstractUITag
/*    */ {
/*    */   private static final long serialVersionUID = 4008321310097730458L;
/*    */   protected String forAttr;
/*    */ 
/*    */   public Component getBean(ValueStack stack, HttpServletRequest req, HttpServletResponse res)
/*    */   {
/* 43 */     return new Label(stack, req, res);
/*    */   }
/*    */ 
/*    */   protected void populateParams() {
/* 47 */     super.populateParams();
/*    */ 
/* 49 */     ((Label)this.component).setFor(this.forAttr);
/*    */   }
/*    */ 
/*    */   public void setFor(String aFor) {
/* 53 */     this.forAttr = aFor;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.views.jsp.ui.LabelTag
 * JD-Core Version:    0.6.0
 */