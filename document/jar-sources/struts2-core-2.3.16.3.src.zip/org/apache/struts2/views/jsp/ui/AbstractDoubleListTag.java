/*     */ package org.apache.struts2.views.jsp.ui;
/*     */ 
/*     */ import org.apache.struts2.components.DoubleListUIBean;
/*     */ 
/*     */ public abstract class AbstractDoubleListTag extends AbstractRequiredListTag
/*     */ {
/*     */   protected String doubleList;
/*     */   protected String doubleListKey;
/*     */   protected String doubleListValue;
/*     */   protected String doubleListCssClass;
/*     */   protected String doubleListCssStyle;
/*     */   protected String doubleListTitle;
/*     */   protected String doubleName;
/*     */   protected String doubleValue;
/*     */   protected String formName;
/*     */   protected String emptyOption;
/*     */   protected String headerKey;
/*     */   protected String headerValue;
/*     */   protected String multiple;
/*     */   protected String size;
/*     */   protected String doubleId;
/*     */   protected String doubleDisabled;
/*     */   protected String doubleMultiple;
/*     */   protected String doubleSize;
/*     */   protected String doubleHeaderKey;
/*     */   protected String doubleHeaderValue;
/*     */   protected String doubleEmptyOption;
/*     */   protected String doubleCssClass;
/*     */   protected String doubleCssStyle;
/*     */   protected String doubleOnclick;
/*     */   protected String doubleOndblclick;
/*     */   protected String doubleOnmousedown;
/*     */   protected String doubleOnmouseup;
/*     */   protected String doubleOnmouseover;
/*     */   protected String doubleOnmousemove;
/*     */   protected String doubleOnmouseout;
/*     */   protected String doubleOnfocus;
/*     */   protected String doubleOnblur;
/*     */   protected String doubleOnkeypress;
/*     */   protected String doubleOnkeydown;
/*     */   protected String doubleOnkeyup;
/*     */   protected String doubleOnselect;
/*     */   protected String doubleOnchange;
/*     */   protected String doubleAccesskey;
/*     */ 
/*     */   protected void populateParams()
/*     */   {
/*  76 */     super.populateParams();
/*     */ 
/*  78 */     DoubleListUIBean bean = (DoubleListUIBean)this.component;
/*  79 */     bean.setDoubleList(this.doubleList);
/*  80 */     bean.setDoubleListKey(this.doubleListKey);
/*  81 */     bean.setDoubleListValue(this.doubleListValue);
/*  82 */     bean.setDoubleListCssClass(this.doubleListCssClass);
/*  83 */     bean.setDoubleListCssStyle(this.doubleListCssStyle);
/*  84 */     bean.setDoubleListTitle(this.doubleListTitle);
/*  85 */     bean.setDoubleName(this.doubleName);
/*  86 */     bean.setDoubleValue(this.doubleValue);
/*  87 */     bean.setFormName(this.formName);
/*     */ 
/*  89 */     bean.setDoubleId(this.doubleId);
/*  90 */     bean.setDoubleDisabled(this.doubleDisabled);
/*  91 */     bean.setDoubleMultiple(this.doubleMultiple);
/*  92 */     bean.setDoubleSize(this.doubleSize);
/*  93 */     bean.setDoubleHeaderKey(this.doubleHeaderKey);
/*  94 */     bean.setDoubleHeaderValue(this.doubleHeaderValue);
/*  95 */     bean.setDoubleEmptyOption(this.doubleEmptyOption);
/*     */ 
/*  97 */     bean.setDoubleCssClass(this.doubleCssClass);
/*  98 */     bean.setDoubleCssStyle(this.doubleCssStyle);
/*     */ 
/* 100 */     bean.setDoubleOnclick(this.doubleOnclick);
/* 101 */     bean.setDoubleOndblclick(this.doubleOndblclick);
/* 102 */     bean.setDoubleOnmousedown(this.doubleOnmousedown);
/* 103 */     bean.setDoubleOnmouseup(this.doubleOnmouseup);
/* 104 */     bean.setDoubleOnmouseover(this.doubleOnmouseover);
/* 105 */     bean.setDoubleOnmousemove(this.doubleOnmousemove);
/* 106 */     bean.setDoubleOnmouseout(this.doubleOnmouseout);
/* 107 */     bean.setDoubleOnfocus(this.doubleOnfocus);
/* 108 */     bean.setDoubleOnblur(this.doubleOnblur);
/* 109 */     bean.setDoubleOnkeypress(this.doubleOnkeypress);
/* 110 */     bean.setDoubleOnkeydown(this.doubleOnkeydown);
/* 111 */     bean.setDoubleOnkeyup(this.doubleOnkeyup);
/* 112 */     bean.setDoubleOnselect(this.doubleOnselect);
/* 113 */     bean.setDoubleOnchange(this.doubleOnchange);
/*     */ 
/* 115 */     bean.setDoubleAccesskey(this.doubleAccesskey);
/*     */ 
/* 117 */     bean.setEmptyOption(this.emptyOption);
/* 118 */     bean.setHeaderKey(this.headerKey);
/* 119 */     bean.setHeaderValue(this.headerValue);
/* 120 */     bean.setMultiple(this.multiple);
/* 121 */     bean.setSize(this.size);
/*     */   }
/*     */ 
/*     */   public void setDoubleList(String list) {
/* 125 */     this.doubleList = list;
/*     */   }
/*     */ 
/*     */   public void setDoubleListKey(String listKey) {
/* 129 */     this.doubleListKey = listKey;
/*     */   }
/*     */ 
/*     */   public void setDoubleListValue(String listValue) {
/* 133 */     this.doubleListValue = listValue;
/*     */   }
/*     */ 
/*     */   public void setDoubleListCssClass(String doubleListCssClass) {
/* 137 */     this.doubleListCssClass = doubleListCssClass;
/*     */   }
/*     */ 
/*     */   public void setDoubleListCssStyle(String doubleListCssStyle) {
/* 141 */     this.doubleListCssStyle = doubleListCssStyle;
/*     */   }
/*     */ 
/*     */   public void setDoubleListTitle(String doubleListTitle) {
/* 145 */     this.doubleListTitle = doubleListTitle;
/*     */   }
/*     */ 
/*     */   public void setDoubleName(String aName) {
/* 149 */     this.doubleName = aName;
/*     */   }
/*     */ 
/*     */   public void setDoubleValue(String doubleValue) {
/* 153 */     this.doubleValue = doubleValue;
/*     */   }
/*     */ 
/*     */   public void setFormName(String formName) {
/* 157 */     this.formName = formName;
/*     */   }
/*     */ 
/*     */   public String getDoubleCssClass() {
/* 161 */     return this.doubleCssClass;
/*     */   }
/*     */ 
/*     */   public void setDoubleCssClass(String doubleCssClass) {
/* 165 */     this.doubleCssClass = doubleCssClass;
/*     */   }
/*     */ 
/*     */   public String getDoubleCssStyle() {
/* 169 */     return this.doubleCssStyle;
/*     */   }
/*     */ 
/*     */   public void setDoubleCssStyle(String doubleCssStyle) {
/* 173 */     this.doubleCssStyle = doubleCssStyle;
/*     */   }
/*     */ 
/*     */   public String getDoubleDisabled() {
/* 177 */     return this.doubleDisabled;
/*     */   }
/*     */ 
/*     */   public void setDoubleDisabled(String doubleDisabled) {
/* 181 */     this.doubleDisabled = doubleDisabled;
/*     */   }
/*     */ 
/*     */   public String getDoubleEmptyOption() {
/* 185 */     return this.doubleEmptyOption;
/*     */   }
/*     */ 
/*     */   public void setDoubleEmptyOption(String doubleEmptyOption) {
/* 189 */     this.doubleEmptyOption = doubleEmptyOption;
/*     */   }
/*     */ 
/*     */   public String getDoubleHeaderKey() {
/* 193 */     return this.doubleHeaderKey;
/*     */   }
/*     */ 
/*     */   public void setDoubleHeaderKey(String doubleHeaderKey) {
/* 197 */     this.doubleHeaderKey = doubleHeaderKey;
/*     */   }
/*     */ 
/*     */   public String getDoubleHeaderValue() {
/* 201 */     return this.doubleHeaderValue;
/*     */   }
/*     */ 
/*     */   public void setDoubleHeaderValue(String doubleHeaderValue) {
/* 205 */     this.doubleHeaderValue = doubleHeaderValue;
/*     */   }
/*     */ 
/*     */   public String getDoubleId() {
/* 209 */     return this.doubleId;
/*     */   }
/*     */ 
/*     */   public void setDoubleId(String doubleId) {
/* 213 */     this.doubleId = doubleId;
/*     */   }
/*     */ 
/*     */   public String getDoubleMultiple() {
/* 217 */     return this.doubleMultiple;
/*     */   }
/*     */ 
/*     */   public void setDoubleMultiple(String doubleMultiple) {
/* 221 */     this.doubleMultiple = doubleMultiple;
/*     */   }
/*     */ 
/*     */   public String getDoubleOnblur() {
/* 225 */     return this.doubleOnblur;
/*     */   }
/*     */ 
/*     */   public void setDoubleOnblur(String doubleOnblur) {
/* 229 */     this.doubleOnblur = doubleOnblur;
/*     */   }
/*     */ 
/*     */   public String getDoubleOnchange() {
/* 233 */     return this.doubleOnchange;
/*     */   }
/*     */ 
/*     */   public void setDoubleOnchange(String doubleOnchange) {
/* 237 */     this.doubleOnchange = doubleOnchange;
/*     */   }
/*     */ 
/*     */   public String getDoubleOnclick() {
/* 241 */     return this.doubleOnclick;
/*     */   }
/*     */ 
/*     */   public void setDoubleOnclick(String doubleOnclick) {
/* 245 */     this.doubleOnclick = doubleOnclick;
/*     */   }
/*     */ 
/*     */   public String getDoubleOndblclick() {
/* 249 */     return this.doubleOndblclick;
/*     */   }
/*     */ 
/*     */   public void setDoubleOndblclick(String doubleOndblclick) {
/* 253 */     this.doubleOndblclick = doubleOndblclick;
/*     */   }
/*     */ 
/*     */   public String getDoubleOnfocus() {
/* 257 */     return this.doubleOnfocus;
/*     */   }
/*     */ 
/*     */   public void setDoubleOnfocus(String doubleOnfocus) {
/* 261 */     this.doubleOnfocus = doubleOnfocus;
/*     */   }
/*     */ 
/*     */   public String getDoubleOnkeydown() {
/* 265 */     return this.doubleOnkeydown;
/*     */   }
/*     */ 
/*     */   public void setDoubleOnkeydown(String doubleOnkeydown) {
/* 269 */     this.doubleOnkeydown = doubleOnkeydown;
/*     */   }
/*     */ 
/*     */   public String getDoubleOnkeypress() {
/* 273 */     return this.doubleOnkeypress;
/*     */   }
/*     */ 
/*     */   public void setDoubleOnkeypress(String doubleOnkeypress) {
/* 277 */     this.doubleOnkeypress = doubleOnkeypress;
/*     */   }
/*     */ 
/*     */   public String getDoubleOnkeyup() {
/* 281 */     return this.doubleOnkeyup;
/*     */   }
/*     */ 
/*     */   public void setDoubleOnkeyup(String doubleOnkeyup) {
/* 285 */     this.doubleOnkeyup = doubleOnkeyup;
/*     */   }
/*     */ 
/*     */   public String getDoubleOnmousedown() {
/* 289 */     return this.doubleOnmousedown;
/*     */   }
/*     */ 
/*     */   public void setDoubleOnmousedown(String doubleOnmousedown) {
/* 293 */     this.doubleOnmousedown = doubleOnmousedown;
/*     */   }
/*     */ 
/*     */   public String getDoubleOnmousemove() {
/* 297 */     return this.doubleOnmousemove;
/*     */   }
/*     */ 
/*     */   public void setDoubleOnmousemove(String doubleOnmousemove) {
/* 301 */     this.doubleOnmousemove = doubleOnmousemove;
/*     */   }
/*     */ 
/*     */   public String getDoubleOnmouseout() {
/* 305 */     return this.doubleOnmouseout;
/*     */   }
/*     */ 
/*     */   public void setDoubleOnmouseout(String doubleOnmouseout) {
/* 309 */     this.doubleOnmouseout = doubleOnmouseout;
/*     */   }
/*     */ 
/*     */   public String getDoubleOnmouseover() {
/* 313 */     return this.doubleOnmouseover;
/*     */   }
/*     */ 
/*     */   public void setDoubleOnmouseover(String doubleOnmouseover) {
/* 317 */     this.doubleOnmouseover = doubleOnmouseover;
/*     */   }
/*     */ 
/*     */   public String getDoubleOnmouseup() {
/* 321 */     return this.doubleOnmouseup;
/*     */   }
/*     */ 
/*     */   public void setDoubleOnmouseup(String doubleOnmouseup) {
/* 325 */     this.doubleOnmouseup = doubleOnmouseup;
/*     */   }
/*     */ 
/*     */   public String getDoubleOnselect() {
/* 329 */     return this.doubleOnselect;
/*     */   }
/*     */ 
/*     */   public void setDoubleOnselect(String doubleOnselect) {
/* 333 */     this.doubleOnselect = doubleOnselect;
/*     */   }
/*     */ 
/*     */   public String getDoubleSize() {
/* 337 */     return this.doubleSize;
/*     */   }
/*     */ 
/*     */   public void setDoubleSize(String doubleSize) {
/* 341 */     this.doubleSize = doubleSize;
/*     */   }
/*     */ 
/*     */   public String getDoubleList() {
/* 345 */     return this.doubleList;
/*     */   }
/*     */ 
/*     */   public String getDoubleListKey() {
/* 349 */     return this.doubleListKey;
/*     */   }
/*     */ 
/*     */   public String getDoubleListValue() {
/* 353 */     return this.doubleListValue;
/*     */   }
/*     */ 
/*     */   public String getDoubleName() {
/* 357 */     return this.doubleName;
/*     */   }
/*     */ 
/*     */   public String getDoubleValue() {
/* 361 */     return this.doubleValue;
/*     */   }
/*     */ 
/*     */   public String getFormName() {
/* 365 */     return this.formName;
/*     */   }
/*     */ 
/*     */   public void setEmptyOption(String emptyOption) {
/* 369 */     this.emptyOption = emptyOption;
/*     */   }
/*     */ 
/*     */   public void setHeaderKey(String headerKey) {
/* 373 */     this.headerKey = headerKey;
/*     */   }
/*     */ 
/*     */   public void setHeaderValue(String headerValue) {
/* 377 */     this.headerValue = headerValue;
/*     */   }
/*     */ 
/*     */   public void setMultiple(String multiple) {
/* 381 */     this.multiple = multiple;
/*     */   }
/*     */ 
/*     */   public void setSize(String size) {
/* 385 */     this.size = size;
/*     */   }
/*     */ 
/*     */   public void setDoubleAccesskey(String doubleAccesskey) {
/* 389 */     this.doubleAccesskey = doubleAccesskey;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.views.jsp.ui.AbstractDoubleListTag
 * JD-Core Version:    0.6.0
 */