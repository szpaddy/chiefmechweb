/*     */ package org.apache.struts2.views.jsp.ui;
/*     */ 
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.struts2.components.Component;
/*     */ import org.apache.struts2.components.Form;
/*     */ 
/*     */ public class FormTag extends AbstractClosingTag
/*     */ {
/*     */   private static final long serialVersionUID = 2792301046860819658L;
/*     */   protected String action;
/*     */   protected String target;
/*     */   protected String enctype;
/*     */   protected String method;
/*     */   protected String namespace;
/*     */   protected String validate;
/*     */   protected String onsubmit;
/*     */   protected String onreset;
/*     */   protected String portletMode;
/*     */   protected String windowState;
/*     */   protected String acceptcharset;
/*     */   protected String focusElement;
/*  52 */   protected boolean includeContext = true;
/*     */ 
/*     */   public Component getBean(ValueStack stack, HttpServletRequest req, HttpServletResponse res) {
/*  55 */     return new Form(stack, req, res);
/*     */   }
/*     */ 
/*     */   protected void populateParams() {
/*  59 */     super.populateParams();
/*  60 */     Form form = (Form)this.component;
/*  61 */     form.setAction(this.action);
/*  62 */     form.setTarget(this.target);
/*  63 */     form.setEnctype(this.enctype);
/*  64 */     form.setMethod(this.method);
/*  65 */     form.setNamespace(this.namespace);
/*  66 */     form.setValidate(this.validate);
/*  67 */     form.setOnreset(this.onreset);
/*  68 */     form.setOnsubmit(this.onsubmit);
/*  69 */     form.setPortletMode(this.portletMode);
/*  70 */     form.setWindowState(this.windowState);
/*  71 */     form.setAcceptcharset(this.acceptcharset);
/*  72 */     form.setFocusElement(this.focusElement);
/*  73 */     form.setIncludeContext(this.includeContext);
/*     */   }
/*     */ 
/*     */   public void setAction(String action)
/*     */   {
/*  78 */     this.action = action;
/*     */   }
/*     */ 
/*     */   public void setTarget(String target) {
/*  82 */     this.target = target;
/*     */   }
/*     */ 
/*     */   public void setEnctype(String enctype) {
/*  86 */     this.enctype = enctype;
/*     */   }
/*     */ 
/*     */   public void setMethod(String method) {
/*  90 */     this.method = method;
/*     */   }
/*     */ 
/*     */   public void setNamespace(String namespace) {
/*  94 */     this.namespace = namespace;
/*     */   }
/*     */ 
/*     */   public void setValidate(String validate) {
/*  98 */     this.validate = validate;
/*     */   }
/*     */ 
/*     */   public void setOnsubmit(String onsubmit) {
/* 102 */     this.onsubmit = onsubmit;
/*     */   }
/*     */ 
/*     */   public void setOnreset(String onreset) {
/* 106 */     this.onreset = onreset;
/*     */   }
/*     */ 
/*     */   public void setPortletMode(String portletMode) {
/* 110 */     this.portletMode = portletMode;
/*     */   }
/*     */ 
/*     */   public void setWindowState(String windowState) {
/* 114 */     this.windowState = windowState;
/*     */   }
/*     */ 
/*     */   public void setAcceptcharset(String acceptcharset) {
/* 118 */     this.acceptcharset = acceptcharset;
/*     */   }
/*     */ 
/*     */   public void setFocusElement(String focusElement) {
/* 122 */     this.focusElement = focusElement;
/*     */   }
/*     */ 
/*     */   public void setIncludeContext(boolean includeContext) {
/* 126 */     this.includeContext = includeContext;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.views.jsp.ui.FormTag
 * JD-Core Version:    0.6.0
 */