/*    */ package org.apache.struts2.views.jsp.iterator;
/*    */ 
/*    */ import com.opensymphony.xwork2.util.ValueStack;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.apache.struts2.components.AppendIterator;
/*    */ import org.apache.struts2.components.Component;
/*    */ import org.apache.struts2.views.jsp.ContextBeanTag;
/*    */ 
/*    */ public class AppendIteratorTag extends ContextBeanTag
/*    */ {
/*    */   private static final long serialVersionUID = -6017337859763283691L;
/*    */ 
/*    */   public Component getBean(ValueStack stack, HttpServletRequest req, HttpServletResponse res)
/*    */   {
/* 45 */     return new AppendIterator(stack);
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.views.jsp.iterator.AppendIteratorTag
 * JD-Core Version:    0.6.0
 */