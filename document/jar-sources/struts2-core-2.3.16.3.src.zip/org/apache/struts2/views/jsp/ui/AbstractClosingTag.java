/*    */ package org.apache.struts2.views.jsp.ui;
/*    */ 
/*    */ import org.apache.struts2.components.ClosingUIBean;
/*    */ 
/*    */ public abstract class AbstractClosingTag extends AbstractUITag
/*    */ {
/*    */   protected String openTemplate;
/*    */ 
/*    */   protected void populateParams()
/*    */   {
/* 32 */     super.populateParams();
/*    */ 
/* 34 */     ((ClosingUIBean)this.component).setOpenTemplate(this.openTemplate);
/*    */   }
/*    */ 
/*    */   public void setOpenTemplate(String openTemplate) {
/* 38 */     this.openTemplate = openTemplate;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.views.jsp.ui.AbstractClosingTag
 * JD-Core Version:    0.6.0
 */