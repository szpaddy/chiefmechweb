/*    */ package org.apache.struts2.views.jsp.ui;
/*    */ 
/*    */ import com.opensymphony.xwork2.util.ValueStack;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.apache.struts2.components.ComboBox;
/*    */ import org.apache.struts2.components.Component;
/*    */ 
/*    */ public class ComboBoxTag extends TextFieldTag
/*    */ {
/*    */   private static final long serialVersionUID = 3509392460170385605L;
/*    */   protected String list;
/*    */   protected String listKey;
/*    */   protected String listValue;
/*    */   protected String headerKey;
/*    */   protected String headerValue;
/*    */   protected String emptyOption;
/*    */ 
/*    */   public void setEmptyOption(String emptyOption)
/*    */   {
/* 47 */     this.emptyOption = emptyOption;
/*    */   }
/*    */ 
/*    */   public void setHeaderKey(String headerKey) {
/* 51 */     this.headerKey = headerKey;
/*    */   }
/*    */ 
/*    */   public void setHeaderValue(String headerValue) {
/* 55 */     this.headerValue = headerValue;
/*    */   }
/*    */ 
/*    */   public void setListKey(String listKey) {
/* 59 */     this.listKey = listKey;
/*    */   }
/*    */ 
/*    */   public void setListValue(String listValue) {
/* 63 */     this.listValue = listValue;
/*    */   }
/*    */ 
/*    */   public Component getBean(ValueStack stack, HttpServletRequest req, HttpServletResponse res) {
/* 67 */     return new ComboBox(stack, req, res);
/*    */   }
/*    */ 
/*    */   protected void populateParams() {
/* 71 */     super.populateParams();
/*    */ 
/* 73 */     ((ComboBox)this.component).setList(this.list);
/* 74 */     ((ComboBox)this.component).setListKey(this.listKey);
/* 75 */     ((ComboBox)this.component).setListValue(this.listValue);
/* 76 */     ((ComboBox)this.component).setHeaderKey(this.headerKey);
/* 77 */     ((ComboBox)this.component).setHeaderValue(this.headerValue);
/* 78 */     ((ComboBox)this.component).setEmptyOption(this.emptyOption);
/*    */   }
/*    */ 
/*    */   public void setList(String list) {
/* 82 */     this.list = list;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.views.jsp.ui.ComboBoxTag
 * JD-Core Version:    0.6.0
 */