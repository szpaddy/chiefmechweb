/*     */ package org.apache.struts2.views.jsp.ui;
/*     */ 
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.struts2.components.Anchor;
/*     */ import org.apache.struts2.components.Component;
/*     */ 
/*     */ public class AnchorTag extends AbstractClosingTag
/*     */ {
/*     */   private static final long serialVersionUID = -1034616578492431113L;
/*     */   protected String href;
/*     */   protected String includeParams;
/*     */   protected String scheme;
/*     */   protected String action;
/*     */   protected String namespace;
/*     */   protected String method;
/*     */   protected String encode;
/*     */   protected String includeContext;
/*     */   protected String escapeAmp;
/*     */   protected String portletMode;
/*     */   protected String windowState;
/*     */   protected String portletUrlType;
/*     */   protected String anchor;
/*     */   protected String forceAddSchemeHostAndPort;
/*     */ 
/*     */   public Component getBean(ValueStack stack, HttpServletRequest req, HttpServletResponse res)
/*     */   {
/*  55 */     return new Anchor(stack, req, res);
/*     */   }
/*     */ 
/*     */   protected void populateParams() {
/*  59 */     super.populateParams();
/*     */ 
/*  61 */     Anchor tag = (Anchor)this.component;
/*  62 */     tag.setHref(this.href);
/*  63 */     tag.setIncludeParams(this.includeParams);
/*  64 */     tag.setScheme(this.scheme);
/*  65 */     tag.setValue(this.value);
/*  66 */     tag.setMethod(this.method);
/*  67 */     tag.setNamespace(this.namespace);
/*  68 */     tag.setAction(this.action);
/*  69 */     tag.setPortletMode(this.portletMode);
/*  70 */     tag.setPortletUrlType(this.portletUrlType);
/*  71 */     tag.setWindowState(this.windowState);
/*  72 */     tag.setAnchor(this.anchor);
/*     */ 
/*  74 */     if (this.encode != null) {
/*  75 */       tag.setEncode(Boolean.valueOf(this.encode).booleanValue());
/*     */     }
/*  77 */     if (this.includeContext != null) {
/*  78 */       tag.setIncludeContext(Boolean.valueOf(this.includeContext).booleanValue());
/*     */     }
/*  80 */     if (this.escapeAmp != null) {
/*  81 */       tag.setEscapeAmp(Boolean.valueOf(this.escapeAmp).booleanValue());
/*     */     }
/*  83 */     if (this.forceAddSchemeHostAndPort != null)
/*  84 */       tag.setForceAddSchemeHostAndPort(Boolean.valueOf(this.forceAddSchemeHostAndPort).booleanValue());
/*     */   }
/*     */ 
/*     */   public void setHref(String href)
/*     */   {
/*  89 */     this.href = href;
/*     */   }
/*     */ 
/*     */   public void setEncode(String encode) {
/*  93 */     this.encode = encode;
/*     */   }
/*     */ 
/*     */   public void setIncludeContext(String includeContext) {
/*  97 */     this.includeContext = includeContext;
/*     */   }
/*     */ 
/*     */   public void setEscapeAmp(String escapeAmp) {
/* 101 */     this.escapeAmp = escapeAmp;
/*     */   }
/*     */ 
/*     */   public void setIncludeParams(String name) {
/* 105 */     this.includeParams = name;
/*     */   }
/*     */ 
/*     */   public void setAction(String action) {
/* 109 */     this.action = action;
/*     */   }
/*     */ 
/*     */   public void setNamespace(String namespace) {
/* 113 */     this.namespace = namespace;
/*     */   }
/*     */ 
/*     */   public void setMethod(String method) {
/* 117 */     this.method = method;
/*     */   }
/*     */ 
/*     */   public void setScheme(String scheme) {
/* 121 */     this.scheme = scheme;
/*     */   }
/*     */ 
/*     */   public void setValue(String value) {
/* 125 */     this.value = value;
/*     */   }
/*     */ 
/*     */   public void setPortletMode(String portletMode) {
/* 129 */     this.portletMode = portletMode;
/*     */   }
/*     */ 
/*     */   public void setPortletUrlType(String portletUrlType) {
/* 133 */     this.portletUrlType = portletUrlType;
/*     */   }
/*     */ 
/*     */   public void setWindowState(String windowState) {
/* 137 */     this.windowState = windowState;
/*     */   }
/*     */ 
/*     */   public void setAnchor(String anchor) {
/* 141 */     this.anchor = anchor;
/*     */   }
/*     */ 
/*     */   public void setForceAddSchemeHostAndPort(String forceAddSchemeHostAndPort) {
/* 145 */     this.forceAddSchemeHostAndPort = forceAddSchemeHostAndPort;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.views.jsp.ui.AnchorTag
 * JD-Core Version:    0.6.0
 */