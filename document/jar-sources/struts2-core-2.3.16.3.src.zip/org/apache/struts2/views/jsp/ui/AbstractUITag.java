/*     */ package org.apache.struts2.views.jsp.ui;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.tagext.DynamicAttributes;
/*     */ import org.apache.commons.lang3.ObjectUtils;
/*     */ import org.apache.struts2.components.UIBean;
/*     */ import org.apache.struts2.util.ComponentUtils;
/*     */ import org.apache.struts2.views.jsp.ComponentTagSupport;
/*     */ 
/*     */ public abstract class AbstractUITag extends ComponentTagSupport
/*     */   implements DynamicAttributes
/*     */ {
/*     */   protected String cssClass;
/*     */   protected String cssErrorClass;
/*     */   protected String cssStyle;
/*     */   protected String cssErrorStyle;
/*     */   protected String title;
/*     */   protected String disabled;
/*     */   protected String label;
/*     */   protected String labelSeparator;
/*     */   protected String labelPosition;
/*     */   protected String requiredPosition;
/*     */   protected String errorPosition;
/*     */   protected String name;
/*     */   protected String requiredLabel;
/*     */   protected String tabindex;
/*     */   protected String value;
/*     */   protected String template;
/*     */   protected String theme;
/*     */   protected String templateDir;
/*     */   protected String onclick;
/*     */   protected String ondblclick;
/*     */   protected String onmousedown;
/*     */   protected String onmouseup;
/*     */   protected String onmouseover;
/*     */   protected String onmousemove;
/*     */   protected String onmouseout;
/*     */   protected String onfocus;
/*     */   protected String onblur;
/*     */   protected String onkeypress;
/*     */   protected String onkeydown;
/*     */   protected String onkeyup;
/*     */   protected String onselect;
/*     */   protected String onchange;
/*     */   protected String accesskey;
/*     */   protected String id;
/*     */   protected String key;
/*     */   protected String tooltip;
/*     */   protected String tooltipConfig;
/*     */   protected String javascriptTooltip;
/*     */   protected String tooltipDelay;
/*     */   protected String tooltipCssClass;
/*     */   protected String tooltipIconPath;
/*  85 */   protected Map<String, Object> dynamicAttributes = new HashMap();
/*     */ 
/*     */   protected void populateParams() {
/*  88 */     super.populateParams();
/*     */ 
/*  90 */     UIBean uiBean = (UIBean)this.component;
/*  91 */     uiBean.setCssClass(this.cssClass);
/*  92 */     uiBean.setCssStyle(this.cssStyle);
/*  93 */     uiBean.setCssErrorClass(this.cssErrorClass);
/*  94 */     uiBean.setCssErrorStyle(this.cssErrorStyle);
/*  95 */     uiBean.setTitle(this.title);
/*  96 */     uiBean.setDisabled(this.disabled);
/*  97 */     uiBean.setLabel(this.label);
/*  98 */     uiBean.setLabelSeparator(this.labelSeparator);
/*  99 */     uiBean.setLabelposition(this.labelPosition);
/* 100 */     uiBean.setRequiredPosition(this.requiredPosition);
/* 101 */     uiBean.setErrorPosition(this.errorPosition);
/* 102 */     uiBean.setName(this.name);
/* 103 */     uiBean.setRequiredLabel(this.requiredLabel);
/* 104 */     uiBean.setTabindex(this.tabindex);
/* 105 */     uiBean.setValue(this.value);
/* 106 */     uiBean.setTemplate(this.template);
/* 107 */     uiBean.setTheme(this.theme);
/* 108 */     uiBean.setTemplateDir(this.templateDir);
/* 109 */     uiBean.setOnclick(this.onclick);
/* 110 */     uiBean.setOndblclick(this.ondblclick);
/* 111 */     uiBean.setOnmousedown(this.onmousedown);
/* 112 */     uiBean.setOnmouseup(this.onmouseup);
/* 113 */     uiBean.setOnmouseover(this.onmouseover);
/* 114 */     uiBean.setOnmousemove(this.onmousemove);
/* 115 */     uiBean.setOnmouseout(this.onmouseout);
/* 116 */     uiBean.setOnfocus(this.onfocus);
/* 117 */     uiBean.setOnblur(this.onblur);
/* 118 */     uiBean.setOnkeypress(this.onkeypress);
/* 119 */     uiBean.setOnkeydown(this.onkeydown);
/* 120 */     uiBean.setOnkeyup(this.onkeyup);
/* 121 */     uiBean.setOnselect(this.onselect);
/* 122 */     uiBean.setOnchange(this.onchange);
/* 123 */     uiBean.setTooltip(this.tooltip);
/* 124 */     uiBean.setTooltipConfig(this.tooltipConfig);
/* 125 */     uiBean.setJavascriptTooltip(this.javascriptTooltip);
/* 126 */     uiBean.setTooltipCssClass(this.tooltipCssClass);
/* 127 */     uiBean.setTooltipDelay(this.tooltipDelay);
/* 128 */     uiBean.setTooltipIconPath(this.tooltipIconPath);
/* 129 */     uiBean.setAccesskey(this.accesskey);
/* 130 */     uiBean.setKey(this.key);
/* 131 */     uiBean.setId(this.id);
/*     */ 
/* 133 */     uiBean.setDynamicAttributes(this.dynamicAttributes);
/*     */   }
/*     */ 
/*     */   public void setId(String id) {
/* 137 */     this.id = id;
/*     */   }
/*     */ 
/*     */   public void setCssClass(String cssClass) {
/* 141 */     this.cssClass = cssClass;
/*     */   }
/*     */ 
/*     */   public void setCssStyle(String cssStyle) {
/* 145 */     this.cssStyle = cssStyle;
/*     */   }
/*     */ 
/*     */   public void setCssErrorClass(String cssErrorClass) {
/* 149 */     this.cssErrorClass = cssErrorClass;
/*     */   }
/*     */ 
/*     */   public void setCssErrorStyle(String cssErrorStyle) {
/* 153 */     this.cssErrorStyle = cssErrorStyle;
/*     */   }
/*     */ 
/*     */   public void setTitle(String title) {
/* 157 */     this.title = title;
/*     */   }
/*     */ 
/*     */   public void setDisabled(String disabled) {
/* 161 */     this.disabled = disabled;
/*     */   }
/*     */ 
/*     */   public void setLabel(String label) {
/* 165 */     this.label = label;
/*     */   }
/*     */ 
/*     */   public void setLabelposition(String labelPosition) {
/* 169 */     this.labelPosition = labelPosition;
/*     */   }
/*     */ 
/*     */   public void setRequiredPosition(String requiredPosition) {
/* 173 */     this.requiredPosition = requiredPosition;
/*     */   }
/*     */ 
/*     */   public void setErrorPosition(String errorPosition) {
/* 177 */     this.errorPosition = errorPosition;
/*     */   }
/*     */ 
/*     */   public void setName(String name) {
/* 181 */     this.name = name;
/*     */   }
/*     */ 
/*     */   public void setRequiredLabel(String requiredLabel) {
/* 185 */     this.requiredLabel = requiredLabel;
/*     */   }
/*     */ 
/*     */   public void setTabindex(String tabindex) {
/* 189 */     this.tabindex = tabindex;
/*     */   }
/*     */ 
/*     */   public void setValue(String value) {
/* 193 */     this.value = value;
/*     */   }
/*     */ 
/*     */   public void setTemplateDir(String templateDir) {
/* 197 */     this.templateDir = templateDir;
/*     */   }
/*     */ 
/*     */   public void setTemplate(String template) {
/* 201 */     this.template = template;
/*     */   }
/*     */ 
/*     */   public void setTheme(String theme) {
/* 205 */     this.theme = theme;
/*     */   }
/*     */ 
/*     */   public void setOnclick(String onclick) {
/* 209 */     this.onclick = onclick;
/*     */   }
/*     */ 
/*     */   public void setOndblclick(String ondblclick) {
/* 213 */     this.ondblclick = ondblclick;
/*     */   }
/*     */ 
/*     */   public void setOnmousedown(String onmousedown) {
/* 217 */     this.onmousedown = onmousedown;
/*     */   }
/*     */ 
/*     */   public void setOnmouseup(String onmouseup) {
/* 221 */     this.onmouseup = onmouseup;
/*     */   }
/*     */ 
/*     */   public void setOnmouseover(String onmouseover) {
/* 225 */     this.onmouseover = onmouseover;
/*     */   }
/*     */ 
/*     */   public void setOnmousemove(String onmousemove) {
/* 229 */     this.onmousemove = onmousemove;
/*     */   }
/*     */ 
/*     */   public void setOnmouseout(String onmouseout) {
/* 233 */     this.onmouseout = onmouseout;
/*     */   }
/*     */ 
/*     */   public void setOnfocus(String onfocus) {
/* 237 */     this.onfocus = onfocus;
/*     */   }
/*     */ 
/*     */   public void setOnblur(String onblur) {
/* 241 */     this.onblur = onblur;
/*     */   }
/*     */ 
/*     */   public void setOnkeypress(String onkeypress) {
/* 245 */     this.onkeypress = onkeypress;
/*     */   }
/*     */ 
/*     */   public void setOnkeydown(String onkeydown) {
/* 249 */     this.onkeydown = onkeydown;
/*     */   }
/*     */ 
/*     */   public void setOnkeyup(String onkeyup) {
/* 253 */     this.onkeyup = onkeyup;
/*     */   }
/*     */ 
/*     */   public void setOnselect(String onselect) {
/* 257 */     this.onselect = onselect;
/*     */   }
/*     */ 
/*     */   public void setOnchange(String onchange) {
/* 261 */     this.onchange = onchange;
/*     */   }
/*     */ 
/*     */   public void setTooltip(String tooltip) {
/* 265 */     this.tooltip = tooltip;
/*     */   }
/*     */ 
/*     */   public void setTooltipConfig(String tooltipConfig) {
/* 269 */     this.tooltipConfig = tooltipConfig;
/*     */   }
/*     */ 
/*     */   public void setAccesskey(String accesskey) {
/* 273 */     this.accesskey = accesskey;
/*     */   }
/*     */ 
/*     */   public void setKey(String key) {
/* 277 */     this.key = key;
/*     */   }
/*     */ 
/*     */   public void setJavascriptTooltip(String javascriptTooltip) {
/* 281 */     this.javascriptTooltip = javascriptTooltip;
/*     */   }
/*     */ 
/*     */   public void setTooltipCssClass(String tooltipCssClass) {
/* 285 */     this.tooltipCssClass = tooltipCssClass;
/*     */   }
/*     */ 
/*     */   public void setTooltipDelay(String tooltipDelay) {
/* 289 */     this.tooltipDelay = tooltipDelay;
/*     */   }
/*     */ 
/*     */   public void setTooltipIconPath(String tooltipIconPath) {
/* 293 */     this.tooltipIconPath = tooltipIconPath;
/*     */   }
/*     */ 
/*     */   public void setLabelSeparator(String labelSeparator) {
/* 297 */     this.labelSeparator = labelSeparator;
/*     */   }
/*     */ 
/*     */   public void setDynamicAttribute(String uri, String localName, Object value) throws JspException {
/* 301 */     if ((ComponentUtils.altSyntax(getStack())) && (ComponentUtils.isExpression(value)))
/* 302 */       this.dynamicAttributes.put(localName, String.valueOf(ObjectUtils.defaultIfNull(findValue(value.toString()), value)));
/*     */     else
/* 304 */       this.dynamicAttributes.put(localName, value);
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.views.jsp.ui.AbstractUITag
 * JD-Core Version:    0.6.0
 */