/*    */ package org.apache.struts2.views.jsp;
/*    */ 
/*    */ public class IteratorStatus
/*    */ {
/*    */   protected StatusState state;
/*    */ 
/*    */   public IteratorStatus(StatusState aState)
/*    */   {
/* 56 */     this.state = aState;
/*    */   }
/*    */ 
/*    */   public int getCount() {
/* 60 */     return this.state.index + 1;
/*    */   }
/*    */ 
/*    */   public boolean isEven() {
/* 64 */     return (this.state.index + 1) % 2 == 0;
/*    */   }
/*    */ 
/*    */   public boolean isFirst() {
/* 68 */     return this.state.index == 0;
/*    */   }
/*    */ 
/*    */   public int getIndex() {
/* 72 */     return this.state.index;
/*    */   }
/*    */ 
/*    */   public boolean isLast() {
/* 76 */     return this.state.last;
/*    */   }
/*    */ 
/*    */   public boolean isOdd() {
/* 80 */     return (this.state.index + 1) % 2 != 0;
/*    */   }
/*    */ 
/*    */   public int modulus(int operand) {
/* 84 */     return (this.state.index + 1) % operand;
/*    */   }
/*    */ 
/*    */   public static class StatusState {
/* 88 */     boolean last = false;
/* 89 */     int index = 0;
/*    */ 
/*    */     public void setLast(boolean isLast) {
/* 92 */       this.last = isLast;
/*    */     }
/*    */ 
/*    */     public void next() {
/* 96 */       this.index += 1;
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.views.jsp.IteratorStatus
 * JD-Core Version:    0.6.0
 */