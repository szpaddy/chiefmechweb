/*    */ package org.apache.struts2.views.jsp.ui;
/*    */ 
/*    */ import org.apache.struts2.components.ListUIBean;
/*    */ 
/*    */ public abstract class AbstractRequiredListTag extends AbstractListTag
/*    */ {
/*    */   protected void populateParams()
/*    */   {
/* 32 */     super.populateParams();
/*    */ 
/* 34 */     ListUIBean listUIBean = (ListUIBean)this.component;
/* 35 */     listUIBean.setThrowExceptionOnNullValueAttribute(true);
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.views.jsp.ui.AbstractRequiredListTag
 * JD-Core Version:    0.6.0
 */