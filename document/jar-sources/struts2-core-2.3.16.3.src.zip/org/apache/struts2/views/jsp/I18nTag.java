/*    */ package org.apache.struts2.views.jsp;
/*    */ 
/*    */ import com.opensymphony.xwork2.util.ValueStack;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.apache.struts2.components.Component;
/*    */ import org.apache.struts2.components.I18n;
/*    */ 
/*    */ public class I18nTag extends ComponentTagSupport
/*    */ {
/*    */   private static final long serialVersionUID = -7914587341936116887L;
/*    */   protected String name;
/*    */ 
/*    */   public Component getBean(ValueStack stack, HttpServletRequest req, HttpServletResponse res)
/*    */   {
/* 43 */     return new I18n(stack);
/*    */   }
/*    */ 
/*    */   protected void populateParams() {
/* 47 */     super.populateParams();
/*    */ 
/* 49 */     ((I18n)this.component).setName(this.name);
/*    */   }
/*    */ 
/*    */   public void setName(String name) {
/* 53 */     this.name = name;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.views.jsp.I18nTag
 * JD-Core Version:    0.6.0
 */