/*    */ package org.apache.struts2.views.jsp;
/*    */ 
/*    */ import com.opensymphony.xwork2.util.ValueStack;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import javax.servlet.jsp.JspException;
/*    */ import javax.servlet.jsp.PageContext;
/*    */ import javax.servlet.jsp.tagext.BodyContent;
/*    */ import org.apache.struts2.components.Component;
/*    */ import org.apache.struts2.components.IteratorComponent;
/*    */ 
/*    */ public class IteratorTag extends ContextBeanTag
/*    */ {
/*    */   private static final long serialVersionUID = -1827978135193581901L;
/*    */   protected String statusAttr;
/*    */   protected String value;
/*    */   protected String begin;
/*    */   protected String end;
/*    */   protected String step;
/*    */ 
/*    */   public Component getBean(ValueStack stack, HttpServletRequest req, HttpServletResponse res)
/*    */   {
/* 46 */     return new IteratorComponent(stack);
/*    */   }
/*    */ 
/*    */   protected void populateParams() {
/* 50 */     super.populateParams();
/*    */ 
/* 52 */     IteratorComponent tag = (IteratorComponent)getComponent();
/* 53 */     tag.setStatus(this.statusAttr);
/* 54 */     tag.setValue(this.value);
/* 55 */     tag.setBegin(this.begin);
/* 56 */     tag.setEnd(this.end);
/* 57 */     tag.setStep(this.step);
/*    */   }
/*    */ 
/*    */   public void setStatus(String status) {
/* 61 */     this.statusAttr = status;
/*    */   }
/*    */ 
/*    */   public void setValue(String value) {
/* 65 */     this.value = value;
/*    */   }
/*    */ 
/*    */   public void setBegin(String begin) {
/* 69 */     this.begin = begin;
/*    */   }
/*    */ 
/*    */   public void setEnd(String end) {
/* 73 */     this.end = end;
/*    */   }
/*    */ 
/*    */   public void setStep(String step) {
/* 77 */     this.step = step;
/*    */   }
/*    */ 
/*    */   public int doEndTag() throws JspException {
/* 81 */     this.component = null;
/* 82 */     return 6;
/*    */   }
/*    */ 
/*    */   public int doAfterBody() throws JspException {
/* 86 */     boolean again = this.component.end(this.pageContext.getOut(), getBody());
/*    */ 
/* 88 */     if (again) {
/* 89 */       return 2;
/*    */     }
/* 91 */     if (this.bodyContent != null) {
/*    */       try {
/* 93 */         this.bodyContent.writeOut(this.bodyContent.getEnclosingWriter());
/*    */       } catch (Exception e) {
/* 95 */         throw new JspException(e);
/*    */       }
/*    */     }
/* 98 */     return 0;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.views.jsp.IteratorTag
 * JD-Core Version:    0.6.0
 */