/*    */ package org.apache.struts2.views.jsp;
/*    */ 
/*    */ import com.opensymphony.xwork2.util.ValueStack;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.apache.struts2.components.Component;
/*    */ import org.apache.struts2.components.Date;
/*    */ 
/*    */ public class DateTag extends ContextBeanTag
/*    */ {
/*    */   private static final long serialVersionUID = -6216963123295613440L;
/*    */   protected String name;
/*    */   protected String format;
/*    */   protected boolean nice;
/*    */   protected String timezone;
/*    */ 
/*    */   public Component getBean(ValueStack stack, HttpServletRequest req, HttpServletResponse res)
/*    */   {
/* 44 */     return new Date(stack);
/*    */   }
/*    */ 
/*    */   protected void populateParams() {
/* 48 */     super.populateParams();
/* 49 */     Date d = (Date)this.component;
/* 50 */     d.setName(this.name);
/* 51 */     d.setFormat(this.format);
/* 52 */     d.setNice(this.nice);
/* 53 */     d.setTimezone(this.timezone);
/*    */   }
/*    */ 
/*    */   public void setFormat(String format) {
/* 57 */     this.format = format;
/*    */   }
/*    */ 
/*    */   public void setNice(boolean nice) {
/* 61 */     this.nice = nice;
/*    */   }
/*    */ 
/*    */   public void setName(String name) {
/* 65 */     this.name = name;
/*    */   }
/*    */ 
/*    */   public void setTimezone(String timezone) {
/* 69 */     this.timezone = timezone;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.views.jsp.DateTag
 * JD-Core Version:    0.6.0
 */