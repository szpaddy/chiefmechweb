/*    */ package org.apache.struts2.views.jsp.ui;
/*    */ 
/*    */ import com.opensymphony.xwork2.util.ValueStack;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.apache.struts2.components.Component;
/*    */ import org.apache.struts2.components.OptGroup;
/*    */ import org.apache.struts2.views.jsp.ComponentTagSupport;
/*    */ 
/*    */ public class OptGroupTag extends ComponentTagSupport
/*    */ {
/*    */   private static final long serialVersionUID = 7367401003498678762L;
/*    */   protected String list;
/*    */   protected String label;
/*    */   protected String disabled;
/*    */   protected String listKey;
/*    */   protected String listValue;
/*    */ 
/*    */   public Component getBean(ValueStack stack, HttpServletRequest req, HttpServletResponse res)
/*    */   {
/* 47 */     return new OptGroup(stack, req, res);
/*    */   }
/*    */ 
/*    */   protected void populateParams() {
/* 51 */     super.populateParams();
/*    */ 
/* 53 */     OptGroup optGroup = (OptGroup)this.component;
/* 54 */     optGroup.setList(this.list);
/* 55 */     optGroup.setLabel(this.label);
/* 56 */     optGroup.setDisabled(this.disabled);
/* 57 */     optGroup.setListKey(this.listKey);
/* 58 */     optGroup.setListValue(this.listValue);
/*    */   }
/*    */ 
/*    */   public void setList(String list) {
/* 62 */     this.list = list;
/*    */   }
/*    */ 
/*    */   public void setLabel(String label) {
/* 66 */     this.label = label;
/*    */   }
/*    */ 
/*    */   public void setDisabled(String disabled) {
/* 70 */     this.disabled = disabled;
/*    */   }
/*    */ 
/*    */   public void setListKey(String listKey) {
/* 74 */     this.listKey = listKey;
/*    */   }
/*    */ 
/*    */   public void setListValue(String listValue) {
/* 78 */     this.listValue = listValue;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.views.jsp.ui.OptGroupTag
 * JD-Core Version:    0.6.0
 */