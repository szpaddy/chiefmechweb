/*     */ package org.apache.struts2.views.jsp.iterator;
/*     */ 
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import java.util.Comparator;
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.PageContext;
/*     */ import org.apache.struts2.util.MakeIterator;
/*     */ import org.apache.struts2.util.SortIteratorFilter;
/*     */ import org.apache.struts2.views.annotations.StrutsTag;
/*     */ import org.apache.struts2.views.annotations.StrutsTagAttribute;
/*     */ import org.apache.struts2.views.jsp.StrutsBodyTagSupport;
/*     */ 
/*     */ @StrutsTag(name="sort", tldTagClass="org.apache.struts2.views.jsp.iterator.SortIteratorTag", description="Sort a List using a Comparator both passed in as the tag attribute.")
/*     */ public class SortIteratorTag extends StrutsBodyTagSupport
/*     */ {
/*     */   private static final long serialVersionUID = -7835719609764092235L;
/*     */   String comparatorAttr;
/*     */   String sourceAttr;
/*     */   String var;
/* 100 */   SortIteratorFilter sortIteratorFilter = null;
/*     */ 
/* 104 */   @StrutsTagAttribute(required=true, type="java.util.Comparator", description="The comparator to use")
/*     */   public void setComparator(String comparator) { this.comparatorAttr = comparator; }
/*     */ 
/*     */   @StrutsTagAttribute(description="The iterable source to sort")
/*     */   public void setSource(String source) {
/* 109 */     this.sourceAttr = source;
/*     */   }
/*     */   @StrutsTagAttribute(description="Deprecated. Use 'var' instead")
/*     */   public void setId(String string) {
/* 114 */     setVar(string);
/*     */   }
/*     */   @StrutsTagAttribute(description="The name to store the resultant iterator into page context, if such name is supplied")
/*     */   public void setVar(String var) {
/* 119 */     this.var = var;
/*     */   }
/*     */ 
/*     */   public int doStartTag()
/*     */     throws JspException
/*     */   {
/*     */     Object srcToSort;
/*     */     Object srcToSort;
/* 125 */     if (this.sourceAttr == null)
/* 126 */       srcToSort = findValue("top");
/*     */     else {
/* 128 */       srcToSort = findValue(this.sourceAttr);
/*     */     }
/* 130 */     if (!MakeIterator.isIterable(srcToSort)) {
/* 131 */       throw new JspException("source [" + srcToSort + "] is not iteratable");
/*     */     }
/*     */ 
/* 135 */     Object comparatorObj = findValue(this.comparatorAttr);
/* 136 */     if (!(comparatorObj instanceof Comparator)) {
/* 137 */       throw new JspException("comparator [" + comparatorObj + "] does not implements Comparator interface");
/*     */     }
/* 139 */     Comparator c = (Comparator)findValue(this.comparatorAttr);
/*     */ 
/* 142 */     this.sortIteratorFilter = new SortIteratorFilter();
/* 143 */     this.sortIteratorFilter.setComparator(c);
/* 144 */     this.sortIteratorFilter.setSource(srcToSort);
/* 145 */     this.sortIteratorFilter.execute();
/*     */ 
/* 148 */     getStack().push(this.sortIteratorFilter);
/* 149 */     if ((this.var != null) && (this.var.length() > 0)) {
/* 150 */       this.pageContext.setAttribute(this.var, this.sortIteratorFilter);
/*     */     }
/*     */ 
/* 153 */     return 1;
/*     */   }
/*     */ 
/*     */   public int doEndTag() throws JspException {
/* 157 */     int returnVal = super.doEndTag();
/*     */ 
/* 160 */     getStack().pop();
/* 161 */     this.sortIteratorFilter = null;
/*     */ 
/* 163 */     return returnVal;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.views.jsp.iterator.SortIteratorTag
 * JD-Core Version:    0.6.0
 */