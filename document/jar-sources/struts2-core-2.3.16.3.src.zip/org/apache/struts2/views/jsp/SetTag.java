/*    */ package org.apache.struts2.views.jsp;
/*    */ 
/*    */ import com.opensymphony.xwork2.util.ValueStack;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.apache.struts2.components.Component;
/*    */ import org.apache.struts2.components.Set;
/*    */ 
/*    */ public class SetTag extends ContextBeanTag
/*    */ {
/*    */   private static final long serialVersionUID = -5074213926790716974L;
/*    */   protected String scope;
/*    */   protected String value;
/*    */ 
/*    */   public Component getBean(ValueStack stack, HttpServletRequest req, HttpServletResponse res)
/*    */   {
/* 44 */     return new Set(stack);
/*    */   }
/*    */ 
/*    */   protected void populateParams() {
/* 48 */     super.populateParams();
/*    */ 
/* 50 */     Set set = (Set)this.component;
/* 51 */     set.setScope(this.scope);
/* 52 */     set.setValue(this.value);
/*    */   }
/*    */ 
/*    */   public void setName(String name) {
/* 56 */     setVar(name);
/*    */   }
/*    */ 
/*    */   public void setScope(String scope) {
/* 60 */     this.scope = scope;
/*    */   }
/*    */ 
/*    */   public void setValue(String value) {
/* 64 */     this.value = value;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.views.jsp.SetTag
 * JD-Core Version:    0.6.0
 */