/*    */ package org.apache.struts2.views.jsp;
/*    */ 
/*    */ import com.opensymphony.xwork2.util.ValueStack;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.apache.struts2.components.Component;
/*    */ import org.apache.struts2.components.Param;
/*    */ 
/*    */ public class ParamTag extends ComponentTagSupport
/*    */ {
/*    */   private static final long serialVersionUID = -968332732207156408L;
/*    */   protected String name;
/*    */   protected String value;
/*    */   protected boolean suppressEmptyParameters;
/*    */ 
/*    */   public Component getBean(ValueStack stack, HttpServletRequest req, HttpServletResponse res)
/*    */   {
/* 43 */     return new Param(stack);
/*    */   }
/*    */ 
/*    */   protected void populateParams() {
/* 47 */     super.populateParams();
/*    */ 
/* 49 */     Param param = (Param)this.component;
/* 50 */     param.setName(this.name);
/* 51 */     param.setValue(this.value);
/* 52 */     param.setSuppressEmptyParameters(this.suppressEmptyParameters);
/*    */   }
/*    */ 
/*    */   public void setName(String name) {
/* 56 */     this.name = name;
/*    */   }
/*    */ 
/*    */   public void setValue(String value) {
/* 60 */     this.value = value;
/*    */   }
/*    */ 
/*    */   public void setSuppressEmptyParameters(boolean suppressEmptyParameters) {
/* 64 */     this.suppressEmptyParameters = suppressEmptyParameters;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.views.jsp.ParamTag
 * JD-Core Version:    0.6.0
 */