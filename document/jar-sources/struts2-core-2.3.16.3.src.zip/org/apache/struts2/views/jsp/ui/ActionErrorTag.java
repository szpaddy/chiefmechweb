/*    */ package org.apache.struts2.views.jsp.ui;
/*    */ 
/*    */ import com.opensymphony.xwork2.util.ValueStack;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.apache.struts2.components.ActionError;
/*    */ import org.apache.struts2.components.Component;
/*    */ 
/*    */ public class ActionErrorTag extends AbstractUITag
/*    */ {
/*    */   private static final long serialVersionUID = -3710234378022378639L;
/* 40 */   private boolean escape = true;
/*    */ 
/*    */   public Component getBean(ValueStack stack, HttpServletRequest req, HttpServletResponse res) {
/* 43 */     return new ActionError(stack, req, res);
/*    */   }
/*    */ 
/*    */   protected void populateParams() {
/* 47 */     super.populateParams();
/*    */ 
/* 49 */     ActionError error = (ActionError)this.component;
/* 50 */     error.setEscape(this.escape);
/*    */   }
/*    */ 
/*    */   public void setEscape(boolean escape) {
/* 54 */     this.escape = escape;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.views.jsp.ui.ActionErrorTag
 * JD-Core Version:    0.6.0
 */