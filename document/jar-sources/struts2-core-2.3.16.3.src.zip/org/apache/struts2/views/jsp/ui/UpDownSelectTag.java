/*     */ package org.apache.struts2.views.jsp.ui;
/*     */ 
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.struts2.components.Component;
/*     */ import org.apache.struts2.components.UpDownSelect;
/*     */ 
/*     */ public class UpDownSelectTag extends SelectTag
/*     */ {
/*     */   private static final long serialVersionUID = -8136573053799541353L;
/*     */   protected String allowMoveUp;
/*     */   protected String allowMoveDown;
/*     */   protected String allowSelectAll;
/*     */   protected String moveUpLabel;
/*     */   protected String moveDownLabel;
/*     */   protected String selectAllLabel;
/*     */ 
/*     */   public Component getBean(ValueStack stack, HttpServletRequest req, HttpServletResponse res)
/*     */   {
/*  49 */     return new UpDownSelect(stack, req, res);
/*     */   }
/*     */ 
/*     */   protected void populateParams() {
/*  53 */     super.populateParams();
/*     */ 
/*  55 */     UpDownSelect c = (UpDownSelect)this.component;
/*     */ 
/*  57 */     c.setAllowMoveUp(this.allowMoveUp);
/*  58 */     c.setAllowMoveDown(this.allowMoveDown);
/*  59 */     c.setAllowSelectAll(this.allowSelectAll);
/*     */ 
/*  61 */     c.setMoveUpLabel(this.moveUpLabel);
/*  62 */     c.setMoveDownLabel(this.moveDownLabel);
/*  63 */     c.setSelectAllLabel(this.selectAllLabel);
/*     */   }
/*     */ 
/*     */   public String getAllowMoveUp()
/*     */   {
/*  69 */     return this.allowMoveUp;
/*     */   }
/*     */ 
/*     */   public void setAllowMoveUp(String allowMoveUp) {
/*  73 */     this.allowMoveUp = allowMoveUp;
/*     */   }
/*     */ 
/*     */   public String getAllowMoveDown()
/*     */   {
/*  79 */     return this.allowMoveDown;
/*     */   }
/*     */ 
/*     */   public void setAllowMoveDown(String allowMoveDown) {
/*  83 */     this.allowMoveDown = allowMoveDown;
/*     */   }
/*     */ 
/*     */   public String getAllowSelectAll()
/*     */   {
/*  89 */     return this.allowSelectAll;
/*     */   }
/*     */ 
/*     */   public void setAllowSelectAll(String allowSelectAll) {
/*  93 */     this.allowSelectAll = allowSelectAll;
/*     */   }
/*     */ 
/*     */   public String getMoveUpLabel()
/*     */   {
/*  98 */     return this.moveUpLabel;
/*     */   }
/*     */ 
/*     */   public void setMoveUpLabel(String moveUpLabel) {
/* 102 */     this.moveUpLabel = moveUpLabel;
/*     */   }
/*     */ 
/*     */   public String getMoveDownLabel()
/*     */   {
/* 108 */     return this.moveDownLabel;
/*     */   }
/*     */ 
/*     */   public void setMoveDownLabel(String moveDownLabel) {
/* 112 */     this.moveDownLabel = moveDownLabel;
/*     */   }
/*     */ 
/*     */   public String getSelectAllLabel()
/*     */   {
/* 118 */     return this.selectAllLabel;
/*     */   }
/*     */ 
/*     */   public void setSelectAllLabel(String selectAllLabel) {
/* 122 */     this.selectAllLabel = selectAllLabel;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.views.jsp.ui.UpDownSelectTag
 * JD-Core Version:    0.6.0
 */