/*     */ package org.apache.struts2.views.jsp.ui;
/*     */ 
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.struts2.components.Component;
/*     */ import org.apache.struts2.components.InputTransferSelect;
/*     */ 
/*     */ public class InputTransferSelectTag extends AbstractListTag
/*     */ {
/*     */   private static final long serialVersionUID = 250474334495763536L;
/*     */   protected String size;
/*     */   protected String multiple;
/*     */   protected String allowRemoveAll;
/*     */   protected String allowUpDown;
/*     */   protected String leftTitle;
/*     */   protected String rightTitle;
/*     */   protected String buttonCssClass;
/*     */   protected String buttonCssStyle;
/*     */   protected String addLabel;
/*     */   protected String removeLabel;
/*     */   protected String removeAllLabel;
/*     */   protected String upLabel;
/*     */   protected String downLabel;
/*     */   protected String headerKey;
/*     */   protected String headerValue;
/*     */ 
/*     */   public Component getBean(ValueStack stack, HttpServletRequest req, HttpServletResponse res)
/*     */   {
/*  60 */     return new InputTransferSelect(stack, req, res);
/*     */   }
/*     */ 
/*     */   protected void populateParams() {
/*  64 */     super.populateParams();
/*     */ 
/*  66 */     InputTransferSelect inputTransferSelect = (InputTransferSelect)this.component;
/*  67 */     inputTransferSelect.setSize(this.size);
/*  68 */     inputTransferSelect.setMultiple(this.multiple);
/*  69 */     inputTransferSelect.setAllowRemoveAll(this.allowRemoveAll);
/*  70 */     inputTransferSelect.setAllowUpDown(this.allowUpDown);
/*  71 */     inputTransferSelect.setLeftTitle(this.leftTitle);
/*  72 */     inputTransferSelect.setRightTitle(this.rightTitle);
/*     */ 
/*  74 */     inputTransferSelect.setButtonCssClass(this.buttonCssClass);
/*  75 */     inputTransferSelect.setButtonCssStyle(this.buttonCssStyle);
/*     */ 
/*  77 */     inputTransferSelect.setAddLabel(this.addLabel);
/*  78 */     inputTransferSelect.setRemoveLabel(this.removeLabel);
/*  79 */     inputTransferSelect.setRemoveAllLabel(this.removeAllLabel);
/*  80 */     inputTransferSelect.setUpLabel(this.upLabel);
/*  81 */     inputTransferSelect.setDownLabel(this.downLabel);
/*  82 */     inputTransferSelect.setHeaderKey(this.headerKey);
/*  83 */     inputTransferSelect.setHeaderValue(this.headerValue);
/*     */   }
/*     */ 
/*     */   public String getSize()
/*     */   {
/*  88 */     return this.size;
/*     */   }
/*     */ 
/*     */   public void setSize(String size) {
/*  92 */     this.size = size;
/*     */   }
/*     */ 
/*     */   public String getMultiple() {
/*  96 */     return this.multiple;
/*     */   }
/*     */ 
/*     */   public void setMultiple(String multiple) {
/* 100 */     this.multiple = multiple;
/*     */   }
/*     */ 
/*     */   public String getAllowRemoveAll() {
/* 104 */     return this.allowRemoveAll;
/*     */   }
/*     */ 
/*     */   public void setAllowRemoveAll(String allowRemoveAll) {
/* 108 */     this.allowRemoveAll = allowRemoveAll;
/*     */   }
/*     */ 
/*     */   public String getAllowUpDown() {
/* 112 */     return this.allowUpDown;
/*     */   }
/*     */ 
/*     */   public void setAllowUpDown(String allowUpDown) {
/* 116 */     this.allowUpDown = allowUpDown;
/*     */   }
/*     */ 
/*     */   public String getLeftTitle() {
/* 120 */     return this.leftTitle;
/*     */   }
/*     */ 
/*     */   public void setLeftTitle(String leftTitle) {
/* 124 */     this.leftTitle = leftTitle;
/*     */   }
/*     */ 
/*     */   public String getRightTitle() {
/* 128 */     return this.rightTitle;
/*     */   }
/*     */ 
/*     */   public void setRightTitle(String rightTitle) {
/* 132 */     this.rightTitle = rightTitle;
/*     */   }
/*     */ 
/*     */   public String getButtonCssClass() {
/* 136 */     return this.buttonCssClass;
/*     */   }
/*     */ 
/*     */   public void setButtonCssClass(String buttonCssClass) {
/* 140 */     this.buttonCssClass = buttonCssClass;
/*     */   }
/*     */ 
/*     */   public String getButtonCssStyle() {
/* 144 */     return this.buttonCssStyle;
/*     */   }
/*     */ 
/*     */   public void setButtonCssStyle(String buttonCssStyle) {
/* 148 */     this.buttonCssStyle = buttonCssStyle;
/*     */   }
/*     */ 
/*     */   public String getAddLabel() {
/* 152 */     return this.addLabel;
/*     */   }
/*     */ 
/*     */   public void setAddLabel(String addLabel) {
/* 156 */     this.addLabel = addLabel;
/*     */   }
/*     */ 
/*     */   public String getRemoveLabel() {
/* 160 */     return this.removeLabel;
/*     */   }
/*     */ 
/*     */   public void setRemoveLabel(String removeLabel) {
/* 164 */     this.removeLabel = removeLabel;
/*     */   }
/*     */ 
/*     */   public String getRemoveAllLabel() {
/* 168 */     return this.removeAllLabel;
/*     */   }
/*     */ 
/*     */   public void setRemoveAllLabel(String removeAllLabel) {
/* 172 */     this.removeAllLabel = removeAllLabel;
/*     */   }
/*     */ 
/*     */   public String getUpLabel() {
/* 176 */     return this.upLabel;
/*     */   }
/*     */ 
/*     */   public void setUpLabel(String upLabel) {
/* 180 */     this.upLabel = upLabel;
/*     */   }
/*     */ 
/*     */   public String getDownLabel() {
/* 184 */     return this.downLabel;
/*     */   }
/*     */ 
/*     */   public void setDownLabel(String downLabel) {
/* 188 */     this.downLabel = downLabel;
/*     */   }
/*     */ 
/*     */   public String getHeaderKey() {
/* 192 */     return this.headerKey;
/*     */   }
/*     */ 
/*     */   public void setHeaderKey(String headerKey) {
/* 196 */     this.headerKey = headerKey;
/*     */   }
/*     */ 
/*     */   public String getHeaderValue() {
/* 200 */     return this.headerValue;
/*     */   }
/*     */ 
/*     */   public void setHeaderValue(String headerValue) {
/* 204 */     this.headerValue = headerValue;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.views.jsp.ui.InputTransferSelectTag
 * JD-Core Version:    0.6.0
 */