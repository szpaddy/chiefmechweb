/*    */ package org.apache.struts2.views.jsp.ui;
/*    */ 
/*    */ import com.opensymphony.xwork2.util.ValueStack;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.apache.struts2.components.Component;
/*    */ import org.apache.struts2.components.TextField;
/*    */ 
/*    */ public class TextFieldTag extends AbstractUITag
/*    */ {
/*    */   private static final long serialVersionUID = 5811285953670562288L;
/*    */   protected String maxlength;
/*    */   protected String readonly;
/*    */   protected String size;
/*    */   protected String type;
/*    */ 
/*    */   public Component getBean(ValueStack stack, HttpServletRequest req, HttpServletResponse res)
/*    */   {
/* 44 */     return new TextField(stack, req, res);
/*    */   }
/*    */ 
/*    */   protected void populateParams() {
/* 48 */     super.populateParams();
/*    */ 
/* 50 */     TextField textField = (TextField)this.component;
/* 51 */     textField.setMaxlength(this.maxlength);
/* 52 */     textField.setReadonly(this.readonly);
/* 53 */     textField.setSize(this.size);
/* 54 */     textField.setType(this.type);
/*    */   }
/*    */ 
/*    */   /** @deprecated */
/*    */   public void setMaxLength(String maxlength)
/*    */   {
/* 61 */     this.maxlength = maxlength;
/*    */   }
/*    */ 
/*    */   public void setMaxlength(String maxlength) {
/* 65 */     this.maxlength = maxlength;
/*    */   }
/*    */ 
/*    */   public void setReadonly(String readonly) {
/* 69 */     this.readonly = readonly;
/*    */   }
/*    */ 
/*    */   public void setSize(String size) {
/* 73 */     this.size = size;
/*    */   }
/*    */ 
/*    */   public void setType(String type) {
/* 77 */     this.type = type;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.views.jsp.ui.TextFieldTag
 * JD-Core Version:    0.6.0
 */