/*    */ package org.apache.struts2.views.jsp.ui;
/*    */ 
/*    */ import com.opensymphony.xwork2.util.ValueStack;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.apache.struts2.components.CheckboxList;
/*    */ import org.apache.struts2.components.Component;
/*    */ 
/*    */ public class CheckboxListTag extends AbstractRequiredListTag
/*    */ {
/*    */   private static final long serialVersionUID = 4023034029558150010L;
/*    */ 
/*    */   public Component getBean(ValueStack stack, HttpServletRequest req, HttpServletResponse res)
/*    */   {
/* 41 */     return new CheckboxList(stack, req, res);
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.views.jsp.ui.CheckboxListTag
 * JD-Core Version:    0.6.0
 */