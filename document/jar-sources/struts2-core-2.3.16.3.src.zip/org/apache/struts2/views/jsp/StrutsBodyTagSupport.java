/*    */ package org.apache.struts2.views.jsp;
/*    */ 
/*    */ import com.opensymphony.xwork2.util.TextParseUtil;
/*    */ import com.opensymphony.xwork2.util.ValueStack;
/*    */ import java.io.PrintWriter;
/*    */ import javax.servlet.jsp.tagext.BodyContent;
/*    */ import javax.servlet.jsp.tagext.BodyTagSupport;
/*    */ import org.apache.struts2.util.ComponentUtils;
/*    */ import org.apache.struts2.util.FastByteArrayOutputStream;
/*    */ 
/*    */ public class StrutsBodyTagSupport extends BodyTagSupport
/*    */ {
/*    */   private static final long serialVersionUID = -1201668454354226175L;
/*    */ 
/*    */   protected ValueStack getStack()
/*    */   {
/* 44 */     return TagUtils.getStack(this.pageContext);
/*    */   }
/*    */ 
/*    */   protected String findString(String expr) {
/* 48 */     return (String)findValue(expr, String.class);
/*    */   }
/*    */ 
/*    */   protected Object findValue(String expr) {
/* 52 */     expr = ComponentUtils.stripExpressionIfAltSyntax(getStack(), expr);
/*    */ 
/* 54 */     return getStack().findValue(expr);
/*    */   }
/*    */ 
/*    */   protected Object findValue(String expr, Class toType) {
/* 58 */     if ((ComponentUtils.altSyntax(getStack())) && (toType == String.class)) {
/* 59 */       return TextParseUtil.translateVariables('%', expr, getStack());
/*    */     }
/*    */ 
/* 62 */     expr = ComponentUtils.stripExpressionIfAltSyntax(getStack(), expr);
/*    */ 
/* 64 */     return getStack().findValue(expr, toType);
/*    */   }
/*    */ 
/*    */   protected String toString(Throwable t)
/*    */   {
/* 69 */     FastByteArrayOutputStream bout = new FastByteArrayOutputStream();
/* 70 */     PrintWriter wrt = new PrintWriter(bout);
/* 71 */     t.printStackTrace(wrt);
/* 72 */     wrt.close();
/*    */ 
/* 74 */     return bout.toString();
/*    */   }
/*    */ 
/*    */   protected String getBody() {
/* 78 */     if (this.bodyContent == null) {
/* 79 */       return "";
/*    */     }
/* 81 */     return this.bodyContent.getString().trim();
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.views.jsp.StrutsBodyTagSupport
 * JD-Core Version:    0.6.0
 */