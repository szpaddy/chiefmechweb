/*    */ package org.apache.struts2.views.jsp.ui;
/*    */ 
/*    */ import com.opensymphony.xwork2.util.ValueStack;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.apache.struts2.components.Component;
/*    */ import org.apache.struts2.components.Submit;
/*    */ 
/*    */ public class SubmitTag extends AbstractClosingTag
/*    */ {
/*    */   private static final long serialVersionUID = 2179281109958301343L;
/*    */   protected String action;
/*    */   protected String method;
/*    */   protected String align;
/*    */   protected String type;
/*    */   protected String src;
/*    */ 
/*    */   public Component getBean(ValueStack stack, HttpServletRequest req, HttpServletResponse res)
/*    */   {
/* 46 */     return new Submit(stack, req, res);
/*    */   }
/*    */ 
/*    */   protected void populateParams() {
/* 50 */     super.populateParams();
/*    */ 
/* 52 */     Submit submit = (Submit)this.component;
/* 53 */     submit.setAction(this.action);
/* 54 */     submit.setMethod(this.method);
/* 55 */     submit.setAlign(this.align);
/* 56 */     submit.setType(this.type);
/* 57 */     submit.setSrc(this.src);
/*    */   }
/*    */ 
/*    */   public void setAction(String action) {
/* 61 */     this.action = action;
/*    */   }
/*    */ 
/*    */   public void setMethod(String method) {
/* 65 */     this.method = method;
/*    */   }
/*    */ 
/*    */   public void setAlign(String align) {
/* 69 */     this.align = align;
/*    */   }
/*    */ 
/*    */   public String getType() {
/* 73 */     return this.type;
/*    */   }
/*    */ 
/*    */   public void setType(String type) {
/* 77 */     this.type = type;
/*    */   }
/*    */ 
/*    */   public void setSrc(String src) {
/* 81 */     this.src = src;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.views.jsp.ui.SubmitTag
 * JD-Core Version:    0.6.0
 */