/*    */ package org.apache.struts2.views.jsp.ui;
/*    */ 
/*    */ import com.opensymphony.xwork2.util.ValueStack;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.apache.struts2.components.Component;
/*    */ import org.apache.struts2.components.Reset;
/*    */ 
/*    */ public class ResetTag extends AbstractUITag
/*    */ {
/*    */   private static final long serialVersionUID = 4742704832277392108L;
/*    */   protected String action;
/*    */   protected String method;
/*    */   protected String align;
/*    */   protected String type;
/*    */   protected String src;
/*    */ 
/*    */   public Component getBean(ValueStack stack, HttpServletRequest req, HttpServletResponse res)
/*    */   {
/* 45 */     return new Reset(stack, req, res);
/*    */   }
/*    */ 
/*    */   protected void populateParams() {
/* 49 */     super.populateParams();
/*    */ 
/* 51 */     Reset reset = (Reset)this.component;
/* 52 */     reset.setAction(this.action);
/* 53 */     reset.setMethod(this.method);
/* 54 */     reset.setAlign(this.align);
/* 55 */     reset.setType(this.type);
/* 56 */     reset.setSrc(this.src);
/*    */   }
/*    */ 
/*    */   public void setAction(String action) {
/* 60 */     this.action = action;
/*    */   }
/*    */ 
/*    */   public void setMethod(String method) {
/* 64 */     this.method = method;
/*    */   }
/*    */ 
/*    */   public void setAlign(String align) {
/* 68 */     this.align = align;
/*    */   }
/*    */ 
/*    */   public void setType(String type) {
/* 72 */     this.type = type;
/*    */   }
/*    */ 
/*    */   public void setSrc(String src) {
/* 76 */     this.src = src;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.views.jsp.ui.ResetTag
 * JD-Core Version:    0.6.0
 */