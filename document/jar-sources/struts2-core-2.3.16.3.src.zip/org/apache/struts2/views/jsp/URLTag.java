/*     */ package org.apache.struts2.views.jsp;
/*     */ 
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.struts2.components.Component;
/*     */ import org.apache.struts2.components.URL;
/*     */ 
/*     */ public class URLTag extends ContextBeanTag
/*     */ {
/*     */   private static final long serialVersionUID = 1722460444125206226L;
/*     */   protected String includeParams;
/*     */   protected String scheme;
/*     */   protected String value;
/*     */   protected String action;
/*     */   protected String namespace;
/*     */   protected String method;
/*     */   protected String encode;
/*     */   protected String includeContext;
/*     */   protected String escapeAmp;
/*     */   protected String portletMode;
/*     */   protected String windowState;
/*     */   protected String portletUrlType;
/*     */   protected String anchor;
/*     */   protected String forceAddSchemeHostAndPort;
/*     */ 
/*     */   public Component getBean(ValueStack stack, HttpServletRequest req, HttpServletResponse res)
/*     */   {
/*  56 */     return new URL(stack, req, res);
/*     */   }
/*     */ 
/*     */   protected void populateParams() {
/*  60 */     super.populateParams();
/*     */ 
/*  62 */     URL url = (URL)this.component;
/*  63 */     url.setIncludeParams(this.includeParams);
/*  64 */     url.setScheme(this.scheme);
/*  65 */     url.setValue(this.value);
/*  66 */     url.setMethod(this.method);
/*  67 */     url.setNamespace(this.namespace);
/*  68 */     url.setAction(this.action);
/*  69 */     url.setPortletMode(this.portletMode);
/*  70 */     url.setPortletUrlType(this.portletUrlType);
/*  71 */     url.setWindowState(this.windowState);
/*  72 */     url.setAnchor(this.anchor);
/*     */ 
/*  74 */     if (this.encode != null) {
/*  75 */       url.setEncode(Boolean.valueOf(this.encode).booleanValue());
/*     */     }
/*  77 */     if (this.includeContext != null) {
/*  78 */       url.setIncludeContext(Boolean.valueOf(this.includeContext).booleanValue());
/*     */     }
/*  80 */     if (this.escapeAmp != null) {
/*  81 */       url.setEscapeAmp(Boolean.valueOf(this.escapeAmp).booleanValue());
/*     */     }
/*  83 */     if (this.forceAddSchemeHostAndPort != null)
/*  84 */       url.setForceAddSchemeHostAndPort(Boolean.valueOf(this.forceAddSchemeHostAndPort).booleanValue());
/*     */   }
/*     */ 
/*     */   public void setEncode(String encode)
/*     */   {
/*  89 */     this.encode = encode;
/*     */   }
/*     */ 
/*     */   public void setIncludeContext(String includeContext) {
/*  93 */     this.includeContext = includeContext;
/*     */   }
/*     */ 
/*     */   public void setEscapeAmp(String escapeAmp) {
/*  97 */     this.escapeAmp = escapeAmp;
/*     */   }
/*     */ 
/*     */   public void setIncludeParams(String name) {
/* 101 */     this.includeParams = name;
/*     */   }
/*     */ 
/*     */   public void setAction(String action) {
/* 105 */     this.action = action;
/*     */   }
/*     */ 
/*     */   public void setNamespace(String namespace) {
/* 109 */     this.namespace = namespace;
/*     */   }
/*     */ 
/*     */   public void setMethod(String method) {
/* 113 */     this.method = method;
/*     */   }
/*     */ 
/*     */   public void setScheme(String scheme) {
/* 117 */     this.scheme = scheme;
/*     */   }
/*     */ 
/*     */   public void setValue(String value) {
/* 121 */     this.value = value;
/*     */   }
/*     */ 
/*     */   public void setPortletMode(String portletMode) {
/* 125 */     this.portletMode = portletMode;
/*     */   }
/*     */ 
/*     */   public void setPortletUrlType(String portletUrlType) {
/* 129 */     this.portletUrlType = portletUrlType;
/*     */   }
/*     */ 
/*     */   public void setWindowState(String windowState) {
/* 133 */     this.windowState = windowState;
/*     */   }
/*     */ 
/*     */   public void setAnchor(String anchor) {
/* 137 */     this.anchor = anchor;
/*     */   }
/*     */ 
/*     */   public void setForceAddSchemeHostAndPort(String forceAddSchemeHostAndPort) {
/* 141 */     this.forceAddSchemeHostAndPort = forceAddSchemeHostAndPort;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.views.jsp.URLTag
 * JD-Core Version:    0.6.0
 */