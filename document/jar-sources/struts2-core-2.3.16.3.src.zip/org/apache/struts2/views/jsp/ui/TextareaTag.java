/*    */ package org.apache.struts2.views.jsp.ui;
/*    */ 
/*    */ import com.opensymphony.xwork2.util.ValueStack;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.apache.struts2.components.Component;
/*    */ import org.apache.struts2.components.TextArea;
/*    */ 
/*    */ public class TextareaTag extends AbstractUITag
/*    */ {
/*    */   private static final long serialVersionUID = -4107122506712927927L;
/*    */   protected String cols;
/*    */   protected String readonly;
/*    */   protected String rows;
/*    */   protected String wrap;
/*    */ 
/*    */   public Component getBean(ValueStack stack, HttpServletRequest req, HttpServletResponse res)
/*    */   {
/* 46 */     return new TextArea(stack, req, res);
/*    */   }
/*    */ 
/*    */   protected void populateParams() {
/* 50 */     super.populateParams();
/*    */ 
/* 52 */     TextArea textArea = (TextArea)this.component;
/* 53 */     textArea.setCols(this.cols);
/* 54 */     textArea.setReadonly(this.readonly);
/* 55 */     textArea.setRows(this.rows);
/* 56 */     textArea.setWrap(this.wrap);
/*    */   }
/*    */ 
/*    */   public void setCols(String cols) {
/* 60 */     this.cols = cols;
/*    */   }
/*    */ 
/*    */   public void setReadonly(String readonly) {
/* 64 */     this.readonly = readonly;
/*    */   }
/*    */ 
/*    */   public void setRows(String rows) {
/* 68 */     this.rows = rows;
/*    */   }
/*    */ 
/*    */   public void setWrap(String wrap) {
/* 72 */     this.wrap = wrap;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.views.jsp.ui.TextareaTag
 * JD-Core Version:    0.6.0
 */