/*    */ package org.apache.struts2.views.jsp.ui;
/*    */ 
/*    */ import org.apache.struts2.components.ListUIBean;
/*    */ 
/*    */ public abstract class AbstractListTag extends AbstractUITag
/*    */ {
/*    */   protected String list;
/*    */   protected String listKey;
/*    */   protected String listValue;
/*    */   protected String listCssClass;
/*    */   protected String listCssStyle;
/*    */   protected String listTitle;
/*    */ 
/*    */   protected void populateParams()
/*    */   {
/* 37 */     super.populateParams();
/*    */ 
/* 39 */     ListUIBean listUIBean = (ListUIBean)this.component;
/* 40 */     listUIBean.setList(this.list);
/* 41 */     listUIBean.setListKey(this.listKey);
/* 42 */     listUIBean.setListValue(this.listValue);
/* 43 */     listUIBean.setListCssClass(this.listCssClass);
/* 44 */     listUIBean.setListCssStyle(this.listCssStyle);
/* 45 */     listUIBean.setListTitle(this.listTitle);
/*    */   }
/*    */ 
/*    */   public void setList(String list) {
/* 49 */     this.list = list;
/*    */   }
/*    */ 
/*    */   public void setListKey(String listKey) {
/* 53 */     this.listKey = listKey;
/*    */   }
/*    */ 
/*    */   public void setListValue(String listValue) {
/* 57 */     this.listValue = listValue;
/*    */   }
/*    */ 
/*    */   public void setListCssClass(String listCssClass) {
/* 61 */     this.listCssClass = listCssClass;
/*    */   }
/*    */ 
/*    */   public void setListCssStyle(String listCssStyle) {
/* 65 */     this.listCssStyle = listCssStyle;
/*    */   }
/*    */ 
/*    */   public void setListTitle(String listTitle) {
/* 69 */     this.listTitle = listTitle;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.views.jsp.ui.AbstractListTag
 * JD-Core Version:    0.6.0
 */