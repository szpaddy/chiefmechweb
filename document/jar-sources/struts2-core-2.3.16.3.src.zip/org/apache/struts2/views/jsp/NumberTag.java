/*     */ package org.apache.struts2.views.jsp;
/*     */ 
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.struts2.components.Component;
/*     */ import org.apache.struts2.components.Number;
/*     */ 
/*     */ public class NumberTag extends ContextBeanTag
/*     */ {
/*     */   private static final long serialVersionUID = -6216963123295613440L;
/*     */   private String name;
/*     */   private String currency;
/*     */   private String type;
/*     */   private Boolean groupingUsed;
/*     */   private Integer maximumFractionDigits;
/*     */   private Integer maximumIntegerDigits;
/*     */   private Integer minimumFractionDigits;
/*     */   private Integer minimumIntegerDigits;
/*     */   private Boolean parseIntegerOnly;
/*     */   private String roundingMode;
/*     */ 
/*     */   public Component getBean(ValueStack stack, HttpServletRequest req, HttpServletResponse res)
/*     */   {
/*  50 */     return new Number(stack);
/*     */   }
/*     */ 
/*     */   protected void populateParams() {
/*  54 */     super.populateParams();
/*  55 */     Number n = (Number)this.component;
/*  56 */     n.setName(this.name);
/*  57 */     n.setCurrency(this.currency);
/*  58 */     n.setType(this.type);
/*  59 */     n.setGroupingUsed(this.groupingUsed);
/*  60 */     n.setMaximumFractionDigits(this.maximumFractionDigits);
/*  61 */     n.setMaximumIntegerDigits(this.maximumIntegerDigits);
/*  62 */     n.setMinimumFractionDigits(this.minimumFractionDigits);
/*  63 */     n.setMinimumIntegerDigits(this.minimumIntegerDigits);
/*  64 */     n.setParseIntegerOnly(this.parseIntegerOnly);
/*  65 */     n.setRoundingMode(this.roundingMode);
/*     */   }
/*     */ 
/*     */   public void setName(String name)
/*     */   {
/*  73 */     this.name = name;
/*     */   }
/*     */ 
/*     */   public void setCurrency(String currency)
/*     */   {
/*  80 */     this.currency = currency;
/*     */   }
/*     */ 
/*     */   public void setType(String type)
/*     */   {
/*  87 */     this.type = type;
/*     */   }
/*     */ 
/*     */   public void setGroupingUsed(Boolean groupingUsed)
/*     */   {
/*  94 */     this.groupingUsed = groupingUsed;
/*     */   }
/*     */ 
/*     */   public void setMaximumFractionDigits(Integer maximumFractionDigits)
/*     */   {
/* 101 */     this.maximumFractionDigits = maximumFractionDigits;
/*     */   }
/*     */ 
/*     */   public void setMaximumIntegerDigits(Integer maximumIntegerDigits)
/*     */   {
/* 108 */     this.maximumIntegerDigits = maximumIntegerDigits;
/*     */   }
/*     */ 
/*     */   public void setMinimumFractionDigits(Integer minimumFractionDigits)
/*     */   {
/* 115 */     this.minimumFractionDigits = minimumFractionDigits;
/*     */   }
/*     */ 
/*     */   public void setMinimumIntegerDigits(Integer minimumIntegerDigits)
/*     */   {
/* 122 */     this.minimumIntegerDigits = minimumIntegerDigits;
/*     */   }
/*     */ 
/*     */   public void setParseIntegerOnly(Boolean parseIntegerOnly)
/*     */   {
/* 129 */     this.parseIntegerOnly = parseIntegerOnly;
/*     */   }
/*     */ 
/*     */   public void setRoundingMode(String roundingMode)
/*     */   {
/* 136 */     this.roundingMode = roundingMode;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.views.jsp.NumberTag
 * JD-Core Version:    0.6.0
 */