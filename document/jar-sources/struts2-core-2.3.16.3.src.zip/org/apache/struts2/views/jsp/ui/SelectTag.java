/*    */ package org.apache.struts2.views.jsp.ui;
/*    */ 
/*    */ import com.opensymphony.xwork2.util.ValueStack;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.apache.struts2.components.Component;
/*    */ import org.apache.struts2.components.Select;
/*    */ 
/*    */ public class SelectTag extends AbstractRequiredListTag
/*    */ {
/*    */   private static final long serialVersionUID = 6121715260335609618L;
/*    */   protected String emptyOption;
/*    */   protected String headerKey;
/*    */   protected String headerValue;
/*    */   protected String multiple;
/*    */   protected String size;
/*    */ 
/*    */   public Component getBean(ValueStack stack, HttpServletRequest req, HttpServletResponse res)
/*    */   {
/* 47 */     return new Select(stack, req, res);
/*    */   }
/*    */ 
/*    */   protected void populateParams() {
/* 51 */     super.populateParams();
/*    */ 
/* 53 */     Select select = (Select)this.component;
/* 54 */     select.setEmptyOption(this.emptyOption);
/* 55 */     select.setHeaderKey(this.headerKey);
/* 56 */     select.setHeaderValue(this.headerValue);
/* 57 */     select.setMultiple(this.multiple);
/* 58 */     select.setSize(this.size);
/*    */   }
/*    */ 
/*    */   public void setEmptyOption(String emptyOption) {
/* 62 */     this.emptyOption = emptyOption;
/*    */   }
/*    */ 
/*    */   public void setHeaderKey(String headerKey) {
/* 66 */     this.headerKey = headerKey;
/*    */   }
/*    */ 
/*    */   public void setHeaderValue(String headerValue) {
/* 70 */     this.headerValue = headerValue;
/*    */   }
/*    */ 
/*    */   public void setMultiple(String multiple) {
/* 74 */     this.multiple = multiple;
/*    */   }
/*    */ 
/*    */   public void setSize(String size) {
/* 78 */     this.size = size;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.views.jsp.ui.SelectTag
 * JD-Core Version:    0.6.0
 */