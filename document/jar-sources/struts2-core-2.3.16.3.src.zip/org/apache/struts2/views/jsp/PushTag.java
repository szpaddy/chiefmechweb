/*    */ package org.apache.struts2.views.jsp;
/*    */ 
/*    */ import com.opensymphony.xwork2.util.ValueStack;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.apache.struts2.components.Component;
/*    */ import org.apache.struts2.components.Push;
/*    */ 
/*    */ public class PushTag extends ComponentTagSupport
/*    */ {
/*    */   private static final long serialVersionUID = -1357895305148907931L;
/*    */   protected String value;
/*    */ 
/*    */   public Component getBean(ValueStack stack, HttpServletRequest req, HttpServletResponse res)
/*    */   {
/* 43 */     return new Push(stack);
/*    */   }
/*    */ 
/*    */   protected void populateParams() {
/* 47 */     super.populateParams();
/*    */ 
/* 49 */     ((Push)this.component).setValue(this.value);
/*    */   }
/*    */ 
/*    */   public void setValue(String value) {
/* 53 */     this.value = value;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.views.jsp.PushTag
 * JD-Core Version:    0.6.0
 */