/*    */ package org.apache.struts2.views.jsp;
/*    */ 
/*    */ import com.opensymphony.xwork2.util.ValueStack;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.apache.struts2.components.Component;
/*    */ import org.apache.struts2.components.ElseIf;
/*    */ 
/*    */ public class ElseIfTag extends ComponentTagSupport
/*    */ {
/*    */   private static final long serialVersionUID = -3872016920741400345L;
/*    */   protected String test;
/*    */ 
/*    */   public Component getBean(ValueStack stack, HttpServletRequest req, HttpServletResponse res)
/*    */   {
/* 42 */     return new ElseIf(stack);
/*    */   }
/*    */ 
/*    */   protected void populateParams() {
/* 46 */     ((ElseIf)getComponent()).setTest(this.test);
/*    */   }
/*    */ 
/*    */   public void setTest(String test) {
/* 50 */     this.test = test;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.views.jsp.ElseIfTag
 * JD-Core Version:    0.6.0
 */