/*    */ package org.apache.struts2.views.jsp.ui;
/*    */ 
/*    */ import com.opensymphony.xwork2.util.ValueStack;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.apache.struts2.components.Component;
/*    */ import org.apache.struts2.components.File;
/*    */ 
/*    */ public class FileTag extends AbstractUITag
/*    */ {
/*    */   private static final long serialVersionUID = -2154950640215144864L;
/*    */   protected String accept;
/*    */   protected String size;
/*    */ 
/*    */   public Component getBean(ValueStack stack, HttpServletRequest req, HttpServletResponse res)
/*    */   {
/* 44 */     return new File(stack, req, res);
/*    */   }
/*    */ 
/*    */   protected void populateParams() {
/* 48 */     super.populateParams();
/*    */ 
/* 50 */     File file = (File)this.component;
/* 51 */     file.setAccept(this.accept);
/* 52 */     file.setSize(this.size);
/*    */   }
/*    */ 
/*    */   public void setAccept(String accept) {
/* 56 */     this.accept = accept;
/*    */   }
/*    */ 
/*    */   public void setSize(String size) {
/* 60 */     this.size = size;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.views.jsp.ui.FileTag
 * JD-Core Version:    0.6.0
 */