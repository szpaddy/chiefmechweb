/*     */ package org.apache.struts2.views.jsp.ui;
/*     */ 
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.struts2.components.Component;
/*     */ import org.apache.struts2.components.OptionTransferSelect;
/*     */ 
/*     */ public class OptionTransferSelectTag extends AbstractDoubleListTag
/*     */ {
/*     */   private static final long serialVersionUID = 250474334495763536L;
/*     */   protected String allowAddToLeft;
/*     */   protected String allowAddToRight;
/*     */   protected String allowAddAllToLeft;
/*     */   protected String allowAddAllToRight;
/*     */   protected String allowSelectAll;
/*     */   protected String allowUpDownOnLeft;
/*     */   protected String allowUpDownOnRight;
/*     */   protected String leftTitle;
/*     */   protected String rightTitle;
/*     */   protected String buttonCssClass;
/*     */   protected String buttonCssStyle;
/*     */   protected String addToLeftLabel;
/*     */   protected String addToRightLabel;
/*     */   protected String addAllToLeftLabel;
/*     */   protected String addAllToRightLabel;
/*     */   protected String selectAllLabel;
/*     */   protected String leftUpLabel;
/*     */   protected String leftDownLabel;
/*     */   protected String rightUpLabel;
/*     */   protected String rightDownLabel;
/*     */   protected String addToLeftOnclick;
/*     */   protected String addToRightOnclick;
/*     */   protected String addAllToLeftOnclick;
/*     */   protected String addAllToRightOnclick;
/*     */   protected String selectAllOnclick;
/*     */   protected String upDownOnLeftOnclick;
/*     */   protected String upDownOnRightOnclick;
/*     */ 
/*     */   public Component getBean(ValueStack stack, HttpServletRequest req, HttpServletResponse res)
/*     */   {
/*  73 */     return new OptionTransferSelect(stack, req, res);
/*     */   }
/*     */ 
/*     */   protected void populateParams() {
/*  77 */     super.populateParams();
/*     */ 
/*  79 */     OptionTransferSelect optionTransferSelect = (OptionTransferSelect)this.component;
/*  80 */     optionTransferSelect.setAllowAddToLeft(this.allowAddToLeft);
/*  81 */     optionTransferSelect.setAllowAddToRight(this.allowAddToRight);
/*  82 */     optionTransferSelect.setAllowAddAllToLeft(this.allowAddAllToLeft);
/*  83 */     optionTransferSelect.setAllowAddAllToRight(this.allowAddAllToRight);
/*  84 */     optionTransferSelect.setAllowSelectAll(this.allowSelectAll);
/*  85 */     optionTransferSelect.setAllowUpDownOnLeft(this.allowUpDownOnLeft);
/*  86 */     optionTransferSelect.setAllowUpDownOnRight(this.allowUpDownOnRight);
/*     */ 
/*  88 */     optionTransferSelect.setAddToLeftLabel(this.addToLeftLabel);
/*  89 */     optionTransferSelect.setAddToRightLabel(this.addToRightLabel);
/*  90 */     optionTransferSelect.setAddAllToLeftLabel(this.addAllToLeftLabel);
/*  91 */     optionTransferSelect.setAddAllToRightLabel(this.addAllToRightLabel);
/*  92 */     optionTransferSelect.setSelectAllLabel(this.selectAllLabel);
/*  93 */     optionTransferSelect.setLeftUpLabel(this.leftUpLabel);
/*  94 */     optionTransferSelect.setLeftDownLabel(this.leftDownLabel);
/*  95 */     optionTransferSelect.setRightUpLabel(this.rightUpLabel);
/*  96 */     optionTransferSelect.setRightDownLabel(this.rightDownLabel);
/*     */ 
/*  98 */     optionTransferSelect.setButtonCssClass(this.buttonCssClass);
/*  99 */     optionTransferSelect.setButtonCssStyle(this.buttonCssStyle);
/*     */ 
/* 101 */     optionTransferSelect.setLeftTitle(this.leftTitle);
/* 102 */     optionTransferSelect.setRightTitle(this.rightTitle);
/*     */ 
/* 104 */     optionTransferSelect.setAddToLeftOnclick(this.addToLeftOnclick);
/* 105 */     optionTransferSelect.setAddToRightOnclick(this.addToRightOnclick);
/* 106 */     optionTransferSelect.setAddAllToLeftOnclick(this.addAllToLeftOnclick);
/* 107 */     optionTransferSelect.setAddAllToRightOnclick(this.addAllToRightOnclick);
/* 108 */     optionTransferSelect.setSelectAllOnclick(this.selectAllOnclick);
/* 109 */     optionTransferSelect.setUpDownOnLeftOnclick(this.upDownOnLeftOnclick);
/* 110 */     optionTransferSelect.setUpDownOnRightOnclick(this.upDownOnRightOnclick);
/*     */   }
/*     */ 
/*     */   public String getAddAllToLeftLabel()
/*     */   {
/* 115 */     return this.addAllToLeftLabel;
/*     */   }
/*     */ 
/*     */   public void setAddAllToLeftLabel(String addAllToLeftLabel)
/*     */   {
/* 120 */     this.addAllToLeftLabel = addAllToLeftLabel;
/*     */   }
/*     */ 
/*     */   public String getAddAllToRightLabel()
/*     */   {
/* 125 */     return this.addAllToRightLabel;
/*     */   }
/*     */ 
/*     */   public void setAddAllToRightLabel(String addAllToRightLabel)
/*     */   {
/* 130 */     this.addAllToRightLabel = addAllToRightLabel;
/*     */   }
/*     */ 
/*     */   public String getAddToLeftLabel()
/*     */   {
/* 135 */     return this.addToLeftLabel;
/*     */   }
/*     */ 
/*     */   public void setAddToLeftLabel(String addToLeftLabel)
/*     */   {
/* 140 */     this.addToLeftLabel = addToLeftLabel;
/*     */   }
/*     */ 
/*     */   public String getAddToRightLabel()
/*     */   {
/* 145 */     return this.addToRightLabel;
/*     */   }
/*     */ 
/*     */   public void setAddToRightLabel(String addToRightLabel)
/*     */   {
/* 150 */     this.addToRightLabel = addToRightLabel;
/*     */   }
/*     */ 
/*     */   public String getAllowAddAllToLeft()
/*     */   {
/* 155 */     return this.allowAddAllToLeft;
/*     */   }
/*     */ 
/*     */   public void setAllowAddAllToLeft(String allowAddAllToLeft)
/*     */   {
/* 160 */     this.allowAddAllToLeft = allowAddAllToLeft;
/*     */   }
/*     */ 
/*     */   public String getAllowAddAllToRight()
/*     */   {
/* 165 */     return this.allowAddAllToRight;
/*     */   }
/*     */ 
/*     */   public void setAllowAddAllToRight(String allowAddAllToRight)
/*     */   {
/* 170 */     this.allowAddAllToRight = allowAddAllToRight;
/*     */   }
/*     */ 
/*     */   public String getAllowAddToLeft()
/*     */   {
/* 175 */     return this.allowAddToLeft;
/*     */   }
/*     */ 
/*     */   public void setAllowAddToLeft(String allowAddToLeft)
/*     */   {
/* 180 */     this.allowAddToLeft = allowAddToLeft;
/*     */   }
/*     */ 
/*     */   public String getAllowAddToRight()
/*     */   {
/* 185 */     return this.allowAddToRight;
/*     */   }
/*     */ 
/*     */   public void setAllowAddToRight(String allowAddToRight)
/*     */   {
/* 190 */     this.allowAddToRight = allowAddToRight;
/*     */   }
/*     */ 
/*     */   public String getAllowUpDownOnLeft() {
/* 194 */     return this.allowUpDownOnLeft;
/*     */   }
/*     */ 
/*     */   public void setAllowUpDownOnLeft(String allowUpDownOnLeft) {
/* 198 */     this.allowUpDownOnLeft = allowUpDownOnLeft;
/*     */   }
/*     */ 
/*     */   public String getAllowUpDownOnRight() {
/* 202 */     return this.allowUpDownOnRight;
/*     */   }
/*     */ 
/*     */   public void setAllowUpDownOnRight(String allowUpDownOnRight) {
/* 206 */     this.allowUpDownOnRight = allowUpDownOnRight;
/*     */   }
/*     */ 
/*     */   public String getLeftUpLabel() {
/* 210 */     return this.leftUpLabel;
/*     */   }
/*     */ 
/*     */   public void setLeftUpLabel(String leftUpLabel) {
/* 214 */     this.leftUpLabel = leftUpLabel;
/*     */   }
/*     */ 
/*     */   public String getLeftDownLabel() {
/* 218 */     return this.leftDownLabel;
/*     */   }
/*     */ 
/*     */   public void setLeftDownLabel(String leftDownLabel) {
/* 222 */     this.leftDownLabel = leftDownLabel;
/*     */   }
/*     */ 
/*     */   public String getRightUpLabel() {
/* 226 */     return this.rightUpLabel;
/*     */   }
/*     */ 
/*     */   public void setRightUpLabel(String rightUpLabel) {
/* 230 */     this.rightUpLabel = rightUpLabel;
/*     */   }
/*     */ 
/*     */   public String getRightDownLabel() {
/* 234 */     return this.rightDownLabel;
/*     */   }
/*     */ 
/*     */   public void setRightDownLabel(String rightDownLabel) {
/* 238 */     this.rightDownLabel = rightDownLabel;
/*     */   }
/*     */ 
/*     */   public String getLeftTitle() {
/* 242 */     return this.leftTitle;
/*     */   }
/*     */ 
/*     */   public void setLeftTitle(String leftTitle)
/*     */   {
/* 247 */     this.leftTitle = leftTitle;
/*     */   }
/*     */ 
/*     */   public String getRightTitle()
/*     */   {
/* 252 */     return this.rightTitle;
/*     */   }
/*     */ 
/*     */   public void setRightTitle(String rightTitle)
/*     */   {
/* 257 */     this.rightTitle = rightTitle;
/*     */   }
/*     */ 
/*     */   public void setAllowSelectAll(String allowSelectAll)
/*     */   {
/* 262 */     this.allowSelectAll = allowSelectAll;
/*     */   }
/*     */ 
/*     */   public String getAllowSelectAll() {
/* 266 */     return this.allowSelectAll;
/*     */   }
/*     */ 
/*     */   public void setSelectAllLabel(String selectAllLabel) {
/* 270 */     this.selectAllLabel = selectAllLabel;
/*     */   }
/*     */ 
/*     */   public String getSelectAllLabel() {
/* 274 */     return this.selectAllLabel;
/*     */   }
/*     */ 
/*     */   public void setButtonCssClass(String buttonCssId) {
/* 278 */     this.buttonCssClass = buttonCssId;
/*     */   }
/*     */ 
/*     */   public String getButtonCssClass() {
/* 282 */     return this.buttonCssClass;
/*     */   }
/*     */ 
/*     */   public void setButtonCssStyle(String buttonCssStyle) {
/* 286 */     this.buttonCssStyle = buttonCssStyle;
/*     */   }
/*     */ 
/*     */   public String getButtonCssStyle() {
/* 290 */     return this.buttonCssStyle;
/*     */   }
/*     */ 
/*     */   public String getAddAllToLeftOnclick() {
/* 294 */     return this.addAllToLeftOnclick;
/*     */   }
/*     */ 
/*     */   public void setAddAllToLeftOnclick(String addAllToLeftOnclick) {
/* 298 */     this.addAllToLeftOnclick = addAllToLeftOnclick;
/*     */   }
/*     */ 
/*     */   public String getAddAllToRightOnclick() {
/* 302 */     return this.addAllToRightOnclick;
/*     */   }
/*     */ 
/*     */   public void setAddAllToRightOnclick(String addAllToRightOnclick) {
/* 306 */     this.addAllToRightOnclick = addAllToRightOnclick;
/*     */   }
/*     */ 
/*     */   public String getAddToLeftOnclick() {
/* 310 */     return this.addToLeftOnclick;
/*     */   }
/*     */ 
/*     */   public void setAddToLeftOnclick(String addToLeftOnclick) {
/* 314 */     this.addToLeftOnclick = addToLeftOnclick;
/*     */   }
/*     */ 
/*     */   public String getAddToRightOnclick() {
/* 318 */     return this.addToRightOnclick;
/*     */   }
/*     */ 
/*     */   public void setAddToRightOnclick(String addToRightOnclick) {
/* 322 */     this.addToRightOnclick = addToRightOnclick;
/*     */   }
/*     */ 
/*     */   public String getUpDownOnLeftOnclick() {
/* 326 */     return this.upDownOnLeftOnclick;
/*     */   }
/*     */ 
/*     */   public void setUpDownOnLeftOnclick(String upDownOnLeftOnclick) {
/* 330 */     this.upDownOnLeftOnclick = upDownOnLeftOnclick;
/*     */   }
/*     */ 
/*     */   public String getUpDownOnRightOnclick() {
/* 334 */     return this.upDownOnRightOnclick;
/*     */   }
/*     */ 
/*     */   public void setUpDownOnRightOnclick(String upDownOnRightOnclick) {
/* 338 */     this.upDownOnRightOnclick = upDownOnRightOnclick;
/*     */   }
/*     */ 
/*     */   public void setSelectAllOnclick(String selectAllOnclick) {
/* 342 */     this.selectAllOnclick = selectAllOnclick;
/*     */   }
/*     */ 
/*     */   public String getSelectAllOnclick() {
/* 346 */     return this.selectAllOnclick;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.views.jsp.ui.OptionTransferSelectTag
 * JD-Core Version:    0.6.0
 */