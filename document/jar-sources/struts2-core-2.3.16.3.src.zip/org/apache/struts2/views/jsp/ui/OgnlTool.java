/*    */ package org.apache.struts2.views.jsp.ui;
/*    */ 
/*    */ import com.opensymphony.xwork2.inject.Inject;
/*    */ import com.opensymphony.xwork2.ognl.OgnlUtil;
/*    */ import ognl.Ognl;
/*    */ import ognl.OgnlException;
/*    */ 
/*    */ public class OgnlTool
/*    */ {
/*    */   private OgnlUtil ognlUtil;
/*    */ 
/*    */   @Inject
/*    */   public void setOgnlUtil(OgnlUtil ognlUtil)
/*    */   {
/* 42 */     this.ognlUtil = ognlUtil;
/*    */   }
/*    */ 
/*    */   public Object findValue(String expr, Object context)
/*    */   {
/*    */     try
/*    */     {
/* 50 */       return Ognl.getValue(this.ognlUtil.compile(expr), context); } catch (OgnlException e) {
/*    */     }
/* 52 */     return null;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.views.jsp.ui.OgnlTool
 * JD-Core Version:    0.6.0
 */