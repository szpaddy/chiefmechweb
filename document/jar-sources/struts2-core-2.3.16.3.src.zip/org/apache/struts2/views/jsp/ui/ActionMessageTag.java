/*    */ package org.apache.struts2.views.jsp.ui;
/*    */ 
/*    */ import com.opensymphony.xwork2.util.ValueStack;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.apache.struts2.components.ActionMessage;
/*    */ import org.apache.struts2.components.Component;
/*    */ 
/*    */ public class ActionMessageTag extends AbstractUITag
/*    */ {
/*    */   private static final long serialVersionUID = 243396927554182506L;
/* 41 */   private boolean escape = true;
/*    */ 
/*    */   public Component getBean(ValueStack stack, HttpServletRequest req, HttpServletResponse res) {
/* 44 */     return new ActionMessage(stack, req, res);
/*    */   }
/*    */ 
/*    */   protected void populateParams() {
/* 48 */     super.populateParams();
/*    */ 
/* 50 */     ActionMessage message = (ActionMessage)this.component;
/* 51 */     message.setEscape(this.escape);
/*    */   }
/*    */ 
/*    */   public void setEscape(boolean escape) {
/* 55 */     this.escape = escape;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.views.jsp.ui.ActionMessageTag
 * JD-Core Version:    0.6.0
 */