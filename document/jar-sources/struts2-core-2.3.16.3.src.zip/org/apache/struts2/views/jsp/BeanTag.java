/*    */ package org.apache.struts2.views.jsp;
/*    */ 
/*    */ import com.opensymphony.xwork2.util.ValueStack;
/*    */ import com.opensymphony.xwork2.util.logging.Logger;
/*    */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.apache.struts2.components.Bean;
/*    */ import org.apache.struts2.components.Component;
/*    */ 
/*    */ public class BeanTag extends ContextBeanTag
/*    */ {
/*    */   private static final long serialVersionUID = -3863152522071209267L;
/* 42 */   protected static Logger LOG = LoggerFactory.getLogger(BeanTag.class);
/*    */   protected String name;
/*    */ 
/*    */   public Component getBean(ValueStack stack, HttpServletRequest req, HttpServletResponse res)
/*    */   {
/* 47 */     return new Bean(stack);
/*    */   }
/*    */ 
/*    */   protected void populateParams() {
/* 51 */     super.populateParams();
/*    */ 
/* 53 */     ((Bean)this.component).setName(this.name);
/*    */   }
/*    */ 
/*    */   public void setName(String name) {
/* 57 */     this.name = name;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.views.jsp.BeanTag
 * JD-Core Version:    0.6.0
 */