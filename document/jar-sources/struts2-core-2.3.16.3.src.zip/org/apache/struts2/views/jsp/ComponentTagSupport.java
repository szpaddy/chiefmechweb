/*    */ package org.apache.struts2.views.jsp;
/*    */ 
/*    */ import com.opensymphony.xwork2.inject.Container;
/*    */ import com.opensymphony.xwork2.util.ValueStack;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import javax.servlet.jsp.JspException;
/*    */ import javax.servlet.jsp.PageContext;
/*    */ import org.apache.struts2.components.Component;
/*    */ import org.apache.struts2.dispatcher.Dispatcher;
/*    */ 
/*    */ public abstract class ComponentTagSupport extends StrutsBodyTagSupport
/*    */ {
/*    */   protected Component component;
/*    */ 
/*    */   public abstract Component getBean(ValueStack paramValueStack, HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse);
/*    */ 
/*    */   public int doEndTag()
/*    */     throws JspException
/*    */   {
/* 42 */     this.component.end(this.pageContext.getOut(), getBody());
/* 43 */     this.component = null;
/* 44 */     return 6;
/*    */   }
/*    */ 
/*    */   public int doStartTag() throws JspException {
/* 48 */     this.component = getBean(getStack(), (HttpServletRequest)this.pageContext.getRequest(), (HttpServletResponse)this.pageContext.getResponse());
/* 49 */     Container container = Dispatcher.getInstance().getContainer();
/* 50 */     container.inject(this.component);
/*    */ 
/* 52 */     populateParams();
/* 53 */     boolean evalBody = this.component.start(this.pageContext.getOut());
/*    */ 
/* 55 */     if (evalBody) {
/* 56 */       return this.component.usesBody() ? 2 : 1;
/*    */     }
/* 58 */     return 0;
/*    */   }
/*    */ 
/*    */   protected void populateParams()
/*    */   {
/*    */   }
/*    */ 
/*    */   public Component getComponent() {
/* 66 */     return this.component;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.views.jsp.ComponentTagSupport
 * JD-Core Version:    0.6.0
 */