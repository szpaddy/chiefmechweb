/*    */ package org.apache.struts2.views.jsp;
/*    */ 
/*    */ import com.opensymphony.xwork2.util.ValueStack;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.apache.struts2.components.Component;
/*    */ import org.apache.struts2.components.Property;
/*    */ 
/*    */ public class PropertyTag extends ComponentTagSupport
/*    */ {
/*    */   private static final long serialVersionUID = 435308349113743852L;
/*    */   private String defaultValue;
/*    */   private String value;
/* 42 */   private boolean escapeHtml = true;
/* 43 */   private boolean escapeJavaScript = false;
/* 44 */   private boolean escapeXml = false;
/* 45 */   private boolean escapeCsv = false;
/*    */ 
/*    */   public Component getBean(ValueStack stack, HttpServletRequest req, HttpServletResponse res) {
/* 48 */     return new Property(stack);
/*    */   }
/*    */ 
/*    */   protected void populateParams() {
/* 52 */     super.populateParams();
/*    */ 
/* 54 */     Property tag = (Property)this.component;
/* 55 */     tag.setDefault(this.defaultValue);
/* 56 */     tag.setValue(this.value);
/* 57 */     tag.setEscape(this.escapeHtml);
/* 58 */     tag.setEscapeJavaScript(this.escapeJavaScript);
/* 59 */     tag.setEscapeXml(this.escapeXml);
/* 60 */     tag.setEscapeCsv(this.escapeCsv);
/*    */   }
/*    */ 
/*    */   public void setDefault(String defaultValue) {
/* 64 */     this.defaultValue = defaultValue;
/*    */   }
/*    */ 
/*    */   public void setEscape(boolean escape) {
/* 68 */     this.escapeHtml = escape;
/*    */   }
/*    */ 
/*    */   public void setEscapeHtml(boolean escapeHtml) {
/* 72 */     this.escapeHtml = escapeHtml;
/*    */   }
/*    */ 
/*    */   public void setEscapeJavaScript(boolean escapeJavaScript) {
/* 76 */     this.escapeJavaScript = escapeJavaScript;
/*    */   }
/*    */ 
/*    */   public void setValue(String value) {
/* 80 */     this.value = value;
/*    */   }
/*    */ 
/*    */   public void setDefaultValue(String defaultValue) {
/* 84 */     this.defaultValue = defaultValue;
/*    */   }
/*    */ 
/*    */   public void setEscapeCsv(boolean escapeCsv) {
/* 88 */     this.escapeCsv = escapeCsv;
/*    */   }
/*    */ 
/*    */   public void setEscapeXml(boolean escapeXml) {
/* 92 */     this.escapeXml = escapeXml;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.views.jsp.PropertyTag
 * JD-Core Version:    0.6.0
 */