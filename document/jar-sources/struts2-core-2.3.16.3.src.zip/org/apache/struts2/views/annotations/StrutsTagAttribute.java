package org.apache.struts2.views.annotations;

import java.lang.annotation.Annotation;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target({java.lang.annotation.ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
public @interface StrutsTagAttribute
{
  public abstract String name();

  public abstract boolean required();

  public abstract boolean rtexprvalue();

  public abstract String description();

  public abstract String defaultValue();

  public abstract String type();
}

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.views.annotations.StrutsTagAttribute
 * JD-Core Version:    0.6.0
 */