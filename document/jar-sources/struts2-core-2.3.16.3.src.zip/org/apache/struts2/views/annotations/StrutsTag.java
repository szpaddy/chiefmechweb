package org.apache.struts2.views.annotations;

import java.lang.annotation.Annotation;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target({java.lang.annotation.ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
public @interface StrutsTag
{
  public abstract String name();

  public abstract String tldBodyContent();

  public abstract String tldTagClass();

  public abstract String description();

  public abstract boolean allowDynamicAttributes();
}

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.views.annotations.StrutsTag
 * JD-Core Version:    0.6.0
 */