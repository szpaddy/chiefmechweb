/*     */ package org.apache.struts2.views.xslt;
/*     */ 
/*     */ import com.opensymphony.xwork2.util.logging.Logger;
/*     */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*     */ import java.beans.BeanInfo;
/*     */ import java.beans.IntrospectionException;
/*     */ import java.beans.Introspector;
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.struts2.StrutsException;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ 
/*     */ public class BeanAdapter extends AbstractAdapterElement
/*     */ {
/*  59 */   private static final Object[] NULLPARAMS = new Object[0];
/*     */   private static Map<Class, PropertyDescriptor[]> propertyDescriptorCache;
/*  68 */   private Logger log = LoggerFactory.getLogger(getClass());
/*     */ 
/*     */   public BeanAdapter()
/*     */   {
/*     */   }
/*     */ 
/*     */   public BeanAdapter(AdapterFactory adapterFactory, AdapterNode parent, String propertyName, Object value)
/*     */   {
/*  77 */     setContext(adapterFactory, parent, propertyName, value);
/*     */   }
/*     */ 
/*     */   public String getTagName()
/*     */   {
/*  83 */     return getPropertyName();
/*     */   }
/*     */ 
/*     */   public NodeList getChildNodes() {
/*  87 */     NodeList nl = super.getChildNodes();
/*     */ 
/*  89 */     if ((this.log.isDebugEnabled()) && (nl != null)) {
/*  90 */       this.log.debug("BeanAdapter getChildNodes for: " + getTagName(), new String[0]);
/*  91 */       this.log.debug(nl.toString(), new String[0]);
/*     */     }
/*  93 */     return nl;
/*     */   }
/*     */ 
/*     */   protected List<Node> buildChildAdapters() {
/*  97 */     this.log.debug("BeanAdapter building children.  PropName = " + getPropertyName(), new String[0]);
/*  98 */     List newAdapters = new ArrayList();
/*  99 */     Class type = getPropertyValue().getClass();
/* 100 */     PropertyDescriptor[] props = getPropertyDescriptors(getPropertyValue());
/*     */ 
/* 102 */     if (props.length > 0) {
/* 103 */       for (PropertyDescriptor prop : props) {
/* 104 */         Method m = prop.getReadMethod();
/*     */ 
/* 106 */         if (m == null)
/*     */         {
/*     */           continue;
/*     */         }
/*     */ 
/* 110 */         this.log.debug("Bean reading property method: " + m.getName(), new String[0]);
/*     */ 
/* 112 */         String propertyName = prop.getName();
/*     */         Object propertyValue;
/*     */         try
/*     */         {
/* 121 */           propertyValue = m.invoke(getPropertyValue(), NULLPARAMS);
/*     */         } catch (Exception e) {
/* 123 */           if ((e instanceof InvocationTargetException))
/* 124 */             e = (Exception)((InvocationTargetException)e).getTargetException();
/* 125 */           if (this.log.isErrorEnabled()) {
/* 126 */             this.log.error("Cannot access bean property: #0", e, new String[] { propertyName });
/*     */           }
/* 128 */           continue;
/*     */         }
/*     */         Node childAdapter;
/*     */         Node childAdapter;
/* 133 */         if (propertyValue == null)
/* 134 */           childAdapter = getAdapterFactory().adaptNullValue(this, propertyName);
/*     */         else {
/* 136 */           childAdapter = getAdapterFactory().adaptNode(this, propertyName, propertyValue);
/*     */         }
/*     */ 
/* 139 */         if (childAdapter != null) {
/* 140 */           newAdapters.add(childAdapter);
/*     */         }
/* 142 */         if (this.log.isDebugEnabled()) {
/* 143 */           this.log.debug(this + " adding adapter: " + childAdapter, new String[0]);
/*     */         }
/*     */       }
/*     */     }
/*     */     else {
/* 148 */       this.log.info("Class " + type.getName() + " has no readable properties, " + " trying to adapt " + getPropertyName() + " with StringAdapter...", new String[0]);
/*     */     }
/*     */ 
/* 152 */     return newAdapters;
/*     */   }
/*     */ 
/*     */   private synchronized PropertyDescriptor[] getPropertyDescriptors(Object bean)
/*     */   {
/*     */     try
/*     */     {
/* 160 */       if (propertyDescriptorCache == null) {
/* 161 */         propertyDescriptorCache = new HashMap();
/*     */       }
/*     */ 
/* 164 */       PropertyDescriptor[] props = (PropertyDescriptor[])propertyDescriptorCache.get(bean.getClass());
/*     */ 
/* 166 */       if (props == null) {
/* 167 */         this.log.debug("Caching property descriptor for " + bean.getClass().getName(), new String[0]);
/* 168 */         props = Introspector.getBeanInfo(bean.getClass(), Object.class).getPropertyDescriptors();
/* 169 */         propertyDescriptorCache.put(bean.getClass(), props);
/*     */       }
/*     */ 
/* 172 */       return props;
/*     */     } catch (IntrospectionException e) {
/* 174 */       e.printStackTrace();
/* 175 */     }throw new StrutsException("Error getting property descriptors for " + bean + " : " + e.getMessage());
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.views.xslt.BeanAdapter
 * JD-Core Version:    0.6.0
 */