/*     */ package org.apache.struts2.views.xslt;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.w3c.dom.Attr;
/*     */ import org.w3c.dom.DOMException;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.NamedNodeMap;
/*     */ import org.w3c.dom.NodeList;
/*     */ import org.w3c.dom.TypeInfo;
/*     */ 
/*     */ public abstract class AbstractAdapterElement extends AbstractAdapterNode
/*     */   implements Element
/*     */ {
/*     */   private Map attributeAdapters;
/*     */ 
/*     */   public void setAttribute(String string, String string1)
/*     */     throws DOMException
/*     */   {
/*  44 */     throw operationNotSupported();
/*     */   }
/*     */ 
/*     */   protected Map getAttributeAdapters() {
/*  48 */     if (this.attributeAdapters == null)
/*  49 */       this.attributeAdapters = buildAttributeAdapters();
/*  50 */     return this.attributeAdapters;
/*     */   }
/*     */ 
/*     */   protected Map buildAttributeAdapters() {
/*  54 */     return new HashMap();
/*     */   }
/*     */ 
/*     */   public String getAttribute(String string)
/*     */   {
/*  61 */     return "";
/*     */   }
/*     */ 
/*     */   public void setAttributeNS(String string, String string1, String string2) throws DOMException {
/*  65 */     throw operationNotSupported();
/*     */   }
/*     */ 
/*     */   public String getAttributeNS(String string, String string1) {
/*  69 */     return null;
/*     */   }
/*     */ 
/*     */   public Attr setAttributeNode(Attr attr) throws DOMException {
/*  73 */     throw operationNotSupported();
/*     */   }
/*     */ 
/*     */   public Attr getAttributeNode(String name) {
/*  77 */     return (Attr)getAttributes().getNamedItem(name);
/*     */   }
/*     */ 
/*     */   public Attr setAttributeNodeNS(Attr attr) throws DOMException {
/*  81 */     throw operationNotSupported();
/*     */   }
/*     */ 
/*     */   public Attr getAttributeNodeNS(String string, String string1) {
/*  85 */     throw operationNotSupported();
/*     */   }
/*     */ 
/*     */   public String getNodeName() {
/*  89 */     return getTagName();
/*     */   }
/*     */ 
/*     */   public short getNodeType() {
/*  93 */     return 1;
/*     */   }
/*     */ 
/*     */   public String getTagName() {
/*  97 */     return getPropertyName();
/*     */   }
/*     */ 
/*     */   public boolean hasAttribute(String string) {
/* 101 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean hasAttributeNS(String string, String string1) {
/* 105 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean hasChildNodes() {
/* 109 */     return getElementsByTagName("*").getLength() > 0;
/*     */   }
/*     */ 
/*     */   public void removeAttribute(String string) throws DOMException {
/* 113 */     throw operationNotSupported();
/*     */   }
/*     */ 
/*     */   public void removeAttributeNS(String string, String string1) throws DOMException {
/* 117 */     throw operationNotSupported();
/*     */   }
/*     */ 
/*     */   public Attr removeAttributeNode(Attr attr) throws DOMException {
/* 121 */     throw operationNotSupported();
/*     */   }
/*     */ 
/*     */   public void setIdAttributeNode(Attr attr, boolean b) throws DOMException {
/* 125 */     throw operationNotSupported();
/*     */   }
/*     */ 
/*     */   public TypeInfo getSchemaTypeInfo() {
/* 129 */     throw operationNotSupported();
/*     */   }
/*     */ 
/*     */   public void setIdAttribute(String string, boolean b) throws DOMException {
/* 133 */     throw operationNotSupported();
/*     */   }
/*     */ 
/*     */   public void setIdAttributeNS(String string, String string1, boolean b) throws DOMException {
/* 137 */     throw operationNotSupported();
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.views.xslt.AbstractAdapterElement
 * JD-Core Version:    0.6.0
 */