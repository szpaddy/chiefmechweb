/*     */ package org.apache.struts2.views.xslt;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionContext;
/*     */ import com.opensymphony.xwork2.ActionInvocation;
/*     */ import com.opensymphony.xwork2.Result;
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import com.opensymphony.xwork2.util.TextParseUtil;
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import com.opensymphony.xwork2.util.logging.Logger;
/*     */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import java.net.URL;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.xml.transform.ErrorListener;
/*     */ import javax.xml.transform.Source;
/*     */ import javax.xml.transform.Templates;
/*     */ import javax.xml.transform.Transformer;
/*     */ import javax.xml.transform.TransformerException;
/*     */ import javax.xml.transform.TransformerFactory;
/*     */ import javax.xml.transform.URIResolver;
/*     */ import javax.xml.transform.dom.DOMSource;
/*     */ import javax.xml.transform.stream.StreamResult;
/*     */ import javax.xml.transform.stream.StreamSource;
/*     */ import org.apache.struts2.ServletActionContext;
/*     */ import org.apache.struts2.StrutsException;
/*     */ 
/*     */ public class XSLTResult
/*     */   implements Result
/*     */ {
/*     */   private static final long serialVersionUID = 6424691441777176763L;
/* 212 */   private static final Logger LOG = LoggerFactory.getLogger(XSLTResult.class);
/*     */   public static final String DEFAULT_PARAM = "stylesheetLocation";
/* 221 */   private static final Map<String, Templates> templatesCache = new HashMap();
/*     */   protected boolean noCache;
/*     */   private String stylesheetLocation;
/*     */   private String matchingPattern;
/*     */   private String excludingPattern;
/*     */   private String exposedValue;
/* 242 */   private int status = 200;
/*     */   private boolean parse;
/*     */   private AdapterFactory adapterFactory;
/*     */ 
/*     */   public XSLTResult()
/*     */   {
/*     */   }
/*     */ 
/*     */   public XSLTResult(String stylesheetLocation)
/*     */   {
/* 251 */     this();
/* 252 */     setStylesheetLocation(stylesheetLocation);
/*     */   }
/*     */   @Inject("struts.xslt.nocache")
/*     */   public void setNoCache(String val) {
/* 257 */     this.noCache = "true".equals(val);
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public void setLocation(String location)
/*     */   {
/* 264 */     setStylesheetLocation(location);
/*     */   }
/*     */ 
/*     */   public void setStylesheetLocation(String location) {
/* 268 */     if (location == null)
/* 269 */       throw new IllegalArgumentException("Null location");
/* 270 */     this.stylesheetLocation = location;
/*     */   }
/*     */ 
/*     */   public String getStylesheetLocation() {
/* 274 */     return this.stylesheetLocation;
/*     */   }
/*     */ 
/*     */   public String getExposedValue() {
/* 278 */     return this.exposedValue;
/*     */   }
/*     */ 
/*     */   public void setExposedValue(String exposedValue) {
/* 282 */     this.exposedValue = exposedValue;
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public String getMatchingPattern()
/*     */   {
/* 289 */     return this.matchingPattern;
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public void setMatchingPattern(String matchingPattern)
/*     */   {
/* 296 */     this.matchingPattern = matchingPattern;
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public String getExcludingPattern()
/*     */   {
/* 303 */     return this.excludingPattern;
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public void setExcludingPattern(String excludingPattern)
/*     */   {
/* 310 */     this.excludingPattern = excludingPattern;
/*     */   }
/*     */ 
/*     */   public String getStatus() {
/* 314 */     return String.valueOf(this.status);
/*     */   }
/*     */ 
/*     */   public void setStatus(String status) {
/*     */     try {
/* 319 */       this.status = Integer.valueOf(status).intValue();
/*     */     } catch (NumberFormatException e) {
/* 321 */       throw new IllegalArgumentException("Status value not number " + e.getMessage(), e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setParse(boolean parse)
/*     */   {
/* 331 */     this.parse = parse;
/*     */   }
/*     */ 
/*     */   public void execute(ActionInvocation invocation) throws Exception {
/* 335 */     long startTime = System.currentTimeMillis();
/* 336 */     String location = getStylesheetLocation();
/*     */ 
/* 338 */     if (this.parse) {
/* 339 */       ValueStack stack = ActionContext.getContext().getValueStack();
/* 340 */       location = TextParseUtil.translateVariables(location, stack);
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 345 */       HttpServletResponse response = ServletActionContext.getResponse();
/* 346 */       response.setStatus(this.status);
/* 347 */       PrintWriter writer = response.getWriter();
/*     */ 
/* 350 */       Templates templates = null;
/*     */       Transformer transformer;
/*     */       Transformer transformer;
/* 352 */       if (location != null) {
/* 353 */         templates = getTemplates(location);
/* 354 */         transformer = templates.newTransformer();
/*     */       } else {
/* 356 */         transformer = TransformerFactory.newInstance().newTransformer();
/*     */       }
/* 358 */       transformer.setURIResolver(getURIResolver());
/* 359 */       transformer.setErrorListener(new ErrorListener()
/*     */       {
/*     */         public void error(TransformerException exception) throws TransformerException
/*     */         {
/* 363 */           throw new StrutsException("Error transforming result", exception);
/*     */         }
/*     */ 
/*     */         public void fatalError(TransformerException exception) throws TransformerException
/*     */         {
/* 368 */           throw new StrutsException("Fatal error transforming result", exception);
/*     */         }
/*     */ 
/*     */         public void warning(TransformerException exception) throws TransformerException
/*     */         {
/* 373 */           if (XSLTResult.LOG.isWarnEnabled())
/* 374 */             XSLTResult.LOG.warn(exception.getMessage(), exception, new String[0]);
/*     */         }
/*     */       });
/*     */       String mimeType;
/*     */       String mimeType;
/* 381 */       if (templates == null)
/* 382 */         mimeType = "text/xml";
/*     */       else
/* 384 */         mimeType = templates.getOutputProperties().getProperty("media-type");
/* 385 */       if (mimeType == null)
/*     */       {
/* 387 */         mimeType = "text/html";
/*     */       }
/*     */ 
/* 390 */       response.setContentType(mimeType);
/*     */ 
/* 392 */       Object result = invocation.getAction();
/* 393 */       if (this.exposedValue != null) {
/* 394 */         ValueStack stack = invocation.getStack();
/* 395 */         result = stack.findValue(this.exposedValue);
/*     */       }
/*     */ 
/* 398 */       Source xmlSource = getDOMSourceForStack(result);
/*     */ 
/* 401 */       if (LOG.isDebugEnabled()) {
/* 402 */         LOG.debug("xmlSource = " + xmlSource, new String[0]);
/*     */       }
/* 404 */       transformer.transform(xmlSource, new StreamResult(writer));
/*     */ 
/* 406 */       writer.flush();
/*     */ 
/* 408 */       if (LOG.isDebugEnabled())
/* 409 */         LOG.debug("Time:" + (System.currentTimeMillis() - startTime) + "ms", new String[0]);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 413 */       if (LOG.isErrorEnabled()) {
/* 414 */         LOG.error("Unable to render XSLT Template, '#0'", e, new String[] { location });
/*     */       }
/* 416 */       throw e;
/*     */     }
/*     */   }
/*     */ 
/*     */   protected AdapterFactory getAdapterFactory() {
/* 421 */     if (this.adapterFactory == null)
/* 422 */       this.adapterFactory = new AdapterFactory();
/* 423 */     return this.adapterFactory;
/*     */   }
/*     */ 
/*     */   protected void setAdapterFactory(AdapterFactory adapterFactory) {
/* 427 */     this.adapterFactory = adapterFactory;
/*     */   }
/*     */ 
/*     */   protected URIResolver getURIResolver()
/*     */   {
/* 435 */     return new ServletURIResolver(ServletActionContext.getServletContext());
/*     */   }
/*     */ 
/*     */   protected Templates getTemplates(String path) throws TransformerException, IOException
/*     */   {
/* 440 */     String pathFromRequest = ServletActionContext.getRequest().getParameter("xslt.location");
/*     */ 
/* 442 */     if (pathFromRequest != null) {
/* 443 */       path = pathFromRequest;
/*     */     }
/* 445 */     if (path == null) {
/* 446 */       throw new TransformerException("Stylesheet path is null");
/*     */     }
/* 448 */     Templates templates = (Templates)templatesCache.get(path);
/*     */ 
/* 450 */     if ((this.noCache) || (templates == null)) {
/* 451 */       synchronized (templatesCache) {
/* 452 */         URL resource = ServletActionContext.getServletContext().getResource(path);
/*     */ 
/* 454 */         if (resource == null) {
/* 455 */           throw new TransformerException("Stylesheet " + path + " not found in resources.");
/*     */         }
/*     */ 
/* 458 */         if (LOG.isDebugEnabled()) {
/* 459 */           LOG.debug("Preparing XSLT stylesheet templates: " + path, new String[0]);
/*     */         }
/*     */ 
/* 462 */         TransformerFactory factory = TransformerFactory.newInstance();
/* 463 */         factory.setURIResolver(getURIResolver());
/* 464 */         templates = factory.newTemplates(new StreamSource(resource.openStream()));
/* 465 */         templatesCache.put(path, templates);
/*     */       }
/*     */     }
/*     */ 
/* 469 */     return templates;
/*     */   }
/*     */ 
/*     */   protected Source getDOMSourceForStack(Object value) throws IllegalAccessException, InstantiationException
/*     */   {
/* 474 */     return new DOMSource(getAdapterFactory().adaptDocument("result", value));
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.views.xslt.XSLTResult
 * JD-Core Version:    0.6.0
 */