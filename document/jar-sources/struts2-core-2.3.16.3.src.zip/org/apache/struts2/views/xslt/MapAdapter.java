/*    */ package org.apache.struts2.views.xslt;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import java.util.Map.Entry;
/*    */ import java.util.Set;
/*    */ import org.w3c.dom.Node;
/*    */ 
/*    */ public class MapAdapter extends AbstractAdapterElement
/*    */ {
/*    */   public MapAdapter()
/*    */   {
/*    */   }
/*    */ 
/*    */   public MapAdapter(AdapterFactory adapterFactory, AdapterNode parent, String propertyName, Map value)
/*    */   {
/* 48 */     setContext(adapterFactory, parent, propertyName, value);
/*    */   }
/*    */ 
/*    */   public Map map() {
/* 52 */     return (Map)getPropertyValue();
/*    */   }
/*    */ 
/*    */   protected List<Node> buildChildAdapters() {
/* 56 */     List children = new ArrayList(map().entrySet().size());
/*    */ 
/* 58 */     for (Iterator i$ = map().entrySet().iterator(); i$.hasNext(); ) { Object o = i$.next();
/* 59 */       Map.Entry entry = (Map.Entry)o;
/* 60 */       Object key = entry.getKey();
/* 61 */       Object value = entry.getValue();
/* 62 */       EntryElement child = new EntryElement(getAdapterFactory(), this, "entry", key, value);
/*    */ 
/* 64 */       children.add(child);
/*    */     }
/*    */ 
/* 67 */     return children;
/*    */   }
/*    */   static class EntryElement extends AbstractAdapterElement {
/*    */     Object key;
/*    */     Object value;
/*    */ 
/* 75 */     public EntryElement(AdapterFactory adapterFactory, AdapterNode parent, String propertyName, Object key, Object value) { setContext(adapterFactory, parent, propertyName, null);
/* 76 */       this.key = key;
/* 77 */       this.value = value; }
/*    */ 
/*    */     protected List<Node> buildChildAdapters()
/*    */     {
/* 81 */       List children = new ArrayList();
/* 82 */       children.add(getAdapterFactory().adaptNode(this, "key", this.key));
/* 83 */       children.add(getAdapterFactory().adaptNode(this, "value", this.value));
/* 84 */       return children;
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.views.xslt.MapAdapter
 * JD-Core Version:    0.6.0
 */