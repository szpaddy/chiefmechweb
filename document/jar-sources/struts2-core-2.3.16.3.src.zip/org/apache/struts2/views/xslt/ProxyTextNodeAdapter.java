/*    */ package org.apache.struts2.views.xslt;
/*    */ 
/*    */ import org.w3c.dom.DOMException;
/*    */ import org.w3c.dom.Text;
/*    */ 
/*    */ public class ProxyTextNodeAdapter extends ProxyNodeAdapter
/*    */   implements Text
/*    */ {
/*    */   public ProxyTextNodeAdapter(AdapterFactory factory, AdapterNode parent, Text value)
/*    */   {
/* 36 */     super(factory, parent, value);
/*    */   }
/*    */ 
/*    */   Text text()
/*    */   {
/* 41 */     return (Text)getPropertyValue();
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 45 */     return "ProxyTextNode for: " + text();
/*    */   }
/*    */ 
/*    */   public Text splitText(int offset) throws DOMException {
/* 49 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   public int getLength() {
/* 53 */     return text().getLength();
/*    */   }
/*    */ 
/*    */   public void deleteData(int offset, int count) throws DOMException {
/* 57 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   public String getData() throws DOMException {
/* 61 */     return text().getData();
/*    */   }
/*    */ 
/*    */   public String substringData(int offset, int count) throws DOMException {
/* 65 */     return text().substringData(offset, count);
/*    */   }
/*    */ 
/*    */   public void replaceData(int offset, int count, String arg) throws DOMException {
/* 69 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   public void insertData(int offset, String arg) throws DOMException {
/* 73 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   public void appendData(String arg) throws DOMException {
/* 77 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   public void setData(String data) throws DOMException {
/* 81 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   public boolean isElementContentWhitespace()
/*    */   {
/* 87 */     throw operationNotSupported();
/*    */   }
/*    */ 
/*    */   public String getWholeText() {
/* 91 */     throw operationNotSupported();
/*    */   }
/*    */ 
/*    */   public Text replaceWholeText(String string) throws DOMException {
/* 95 */     throw operationNotSupported();
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.views.xslt.ProxyTextNodeAdapter
 * JD-Core Version:    0.6.0
 */