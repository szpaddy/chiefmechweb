/*    */ package org.apache.struts2.views.xslt;
/*    */ 
/*    */ import com.opensymphony.xwork2.util.logging.Logger;
/*    */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.w3c.dom.Node;
/*    */ 
/*    */ public class ArrayAdapter extends AbstractAdapterElement
/*    */ {
/* 37 */   private Logger log = LoggerFactory.getLogger(getClass());
/*    */ 
/*    */   public ArrayAdapter() {
/*    */   }
/*    */ 
/*    */   public ArrayAdapter(AdapterFactory adapterFactory, AdapterNode parent, String propertyName, Object value) {
/* 43 */     setContext(adapterFactory, parent, propertyName, value);
/*    */   }
/*    */ 
/*    */   protected List<Node> buildChildAdapters() {
/* 47 */     List children = new ArrayList();
/* 48 */     Object[] values = (Object[])(Object[])getPropertyValue();
/*    */ 
/* 50 */     for (Object value : values) {
/* 51 */       Node childAdapter = getAdapterFactory().adaptNode(this, "item", value);
/* 52 */       if (childAdapter != null) {
/* 53 */         children.add(childAdapter);
/*    */       }
/* 55 */       if (this.log.isDebugEnabled()) {
/* 56 */         this.log.debug(this + " adding adapter: " + childAdapter, new String[0]);
/*    */       }
/*    */     }
/*    */ 
/* 60 */     return children;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.views.xslt.ArrayAdapter
 * JD-Core Version:    0.6.0
 */