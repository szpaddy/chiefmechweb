/*    */ package org.apache.struts2.views.xslt;
/*    */ 
/*    */ import org.w3c.dom.Attr;
/*    */ import org.w3c.dom.DOMException;
/*    */ import org.w3c.dom.Element;
/*    */ import org.w3c.dom.TypeInfo;
/*    */ 
/*    */ public class ProxyAttrAdapter extends ProxyNodeAdapter
/*    */   implements Attr
/*    */ {
/*    */   public ProxyAttrAdapter(AdapterFactory factory, AdapterNode parent, Attr value)
/*    */   {
/* 38 */     super(factory, parent, value);
/*    */   }
/*    */ 
/*    */   protected Attr attr()
/*    */   {
/* 43 */     return (Attr)getPropertyValue();
/*    */   }
/*    */ 
/*    */   public String getName()
/*    */   {
/* 49 */     return attr().getName();
/*    */   }
/*    */ 
/*    */   public boolean getSpecified() {
/* 53 */     return attr().getSpecified();
/*    */   }
/*    */ 
/*    */   public String getValue() {
/* 57 */     return attr().getValue();
/*    */   }
/*    */ 
/*    */   public void setValue(String string) throws DOMException {
/* 61 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   public Element getOwnerElement() {
/* 65 */     return (Element)getParent();
/*    */   }
/*    */ 
/*    */   public TypeInfo getSchemaTypeInfo()
/*    */   {
/* 71 */     throw operationNotSupported();
/*    */   }
/*    */ 
/*    */   public boolean isId() {
/* 75 */     throw operationNotSupported();
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 83 */     return "ProxyAttribute for: " + attr();
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.views.xslt.ProxyAttrAdapter
 * JD-Core Version:    0.6.0
 */