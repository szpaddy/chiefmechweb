/*    */ package org.apache.struts2.views.xslt;
/*    */ 
/*    */ import org.w3c.dom.DOMException;
/*    */ import org.w3c.dom.NamedNodeMap;
/*    */ import org.w3c.dom.Node;
/*    */ 
/*    */ public class ProxyNamedNodeMap
/*    */   implements NamedNodeMap
/*    */ {
/*    */   private NamedNodeMap nodes;
/*    */   private AdapterFactory adapterFactory;
/*    */   private AdapterNode parent;
/*    */ 
/*    */   public ProxyNamedNodeMap(AdapterFactory factory, AdapterNode parent, NamedNodeMap nodes)
/*    */   {
/* 42 */     this.nodes = nodes;
/* 43 */     this.adapterFactory = factory;
/* 44 */     this.parent = parent;
/*    */   }
/*    */ 
/*    */   protected Node wrap(Node node) {
/* 48 */     return this.adapterFactory.proxyNode(this.parent, node);
/*    */   }
/*    */ 
/*    */   public int getLength() {
/* 52 */     return this.nodes.getLength();
/*    */   }
/*    */ 
/*    */   public Node item(int index) {
/* 56 */     return wrap(this.nodes.item(index));
/*    */   }
/*    */ 
/*    */   public Node getNamedItem(String name) {
/* 60 */     return wrap(this.nodes.getNamedItem(name));
/*    */   }
/*    */ 
/*    */   public Node removeNamedItem(String name) throws DOMException {
/* 64 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   public Node setNamedItem(Node arg) throws DOMException {
/* 68 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   public Node setNamedItemNS(Node arg) throws DOMException {
/* 72 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   public Node getNamedItemNS(String namespaceURI, String localName) {
/* 76 */     return wrap(this.nodes.getNamedItemNS(namespaceURI, localName));
/*    */   }
/*    */ 
/*    */   public Node removeNamedItemNS(String namespaceURI, String localName) throws DOMException {
/* 80 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.views.xslt.ProxyNamedNodeMap
 * JD-Core Version:    0.6.0
 */