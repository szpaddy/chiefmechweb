/*     */ package org.apache.struts2.views.xslt;
/*     */ 
/*     */ import com.opensymphony.xwork2.util.logging.Logger;
/*     */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*     */ import org.w3c.dom.DOMException;
/*     */ import org.w3c.dom.NamedNodeMap;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ public abstract class ProxyNodeAdapter extends AbstractAdapterNode
/*     */ {
/*  39 */   private Logger log = LoggerFactory.getLogger(getClass());
/*     */ 
/*     */   public ProxyNodeAdapter(AdapterFactory factory, AdapterNode parent, Node value) {
/*  42 */     setContext(factory, parent, "document", value);
/*  43 */     this.log.debug("proxied node is: " + value, new String[0]);
/*  44 */     this.log.debug("node class is: " + value.getClass(), new String[0]);
/*  45 */     this.log.debug("node type is: " + value.getNodeType(), new String[0]);
/*  46 */     this.log.debug("node name is: " + value.getNodeName(), new String[0]);
/*     */   }
/*     */ 
/*     */   protected Node node()
/*     */   {
/*  53 */     return (Node)getPropertyValue();
/*     */   }
/*     */ 
/*     */   protected Node wrap(Node node)
/*     */   {
/*  62 */     return getAdapterFactory().proxyNode(this, node);
/*     */   }
/*     */ 
/*     */   protected NamedNodeMap wrap(NamedNodeMap nnm) {
/*  66 */     return getAdapterFactory().proxyNamedNodeMap(this, nnm);
/*     */   }
/*     */ 
/*     */   public String getNodeName()
/*     */   {
/*  77 */     this.log.trace("getNodeName", new String[0]);
/*  78 */     return node().getNodeName();
/*     */   }
/*     */ 
/*     */   public String getNodeValue() throws DOMException {
/*  82 */     this.log.trace("getNodeValue", new String[0]);
/*  83 */     return node().getNodeValue();
/*     */   }
/*     */ 
/*     */   public short getNodeType() {
/*  87 */     if (this.log.isTraceEnabled())
/*  88 */       this.log.trace("getNodeType: " + getNodeName() + ": " + node().getNodeType(), new String[0]);
/*  89 */     return node().getNodeType();
/*     */   }
/*     */ 
/*     */   public NamedNodeMap getAttributes() {
/*  93 */     NamedNodeMap nnm = wrap(node().getAttributes());
/*  94 */     if (this.log.isTraceEnabled())
/*  95 */       this.log.trace("getAttributes: " + nnm, new String[0]);
/*  96 */     return nnm;
/*     */   }
/*     */ 
/*     */   public boolean hasChildNodes() {
/* 100 */     this.log.trace("hasChildNodes", new String[0]);
/* 101 */     return node().hasChildNodes();
/*     */   }
/*     */ 
/*     */   public boolean isSupported(String s, String s1) {
/* 105 */     this.log.trace("isSupported", new String[0]);
/*     */ 
/* 107 */     return node().isSupported(s, s1);
/*     */   }
/*     */ 
/*     */   public String getNamespaceURI() {
/* 111 */     this.log.trace("getNamespaceURI", new String[0]);
/* 112 */     return node().getNamespaceURI();
/*     */   }
/*     */ 
/*     */   public String getPrefix() {
/* 116 */     this.log.trace("getPrefix", new String[0]);
/* 117 */     return node().getPrefix();
/*     */   }
/*     */ 
/*     */   public String getLocalName() {
/* 121 */     this.log.trace("getLocalName", new String[0]);
/* 122 */     return node().getLocalName();
/*     */   }
/*     */ 
/*     */   public boolean hasAttributes() {
/* 126 */     this.log.trace("hasAttributes", new String[0]);
/* 127 */     return node().hasAttributes();
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 133 */     return "ProxyNode for: " + node();
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.views.xslt.ProxyNodeAdapter
 * JD-Core Version:    0.6.0
 */