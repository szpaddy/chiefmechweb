/*     */ package org.apache.struts2.views.xslt;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.struts2.StrutsException;
/*     */ import org.w3c.dom.Attr;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.NamedNodeMap;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.Text;
/*     */ 
/*     */ public class AdapterFactory
/*     */ {
/*  94 */   private Map<Class, Class> adapterTypes = new HashMap();
/*     */ 
/*     */   public void registerAdapterType(Class type, Class adapterType)
/*     */   {
/* 103 */     this.adapterTypes.put(type, adapterType);
/*     */   }
/*     */ 
/*     */   public Document adaptDocument(String propertyName, Object propertyValue)
/*     */     throws IllegalAccessException, InstantiationException
/*     */   {
/* 121 */     return new SimpleAdapterDocument(this, null, propertyName, propertyValue);
/*     */   }
/*     */ 
/*     */   public Node adaptNode(AdapterNode parent, String propertyName, Object value)
/*     */   {
/* 133 */     Class adapterClass = getAdapterForValue(value);
/* 134 */     if (adapterClass != null) {
/* 135 */       return constructAdapterInstance(adapterClass, parent, propertyName, value);
/*     */     }
/*     */ 
/* 138 */     if ((value instanceof Document)) {
/* 139 */       value = ((Document)value).getDocumentElement();
/*     */     }
/*     */ 
/* 142 */     if ((value instanceof Node)) {
/* 143 */       return proxyNode(parent, (Node)value);
/*     */     }
/*     */ 
/* 146 */     Class valueType = value.getClass();
/*     */ 
/* 148 */     if (valueType.isArray())
/* 149 */       adapterClass = ArrayAdapter.class;
/* 150 */     else if (((value instanceof String)) || ((value instanceof Number)) || ((value instanceof Boolean)) || (valueType.isPrimitive()))
/* 151 */       adapterClass = StringAdapter.class;
/* 152 */     else if ((value instanceof Collection))
/* 153 */       adapterClass = CollectionAdapter.class;
/* 154 */     else if ((value instanceof Map))
/* 155 */       adapterClass = MapAdapter.class;
/*     */     else {
/* 157 */       adapterClass = BeanAdapter.class;
/*     */     }
/* 159 */     return constructAdapterInstance(adapterClass, parent, propertyName, value);
/*     */   }
/*     */ 
/*     */   public Node proxyNode(AdapterNode parent, Node node)
/*     */   {
/* 176 */     if ((node instanceof Document)) {
/* 177 */       node = ((Document)node).getDocumentElement();
/*     */     }
/* 179 */     if (node == null)
/* 180 */       return null;
/* 181 */     if (node.getNodeType() == 1)
/* 182 */       return new ProxyElementAdapter(this, parent, (Element)node);
/* 183 */     if (node.getNodeType() == 3)
/* 184 */       return new ProxyTextNodeAdapter(this, parent, (Text)node);
/* 185 */     if (node.getNodeType() == 2) {
/* 186 */       return new ProxyAttrAdapter(this, parent, (Attr)node);
/*     */     }
/* 188 */     return null;
/*     */   }
/*     */ 
/*     */   public NamedNodeMap proxyNamedNodeMap(AdapterNode parent, NamedNodeMap nnm) {
/* 192 */     return new ProxyNamedNodeMap(this, parent, nnm);
/*     */   }
/*     */ 
/*     */   private Node constructAdapterInstance(Class adapterClass, AdapterNode parent, String propertyName, Object propertyValue)
/*     */   {
/*     */     try
/*     */     {
/* 202 */       adapterClass.getConstructor(new Class[0]);
/*     */     } catch (NoSuchMethodException e1) {
/* 204 */       throw new StrutsException("Adapter class: " + adapterClass + " does not have a no-args consructor.");
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 209 */       AdapterNode adapterNode = (AdapterNode)adapterClass.newInstance();
/* 210 */       adapterNode.setAdapterFactory(this);
/* 211 */       adapterNode.setParent(parent);
/* 212 */       adapterNode.setPropertyName(propertyName);
/* 213 */       adapterNode.setPropertyValue(propertyValue);
/*     */ 
/* 215 */       return adapterNode;
/*     */     }
/*     */     catch (IllegalAccessException e) {
/* 218 */       throw new StrutsException("Cannot adapt " + propertyValue + " (" + propertyName + ") :" + e.getMessage(), e); } catch (InstantiationException e) {
/*     */     }
/* 220 */     throw new StrutsException("Cannot adapt " + propertyValue + " (" + propertyName + ") :" + e.getMessage(), e);
/*     */   }
/*     */ 
/*     */   public Node adaptNullValue(AdapterNode parent, String propertyName)
/*     */   {
/* 231 */     return new StringAdapter(this, parent, propertyName, "null");
/*     */   }
/*     */ 
/*     */   public Class getAdapterForValue(Object value)
/*     */   {
/* 236 */     return (Class)this.adapterTypes.get(value.getClass());
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.views.xslt.AdapterFactory
 * JD-Core Version:    0.6.0
 */