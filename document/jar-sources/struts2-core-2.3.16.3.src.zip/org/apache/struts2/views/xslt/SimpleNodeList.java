/*    */ package org.apache.struts2.views.xslt;
/*    */ 
/*    */ import com.opensymphony.xwork2.util.logging.Logger;
/*    */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*    */ import java.util.List;
/*    */ import org.w3c.dom.Node;
/*    */ import org.w3c.dom.NodeList;
/*    */ 
/*    */ public class SimpleNodeList
/*    */   implements NodeList
/*    */ {
/* 33 */   private Logger log = LoggerFactory.getLogger(SimpleNodeList.class);
/*    */   private List<Node> nodes;
/*    */ 
/*    */   public SimpleNodeList(List<Node> nodes)
/*    */   {
/* 38 */     this.nodes = nodes;
/*    */   }
/*    */ 
/*    */   public int getLength() {
/* 42 */     if (this.log.isTraceEnabled())
/* 43 */       this.log.trace("getLength: " + this.nodes.size(), new String[0]);
/* 44 */     return this.nodes.size();
/*    */   }
/*    */ 
/*    */   public Node item(int i) {
/* 48 */     this.log.trace("getItem: " + i, new String[0]);
/* 49 */     return (Node)this.nodes.get(i);
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 53 */     StringBuilder sb = new StringBuilder("SimpleNodeList: [");
/* 54 */     for (int i = 0; i < getLength(); i++)
/* 55 */       sb.append(item(i).getNodeName()).append(',');
/* 56 */     sb.append("]");
/* 57 */     return sb.toString();
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.views.xslt.SimpleNodeList
 * JD-Core Version:    0.6.0
 */