/*     */ package org.apache.struts2.views.xslt;
/*     */ 
/*     */ import com.opensymphony.xwork2.util.DomHelper;
/*     */ import com.opensymphony.xwork2.util.logging.Logger;
/*     */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*     */ import java.io.StringReader;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.w3c.dom.Node;
/*     */ import org.xml.sax.InputSource;
/*     */ 
/*     */ public class StringAdapter extends AbstractAdapterElement
/*     */ {
/*  50 */   private Logger log = LoggerFactory.getLogger(getClass());
/*     */   boolean parseStringAsXML;
/*     */ 
/*     */   public StringAdapter()
/*     */   {
/*     */   }
/*     */ 
/*     */   public StringAdapter(AdapterFactory adapterFactory, AdapterNode parent, String propertyName, String value)
/*     */   {
/*  57 */     setContext(adapterFactory, parent, propertyName, value);
/*     */   }
/*     */ 
/*     */   protected String getStringValue()
/*     */   {
/*  70 */     return getPropertyValue().toString();
/*     */   }
/*     */ 
/*     */   protected List<Node> buildChildAdapters()
/*     */   {
/*     */     Node node;
/*  75 */     if (getParseStringAsXML()) {
/*  76 */       this.log.debug("parsing string as xml: " + getStringValue(), new String[0]);
/*     */ 
/*  78 */       Node node = DomHelper.parse(new InputSource(new StringReader(getStringValue())));
/*  79 */       node = getAdapterFactory().proxyNode(this, node);
/*     */     } else {
/*  81 */       this.log.debug("using string as is: " + getStringValue(), new String[0]);
/*     */ 
/*  83 */       node = new SimpleTextNode(getAdapterFactory(), this, "text", getStringValue());
/*     */     }
/*     */ 
/*  86 */     List children = new ArrayList();
/*  87 */     children.add(node);
/*  88 */     return children;
/*     */   }
/*     */ 
/*     */   public boolean getParseStringAsXML()
/*     */   {
/*  98 */     return this.parseStringAsXML;
/*     */   }
/*     */ 
/*     */   public void setParseStringAsXML(boolean parseStringAsXML)
/*     */   {
/* 111 */     this.parseStringAsXML = parseStringAsXML;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.views.xslt.StringAdapter
 * JD-Core Version:    0.6.0
 */