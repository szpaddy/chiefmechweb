package org.apache.struts2.views.xslt;

import org.w3c.dom.Node;

public abstract interface AdapterNode extends Node
{
  public abstract AdapterFactory getAdapterFactory();

  public abstract void setAdapterFactory(AdapterFactory paramAdapterFactory);

  public abstract AdapterNode getParent();

  public abstract void setParent(AdapterNode paramAdapterNode);

  public abstract Node getChildBefore(Node paramNode);

  public abstract Node getChildAfter(Node paramNode);

  public abstract String getPropertyName();

  public abstract void setPropertyName(String paramString);

  public abstract Object getPropertyValue();

  public abstract void setPropertyValue(Object paramObject);
}

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.views.xslt.AdapterNode
 * JD-Core Version:    0.6.0
 */