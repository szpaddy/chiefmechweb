/*     */ package org.apache.struts2.views.xslt;
/*     */ 
/*     */ import com.opensymphony.xwork2.util.logging.Logger;
/*     */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.w3c.dom.Attr;
/*     */ import org.w3c.dom.DOMException;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ import org.w3c.dom.TypeInfo;
/*     */ 
/*     */ public class ProxyElementAdapter extends ProxyNodeAdapter
/*     */   implements Element
/*     */ {
/*  48 */   private Logger log = LoggerFactory.getLogger(getClass());
/*     */ 
/*     */   public ProxyElementAdapter(AdapterFactory factory, AdapterNode parent, Element value) {
/*  51 */     super(factory, parent, value);
/*     */   }
/*     */ 
/*     */   protected Element element()
/*     */   {
/*  58 */     return (Element)getPropertyValue();
/*     */   }
/*     */ 
/*     */   protected List<Node> buildChildAdapters() {
/*  62 */     List adapters = new ArrayList();
/*  63 */     NodeList children = node().getChildNodes();
/*  64 */     for (int i = 0; i < children.getLength(); i++) {
/*  65 */       Node child = children.item(i);
/*  66 */       Node adapter = wrap(child);
/*  67 */       if (adapter != null) {
/*  68 */         this.log.debug("wrapped child node: " + child.getNodeName(), new String[0]);
/*  69 */         adapters.add(adapter);
/*     */       }
/*     */     }
/*  72 */     return adapters;
/*     */   }
/*     */ 
/*     */   public String getTagName()
/*     */   {
/*  78 */     return element().getTagName();
/*     */   }
/*     */ 
/*     */   public boolean hasAttribute(String name) {
/*  82 */     return element().hasAttribute(name);
/*     */   }
/*     */ 
/*     */   public String getAttribute(String name) {
/*  86 */     return element().getAttribute(name);
/*     */   }
/*     */ 
/*     */   public boolean hasAttributeNS(String namespaceURI, String localName) {
/*  90 */     return element().hasAttributeNS(namespaceURI, localName);
/*     */   }
/*     */ 
/*     */   public Attr getAttributeNode(String name) {
/*  94 */     this.log.debug("wrapping attribute", new String[0]);
/*  95 */     return (Attr)wrap(element().getAttributeNode(name));
/*     */   }
/*     */ 
/*     */   public NodeList getElementsByTagName(String name)
/*     */   {
/* 100 */     return super.getElementsByTagName(name);
/*     */   }
/*     */ 
/*     */   public String getAttributeNS(String namespaceURI, String localName) {
/* 104 */     return element().getAttributeNS(namespaceURI, localName);
/*     */   }
/*     */ 
/*     */   public Attr getAttributeNodeNS(String namespaceURI, String localName) {
/* 108 */     return (Attr)wrap(element().getAttributeNodeNS(namespaceURI, localName));
/*     */   }
/*     */ 
/*     */   public NodeList getElementsByTagNameNS(String namespaceURI, String localName) {
/* 112 */     return super.getElementsByTagNameNS(namespaceURI, localName);
/*     */   }
/*     */ 
/*     */   public void removeAttribute(String name)
/*     */     throws DOMException
/*     */   {
/* 118 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public void removeAttributeNS(String namespaceURI, String localName) throws DOMException {
/* 122 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public void setAttribute(String name, String value) throws DOMException {
/* 126 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public Attr removeAttributeNode(Attr oldAttr) throws DOMException {
/* 130 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public Attr setAttributeNode(Attr newAttr) throws DOMException {
/* 134 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public Attr setAttributeNodeNS(Attr newAttr) throws DOMException {
/* 138 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public void setAttributeNS(String namespaceURI, String qualifiedName, String value) throws DOMException {
/* 142 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public TypeInfo getSchemaTypeInfo()
/*     */   {
/* 150 */     throw operationNotSupported();
/*     */   }
/*     */ 
/*     */   public void setIdAttribute(String string, boolean b) throws DOMException {
/* 154 */     throw operationNotSupported();
/*     */   }
/*     */ 
/*     */   public void setIdAttributeNS(String string, String string1, boolean b) throws DOMException {
/* 158 */     throw operationNotSupported();
/*     */   }
/*     */ 
/*     */   public void setIdAttributeNode(Attr attr, boolean b) throws DOMException {
/* 162 */     throw operationNotSupported();
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 168 */     return "ProxyElement for: " + element();
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.views.xslt.ProxyElementAdapter
 * JD-Core Version:    0.6.0
 */