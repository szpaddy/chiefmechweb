/*    */ package org.apache.struts2.views.xslt;
/*    */ 
/*    */ import com.opensymphony.xwork2.util.logging.Logger;
/*    */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import org.w3c.dom.Node;
/*    */ 
/*    */ public class CollectionAdapter extends AbstractAdapterElement
/*    */ {
/* 38 */   private Logger log = LoggerFactory.getLogger(getClass());
/*    */ 
/*    */   public CollectionAdapter() {
/*    */   }
/*    */   public CollectionAdapter(AdapterFactory rootAdapterFactory, AdapterNode parent, String propertyName, Object value) {
/* 43 */     setContext(rootAdapterFactory, parent, propertyName, value);
/*    */   }
/*    */ 
/*    */   protected List<Node> buildChildAdapters() {
/* 47 */     Collection values = (Collection)getPropertyValue();
/* 48 */     List children = new ArrayList(values.size());
/*    */ 
/* 50 */     for (Iterator i$ = values.iterator(); i$.hasNext(); ) { Object value = i$.next();
/*    */       Node childAdapter;
/*    */       Node childAdapter;
/* 52 */       if (value == null)
/* 53 */         childAdapter = getAdapterFactory().adaptNullValue(this, "item");
/*    */       else {
/* 55 */         childAdapter = getAdapterFactory().adaptNode(this, "item", value);
/*    */       }
/* 57 */       if (childAdapter != null) {
/* 58 */         children.add(childAdapter);
/*    */       }
/* 60 */       if (this.log.isDebugEnabled()) {
/* 61 */         this.log.debug(this + " adding adapter: " + childAdapter, new String[0]);
/*    */       }
/*    */     }
/*    */ 
/* 65 */     return children;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.views.xslt.CollectionAdapter
 * JD-Core Version:    0.6.0
 */