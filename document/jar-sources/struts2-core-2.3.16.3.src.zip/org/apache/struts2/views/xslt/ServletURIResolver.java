/*    */ package org.apache.struts2.views.xslt;
/*    */ 
/*    */ import com.opensymphony.xwork2.util.logging.Logger;
/*    */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*    */ import java.io.InputStream;
/*    */ import javax.servlet.ServletContext;
/*    */ import javax.xml.transform.Source;
/*    */ import javax.xml.transform.TransformerException;
/*    */ import javax.xml.transform.URIResolver;
/*    */ import javax.xml.transform.stream.StreamSource;
/*    */ 
/*    */ public class ServletURIResolver
/*    */   implements URIResolver
/*    */ {
/* 45 */   private Logger log = LoggerFactory.getLogger(getClass());
/*    */   static final String PROTOCOL = "response:";
/*    */   private ServletContext sc;
/*    */ 
/*    */   public ServletURIResolver(ServletContext sc)
/*    */   {
/* 51 */     this.log.trace("ServletURIResolver: " + sc, new String[0]);
/* 52 */     this.sc = sc;
/*    */   }
/*    */ 
/*    */   public Source resolve(String href, String base) throws TransformerException {
/* 56 */     this.log.debug("ServletURIResolver resolve(): href=" + href + ", base=" + base, new String[0]);
/* 57 */     if (href.startsWith("response:")) {
/* 58 */       String res = href.substring("response:".length());
/* 59 */       this.log.debug("Resolving resource <" + res + ">", new String[0]);
/*    */ 
/* 61 */       InputStream is = this.sc.getResourceAsStream(res);
/*    */ 
/* 63 */       if (is == null) {
/* 64 */         throw new TransformerException("Resource " + res + " not found in resources.");
/*    */       }
/*    */ 
/* 68 */       return new StreamSource(is);
/*    */     }
/*    */ 
/* 71 */     throw new TransformerException("Cannot handle procotol of resource " + href);
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.views.xslt.ServletURIResolver
 * JD-Core Version:    0.6.0
 */