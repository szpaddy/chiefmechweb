/*     */ package org.apache.struts2.views.xslt;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import org.apache.struts2.StrutsException;
/*     */ import org.w3c.dom.Attr;
/*     */ import org.w3c.dom.CDATASection;
/*     */ import org.w3c.dom.Comment;
/*     */ import org.w3c.dom.DOMConfiguration;
/*     */ import org.w3c.dom.DOMException;
/*     */ import org.w3c.dom.DOMImplementation;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.DocumentFragment;
/*     */ import org.w3c.dom.DocumentType;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.EntityReference;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ import org.w3c.dom.ProcessingInstruction;
/*     */ import org.w3c.dom.Text;
/*     */ 
/*     */ public class SimpleAdapterDocument extends AbstractAdapterNode
/*     */   implements Document
/*     */ {
/*     */   private Element rootElement;
/*     */ 
/*     */   public SimpleAdapterDocument(AdapterFactory adapterFactory, AdapterNode parent, String propertyName, Object value)
/*     */   {
/*  61 */     setContext(adapterFactory, parent, propertyName, value);
/*     */   }
/*     */ 
/*     */   public void setPropertyValue(Object prop)
/*     */   {
/*  66 */     super.setPropertyValue(prop);
/*  67 */     this.rootElement = null;
/*     */   }
/*     */ 
/*     */   private Element getRootElement()
/*     */   {
/*  74 */     if (this.rootElement != null) {
/*  75 */       return this.rootElement;
/*     */     }
/*  77 */     Node node = getAdapterFactory().adaptNode(this, getPropertyName(), getPropertyValue());
/*     */ 
/*  79 */     if ((node instanceof Element))
/*  80 */       this.rootElement = ((Element)node);
/*     */     else {
/*  82 */       throw new StrutsException("Document adapter expected to wrap an Element type.  Node is not an element:" + node);
/*     */     }
/*     */ 
/*  85 */     return this.rootElement;
/*     */   }
/*     */ 
/*     */   protected List<Node> getChildAdapters() {
/*  89 */     return Arrays.asList(new Node[] { getRootElement() });
/*     */   }
/*     */ 
/*     */   public NodeList getChildNodes() {
/*  93 */     return new NodeList() {
/*     */       public Node item(int i) {
/*  95 */         return SimpleAdapterDocument.this.getRootElement();
/*     */       }
/*     */ 
/*     */       public int getLength() {
/*  99 */         return 1;
/*     */       } } ;
/*     */   }
/*     */ 
/*     */   public DocumentType getDoctype() {
/* 105 */     return null;
/*     */   }
/*     */ 
/*     */   public Element getDocumentElement() {
/* 109 */     return getRootElement();
/*     */   }
/*     */ 
/*     */   public Element getElementById(String string) {
/* 113 */     return null;
/*     */   }
/*     */ 
/*     */   public NodeList getElementsByTagName(String string) {
/* 117 */     return null;
/*     */   }
/*     */ 
/*     */   public NodeList getElementsByTagNameNS(String string, String string1) {
/* 121 */     return null;
/*     */   }
/*     */ 
/*     */   public Node getFirstChild() {
/* 125 */     return getRootElement();
/*     */   }
/*     */ 
/*     */   public DOMImplementation getImplementation() {
/* 129 */     return null;
/*     */   }
/*     */ 
/*     */   public Node getLastChild() {
/* 133 */     return getRootElement();
/*     */   }
/*     */ 
/*     */   public String getNodeName() {
/* 137 */     return "#document";
/*     */   }
/*     */ 
/*     */   public short getNodeType() {
/* 141 */     return 9;
/*     */   }
/*     */ 
/*     */   public Attr createAttribute(String string) throws DOMException {
/* 145 */     return null;
/*     */   }
/*     */ 
/*     */   public Attr createAttributeNS(String string, String string1) throws DOMException {
/* 149 */     return null;
/*     */   }
/*     */ 
/*     */   public CDATASection createCDATASection(String string) throws DOMException {
/* 153 */     return null;
/*     */   }
/*     */ 
/*     */   public Comment createComment(String string) {
/* 157 */     return null;
/*     */   }
/*     */ 
/*     */   public DocumentFragment createDocumentFragment() {
/* 161 */     return null;
/*     */   }
/*     */ 
/*     */   public Element createElement(String string) throws DOMException {
/* 165 */     return null;
/*     */   }
/*     */ 
/*     */   public Element createElementNS(String string, String string1) throws DOMException {
/* 169 */     return null;
/*     */   }
/*     */ 
/*     */   public EntityReference createEntityReference(String string) throws DOMException {
/* 173 */     return null;
/*     */   }
/*     */ 
/*     */   public ProcessingInstruction createProcessingInstruction(String string, String string1) throws DOMException {
/* 177 */     return null;
/*     */   }
/*     */ 
/*     */   public Text createTextNode(String string) {
/* 181 */     return null;
/*     */   }
/*     */ 
/*     */   public boolean hasChildNodes() {
/* 185 */     return true;
/*     */   }
/*     */ 
/*     */   public Node importNode(Node node, boolean b) throws DOMException {
/* 189 */     return null;
/*     */   }
/*     */ 
/*     */   public Node getChildAfter(Node child) {
/* 193 */     return null;
/*     */   }
/*     */ 
/*     */   public Node getChildBefore(Node child) {
/* 197 */     return null;
/*     */   }
/*     */ 
/*     */   public String getInputEncoding()
/*     */   {
/* 203 */     throw operationNotSupported();
/*     */   }
/*     */ 
/*     */   public String getXmlEncoding() {
/* 207 */     throw operationNotSupported();
/*     */   }
/*     */ 
/*     */   public boolean getXmlStandalone() {
/* 211 */     throw operationNotSupported();
/*     */   }
/*     */ 
/*     */   public void setXmlStandalone(boolean b) throws DOMException {
/* 215 */     throw operationNotSupported();
/*     */   }
/*     */ 
/*     */   public String getXmlVersion() {
/* 219 */     throw operationNotSupported();
/*     */   }
/*     */ 
/*     */   public void setXmlVersion(String string) throws DOMException {
/* 223 */     throw operationNotSupported();
/*     */   }
/*     */ 
/*     */   public boolean getStrictErrorChecking() {
/* 227 */     throw operationNotSupported();
/*     */   }
/*     */ 
/*     */   public void setStrictErrorChecking(boolean b) {
/* 231 */     throw operationNotSupported();
/*     */   }
/*     */ 
/*     */   public String getDocumentURI() {
/* 235 */     throw operationNotSupported();
/*     */   }
/*     */ 
/*     */   public void setDocumentURI(String string) {
/* 239 */     throw operationNotSupported();
/*     */   }
/*     */ 
/*     */   public Node adoptNode(Node node) throws DOMException {
/* 243 */     throw operationNotSupported();
/*     */   }
/*     */ 
/*     */   public DOMConfiguration getDomConfig() {
/* 247 */     throw operationNotSupported();
/*     */   }
/*     */ 
/*     */   public void normalizeDocument() {
/* 251 */     throw operationNotSupported();
/*     */   }
/*     */ 
/*     */   public Node renameNode(Node node, String string, String string1) throws DOMException {
/* 255 */     return null;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.views.xslt.SimpleAdapterDocument
 * JD-Core Version:    0.6.0
 */