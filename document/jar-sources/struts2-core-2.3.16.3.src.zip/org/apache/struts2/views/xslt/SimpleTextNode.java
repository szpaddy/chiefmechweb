/*     */ package org.apache.struts2.views.xslt;
/*     */ 
/*     */ import org.apache.struts2.StrutsException;
/*     */ import org.w3c.dom.DOMException;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.Text;
/*     */ 
/*     */ public class SimpleTextNode extends AbstractAdapterNode
/*     */   implements Node, Text
/*     */ {
/*     */   public SimpleTextNode(AdapterFactory rootAdapterFactory, AdapterNode parent, String propertyName, Object value)
/*     */   {
/*  36 */     setContext(rootAdapterFactory, parent, propertyName, value);
/*     */   }
/*     */ 
/*     */   protected String getStringValue() {
/*  40 */     return getPropertyValue().toString();
/*     */   }
/*     */ 
/*     */   public void setData(String string) throws DOMException {
/*  44 */     throw new StrutsException("Operation not supported");
/*     */   }
/*     */ 
/*     */   public String getData() throws DOMException {
/*  48 */     return getStringValue();
/*     */   }
/*     */ 
/*     */   public int getLength() {
/*  52 */     return getStringValue().length();
/*     */   }
/*     */ 
/*     */   public String getNodeName() {
/*  56 */     return "#text";
/*     */   }
/*     */ 
/*     */   public short getNodeType() {
/*  60 */     return 3;
/*     */   }
/*     */ 
/*     */   public String getNodeValue() throws DOMException {
/*  64 */     return getStringValue();
/*     */   }
/*     */ 
/*     */   public void appendData(String string) throws DOMException {
/*  68 */     throw new StrutsException("Operation not supported");
/*     */   }
/*     */ 
/*     */   public void deleteData(int i, int i1) throws DOMException {
/*  72 */     throw new StrutsException("Operation not supported");
/*     */   }
/*     */ 
/*     */   public void insertData(int i, String string) throws DOMException {
/*  76 */     throw new StrutsException("Operation not supported");
/*     */   }
/*     */ 
/*     */   public void replaceData(int i, int i1, String string) throws DOMException {
/*  80 */     throw new StrutsException("Operation not supported");
/*     */   }
/*     */ 
/*     */   public Text splitText(int i) throws DOMException {
/*  84 */     throw new StrutsException("Operation not supported");
/*     */   }
/*     */ 
/*     */   public String substringData(int beginIndex, int endIndex) throws DOMException {
/*  88 */     return getStringValue().substring(beginIndex, endIndex);
/*     */   }
/*     */ 
/*     */   public boolean isElementContentWhitespace()
/*     */   {
/*  94 */     throw operationNotSupported();
/*     */   }
/*     */ 
/*     */   public String getWholeText() {
/*  98 */     throw operationNotSupported();
/*     */   }
/*     */ 
/*     */   public Text replaceWholeText(String string) throws DOMException {
/* 102 */     throw operationNotSupported();
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.views.xslt.SimpleTextNode
 * JD-Core Version:    0.6.0
 */