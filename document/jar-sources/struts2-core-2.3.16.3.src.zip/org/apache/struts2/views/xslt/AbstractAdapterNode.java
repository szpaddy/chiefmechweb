/*     */ package org.apache.struts2.views.xslt;
/*     */ 
/*     */ import com.opensymphony.xwork2.util.logging.Logger;
/*     */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*     */ import java.util.ArrayList;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import org.apache.struts2.StrutsException;
/*     */ import org.w3c.dom.DOMException;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.NamedNodeMap;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ import org.w3c.dom.UserDataHandler;
/*     */ 
/*     */ public abstract class AbstractAdapterNode
/*     */   implements AdapterNode
/*     */ {
/*  49 */   private static final NamedNodeMap EMPTY_NAMEDNODEMAP = new NamedNodeMap()
/*     */   {
/*     */     public int getLength() {
/*  52 */       return 0;
/*     */     }
/*     */ 
/*     */     public Node item(int index) {
/*  56 */       return null;
/*     */     }
/*     */ 
/*     */     public Node getNamedItem(String name) {
/*  60 */       return null;
/*     */     }
/*     */ 
/*     */     public Node removeNamedItem(String name) throws DOMException {
/*  64 */       return null;
/*     */     }
/*     */ 
/*     */     public Node setNamedItem(Node arg) throws DOMException {
/*  68 */       return null;
/*     */     }
/*     */ 
/*     */     public Node setNamedItemNS(Node arg) throws DOMException {
/*  72 */       return null;
/*     */     }
/*     */ 
/*     */     public Node getNamedItemNS(String namespaceURI, String localName) {
/*  76 */       return null;
/*     */     }
/*     */ 
/*     */     public Node removeNamedItemNS(String namespaceURI, String localName) throws DOMException {
/*  80 */       return null;
/*     */     } } ;
/*     */   private List<Node> childAdapters;
/*  85 */   private Logger log = LoggerFactory.getLogger(getClass());
/*     */   private Object propertyValue;
/*     */   private String propertyName;
/*     */   private AdapterNode parent;
/*     */   private AdapterFactory adapterFactory;
/*     */ 
/*  95 */   public AbstractAdapterNode() { if (LoggerFactory.getLogger(getClass()).isDebugEnabled())
/*  96 */       LoggerFactory.getLogger(getClass()).debug("Creating " + this, new String[0]);
/*     */   }
/*     */ 
/*     */   protected void setContext(AdapterFactory adapterFactory, AdapterNode parent, String propertyName, Object value)
/*     */   {
/* 108 */     setAdapterFactory(adapterFactory);
/* 109 */     setParent(parent);
/* 110 */     setPropertyName(propertyName);
/* 111 */     setPropertyValue(value);
/*     */   }
/*     */ 
/*     */   protected List<Node> buildChildAdapters()
/*     */   {
/* 120 */     return new ArrayList();
/*     */   }
/*     */ 
/*     */   protected List<Node> getChildAdapters()
/*     */   {
/* 127 */     if (this.childAdapters == null) {
/* 128 */       this.childAdapters = buildChildAdapters();
/*     */     }
/* 130 */     return this.childAdapters;
/*     */   }
/*     */ 
/*     */   public Node getChildBeforeOrAfter(Node child, boolean before) {
/* 134 */     this.log.debug("getChildBeforeOrAfter: ", new String[0]);
/* 135 */     List adapters = getChildAdapters();
/* 136 */     if (this.log.isDebugEnabled()) {
/* 137 */       this.log.debug("childAdapters = " + adapters, new String[0]);
/* 138 */       this.log.debug("child = " + child, new String[0]);
/*     */     }
/* 140 */     int index = adapters.indexOf(child);
/* 141 */     if (index < 0)
/* 142 */       throw new StrutsException(child + " is no child of " + this);
/* 143 */     int siblingIndex = before ? index - 1 : index + 1;
/* 144 */     return (0 < siblingIndex) && (siblingIndex < adapters.size()) ? (Node)adapters.get(siblingIndex) : null;
/*     */   }
/*     */ 
/*     */   public Node getChildAfter(Node child)
/*     */   {
/* 149 */     this.log.trace("getChildafter", new String[0]);
/* 150 */     return getChildBeforeOrAfter(child, false);
/*     */   }
/*     */ 
/*     */   public Node getChildBefore(Node child) {
/* 154 */     this.log.trace("getchildbefore", new String[0]);
/* 155 */     return getChildBeforeOrAfter(child, true);
/*     */   }
/*     */ 
/*     */   public NodeList getElementsByTagName(String tagName) {
/* 159 */     if (tagName.equals("*")) {
/* 160 */       return getChildNodes();
/*     */     }
/* 162 */     LinkedList filteredChildren = new LinkedList();
/*     */ 
/* 164 */     for (Node adapterNode : getChildAdapters()) {
/* 165 */       if (adapterNode.getNodeName().equals(tagName)) {
/* 166 */         filteredChildren.add(adapterNode);
/*     */       }
/*     */     }
/*     */ 
/* 170 */     return new SimpleNodeList(filteredChildren);
/*     */   }
/*     */ 
/*     */   public NodeList getElementsByTagNameNS(String string, String string1)
/*     */   {
/* 176 */     return null;
/*     */   }
/*     */ 
/*     */   public NamedNodeMap getAttributes()
/*     */   {
/* 182 */     return EMPTY_NAMEDNODEMAP;
/*     */   }
/*     */ 
/*     */   public NodeList getChildNodes() {
/* 186 */     NodeList nl = new SimpleNodeList(getChildAdapters());
/* 187 */     if (this.log.isDebugEnabled()) {
/* 188 */       this.log.debug("getChildNodes for tag: " + getNodeName() + " num children: " + nl.getLength(), new String[0]);
/*     */     }
/* 190 */     return nl;
/*     */   }
/*     */ 
/*     */   public Node getFirstChild() {
/* 194 */     return getChildNodes().getLength() > 0 ? getChildNodes().item(0) : null;
/*     */   }
/*     */ 
/*     */   public Node getLastChild() {
/* 198 */     return getChildNodes().getLength() > 0 ? getChildNodes().item(getChildNodes().getLength() - 1) : null;
/*     */   }
/*     */ 
/*     */   public String getLocalName()
/*     */   {
/* 203 */     return null;
/*     */   }
/*     */ 
/*     */   public String getNamespaceURI() {
/* 207 */     return null;
/*     */   }
/*     */ 
/*     */   public void setNodeValue(String string) throws DOMException {
/* 211 */     throw operationNotSupported();
/*     */   }
/*     */ 
/*     */   public String getNodeValue() throws DOMException {
/* 215 */     throw operationNotSupported();
/*     */   }
/*     */ 
/*     */   public Document getOwnerDocument() {
/* 219 */     return null;
/*     */   }
/*     */ 
/*     */   public Node getParentNode() {
/* 223 */     this.log.trace("getParentNode", new String[0]);
/* 224 */     return getParent();
/*     */   }
/*     */ 
/*     */   public AdapterNode getParent() {
/* 228 */     return this.parent;
/*     */   }
/*     */ 
/*     */   public void setParent(AdapterNode parent) {
/* 232 */     this.parent = parent;
/*     */   }
/*     */ 
/*     */   public Object getPropertyValue() {
/* 236 */     return this.propertyValue;
/*     */   }
/*     */ 
/*     */   public void setPropertyValue(Object prop) {
/* 240 */     this.propertyValue = prop;
/*     */   }
/*     */ 
/*     */   public void setPrefix(String string) throws DOMException {
/* 244 */     throw operationNotSupported();
/*     */   }
/*     */ 
/*     */   public String getPrefix() {
/* 248 */     return null;
/*     */   }
/*     */ 
/*     */   public Node getNextSibling() {
/* 252 */     Node next = getParent().getChildAfter(this);
/* 253 */     if (this.log.isTraceEnabled()) {
/* 254 */       this.log.trace("getNextSibling on " + getNodeName() + ": " + (next == null ? "null" : next.getNodeName()), new String[0]);
/*     */     }
/*     */ 
/* 258 */     return next;
/*     */   }
/*     */ 
/*     */   public Node getPreviousSibling() {
/* 262 */     return getParent().getChildBefore(this);
/*     */   }
/*     */ 
/*     */   public String getPropertyName() {
/* 266 */     return this.propertyName;
/*     */   }
/*     */ 
/*     */   public void setPropertyName(String name) {
/* 270 */     this.propertyName = name;
/*     */   }
/*     */ 
/*     */   public AdapterFactory getAdapterFactory() {
/* 274 */     return this.adapterFactory;
/*     */   }
/*     */ 
/*     */   public void setAdapterFactory(AdapterFactory adapterFactory) {
/* 278 */     this.adapterFactory = adapterFactory;
/*     */   }
/*     */ 
/*     */   public boolean isSupported(String string, String string1) {
/* 282 */     throw operationNotSupported();
/*     */   }
/*     */ 
/*     */   public Node appendChild(Node node) throws DOMException {
/* 286 */     throw operationNotSupported();
/*     */   }
/*     */ 
/*     */   public Node cloneNode(boolean b) {
/* 290 */     this.log.trace("cloneNode", new String[0]);
/* 291 */     throw operationNotSupported();
/*     */   }
/*     */ 
/*     */   public boolean hasAttributes() {
/* 295 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean hasChildNodes() {
/* 299 */     return false;
/*     */   }
/*     */ 
/*     */   public Node insertBefore(Node node, Node node1) throws DOMException {
/* 303 */     throw operationNotSupported();
/*     */   }
/*     */ 
/*     */   public void normalize() {
/* 307 */     this.log.trace("normalize", new String[0]);
/* 308 */     throw operationNotSupported();
/*     */   }
/*     */ 
/*     */   public Node removeChild(Node node) throws DOMException {
/* 312 */     throw operationNotSupported();
/*     */   }
/*     */ 
/*     */   public Node replaceChild(Node node, Node node1) throws DOMException {
/* 316 */     throw operationNotSupported();
/*     */   }
/*     */ 
/*     */   public boolean isDefaultNamespace(String string)
/*     */   {
/* 322 */     throw operationNotSupported();
/*     */   }
/*     */ 
/*     */   public String lookupNamespaceURI(String string) {
/* 326 */     throw operationNotSupported();
/*     */   }
/*     */ 
/*     */   public String getNodeName() {
/* 330 */     throw operationNotSupported();
/*     */   }
/*     */ 
/*     */   public short getNodeType() {
/* 334 */     throw operationNotSupported();
/*     */   }
/*     */ 
/*     */   public String getBaseURI() {
/* 338 */     throw operationNotSupported();
/*     */   }
/*     */ 
/*     */   public short compareDocumentPosition(Node node) throws DOMException {
/* 342 */     throw operationNotSupported();
/*     */   }
/*     */ 
/*     */   public String getTextContent() throws DOMException {
/* 346 */     throw operationNotSupported();
/*     */   }
/*     */ 
/*     */   public void setTextContent(String string) throws DOMException {
/* 350 */     throw operationNotSupported();
/*     */   }
/*     */ 
/*     */   public boolean isSameNode(Node node)
/*     */   {
/* 355 */     throw operationNotSupported();
/*     */   }
/*     */ 
/*     */   public String lookupPrefix(String string) {
/* 359 */     throw operationNotSupported();
/*     */   }
/*     */ 
/*     */   public boolean isEqualNode(Node node) {
/* 363 */     throw operationNotSupported();
/*     */   }
/*     */ 
/*     */   public Object getFeature(String string, String string1) {
/* 367 */     throw operationNotSupported();
/*     */   }
/*     */ 
/*     */   public Object setUserData(String string, Object object, UserDataHandler userDataHandler) {
/* 371 */     throw operationNotSupported();
/*     */   }
/*     */ 
/*     */   public Object getUserData(String string) {
/* 375 */     throw operationNotSupported();
/*     */   }
/*     */ 
/*     */   protected StrutsException operationNotSupported()
/*     */   {
/* 381 */     return new StrutsException("Operation not supported.");
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 385 */     return getClass() + ": " + getNodeName() + " parent=" + getParentNode();
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.views.xslt.AbstractAdapterNode
 * JD-Core Version:    0.6.0
 */