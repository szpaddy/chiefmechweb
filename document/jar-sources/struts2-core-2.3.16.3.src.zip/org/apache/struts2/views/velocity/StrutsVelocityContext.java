/*     */ package org.apache.struts2.views.velocity;
/*     */ 
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import java.util.Map;
/*     */ import org.apache.velocity.VelocityContext;
/*     */ 
/*     */ public class StrutsVelocityContext extends VelocityContext
/*     */ {
/*     */   private static final long serialVersionUID = 8497212428904436963L;
/*     */   ValueStack stack;
/*     */   VelocityContext[] chainedContexts;
/*     */ 
/*     */   public StrutsVelocityContext(ValueStack stack)
/*     */   {
/*  39 */     this(null, stack);
/*     */   }
/*     */ 
/*     */   public StrutsVelocityContext(VelocityContext[] chainedContexts, ValueStack stack) {
/*  43 */     this.chainedContexts = chainedContexts;
/*  44 */     this.stack = stack;
/*     */   }
/*     */ 
/*     */   public boolean internalContainsKey(Object key)
/*     */   {
/*  49 */     boolean contains = super.internalContainsKey(key);
/*     */ 
/*  52 */     if (contains) {
/*  53 */       return true;
/*     */     }
/*     */ 
/*  57 */     if (this.stack != null) {
/*  58 */       Object o = this.stack.findValue(key.toString());
/*     */ 
/*  60 */       if (o != null) {
/*  61 */         return true;
/*     */       }
/*     */ 
/*  64 */       o = this.stack.getContext().get(key.toString());
/*  65 */       if (o != null) {
/*  66 */         return true;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/*  71 */     if (this.chainedContexts != null) {
/*  72 */       for (int index = 0; index < this.chainedContexts.length; index++) {
/*  73 */         if (this.chainedContexts[index].containsKey(key)) {
/*  74 */           return true;
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/*  80 */     return false;
/*     */   }
/*     */ 
/*     */   public Object internalGet(String key)
/*     */   {
/*  85 */     if (super.internalContainsKey(key)) {
/*  86 */       return super.internalGet(key);
/*     */     }
/*     */ 
/*  90 */     if (this.stack != null) {
/*  91 */       Object object = this.stack.findValue(key);
/*     */ 
/*  93 */       if (object != null) {
/*  94 */         return object;
/*     */       }
/*     */ 
/*  97 */       object = this.stack.getContext().get(key);
/*  98 */       if (object != null) {
/*  99 */         return object;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 105 */     if (this.chainedContexts != null) {
/* 106 */       for (int index = 0; index < this.chainedContexts.length; index++) {
/* 107 */         if (this.chainedContexts[index].containsKey(key)) {
/* 108 */           return this.chainedContexts[index].internalGet(key);
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 114 */     return null;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.views.velocity.StrutsVelocityContext
 * JD-Core Version:    0.6.0
 */