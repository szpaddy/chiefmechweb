/*     */ package org.apache.struts2.views.velocity;
/*     */ 
/*     */ import com.opensymphony.xwork2.ObjectFactory;
/*     */ import com.opensymphony.xwork2.inject.Container;
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import com.opensymphony.xwork2.util.logging.Logger;
/*     */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import java.util.StringTokenizer;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.commons.lang3.StringUtils;
/*     */ import org.apache.struts2.ServletActionContext;
/*     */ import org.apache.struts2.StrutsException;
/*     */ import org.apache.struts2.util.VelocityStrutsUtil;
/*     */ import org.apache.struts2.views.TagLibraryDirectiveProvider;
/*     */ import org.apache.struts2.views.util.ContextUtil;
/*     */ import org.apache.velocity.VelocityContext;
/*     */ import org.apache.velocity.app.Velocity;
/*     */ import org.apache.velocity.app.VelocityEngine;
/*     */ import org.apache.velocity.context.Context;
/*     */ import org.apache.velocity.tools.view.ToolboxManager;
/*     */ import org.apache.velocity.tools.view.context.ChainedContext;
/*     */ import org.apache.velocity.tools.view.servlet.ServletToolboxManager;
/*     */ 
/*     */ public class VelocityManager
/*     */ {
/*  68 */   private static final Logger LOG = LoggerFactory.getLogger(VelocityManager.class);
/*     */   public static final String STRUTS = "struts";
/*     */   private ObjectFactory objectFactory;
/*     */   public static final String KEY_VELOCITY_STRUTS_CONTEXT = ".KEY_velocity.struts2.context";
/*     */   public static final String PARENT = "parent";
/*     */   public static final String TAG = "tag";
/*     */   private VelocityEngine velocityEngine;
/*  89 */   protected ToolboxManager toolboxManager = null;
/*     */   private String toolBoxLocation;
/*     */   private String[] chainedContextNames;
/*     */   private Properties velocityProperties;
/*     */   private String customConfigFile;
/*     */   private List<TagLibraryDirectiveProvider> tagLibraries;
/*     */ 
/*     */   @Inject
/*     */   public void setObjectFactory(ObjectFactory fac)
/*     */   {
/* 106 */     this.objectFactory = fac;
/*     */   }
/*     */   @Inject
/*     */   public void setContainer(Container container) {
/* 111 */     List list = new ArrayList();
/* 112 */     Set prefixes = container.getInstanceNames(TagLibraryDirectiveProvider.class);
/* 113 */     for (String prefix : prefixes) {
/* 114 */       list.add(container.getInstance(TagLibraryDirectiveProvider.class, prefix));
/*     */     }
/* 116 */     this.tagLibraries = Collections.unmodifiableList(list);
/*     */   }
/*     */ 
/*     */   public VelocityEngine getVelocityEngine()
/*     */   {
/* 124 */     return this.velocityEngine;
/*     */   }
/*     */ 
/*     */   public Context createContext(ValueStack stack, HttpServletRequest req, HttpServletResponse res)
/*     */   {
/* 143 */     Context result = null;
/* 144 */     VelocityContext[] chainedContexts = prepareChainedContexts(req, res, stack.getContext());
/* 145 */     StrutsVelocityContext context = new StrutsVelocityContext(chainedContexts, stack);
/* 146 */     Map standardMap = ContextUtil.getStandardContext(stack, req, res);
/* 147 */     for (Iterator iterator = standardMap.entrySet().iterator(); iterator.hasNext(); ) {
/* 148 */       Map.Entry entry = (Map.Entry)iterator.next();
/* 149 */       context.put((String)entry.getKey(), entry.getValue());
/*     */     }
/* 151 */     context.put("struts", new VelocityStrutsUtil(this.velocityEngine, context, stack, req, res));
/*     */ 
/* 154 */     ServletContext ctx = null;
/*     */     try {
/* 156 */       ctx = ServletActionContext.getServletContext();
/*     */     }
/*     */     catch (NullPointerException npe) {
/* 159 */       if (LOG.isDebugEnabled()) {
/* 160 */         LOG.debug("internal toolbox context ignored", new String[0]);
/*     */       }
/*     */     }
/*     */ 
/* 164 */     if ((this.toolboxManager != null) && (ctx != null)) {
/* 165 */       ChainedContext chained = new ChainedContext(context, this.velocityEngine, req, res, ctx);
/* 166 */       chained.setToolbox(this.toolboxManager.getToolbox(chained));
/* 167 */       result = chained;
/*     */     } else {
/* 169 */       result = context;
/*     */     }
/*     */ 
/* 172 */     req.setAttribute(".KEY_velocity.struts2.context", result);
/* 173 */     return result;
/*     */   }
/*     */ 
/*     */   protected VelocityContext[] prepareChainedContexts(HttpServletRequest servletRequest, HttpServletResponse servletResponse, Map extraContext)
/*     */   {
/* 187 */     if (this.chainedContextNames == null) {
/* 188 */       return null;
/*     */     }
/* 190 */     List contextList = new ArrayList();
/* 191 */     for (int i = 0; i < this.chainedContextNames.length; i++) {
/* 192 */       String className = this.chainedContextNames[i];
/*     */       try {
/* 194 */         VelocityContext velocityContext = (VelocityContext)this.objectFactory.buildBean(className, null);
/* 195 */         contextList.add(velocityContext);
/*     */       } catch (Exception e) {
/* 197 */         if (LOG.isWarnEnabled()) {
/* 198 */           LOG.warn("Warning.  " + e.getClass().getName() + " caught while attempting to instantiate a chained VelocityContext, " + className + " -- skipping", new String[0]);
/*     */         }
/*     */       }
/*     */     }
/* 202 */     if (contextList.size() > 0) {
/* 203 */       VelocityContext[] extraContexts = new VelocityContext[contextList.size()];
/* 204 */       contextList.toArray(extraContexts);
/* 205 */       return extraContexts;
/*     */     }
/* 207 */     return null;
/*     */   }
/*     */ 
/*     */   public synchronized void init(ServletContext context)
/*     */   {
/* 218 */     if (this.velocityEngine == null) {
/* 219 */       this.velocityEngine = newVelocityEngine(context);
/*     */     }
/* 221 */     initToolbox(context);
/*     */   }
/*     */ 
/*     */   public Properties loadConfiguration(ServletContext context)
/*     */   {
/* 236 */     if (context == null) {
/* 237 */       String gripe = "Error attempting to create a loadConfiguration from a null ServletContext!";
/* 238 */       LOG.error(gripe, new String[0]);
/* 239 */       throw new IllegalArgumentException(gripe);
/*     */     }
/*     */ 
/* 242 */     Properties properties = new Properties();
/*     */ 
/* 245 */     applyDefaultConfiguration(context, properties);
/*     */ 
/* 248 */     String defaultUserDirective = properties.getProperty("userdirective");
/*     */     String configfile;
/* 260 */     if (this.customConfigFile != null)
/* 261 */       configfile = this.customConfigFile;
/*     */     else {
/* 263 */       configfile = "velocity.properties";
/*     */     }
/*     */ 
/* 266 */     String configfile = configfile.trim();
/*     */ 
/* 268 */     InputStream in = null;
/* 269 */     String resourceLocation = null;
/*     */     try
/*     */     {
/* 272 */       if (context.getRealPath(configfile) != null)
/*     */       {
/* 274 */         String filename = context.getRealPath(configfile);
/*     */ 
/* 276 */         if (filename != null) {
/* 277 */           File file = new File(filename);
/*     */ 
/* 279 */           if (file.isFile()) {
/* 280 */             resourceLocation = file.getCanonicalPath() + " from file system";
/* 281 */             in = new FileInputStream(file);
/*     */           }
/*     */ 
/* 285 */           if (in == null) {
/* 286 */             file = new File(context.getRealPath("/WEB-INF/" + configfile));
/*     */ 
/* 288 */             if (file.isFile()) {
/* 289 */               resourceLocation = file.getCanonicalPath() + " from file system";
/* 290 */               in = new FileInputStream(file);
/*     */             }
/*     */           }
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 297 */       if (in == null) {
/* 298 */         in = VelocityManager.class.getClassLoader().getResourceAsStream(configfile);
/* 299 */         if (in != null) {
/* 300 */           resourceLocation = configfile + " from classloader";
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 305 */       if (in != null) {
/* 306 */         if (LOG.isInfoEnabled()) {
/* 307 */           LOG.info("Initializing velocity using " + resourceLocation, new String[0]);
/*     */         }
/* 309 */         properties.load(in);
/*     */       }
/*     */     } catch (IOException e) {
/* 312 */       if (LOG.isWarnEnabled())
/* 313 */         LOG.warn("Unable to load velocity configuration " + resourceLocation, e, new String[0]);
/*     */     }
/*     */     finally {
/* 316 */       if (in != null) {
/*     */         try {
/* 318 */           in.close();
/*     */         }
/*     */         catch (IOException e)
/*     */         {
/*     */         }
/*     */       }
/*     */     }
/* 325 */     if (this.velocityProperties != null) {
/* 326 */       Iterator keys = this.velocityProperties.keySet().iterator();
/* 327 */       while (keys.hasNext()) {
/* 328 */         String key = (String)keys.next();
/* 329 */         properties.setProperty(key, this.velocityProperties.getProperty(key));
/*     */       }
/*     */     }
/*     */ 
/* 333 */     String userdirective = properties.getProperty("userdirective");
/*     */ 
/* 335 */     if ((userdirective == null) || (userdirective.trim().equals("")))
/* 336 */       userdirective = defaultUserDirective;
/*     */     else {
/* 338 */       userdirective = userdirective.trim() + "," + defaultUserDirective;
/*     */     }
/*     */ 
/* 341 */     properties.setProperty("userdirective", userdirective);
/*     */ 
/* 345 */     if (LOG.isDebugEnabled()) {
/* 346 */       LOG.debug("Initializing Velocity with the following properties ...", new String[0]);
/*     */ 
/* 348 */       Iterator iter = properties.keySet().iterator();
/* 349 */       while (iter.hasNext()) {
/* 350 */         String key = (String)iter.next();
/* 351 */         String value = properties.getProperty(key);
/*     */ 
/* 353 */         if (LOG.isDebugEnabled()) {
/* 354 */           LOG.debug("    '" + key + "' = '" + value + "'", new String[0]);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 359 */     return properties;
/*     */   }
/*     */   @Inject("struts.velocity.configfile")
/*     */   public void setCustomConfigFile(String val) {
/* 364 */     this.customConfigFile = val;
/*     */   }
/*     */   @Inject("struts.velocity.toolboxlocation")
/*     */   public void setToolBoxLocation(String toolboxLocation) {
/* 369 */     this.toolBoxLocation = toolboxLocation;
/*     */   }
/*     */ 
/*     */   public ToolboxManager getToolboxManager() {
/* 373 */     return this.toolboxManager;
/*     */   }
/*     */ 
/*     */   @Inject("struts.velocity.contexts")
/*     */   public void setChainedContexts(String contexts)
/*     */   {
/* 385 */     StringTokenizer st = new StringTokenizer(contexts, ",");
/* 386 */     List contextList = new ArrayList();
/*     */ 
/* 388 */     while (st.hasMoreTokens()) {
/* 389 */       String classname = st.nextToken();
/* 390 */       contextList.add(classname);
/*     */     }
/* 392 */     if (contextList.size() > 0) {
/* 393 */       String[] chainedContexts = new String[contextList.size()];
/* 394 */       contextList.toArray(chainedContexts);
/* 395 */       this.chainedContextNames = chainedContexts;
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void initToolbox(ServletContext context)
/*     */   {
/* 405 */     if (StringUtils.isNotBlank(this.toolBoxLocation))
/* 406 */       this.toolboxManager = ServletToolboxManager.getInstance(context, this.toolBoxLocation);
/*     */     else
/* 408 */       Velocity.info("VelocityViewServlet: No toolbox entry in configuration.");
/*     */   }
/*     */ 
/*     */   protected VelocityEngine newVelocityEngine(ServletContext context)
/*     */   {
/* 441 */     if (context == null) {
/* 442 */       String gripe = "Error attempting to create a new VelocityEngine from a null ServletContext!";
/* 443 */       LOG.error(gripe, new String[0]);
/* 444 */       throw new IllegalArgumentException(gripe);
/*     */     }
/*     */ 
/* 447 */     Properties p = loadConfiguration(context);
/*     */ 
/* 449 */     VelocityEngine velocityEngine = new VelocityEngine();
/*     */ 
/* 453 */     velocityEngine.setApplicationAttribute(ServletContext.class.getName(), context);
/*     */     try
/*     */     {
/* 457 */       velocityEngine.init(p);
/*     */     } catch (Exception e) {
/* 459 */       throw new StrutsException("Unable to instantiate VelocityEngine!", e);
/*     */     }
/*     */ 
/* 462 */     return velocityEngine;
/*     */   }
/*     */ 
/*     */   private void applyDefaultConfiguration(ServletContext context, Properties p)
/*     */   {
/* 483 */     if (p.getProperty("resource.loader") == null) {
/* 484 */       p.setProperty("resource.loader", "strutsfile, strutsclass");
/*     */     }
/*     */ 
/* 493 */     if (context.getRealPath("") != null) {
/* 494 */       p.setProperty("strutsfile.resource.loader.description", "Velocity File Resource Loader");
/* 495 */       p.setProperty("strutsfile.resource.loader.class", "org.apache.velocity.runtime.resource.loader.FileResourceLoader");
/* 496 */       p.setProperty("strutsfile.resource.loader.path", context.getRealPath(""));
/* 497 */       p.setProperty("strutsfile.resource.loader.modificationCheckInterval", "2");
/* 498 */       p.setProperty("strutsfile.resource.loader.cache", "true");
/*     */     }
/*     */     else {
/* 501 */       String prop = p.getProperty("resource.loader");
/* 502 */       if (prop.indexOf("strutsfile,") != -1)
/* 503 */         prop = replace(prop, "strutsfile,", "");
/* 504 */       else if (prop.indexOf(", strutsfile") != -1)
/* 505 */         prop = replace(prop, ", strutsfile", "");
/* 506 */       else if (prop.indexOf("strutsfile") != -1) {
/* 507 */         prop = replace(prop, "strutsfile", "");
/*     */       }
/*     */ 
/* 510 */       p.setProperty("resource.loader", prop);
/*     */     }
/*     */ 
/* 519 */     p.setProperty("strutsclass.resource.loader.description", "Velocity Classpath Resource Loader");
/* 520 */     p.setProperty("strutsclass.resource.loader.class", "org.apache.struts2.views.velocity.StrutsResourceLoader");
/* 521 */     p.setProperty("strutsclass.resource.loader.modificationCheckInterval", "2");
/* 522 */     p.setProperty("strutsclass.resource.loader.cache", "true");
/*     */ 
/* 525 */     StringBuilder sb = new StringBuilder();
/*     */ 
/* 527 */     for (TagLibraryDirectiveProvider tagLibrary : this.tagLibraries) {
/* 528 */       List directives = tagLibrary.getDirectiveClasses();
/* 529 */       for (Class directive : directives) {
/* 530 */         addDirective(sb, directive);
/*     */       }
/*     */     }
/*     */ 
/* 534 */     String directives = sb.toString();
/*     */ 
/* 536 */     String userdirective = p.getProperty("userdirective");
/* 537 */     if ((userdirective == null) || (userdirective.trim().equals("")))
/* 538 */       userdirective = directives;
/*     */     else {
/* 540 */       userdirective = userdirective.trim() + "," + directives;
/*     */     }
/*     */ 
/* 543 */     p.setProperty("userdirective", userdirective);
/*     */   }
/*     */ 
/*     */   private void addDirective(StringBuilder sb, Class clazz) {
/* 547 */     sb.append(clazz.getName()).append(",");
/*     */   }
/*     */ 
/*     */   private static final String replace(String string, String oldString, String newString) {
/* 551 */     if (string == null) {
/* 552 */       return null;
/*     */     }
/*     */ 
/* 555 */     if (newString == null) {
/* 556 */       return string;
/*     */     }
/* 558 */     int i = 0;
/*     */ 
/* 560 */     if ((i = string.indexOf(oldString, i)) >= 0)
/*     */     {
/* 562 */       char[] string2 = string.toCharArray();
/* 563 */       char[] newString2 = newString.toCharArray();
/* 564 */       int oLength = oldString.length();
/* 565 */       StringBuilder buf = new StringBuilder(string2.length);
/* 566 */       buf.append(string2, 0, i).append(newString2);
/* 567 */       i += oLength;
/* 568 */       int j = i;
/*     */ 
/* 570 */       while ((i = string.indexOf(oldString, i)) > 0) {
/* 571 */         buf.append(string2, j, i - j).append(newString2);
/* 572 */         i += oLength;
/* 573 */         j = i;
/*     */       }
/* 575 */       buf.append(string2, j, string2.length - j);
/* 576 */       return buf.toString();
/*     */     }
/* 578 */     return string;
/*     */   }
/*     */ 
/*     */   public Properties getVelocityProperties()
/*     */   {
/* 585 */     return this.velocityProperties;
/*     */   }
/*     */ 
/*     */   public void setVelocityProperties(Properties velocityProperties)
/*     */   {
/* 592 */     this.velocityProperties = velocityProperties;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.views.velocity.VelocityManager
 * JD-Core Version:    0.6.0
 */