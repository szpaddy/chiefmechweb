/*     */ package org.apache.struts2.views.velocity.components;
/*     */ 
/*     */ import com.opensymphony.xwork2.inject.Container;
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.struts2.components.Component;
/*     */ import org.apache.velocity.context.InternalContextAdapter;
/*     */ import org.apache.velocity.exception.MethodInvocationException;
/*     */ import org.apache.velocity.exception.ParseErrorException;
/*     */ import org.apache.velocity.exception.ResourceNotFoundException;
/*     */ import org.apache.velocity.runtime.directive.Directive;
/*     */ import org.apache.velocity.runtime.parser.node.Node;
/*     */ 
/*     */ public abstract class AbstractDirective extends Directive
/*     */ {
/*     */   public String getName()
/*     */   {
/*  47 */     return "s" + getBeanName();
/*     */   }
/*     */ 
/*     */   public abstract String getBeanName();
/*     */ 
/*     */   public int getType()
/*     */   {
/*  56 */     return 2;
/*     */   }
/*     */ 
/*     */   protected abstract Component getBean(ValueStack paramValueStack, HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse);
/*     */ 
/*     */   public boolean render(InternalContextAdapter ctx, Writer writer, Node node) throws IOException, ResourceNotFoundException, ParseErrorException, MethodInvocationException {
/*  63 */     ValueStack stack = (ValueStack)ctx.get("stack");
/*  64 */     HttpServletRequest req = (HttpServletRequest)stack.getContext().get("com.opensymphony.xwork2.dispatcher.HttpServletRequest");
/*  65 */     HttpServletResponse res = (HttpServletResponse)stack.getContext().get("com.opensymphony.xwork2.dispatcher.HttpServletResponse");
/*  66 */     Component bean = getBean(stack, req, res);
/*  67 */     Container container = (Container)stack.getContext().get("com.opensymphony.xwork2.ActionContext.container");
/*  68 */     container.inject(bean);
/*     */ 
/*  70 */     Map params = createPropertyMap(ctx, node);
/*  71 */     bean.copyParams(params);
/*     */ 
/*  73 */     bean.start(writer);
/*     */ 
/*  75 */     if (getType() == 1) {
/*  76 */       Node body = node.jjtGetChild(node.jjtGetNumChildren() - 1);
/*  77 */       body.render(ctx, writer);
/*     */     }
/*     */ 
/*  80 */     bean.end(writer, "");
/*  81 */     return true;
/*     */   }
/*     */ 
/*     */   protected Map createPropertyMap(InternalContextAdapter contextAdapter, Node node)
/*     */     throws ParseErrorException, MethodInvocationException
/*     */   {
/*  99 */     int children = node.jjtGetNumChildren();
/* 100 */     if (getType() == 1) {
/* 101 */       children--;
/*     */     }
/*     */ 
/* 112 */     Node firstChild = null;
/* 113 */     Object firstValue = null;
/*     */     Map propertyMap;
/*     */     Map propertyMap;
/* 114 */     if ((children == 1) && (null != (firstChild = node.jjtGetChild(0))) && (null != (firstValue = firstChild.value(contextAdapter))) && ((firstValue instanceof Map)))
/*     */     {
/* 118 */       propertyMap = (Map)firstValue;
/*     */     } else {
/* 120 */       propertyMap = new HashMap();
/*     */ 
/* 122 */       int index = 0; for (int length = children; index < length; index++) {
/* 123 */         putProperty(propertyMap, contextAdapter, node.jjtGetChild(index));
/*     */       }
/*     */     }
/*     */ 
/* 127 */     return propertyMap;
/*     */   }
/*     */ 
/*     */   protected void putProperty(Map propertyMap, InternalContextAdapter contextAdapter, Node node)
/*     */     throws ParseErrorException, MethodInvocationException
/*     */   {
/* 139 */     String param = node.value(contextAdapter).toString();
/*     */ 
/* 141 */     int idx = param.indexOf("=");
/*     */ 
/* 143 */     if (idx != -1) {
/* 144 */       String property = param.substring(0, idx);
/*     */ 
/* 146 */       String value = param.substring(idx + 1);
/* 147 */       propertyMap.put(property, value);
/*     */     } else {
/* 149 */       throw new ParseErrorException("#" + getName() + " arguments must include an assignment operator!  For example #tag( Component \"template=mytemplate\" ).  #tag( TextField \"mytemplate\" ) is illegal!");
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.views.velocity.components.AbstractDirective
 * JD-Core Version:    0.6.0
 */