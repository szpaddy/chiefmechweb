/*    */ package org.apache.struts2.views.velocity.components;
/*    */ 
/*    */ import com.opensymphony.xwork2.util.ValueStack;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.apache.struts2.components.Component;
/*    */ import org.apache.struts2.components.GenericUIBean;
/*    */ 
/*    */ public class ComponentDirective extends AbstractDirective
/*    */ {
/*    */   protected Component getBean(ValueStack stack, HttpServletRequest req, HttpServletResponse res)
/*    */   {
/* 37 */     return new GenericUIBean(stack, req, res);
/*    */   }
/*    */ 
/*    */   public String getBeanName() {
/* 41 */     return "component";
/*    */   }
/*    */ 
/*    */   public int getType() {
/* 45 */     return 1;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.views.velocity.components.ComponentDirective
 * JD-Core Version:    0.6.0
 */