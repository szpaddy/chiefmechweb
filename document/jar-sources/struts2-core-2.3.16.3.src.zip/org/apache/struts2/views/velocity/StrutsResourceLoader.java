/*    */ package org.apache.struts2.views.velocity;
/*    */ 
/*    */ import com.opensymphony.xwork2.util.ClassLoaderUtil;
/*    */ import java.io.InputStream;
/*    */ import org.apache.velocity.exception.ResourceNotFoundException;
/*    */ import org.apache.velocity.runtime.resource.loader.ClasspathResourceLoader;
/*    */ 
/*    */ public class StrutsResourceLoader extends ClasspathResourceLoader
/*    */ {
/*    */   public synchronized InputStream getResourceStream(String name)
/*    */     throws ResourceNotFoundException
/*    */   {
/* 38 */     if ((name == null) || (name.length() == 0)) {
/* 39 */       throw new ResourceNotFoundException("No template name provided");
/*    */     }
/*    */ 
/* 42 */     if (name.startsWith("/")) {
/* 43 */       name = name.substring(1);
/*    */     }
/*    */     try
/*    */     {
/* 47 */       return ClassLoaderUtil.getResourceAsStream(name, StrutsResourceLoader.class); } catch (Exception e) {
/*    */     }
/* 49 */     throw new ResourceNotFoundException(e);
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.views.velocity.StrutsResourceLoader
 * JD-Core Version:    0.6.0
 */