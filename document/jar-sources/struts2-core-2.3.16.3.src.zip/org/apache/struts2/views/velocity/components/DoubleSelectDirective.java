/*    */ package org.apache.struts2.views.velocity.components;
/*    */ 
/*    */ import com.opensymphony.xwork2.util.ValueStack;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.apache.struts2.components.Component;
/*    */ import org.apache.struts2.components.DoubleSelect;
/*    */ 
/*    */ public class DoubleSelectDirective extends AbstractDirective
/*    */ {
/*    */   protected Component getBean(ValueStack stack, HttpServletRequest req, HttpServletResponse res)
/*    */   {
/* 37 */     return new DoubleSelect(stack, req, res);
/*    */   }
/*    */ 
/*    */   public String getBeanName() {
/* 41 */     return "doubleselect";
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.views.velocity.components.DoubleSelectDirective
 * JD-Core Version:    0.6.0
 */