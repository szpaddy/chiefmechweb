/*    */ package org.apache.struts2.views.velocity.components;
/*    */ 
/*    */ import com.opensymphony.xwork2.util.ValueStack;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.apache.struts2.components.Component;
/*    */ import org.apache.struts2.components.Property;
/*    */ 
/*    */ public class PropertyDirective extends AbstractDirective
/*    */ {
/*    */   public String getBeanName()
/*    */   {
/* 36 */     return "property";
/*    */   }
/*    */ 
/*    */   protected Component getBean(ValueStack stack, HttpServletRequest req, HttpServletResponse res) {
/* 40 */     return new Property(stack);
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.views.velocity.components.PropertyDirective
 * JD-Core Version:    0.6.0
 */