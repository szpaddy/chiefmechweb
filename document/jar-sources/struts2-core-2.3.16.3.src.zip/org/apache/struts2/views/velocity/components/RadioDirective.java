/*    */ package org.apache.struts2.views.velocity.components;
/*    */ 
/*    */ import com.opensymphony.xwork2.util.ValueStack;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.apache.struts2.components.Component;
/*    */ import org.apache.struts2.components.Radio;
/*    */ 
/*    */ public class RadioDirective extends AbstractDirective
/*    */ {
/*    */   public String getBeanName()
/*    */   {
/* 37 */     return "radio";
/*    */   }
/*    */ 
/*    */   protected Component getBean(ValueStack stack, HttpServletRequest req, HttpServletResponse res) {
/* 41 */     return new Radio(stack, req, res);
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.views.velocity.components.RadioDirective
 * JD-Core Version:    0.6.0
 */