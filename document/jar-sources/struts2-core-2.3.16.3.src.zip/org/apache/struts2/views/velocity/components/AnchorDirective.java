/*    */ package org.apache.struts2.views.velocity.components;
/*    */ 
/*    */ import com.opensymphony.xwork2.util.ValueStack;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.apache.struts2.components.Anchor;
/*    */ import org.apache.struts2.components.Component;
/*    */ 
/*    */ public class AnchorDirective extends AbstractDirective
/*    */ {
/*    */   public String getBeanName()
/*    */   {
/* 37 */     return "a";
/*    */   }
/*    */ 
/*    */   protected Component getBean(ValueStack stack, HttpServletRequest req, HttpServletResponse res) {
/* 41 */     return new Anchor(stack, req, res);
/*    */   }
/*    */ 
/*    */   public int getType() {
/* 45 */     return 1;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.views.velocity.components.AnchorDirective
 * JD-Core Version:    0.6.0
 */