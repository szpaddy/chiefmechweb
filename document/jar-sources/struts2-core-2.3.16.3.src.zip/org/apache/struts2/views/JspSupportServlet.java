/*    */ package org.apache.struts2.views;
/*    */ 
/*    */ import javax.servlet.ServletConfig;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.http.HttpServlet;
/*    */ 
/*    */ public class JspSupportServlet extends HttpServlet
/*    */ {
/*    */   private static final long serialVersionUID = 8302309812391541933L;
/*    */   public static JspSupportServlet jspSupportServlet;
/*    */ 
/*    */   public void init(ServletConfig servletConfig)
/*    */     throws ServletException
/*    */   {
/* 37 */     super.init(servletConfig);
/*    */ 
/* 39 */     jspSupportServlet = this;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.views.JspSupportServlet
 * JD-Core Version:    0.6.0
 */