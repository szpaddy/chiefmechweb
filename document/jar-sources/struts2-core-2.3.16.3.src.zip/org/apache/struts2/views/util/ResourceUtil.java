/*    */ package org.apache.struts2.views.util;
/*    */ 
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import org.apache.struts2.RequestUtils;
/*    */ 
/*    */ public class ResourceUtil
/*    */ {
/*    */   public static String getResourceBase(HttpServletRequest req)
/*    */   {
/* 29 */     String path = RequestUtils.getServletPath(req);
/* 30 */     if ((path == null) || ("".equals(path))) {
/* 31 */       return "";
/*    */     }
/*    */ 
/* 34 */     return path.substring(0, path.lastIndexOf('/'));
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.views.util.ResourceUtil
 * JD-Core Version:    0.6.0
 */