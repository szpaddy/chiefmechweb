package org.apache.struts2.views.util;

import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public abstract interface UrlHelper
{
  public static final int DEFAULT_HTTP_PORT = 80;
  public static final int DEFAULT_HTTPS_PORT = 443;
  public static final String AMP = "&amp;";

  public abstract String buildUrl(String paramString, HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse, Map<String, Object> paramMap);

  public abstract String buildUrl(String paramString1, HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse, Map<String, Object> paramMap, String paramString2, boolean paramBoolean1, boolean paramBoolean2);

  public abstract String buildUrl(String paramString1, HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse, Map<String, Object> paramMap, String paramString2, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3);

  public abstract String buildUrl(String paramString1, HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse, Map<String, Object> paramMap, String paramString2, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4);

  public abstract void buildParametersString(Map<String, Object> paramMap, StringBuilder paramStringBuilder, String paramString);

  public abstract Map<String, Object> parseQueryString(String paramString, boolean paramBoolean);
}

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.views.util.UrlHelper
 * JD-Core Version:    0.6.0
 */