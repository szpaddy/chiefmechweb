/*     */ package org.apache.struts2.views.util;
/*     */ 
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import com.opensymphony.xwork2.util.logging.Logger;
/*     */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.net.URLDecoder;
/*     */ import java.net.URLEncoder;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.commons.lang3.StringEscapeUtils;
/*     */ import org.apache.commons.lang3.StringUtils;
/*     */ 
/*     */ public class DefaultUrlHelper
/*     */   implements UrlHelper
/*     */ {
/*  48 */   private static final Logger LOG = LoggerFactory.getLogger(DefaultUrlHelper.class);
/*     */   public static final String HTTP_PROTOCOL = "http";
/*     */   public static final String HTTPS_PROTOCOL = "https";
/*  53 */   private String encoding = "UTF-8";
/*  54 */   private int httpPort = 80;
/*  55 */   private int httpsPort = 443;
/*     */ 
/*  59 */   @Inject("struts.i18n.encoding")
/*     */   public void setEncoding(String encoding) { if (StringUtils.isNotEmpty(encoding))
/*  60 */       this.encoding = encoding; }
/*     */ 
/*     */   @Inject("struts.url.http.port")
/*     */   public void setHttpPort(String httpPort)
/*     */   {
/*  66 */     this.httpPort = Integer.parseInt(httpPort);
/*     */   }
/*     */   @Inject("struts.url.https.port")
/*     */   public void setHttpsPort(String httpsPort) {
/*  71 */     this.httpsPort = Integer.parseInt(httpsPort);
/*     */   }
/*     */ 
/*     */   public String buildUrl(String action, HttpServletRequest request, HttpServletResponse response, Map<String, Object> params) {
/*  75 */     return buildUrl(action, request, response, params, null, true, true);
/*     */   }
/*     */ 
/*     */   public String buildUrl(String action, HttpServletRequest request, HttpServletResponse response, Map<String, Object> params, String scheme, boolean includeContext, boolean encodeResult)
/*     */   {
/*  80 */     return buildUrl(action, request, response, params, scheme, includeContext, encodeResult, false);
/*     */   }
/*     */ 
/*     */   public String buildUrl(String action, HttpServletRequest request, HttpServletResponse response, Map<String, Object> params, String scheme, boolean includeContext, boolean encodeResult, boolean forceAddSchemeHostAndPort)
/*     */   {
/*  85 */     return buildUrl(action, request, response, params, scheme, includeContext, encodeResult, forceAddSchemeHostAndPort, true);
/*     */   }
/*     */ 
/*     */   public String buildUrl(String action, HttpServletRequest request, HttpServletResponse response, Map<String, Object> params, String scheme, boolean includeContext, boolean encodeResult, boolean forceAddSchemeHostAndPort, boolean escapeAmp)
/*     */   {
/*  91 */     StringBuilder link = new StringBuilder();
/*  92 */     boolean changedScheme = false;
/*     */ 
/*  96 */     if (forceAddSchemeHostAndPort) {
/*  97 */       String reqScheme = request.getScheme();
/*  98 */       changedScheme = true;
/*  99 */       link.append(scheme != null ? scheme : reqScheme);
/* 100 */       link.append("://");
/* 101 */       link.append(request.getServerName());
/*     */ 
/* 103 */       if (scheme != null)
/*     */       {
/* 105 */         if (!scheme.equals(reqScheme)) {
/* 106 */           if ((("http".equals(scheme)) && (this.httpPort != 80)) || (("https".equals(scheme)) && (this.httpsPort != 443))) {
/* 107 */             link.append(":");
/* 108 */             link.append("http".equals(scheme) ? this.httpPort : this.httpsPort);
/*     */           }
/*     */         }
/*     */         else {
/* 112 */           int reqPort = request.getServerPort();
/*     */ 
/* 114 */           if (((scheme.equals("http")) && (reqPort != 80)) || ((scheme.equals("https")) && (reqPort != 443))) {
/* 115 */             link.append(":");
/* 116 */             link.append(reqPort);
/*     */           }
/*     */         }
/*     */       }
/* 120 */     } else if ((scheme != null) && (!scheme.equals(request.getScheme()))) {
/* 121 */       changedScheme = true;
/* 122 */       link.append(scheme);
/* 123 */       link.append("://");
/* 124 */       link.append(request.getServerName());
/*     */ 
/* 126 */       if (((scheme.equals("http")) && (this.httpPort != 80)) || (("https".equals(scheme)) && (this.httpsPort != 443)))
/*     */       {
/* 128 */         link.append(":");
/* 129 */         link.append("http".equals(scheme) ? this.httpPort : this.httpsPort);
/*     */       }
/*     */     }
/*     */ 
/* 133 */     if (action != null)
/*     */     {
/* 136 */       if ((action.startsWith("/")) && (includeContext)) {
/* 137 */         String contextPath = request.getContextPath();
/* 138 */         if (!contextPath.equals("/"))
/* 139 */           link.append(contextPath);
/*     */       }
/* 141 */       else if (changedScheme)
/*     */       {
/* 145 */         String uri = (String)request.getAttribute("javax.servlet.forward.request_uri");
/*     */ 
/* 148 */         if (uri == null) {
/* 149 */           uri = request.getRequestURI();
/*     */         }
/*     */ 
/* 152 */         link.append(uri.substring(0, uri.lastIndexOf('/') + 1));
/*     */       }
/*     */ 
/* 156 */       link.append(action);
/*     */     }
/*     */     else {
/* 159 */       String requestURI = (String)request.getAttribute("struts.request_uri");
/*     */ 
/* 163 */       if (requestURI == null) {
/* 164 */         requestURI = (String)request.getAttribute("javax.servlet.forward.request_uri");
/*     */       }
/*     */ 
/* 168 */       if (requestURI == null) {
/* 169 */         requestURI = request.getRequestURI();
/*     */       }
/*     */ 
/* 172 */       link.append(requestURI);
/*     */     }
/*     */ 
/* 176 */     if (escapeAmp)
/* 177 */       buildParametersString(params, link, "&amp;");
/*     */     else {
/* 179 */       buildParametersString(params, link, "&");
/*     */     }
/*     */ 
/* 182 */     String result = link.toString();
/*     */ 
/* 184 */     if (StringUtils.containsIgnoreCase(result, "<script"))
/* 185 */       result = StringEscapeUtils.escapeEcmaScript(result);
/*     */     try
/*     */     {
/* 188 */       result = encodeResult ? response.encodeURL(result) : result;
/*     */     } catch (Exception ex) {
/* 190 */       if (LOG.isDebugEnabled()) {
/* 191 */         LOG.debug("Could not encode the URL for some reason, use it unchanged", ex, new String[0]);
/*     */       }
/* 193 */       result = link.toString();
/*     */     }
/*     */ 
/* 196 */     return result;
/*     */   }
/*     */ 
/*     */   public void buildParametersString(Map<String, Object> params, StringBuilder link, String paramSeparator) {
/* 200 */     if ((params != null) && (params.size() > 0)) {
/* 201 */       if (!link.toString().contains("?"))
/* 202 */         link.append("?");
/*     */       else {
/* 204 */         link.append(paramSeparator);
/*     */       }
/*     */ 
/* 208 */       Iterator iter = params.entrySet().iterator();
/* 209 */       while (iter.hasNext()) {
/* 210 */         Map.Entry entry = (Map.Entry)iter.next();
/* 211 */         String name = (String)entry.getKey();
/* 212 */         Object value = entry.getValue();
/*     */         Iterator iterator;
/* 214 */         if ((value instanceof Iterable)) {
/* 215 */           for (iterator = ((Iterable)value).iterator(); iterator.hasNext(); ) {
/* 216 */             Object paramValue = iterator.next();
/* 217 */             link.append(buildParameterSubstring(name, paramValue != null ? paramValue.toString() : ""));
/*     */ 
/* 219 */             if (iterator.hasNext())
/* 220 */               link.append(paramSeparator);
/*     */           }
/*     */         }
/* 223 */         else if ((value instanceof Object[])) {
/* 224 */           Object[] array = (Object[])(Object[])value;
/* 225 */           for (int i = 0; i < array.length; i++) {
/* 226 */             Object paramValue = array[i];
/* 227 */             link.append(buildParameterSubstring(name, paramValue != null ? paramValue.toString() : ""));
/*     */ 
/* 229 */             if (i < array.length - 1)
/* 230 */               link.append(paramSeparator);
/*     */           }
/*     */         }
/*     */         else {
/* 234 */           link.append(buildParameterSubstring(name, value != null ? value.toString() : ""));
/*     */         }
/*     */ 
/* 237 */         if (iter.hasNext())
/* 238 */           link.append(paramSeparator);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private String buildParameterSubstring(String name, String value)
/*     */   {
/* 245 */     StringBuilder builder = new StringBuilder();
/* 246 */     builder.append(encode(name));
/* 247 */     builder.append('=');
/* 248 */     builder.append(encode(value));
/* 249 */     return builder.toString();
/*     */   }
/*     */ 
/*     */   public String encode(String input)
/*     */   {
/*     */     try
/*     */     {
/* 260 */       return URLEncoder.encode(input, this.encoding);
/*     */     } catch (UnsupportedEncodingException e) {
/* 262 */       if (LOG.isWarnEnabled())
/* 263 */         LOG.warn("Could not encode URL parameter '#0', returning value un-encoded", new String[] { input });
/*     */     }
/* 265 */     return input;
/*     */   }
/*     */ 
/*     */   public String decode(String input)
/*     */   {
/*     */     try
/*     */     {
/* 277 */       return URLDecoder.decode(input, this.encoding);
/*     */     } catch (UnsupportedEncodingException e) {
/* 279 */       if (LOG.isWarnEnabled())
/* 280 */         LOG.warn("Could not decode URL parameter '#0', returning value un-decoded", new String[] { input });
/*     */     }
/* 282 */     return input;
/*     */   }
/*     */ 
/*     */   public Map<String, Object> parseQueryString(String queryString, boolean forceValueArray)
/*     */   {
/* 287 */     Map queryParams = new LinkedHashMap();
/* 288 */     if (queryString != null) {
/* 289 */       String[] params = queryString.split("&");
/* 290 */       for (String param : params) {
/* 291 */         if (param.trim().length() > 0) {
/* 292 */           String[] tmpParams = param.split("=");
/* 293 */           String paramName = null;
/* 294 */           String paramValue = "";
/* 295 */           if (tmpParams.length > 0) {
/* 296 */             paramName = tmpParams[0];
/*     */           }
/* 298 */           if (tmpParams.length > 1) {
/* 299 */             paramValue = tmpParams[1];
/*     */           }
/* 301 */           if (paramName != null) {
/* 302 */             paramName = decode(paramName);
/* 303 */             String translatedParamValue = decode(paramValue);
/*     */ 
/* 305 */             if ((queryParams.containsKey(paramName)) || (forceValueArray))
/*     */             {
/* 307 */               Object currentParam = queryParams.get(paramName);
/* 308 */               if ((currentParam instanceof String)) {
/* 309 */                 queryParams.put(paramName, new String[] { (String)currentParam, translatedParamValue });
/*     */               } else {
/* 311 */                 String[] currentParamValues = (String[])(String[])currentParam;
/* 312 */                 if (currentParamValues != null) {
/* 313 */                   List paramList = new ArrayList(Arrays.asList(currentParamValues));
/* 314 */                   paramList.add(translatedParamValue);
/* 315 */                   queryParams.put(paramName, paramList.toArray(new String[paramList.size()]));
/*     */                 } else {
/* 317 */                   queryParams.put(paramName, new String[] { translatedParamValue });
/*     */                 }
/*     */               }
/*     */             } else {
/* 321 */               queryParams.put(paramName, translatedParamValue);
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 327 */     return queryParams;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.views.util.DefaultUrlHelper
 * JD-Core Version:    0.6.0
 */