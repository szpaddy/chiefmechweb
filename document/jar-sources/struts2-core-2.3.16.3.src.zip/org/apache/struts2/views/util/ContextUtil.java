/*    */ package org.apache.struts2.views.util;
/*    */ 
/*    */ import com.opensymphony.xwork2.ActionInvocation;
/*    */ import com.opensymphony.xwork2.inject.Container;
/*    */ import com.opensymphony.xwork2.util.ValueStack;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.apache.struts2.util.StrutsUtil;
/*    */ import org.apache.struts2.views.jsp.ui.OgnlTool;
/*    */ 
/*    */ public class ContextUtil
/*    */ {
/*    */   public static final String REQUEST = "request";
/*    */   public static final String REQUEST2 = "request";
/*    */   public static final String RESPONSE = "response";
/*    */   public static final String RESPONSE2 = "response";
/*    */   public static final String SESSION = "session";
/*    */   public static final String BASE = "base";
/*    */   public static final String STACK = "stack";
/*    */   public static final String OGNL = "ognl";
/*    */   public static final String STRUTS = "struts";
/*    */   public static final String ACTION = "action";
/*    */ 
/*    */   public static Map getStandardContext(ValueStack stack, HttpServletRequest req, HttpServletResponse res)
/*    */   {
/* 58 */     HashMap map = new HashMap();
/* 59 */     map.put("request", req);
/* 60 */     map.put("request", req);
/* 61 */     map.put("response", res);
/* 62 */     map.put("response", res);
/* 63 */     map.put("session", req.getSession(false));
/* 64 */     map.put("base", req.getContextPath());
/* 65 */     map.put("stack", stack);
/* 66 */     map.put("ognl", ((Container)stack.getContext().get("com.opensymphony.xwork2.ActionContext.container")).getInstance(OgnlTool.class));
/* 67 */     map.put("struts", new StrutsUtil(stack, req, res));
/*    */ 
/* 69 */     ActionInvocation invocation = (ActionInvocation)stack.getContext().get("com.opensymphony.xwork2.ActionContext.actionInvocation");
/* 70 */     if (invocation != null) {
/* 71 */       map.put("action", invocation.getAction());
/*    */     }
/* 73 */     return map;
/*    */   }
/*    */ 
/*    */   public static boolean isUseAltSyntax(Map context)
/*    */   {
/* 85 */     return ("true".equals(((Container)context.get("com.opensymphony.xwork2.ActionContext.container")).getInstance(String.class, "struts.tag.altSyntax"))) || ((context.containsKey("useAltSyntax")) && (context.get("useAltSyntax") != null) && ("true".equals(context.get("useAltSyntax").toString())));
/*    */   }
/*    */ 
/*    */   public static String getTemplateSuffix(Map context)
/*    */   {
/* 97 */     return context.containsKey("templateSuffix") ? (String)context.get("templateSuffix") : null;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.views.util.ContextUtil
 * JD-Core Version:    0.6.0
 */