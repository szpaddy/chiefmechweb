package org.apache.struts2.config;

import com.opensymphony.xwork2.util.location.Location;
import java.util.Iterator;

abstract interface Settings
{
  public abstract String get(String paramString);

  public abstract Location getLocation(String paramString);

  public abstract Iterator list();
}

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.config.Settings
 * JD-Core Version:    0.6.0
 */