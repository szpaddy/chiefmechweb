/*    */ package org.apache.struts2.config;
/*    */ 
/*    */ import com.opensymphony.xwork2.config.Configuration;
/*    */ import com.opensymphony.xwork2.config.ConfigurationException;
/*    */ import com.opensymphony.xwork2.config.ConfigurationProvider;
/*    */ import com.opensymphony.xwork2.inject.ContainerBuilder;
/*    */ import com.opensymphony.xwork2.util.location.LocatableProperties;
/*    */ import java.util.Iterator;
/*    */ 
/*    */ public class PropertiesConfigurationProvider
/*    */   implements ConfigurationProvider
/*    */ {
/*    */   public void destroy()
/*    */   {
/*    */   }
/*    */ 
/*    */   public void init(Configuration configuration)
/*    */     throws ConfigurationException
/*    */   {
/*    */   }
/*    */ 
/*    */   public void loadPackages()
/*    */     throws ConfigurationException
/*    */   {
/*    */   }
/*    */ 
/*    */   public boolean needsReload()
/*    */   {
/* 44 */     return false;
/*    */   }
/*    */ 
/*    */   public void register(ContainerBuilder builder, LocatableProperties props) throws ConfigurationException {
/* 48 */     DefaultSettings settings = new DefaultSettings();
/* 49 */     loadSettings(props, settings);
/*    */   }
/*    */ 
/*    */   protected void loadSettings(LocatableProperties props, Settings settings)
/*    */   {
/* 57 */     for (Iterator i = settings.list(); i.hasNext(); ) {
/* 58 */       String name = (String)i.next();
/* 59 */       props.setProperty(name, settings.get(name), settings.getLocation(name));
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.config.PropertiesConfigurationProvider
 * JD-Core Version:    0.6.0
 */