/*    */ package org.apache.struts2.config;
/*    */ 
/*    */ import com.opensymphony.xwork2.util.location.Location;
/*    */ import com.opensymphony.xwork2.util.logging.Logger;
/*    */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Iterator;
/*    */ import java.util.StringTokenizer;
/*    */ 
/*    */ public class DefaultSettings
/*    */   implements Settings
/*    */ {
/* 41 */   private static final Logger LOG = LoggerFactory.getLogger(DefaultSettings.class);
/*    */   private Settings delegate;
/*    */ 
/*    */   public DefaultSettings()
/*    */   {
/* 59 */     ArrayList list = new ArrayList();
/*    */     try
/*    */     {
/* 63 */       list.add(new PropertiesSettings("struts"));
/*    */     } catch (Exception e) {
/* 65 */       LOG.warn("DefaultSettings: Could not find or error in struts.properties", e, new String[0]);
/*    */     }
/*    */ 
/* 68 */     this.delegate = new DelegatingSettings(list);
/*    */ 
/* 71 */     String files = this.delegate.get("struts.custom.properties");
/* 72 */     if (files != null) {
/* 73 */       StringTokenizer customProperties = new StringTokenizer(files, ",");
/*    */ 
/* 75 */       while (customProperties.hasMoreTokens()) {
/* 76 */         String name = customProperties.nextToken();
/*    */         try {
/* 78 */           list.add(new PropertiesSettings(name));
/*    */         } catch (Exception e) {
/* 80 */           LOG.error("DefaultSettings: Could not find " + name + ".properties. Skipping.", new String[0]);
/*    */         }
/*    */       }
/*    */ 
/* 84 */       this.delegate = new DelegatingSettings(list);
/*    */     }
/*    */   }
/*    */ 
/*    */   public Location getLocation(String name) {
/* 89 */     return this.delegate.getLocation(name);
/*    */   }
/*    */ 
/*    */   public String get(String aName) throws IllegalArgumentException {
/* 93 */     return this.delegate.get(aName);
/*    */   }
/*    */ 
/*    */   public Iterator list() {
/* 97 */     return this.delegate.list();
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.config.DefaultSettings
 * JD-Core Version:    0.6.0
 */