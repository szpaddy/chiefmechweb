/*    */ package org.apache.struts2.config;
/*    */ 
/*    */ import javax.servlet.ServletContext;
/*    */ 
/*    */ public class ServletContextSingleton
/*    */ {
/*    */   private ServletContext servletContext;
/*    */   private static ServletContextSingleton singleton;
/*    */ 
/*    */   public static ServletContextSingleton getInstance()
/*    */   {
/* 68 */     if (singleton == null) {
/* 69 */       singleton = new ServletContextSingleton();
/*    */     }
/* 71 */     return singleton;
/*    */   }
/*    */ 
/*    */   public ServletContext getServletContext()
/*    */   {
/* 80 */     return this.servletContext;
/*    */   }
/*    */ 
/*    */   public void setServletContext(ServletContext context)
/*    */   {
/* 89 */     this.servletContext = context;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.config.ServletContextSingleton
 * JD-Core Version:    0.6.0
 */