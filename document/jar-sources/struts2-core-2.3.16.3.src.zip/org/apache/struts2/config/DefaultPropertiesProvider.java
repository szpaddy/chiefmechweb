/*    */ package org.apache.struts2.config;
/*    */ 
/*    */ import com.opensymphony.xwork2.config.Configuration;
/*    */ import com.opensymphony.xwork2.config.ConfigurationException;
/*    */ import com.opensymphony.xwork2.inject.ContainerBuilder;
/*    */ import com.opensymphony.xwork2.util.location.LocatableProperties;
/*    */ 
/*    */ public class DefaultPropertiesProvider extends PropertiesConfigurationProvider
/*    */ {
/*    */   public void destroy()
/*    */   {
/*    */   }
/*    */ 
/*    */   public void init(Configuration configuration)
/*    */     throws ConfigurationException
/*    */   {
/*    */   }
/*    */ 
/*    */   public void register(ContainerBuilder builder, LocatableProperties props)
/*    */     throws ConfigurationException
/*    */   {
/*    */     try
/*    */     {
/* 42 */       PropertiesSettings defaultSettings = new PropertiesSettings("org/apache/struts2/default");
/* 43 */       loadSettings(props, defaultSettings);
/*    */     } catch (Exception e) {
/* 45 */       throw new ConfigurationException("Could not find or error in org/apache/struts2/default.properties", e);
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.config.DefaultPropertiesProvider
 * JD-Core Version:    0.6.0
 */