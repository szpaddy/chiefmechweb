/*     */ package org.apache.struts2.config;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionContext;
/*     */ import com.opensymphony.xwork2.config.ConfigurationException;
/*     */ import com.opensymphony.xwork2.config.providers.XmlConfigurationProvider;
/*     */ import com.opensymphony.xwork2.inject.ContainerBuilder;
/*     */ import com.opensymphony.xwork2.inject.Context;
/*     */ import com.opensymphony.xwork2.inject.Factory;
/*     */ import com.opensymphony.xwork2.util.location.LocatableProperties;
/*     */ import com.opensymphony.xwork2.util.logging.Logger;
/*     */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URI;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.servlet.ServletContext;
/*     */ 
/*     */ public class StrutsXmlConfigurationProvider extends XmlConfigurationProvider
/*     */ {
/*  51 */   private static final Logger LOG = LoggerFactory.getLogger(StrutsXmlConfigurationProvider.class);
/*  52 */   private File baseDir = null;
/*     */   private String filename;
/*     */   private String reloadKey;
/*     */   private ServletContext servletContext;
/*     */ 
/*     */   public StrutsXmlConfigurationProvider(boolean errorIfMissing)
/*     */   {
/*  63 */     this("struts.xml", errorIfMissing, null);
/*     */   }
/*     */ 
/*     */   public StrutsXmlConfigurationProvider(String filename, boolean errorIfMissing, ServletContext ctx)
/*     */   {
/*  74 */     super(filename, errorIfMissing);
/*  75 */     this.servletContext = ctx;
/*  76 */     this.filename = filename;
/*  77 */     this.reloadKey = ("configurationReload-" + filename);
/*  78 */     Map dtdMappings = new HashMap(getDtdMappings());
/*  79 */     dtdMappings.put("-//Apache Software Foundation//DTD Struts Configuration 2.0//EN", "struts-2.0.dtd");
/*  80 */     dtdMappings.put("-//Apache Software Foundation//DTD Struts Configuration 2.1//EN", "struts-2.1.dtd");
/*  81 */     dtdMappings.put("-//Apache Software Foundation//DTD Struts Configuration 2.1.7//EN", "struts-2.1.7.dtd");
/*  82 */     dtdMappings.put("-//Apache Software Foundation//DTD Struts Configuration 2.3//EN", "struts-2.3.dtd");
/*  83 */     setDtdMappings(dtdMappings);
/*  84 */     File file = new File(filename);
/*  85 */     if (file.getParent() != null)
/*  86 */       this.baseDir = file.getParentFile();
/*     */   }
/*     */ 
/*     */   public void register(ContainerBuilder containerBuilder, LocatableProperties props)
/*     */     throws ConfigurationException
/*     */   {
/*  95 */     if ((this.servletContext != null) && (!containerBuilder.contains(ServletContext.class)))
/*  96 */       containerBuilder.factory(ServletContext.class, new Factory() {
/*     */         public ServletContext create(Context context) throws Exception {
/*  98 */           return StrutsXmlConfigurationProvider.this.servletContext;
/*     */         }
/*     */       });
/* 102 */     super.register(containerBuilder, props);
/*     */   }
/*     */ 
/*     */   public void loadPackages()
/*     */   {
/* 110 */     ActionContext ctx = ActionContext.getContext();
/* 111 */     ctx.put(this.reloadKey, Boolean.TRUE);
/* 112 */     super.loadPackages();
/*     */   }
/*     */ 
/*     */   protected Iterator<URL> getConfigurationUrls(String fileName)
/*     */     throws IOException
/*     */   {
/* 123 */     URL url = null;
/* 124 */     if (this.baseDir != null) {
/* 125 */       url = findInFileSystem(fileName);
/* 126 */       if (url == null) {
/* 127 */         return super.getConfigurationUrls(fileName);
/*     */       }
/*     */     }
/* 130 */     if (url != null) {
/* 131 */       List list = new ArrayList();
/* 132 */       list.add(url);
/* 133 */       return list.iterator();
/*     */     }
/* 135 */     return super.getConfigurationUrls(fileName);
/*     */   }
/*     */ 
/*     */   protected URL findInFileSystem(String fileName) throws IOException
/*     */   {
/* 140 */     URL url = null;
/* 141 */     File file = new File(fileName);
/* 142 */     if (LOG.isDebugEnabled()) {
/* 143 */       LOG.debug("Trying to load file " + file, new String[0]);
/*     */     }
/*     */ 
/* 147 */     if (!file.exists()) {
/* 148 */       file = new File(this.baseDir, fileName);
/*     */     }
/* 150 */     if (file.exists()) {
/*     */       try {
/* 152 */         url = file.toURI().toURL();
/*     */       } catch (MalformedURLException e) {
/* 154 */         throw new IOException("Unable to convert " + file + " to a URL");
/*     */       }
/*     */     }
/* 157 */     return url;
/*     */   }
/*     */ 
/*     */   public boolean needsReload()
/*     */   {
/* 165 */     ActionContext ctx = ActionContext.getContext();
/* 166 */     if (ctx != null) {
/* 167 */       return (ctx.get(this.reloadKey) == null) && (super.needsReload());
/*     */     }
/* 169 */     return super.needsReload();
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 175 */     return "Struts XML configuration provider (" + this.filename + ")";
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.config.StrutsXmlConfigurationProvider
 * JD-Core Version:    0.6.0
 */