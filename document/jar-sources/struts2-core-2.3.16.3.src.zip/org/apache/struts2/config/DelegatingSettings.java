/*     */ package org.apache.struts2.config;
/*     */ 
/*     */ import com.opensymphony.xwork2.util.location.Location;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ 
/*     */ class DelegatingSettings
/*     */   implements Settings
/*     */ {
/*     */   List<Settings> delegates;
/*     */ 
/*     */   public DelegatingSettings(List<Settings> delegates)
/*     */   {
/*  55 */     this.delegates = delegates;
/*     */   }
/*     */ 
/*     */   public String get(String name) throws IllegalArgumentException {
/*  59 */     for (Settings delegate : this.delegates) {
/*  60 */       String value = delegate.get(name);
/*  61 */       if (value != null) {
/*  62 */         return value;
/*     */       }
/*     */     }
/*  65 */     return null;
/*     */   }
/*     */ 
/*     */   public Iterator list()
/*     */   {
/*  70 */     boolean workedAtAll = false;
/*     */ 
/*  72 */     Set settingList = new HashSet();
/*  73 */     UnsupportedOperationException e = null;
/*     */ 
/*  75 */     for (Settings delegate : this.delegates) {
/*     */       try {
/*  77 */         Iterator list = delegate.list();
/*     */ 
/*  79 */         while (list.hasNext()) {
/*  80 */           settingList.add(list.next());
/*     */         }
/*     */ 
/*  83 */         workedAtAll = true;
/*     */       } catch (UnsupportedOperationException ex) {
/*  85 */         e = ex;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/*  91 */     if (!workedAtAll) {
/*  92 */       throw (e == null ? new UnsupportedOperationException() : e);
/*     */     }
/*  94 */     return settingList.iterator();
/*     */   }
/*     */ 
/*     */   public Location getLocation(String name)
/*     */   {
/*  99 */     for (Settings delegate : this.delegates) {
/* 100 */       Location loc = delegate.getLocation(name);
/* 101 */       if (loc != null) {
/* 102 */         return loc;
/*     */       }
/*     */     }
/* 105 */     return Location.UNKNOWN;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.config.DelegatingSettings
 * JD-Core Version:    0.6.0
 */