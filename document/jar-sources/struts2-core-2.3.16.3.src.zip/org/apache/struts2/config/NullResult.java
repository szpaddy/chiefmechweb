/*    */ package org.apache.struts2.config;
/*    */ 
/*    */ import com.opensymphony.xwork2.ActionInvocation;
/*    */ import com.opensymphony.xwork2.Result;
/*    */ 
/*    */ public class NullResult
/*    */   implements Result
/*    */ {
/*    */   public void execute(ActionInvocation invocation)
/*    */     throws Exception
/*    */   {
/* 33 */     throw new IllegalStateException("Shouldn't be called");
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.config.NullResult
 * JD-Core Version:    0.6.0
 */