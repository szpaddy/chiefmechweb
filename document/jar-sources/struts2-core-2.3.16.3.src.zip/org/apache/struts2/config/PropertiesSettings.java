/*     */ package org.apache.struts2.config;
/*     */ 
/*     */ import com.opensymphony.xwork2.util.ClassLoaderUtil;
/*     */ import com.opensymphony.xwork2.util.location.LocatableProperties;
/*     */ import com.opensymphony.xwork2.util.location.Location;
/*     */ import com.opensymphony.xwork2.util.location.LocationImpl;
/*     */ import com.opensymphony.xwork2.util.logging.Logger;
/*     */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URL;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ import org.apache.struts2.StrutsException;
/*     */ 
/*     */ class PropertiesSettings
/*     */   implements Settings
/*     */ {
/*  43 */   private static final Logger LOG = LoggerFactory.getLogger(PropertiesSettings.class);
/*     */   private LocatableProperties settings;
/*     */ 
/*     */   public PropertiesSettings(String name)
/*     */   {
/*  56 */     URL settingsUrl = ClassLoaderUtil.getResource(name + ".properties", getClass());
/*     */ 
/*  58 */     if (settingsUrl == null) {
/*  59 */       if (LOG.isDebugEnabled()) {
/*  60 */         LOG.debug(name + ".properties missing", new String[0]);
/*     */       }
/*  62 */       this.settings = new LocatableProperties();
/*  63 */       return;
/*     */     }
/*     */ 
/*  66 */     this.settings = new LocatableProperties(new LocationImpl(null, settingsUrl.toString()));
/*     */ 
/*  69 */     InputStream in = null;
/*     */     try {
/*  71 */       in = settingsUrl.openStream();
/*  72 */       this.settings.load(in);
/*     */     } catch (IOException e) {
/*  74 */       throw new StrutsException("Could not load " + name + ".properties:" + e, e);
/*     */     } finally {
/*  76 */       if (in != null)
/*     */         try {
/*  78 */           in.close();
/*     */         } catch (IOException io) {
/*  80 */           if (LOG.isWarnEnabled())
/*  81 */             LOG.warn("Unable to close input stream", io, new String[0]);
/*     */         }
/*     */     }
/*     */   }
/*     */ 
/*     */   public String get(String aName)
/*     */     throws IllegalArgumentException
/*     */   {
/*  95 */     return this.settings.getProperty(aName);
/*     */   }
/*     */ 
/*     */   public Location getLocation(String aName)
/*     */     throws IllegalArgumentException
/*     */   {
/* 104 */     return this.settings.getPropertyLocation(aName);
/*     */   }
/*     */ 
/*     */   public Iterator list()
/*     */   {
/* 113 */     return this.settings.keySet().iterator();
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.config.PropertiesSettings
 * JD-Core Version:    0.6.0
 */