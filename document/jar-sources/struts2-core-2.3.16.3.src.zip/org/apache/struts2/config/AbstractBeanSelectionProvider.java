/*     */ package org.apache.struts2.config;
/*     */ 
/*     */ import com.opensymphony.xwork2.ObjectFactory;
/*     */ import com.opensymphony.xwork2.config.BeanSelectionProvider;
/*     */ import com.opensymphony.xwork2.config.Configuration;
/*     */ import com.opensymphony.xwork2.config.ConfigurationException;
/*     */ import com.opensymphony.xwork2.inject.Container;
/*     */ import com.opensymphony.xwork2.inject.ContainerBuilder;
/*     */ import com.opensymphony.xwork2.inject.Context;
/*     */ import com.opensymphony.xwork2.inject.Factory;
/*     */ import com.opensymphony.xwork2.inject.Scope;
/*     */ import com.opensymphony.xwork2.util.ClassLoaderUtil;
/*     */ import com.opensymphony.xwork2.util.location.LocatableProperties;
/*     */ import com.opensymphony.xwork2.util.logging.Logger;
/*     */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*     */ import java.util.Properties;
/*     */ 
/*     */ public abstract class AbstractBeanSelectionProvider
/*     */   implements BeanSelectionProvider
/*     */ {
/*  24 */   private static final Logger LOG = LoggerFactory.getLogger(AbstractBeanSelectionProvider.class);
/*     */   public static final String DEFAULT_BEAN_NAME = "struts";
/*     */ 
/*     */   public void destroy()
/*     */   {
/*     */   }
/*     */ 
/*     */   public void loadPackages()
/*     */     throws ConfigurationException
/*     */   {
/*     */   }
/*     */ 
/*     */   public void init(Configuration configuration)
/*     */     throws ConfigurationException
/*     */   {
/*     */   }
/*     */ 
/*     */   public boolean needsReload()
/*     */   {
/*  41 */     return false;
/*     */   }
/*     */ 
/*     */   protected void alias(Class type, String key, ContainerBuilder builder, Properties props) {
/*  45 */     alias(type, key, builder, props, Scope.SINGLETON);
/*     */   }
/*     */ 
/*     */   protected void alias(Class type, String key, ContainerBuilder builder, Properties props, Scope scope) {
/*  49 */     if (!builder.contains(type)) {
/*  50 */       String foundName = props.getProperty(key, "struts");
/*  51 */       if (builder.contains(type, foundName)) {
/*  52 */         if (LOG.isInfoEnabled()) {
/*  53 */           LOG.info("Choosing bean (#0) for (#1)", new String[] { foundName, type.getName() });
/*     */         }
/*  55 */         builder.alias(type, foundName, "default");
/*     */       } else {
/*     */         try {
/*  58 */           Class cls = ClassLoaderUtil.loadClass(foundName, getClass());
/*  59 */           if (LOG.isDebugEnabled()) {
/*  60 */             LOG.debug("Choosing bean (#0) for (#1)", new String[] { cls.getName(), type.getName() });
/*     */           }
/*  62 */           builder.factory(type, cls, scope);
/*     */         }
/*     */         catch (ClassNotFoundException ex) {
/*  65 */           if (LOG.isDebugEnabled()) {
/*  66 */             LOG.debug("Choosing bean (#0) for (#1) to be loaded from the ObjectFactory", new String[] { foundName, type.getName() });
/*     */           }
/*  68 */           if (!"struts".equals(foundName))
/*     */           {
/*  71 */             if (ObjectFactory.class != type)
/*  72 */               builder.factory(type, new ObjectFactoryDelegateFactory(foundName, type), scope);
/*     */             else {
/*  74 */               throw new ConfigurationException("Cannot locate the chosen ObjectFactory implementation: " + foundName);
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*  80 */     else if (LOG.isWarnEnabled()) {
/*  81 */       LOG.warn("Unable to alias bean type (#0), default mapping already assigned.", new String[] { type.getName() });
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void convertIfExist(LocatableProperties props, String fromKey, String toKey)
/*     */   {
/*  87 */     if (props.containsKey(fromKey))
/*  88 */       props.setProperty(toKey, props.getProperty(fromKey));
/*     */   }
/*     */ 
/*     */   static class ObjectFactoryDelegateFactory implements Factory
/*     */   {
/*     */     String name;
/*     */     Class type;
/*     */ 
/*     */     ObjectFactoryDelegateFactory(String name, Class type)
/*     */     {
/* 100 */       this.name = name;
/* 101 */       this.type = type;
/*     */     }
/*     */ 
/*     */     public Object create(Context context) throws Exception {
/* 105 */       ObjectFactory objFactory = (ObjectFactory)context.getContainer().getInstance(ObjectFactory.class);
/*     */       try {
/* 107 */         return objFactory.buildBean(this.name, null, true); } catch (ClassNotFoundException ex) {
/*     */       }
/* 109 */       throw new ConfigurationException("Unable to load bean " + this.type.getName() + " (" + this.name + ")");
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.config.AbstractBeanSelectionProvider
 * JD-Core Version:    0.6.0
 */