/*     */ package org.apache.struts2.config;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionProxyFactory;
/*     */ import com.opensymphony.xwork2.FileManagerFactory;
/*     */ import com.opensymphony.xwork2.LocaleProvider;
/*     */ import com.opensymphony.xwork2.ObjectFactory;
/*     */ import com.opensymphony.xwork2.TextProvider;
/*     */ import com.opensymphony.xwork2.UnknownHandlerManager;
/*     */ import com.opensymphony.xwork2.conversion.ConversionAnnotationProcessor;
/*     */ import com.opensymphony.xwork2.conversion.ConversionFileProcessor;
/*     */ import com.opensymphony.xwork2.conversion.ConversionPropertiesProcessor;
/*     */ import com.opensymphony.xwork2.conversion.ObjectTypeDeterminer;
/*     */ import com.opensymphony.xwork2.conversion.TypeConverterCreator;
/*     */ import com.opensymphony.xwork2.conversion.TypeConverterHolder;
/*     */ import com.opensymphony.xwork2.conversion.impl.ArrayConverter;
/*     */ import com.opensymphony.xwork2.conversion.impl.CollectionConverter;
/*     */ import com.opensymphony.xwork2.conversion.impl.DateConverter;
/*     */ import com.opensymphony.xwork2.conversion.impl.NumberConverter;
/*     */ import com.opensymphony.xwork2.conversion.impl.StringConverter;
/*     */ import com.opensymphony.xwork2.conversion.impl.XWorkConverter;
/*     */ import com.opensymphony.xwork2.factory.ActionFactory;
/*     */ import com.opensymphony.xwork2.factory.ConverterFactory;
/*     */ import com.opensymphony.xwork2.factory.InterceptorFactory;
/*     */ import com.opensymphony.xwork2.factory.ResultFactory;
/*     */ import com.opensymphony.xwork2.factory.ValidatorFactory;
/*     */ import com.opensymphony.xwork2.inject.ContainerBuilder;
/*     */ import com.opensymphony.xwork2.inject.Scope;
/*     */ import com.opensymphony.xwork2.util.LocalizedTextUtil;
/*     */ import com.opensymphony.xwork2.util.PatternMatcher;
/*     */ import com.opensymphony.xwork2.util.TextParser;
/*     */ import com.opensymphony.xwork2.util.ValueStackFactory;
/*     */ import com.opensymphony.xwork2.util.location.LocatableProperties;
/*     */ import com.opensymphony.xwork2.util.logging.Logger;
/*     */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*     */ import com.opensymphony.xwork2.util.reflection.ReflectionContextFactory;
/*     */ import com.opensymphony.xwork2.util.reflection.ReflectionProvider;
/*     */ import com.opensymphony.xwork2.validator.ActionValidatorManager;
/*     */ import java.util.StringTokenizer;
/*     */ import org.apache.struts2.components.UrlRenderer;
/*     */ import org.apache.struts2.dispatcher.StaticContentLoader;
/*     */ import org.apache.struts2.dispatcher.mapper.ActionMapper;
/*     */ import org.apache.struts2.dispatcher.multipart.MultiPartRequest;
/*     */ import org.apache.struts2.views.freemarker.FreemarkerManager;
/*     */ import org.apache.struts2.views.util.UrlHelper;
/*     */ import org.apache.struts2.views.velocity.VelocityManager;
/*     */ 
/*     */ public class DefaultBeanSelectionProvider extends AbstractBeanSelectionProvider
/*     */ {
/* 337 */   private static final Logger LOG = LoggerFactory.getLogger(DefaultBeanSelectionProvider.class);
/*     */ 
/*     */   public void register(ContainerBuilder builder, LocatableProperties props) {
/* 340 */     alias(ObjectFactory.class, "struts.objectFactory", builder, props);
/* 341 */     alias(ActionFactory.class, "struts.objectFactory.actionFactory", builder, props);
/* 342 */     alias(ResultFactory.class, "struts.objectFactory.resultFactory", builder, props);
/* 343 */     alias(ConverterFactory.class, "struts.objectFactory.converterFactory", builder, props);
/* 344 */     alias(InterceptorFactory.class, "struts.objectFactory.interceptorFactory", builder, props);
/* 345 */     alias(ValidatorFactory.class, "struts.objectFactory.interceptorFactory", builder, props);
/*     */ 
/* 347 */     alias(FileManagerFactory.class, "struts.fileManagerFactory", builder, props, Scope.SINGLETON);
/*     */ 
/* 349 */     alias(XWorkConverter.class, "struts.xworkConverter", builder, props);
/* 350 */     alias(CollectionConverter.class, "struts.converter.collection", builder, props);
/* 351 */     alias(ArrayConverter.class, "struts.converter.array", builder, props);
/* 352 */     alias(DateConverter.class, "struts.converter.date", builder, props);
/* 353 */     alias(NumberConverter.class, "struts.converter.number", builder, props);
/* 354 */     alias(StringConverter.class, "struts.converter.string", builder, props);
/*     */ 
/* 356 */     alias(ConversionPropertiesProcessor.class, "struts.converter.properties.processor", builder, props);
/* 357 */     alias(ConversionFileProcessor.class, "struts.converter.file.processor", builder, props);
/* 358 */     alias(ConversionAnnotationProcessor.class, "struts.converter.annotation.processor", builder, props);
/* 359 */     alias(TypeConverterCreator.class, "struts.converter.creator", builder, props);
/* 360 */     alias(TypeConverterHolder.class, "struts..converter.holder", builder, props);
/*     */ 
/* 362 */     alias(TextProvider.class, "struts.xworkTextProvider", builder, props, Scope.DEFAULT);
/*     */ 
/* 364 */     alias(LocaleProvider.class, "struts.localeProvider", builder, props);
/* 365 */     alias(ActionProxyFactory.class, "struts.actionProxyFactory", builder, props);
/* 366 */     alias(ObjectTypeDeterminer.class, "struts.objectTypeDeterminer", builder, props);
/* 367 */     alias(ActionMapper.class, "struts.mapper.class", builder, props);
/* 368 */     alias(MultiPartRequest.class, "struts.multipart.parser", builder, props, Scope.DEFAULT);
/* 369 */     alias(FreemarkerManager.class, "struts.freemarker.manager.classname", builder, props);
/* 370 */     alias(VelocityManager.class, "struts.velocity.manager.classname", builder, props);
/* 371 */     alias(UrlRenderer.class, "struts.urlRenderer", builder, props);
/* 372 */     alias(ActionValidatorManager.class, "struts.actionValidatorManager", builder, props);
/* 373 */     alias(ValueStackFactory.class, "struts.valueStackFactory", builder, props);
/* 374 */     alias(ReflectionProvider.class, "struts.reflectionProvider", builder, props);
/* 375 */     alias(ReflectionContextFactory.class, "struts.reflectionContextFactory", builder, props);
/* 376 */     alias(PatternMatcher.class, "struts.patternMatcher", builder, props);
/* 377 */     alias(StaticContentLoader.class, "struts.staticContentLoader", builder, props);
/* 378 */     alias(UnknownHandlerManager.class, "struts.unknownHandlerManager", builder, props);
/* 379 */     alias(UrlHelper.class, "struts.view.urlHelper", builder, props);
/*     */ 
/* 381 */     alias(TextParser.class, "struts.expression.parser", builder, props);
/*     */ 
/* 383 */     switchDevMode(props);
/*     */ 
/* 386 */     convertIfExist(props, "struts.ognl.logMissingProperties", "logMissingProperties");
/* 387 */     convertIfExist(props, "struts.ognl.enableExpressionCache", "enableOGNLExpressionCache");
/* 388 */     convertIfExist(props, "struts.ognl.enableOGNLEvalExpression", "enableOGNLEvalExpression");
/* 389 */     convertIfExist(props, "struts.ognl.allowStaticMethodAccess", "allowStaticMethodAccess");
/* 390 */     convertIfExist(props, "struts.configuration.xml.reload", "reloadXmlConfiguration");
/*     */ 
/* 392 */     LocalizedTextUtil.addDefaultResourceBundle("org/apache/struts2/struts-messages");
/* 393 */     loadCustomResourceBundles(props);
/*     */   }
/*     */ 
/*     */   private void switchDevMode(LocatableProperties props)
/*     */   {
/* 402 */     if ("true".equalsIgnoreCase(props.getProperty("struts.devMode"))) {
/* 403 */       if (props.getProperty("struts.i18n.reload") == null) {
/* 404 */         props.setProperty("struts.i18n.reload", "true");
/*     */       }
/* 406 */       if (props.getProperty("struts.configuration.xml.reload") == null) {
/* 407 */         props.setProperty("struts.configuration.xml.reload", "true");
/*     */       }
/* 409 */       if (props.getProperty("struts.freemarker.templatesCache") == null) {
/* 410 */         props.setProperty("struts.freemarker.templatesCache", "false");
/*     */       }
/* 412 */       if (props.getProperty("struts.freemarker.templatesCache.updateDelay") == null) {
/* 413 */         props.setProperty("struts.freemarker.templatesCache.updateDelay", "0");
/*     */       }
/*     */ 
/* 416 */       props.setProperty("devMode", "true");
/*     */     } else {
/* 418 */       props.setProperty("devMode", "false");
/*     */     }
/*     */   }
/*     */ 
/*     */   private void loadCustomResourceBundles(LocatableProperties props) {
/* 423 */     String bundles = props.getProperty("struts.custom.i18n.resources");
/* 424 */     if ((bundles != null) && (bundles.length() > 0)) {
/* 425 */       StringTokenizer customBundles = new StringTokenizer(bundles, ", ");
/*     */ 
/* 427 */       while (customBundles.hasMoreTokens()) {
/* 428 */         String name = customBundles.nextToken();
/*     */         try {
/* 430 */           if (LOG.isInfoEnabled()) {
/* 431 */             LOG.info("Loading global messages from [#0]", new String[] { name });
/*     */           }
/* 433 */           LocalizedTextUtil.addDefaultResourceBundle(name);
/*     */         } catch (Exception e) {
/* 435 */           LOG.error("Could not find messages file #0.properties. Skipping", new String[] { name });
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.config.DefaultBeanSelectionProvider
 * JD-Core Version:    0.6.0
 */