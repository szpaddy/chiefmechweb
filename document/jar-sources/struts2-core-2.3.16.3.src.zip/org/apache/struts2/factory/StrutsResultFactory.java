/*    */ package org.apache.struts2.factory;
/*    */ 
/*    */ import com.opensymphony.xwork2.ObjectFactory;
/*    */ import com.opensymphony.xwork2.Result;
/*    */ import com.opensymphony.xwork2.config.entities.ResultConfig;
/*    */ import com.opensymphony.xwork2.factory.ResultFactory;
/*    */ import com.opensymphony.xwork2.inject.Inject;
/*    */ import com.opensymphony.xwork2.result.ParamNameAwareResult;
/*    */ import com.opensymphony.xwork2.util.reflection.ReflectionException;
/*    */ import com.opensymphony.xwork2.util.reflection.ReflectionExceptionHandler;
/*    */ import com.opensymphony.xwork2.util.reflection.ReflectionProvider;
/*    */ import java.util.Map;
/*    */ import java.util.Map.Entry;
/*    */ 
/*    */ public class StrutsResultFactory
/*    */   implements ResultFactory
/*    */ {
/*    */   protected ObjectFactory objectFactory;
/*    */   protected ReflectionProvider reflectionProvider;
/*    */ 
/*    */   @Inject
/*    */   public void setObjectFactory(ObjectFactory objectFactory)
/*    */   {
/* 25 */     this.objectFactory = objectFactory;
/*    */   }
/*    */   @Inject
/*    */   public void setReflectionProvider(ReflectionProvider provider) {
/* 30 */     this.reflectionProvider = provider;
/*    */   }
/*    */ 
/*    */   public Result buildResult(ResultConfig resultConfig, Map<String, Object> extraContext) throws Exception {
/* 34 */     String resultClassName = resultConfig.getClassName();
/* 35 */     Result result = null;
/*    */ 
/* 37 */     if (resultClassName != null) {
/* 38 */       result = (Result)this.objectFactory.buildBean(resultClassName, extraContext);
/* 39 */       Map params = resultConfig.getParams();
/* 40 */       if (params != null) {
/* 41 */         setParameters(extraContext, result, params);
/*    */       }
/*    */     }
/* 44 */     return result;
/*    */   }
/*    */ 
/*    */   protected void setParameters(Map<String, Object> extraContext, Result result, Map<String, String> params) {
/* 48 */     for (Map.Entry paramEntry : params.entrySet())
/*    */       try {
/* 50 */         String name = (String)paramEntry.getKey();
/* 51 */         String value = (String)paramEntry.getValue();
/* 52 */         setParameter(result, name, value, extraContext);
/*    */       } catch (ReflectionException ex) {
/* 54 */         if ((result instanceof ReflectionExceptionHandler))
/* 55 */           ((ReflectionExceptionHandler)result).handle(ex);
/*    */       }
/*    */   }
/*    */ 
/*    */   protected void setParameter(Result result, String name, String value, Map<String, Object> extraContext)
/*    */   {
/* 62 */     if ((result instanceof ParamNameAwareResult)) {
/* 63 */       if (((ParamNameAwareResult)result).acceptableParameterName(name, value))
/* 64 */         this.reflectionProvider.setProperty(name, value, result, extraContext, true);
/*    */     }
/*    */     else
/* 67 */       this.reflectionProvider.setProperty(name, value, result, extraContext, true);
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.factory.StrutsResultFactory
 * JD-Core Version:    0.6.0
 */