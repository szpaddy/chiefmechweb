/*    */ package org.apache.struts2.impl;
/*    */ 
/*    */ import com.opensymphony.xwork2.ActionInvocation;
/*    */ import com.opensymphony.xwork2.ActionProxy;
/*    */ import com.opensymphony.xwork2.DefaultActionProxyFactory;
/*    */ import com.opensymphony.xwork2.inject.Container;
/*    */ 
/*    */ public class StrutsActionProxyFactory extends DefaultActionProxyFactory
/*    */ {
/*    */   public ActionProxy createActionProxy(ActionInvocation inv, String namespace, String actionName, String methodName, boolean executeResult, boolean cleanupContext)
/*    */   {
/* 35 */     StrutsActionProxy proxy = new StrutsActionProxy(inv, namespace, actionName, methodName, executeResult, cleanupContext);
/* 36 */     this.container.inject(proxy);
/* 37 */     proxy.prepare();
/* 38 */     return proxy;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.impl.StrutsActionProxyFactory
 * JD-Core Version:    0.6.0
 */