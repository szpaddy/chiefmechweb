/*    */ package org.apache.struts2.impl;
/*    */ 
/*    */ import com.opensymphony.xwork2.ActionProxy;
/*    */ import com.opensymphony.xwork2.ActionProxyFactory;
/*    */ import com.opensymphony.xwork2.DefaultActionProxyFactory;
/*    */ import com.opensymphony.xwork2.inject.Container;
/*    */ import com.opensymphony.xwork2.inject.Inject;
/*    */ import com.opensymphony.xwork2.util.logging.Logger;
/*    */ import com.opensymphony.xwork2.util.logging.LoggerFactory;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class PrefixBasedActionProxyFactory extends DefaultActionProxyFactory
/*    */ {
/* 36 */   private static final Logger LOG = LoggerFactory.getLogger(PrefixBasedActionProxyFactory.class);
/*    */ 
/* 38 */   private Map<String, ActionProxyFactory> actionProxyFactories = new HashMap();
/*    */   private ActionProxyFactory defaultFactory;
/*    */ 
/*    */   @Inject
/*    */   public void setContainer(Container container)
/*    */   {
/* 43 */     this.container = container;
/*    */   }
/*    */   @Inject("struts.actionProxyFactory")
/*    */   public void setActionProxyFactory(ActionProxyFactory factory) {
/* 48 */     this.defaultFactory = factory;
/*    */   }
/*    */   @Inject("struts.mapper.prefixMapping")
/*    */   public void setPrefixBasedActionProxyFactories(String list) {
/* 53 */     if (list != null) {
/* 54 */       String[] factories = list.split(",");
/* 55 */       for (String factory : factories) {
/* 56 */         String[] thisFactory = factory.split(":");
/* 57 */         if ((thisFactory != null) && (thisFactory.length == 2)) {
/* 58 */           String factoryPrefix = thisFactory[0].trim();
/* 59 */           String factoryName = thisFactory[1].trim();
/* 60 */           ActionProxyFactory obj = (ActionProxyFactory)this.container.getInstance(ActionProxyFactory.class, factoryName);
/* 61 */           if (obj != null)
/* 62 */             this.actionProxyFactories.put(factoryPrefix, obj);
/* 63 */           else if (LOG.isWarnEnabled())
/* 64 */             LOG.warn("Invalid PrefixBasedActionProxyFactory config entry: [#0]", new String[] { factory });
/*    */         }
/*    */       }
/*    */     }
/*    */   }
/*    */ 
/*    */   public ActionProxy createActionProxy(String namespace, String actionName, String methodName, Map<String, Object> extraContext, boolean executeResult, boolean cleanupContext)
/*    */   {
/* 74 */     String uri = namespace + (namespace.endsWith("/") ? actionName : new StringBuilder().append("/").append(actionName).toString());
/* 75 */     for (int lastIndex = uri.lastIndexOf('/'); lastIndex > -1; lastIndex = uri.lastIndexOf('/', lastIndex - 1)) {
/* 76 */       String key = uri.substring(0, lastIndex);
/* 77 */       ActionProxyFactory actionProxyFactory = (ActionProxyFactory)this.actionProxyFactories.get(key);
/* 78 */       if (actionProxyFactory != null) {
/* 79 */         if (LOG.isDebugEnabled()) {
/* 80 */           LOG.debug("Using ActionProxyFactory [#0] for prefix [#1]", new Object[] { actionProxyFactory, key });
/*    */         }
/* 82 */         return actionProxyFactory.createActionProxy(namespace, actionName, methodName, extraContext, executeResult, cleanupContext);
/* 83 */       }if (LOG.isDebugEnabled()) {
/* 84 */         LOG.debug("No ActionProxyFactory defined for [#1]", new String[] { key });
/*    */       }
/*    */     }
/* 87 */     if (LOG.isDebugEnabled()) {
/* 88 */       LOG.debug("Cannot find any matching ActionProxyFactory, falling back to [#0]", new Object[] { this.defaultFactory });
/*    */     }
/* 90 */     return this.defaultFactory.createActionProxy(namespace, actionName, methodName, extraContext, executeResult, cleanupContext);
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.impl.PrefixBasedActionProxyFactory
 * JD-Core Version:    0.6.0
 */