/*    */ package org.apache.struts2.impl;
/*    */ 
/*    */ import com.opensymphony.xwork2.ObjectFactory;
/*    */ import com.opensymphony.xwork2.config.ConfigurationException;
/*    */ import com.opensymphony.xwork2.config.entities.InterceptorConfig;
/*    */ import com.opensymphony.xwork2.inject.Inject;
/*    */ import com.opensymphony.xwork2.interceptor.Interceptor;
/*    */ import com.opensymphony.xwork2.util.reflection.ReflectionProvider;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ @Deprecated
/*    */ public class StrutsObjectFactory extends ObjectFactory
/*    */ {
/*    */   private ReflectionProvider reflectionProvider;
/*    */ 
/*    */   @Inject
/*    */   public void setReflectionProvider(ReflectionProvider reflectionProvider)
/*    */   {
/* 49 */     this.reflectionProvider = reflectionProvider;
/*    */   }
/*    */ 
/*    */   public Interceptor buildInterceptor(InterceptorConfig interceptorConfig, Map refParams) throws ConfigurationException
/*    */   {
/* 54 */     String className = interceptorConfig.getClassName();
/*    */ 
/* 56 */     Map params = new HashMap();
/* 57 */     Map typeParams = interceptorConfig.getParams();
/* 58 */     if ((typeParams != null) && (!typeParams.isEmpty()))
/* 59 */       params.putAll(typeParams);
/* 60 */     if ((refParams != null) && (!refParams.isEmpty())) {
/* 61 */       params.putAll(refParams);
/*    */     }
/*    */ 
/*    */     try
/*    */     {
/* 66 */       Object o = buildBean(className, null);
/* 67 */       this.reflectionProvider.setProperties(params, o);
/*    */ 
/* 69 */       if ((o instanceof Interceptor)) {
/* 70 */         Interceptor interceptor = (Interceptor)o;
/* 71 */         interceptor.init();
/* 72 */         return interceptor;
/*    */       }
/*    */ 
/* 79 */       throw new ConfigurationException("Class [" + className + "] does not implement Interceptor", interceptorConfig);
/*    */     }
/*    */     catch (InstantiationException e) {
/* 82 */       throw new ConfigurationException("Unable to instantiate an instance of Interceptor class [" + className + "].", e, interceptorConfig);
/*    */     }
/*    */     catch (IllegalAccessException e)
/*    */     {
/* 86 */       throw new ConfigurationException("IllegalAccessException while attempting to instantiate an instance of Interceptor class [" + className + "].", e, interceptorConfig);
/*    */     }
/*    */     catch (Exception e)
/*    */     {
/* 91 */       throw new ConfigurationException("Caught Exception while registering Interceptor class " + className, e, interceptorConfig);
/*    */     }
/*    */     catch (NoClassDefFoundError e) {
/*    */     }
/* 95 */     throw new ConfigurationException("Could not load class " + className + ". Perhaps it exists but certain dependencies are not available?", e, interceptorConfig);
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.impl.StrutsObjectFactory
 * JD-Core Version:    0.6.0
 */