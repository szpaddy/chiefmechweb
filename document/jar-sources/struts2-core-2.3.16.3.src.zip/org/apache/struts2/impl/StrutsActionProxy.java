/*    */ package org.apache.struts2.impl;
/*    */ 
/*    */ import com.opensymphony.xwork2.ActionContext;
/*    */ import com.opensymphony.xwork2.ActionInvocation;
/*    */ import com.opensymphony.xwork2.DefaultActionProxy;
/*    */ import com.opensymphony.xwork2.util.LocalizedTextUtil;
/*    */ import java.util.Locale;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import org.apache.struts2.ServletActionContext;
/*    */ 
/*    */ public class StrutsActionProxy extends DefaultActionProxy
/*    */ {
/*    */   private static final long serialVersionUID = -2434901249671934080L;
/*    */ 
/*    */   public StrutsActionProxy(ActionInvocation inv, String namespace, String actionName, String methodName, boolean executeResult, boolean cleanupContext)
/*    */   {
/* 40 */     super(inv, namespace, actionName, methodName, executeResult, cleanupContext);
/*    */   }
/*    */ 
/*    */   public String execute() throws Exception {
/* 44 */     ActionContext previous = ActionContext.getContext();
/* 45 */     ActionContext.setContext(this.invocation.getInvocationContext());
/*    */     try
/*    */     {
/* 54 */       String str = this.invocation.invoke();
/*    */       return str;
/*    */     }
/*    */     finally
/*    */     {
/* 56 */       if (this.cleanupContext)
/* 57 */         ActionContext.setContext(previous); 
/* 57 */     }throw localObject;
/*    */   }
/*    */ 
/*    */   protected void prepare()
/*    */   {
/* 63 */     super.prepare();
/*    */   }
/*    */ 
/*    */   protected String getErrorMessage()
/*    */   {
/* 68 */     if ((this.namespace != null) && (this.namespace.trim().length() > 0)) {
/* 69 */       String contextPath = ServletActionContext.getRequest().getContextPath();
/* 70 */       return LocalizedTextUtil.findDefaultText("struts.exception.missing-package-action.with-context", Locale.getDefault(), new String[] { this.namespace, this.actionName, contextPath });
/*    */     }
/*    */ 
/* 76 */     return super.getErrorMessage();
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.impl.StrutsActionProxy
 * JD-Core Version:    0.6.0
 */