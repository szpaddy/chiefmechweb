/*    */ package org.apache.struts2;
/*    */ 
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ 
/*    */ public class RequestUtils
/*    */ {
/*    */   public static String getServletPath(HttpServletRequest request)
/*    */   {
/* 40 */     String servletPath = request.getServletPath();
/*    */ 
/* 42 */     String requestUri = request.getRequestURI();
/*    */ 
/* 44 */     if ((requestUri != null) && (servletPath != null) && (!requestUri.endsWith(servletPath))) {
/* 45 */       int pos = requestUri.indexOf(servletPath);
/* 46 */       if (pos > -1) {
/* 47 */         servletPath = requestUri.substring(requestUri.indexOf(servletPath));
/*    */       }
/*    */     }
/*    */ 
/* 51 */     if ((null != servletPath) && (!"".equals(servletPath))) {
/* 52 */       return servletPath;
/*    */     }
/*    */ 
/* 55 */     int startIndex = request.getContextPath().equals("") ? 0 : request.getContextPath().length();
/* 56 */     int endIndex = request.getPathInfo() == null ? requestUri.length() : requestUri.lastIndexOf(request.getPathInfo());
/*    */ 
/* 58 */     if (startIndex > endIndex) {
/* 59 */       endIndex = startIndex;
/*    */     }
/*    */ 
/* 62 */     return requestUri.substring(startIndex, endIndex);
/*    */   }
/*    */ 
/*    */   public static String getUri(HttpServletRequest request)
/*    */   {
/* 73 */     String uri = (String)request.getAttribute("javax.servlet.include.servlet_path");
/*    */ 
/* 75 */     if (uri != null) {
/* 76 */       return uri;
/*    */     }
/*    */ 
/* 79 */     uri = getServletPath(request);
/* 80 */     if ((uri != null) && (!"".equals(uri))) {
/* 81 */       return uri;
/*    */     }
/*    */ 
/* 84 */     uri = request.getRequestURI();
/* 85 */     return uri.substring(request.getContextPath().length());
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.RequestUtils
 * JD-Core Version:    0.6.0
 */