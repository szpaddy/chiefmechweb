/*     */ package org.apache.struts2;
/*     */ 
/*     */ import com.opensymphony.xwork2.ActionContext;
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import java.util.Map;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.servlet.jsp.PageContext;
/*     */ import org.apache.struts2.dispatcher.mapper.ActionMapping;
/*     */ 
/*     */ public class ServletActionContext extends ActionContext
/*     */   implements StrutsStatics
/*     */ {
/*     */   private static final long serialVersionUID = -666854718275106687L;
/*     */   public static final String STRUTS_VALUESTACK_KEY = "struts.valueStack";
/*     */   public static final String ACTION_MAPPING = "struts.actionMapping";
/*     */ 
/*     */   private ServletActionContext(Map context)
/*     */   {
/*  51 */     super(context);
/*     */   }
/*     */ 
/*     */   public static ActionContext getActionContext(HttpServletRequest req)
/*     */   {
/*  61 */     ValueStack vs = getValueStack(req);
/*  62 */     if (vs != null) {
/*  63 */       return new ActionContext(vs.getContext());
/*     */     }
/*  65 */     return null;
/*     */   }
/*     */ 
/*     */   public static ValueStack getValueStack(HttpServletRequest req)
/*     */   {
/*  76 */     return (ValueStack)req.getAttribute("struts.valueStack");
/*     */   }
/*     */ 
/*     */   public static ActionMapping getActionMapping()
/*     */   {
/*  85 */     return (ActionMapping)ActionContext.getContext().get("struts.actionMapping");
/*     */   }
/*     */ 
/*     */   public static PageContext getPageContext()
/*     */   {
/*  94 */     return (PageContext)ActionContext.getContext().get("com.opensymphony.xwork2.dispatcher.PageContext");
/*     */   }
/*     */ 
/*     */   public static void setRequest(HttpServletRequest request)
/*     */   {
/* 103 */     ActionContext.getContext().put("com.opensymphony.xwork2.dispatcher.HttpServletRequest", request);
/*     */   }
/*     */ 
/*     */   public static HttpServletRequest getRequest()
/*     */   {
/* 112 */     return (HttpServletRequest)ActionContext.getContext().get("com.opensymphony.xwork2.dispatcher.HttpServletRequest");
/*     */   }
/*     */ 
/*     */   public static void setResponse(HttpServletResponse response)
/*     */   {
/* 121 */     ActionContext.getContext().put("com.opensymphony.xwork2.dispatcher.HttpServletResponse", response);
/*     */   }
/*     */ 
/*     */   public static HttpServletResponse getResponse()
/*     */   {
/* 130 */     return (HttpServletResponse)ActionContext.getContext().get("com.opensymphony.xwork2.dispatcher.HttpServletResponse");
/*     */   }
/*     */ 
/*     */   public static ServletContext getServletContext()
/*     */   {
/* 139 */     return (ServletContext)ActionContext.getContext().get("com.opensymphony.xwork2.dispatcher.ServletContext");
/*     */   }
/*     */ 
/*     */   public static void setServletContext(ServletContext servletContext)
/*     */   {
/* 148 */     ActionContext.getContext().put("com.opensymphony.xwork2.dispatcher.ServletContext", servletContext);
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\struts2-core-2.3.16.3.jar
 * Qualified Name:     org.apache.struts2.ServletActionContext
 * JD-Core Version:    0.6.0
 */