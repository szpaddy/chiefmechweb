/*    */ package org.springframework.http;
/*    */ 
/*    */ public class InvalidMediaTypeException extends IllegalArgumentException
/*    */ {
/*    */   private String mediaType;
/*    */ 
/*    */   public InvalidMediaTypeException(String mediaType, String msg)
/*    */   {
/* 38 */     super("Invalid media type \"" + mediaType + "\": " + msg);
/* 39 */     this.mediaType = mediaType;
/*    */   }
/*    */ 
/*    */   public String getMediaType()
/*    */   {
/* 48 */     return this.mediaType;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.http.InvalidMediaTypeException
 * JD-Core Version:    0.6.0
 */