/*     */ package org.springframework.http;
/*     */ 
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.UnsupportedCharsetException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.BitSet;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.TreeSet;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.LinkedCaseInsensitiveMap;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.util.comparator.CompoundComparator;
/*     */ 
/*     */ public class MediaType
/*     */   implements Comparable<MediaType>
/*     */ {
/*     */   public static final MediaType ALL;
/*     */   public static final String ALL_VALUE = "*/*";
/*     */   public static final MediaType APPLICATION_ATOM_XML;
/*     */   public static final String APPLICATION_ATOM_XML_VALUE = "application/atom+xml";
/*     */   public static final MediaType APPLICATION_FORM_URLENCODED;
/*     */   public static final String APPLICATION_FORM_URLENCODED_VALUE = "application/x-www-form-urlencoded";
/*     */   public static final MediaType APPLICATION_JSON;
/*     */   public static final String APPLICATION_JSON_VALUE = "application/json";
/*     */   public static final MediaType APPLICATION_OCTET_STREAM;
/*     */   public static final String APPLICATION_OCTET_STREAM_VALUE = "application/octet-stream";
/*     */   public static final MediaType APPLICATION_XHTML_XML;
/*     */   public static final String APPLICATION_XHTML_XML_VALUE = "application/xhtml+xml";
/*     */   public static final MediaType APPLICATION_XML;
/*     */   public static final String APPLICATION_XML_VALUE = "application/xml";
/*     */   public static final MediaType IMAGE_GIF;
/*     */   public static final String IMAGE_GIF_VALUE = "image/gif";
/*     */   public static final MediaType IMAGE_JPEG;
/*     */   public static final String IMAGE_JPEG_VALUE = "image/jpeg";
/*     */   public static final MediaType IMAGE_PNG;
/*     */   public static final String IMAGE_PNG_VALUE = "image/png";
/*     */   public static final MediaType MULTIPART_FORM_DATA;
/*     */   public static final String MULTIPART_FORM_DATA_VALUE = "multipart/form-data";
/*     */   public static final MediaType TEXT_HTML;
/*     */   public static final String TEXT_HTML_VALUE = "text/html";
/*     */   public static final MediaType TEXT_PLAIN;
/*     */   public static final String TEXT_PLAIN_VALUE = "text/plain";
/*     */   public static final MediaType TEXT_XML;
/*     */   public static final String TEXT_XML_VALUE = "text/xml";
/*     */   private static final BitSet TOKEN;
/*     */   private static final String WILDCARD_TYPE = "*";
/*     */   private static final String PARAM_QUALITY_FACTOR = "q";
/*     */   private static final String PARAM_CHARSET = "charset";
/*     */   private final String type;
/*     */   private final String subtype;
/*     */   private final Map<String, String> parameters;
/*     */   public static final Comparator<MediaType> SPECIFICITY_COMPARATOR;
/*     */   public static final Comparator<MediaType> QUALITY_VALUE_COMPARATOR;
/*     */ 
/*     */   public MediaType(String type)
/*     */   {
/* 269 */     this(type, "*");
/*     */   }
/*     */ 
/*     */   public MediaType(String type, String subtype)
/*     */   {
/* 280 */     this(type, subtype, Collections.emptyMap());
/*     */   }
/*     */ 
/*     */   public MediaType(String type, String subtype, Charset charSet)
/*     */   {
/* 291 */     this(type, subtype, Collections.singletonMap("charset", charSet.name()));
/*     */   }
/*     */ 
/*     */   public MediaType(String type, String subtype, double qualityValue)
/*     */   {
/* 303 */     this(type, subtype, Collections.singletonMap("q", Double.toString(qualityValue)));
/*     */   }
/*     */ 
/*     */   public MediaType(MediaType other, Map<String, String> parameters)
/*     */   {
/* 314 */     this(other.getType(), other.getSubtype(), parameters);
/*     */   }
/*     */ 
/*     */   public MediaType(String type, String subtype, Map<String, String> parameters)
/*     */   {
/* 325 */     Assert.hasLength(type, "type must not be empty");
/* 326 */     Assert.hasLength(subtype, "subtype must not be empty");
/* 327 */     checkToken(type);
/* 328 */     checkToken(subtype);
/* 329 */     this.type = type.toLowerCase(Locale.ENGLISH);
/* 330 */     this.subtype = subtype.toLowerCase(Locale.ENGLISH);
/* 331 */     if (!CollectionUtils.isEmpty(parameters)) {
/* 332 */       Map m = new LinkedCaseInsensitiveMap(parameters.size(), Locale.ENGLISH);
/* 333 */       for (Map.Entry entry : parameters.entrySet()) {
/* 334 */         String attribute = (String)entry.getKey();
/* 335 */         String value = (String)entry.getValue();
/* 336 */         checkParameters(attribute, value);
/* 337 */         m.put(attribute, value);
/*     */       }
/* 339 */       this.parameters = Collections.unmodifiableMap(m);
/*     */     }
/*     */     else {
/* 342 */       this.parameters = Collections.emptyMap();
/*     */     }
/*     */   }
/*     */ 
/*     */   private void checkToken(String token)
/*     */   {
/* 352 */     for (int i = 0; i < token.length(); i++) {
/* 353 */       char ch = token.charAt(i);
/* 354 */       if (!TOKEN.get(ch))
/* 355 */         throw new IllegalArgumentException("Invalid token character '" + ch + "' in token \"" + token + "\"");
/*     */     }
/*     */   }
/*     */ 
/*     */   private void checkParameters(String attribute, String value)
/*     */   {
/* 361 */     Assert.hasLength(attribute, "parameter attribute must not be empty");
/* 362 */     Assert.hasLength(value, "parameter value must not be empty");
/* 363 */     checkToken(attribute);
/* 364 */     if ("q".equals(attribute)) {
/* 365 */       value = unquote(value);
/* 366 */       double d = Double.parseDouble(value);
/* 367 */       Assert.isTrue((d >= 0.0D) && (d <= 1.0D), "Invalid quality value \"" + value + "\": should be between 0.0 and 1.0");
/*     */     }
/* 370 */     else if ("charset".equals(attribute)) {
/* 371 */       value = unquote(value);
/* 372 */       Charset.forName(value);
/*     */     }
/* 374 */     else if (!isQuotedString(value)) {
/* 375 */       checkToken(value);
/*     */     }
/*     */   }
/*     */ 
/*     */   private boolean isQuotedString(String s) {
/* 380 */     if (s.length() < 2) {
/* 381 */       return false;
/*     */     }
/*     */ 
/* 384 */     return ((s.startsWith("\"")) && (s.endsWith("\""))) || ((s.startsWith("'")) && (s.endsWith("'")));
/*     */   }
/*     */ 
/*     */   private String unquote(String s)
/*     */   {
/* 389 */     if (s == null) {
/* 390 */       return null;
/*     */     }
/* 392 */     return isQuotedString(s) ? s.substring(1, s.length() - 1) : s;
/*     */   }
/*     */ 
/*     */   public String getType()
/*     */   {
/* 399 */     return this.type;
/*     */   }
/*     */ 
/*     */   public boolean isWildcardType()
/*     */   {
/* 406 */     return "*".equals(this.type);
/*     */   }
/*     */ 
/*     */   public String getSubtype()
/*     */   {
/* 413 */     return this.subtype;
/*     */   }
/*     */ 
/*     */   public boolean isWildcardSubtype()
/*     */   {
/* 422 */     return ("*".equals(this.subtype)) || (this.subtype.startsWith("*+"));
/*     */   }
/*     */ 
/*     */   public boolean isConcrete()
/*     */   {
/* 431 */     return (!isWildcardType()) && (!isWildcardSubtype());
/*     */   }
/*     */ 
/*     */   public Charset getCharSet()
/*     */   {
/* 439 */     String charSet = getParameter("charset");
/* 440 */     return charSet != null ? Charset.forName(unquote(charSet)) : null;
/*     */   }
/*     */ 
/*     */   public double getQualityValue()
/*     */   {
/* 449 */     String qualityFactory = getParameter("q");
/* 450 */     return qualityFactory != null ? Double.parseDouble(unquote(qualityFactory)) : 1.0D;
/*     */   }
/*     */ 
/*     */   public String getParameter(String name)
/*     */   {
/* 459 */     return (String)this.parameters.get(name);
/*     */   }
/*     */ 
/*     */   public Map<String, String> getParameters()
/*     */   {
/* 467 */     return this.parameters;
/*     */   }
/*     */ 
/*     */   public boolean includes(MediaType other)
/*     */   {
/* 478 */     if (other == null) {
/* 479 */       return false;
/*     */     }
/* 481 */     if (isWildcardType())
/*     */     {
/* 483 */       return true;
/*     */     }
/* 485 */     if (this.type.equals(other.type)) {
/* 486 */       if (this.subtype.equals(other.subtype)) {
/* 487 */         return true;
/*     */       }
/* 489 */       if (isWildcardSubtype())
/*     */       {
/* 491 */         int thisPlusIdx = this.subtype.indexOf('+');
/* 492 */         if (thisPlusIdx == -1) {
/* 493 */           return true;
/*     */         }
/*     */ 
/* 497 */         int otherPlusIdx = other.subtype.indexOf('+');
/* 498 */         if (otherPlusIdx != -1) {
/* 499 */           String thisSubtypeNoSuffix = this.subtype.substring(0, thisPlusIdx);
/* 500 */           String thisSubtypeSuffix = this.subtype.substring(thisPlusIdx + 1);
/* 501 */           String otherSubtypeSuffix = other.subtype.substring(otherPlusIdx + 1);
/* 502 */           if ((thisSubtypeSuffix.equals(otherSubtypeSuffix)) && ("*".equals(thisSubtypeNoSuffix))) {
/* 503 */             return true;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 509 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean isCompatibleWith(MediaType other)
/*     */   {
/* 520 */     if (other == null) {
/* 521 */       return false;
/*     */     }
/* 523 */     if ((isWildcardType()) || (other.isWildcardType())) {
/* 524 */       return true;
/*     */     }
/* 526 */     if (this.type.equals(other.type)) {
/* 527 */       if (this.subtype.equals(other.subtype)) {
/* 528 */         return true;
/*     */       }
/*     */ 
/* 531 */       if ((isWildcardSubtype()) || (other.isWildcardSubtype()))
/*     */       {
/* 533 */         int thisPlusIdx = this.subtype.indexOf('+');
/* 534 */         int otherPlusIdx = other.subtype.indexOf('+');
/*     */ 
/* 536 */         if ((thisPlusIdx == -1) && (otherPlusIdx == -1)) {
/* 537 */           return true;
/*     */         }
/* 539 */         if ((thisPlusIdx != -1) && (otherPlusIdx != -1)) {
/* 540 */           String thisSubtypeNoSuffix = this.subtype.substring(0, thisPlusIdx);
/* 541 */           String otherSubtypeNoSuffix = other.subtype.substring(0, otherPlusIdx);
/*     */ 
/* 543 */           String thisSubtypeSuffix = this.subtype.substring(thisPlusIdx + 1);
/* 544 */           String otherSubtypeSuffix = other.subtype.substring(otherPlusIdx + 1);
/*     */ 
/* 546 */           if ((thisSubtypeSuffix.equals(otherSubtypeSuffix)) && (("*".equals(thisSubtypeNoSuffix)) || ("*".equals(otherSubtypeNoSuffix))))
/*     */           {
/* 548 */             return true;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 553 */     return false;
/*     */   }
/*     */ 
/*     */   public MediaType copyQualityValue(MediaType mediaType)
/*     */   {
/* 561 */     if (!mediaType.parameters.containsKey("q")) {
/* 562 */       return this;
/*     */     }
/* 564 */     Map params = new LinkedHashMap(this.parameters);
/* 565 */     params.put("q", mediaType.parameters.get("q"));
/* 566 */     return new MediaType(this, params);
/*     */   }
/*     */ 
/*     */   public MediaType removeQualityValue()
/*     */   {
/* 574 */     if (!this.parameters.containsKey("q")) {
/* 575 */       return this;
/*     */     }
/* 577 */     Map params = new LinkedHashMap(this.parameters);
/* 578 */     params.remove("q");
/* 579 */     return new MediaType(this, params);
/*     */   }
/*     */ 
/*     */   public int compareTo(MediaType other)
/*     */   {
/* 588 */     int comp = this.type.compareToIgnoreCase(other.type);
/* 589 */     if (comp != 0) {
/* 590 */       return comp;
/*     */     }
/* 592 */     comp = this.subtype.compareToIgnoreCase(other.subtype);
/* 593 */     if (comp != 0) {
/* 594 */       return comp;
/*     */     }
/* 596 */     comp = this.parameters.size() - other.parameters.size();
/* 597 */     if (comp != 0) {
/* 598 */       return comp;
/*     */     }
/* 600 */     TreeSet thisAttributes = new TreeSet(String.CASE_INSENSITIVE_ORDER);
/* 601 */     thisAttributes.addAll(this.parameters.keySet());
/* 602 */     TreeSet otherAttributes = new TreeSet(String.CASE_INSENSITIVE_ORDER);
/* 603 */     otherAttributes.addAll(other.parameters.keySet());
/* 604 */     Iterator thisAttributesIterator = thisAttributes.iterator();
/* 605 */     Iterator otherAttributesIterator = otherAttributes.iterator();
/* 606 */     while (thisAttributesIterator.hasNext()) {
/* 607 */       String thisAttribute = (String)thisAttributesIterator.next();
/* 608 */       String otherAttribute = (String)otherAttributesIterator.next();
/* 609 */       comp = thisAttribute.compareToIgnoreCase(otherAttribute);
/* 610 */       if (comp != 0) {
/* 611 */         return comp;
/*     */       }
/* 613 */       String thisValue = (String)this.parameters.get(thisAttribute);
/* 614 */       String otherValue = (String)other.parameters.get(otherAttribute);
/* 615 */       if (otherValue == null) {
/* 616 */         otherValue = "";
/*     */       }
/* 618 */       comp = thisValue.compareTo(otherValue);
/* 619 */       if (comp != 0) {
/* 620 */         return comp;
/*     */       }
/*     */     }
/* 623 */     return 0;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object other)
/*     */   {
/* 628 */     if (this == other) {
/* 629 */       return true;
/*     */     }
/* 631 */     if (!(other instanceof MediaType)) {
/* 632 */       return false;
/*     */     }
/* 634 */     MediaType otherType = (MediaType)other;
/* 635 */     return (this.type.equalsIgnoreCase(otherType.type)) && (this.subtype.equalsIgnoreCase(otherType.subtype)) && (this.parameters.equals(otherType.parameters));
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 641 */     int result = this.type.hashCode();
/* 642 */     result = 31 * result + this.subtype.hashCode();
/* 643 */     result = 31 * result + this.parameters.hashCode();
/* 644 */     return result;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 649 */     StringBuilder builder = new StringBuilder();
/* 650 */     appendTo(builder);
/* 651 */     return builder.toString();
/*     */   }
/*     */ 
/*     */   private void appendTo(StringBuilder builder) {
/* 655 */     builder.append(this.type);
/* 656 */     builder.append('/');
/* 657 */     builder.append(this.subtype);
/* 658 */     appendTo(this.parameters, builder);
/*     */   }
/*     */ 
/*     */   private void appendTo(Map<String, String> map, StringBuilder builder) {
/* 662 */     for (Map.Entry entry : map.entrySet()) {
/* 663 */       builder.append(';');
/* 664 */       builder.append((String)entry.getKey());
/* 665 */       builder.append('=');
/* 666 */       builder.append((String)entry.getValue());
/*     */     }
/*     */   }
/*     */ 
/*     */   public static MediaType valueOf(String value)
/*     */   {
/* 678 */     return parseMediaType(value);
/*     */   }
/*     */ 
/*     */   public static MediaType parseMediaType(String mediaType)
/*     */   {
/* 688 */     Assert.hasLength(mediaType, "'mediaType' must not be empty");
/* 689 */     String[] parts = StringUtils.tokenizeToStringArray(mediaType, ";");
/*     */ 
/* 691 */     String fullType = parts[0].trim();
/*     */ 
/* 693 */     if ("*".equals(fullType)) {
/* 694 */       fullType = "*/*";
/*     */     }
/* 696 */     int subIndex = fullType.indexOf('/');
/* 697 */     if (subIndex == -1) {
/* 698 */       throw new InvalidMediaTypeException(mediaType, "does not contain '/'");
/*     */     }
/* 700 */     if (subIndex == fullType.length() - 1) {
/* 701 */       throw new InvalidMediaTypeException(mediaType, "does not contain subtype after '/'");
/*     */     }
/* 703 */     String type = fullType.substring(0, subIndex);
/* 704 */     String subtype = fullType.substring(subIndex + 1, fullType.length());
/* 705 */     if (("*".equals(type)) && (!"*".equals(subtype))) {
/* 706 */       throw new InvalidMediaTypeException(mediaType, "wildcard type is legal only in '*/*' (all media types)");
/*     */     }
/*     */ 
/* 709 */     Map parameters = null;
/* 710 */     if (parts.length > 1) {
/* 711 */       parameters = new LinkedHashMap(parts.length - 1);
/* 712 */       for (int i = 1; i < parts.length; i++) {
/* 713 */         String parameter = parts[i];
/* 714 */         int eqIndex = parameter.indexOf('=');
/* 715 */         if (eqIndex != -1) {
/* 716 */           String attribute = parameter.substring(0, eqIndex);
/* 717 */           String value = parameter.substring(eqIndex + 1, parameter.length());
/* 718 */           parameters.put(attribute, value);
/*     */         }
/*     */       }
/*     */     }
/*     */     try
/*     */     {
/* 724 */       return new MediaType(type, subtype, parameters);
/*     */     }
/*     */     catch (UnsupportedCharsetException ex) {
/* 727 */       throw new InvalidMediaTypeException(mediaType, "unsupported charset '" + ex.getCharsetName() + "'");
/*     */     } catch (IllegalArgumentException ex) {
/*     */     }
/* 730 */     throw new InvalidMediaTypeException(mediaType, ex.getMessage());
/*     */   }
/*     */ 
/*     */   public static List<MediaType> parseMediaTypes(String mediaTypes)
/*     */   {
/* 743 */     if (!StringUtils.hasLength(mediaTypes)) {
/* 744 */       return Collections.emptyList();
/*     */     }
/* 746 */     String[] tokens = mediaTypes.split(",\\s*");
/* 747 */     List result = new ArrayList(tokens.length);
/* 748 */     for (String token : tokens) {
/* 749 */       result.add(parseMediaType(token));
/*     */     }
/* 751 */     return result;
/*     */   }
/*     */ 
/*     */   public static String toString(Collection<MediaType> mediaTypes)
/*     */   {
/* 762 */     StringBuilder builder = new StringBuilder();
/* 763 */     for (Iterator iterator = mediaTypes.iterator(); iterator.hasNext(); ) {
/* 764 */       MediaType mediaType = (MediaType)iterator.next();
/* 765 */       mediaType.appendTo(builder);
/* 766 */       if (iterator.hasNext()) {
/* 767 */         builder.append(", ");
/*     */       }
/*     */     }
/* 770 */     return builder.toString();
/*     */   }
/*     */ 
/*     */   public static void sortBySpecificity(List<MediaType> mediaTypes)
/*     */   {
/* 800 */     Assert.notNull(mediaTypes, "'mediaTypes' must not be null");
/* 801 */     if (mediaTypes.size() > 1)
/* 802 */       Collections.sort(mediaTypes, SPECIFICITY_COMPARATOR);
/*     */   }
/*     */ 
/*     */   public static void sortByQualityValue(List<MediaType> mediaTypes)
/*     */   {
/* 827 */     Assert.notNull(mediaTypes, "'mediaTypes' must not be null");
/* 828 */     if (mediaTypes.size() > 1)
/* 829 */       Collections.sort(mediaTypes, QUALITY_VALUE_COMPARATOR);
/*     */   }
/*     */ 
/*     */   public static void sortBySpecificityAndQuality(List<MediaType> mediaTypes)
/*     */   {
/* 840 */     Assert.notNull(mediaTypes, "'mediaTypes' must not be null");
/* 841 */     if (mediaTypes.size() > 1)
/* 842 */       Collections.sort(mediaTypes, new CompoundComparator(new Comparator[] { SPECIFICITY_COMPARATOR, QUALITY_VALUE_COMPARATOR }));
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/* 213 */     BitSet ctl = new BitSet(128);
/* 214 */     for (int i = 0; i <= 31; i++) {
/* 215 */       ctl.set(i);
/*     */     }
/* 217 */     ctl.set(127);
/*     */ 
/* 219 */     BitSet separators = new BitSet(128);
/* 220 */     separators.set(40);
/* 221 */     separators.set(41);
/* 222 */     separators.set(60);
/* 223 */     separators.set(62);
/* 224 */     separators.set(64);
/* 225 */     separators.set(44);
/* 226 */     separators.set(59);
/* 227 */     separators.set(58);
/* 228 */     separators.set(92);
/* 229 */     separators.set(34);
/* 230 */     separators.set(47);
/* 231 */     separators.set(91);
/* 232 */     separators.set(93);
/* 233 */     separators.set(63);
/* 234 */     separators.set(61);
/* 235 */     separators.set(123);
/* 236 */     separators.set(125);
/* 237 */     separators.set(32);
/* 238 */     separators.set(9);
/*     */ 
/* 240 */     TOKEN = new BitSet(128);
/* 241 */     TOKEN.set(0, 128);
/* 242 */     TOKEN.andNot(ctl);
/* 243 */     TOKEN.andNot(separators);
/*     */ 
/* 245 */     ALL = valueOf("*/*");
/* 246 */     APPLICATION_ATOM_XML = valueOf("application/atom+xml");
/* 247 */     APPLICATION_FORM_URLENCODED = valueOf("application/x-www-form-urlencoded");
/* 248 */     APPLICATION_JSON = valueOf("application/json");
/* 249 */     APPLICATION_OCTET_STREAM = valueOf("application/octet-stream");
/* 250 */     APPLICATION_XHTML_XML = valueOf("application/xhtml+xml");
/* 251 */     APPLICATION_XML = valueOf("application/xml");
/* 252 */     IMAGE_GIF = valueOf("image/gif");
/* 253 */     IMAGE_JPEG = valueOf("image/jpeg");
/* 254 */     IMAGE_PNG = valueOf("image/png");
/* 255 */     MULTIPART_FORM_DATA = valueOf("multipart/form-data");
/* 256 */     TEXT_HTML = valueOf("text/html");
/* 257 */     TEXT_PLAIN = valueOf("text/plain");
/* 258 */     TEXT_XML = valueOf("text/xml");
/*     */ 
/* 851 */     SPECIFICITY_COMPARATOR = new Comparator()
/*     */     {
/*     */       public int compare(MediaType mediaType1, MediaType mediaType2) {
/* 854 */         if ((mediaType1.isWildcardType()) && (!mediaType2.isWildcardType())) {
/* 855 */           return 1;
/*     */         }
/* 857 */         if ((mediaType2.isWildcardType()) && (!mediaType1.isWildcardType())) {
/* 858 */           return -1;
/*     */         }
/* 860 */         if (!mediaType1.getType().equals(mediaType2.getType())) {
/* 861 */           return 0;
/*     */         }
/*     */ 
/* 864 */         if ((mediaType1.isWildcardSubtype()) && (!mediaType2.isWildcardSubtype())) {
/* 865 */           return 1;
/*     */         }
/* 867 */         if ((mediaType2.isWildcardSubtype()) && (!mediaType1.isWildcardSubtype())) {
/* 868 */           return -1;
/*     */         }
/* 870 */         if (!mediaType1.getSubtype().equals(mediaType2.getSubtype())) {
/* 871 */           return 0;
/*     */         }
/*     */ 
/* 874 */         double quality1 = mediaType1.getQualityValue();
/* 875 */         double quality2 = mediaType2.getQualityValue();
/* 876 */         int qualityComparison = Double.compare(quality2, quality1);
/* 877 */         if (qualityComparison != 0) {
/* 878 */           return qualityComparison;
/*     */         }
/*     */ 
/* 881 */         int paramsSize1 = mediaType1.parameters.size();
/* 882 */         int paramsSize2 = mediaType2.parameters.size();
/* 883 */         return paramsSize2 == paramsSize1 ? 0 : paramsSize2 < paramsSize1 ? -1 : 1;
/*     */       }
/*     */     };
/* 894 */     QUALITY_VALUE_COMPARATOR = new Comparator()
/*     */     {
/*     */       public int compare(MediaType mediaType1, MediaType mediaType2) {
/* 897 */         double quality1 = mediaType1.getQualityValue();
/* 898 */         double quality2 = mediaType2.getQualityValue();
/* 899 */         int qualityComparison = Double.compare(quality2, quality1);
/* 900 */         if (qualityComparison != 0) {
/* 901 */           return qualityComparison;
/*     */         }
/* 903 */         if ((mediaType1.isWildcardType()) && (!mediaType2.isWildcardType())) {
/* 904 */           return 1;
/*     */         }
/* 906 */         if ((mediaType2.isWildcardType()) && (!mediaType1.isWildcardType())) {
/* 907 */           return -1;
/*     */         }
/* 909 */         if (!mediaType1.getType().equals(mediaType2.getType())) {
/* 910 */           return 0;
/*     */         }
/*     */ 
/* 913 */         if ((mediaType1.isWildcardSubtype()) && (!mediaType2.isWildcardSubtype())) {
/* 914 */           return 1;
/*     */         }
/* 916 */         if ((mediaType2.isWildcardSubtype()) && (!mediaType1.isWildcardSubtype())) {
/* 917 */           return -1;
/*     */         }
/* 919 */         if (!mediaType1.getSubtype().equals(mediaType2.getSubtype())) {
/* 920 */           return 0;
/*     */         }
/*     */ 
/* 923 */         int paramsSize1 = mediaType1.parameters.size();
/* 924 */         int paramsSize2 = mediaType2.parameters.size();
/* 925 */         return paramsSize2 == paramsSize1 ? 0 : paramsSize2 < paramsSize1 ? -1 : 1;
/*     */       }
/*     */     };
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.http.MediaType
 * JD-Core Version:    0.6.0
 */