/*    */ package org.springframework.http;
/*    */ 
/*    */ public enum HttpMethod
/*    */ {
/* 29 */   GET, POST, HEAD, OPTIONS, PUT, PATCH, DELETE, TRACE;
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.http.HttpMethod
 * JD-Core Version:    0.6.0
 */