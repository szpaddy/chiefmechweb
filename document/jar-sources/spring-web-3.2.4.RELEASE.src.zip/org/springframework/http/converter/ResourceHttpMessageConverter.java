/*     */ package org.springframework.http.converter;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import javax.activation.FileTypeMap;
/*     */ import javax.activation.MimetypesFileTypeMap;
/*     */ import org.springframework.core.io.ByteArrayResource;
/*     */ import org.springframework.core.io.ClassPathResource;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.http.HttpInputMessage;
/*     */ import org.springframework.http.HttpOutputMessage;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StreamUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class ResourceHttpMessageConverter extends AbstractHttpMessageConverter<Resource>
/*     */ {
/*  47 */   private static final boolean jafPresent = ClassUtils.isPresent("javax.activation.FileTypeMap", ResourceHttpMessageConverter.class.getClassLoader());
/*     */ 
/*     */   public ResourceHttpMessageConverter()
/*     */   {
/*  52 */     super(MediaType.ALL);
/*     */   }
/*     */ 
/*     */   protected boolean supports(Class<?> clazz)
/*     */   {
/*  58 */     return Resource.class.isAssignableFrom(clazz);
/*     */   }
/*     */ 
/*     */   protected Resource readInternal(Class<? extends Resource> clazz, HttpInputMessage inputMessage)
/*     */     throws IOException, HttpMessageNotReadableException
/*     */   {
/*  65 */     byte[] body = StreamUtils.copyToByteArray(inputMessage.getBody());
/*  66 */     return new ByteArrayResource(body);
/*     */   }
/*     */ 
/*     */   protected MediaType getDefaultContentType(Resource resource)
/*     */   {
/*  71 */     if (jafPresent) {
/*  72 */       return ActivationMediaTypeFactory.getMediaType(resource);
/*     */     }
/*     */ 
/*  75 */     return MediaType.APPLICATION_OCTET_STREAM;
/*     */   }
/*     */ 
/*     */   protected Long getContentLength(Resource resource, MediaType contentType)
/*     */     throws IOException
/*     */   {
/*  81 */     return Long.valueOf(resource.contentLength());
/*     */   }
/*     */ 
/*     */   protected void writeInternal(Resource resource, HttpOutputMessage outputMessage)
/*     */     throws IOException, HttpMessageNotWritableException
/*     */   {
/*  88 */     InputStream in = resource.getInputStream();
/*     */     try {
/*  90 */       StreamUtils.copy(in, outputMessage.getBody());
/*     */     }
/*     */     finally {
/*     */       try {
/*  94 */         in.close();
/*     */       }
/*     */       catch (IOException ex) {
/*     */       }
/*     */     }
/*  99 */     outputMessage.getBody().flush();
/*     */   }
/*     */ 
/*     */   private static class ActivationMediaTypeFactory
/*     */   {
/* 111 */     private static final FileTypeMap fileTypeMap = loadFileTypeMapFromContextSupportModule();
/*     */ 
/*     */     private static FileTypeMap loadFileTypeMapFromContextSupportModule()
/*     */     {
/* 116 */       Resource mappingLocation = new ClassPathResource("org/springframework/mail/javamail/mime.types");
/* 117 */       if (mappingLocation.exists()) {
/* 118 */         InputStream inputStream = null;
/*     */         try {
/* 120 */           inputStream = mappingLocation.getInputStream();
/* 121 */           MimetypesFileTypeMap localMimetypesFileTypeMap = new MimetypesFileTypeMap(inputStream);
/*     */           return localMimetypesFileTypeMap;
/*     */         }
/*     */         catch (IOException ex)
/*     */         {
/*     */         }
/*     */         finally
/*     */         {
/* 127 */           if (inputStream != null) {
/*     */             try {
/* 129 */               inputStream.close();
/*     */             }
/*     */             catch (IOException ex)
/*     */             {
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/* 137 */       return FileTypeMap.getDefaultFileTypeMap();
/*     */     }
/*     */ 
/*     */     public static MediaType getMediaType(Resource resource) {
/* 141 */       String mediaType = fileTypeMap.getContentType(resource.getFilename());
/* 142 */       return StringUtils.hasText(mediaType) ? MediaType.parseMediaType(mediaType) : null;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.http.converter.ResourceHttpMessageConverter
 * JD-Core Version:    0.6.0
 */