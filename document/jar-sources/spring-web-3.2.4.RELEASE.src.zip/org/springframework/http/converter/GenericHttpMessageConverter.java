package org.springframework.http.converter;

import java.io.IOException;
import java.lang.reflect.Type;
import org.springframework.http.HttpInputMessage;
import org.springframework.http.MediaType;

public abstract interface GenericHttpMessageConverter<T> extends HttpMessageConverter<T>
{
  public abstract boolean canRead(Type paramType, Class<?> paramClass, MediaType paramMediaType);

  public abstract T read(Type paramType, Class<?> paramClass, HttpInputMessage paramHttpInputMessage)
    throws IOException, HttpMessageNotReadableException;
}

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.http.converter.GenericHttpMessageConverter
 * JD-Core Version:    0.6.0
 */