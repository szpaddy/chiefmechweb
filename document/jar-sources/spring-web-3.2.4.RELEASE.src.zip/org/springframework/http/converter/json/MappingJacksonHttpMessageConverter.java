/*     */ package org.springframework.http.converter.json;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Type;
/*     */ import java.nio.charset.Charset;
/*     */ import org.codehaus.jackson.JsonEncoding;
/*     */ import org.codehaus.jackson.JsonFactory;
/*     */ import org.codehaus.jackson.JsonGenerator;
/*     */ import org.codehaus.jackson.JsonProcessingException;
/*     */ import org.codehaus.jackson.map.ObjectMapper;
/*     */ import org.codehaus.jackson.map.SerializationConfig;
/*     */ import org.codehaus.jackson.map.SerializationConfig.Feature;
/*     */ import org.codehaus.jackson.map.type.TypeFactory;
/*     */ import org.codehaus.jackson.type.JavaType;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpInputMessage;
/*     */ import org.springframework.http.HttpOutputMessage;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.converter.AbstractHttpMessageConverter;
/*     */ import org.springframework.http.converter.GenericHttpMessageConverter;
/*     */ import org.springframework.http.converter.HttpMessageNotReadableException;
/*     */ import org.springframework.http.converter.HttpMessageNotWritableException;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public class MappingJacksonHttpMessageConverter extends AbstractHttpMessageConverter<Object>
/*     */   implements GenericHttpMessageConverter<Object>
/*     */ {
/*  57 */   public static final Charset DEFAULT_CHARSET = Charset.forName("UTF-8");
/*     */ 
/*  60 */   private ObjectMapper objectMapper = new ObjectMapper();
/*     */   private String jsonPrefix;
/*     */   private Boolean prettyPrint;
/*     */ 
/*     */   public MappingJacksonHttpMessageConverter()
/*     */   {
/*  71 */     super(new MediaType[] { new MediaType("application", "json", DEFAULT_CHARSET), new MediaType("application", "*+json", DEFAULT_CHARSET) });
/*     */   }
/*     */ 
/*     */   public void setObjectMapper(ObjectMapper objectMapper)
/*     */   {
/*  84 */     Assert.notNull(objectMapper, "ObjectMapper must not be null");
/*  85 */     this.objectMapper = objectMapper;
/*  86 */     configurePrettyPrint();
/*     */   }
/*     */ 
/*     */   private void configurePrettyPrint() {
/*  90 */     if (this.prettyPrint != null)
/*  91 */       this.objectMapper.configure(SerializationConfig.Feature.INDENT_OUTPUT, this.prettyPrint.booleanValue());
/*     */   }
/*     */ 
/*     */   public ObjectMapper getObjectMapper()
/*     */   {
/*  99 */     return this.objectMapper;
/*     */   }
/*     */ 
/*     */   public void setJsonPrefix(String jsonPrefix)
/*     */   {
/* 108 */     this.jsonPrefix = jsonPrefix;
/*     */   }
/*     */ 
/*     */   public void setPrefixJson(boolean prefixJson)
/*     */   {
/* 120 */     this.jsonPrefix = (prefixJson ? "{} && " : null);
/*     */   }
/*     */ 
/*     */   public void setPrettyPrint(boolean prettyPrint)
/*     */   {
/* 134 */     this.prettyPrint = Boolean.valueOf(prettyPrint);
/* 135 */     configurePrettyPrint();
/*     */   }
/*     */ 
/*     */   public boolean canRead(Class<?> clazz, MediaType mediaType)
/*     */   {
/* 140 */     return canRead(clazz, null, mediaType);
/*     */   }
/*     */ 
/*     */   public boolean canRead(Type type, Class<?> contextClass, MediaType mediaType) {
/* 144 */     JavaType javaType = getJavaType(type, contextClass);
/* 145 */     return (this.objectMapper.canDeserialize(javaType)) && (canRead(mediaType));
/*     */   }
/*     */ 
/*     */   public boolean canWrite(Class<?> clazz, MediaType mediaType)
/*     */   {
/* 150 */     return (this.objectMapper.canSerialize(clazz)) && (canWrite(mediaType));
/*     */   }
/*     */ 
/*     */   protected boolean supports(Class<?> clazz)
/*     */   {
/* 156 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   protected Object readInternal(Class<?> clazz, HttpInputMessage inputMessage)
/*     */     throws IOException, HttpMessageNotReadableException
/*     */   {
/* 163 */     JavaType javaType = getJavaType(clazz, null);
/* 164 */     return readJavaType(javaType, inputMessage);
/*     */   }
/*     */ 
/*     */   public Object read(Type type, Class<?> contextClass, HttpInputMessage inputMessage)
/*     */     throws IOException, HttpMessageNotReadableException
/*     */   {
/* 170 */     JavaType javaType = getJavaType(type, contextClass);
/* 171 */     return readJavaType(javaType, inputMessage);
/*     */   }
/*     */ 
/*     */   private Object readJavaType(JavaType javaType, HttpInputMessage inputMessage) {
/*     */     try {
/* 176 */       return this.objectMapper.readValue(inputMessage.getBody(), javaType);
/*     */     } catch (IOException ex) {
/*     */     }
/* 179 */     throw new HttpMessageNotReadableException("Could not read JSON: " + ex.getMessage(), ex);
/*     */   }
/*     */ 
/*     */   protected void writeInternal(Object object, HttpOutputMessage outputMessage)
/*     */     throws IOException, HttpMessageNotWritableException
/*     */   {
/* 187 */     JsonEncoding encoding = getJsonEncoding(outputMessage.getHeaders().getContentType());
/* 188 */     JsonGenerator jsonGenerator = this.objectMapper.getJsonFactory().createJsonGenerator(outputMessage.getBody(), encoding);
/*     */ 
/* 193 */     if (this.objectMapper.getSerializationConfig().isEnabled(SerializationConfig.Feature.INDENT_OUTPUT)) {
/* 194 */       jsonGenerator.useDefaultPrettyPrinter();
/*     */     }
/*     */     try
/*     */     {
/* 198 */       if (this.jsonPrefix != null) {
/* 199 */         jsonGenerator.writeRaw("{} && ");
/*     */       }
/* 201 */       this.objectMapper.writeValue(jsonGenerator, object);
/*     */     }
/*     */     catch (JsonProcessingException ex) {
/* 204 */       throw new HttpMessageNotWritableException("Could not write JSON: " + ex.getMessage(), ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected JavaType getJavaType(Type type, Class<?> contextClass)
/*     */   {
/* 229 */     return contextClass != null ? TypeFactory.type(type, TypeFactory.type(contextClass)) : TypeFactory.type(type);
/*     */   }
/*     */ 
/*     */   protected JsonEncoding getJsonEncoding(MediaType contentType)
/*     */   {
/* 240 */     if ((contentType != null) && (contentType.getCharSet() != null)) {
/* 241 */       Charset charset = contentType.getCharSet();
/* 242 */       for (JsonEncoding encoding : JsonEncoding.values()) {
/* 243 */         if (charset.name().equals(encoding.getJavaName())) {
/* 244 */           return encoding;
/*     */         }
/*     */       }
/*     */     }
/* 248 */     return JsonEncoding.UTF8;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.http.converter.json.MappingJacksonHttpMessageConverter
 * JD-Core Version:    0.6.0
 */