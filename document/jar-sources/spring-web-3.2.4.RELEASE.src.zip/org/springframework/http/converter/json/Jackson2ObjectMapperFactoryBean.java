/*     */ package org.springframework.http.converter.json;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonGenerator.Feature;
/*     */ import com.fasterxml.jackson.core.JsonParser.Feature;
/*     */ import com.fasterxml.jackson.databind.AnnotationIntrospector;
/*     */ import com.fasterxml.jackson.databind.DeserializationFeature;
/*     */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*     */ import com.fasterxml.jackson.databind.JsonSerializer;
/*     */ import com.fasterxml.jackson.databind.MapperFeature;
/*     */ import com.fasterxml.jackson.databind.ObjectMapper;
/*     */ import com.fasterxml.jackson.databind.SerializationFeature;
/*     */ import com.fasterxml.jackson.databind.module.SimpleModule;
/*     */ import java.text.DateFormat;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.springframework.beans.FatalBeanException;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public class Jackson2ObjectMapperFactoryBean
/*     */   implements FactoryBean<ObjectMapper>, InitializingBean
/*     */ {
/*     */   private ObjectMapper objectMapper;
/* 105 */   private Map<Object, Boolean> features = new HashMap();
/*     */   private DateFormat dateFormat;
/*     */   private AnnotationIntrospector annotationIntrospector;
/* 111 */   private final Map<Class<?>, JsonSerializer<?>> serializers = new LinkedHashMap();
/*     */ 
/* 113 */   private final Map<Class<?>, JsonDeserializer<?>> deserializers = new LinkedHashMap();
/*     */ 
/*     */   public void setObjectMapper(ObjectMapper objectMapper)
/*     */   {
/* 121 */     this.objectMapper = objectMapper;
/*     */   }
/*     */ 
/*     */   public void setDateFormat(DateFormat dateFormat)
/*     */   {
/* 131 */     this.dateFormat = dateFormat;
/*     */   }
/*     */ 
/*     */   public void setSimpleDateFormat(String format)
/*     */   {
/* 141 */     this.dateFormat = new SimpleDateFormat(format);
/*     */   }
/*     */ 
/*     */   public void setAnnotationIntrospector(AnnotationIntrospector annotationIntrospector)
/*     */   {
/* 149 */     this.annotationIntrospector = annotationIntrospector;
/*     */   }
/*     */ 
/*     */   public void setSerializers(JsonSerializer<?>[] serializers)
/*     */   {
/* 159 */     if (serializers != null)
/* 160 */       for (JsonSerializer serializer : serializers) {
/* 161 */         Class handledType = serializer.handledType();
/* 162 */         Assert.isTrue((handledType != null) && (handledType != Object.class), "Unknown handled type in " + serializer.getClass().getName());
/*     */ 
/* 164 */         this.serializers.put(serializer.handledType(), serializer);
/*     */       }
/*     */   }
/*     */ 
/*     */   public void setSerializersByType(Map<Class<?>, JsonSerializer<?>> serializers)
/*     */   {
/* 174 */     if (serializers != null)
/* 175 */       this.serializers.putAll(serializers);
/*     */   }
/*     */ 
/*     */   public void setDeserializersByType(Map<Class<?>, JsonDeserializer<?>> deserializers)
/*     */   {
/* 183 */     if (deserializers != null)
/* 184 */       this.deserializers.putAll(deserializers);
/*     */   }
/*     */ 
/*     */   public void setAutoDetectFields(boolean autoDetectFields)
/*     */   {
/* 192 */     this.features.put(MapperFeature.AUTO_DETECT_FIELDS, Boolean.valueOf(autoDetectFields));
/*     */   }
/*     */ 
/*     */   public void setAutoDetectGettersSetters(boolean autoDetectGettersSetters)
/*     */   {
/* 200 */     this.features.put(MapperFeature.AUTO_DETECT_GETTERS, Boolean.valueOf(autoDetectGettersSetters));
/* 201 */     this.features.put(MapperFeature.AUTO_DETECT_SETTERS, Boolean.valueOf(autoDetectGettersSetters));
/*     */   }
/*     */ 
/*     */   public void setFailOnEmptyBeans(boolean failOnEmptyBeans)
/*     */   {
/* 208 */     this.features.put(SerializationFeature.FAIL_ON_EMPTY_BEANS, Boolean.valueOf(failOnEmptyBeans));
/*     */   }
/*     */ 
/*     */   public void setIndentOutput(boolean indentOutput)
/*     */   {
/* 215 */     this.features.put(SerializationFeature.INDENT_OUTPUT, Boolean.valueOf(indentOutput));
/*     */   }
/*     */ 
/*     */   public void setFeaturesToEnable(Object[] featuresToEnable)
/*     */   {
/* 227 */     if (featuresToEnable != null)
/* 228 */       for (Object feature : featuresToEnable)
/* 229 */         this.features.put(feature, Boolean.TRUE);
/*     */   }
/*     */ 
/*     */   public void setFeaturesToDisable(Object[] featuresToDisable)
/*     */   {
/* 243 */     if (featuresToDisable != null)
/* 244 */       for (Object feature : featuresToDisable)
/* 245 */         this.features.put(feature, Boolean.FALSE);
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */   {
/* 252 */     if (this.objectMapper == null) {
/* 253 */       this.objectMapper = new ObjectMapper();
/*     */     }
/*     */ 
/* 256 */     if (this.dateFormat != null) {
/* 257 */       this.objectMapper.setDateFormat(this.dateFormat);
/*     */     }
/*     */ 
/* 260 */     if ((!this.serializers.isEmpty()) || (!this.deserializers.isEmpty())) {
/* 261 */       SimpleModule module = new SimpleModule();
/* 262 */       addSerializers(module);
/* 263 */       addDeserializers(module);
/* 264 */       this.objectMapper.registerModule(module);
/*     */     }
/*     */ 
/* 267 */     if (this.annotationIntrospector != null) {
/* 268 */       this.objectMapper.setAnnotationIntrospector(this.annotationIntrospector);
/*     */     }
/*     */ 
/* 271 */     for (Iterator i$ = this.features.keySet().iterator(); i$.hasNext(); ) { Object feature = i$.next();
/* 272 */       configureFeature(feature, ((Boolean)this.features.get(feature)).booleanValue());
/*     */     }
/*     */   }
/*     */ 
/*     */   private <T> void addSerializers(SimpleModule module)
/*     */   {
/* 278 */     for (Class type : this.serializers.keySet())
/* 279 */       module.addSerializer(type, (JsonSerializer)this.serializers.get(type));
/*     */   }
/*     */ 
/*     */   private <T> void addDeserializers(SimpleModule module)
/*     */   {
/* 285 */     for (Class type : this.deserializers.keySet())
/* 286 */       module.addDeserializer(type, (JsonDeserializer)this.deserializers.get(type));
/*     */   }
/*     */ 
/*     */   private void configureFeature(Object feature, boolean enabled)
/*     */   {
/* 291 */     if ((feature instanceof JsonParser.Feature)) {
/* 292 */       this.objectMapper.configure((JsonParser.Feature)feature, enabled);
/*     */     }
/* 294 */     else if ((feature instanceof JsonGenerator.Feature)) {
/* 295 */       this.objectMapper.configure((JsonGenerator.Feature)feature, enabled);
/*     */     }
/* 297 */     else if ((feature instanceof SerializationFeature)) {
/* 298 */       this.objectMapper.configure((SerializationFeature)feature, enabled);
/*     */     }
/* 300 */     else if ((feature instanceof DeserializationFeature)) {
/* 301 */       this.objectMapper.configure((DeserializationFeature)feature, enabled);
/*     */     }
/* 303 */     else if ((feature instanceof MapperFeature)) {
/* 304 */       this.objectMapper.configure((MapperFeature)feature, enabled);
/*     */     }
/*     */     else
/* 307 */       throw new FatalBeanException("Unknown feature class " + feature.getClass().getName());
/*     */   }
/*     */ 
/*     */   public ObjectMapper getObject()
/*     */   {
/* 316 */     return this.objectMapper;
/*     */   }
/*     */ 
/*     */   public Class<?> getObjectType() {
/* 320 */     return ObjectMapper.class;
/*     */   }
/*     */ 
/*     */   public boolean isSingleton() {
/* 324 */     return true;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.http.converter.json.Jackson2ObjectMapperFactoryBean
 * JD-Core Version:    0.6.0
 */