/*     */ package org.springframework.http.converter.xml;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.ParameterizedType;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.SortedSet;
/*     */ import java.util.TreeSet;
/*     */ import javax.xml.bind.JAXBElement;
/*     */ import javax.xml.bind.JAXBException;
/*     */ import javax.xml.bind.UnmarshalException;
/*     */ import javax.xml.bind.Unmarshaller;
/*     */ import javax.xml.bind.annotation.XmlRootElement;
/*     */ import javax.xml.bind.annotation.XmlType;
/*     */ import javax.xml.stream.XMLInputFactory;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.XMLStreamReader;
/*     */ import javax.xml.transform.Result;
/*     */ import javax.xml.transform.Source;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpInputMessage;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.converter.GenericHttpMessageConverter;
/*     */ import org.springframework.http.converter.HttpMessageConversionException;
/*     */ import org.springframework.http.converter.HttpMessageNotReadableException;
/*     */ 
/*     */ public class Jaxb2CollectionHttpMessageConverter<T extends Collection> extends AbstractJaxb2HttpMessageConverter<T>
/*     */   implements GenericHttpMessageConverter<T>
/*     */ {
/*  60 */   private final XMLInputFactory inputFactory = createXmlInputFactory();
/*     */ 
/*     */   public boolean canRead(Class<?> clazz, MediaType mediaType)
/*     */   {
/*  68 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean canRead(Type type, Class<?> contextClass, MediaType mediaType)
/*     */   {
/*  78 */     if (!(type instanceof ParameterizedType)) {
/*  79 */       return false;
/*     */     }
/*  81 */     ParameterizedType parameterizedType = (ParameterizedType)type;
/*  82 */     if (!(parameterizedType.getRawType() instanceof Class)) {
/*  83 */       return false;
/*     */     }
/*  85 */     Class rawType = (Class)parameterizedType.getRawType();
/*  86 */     if (!Collection.class.isAssignableFrom(rawType)) {
/*  87 */       return false;
/*     */     }
/*  89 */     if (parameterizedType.getActualTypeArguments().length != 1) {
/*  90 */       return false;
/*     */     }
/*  92 */     Type typeArgument = parameterizedType.getActualTypeArguments()[0];
/*  93 */     if (!(typeArgument instanceof Class)) {
/*  94 */       return false;
/*     */     }
/*  96 */     Class typeArgumentClass = (Class)typeArgument;
/*  97 */     return ((typeArgumentClass.isAnnotationPresent(XmlRootElement.class)) || (typeArgumentClass.isAnnotationPresent(XmlType.class))) && (canRead(mediaType));
/*     */   }
/*     */ 
/*     */   public boolean canWrite(Class<?> clazz, MediaType mediaType)
/*     */   {
/* 107 */     return false;
/*     */   }
/*     */ 
/*     */   protected boolean supports(Class<?> clazz)
/*     */   {
/* 113 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   protected T readFromSource(Class<? extends T> clazz, HttpHeaders headers, Source source)
/*     */     throws IOException
/*     */   {
/* 119 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public T read(Type type, Class<?> contextClass, HttpInputMessage inputMessage)
/*     */     throws IOException, HttpMessageNotReadableException
/*     */   {
/* 125 */     ParameterizedType parameterizedType = (ParameterizedType)type;
/* 126 */     Collection result = createCollection((Class)parameterizedType.getRawType());
/* 127 */     Class elementClass = (Class)parameterizedType.getActualTypeArguments()[0];
/*     */     try
/*     */     {
/* 130 */       Unmarshaller unmarshaller = createUnmarshaller(elementClass);
/* 131 */       XMLStreamReader streamReader = this.inputFactory.createXMLStreamReader(inputMessage.getBody());
/* 132 */       int event = moveToFirstChildOfRootElement(streamReader);
/*     */ 
/* 134 */       while (event != 8) {
/* 135 */         if (elementClass.isAnnotationPresent(XmlRootElement.class)) {
/* 136 */           result.add(unmarshaller.unmarshal(streamReader));
/*     */         }
/* 138 */         else if (elementClass.isAnnotationPresent(XmlType.class)) {
/* 139 */           result.add(unmarshaller.unmarshal(streamReader, elementClass).getValue());
/*     */         }
/*     */         else
/*     */         {
/* 143 */           throw new HttpMessageConversionException("Could not unmarshal to [" + elementClass + "]");
/*     */         }
/* 145 */         event = moveToNextElement(streamReader);
/*     */       }
/* 147 */       return result;
/*     */     }
/*     */     catch (UnmarshalException ex) {
/* 150 */       throw new HttpMessageNotReadableException("Could not unmarshal to [" + elementClass + "]: " + ex.getMessage(), ex);
/*     */     }
/*     */     catch (JAXBException ex) {
/* 153 */       throw new HttpMessageConversionException("Could not instantiate JAXBContext: " + ex.getMessage(), ex);
/*     */     } catch (XMLStreamException ex) {
/*     */     }
/* 156 */     throw new HttpMessageConversionException(ex.getMessage(), ex);
/*     */   }
/*     */ 
/*     */   protected T createCollection(Class<?> collectionClass)
/*     */   {
/* 169 */     if (!collectionClass.isInterface()) {
/*     */       try {
/* 171 */         return (Collection)collectionClass.newInstance();
/*     */       }
/*     */       catch (Exception ex) {
/* 174 */         throw new IllegalArgumentException("Could not instantiate collection class [" + collectionClass.getName() + "]: " + ex.getMessage());
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 179 */     if (List.class.equals(collectionClass)) {
/* 180 */       return new ArrayList();
/*     */     }
/* 182 */     if (SortedSet.class.equals(collectionClass)) {
/* 183 */       return new TreeSet();
/*     */     }
/*     */ 
/* 186 */     return new LinkedHashSet();
/*     */   }
/*     */ 
/*     */   private int moveToFirstChildOfRootElement(XMLStreamReader streamReader)
/*     */     throws XMLStreamException
/*     */   {
/* 192 */     int event = streamReader.next();
/* 193 */     while (event != 1) {
/* 194 */       event = streamReader.next();
/*     */     }
/*     */ 
/* 198 */     event = streamReader.next();
/* 199 */     while ((event != 1) && (event != 8)) {
/* 200 */       event = streamReader.next();
/*     */     }
/* 202 */     return event;
/*     */   }
/*     */ 
/*     */   private int moveToNextElement(XMLStreamReader streamReader) throws XMLStreamException {
/* 206 */     int event = streamReader.getEventType();
/* 207 */     while ((event != 1) && (event != 8)) {
/* 208 */       event = streamReader.next();
/*     */     }
/* 210 */     return event;
/*     */   }
/*     */ 
/*     */   protected void writeToResult(T t, HttpHeaders headers, Result result) throws IOException
/*     */   {
/* 215 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   protected XMLInputFactory createXmlInputFactory()
/*     */   {
/* 227 */     XMLInputFactory inputFactory = XMLInputFactory.newInstance();
/* 228 */     inputFactory.setProperty("javax.xml.stream.isReplacingEntityReferences", Boolean.valueOf(false));
/* 229 */     return inputFactory;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.http.converter.xml.Jaxb2CollectionHttpMessageConverter
 * JD-Core Version:    0.6.0
 */