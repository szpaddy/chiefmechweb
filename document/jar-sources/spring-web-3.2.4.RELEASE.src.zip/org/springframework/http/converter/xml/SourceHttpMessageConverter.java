/*     */ package org.springframework.http.converter.xml;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import javax.xml.transform.Result;
/*     */ import javax.xml.transform.Source;
/*     */ import javax.xml.transform.TransformerException;
/*     */ import javax.xml.transform.dom.DOMResult;
/*     */ import javax.xml.transform.dom.DOMSource;
/*     */ import javax.xml.transform.sax.SAXSource;
/*     */ import javax.xml.transform.stream.StreamResult;
/*     */ import javax.xml.transform.stream.StreamSource;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.converter.HttpMessageConversionException;
/*     */ import org.springframework.http.converter.HttpMessageNotReadableException;
/*     */ import org.springframework.http.converter.HttpMessageNotWritableException;
/*     */ import org.xml.sax.InputSource;
/*     */ 
/*     */ public class SourceHttpMessageConverter<T extends Source> extends AbstractXmlHttpMessageConverter<T>
/*     */ {
/*     */   public boolean supports(Class<?> clazz)
/*     */   {
/*  51 */     return (DOMSource.class.equals(clazz)) || (SAXSource.class.equals(clazz)) || (StreamSource.class.equals(clazz)) || (Source.class.equals(clazz));
/*     */   }
/*     */ 
/*     */   protected T readFromSource(Class clazz, HttpHeaders headers, Source source)
/*     */     throws IOException
/*     */   {
/*     */     try
/*     */     {
/*  59 */       if (DOMSource.class.equals(clazz)) {
/*  60 */         DOMResult domResult = new DOMResult();
/*  61 */         transform(source, domResult);
/*  62 */         return new DOMSource(domResult.getNode());
/*     */       }
/*  64 */       if (SAXSource.class.equals(clazz)) {
/*  65 */         ByteArrayInputStream bis = transformToByteArrayInputStream(source);
/*  66 */         return new SAXSource(new InputSource(bis));
/*     */       }
/*  68 */       if ((StreamSource.class.equals(clazz)) || (Source.class.equals(clazz))) {
/*  69 */         ByteArrayInputStream bis = transformToByteArrayInputStream(source);
/*  70 */         return new StreamSource(bis);
/*     */       }
/*     */ 
/*  73 */       throw new HttpMessageConversionException("Could not read class [" + clazz + "]. Only DOMSource, SAXSource, and StreamSource are supported.");
/*     */     }
/*     */     catch (TransformerException ex)
/*     */     {
/*     */     }
/*  78 */     throw new HttpMessageNotReadableException("Could not transform from [" + source + "] to [" + clazz + "]", ex);
/*     */   }
/*     */ 
/*     */   private ByteArrayInputStream transformToByteArrayInputStream(Source source)
/*     */     throws TransformerException
/*     */   {
/*  84 */     ByteArrayOutputStream bos = new ByteArrayOutputStream();
/*  85 */     transform(source, new StreamResult(bos));
/*  86 */     return new ByteArrayInputStream(bos.toByteArray());
/*     */   }
/*     */ 
/*     */   protected Long getContentLength(T t, MediaType contentType)
/*     */   {
/*  91 */     if ((t instanceof DOMSource)) {
/*     */       try {
/*  93 */         CountingOutputStream os = new CountingOutputStream(null);
/*  94 */         transform(t, new StreamResult(os));
/*  95 */         return Long.valueOf(os.count);
/*     */       }
/*     */       catch (TransformerException ex)
/*     */       {
/*     */       }
/*     */     }
/* 101 */     return null;
/*     */   }
/*     */ 
/*     */   protected void writeToResult(T t, HttpHeaders headers, Result result) throws IOException
/*     */   {
/*     */     try {
/* 107 */       transform(t, result);
/*     */     }
/*     */     catch (TransformerException ex) {
/* 110 */       throw new HttpMessageNotWritableException("Could not transform [" + t + "] to [" + result + "]", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class CountingOutputStream extends OutputStream
/*     */   {
/* 116 */     private long count = 0L;
/*     */ 
/*     */     public void write(int b) throws IOException
/*     */     {
/* 120 */       this.count += 1L;
/*     */     }
/*     */ 
/*     */     public void write(byte[] b) throws IOException
/*     */     {
/* 125 */       this.count += b.length;
/*     */     }
/*     */ 
/*     */     public void write(byte[] b, int off, int len) throws IOException
/*     */     {
/* 130 */       this.count += len;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.http.converter.xml.SourceHttpMessageConverter
 * JD-Core Version:    0.6.0
 */