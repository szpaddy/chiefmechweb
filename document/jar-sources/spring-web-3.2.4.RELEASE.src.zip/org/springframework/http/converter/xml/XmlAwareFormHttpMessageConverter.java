/*    */ package org.springframework.http.converter.xml;
/*    */ 
/*    */ import org.springframework.http.converter.FormHttpMessageConverter;
/*    */ 
/*    */ @Deprecated
/*    */ public class XmlAwareFormHttpMessageConverter extends FormHttpMessageConverter
/*    */ {
/*    */   public XmlAwareFormHttpMessageConverter()
/*    */   {
/* 35 */     addPartConverter(new SourceHttpMessageConverter());
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.http.converter.xml.XmlAwareFormHttpMessageConverter
 * JD-Core Version:    0.6.0
 */