/*     */ package org.springframework.http.converter;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpInputMessage;
/*     */ import org.springframework.http.HttpOutputMessage;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public abstract class AbstractHttpMessageConverter<T>
/*     */   implements HttpMessageConverter<T>
/*     */ {
/*  48 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */ 
/*  50 */   private List<MediaType> supportedMediaTypes = Collections.emptyList();
/*     */ 
/*     */   protected AbstractHttpMessageConverter()
/*     */   {
/*     */   }
/*     */ 
/*     */   protected AbstractHttpMessageConverter(MediaType supportedMediaType)
/*     */   {
/*  65 */     setSupportedMediaTypes(Collections.singletonList(supportedMediaType));
/*     */   }
/*     */ 
/*     */   protected AbstractHttpMessageConverter(MediaType[] supportedMediaTypes)
/*     */   {
/*  73 */     setSupportedMediaTypes(Arrays.asList(supportedMediaTypes));
/*     */   }
/*     */ 
/*     */   public void setSupportedMediaTypes(List<MediaType> supportedMediaTypes)
/*     */   {
/*  81 */     Assert.notEmpty(supportedMediaTypes, "'supportedMediaTypes' must not be empty");
/*  82 */     this.supportedMediaTypes = new ArrayList(supportedMediaTypes);
/*     */   }
/*     */ 
/*     */   public List<MediaType> getSupportedMediaTypes() {
/*  86 */     return Collections.unmodifiableList(this.supportedMediaTypes);
/*     */   }
/*     */ 
/*     */   public boolean canRead(Class<?> clazz, MediaType mediaType)
/*     */   {
/*  96 */     return (supports(clazz)) && (canRead(mediaType));
/*     */   }
/*     */ 
/*     */   protected boolean canRead(MediaType mediaType)
/*     */   {
/* 108 */     if (mediaType == null) {
/* 109 */       return true;
/*     */     }
/* 111 */     for (MediaType supportedMediaType : getSupportedMediaTypes()) {
/* 112 */       if (supportedMediaType.includes(mediaType)) {
/* 113 */         return true;
/*     */       }
/*     */     }
/* 116 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean canWrite(Class<?> clazz, MediaType mediaType)
/*     */   {
/* 125 */     return (supports(clazz)) && (canWrite(mediaType));
/*     */   }
/*     */ 
/*     */   protected boolean canWrite(MediaType mediaType)
/*     */   {
/* 137 */     if ((mediaType == null) || (MediaType.ALL.equals(mediaType))) {
/* 138 */       return true;
/*     */     }
/* 140 */     for (MediaType supportedMediaType : getSupportedMediaTypes()) {
/* 141 */       if (supportedMediaType.isCompatibleWith(mediaType)) {
/* 142 */         return true;
/*     */       }
/*     */     }
/* 145 */     return false;
/*     */   }
/*     */ 
/*     */   public final T read(Class<? extends T> clazz, HttpInputMessage inputMessage)
/*     */     throws IOException
/*     */   {
/* 153 */     return readInternal(clazz, inputMessage);
/*     */   }
/*     */ 
/*     */   public final void write(T t, MediaType contentType, HttpOutputMessage outputMessage)
/*     */     throws IOException, HttpMessageNotWritableException
/*     */   {
/* 164 */     HttpHeaders headers = outputMessage.getHeaders();
/* 165 */     if (headers.getContentType() == null) {
/* 166 */       if ((contentType == null) || (contentType.isWildcardType()) || (contentType.isWildcardSubtype())) {
/* 167 */         contentType = getDefaultContentType(t);
/*     */       }
/* 169 */       if (contentType != null) {
/* 170 */         headers.setContentType(contentType);
/*     */       }
/*     */     }
/* 173 */     if (headers.getContentLength() == -1L) {
/* 174 */       Long contentLength = getContentLength(t, headers.getContentType());
/* 175 */       if (contentLength != null) {
/* 176 */         headers.setContentLength(contentLength.longValue());
/*     */       }
/*     */     }
/* 179 */     writeInternal(t, outputMessage);
/* 180 */     outputMessage.getBody().flush();
/*     */   }
/*     */ 
/*     */   protected MediaType getDefaultContentType(T t)
/*     */     throws IOException
/*     */   {
/* 193 */     List mediaTypes = getSupportedMediaTypes();
/* 194 */     return !mediaTypes.isEmpty() ? (MediaType)mediaTypes.get(0) : null;
/*     */   }
/*     */ 
/*     */   protected Long getContentLength(T t, MediaType contentType)
/*     */     throws IOException
/*     */   {
/* 205 */     return null;
/*     */   }
/*     */ 
/*     */   protected abstract boolean supports(Class<?> paramClass);
/*     */ 
/*     */   protected abstract T readInternal(Class<? extends T> paramClass, HttpInputMessage paramHttpInputMessage)
/*     */     throws IOException, HttpMessageNotReadableException;
/*     */ 
/*     */   protected abstract void writeInternal(T paramT, HttpOutputMessage paramHttpOutputMessage)
/*     */     throws IOException, HttpMessageNotWritableException;
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.http.converter.AbstractHttpMessageConverter
 * JD-Core Version:    0.6.0
 */