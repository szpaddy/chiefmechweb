/*     */ package org.springframework.http.converter;
/*     */ 
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import javax.imageio.IIOImage;
/*     */ import javax.imageio.ImageIO;
/*     */ import javax.imageio.ImageReadParam;
/*     */ import javax.imageio.ImageReader;
/*     */ import javax.imageio.ImageWriteParam;
/*     */ import javax.imageio.ImageWriter;
/*     */ import javax.imageio.stream.FileCacheImageInputStream;
/*     */ import javax.imageio.stream.FileCacheImageOutputStream;
/*     */ import javax.imageio.stream.ImageInputStream;
/*     */ import javax.imageio.stream.ImageOutputStream;
/*     */ import javax.imageio.stream.MemoryCacheImageInputStream;
/*     */ import javax.imageio.stream.MemoryCacheImageOutputStream;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpInputMessage;
/*     */ import org.springframework.http.HttpOutputMessage;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public class BufferedImageHttpMessageConverter
/*     */   implements HttpMessageConverter<BufferedImage>
/*     */ {
/*  65 */   private final List<MediaType> readableMediaTypes = new ArrayList();
/*     */   private MediaType defaultContentType;
/*     */   private File cacheDir;
/*     */ 
/*     */   public BufferedImageHttpMessageConverter()
/*     */   {
/*  73 */     String[] readerMediaTypes = ImageIO.getReaderMIMETypes();
/*  74 */     for (String mediaType : readerMediaTypes) {
/*  75 */       this.readableMediaTypes.add(MediaType.parseMediaType(mediaType));
/*     */     }
/*     */ 
/*  78 */     String[] writerMediaTypes = ImageIO.getWriterMIMETypes();
/*  79 */     if (writerMediaTypes.length > 0)
/*  80 */       this.defaultContentType = MediaType.parseMediaType(writerMediaTypes[0]);
/*     */   }
/*     */ 
/*     */   public void setDefaultContentType(MediaType defaultContentType)
/*     */   {
/*  89 */     Assert.notNull(defaultContentType, "'contentType' must not be null");
/*  90 */     Iterator imageWriters = ImageIO.getImageWritersByMIMEType(defaultContentType.toString());
/*  91 */     if (!imageWriters.hasNext()) {
/*  92 */       throw new IllegalArgumentException("ContentType [" + defaultContentType + "] is not supported by the Java Image I/O API");
/*     */     }
/*     */ 
/*  96 */     this.defaultContentType = defaultContentType;
/*     */   }
/*     */ 
/*     */   public MediaType getDefaultContentType()
/*     */   {
/* 104 */     return this.defaultContentType;
/*     */   }
/*     */ 
/*     */   public void setCacheDir(File cacheDir)
/*     */   {
/* 112 */     Assert.notNull(cacheDir, "'cacheDir' must not be null");
/* 113 */     Assert.isTrue(cacheDir.isDirectory(), "'cacheDir' is not a directory");
/* 114 */     this.cacheDir = cacheDir;
/*     */   }
/*     */ 
/*     */   public boolean canRead(Class<?> clazz, MediaType mediaType)
/*     */   {
/* 119 */     return (BufferedImage.class.equals(clazz)) && (isReadable(mediaType));
/*     */   }
/*     */ 
/*     */   private boolean isReadable(MediaType mediaType) {
/* 123 */     if (mediaType == null) {
/* 124 */       return true;
/*     */     }
/* 126 */     Iterator imageReaders = ImageIO.getImageReadersByMIMEType(mediaType.toString());
/* 127 */     return imageReaders.hasNext();
/*     */   }
/*     */ 
/*     */   public boolean canWrite(Class<?> clazz, MediaType mediaType) {
/* 131 */     return (BufferedImage.class.equals(clazz)) && (isWritable(mediaType));
/*     */   }
/*     */ 
/*     */   private boolean isWritable(MediaType mediaType) {
/* 135 */     if ((mediaType == null) || (MediaType.ALL.equals(mediaType))) {
/* 136 */       return true;
/*     */     }
/* 138 */     Iterator imageWriters = ImageIO.getImageWritersByMIMEType(mediaType.toString());
/* 139 */     return imageWriters.hasNext();
/*     */   }
/*     */ 
/*     */   public List<MediaType> getSupportedMediaTypes() {
/* 143 */     return Collections.unmodifiableList(this.readableMediaTypes);
/*     */   }
/*     */ 
/*     */   public BufferedImage read(Class<? extends BufferedImage> clazz, HttpInputMessage inputMessage)
/*     */     throws IOException, HttpMessageNotReadableException
/*     */   {
/* 149 */     ImageInputStream imageInputStream = null;
/* 150 */     ImageReader imageReader = null;
/*     */     try {
/* 152 */       imageInputStream = createImageInputStream(inputMessage.getBody());
/* 153 */       MediaType contentType = inputMessage.getHeaders().getContentType();
/* 154 */       Iterator imageReaders = ImageIO.getImageReadersByMIMEType(contentType.toString());
/* 155 */       if (imageReaders.hasNext()) {
/* 156 */         imageReader = (ImageReader)imageReaders.next();
/* 157 */         ImageReadParam irp = imageReader.getDefaultReadParam();
/* 158 */         process(irp);
/* 159 */         imageReader.setInput(imageInputStream, true);
/* 160 */         BufferedImage localBufferedImage = imageReader.read(0, irp);
/*     */         return localBufferedImage;
/*     */       }
/* 163 */       throw new HttpMessageNotReadableException("Could not find javax.imageio.ImageReader for Content-Type [" + contentType + "]");
/*     */     }
/*     */     finally
/*     */     {
/* 168 */       if (imageReader != null) {
/* 169 */         imageReader.dispose();
/*     */       }
/* 171 */       if (imageInputStream != null)
/*     */         try {
/* 173 */           imageInputStream.close();
/*     */         } catch (IOException ex) {
/*     */         }
/*     */     }
/* 177 */     throw localObject;
/*     */   }
/*     */ 
/*     */   private ImageInputStream createImageInputStream(InputStream is)
/*     */     throws IOException
/*     */   {
/* 183 */     if (this.cacheDir != null) {
/* 184 */       return new FileCacheImageInputStream(is, this.cacheDir);
/*     */     }
/*     */ 
/* 187 */     return new MemoryCacheImageInputStream(is);
/*     */   }
/*     */ 
/*     */   public void write(BufferedImage image, MediaType contentType, HttpOutputMessage outputMessage)
/*     */     throws IOException, HttpMessageNotWritableException
/*     */   {
/* 194 */     if ((contentType == null) || (contentType.isWildcardType()) || (contentType.isWildcardSubtype())) {
/* 195 */       contentType = getDefaultContentType();
/*     */     }
/* 197 */     Assert.notNull(contentType, "Count not determine Content-Type, set one using the 'defaultContentType' property");
/*     */ 
/* 199 */     outputMessage.getHeaders().setContentType(contentType);
/* 200 */     ImageOutputStream imageOutputStream = null;
/* 201 */     ImageWriter imageWriter = null;
/*     */     try {
/* 203 */       imageOutputStream = createImageOutputStream(outputMessage.getBody());
/* 204 */       Iterator imageWriters = ImageIO.getImageWritersByMIMEType(contentType.toString());
/* 205 */       if (imageWriters.hasNext()) {
/* 206 */         imageWriter = (ImageWriter)imageWriters.next();
/* 207 */         ImageWriteParam iwp = imageWriter.getDefaultWriteParam();
/* 208 */         process(iwp);
/* 209 */         imageWriter.setOutput(imageOutputStream);
/* 210 */         imageWriter.write(null, new IIOImage(image, null, null), iwp);
/*     */       }
/*     */       else {
/* 213 */         throw new HttpMessageNotWritableException("Could not find javax.imageio.ImageWriter for Content-Type [" + contentType + "]");
/*     */       }
/*     */     }
/*     */     finally
/*     */     {
/* 218 */       if (imageWriter != null) {
/* 219 */         imageWriter.dispose();
/*     */       }
/* 221 */       if (imageOutputStream != null)
/*     */         try {
/* 223 */           imageOutputStream.close();
/*     */         }
/*     */         catch (IOException ex)
/*     */         {
/*     */         }
/*     */     }
/*     */   }
/*     */ 
/*     */   private ImageOutputStream createImageOutputStream(OutputStream os) throws IOException
/*     */   {
/* 233 */     if (this.cacheDir != null) {
/* 234 */       return new FileCacheImageOutputStream(os, this.cacheDir);
/*     */     }
/*     */ 
/* 237 */     return new MemoryCacheImageOutputStream(os);
/*     */   }
/*     */ 
/*     */   protected void process(ImageReadParam irp)
/*     */   {
/*     */   }
/*     */ 
/*     */   protected void process(ImageWriteParam iwp)
/*     */   {
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.http.converter.BufferedImageHttpMessageConverter
 * JD-Core Version:    0.6.0
 */