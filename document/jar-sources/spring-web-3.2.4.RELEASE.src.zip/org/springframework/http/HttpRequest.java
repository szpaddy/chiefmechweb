package org.springframework.http;

import java.net.URI;

public abstract interface HttpRequest extends HttpMessage
{
  public abstract HttpMethod getMethod();

  public abstract URI getURI();
}

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.http.HttpRequest
 * JD-Core Version:    0.6.0
 */