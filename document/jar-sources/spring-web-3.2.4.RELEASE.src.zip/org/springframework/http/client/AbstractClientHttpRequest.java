/*    */ package org.springframework.http.client;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStream;
/*    */ import org.springframework.http.HttpHeaders;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ public abstract class AbstractClientHttpRequest
/*    */   implements ClientHttpRequest
/*    */ {
/* 33 */   private final HttpHeaders headers = new HttpHeaders();
/*    */ 
/* 35 */   private boolean executed = false;
/*    */ 
/*    */   public final HttpHeaders getHeaders()
/*    */   {
/* 39 */     return this.executed ? HttpHeaders.readOnlyHttpHeaders(this.headers) : this.headers;
/*    */   }
/*    */ 
/*    */   public final OutputStream getBody() throws IOException {
/* 43 */     checkExecuted();
/* 44 */     return getBodyInternal(this.headers);
/*    */   }
/*    */ 
/*    */   public final ClientHttpResponse execute() throws IOException {
/* 48 */     checkExecuted();
/* 49 */     ClientHttpResponse result = executeInternal(this.headers);
/* 50 */     this.executed = true;
/* 51 */     return result;
/*    */   }
/*    */ 
/*    */   private void checkExecuted() {
/* 55 */     Assert.state(!this.executed, "ClientHttpRequest already executed");
/*    */   }
/*    */ 
/*    */   protected abstract OutputStream getBodyInternal(HttpHeaders paramHttpHeaders)
/*    */     throws IOException;
/*    */ 
/*    */   protected abstract ClientHttpResponse executeInternal(HttpHeaders paramHttpHeaders)
/*    */     throws IOException;
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.http.client.AbstractClientHttpRequest
 * JD-Core Version:    0.6.0
 */