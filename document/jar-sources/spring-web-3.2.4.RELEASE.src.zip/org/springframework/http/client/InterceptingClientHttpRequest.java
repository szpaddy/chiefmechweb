/*    */ package org.springframework.http.client;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.net.URI;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import org.springframework.http.HttpHeaders;
/*    */ import org.springframework.http.HttpMethod;
/*    */ import org.springframework.http.HttpRequest;
/*    */ import org.springframework.util.StreamUtils;
/*    */ 
/*    */ class InterceptingClientHttpRequest extends AbstractBufferingClientHttpRequest
/*    */ {
/*    */   private final ClientHttpRequestFactory requestFactory;
/*    */   private final List<ClientHttpRequestInterceptor> interceptors;
/*    */   private HttpMethod method;
/*    */   private URI uri;
/*    */ 
/*    */   protected InterceptingClientHttpRequest(ClientHttpRequestFactory requestFactory, List<ClientHttpRequestInterceptor> interceptors, URI uri, HttpMethod method)
/*    */   {
/* 49 */     this.requestFactory = requestFactory;
/* 50 */     this.interceptors = interceptors;
/* 51 */     this.method = method;
/* 52 */     this.uri = uri;
/*    */   }
/*    */ 
/*    */   public HttpMethod getMethod() {
/* 56 */     return this.method;
/*    */   }
/*    */ 
/*    */   public URI getURI() {
/* 60 */     return this.uri;
/*    */   }
/*    */ 
/*    */   protected final ClientHttpResponse executeInternal(HttpHeaders headers, byte[] bufferedOutput) throws IOException
/*    */   {
/* 65 */     RequestExecution requestExecution = new RequestExecution(null);
/*    */ 
/* 67 */     return requestExecution.execute(this, bufferedOutput);
/*    */   }
/*    */ 
/*    */   private class RequestExecution implements ClientHttpRequestExecution {
/*    */     private final Iterator<ClientHttpRequestInterceptor> iterator;
/*    */ 
/*    */     private RequestExecution() {
/* 75 */       this.iterator = InterceptingClientHttpRequest.this.interceptors.iterator();
/*    */     }
/*    */ 
/*    */     public ClientHttpResponse execute(HttpRequest request, byte[] body) throws IOException {
/* 79 */       if (this.iterator.hasNext()) {
/* 80 */         ClientHttpRequestInterceptor nextInterceptor = (ClientHttpRequestInterceptor)this.iterator.next();
/* 81 */         return nextInterceptor.intercept(request, body, this);
/*    */       }
/*    */ 
/* 84 */       ClientHttpRequest delegate = InterceptingClientHttpRequest.this.requestFactory.createRequest(request.getURI(), request.getMethod());
/*    */ 
/* 86 */       delegate.getHeaders().putAll(request.getHeaders());
/*    */ 
/* 88 */       if (body.length > 0) {
/* 89 */         StreamUtils.copy(body, delegate.getBody());
/*    */       }
/* 91 */       return delegate.execute();
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.http.client.InterceptingClientHttpRequest
 * JD-Core Version:    0.6.0
 */