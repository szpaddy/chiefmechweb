/*    */ package org.springframework.http.client;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.net.HttpURLConnection;
/*    */ import java.net.URI;
/*    */ import java.net.URISyntaxException;
/*    */ import java.net.URL;
/*    */ import java.util.List;
/*    */ import java.util.Map.Entry;
/*    */ import org.springframework.http.HttpHeaders;
/*    */ import org.springframework.http.HttpMethod;
/*    */ import org.springframework.util.FileCopyUtils;
/*    */ 
/*    */ final class SimpleBufferingClientHttpRequest extends AbstractBufferingClientHttpRequest
/*    */ {
/*    */   private final HttpURLConnection connection;
/*    */   private final boolean outputStreaming;
/*    */ 
/*    */   SimpleBufferingClientHttpRequest(HttpURLConnection connection, boolean outputStreaming)
/*    */   {
/* 46 */     this.connection = connection;
/* 47 */     this.outputStreaming = outputStreaming;
/*    */   }
/*    */ 
/*    */   public HttpMethod getMethod()
/*    */   {
/* 52 */     return HttpMethod.valueOf(this.connection.getRequestMethod());
/*    */   }
/*    */ 
/*    */   public URI getURI() {
/*    */     try {
/* 57 */       return this.connection.getURL().toURI();
/*    */     } catch (URISyntaxException ex) {
/*    */     }
/* 60 */     throw new IllegalStateException("Could not get HttpURLConnection URI: " + ex.getMessage(), ex);
/*    */   }
/*    */ 
/*    */   protected ClientHttpResponse executeInternal(HttpHeaders headers, byte[] bufferedOutput)
/*    */     throws IOException
/*    */   {
/* 66 */     for (Map.Entry entry : headers.entrySet()) {
/* 67 */       headerName = (String)entry.getKey();
/* 68 */       for (String headerValue : (List)entry.getValue())
/* 69 */         this.connection.addRequestProperty(headerName, headerValue);
/*    */     }
/*    */     String headerName;
/* 73 */     if ((this.connection.getDoOutput()) && (this.outputStreaming)) {
/* 74 */       this.connection.setFixedLengthStreamingMode(bufferedOutput.length);
/*    */     }
/* 76 */     this.connection.connect();
/* 77 */     if (this.connection.getDoOutput()) {
/* 78 */       FileCopyUtils.copy(bufferedOutput, this.connection.getOutputStream());
/*    */     }
/*    */ 
/* 81 */     return new SimpleClientHttpResponse(this.connection);
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.http.client.SimpleBufferingClientHttpRequest
 * JD-Core Version:    0.6.0
 */