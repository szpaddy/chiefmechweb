/*     */ package org.springframework.http.client;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.URI;
/*     */ import org.apache.commons.httpclient.HttpClient;
/*     */ import org.apache.commons.httpclient.HttpConnectionManager;
/*     */ import org.apache.commons.httpclient.HttpMethodBase;
/*     */ import org.apache.commons.httpclient.MultiThreadedHttpConnectionManager;
/*     */ import org.apache.commons.httpclient.methods.DeleteMethod;
/*     */ import org.apache.commons.httpclient.methods.GetMethod;
/*     */ import org.apache.commons.httpclient.methods.HeadMethod;
/*     */ import org.apache.commons.httpclient.methods.OptionsMethod;
/*     */ import org.apache.commons.httpclient.methods.PostMethod;
/*     */ import org.apache.commons.httpclient.methods.PutMethod;
/*     */ import org.apache.commons.httpclient.methods.TraceMethod;
/*     */ import org.apache.commons.httpclient.params.HttpConnectionManagerParams;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ @Deprecated
/*     */ public class CommonsClientHttpRequestFactory
/*     */   implements ClientHttpRequestFactory, DisposableBean
/*     */ {
/*     */   private static final int DEFAULT_READ_TIMEOUT_MILLISECONDS = 60000;
/*     */   private HttpClient httpClient;
/*     */ 
/*     */   public CommonsClientHttpRequestFactory()
/*     */   {
/*  63 */     this.httpClient = new HttpClient(new MultiThreadedHttpConnectionManager());
/*  64 */     setReadTimeout(60000);
/*     */   }
/*     */ 
/*     */   public CommonsClientHttpRequestFactory(HttpClient httpClient)
/*     */   {
/*  73 */     Assert.notNull(httpClient, "httpClient must not be null");
/*  74 */     this.httpClient = httpClient;
/*     */   }
/*     */ 
/*     */   public void setHttpClient(HttpClient httpClient)
/*     */   {
/*  82 */     this.httpClient = httpClient;
/*     */   }
/*     */ 
/*     */   public HttpClient getHttpClient()
/*     */   {
/*  89 */     return this.httpClient;
/*     */   }
/*     */ 
/*     */   public void setConnectTimeout(int timeout)
/*     */   {
/*  99 */     Assert.isTrue(timeout >= 0, "Timeout must be a non-negative value");
/* 100 */     this.httpClient.getHttpConnectionManager().getParams().setConnectionTimeout(timeout);
/*     */   }
/*     */ 
/*     */   public void setReadTimeout(int timeout)
/*     */   {
/* 110 */     Assert.isTrue(timeout >= 0, "Timeout must be a non-negative value");
/* 111 */     getHttpClient().getHttpConnectionManager().getParams().setSoTimeout(timeout);
/*     */   }
/*     */ 
/*     */   public ClientHttpRequest createRequest(URI uri, HttpMethod httpMethod) throws IOException
/*     */   {
/* 116 */     HttpMethodBase commonsHttpMethod = createCommonsHttpMethod(httpMethod, uri.toString());
/* 117 */     postProcessCommonsHttpMethod(commonsHttpMethod);
/* 118 */     return new CommonsClientHttpRequest(getHttpClient(), commonsHttpMethod);
/*     */   }
/*     */ 
/*     */   protected HttpMethodBase createCommonsHttpMethod(HttpMethod httpMethod, String uri)
/*     */   {
/* 129 */     switch (1.$SwitchMap$org$springframework$http$HttpMethod[httpMethod.ordinal()]) {
/*     */     case 1:
/* 131 */       return new GetMethod(uri);
/*     */     case 2:
/* 133 */       return new DeleteMethod(uri);
/*     */     case 3:
/* 135 */       return new HeadMethod(uri);
/*     */     case 4:
/* 137 */       return new OptionsMethod(uri);
/*     */     case 5:
/* 139 */       return new PostMethod(uri);
/*     */     case 6:
/* 141 */       return new PutMethod(uri);
/*     */     case 7:
/* 143 */       return new TraceMethod(uri);
/*     */     case 8:
/* 145 */       throw new IllegalArgumentException("HTTP method PATCH not available before Apache HttpComponents HttpClient 4.2");
/*     */     }
/*     */ 
/* 148 */     throw new IllegalArgumentException("Invalid HTTP method: " + httpMethod);
/*     */   }
/*     */ 
/*     */   protected void postProcessCommonsHttpMethod(HttpMethodBase httpMethod)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void destroy()
/*     */   {
/* 166 */     HttpConnectionManager connectionManager = getHttpClient().getHttpConnectionManager();
/* 167 */     if ((connectionManager instanceof MultiThreadedHttpConnectionManager))
/* 168 */       ((MultiThreadedHttpConnectionManager)connectionManager).shutdown();
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.http.client.CommonsClientHttpRequestFactory
 * JD-Core Version:    0.6.0
 */