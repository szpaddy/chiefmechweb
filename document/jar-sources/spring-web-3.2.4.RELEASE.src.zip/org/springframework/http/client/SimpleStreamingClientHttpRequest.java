/*     */ package org.springframework.http.client;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.net.HttpURLConnection;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.net.URL;
/*     */ import java.util.List;
/*     */ import java.util.Map.Entry;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.util.StreamUtils;
/*     */ 
/*     */ final class SimpleStreamingClientHttpRequest extends AbstractClientHttpRequest
/*     */ {
/*     */   private final HttpURLConnection connection;
/*     */   private final int chunkSize;
/*     */   private OutputStream body;
/*     */   private final boolean outputStreaming;
/*     */ 
/*     */   SimpleStreamingClientHttpRequest(HttpURLConnection connection, int chunkSize, boolean outputStreaming)
/*     */   {
/*  52 */     this.connection = connection;
/*  53 */     this.chunkSize = chunkSize;
/*  54 */     this.outputStreaming = outputStreaming;
/*     */   }
/*     */ 
/*     */   public HttpMethod getMethod() {
/*  58 */     return HttpMethod.valueOf(this.connection.getRequestMethod());
/*     */   }
/*     */ 
/*     */   public URI getURI() {
/*     */     try {
/*  63 */       return this.connection.getURL().toURI();
/*     */     } catch (URISyntaxException ex) {
/*     */     }
/*  66 */     throw new IllegalStateException("Could not get HttpURLConnection URI: " + ex.getMessage(), ex);
/*     */   }
/*     */ 
/*     */   protected OutputStream getBodyInternal(HttpHeaders headers)
/*     */     throws IOException
/*     */   {
/*  72 */     if (this.body == null) {
/*  73 */       if (this.outputStreaming) {
/*  74 */         int contentLength = (int)headers.getContentLength();
/*  75 */         if (contentLength >= 0) {
/*  76 */           this.connection.setFixedLengthStreamingMode(contentLength);
/*     */         }
/*     */         else {
/*  79 */           this.connection.setChunkedStreamingMode(this.chunkSize);
/*     */         }
/*     */       }
/*  82 */       writeHeaders(headers);
/*  83 */       this.connection.connect();
/*  84 */       this.body = this.connection.getOutputStream();
/*     */     }
/*  86 */     return StreamUtils.nonClosing(this.body);
/*     */   }
/*     */ 
/*     */   private void writeHeaders(HttpHeaders headers) {
/*  90 */     for (Map.Entry entry : headers.entrySet()) {
/*  91 */       headerName = (String)entry.getKey();
/*  92 */       for (String headerValue : (List)entry.getValue())
/*  93 */         this.connection.addRequestProperty(headerName, headerValue);
/*     */     }
/*     */     String headerName;
/*     */   }
/*     */ 
/*     */   protected ClientHttpResponse executeInternal(HttpHeaders headers) throws IOException {
/*     */     try {
/* 101 */       if (this.body != null) {
/* 102 */         this.body.close();
/*     */       }
/*     */       else {
/* 105 */         writeHeaders(headers);
/* 106 */         this.connection.connect();
/*     */       }
/*     */     }
/*     */     catch (IOException ex)
/*     */     {
/*     */     }
/* 112 */     return new SimpleClientHttpResponse(this.connection);
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.http.client.SimpleStreamingClientHttpRequest
 * JD-Core Version:    0.6.0
 */