/*     */ package org.springframework.http.client;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.URI;
/*     */ import org.apache.http.client.HttpClient;
/*     */ import org.apache.http.client.methods.HttpDelete;
/*     */ import org.apache.http.client.methods.HttpGet;
/*     */ import org.apache.http.client.methods.HttpHead;
/*     */ import org.apache.http.client.methods.HttpOptions;
/*     */ import org.apache.http.client.methods.HttpPatch;
/*     */ import org.apache.http.client.methods.HttpPost;
/*     */ import org.apache.http.client.methods.HttpPut;
/*     */ import org.apache.http.client.methods.HttpTrace;
/*     */ import org.apache.http.client.methods.HttpUriRequest;
/*     */ import org.apache.http.conn.ClientConnectionManager;
/*     */ import org.apache.http.conn.scheme.PlainSocketFactory;
/*     */ import org.apache.http.conn.scheme.Scheme;
/*     */ import org.apache.http.conn.scheme.SchemeRegistry;
/*     */ import org.apache.http.conn.ssl.SSLSocketFactory;
/*     */ import org.apache.http.impl.client.DefaultHttpClient;
/*     */ import org.apache.http.impl.conn.PoolingClientConnectionManager;
/*     */ import org.apache.http.params.HttpParams;
/*     */ import org.apache.http.protocol.HttpContext;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public class HttpComponentsClientHttpRequestFactory
/*     */   implements ClientHttpRequestFactory, DisposableBean
/*     */ {
/*     */   private static final int DEFAULT_MAX_TOTAL_CONNECTIONS = 100;
/*     */   private static final int DEFAULT_MAX_CONNECTIONS_PER_ROUTE = 5;
/*     */   private static final int DEFAULT_READ_TIMEOUT_MILLISECONDS = 60000;
/*     */   private HttpClient httpClient;
/*     */ 
/*     */   public HttpComponentsClientHttpRequestFactory()
/*     */   {
/*  73 */     SchemeRegistry schemeRegistry = new SchemeRegistry();
/*  74 */     schemeRegistry.register(new Scheme("http", 80, PlainSocketFactory.getSocketFactory()));
/*  75 */     schemeRegistry.register(new Scheme("https", 443, SSLSocketFactory.getSocketFactory()));
/*     */ 
/*  77 */     PoolingClientConnectionManager connectionManager = new PoolingClientConnectionManager(schemeRegistry);
/*  78 */     connectionManager.setMaxTotal(100);
/*  79 */     connectionManager.setDefaultMaxPerRoute(5);
/*     */ 
/*  81 */     this.httpClient = new DefaultHttpClient(connectionManager);
/*  82 */     setReadTimeout(60000);
/*     */   }
/*     */ 
/*     */   public HttpComponentsClientHttpRequestFactory(HttpClient httpClient)
/*     */   {
/*  92 */     Assert.notNull(httpClient, "HttpClient must not be null");
/*  93 */     this.httpClient = httpClient;
/*     */   }
/*     */ 
/*     */   public void setHttpClient(HttpClient httpClient)
/*     */   {
/* 101 */     this.httpClient = httpClient;
/*     */   }
/*     */ 
/*     */   public HttpClient getHttpClient()
/*     */   {
/* 108 */     return this.httpClient;
/*     */   }
/*     */ 
/*     */   public void setConnectTimeout(int timeout)
/*     */   {
/* 117 */     Assert.isTrue(timeout >= 0, "Timeout must be a non-negative value");
/* 118 */     getHttpClient().getParams().setIntParameter("http.connection.timeout", timeout);
/*     */   }
/*     */ 
/*     */   public void setReadTimeout(int timeout)
/*     */   {
/* 127 */     Assert.isTrue(timeout >= 0, "Timeout must be a non-negative value");
/* 128 */     getHttpClient().getParams().setIntParameter("http.socket.timeout", timeout);
/*     */   }
/*     */ 
/*     */   public ClientHttpRequest createRequest(URI uri, HttpMethod httpMethod) throws IOException {
/* 132 */     HttpUriRequest httpRequest = createHttpUriRequest(httpMethod, uri);
/* 133 */     postProcessHttpRequest(httpRequest);
/* 134 */     return new HttpComponentsClientHttpRequest(getHttpClient(), httpRequest, createHttpContext(httpMethod, uri));
/*     */   }
/*     */ 
/*     */   protected HttpUriRequest createHttpUriRequest(HttpMethod httpMethod, URI uri)
/*     */   {
/* 144 */     switch (1.$SwitchMap$org$springframework$http$HttpMethod[httpMethod.ordinal()]) {
/*     */     case 1:
/* 146 */       return new HttpGet(uri);
/*     */     case 2:
/* 148 */       return new HttpDelete(uri);
/*     */     case 3:
/* 150 */       return new HttpHead(uri);
/*     */     case 4:
/* 152 */       return new HttpOptions(uri);
/*     */     case 5:
/* 154 */       return new HttpPost(uri);
/*     */     case 6:
/* 156 */       return new HttpPut(uri);
/*     */     case 7:
/* 158 */       return new HttpTrace(uri);
/*     */     case 8:
/* 160 */       return new HttpPatch(uri);
/*     */     }
/* 162 */     throw new IllegalArgumentException("Invalid HTTP method: " + httpMethod);
/*     */   }
/*     */ 
/*     */   protected void postProcessHttpRequest(HttpUriRequest request)
/*     */   {
/*     */   }
/*     */ 
/*     */   protected HttpContext createHttpContext(HttpMethod httpMethod, URI uri)
/*     */   {
/* 183 */     return null;
/*     */   }
/*     */ 
/*     */   public void destroy()
/*     */   {
/* 192 */     getHttpClient().getConnectionManager().shutdown();
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.http.client.HttpComponentsClientHttpRequestFactory
 * JD-Core Version:    0.6.0
 */