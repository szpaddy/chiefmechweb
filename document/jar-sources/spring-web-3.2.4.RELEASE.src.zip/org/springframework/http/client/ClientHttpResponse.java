package org.springframework.http.client;

import java.io.Closeable;
import java.io.IOException;
import org.springframework.http.HttpInputMessage;
import org.springframework.http.HttpStatus;

public abstract interface ClientHttpResponse extends HttpInputMessage, Closeable
{
  public abstract HttpStatus getStatusCode()
    throws IOException;

  public abstract int getRawStatusCode()
    throws IOException;

  public abstract String getStatusText()
    throws IOException;

  public abstract void close();
}

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.http.client.ClientHttpResponse
 * JD-Core Version:    0.6.0
 */