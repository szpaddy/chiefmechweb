/*    */ package org.springframework.http.client.support;
/*    */ 
/*    */ import java.net.URI;
/*    */ import org.springframework.http.HttpHeaders;
/*    */ import org.springframework.http.HttpMethod;
/*    */ import org.springframework.http.HttpRequest;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ public class HttpRequestWrapper
/*    */   implements HttpRequest
/*    */ {
/*    */   private final HttpRequest request;
/*    */ 
/*    */   public HttpRequestWrapper(HttpRequest request)
/*    */   {
/* 44 */     Assert.notNull(request, "'request' must not be null");
/* 45 */     this.request = request;
/*    */   }
/*    */ 
/*    */   public HttpRequest getRequest()
/*    */   {
/* 52 */     return this.request;
/*    */   }
/*    */ 
/*    */   public HttpMethod getMethod()
/*    */   {
/* 59 */     return this.request.getMethod();
/*    */   }
/*    */ 
/*    */   public URI getURI()
/*    */   {
/* 66 */     return this.request.getURI();
/*    */   }
/*    */ 
/*    */   public HttpHeaders getHeaders()
/*    */   {
/* 73 */     return this.request.getHeaders();
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.http.client.support.HttpRequestWrapper
 * JD-Core Version:    0.6.0
 */