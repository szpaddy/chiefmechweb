package org.springframework.http.client;

import java.io.IOException;
import java.net.URI;
import org.springframework.http.HttpMethod;

public abstract interface ClientHttpRequestFactory
{
  public abstract ClientHttpRequest createRequest(URI paramURI, HttpMethod paramHttpMethod)
    throws IOException;
}

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.http.client.ClientHttpRequestFactory
 * JD-Core Version:    0.6.0
 */