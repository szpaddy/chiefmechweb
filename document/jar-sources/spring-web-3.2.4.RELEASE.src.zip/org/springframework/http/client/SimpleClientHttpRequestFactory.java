/*     */ package org.springframework.http.client;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.HttpURLConnection;
/*     */ import java.net.Proxy;
/*     */ import java.net.URI;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public class SimpleClientHttpRequestFactory
/*     */   implements ClientHttpRequestFactory
/*     */ {
/*     */   private static final int DEFAULT_CHUNK_SIZE = 4096;
/*     */   private Proxy proxy;
/*  45 */   private boolean bufferRequestBody = true;
/*     */ 
/*  47 */   private int chunkSize = 4096;
/*     */ 
/*  49 */   private int connectTimeout = -1;
/*     */ 
/*  51 */   private int readTimeout = -1;
/*     */ 
/*  53 */   private boolean outputStreaming = true;
/*     */ 
/*     */   public void setProxy(Proxy proxy)
/*     */   {
/*  60 */     this.proxy = proxy;
/*     */   }
/*     */ 
/*     */   public void setBufferRequestBody(boolean bufferRequestBody)
/*     */   {
/*  75 */     this.bufferRequestBody = bufferRequestBody;
/*     */   }
/*     */ 
/*     */   public void setChunkSize(int chunkSize)
/*     */   {
/*  86 */     this.chunkSize = chunkSize;
/*     */   }
/*     */ 
/*     */   public void setConnectTimeout(int connectTimeout)
/*     */   {
/*  96 */     this.connectTimeout = connectTimeout;
/*     */   }
/*     */ 
/*     */   public void setReadTimeout(int readTimeout)
/*     */   {
/* 106 */     this.readTimeout = readTimeout;
/*     */   }
/*     */ 
/*     */   public void setOutputStreaming(boolean outputStreaming)
/*     */   {
/* 121 */     this.outputStreaming = outputStreaming;
/*     */   }
/*     */ 
/*     */   public ClientHttpRequest createRequest(URI uri, HttpMethod httpMethod) throws IOException
/*     */   {
/* 126 */     HttpURLConnection connection = openConnection(uri.toURL(), this.proxy);
/* 127 */     prepareConnection(connection, httpMethod.name());
/* 128 */     if (this.bufferRequestBody) {
/* 129 */       return new SimpleBufferingClientHttpRequest(connection, this.outputStreaming);
/*     */     }
/*     */ 
/* 132 */     return new SimpleStreamingClientHttpRequest(connection, this.chunkSize, this.outputStreaming);
/*     */   }
/*     */ 
/*     */   protected HttpURLConnection openConnection(URL url, Proxy proxy)
/*     */     throws IOException
/*     */   {
/* 147 */     URLConnection urlConnection = proxy != null ? url.openConnection(proxy) : url.openConnection();
/* 148 */     Assert.isInstanceOf(HttpURLConnection.class, urlConnection);
/* 149 */     return (HttpURLConnection)urlConnection;
/*     */   }
/*     */ 
/*     */   protected void prepareConnection(HttpURLConnection connection, String httpMethod)
/*     */     throws IOException
/*     */   {
/* 160 */     if (this.connectTimeout >= 0) {
/* 161 */       connection.setConnectTimeout(this.connectTimeout);
/*     */     }
/* 163 */     if (this.readTimeout >= 0) {
/* 164 */       connection.setReadTimeout(this.readTimeout);
/*     */     }
/* 166 */     connection.setDoInput(true);
/* 167 */     if ("GET".equals(httpMethod)) {
/* 168 */       connection.setInstanceFollowRedirects(true);
/*     */     }
/*     */     else {
/* 171 */       connection.setInstanceFollowRedirects(false);
/*     */     }
/* 173 */     if (("PUT".equals(httpMethod)) || ("POST".equals(httpMethod)) || ("PATCH".equals(httpMethod))) {
/* 174 */       connection.setDoOutput(true);
/*     */     }
/*     */     else {
/* 177 */       connection.setDoOutput(false);
/*     */     }
/* 179 */     connection.setRequestMethod(httpMethod);
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.http.client.SimpleClientHttpRequestFactory
 * JD-Core Version:    0.6.0
 */