/*    */ package org.springframework.http.server;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStream;
/*    */ import java.nio.charset.Charset;
/*    */ import java.util.List;
/*    */ import java.util.Map.Entry;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.springframework.http.HttpHeaders;
/*    */ import org.springframework.http.HttpStatus;
/*    */ import org.springframework.http.MediaType;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ public class ServletServerHttpResponse
/*    */   implements ServerHttpResponse
/*    */ {
/*    */   private final HttpServletResponse servletResponse;
/* 39 */   private final HttpHeaders headers = new HttpHeaders();
/*    */ 
/* 41 */   private boolean headersWritten = false;
/*    */ 
/*    */   public ServletServerHttpResponse(HttpServletResponse servletResponse)
/*    */   {
/* 49 */     Assert.notNull(servletResponse, "'servletResponse' must not be null");
/* 50 */     this.servletResponse = servletResponse;
/*    */   }
/*    */ 
/*    */   public HttpServletResponse getServletResponse()
/*    */   {
/* 58 */     return this.servletResponse;
/*    */   }
/*    */ 
/*    */   public void setStatusCode(HttpStatus status) {
/* 62 */     this.servletResponse.setStatus(status.value());
/*    */   }
/*    */ 
/*    */   public HttpHeaders getHeaders() {
/* 66 */     return this.headersWritten ? HttpHeaders.readOnlyHttpHeaders(this.headers) : this.headers;
/*    */   }
/*    */ 
/*    */   public OutputStream getBody() throws IOException {
/* 70 */     writeHeaders();
/* 71 */     return this.servletResponse.getOutputStream();
/*    */   }
/*    */ 
/*    */   public void close() {
/* 75 */     writeHeaders();
/*    */   }
/*    */ 
/*    */   private void writeHeaders() {
/* 79 */     if (!this.headersWritten) {
/* 80 */       for (Map.Entry entry : this.headers.entrySet()) {
/* 81 */         headerName = (String)entry.getKey();
/* 82 */         for (String headerValue : (List)entry.getValue())
/* 83 */           this.servletResponse.addHeader(headerName, headerValue);
/*    */       }
/*    */       String headerName;
/* 87 */       if ((this.servletResponse.getContentType() == null) && (this.headers.getContentType() != null)) {
/* 88 */         this.servletResponse.setContentType(this.headers.getContentType().toString());
/*    */       }
/* 90 */       if ((this.servletResponse.getCharacterEncoding() == null) && (this.headers.getContentType() != null) && (this.headers.getContentType().getCharSet() != null))
/*    */       {
/* 92 */         this.servletResponse.setCharacterEncoding(this.headers.getContentType().getCharSet().name());
/*    */       }
/* 94 */       this.headersWritten = true;
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.http.server.ServletServerHttpResponse
 * JD-Core Version:    0.6.0
 */