package org.springframework.http.server;

import java.io.Closeable;
import org.springframework.http.HttpOutputMessage;
import org.springframework.http.HttpStatus;

public abstract interface ServerHttpResponse extends HttpOutputMessage, Closeable
{
  public abstract void setStatusCode(HttpStatus paramHttpStatus);

  public abstract void close();
}

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.http.server.ServerHttpResponse
 * JD-Core Version:    0.6.0
 */