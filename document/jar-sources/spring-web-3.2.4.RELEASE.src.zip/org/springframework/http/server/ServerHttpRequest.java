package org.springframework.http.server;

import org.springframework.http.HttpInputMessage;
import org.springframework.http.HttpRequest;

public abstract interface ServerHttpRequest extends HttpRequest, HttpInputMessage
{
}

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.http.server.ServerHttpRequest
 * JD-Core Version:    0.6.0
 */