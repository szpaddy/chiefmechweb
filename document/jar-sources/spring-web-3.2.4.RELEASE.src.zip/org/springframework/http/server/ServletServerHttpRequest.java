/*     */ package org.springframework.http.server;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.Writer;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.net.URLEncoder;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.Arrays;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public class ServletServerHttpRequest
/*     */   implements ServerHttpRequest
/*     */ {
/*     */   protected static final String FORM_CONTENT_TYPE = "application/x-www-form-urlencoded";
/*     */   protected static final String FORM_CHARSET = "UTF-8";
/*     */   private static final String METHOD_POST = "POST";
/*     */   private final HttpServletRequest servletRequest;
/*     */   private HttpHeaders headers;
/*     */ 
/*     */   public ServletServerHttpRequest(HttpServletRequest servletRequest)
/*     */   {
/*  67 */     Assert.notNull(servletRequest, "'servletRequest' must not be null");
/*  68 */     this.servletRequest = servletRequest;
/*     */   }
/*     */ 
/*     */   public HttpServletRequest getServletRequest()
/*     */   {
/*  76 */     return this.servletRequest;
/*     */   }
/*     */ 
/*     */   public HttpMethod getMethod() {
/*  80 */     return HttpMethod.valueOf(this.servletRequest.getMethod());
/*     */   }
/*     */ 
/*     */   public URI getURI() {
/*     */     try {
/*  85 */       return new URI(this.servletRequest.getScheme(), null, this.servletRequest.getServerName(), this.servletRequest.getServerPort(), this.servletRequest.getRequestURI(), this.servletRequest.getQueryString(), null);
/*     */     }
/*     */     catch (URISyntaxException ex)
/*     */     {
/*     */     }
/*  90 */     throw new IllegalStateException("Could not get HttpServletRequest URI: " + ex.getMessage(), ex);
/*     */   }
/*     */ 
/*     */   public HttpHeaders getHeaders()
/*     */   {
/*  95 */     if (this.headers == null) {
/*  96 */       this.headers = new HttpHeaders();
/*  97 */       for (Enumeration headerNames = this.servletRequest.getHeaderNames(); headerNames.hasMoreElements(); ) {
/*  98 */         String headerName = (String)headerNames.nextElement();
/*  99 */         Enumeration headerValues = this.servletRequest.getHeaders(headerName);
/* 100 */         while (headerValues.hasMoreElements()) {
/* 101 */           String headerValue = (String)headerValues.nextElement();
/* 102 */           this.headers.add(headerName, headerValue);
/*     */         }
/*     */       }
/*     */ 
/* 106 */       if ((this.headers.getContentType() == null) && (this.servletRequest.getContentType() != null)) {
/* 107 */         MediaType contentType = MediaType.parseMediaType(this.servletRequest.getContentType());
/* 108 */         this.headers.setContentType(contentType);
/*     */       }
/* 110 */       if ((this.headers.getContentType() != null) && (this.headers.getContentType().getCharSet() == null) && (this.servletRequest.getCharacterEncoding() != null))
/*     */       {
/* 112 */         MediaType oldContentType = this.headers.getContentType();
/* 113 */         Charset charSet = Charset.forName(this.servletRequest.getCharacterEncoding());
/* 114 */         Map params = new HashMap(oldContentType.getParameters());
/* 115 */         params.put("charset", charSet.toString());
/* 116 */         MediaType newContentType = new MediaType(oldContentType.getType(), oldContentType.getSubtype(), params);
/* 117 */         this.headers.setContentType(newContentType);
/*     */       }
/* 119 */       if ((this.headers.getContentLength() == -1L) && (this.servletRequest.getContentLength() != -1)) {
/* 120 */         this.headers.setContentLength(this.servletRequest.getContentLength());
/*     */       }
/*     */     }
/* 123 */     return this.headers;
/*     */   }
/*     */ 
/*     */   public InputStream getBody() throws IOException {
/* 127 */     if (isFormPost(this.servletRequest)) {
/* 128 */       return getBodyFromServletRequestParameters(this.servletRequest);
/*     */     }
/*     */ 
/* 131 */     return this.servletRequest.getInputStream();
/*     */   }
/*     */ 
/*     */   private boolean isFormPost(HttpServletRequest request)
/*     */   {
/* 136 */     return (request.getContentType() != null) && (request.getContentType().contains("application/x-www-form-urlencoded")) && ("POST".equalsIgnoreCase(request.getMethod()));
/*     */   }
/*     */ 
/*     */   private InputStream getBodyFromServletRequestParameters(HttpServletRequest request)
/*     */     throws IOException
/*     */   {
/* 147 */     ByteArrayOutputStream bos = new ByteArrayOutputStream();
/* 148 */     Writer writer = new OutputStreamWriter(bos, "UTF-8");
/*     */ 
/* 150 */     Map form = request.getParameterMap();
/* 151 */     for (Iterator nameIterator = form.keySet().iterator(); nameIterator.hasNext(); ) {
/* 152 */       String name = (String)nameIterator.next();
/* 153 */       List values = Arrays.asList((Object[])form.get(name));
/* 154 */       for (Iterator valueIterator = values.iterator(); valueIterator.hasNext(); ) {
/* 155 */         String value = (String)valueIterator.next();
/* 156 */         writer.write(URLEncoder.encode(name, "UTF-8"));
/* 157 */         if (value != null) {
/* 158 */           writer.write(61);
/* 159 */           writer.write(URLEncoder.encode(value, "UTF-8"));
/* 160 */           if (valueIterator.hasNext()) {
/* 161 */             writer.write(38);
/*     */           }
/*     */         }
/*     */       }
/* 165 */       if (nameIterator.hasNext()) {
/* 166 */         writer.append('&');
/*     */       }
/*     */     }
/* 169 */     writer.flush();
/*     */ 
/* 171 */     return new ByteArrayInputStream(bos.toByteArray());
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.http.server.ServletServerHttpRequest
 * JD-Core Version:    0.6.0
 */