/*     */ package org.springframework.http;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.net.URI;
/*     */ import java.nio.charset.Charset;
/*     */ import java.text.ParseException;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Date;
/*     */ import java.util.EnumSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.TimeZone;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.LinkedCaseInsensitiveMap;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class HttpHeaders
/*     */   implements MultiValueMap<String, String>, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = -8578554704772377436L;
/*     */   private static final String ACCEPT = "Accept";
/*     */   private static final String ACCEPT_CHARSET = "Accept-Charset";
/*     */   private static final String ALLOW = "Allow";
/*     */   private static final String CACHE_CONTROL = "Cache-Control";
/*     */   private static final String CONTENT_DISPOSITION = "Content-Disposition";
/*     */   private static final String CONTENT_LENGTH = "Content-Length";
/*     */   private static final String CONTENT_TYPE = "Content-Type";
/*     */   private static final String DATE = "Date";
/*     */   private static final String ETAG = "ETag";
/*     */   private static final String EXPIRES = "Expires";
/*     */   private static final String IF_MODIFIED_SINCE = "If-Modified-Since";
/*     */   private static final String IF_NONE_MATCH = "If-None-Match";
/*     */   private static final String LAST_MODIFIED = "Last-Modified";
/*     */   private static final String LOCATION = "Location";
/*     */   private static final String PRAGMA = "Pragma";
/*  97 */   private static final String[] DATE_FORMATS = { "EEE, dd MMM yyyy HH:mm:ss zzz", "EEE, dd-MMM-yy HH:mm:ss zzz", "EEE MMM dd HH:mm:ss yyyy" };
/*     */ 
/* 103 */   private static TimeZone GMT = TimeZone.getTimeZone("GMT");
/*     */   private final Map<String, List<String>> headers;
/*     */ 
/*     */   private HttpHeaders(Map<String, List<String>> headers, boolean readOnly)
/*     */   {
/* 112 */     Assert.notNull(headers, "'headers' must not be null");
/* 113 */     if (readOnly) {
/* 114 */       Map map = new LinkedCaseInsensitiveMap(headers.size(), Locale.ENGLISH);
/*     */ 
/* 116 */       for (Map.Entry entry : headers.entrySet()) {
/* 117 */         List values = Collections.unmodifiableList((List)entry.getValue());
/* 118 */         map.put(entry.getKey(), values);
/*     */       }
/* 120 */       this.headers = Collections.unmodifiableMap(map);
/*     */     }
/*     */     else {
/* 123 */       this.headers = headers;
/*     */     }
/*     */   }
/*     */ 
/*     */   public HttpHeaders()
/*     */   {
/* 131 */     this(new LinkedCaseInsensitiveMap(8, Locale.ENGLISH), false);
/*     */   }
/*     */ 
/*     */   public static HttpHeaders readOnlyHttpHeaders(HttpHeaders headers)
/*     */   {
/* 138 */     return new HttpHeaders(headers, true);
/*     */   }
/*     */ 
/*     */   public void setAccept(List<MediaType> acceptableMediaTypes)
/*     */   {
/* 146 */     set("Accept", MediaType.toString(acceptableMediaTypes));
/*     */   }
/*     */ 
/*     */   public List<MediaType> getAccept()
/*     */   {
/* 155 */     String value = getFirst("Accept");
/* 156 */     List result = value != null ? MediaType.parseMediaTypes(value) : Collections.emptyList();
/*     */ 
/* 159 */     if ((result.size() == 1) && (((List)this.headers.get("Accept")).size() > 1)) {
/* 160 */       value = StringUtils.collectionToCommaDelimitedString((Collection)this.headers.get("Accept"));
/* 161 */       result = MediaType.parseMediaTypes(value);
/*     */     }
/*     */ 
/* 164 */     return result;
/*     */   }
/*     */ 
/*     */   public void setAcceptCharset(List<Charset> acceptableCharsets)
/*     */   {
/* 172 */     StringBuilder builder = new StringBuilder();
/* 173 */     for (Iterator iterator = acceptableCharsets.iterator(); iterator.hasNext(); ) {
/* 174 */       Charset charset = (Charset)iterator.next();
/* 175 */       builder.append(charset.name().toLowerCase(Locale.ENGLISH));
/* 176 */       if (iterator.hasNext()) {
/* 177 */         builder.append(", ");
/*     */       }
/*     */     }
/* 180 */     set("Accept-Charset", builder.toString());
/*     */   }
/*     */ 
/*     */   public List<Charset> getAcceptCharset()
/*     */   {
/* 189 */     List result = new ArrayList();
/* 190 */     String value = getFirst("Accept-Charset");
/* 191 */     if (value != null) {
/* 192 */       String[] tokens = value.split(",\\s*");
/* 193 */       for (String token : tokens) {
/* 194 */         int paramIdx = token.indexOf(';');
/*     */         String charsetName;
/*     */         String charsetName;
/* 196 */         if (paramIdx == -1) {
/* 197 */           charsetName = token;
/*     */         }
/*     */         else {
/* 200 */           charsetName = token.substring(0, paramIdx);
/*     */         }
/* 202 */         if (!charsetName.equals("*")) {
/* 203 */           result.add(Charset.forName(charsetName));
/*     */         }
/*     */       }
/*     */     }
/* 207 */     return result;
/*     */   }
/*     */ 
/*     */   public void setAllow(Set<HttpMethod> allowedMethods)
/*     */   {
/* 215 */     set("Allow", StringUtils.collectionToCommaDelimitedString(allowedMethods));
/*     */   }
/*     */ 
/*     */   public Set<HttpMethod> getAllow()
/*     */   {
/* 224 */     String value = getFirst("Allow");
/* 225 */     if (value != null) {
/* 226 */       List allowedMethod = new ArrayList(5);
/* 227 */       String[] tokens = value.split(",\\s*");
/* 228 */       for (String token : tokens) {
/* 229 */         allowedMethod.add(HttpMethod.valueOf(token));
/*     */       }
/* 231 */       return EnumSet.copyOf(allowedMethod);
/*     */     }
/*     */ 
/* 234 */     return EnumSet.noneOf(HttpMethod.class);
/*     */   }
/*     */ 
/*     */   public void setCacheControl(String cacheControl)
/*     */   {
/* 243 */     set("Cache-Control", cacheControl);
/*     */   }
/*     */ 
/*     */   public String getCacheControl()
/*     */   {
/* 251 */     return getFirst("Cache-Control");
/*     */   }
/*     */ 
/*     */   public void setContentDispositionFormData(String name, String filename)
/*     */   {
/* 260 */     Assert.notNull(name, "'name' must not be null");
/* 261 */     StringBuilder builder = new StringBuilder("form-data; name=\"");
/* 262 */     builder.append(name).append('"');
/* 263 */     if (filename != null) {
/* 264 */       builder.append("; filename=\"");
/* 265 */       builder.append(filename).append('"');
/*     */     }
/* 267 */     set("Content-Disposition", builder.toString());
/*     */   }
/*     */ 
/*     */   public void setContentLength(long contentLength)
/*     */   {
/* 275 */     set("Content-Length", Long.toString(contentLength));
/*     */   }
/*     */ 
/*     */   public long getContentLength()
/*     */   {
/* 284 */     String value = getFirst("Content-Length");
/* 285 */     return value != null ? Long.parseLong(value) : -1L;
/*     */   }
/*     */ 
/*     */   public void setContentType(MediaType mediaType)
/*     */   {
/* 293 */     Assert.isTrue(!mediaType.isWildcardType(), "'Content-Type' cannot contain wildcard type '*'");
/* 294 */     Assert.isTrue(!mediaType.isWildcardSubtype(), "'Content-Type' cannot contain wildcard subtype '*'");
/* 295 */     set("Content-Type", mediaType.toString());
/*     */   }
/*     */ 
/*     */   public MediaType getContentType()
/*     */   {
/* 304 */     String value = getFirst("Content-Type");
/* 305 */     return value != null ? MediaType.parseMediaType(value) : null;
/*     */   }
/*     */ 
/*     */   public void setDate(long date)
/*     */   {
/* 314 */     setDate("Date", date);
/*     */   }
/*     */ 
/*     */   public long getDate()
/*     */   {
/* 324 */     return getFirstDate("Date");
/*     */   }
/*     */ 
/*     */   public void setETag(String eTag)
/*     */   {
/* 332 */     if (eTag != null) {
/* 333 */       Assert.isTrue((eTag.startsWith("\"")) || (eTag.startsWith("W/")), "Invalid eTag, does not start with W/ or \"");
/* 334 */       Assert.isTrue(eTag.endsWith("\""), "Invalid eTag, does not end with \"");
/*     */     }
/* 336 */     set("ETag", eTag);
/*     */   }
/*     */ 
/*     */   public String getETag()
/*     */   {
/* 344 */     return getFirst("ETag");
/*     */   }
/*     */ 
/*     */   public void setExpires(long expires)
/*     */   {
/* 353 */     setDate("Expires", expires);
/*     */   }
/*     */ 
/*     */   public long getExpires()
/*     */   {
/*     */     try
/*     */     {
/* 366 */       return getFirstDate("Expires");
/*     */     } catch (IllegalArgumentException ex) {
/*     */     }
/* 369 */     return -1L;
/*     */   }
/*     */ 
/*     */   public void setIfModifiedSince(long ifModifiedSince)
/*     */   {
/* 379 */     setDate("If-Modified-Since", ifModifiedSince);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public long getIfNotModifiedSince()
/*     */   {
/* 390 */     return getIfModifiedSince();
/*     */   }
/*     */ 
/*     */   public long getIfModifiedSince()
/*     */   {
/* 399 */     return getFirstDate("If-Modified-Since");
/*     */   }
/*     */ 
/*     */   public void setIfNoneMatch(String ifNoneMatch)
/*     */   {
/* 407 */     set("If-None-Match", ifNoneMatch);
/*     */   }
/*     */ 
/*     */   public void setIfNoneMatch(List<String> ifNoneMatchList)
/*     */   {
/* 415 */     StringBuilder builder = new StringBuilder();
/* 416 */     for (Iterator iterator = ifNoneMatchList.iterator(); iterator.hasNext(); ) {
/* 417 */       String ifNoneMatch = (String)iterator.next();
/* 418 */       builder.append(ifNoneMatch);
/* 419 */       if (iterator.hasNext()) {
/* 420 */         builder.append(", ");
/*     */       }
/*     */     }
/* 423 */     set("If-None-Match", builder.toString());
/*     */   }
/*     */ 
/*     */   public List<String> getIfNoneMatch()
/*     */   {
/* 431 */     List result = new ArrayList();
/*     */ 
/* 433 */     String value = getFirst("If-None-Match");
/* 434 */     if (value != null) {
/* 435 */       String[] tokens = value.split(",\\s*");
/* 436 */       for (String token : tokens) {
/* 437 */         result.add(token);
/*     */       }
/*     */     }
/* 440 */     return result;
/*     */   }
/*     */ 
/*     */   public void setLastModified(long lastModified)
/*     */   {
/* 449 */     setDate("Last-Modified", lastModified);
/*     */   }
/*     */ 
/*     */   public long getLastModified()
/*     */   {
/* 458 */     return getFirstDate("Last-Modified");
/*     */   }
/*     */ 
/*     */   public void setLocation(URI location)
/*     */   {
/* 466 */     set("Location", location.toASCIIString());
/*     */   }
/*     */ 
/*     */   public URI getLocation()
/*     */   {
/* 475 */     String value = getFirst("Location");
/* 476 */     return value != null ? URI.create(value) : null;
/*     */   }
/*     */ 
/*     */   public void setPragma(String pragma)
/*     */   {
/* 484 */     set("Pragma", pragma);
/*     */   }
/*     */ 
/*     */   public String getPragma()
/*     */   {
/* 492 */     return getFirst("Pragma");
/*     */   }
/*     */ 
/*     */   public long getFirstDate(String headerName)
/*     */   {
/* 503 */     String headerValue = getFirst(headerName);
/* 504 */     if (headerValue == null) {
/* 505 */       return -1L;
/*     */     }
/* 507 */     for (String dateFormat : DATE_FORMATS) {
/* 508 */       SimpleDateFormat simpleDateFormat = new SimpleDateFormat(dateFormat, Locale.US);
/* 509 */       simpleDateFormat.setTimeZone(GMT);
/*     */       try {
/* 511 */         return simpleDateFormat.parse(headerValue).getTime();
/*     */       }
/*     */       catch (ParseException e)
/*     */       {
/*     */       }
/*     */     }
/* 517 */     throw new IllegalArgumentException("Cannot parse date value \"" + headerValue + "\" for \"" + headerName + "\" header");
/*     */   }
/*     */ 
/*     */   public void setDate(String headerName, long date)
/*     */   {
/* 527 */     SimpleDateFormat dateFormat = new SimpleDateFormat(DATE_FORMATS[0], Locale.US);
/* 528 */     dateFormat.setTimeZone(GMT);
/* 529 */     set(headerName, dateFormat.format(new Date(date)));
/*     */   }
/*     */ 
/*     */   public String getFirst(String headerName)
/*     */   {
/* 540 */     List headerValues = (List)this.headers.get(headerName);
/* 541 */     return headerValues != null ? (String)headerValues.get(0) : null;
/*     */   }
/*     */ 
/*     */   public void add(String headerName, String headerValue)
/*     */   {
/* 553 */     List headerValues = (List)this.headers.get(headerName);
/* 554 */     if (headerValues == null) {
/* 555 */       headerValues = new LinkedList();
/* 556 */       this.headers.put(headerName, headerValues);
/*     */     }
/* 558 */     headerValues.add(headerValue);
/*     */   }
/*     */ 
/*     */   public void set(String headerName, String headerValue)
/*     */   {
/* 570 */     List headerValues = new LinkedList();
/* 571 */     headerValues.add(headerValue);
/* 572 */     this.headers.put(headerName, headerValues);
/*     */   }
/*     */ 
/*     */   public void setAll(Map<String, String> values) {
/* 576 */     for (Map.Entry entry : values.entrySet())
/* 577 */       set((String)entry.getKey(), (String)entry.getValue());
/*     */   }
/*     */ 
/*     */   public Map<String, String> toSingleValueMap()
/*     */   {
/* 582 */     LinkedHashMap singleValueMap = new LinkedHashMap(this.headers.size());
/* 583 */     for (Map.Entry entry : this.headers.entrySet()) {
/* 584 */       singleValueMap.put(entry.getKey(), ((List)entry.getValue()).get(0));
/*     */     }
/* 586 */     return singleValueMap;
/*     */   }
/*     */ 
/*     */   public int size()
/*     */   {
/* 592 */     return this.headers.size();
/*     */   }
/*     */ 
/*     */   public boolean isEmpty() {
/* 596 */     return this.headers.isEmpty();
/*     */   }
/*     */ 
/*     */   public boolean containsKey(Object key) {
/* 600 */     return this.headers.containsKey(key);
/*     */   }
/*     */ 
/*     */   public boolean containsValue(Object value) {
/* 604 */     return this.headers.containsValue(value);
/*     */   }
/*     */ 
/*     */   public List<String> get(Object key) {
/* 608 */     return (List)this.headers.get(key);
/*     */   }
/*     */ 
/*     */   public List<String> put(String key, List<String> value) {
/* 612 */     return (List)this.headers.put(key, value);
/*     */   }
/*     */ 
/*     */   public List<String> remove(Object key) {
/* 616 */     return (List)this.headers.remove(key);
/*     */   }
/*     */ 
/*     */   public void putAll(Map<? extends String, ? extends List<String>> m) {
/* 620 */     this.headers.putAll(m);
/*     */   }
/*     */ 
/*     */   public void clear() {
/* 624 */     this.headers.clear();
/*     */   }
/*     */ 
/*     */   public Set<String> keySet() {
/* 628 */     return this.headers.keySet();
/*     */   }
/*     */ 
/*     */   public Collection<List<String>> values() {
/* 632 */     return this.headers.values();
/*     */   }
/*     */ 
/*     */   public Set<Map.Entry<String, List<String>>> entrySet() {
/* 636 */     return this.headers.entrySet();
/*     */   }
/*     */ 
/*     */   public boolean equals(Object other)
/*     */   {
/* 642 */     if (this == other) {
/* 643 */       return true;
/*     */     }
/* 645 */     if (!(other instanceof HttpHeaders)) {
/* 646 */       return false;
/*     */     }
/* 648 */     HttpHeaders otherHeaders = (HttpHeaders)other;
/* 649 */     return this.headers.equals(otherHeaders.headers);
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 654 */     return this.headers.hashCode();
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 659 */     return this.headers.toString();
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.http.HttpHeaders
 * JD-Core Version:    0.6.0
 */