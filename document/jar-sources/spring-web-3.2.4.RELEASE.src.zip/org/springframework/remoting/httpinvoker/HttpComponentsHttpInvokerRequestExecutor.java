/*     */ package org.springframework.remoting.httpinvoker;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.zip.GZIPInputStream;
/*     */ import org.apache.http.Header;
/*     */ import org.apache.http.HttpEntity;
/*     */ import org.apache.http.HttpResponse;
/*     */ import org.apache.http.NoHttpResponseException;
/*     */ import org.apache.http.StatusLine;
/*     */ import org.apache.http.client.HttpClient;
/*     */ import org.apache.http.client.methods.HttpPost;
/*     */ import org.apache.http.conn.scheme.PlainSocketFactory;
/*     */ import org.apache.http.conn.scheme.Scheme;
/*     */ import org.apache.http.conn.scheme.SchemeRegistry;
/*     */ import org.apache.http.conn.ssl.SSLSocketFactory;
/*     */ import org.apache.http.entity.ByteArrayEntity;
/*     */ import org.apache.http.impl.client.DefaultHttpClient;
/*     */ import org.apache.http.impl.conn.PoolingClientConnectionManager;
/*     */ import org.apache.http.params.HttpParams;
/*     */ import org.springframework.context.i18n.LocaleContext;
/*     */ import org.springframework.context.i18n.LocaleContextHolder;
/*     */ import org.springframework.remoting.support.RemoteInvocationResult;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class HttpComponentsHttpInvokerRequestExecutor extends AbstractHttpInvokerRequestExecutor
/*     */ {
/*     */   private static final int DEFAULT_MAX_TOTAL_CONNECTIONS = 100;
/*     */   private static final int DEFAULT_MAX_CONNECTIONS_PER_ROUTE = 5;
/*     */   private static final int DEFAULT_READ_TIMEOUT_MILLISECONDS = 60000;
/*     */   private HttpClient httpClient;
/*     */ 
/*     */   public HttpComponentsHttpInvokerRequestExecutor()
/*     */   {
/*  76 */     SchemeRegistry schemeRegistry = new SchemeRegistry();
/*  77 */     schemeRegistry.register(new Scheme("http", 80, PlainSocketFactory.getSocketFactory()));
/*  78 */     schemeRegistry.register(new Scheme("https", 443, SSLSocketFactory.getSocketFactory()));
/*     */ 
/*  80 */     PoolingClientConnectionManager connectionManager = new PoolingClientConnectionManager(schemeRegistry);
/*  81 */     connectionManager.setMaxTotal(100);
/*  82 */     connectionManager.setDefaultMaxPerRoute(5);
/*     */ 
/*  84 */     this.httpClient = new DefaultHttpClient(connectionManager);
/*  85 */     setReadTimeout(60000);
/*     */   }
/*     */ 
/*     */   public HttpComponentsHttpInvokerRequestExecutor(HttpClient httpClient)
/*     */   {
/*  94 */     this.httpClient = httpClient;
/*     */   }
/*     */ 
/*     */   public void setHttpClient(HttpClient httpClient)
/*     */   {
/* 102 */     this.httpClient = httpClient;
/*     */   }
/*     */ 
/*     */   public HttpClient getHttpClient()
/*     */   {
/* 109 */     return this.httpClient;
/*     */   }
/*     */ 
/*     */   public void setConnectTimeout(int timeout)
/*     */   {
/* 118 */     Assert.isTrue(timeout >= 0, "Timeout must be a non-negative value");
/* 119 */     getHttpClient().getParams().setIntParameter("http.connection.timeout", timeout);
/*     */   }
/*     */ 
/*     */   public void setReadTimeout(int timeout)
/*     */   {
/* 129 */     Assert.isTrue(timeout >= 0, "Timeout must be a non-negative value");
/* 130 */     getHttpClient().getParams().setIntParameter("http.socket.timeout", timeout);
/*     */   }
/*     */ 
/*     */   protected RemoteInvocationResult doExecuteRequest(HttpInvokerClientConfiguration config, ByteArrayOutputStream baos)
/*     */     throws IOException, ClassNotFoundException
/*     */   {
/* 149 */     HttpPost postMethod = createHttpPost(config);
/* 150 */     setRequestBody(config, postMethod, baos);
/*     */     try {
/* 152 */       HttpResponse response = executeHttpPost(config, getHttpClient(), postMethod);
/* 153 */       validateResponse(config, response);
/* 154 */       InputStream responseBody = getResponseBody(config, response);
/* 155 */       RemoteInvocationResult localRemoteInvocationResult = readRemoteInvocationResult(responseBody, config.getCodebaseUrl());
/*     */       return localRemoteInvocationResult; } finally { postMethod.releaseConnection(); } throw localObject;
/*     */   }
/*     */ 
/*     */   protected HttpPost createHttpPost(HttpInvokerClientConfiguration config)
/*     */     throws IOException
/*     */   {
/* 172 */     HttpPost httpPost = new HttpPost(config.getServiceUrl());
/* 173 */     LocaleContext locale = LocaleContextHolder.getLocaleContext();
/* 174 */     if (locale != null) {
/* 175 */       httpPost.addHeader("Accept-Language", StringUtils.toLanguageTag(locale.getLocale()));
/*     */     }
/* 177 */     if (isAcceptGzipEncoding()) {
/* 178 */       httpPost.addHeader("Accept-Encoding", "gzip");
/*     */     }
/* 180 */     return httpPost;
/*     */   }
/*     */ 
/*     */   protected void setRequestBody(HttpInvokerClientConfiguration config, HttpPost httpPost, ByteArrayOutputStream baos)
/*     */     throws IOException
/*     */   {
/* 198 */     ByteArrayEntity entity = new ByteArrayEntity(baos.toByteArray());
/* 199 */     entity.setContentType(getContentType());
/* 200 */     httpPost.setEntity(entity);
/*     */   }
/*     */ 
/*     */   protected HttpResponse executeHttpPost(HttpInvokerClientConfiguration config, HttpClient httpClient, HttpPost httpPost)
/*     */     throws IOException
/*     */   {
/* 215 */     return httpClient.execute(httpPost);
/*     */   }
/*     */ 
/*     */   protected void validateResponse(HttpInvokerClientConfiguration config, HttpResponse response)
/*     */     throws IOException
/*     */   {
/* 230 */     StatusLine status = response.getStatusLine();
/* 231 */     if (status.getStatusCode() >= 300)
/* 232 */       throw new NoHttpResponseException("Did not receive successful HTTP response: status code = " + status.getStatusCode() + ", status message = [" + status.getReasonPhrase() + "]");
/*     */   }
/*     */ 
/*     */   protected InputStream getResponseBody(HttpInvokerClientConfiguration config, HttpResponse httpResponse)
/*     */     throws IOException
/*     */   {
/* 253 */     if (isGzipResponse(httpResponse)) {
/* 254 */       return new GZIPInputStream(httpResponse.getEntity().getContent());
/*     */     }
/*     */ 
/* 257 */     return httpResponse.getEntity().getContent();
/*     */   }
/*     */ 
/*     */   protected boolean isGzipResponse(HttpResponse httpResponse)
/*     */   {
/* 269 */     Header encodingHeader = httpResponse.getFirstHeader("Content-Encoding");
/* 270 */     return (encodingHeader != null) && (encodingHeader.getValue() != null) && (encodingHeader.getValue().toLowerCase().contains("gzip"));
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.remoting.httpinvoker.HttpComponentsHttpInvokerRequestExecutor
 * JD-Core Version:    0.6.0
 */