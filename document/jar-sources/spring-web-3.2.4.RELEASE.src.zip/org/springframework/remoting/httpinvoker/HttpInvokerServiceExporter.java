/*     */ package org.springframework.remoting.httpinvoker;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.OutputStream;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.springframework.remoting.rmi.RemoteInvocationSerializingExporter;
/*     */ import org.springframework.remoting.support.RemoteInvocation;
/*     */ import org.springframework.remoting.support.RemoteInvocationResult;
/*     */ import org.springframework.web.HttpRequestHandler;
/*     */ import org.springframework.web.util.NestedServletException;
/*     */ 
/*     */ public class HttpInvokerServiceExporter extends RemoteInvocationSerializingExporter
/*     */   implements HttpRequestHandler
/*     */ {
/*     */   public void handleRequest(HttpServletRequest request, HttpServletResponse response)
/*     */     throws ServletException, IOException
/*     */   {
/*     */     try
/*     */     {
/*  72 */       RemoteInvocation invocation = readRemoteInvocation(request);
/*  73 */       RemoteInvocationResult result = invokeAndCreateResult(invocation, getProxy());
/*  74 */       writeRemoteInvocationResult(request, response, result);
/*     */     }
/*     */     catch (ClassNotFoundException ex) {
/*  77 */       throw new NestedServletException("Class not found during deserialization", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected RemoteInvocation readRemoteInvocation(HttpServletRequest request)
/*     */     throws IOException, ClassNotFoundException
/*     */   {
/*  95 */     return readRemoteInvocation(request, request.getInputStream());
/*     */   }
/*     */ 
/*     */   protected RemoteInvocation readRemoteInvocation(HttpServletRequest request, InputStream is)
/*     */     throws IOException, ClassNotFoundException
/*     */   {
/* 114 */     ObjectInputStream ois = createObjectInputStream(decorateInputStream(request, is));
/*     */     try {
/* 116 */       RemoteInvocation localRemoteInvocation = doReadRemoteInvocation(ois);
/*     */       return localRemoteInvocation; } finally { ois.close(); } throw localObject;
/*     */   }
/*     */ 
/*     */   protected InputStream decorateInputStream(HttpServletRequest request, InputStream is)
/*     */     throws IOException
/*     */   {
/* 134 */     return is;
/*     */   }
/*     */ 
/*     */   protected void writeRemoteInvocationResult(HttpServletRequest request, HttpServletResponse response, RemoteInvocationResult result)
/*     */     throws IOException
/*     */   {
/* 148 */     response.setContentType(getContentType());
/* 149 */     writeRemoteInvocationResult(request, response, result, response.getOutputStream());
/*     */   }
/*     */ 
/*     */   protected void writeRemoteInvocationResult(HttpServletRequest request, HttpServletResponse response, RemoteInvocationResult result, OutputStream os)
/*     */     throws IOException
/*     */   {
/* 171 */     ObjectOutputStream oos = createObjectOutputStream(decorateOutputStream(request, response, os));
/*     */     try {
/* 173 */       doWriteRemoteInvocationResult(result, oos);
/*     */     }
/*     */     finally {
/* 176 */       oos.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   protected OutputStream decorateOutputStream(HttpServletRequest request, HttpServletResponse response, OutputStream os)
/*     */     throws IOException
/*     */   {
/* 194 */     return os;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.remoting.httpinvoker.HttpInvokerServiceExporter
 * JD-Core Version:    0.6.0
 */