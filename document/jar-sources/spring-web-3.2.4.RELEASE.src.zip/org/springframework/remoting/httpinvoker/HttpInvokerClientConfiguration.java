package org.springframework.remoting.httpinvoker;

public abstract interface HttpInvokerClientConfiguration
{
  public abstract String getServiceUrl();

  public abstract String getCodebaseUrl();
}

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.remoting.httpinvoker.HttpInvokerClientConfiguration
 * JD-Core Version:    0.6.0
 */