/*    */ package org.springframework.remoting.caucho;
/*    */ 
/*    */ import org.springframework.aop.framework.ProxyFactory;
/*    */ import org.springframework.beans.factory.FactoryBean;
/*    */ 
/*    */ public class BurlapProxyFactoryBean extends BurlapClientInterceptor
/*    */   implements FactoryBean<Object>
/*    */ {
/*    */   private Object serviceProxy;
/*    */ 
/*    */   public void afterPropertiesSet()
/*    */   {
/* 50 */     super.afterPropertiesSet();
/* 51 */     this.serviceProxy = new ProxyFactory(getServiceInterface(), this).getProxy(getBeanClassLoader());
/*    */   }
/*    */ 
/*    */   public Object getObject()
/*    */   {
/* 56 */     return this.serviceProxy;
/*    */   }
/*    */ 
/*    */   public Class<?> getObjectType() {
/* 60 */     return getServiceInterface();
/*    */   }
/*    */ 
/*    */   public boolean isSingleton() {
/* 64 */     return true;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.remoting.caucho.BurlapProxyFactoryBean
 * JD-Core Version:    0.6.0
 */