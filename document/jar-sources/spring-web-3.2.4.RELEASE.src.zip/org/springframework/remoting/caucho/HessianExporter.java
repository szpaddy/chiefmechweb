/*     */ package org.springframework.remoting.caucho;
/*     */ 
/*     */ import com.caucho.hessian.io.AbstractHessianInput;
/*     */ import com.caucho.hessian.io.AbstractHessianOutput;
/*     */ import com.caucho.hessian.io.Hessian2Input;
/*     */ import com.caucho.hessian.io.Hessian2Output;
/*     */ import com.caucho.hessian.io.HessianDebugInputStream;
/*     */ import com.caucho.hessian.io.HessianDebugOutputStream;
/*     */ import com.caucho.hessian.io.HessianInput;
/*     */ import com.caucho.hessian.io.HessianOutput;
/*     */ import com.caucho.hessian.io.SerializerFactory;
/*     */ import com.caucho.hessian.server.HessianSkeleton;
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.PrintWriter;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.remoting.support.RemoteExporter;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.CommonsLogWriter;
/*     */ 
/*     */ public class HessianExporter extends RemoteExporter
/*     */   implements InitializingBean
/*     */ {
/*     */   public static final String CONTENT_TYPE_HESSIAN = "application/x-hessian";
/*  61 */   private SerializerFactory serializerFactory = new SerializerFactory();
/*     */   private Log debugLogger;
/*     */   private HessianSkeleton skeleton;
/*     */ 
/*     */   public void setSerializerFactory(SerializerFactory serializerFactory)
/*     */   {
/*  75 */     this.serializerFactory = (serializerFactory != null ? serializerFactory : new SerializerFactory());
/*     */   }
/*     */ 
/*     */   public void setSendCollectionType(boolean sendCollectionType)
/*     */   {
/*  83 */     this.serializerFactory.setSendCollectionType(sendCollectionType);
/*     */   }
/*     */ 
/*     */   public void setDebug(boolean debug)
/*     */   {
/*  92 */     this.debugLogger = (debug ? this.logger : null);
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */   {
/*  97 */     prepare();
/*     */   }
/*     */ 
/*     */   public void prepare()
/*     */   {
/* 104 */     checkService();
/* 105 */     checkServiceInterface();
/* 106 */     this.skeleton = new HessianSkeleton(getProxyForService(), getServiceInterface());
/*     */   }
/*     */ 
/*     */   public void invoke(InputStream inputStream, OutputStream outputStream)
/*     */     throws Throwable
/*     */   {
/* 117 */     Assert.notNull(this.skeleton, "Hessian exporter has not been initialized");
/* 118 */     doInvoke(this.skeleton, inputStream, outputStream);
/*     */   }
/*     */ 
/*     */   protected void doInvoke(HessianSkeleton skeleton, InputStream inputStream, OutputStream outputStream)
/*     */     throws Throwable
/*     */   {
/* 131 */     ClassLoader originalClassLoader = overrideThreadContextClassLoader();
/*     */     try {
/* 133 */       InputStream isToUse = inputStream;
/* 134 */       OutputStream osToUse = outputStream;
/*     */ 
/* 136 */       if ((this.debugLogger != null) && (this.debugLogger.isDebugEnabled())) {
/* 137 */         PrintWriter debugWriter = new PrintWriter(new CommonsLogWriter(this.debugLogger));
/* 138 */         HessianDebugInputStream dis = new HessianDebugInputStream(inputStream, debugWriter);
/* 139 */         dis.startTop2();
/* 140 */         HessianDebugOutputStream dos = new HessianDebugOutputStream(outputStream, debugWriter);
/* 141 */         dos.startTop2();
/* 142 */         isToUse = dis;
/* 143 */         osToUse = dos;
/*     */       }
/*     */ 
/* 146 */       if (!isToUse.markSupported()) {
/* 147 */         isToUse = new BufferedInputStream(isToUse);
/* 148 */         isToUse.mark(1);
/*     */       }
/*     */ 
/* 151 */       int code = isToUse.read();
/*     */ 
/* 158 */       if (code == 72)
/*     */       {
/* 160 */         int major = isToUse.read();
/* 161 */         int minor = isToUse.read();
/* 162 */         if (major != 2) {
/* 163 */           throw new IOException("Version " + major + "." + minor + " is not understood");
/*     */         }
/* 165 */         AbstractHessianInput in = new Hessian2Input(isToUse);
/* 166 */         AbstractHessianOutput out = new Hessian2Output(osToUse);
/* 167 */         in.readCall();
/*     */       }
/* 169 */       else if (code == 67)
/*     */       {
/* 171 */         isToUse.reset();
/* 172 */         AbstractHessianInput in = new Hessian2Input(isToUse);
/* 173 */         AbstractHessianOutput out = new Hessian2Output(osToUse);
/* 174 */         in.readCall();
/*     */       }
/*     */       else
/*     */       {
/*     */         AbstractHessianOutput out;
/* 176 */         if (code == 99)
/*     */         {
/* 178 */           int major = isToUse.read();
/* 179 */           int minor = isToUse.read();
/* 180 */           AbstractHessianInput in = new HessianInput(isToUse);
/*     */           AbstractHessianOutput out;
/* 181 */           if (major >= 2) {
/* 182 */             out = new Hessian2Output(osToUse);
/*     */           }
/*     */           else
/* 185 */             out = new HessianOutput(osToUse);
/*     */         }
/*     */         else
/*     */         {
/* 189 */           throw new IOException("Expected 'H'/'C' (Hessian 2.0) or 'c' (Hessian 1.0) in hessian input at " + code);
/*     */         }
/*     */       }
/*     */       AbstractHessianOutput out;
/*     */       AbstractHessianInput in;
/* 192 */       if (this.serializerFactory != null) {
/* 193 */         in.setSerializerFactory(this.serializerFactory);
/* 194 */         out.setSerializerFactory(this.serializerFactory);
/*     */       }
/*     */       try
/*     */       {
/* 198 */         skeleton.invoke(in, out);
/*     */       }
/*     */       finally {
/*     */         try {
/* 202 */           in.close();
/* 203 */           isToUse.close();
/*     */         }
/*     */         catch (IOException ex)
/*     */         {
/*     */         }
/*     */         try {
/* 209 */           out.close();
/* 210 */           osToUse.close();
/*     */         }
/*     */         catch (IOException ex)
/*     */         {
/*     */         }
/*     */       }
/*     */     }
/*     */     finally {
/* 218 */       resetThreadContextClassLoader(originalClassLoader);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.remoting.caucho.HessianExporter
 * JD-Core Version:    0.6.0
 */