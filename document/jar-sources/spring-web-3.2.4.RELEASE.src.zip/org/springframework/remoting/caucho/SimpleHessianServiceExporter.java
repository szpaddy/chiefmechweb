/*    */ package org.springframework.remoting.caucho;
/*    */ 
/*    */ import com.sun.net.httpserver.Headers;
/*    */ import com.sun.net.httpserver.HttpExchange;
/*    */ import com.sun.net.httpserver.HttpHandler;
/*    */ import java.io.ByteArrayOutputStream;
/*    */ import java.io.IOException;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.springframework.util.FileCopyUtils;
/*    */ 
/*    */ public class SimpleHessianServiceExporter extends HessianExporter
/*    */   implements HttpHandler
/*    */ {
/*    */   public void handle(HttpExchange exchange)
/*    */     throws IOException
/*    */   {
/* 54 */     if (!"POST".equals(exchange.getRequestMethod())) {
/* 55 */       exchange.getResponseHeaders().set("Allow", "POST");
/* 56 */       exchange.sendResponseHeaders(405, -1L);
/* 57 */       return;
/*    */     }
/*    */ 
/* 60 */     ByteArrayOutputStream output = new ByteArrayOutputStream(1024);
/*    */     try {
/* 62 */       invoke(exchange.getRequestBody(), output);
/*    */     }
/*    */     catch (Throwable ex) {
/* 65 */       exchange.sendResponseHeaders(500, -1L);
/* 66 */       this.logger.error("Hessian skeleton invocation failed", ex);
/* 67 */       return;
/*    */     }
/*    */ 
/* 70 */     exchange.getResponseHeaders().set("Content-Type", "application/x-hessian");
/* 71 */     exchange.sendResponseHeaders(200, output.size());
/* 72 */     FileCopyUtils.copy(output.toByteArray(), exchange.getResponseBody());
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.remoting.caucho.SimpleHessianServiceExporter
 * JD-Core Version:    0.6.0
 */