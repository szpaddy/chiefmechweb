/*     */ package org.springframework.remoting.jaxrpc;
/*     */ 
/*     */ import java.io.File;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.xml.rpc.ServiceException;
/*     */ import javax.xml.rpc.server.ServiceLifecycle;
/*     */ import javax.xml.rpc.server.ServletEndpointContext;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.support.MessageSourceAccessor;
/*     */ import org.springframework.web.context.WebApplicationContext;
/*     */ import org.springframework.web.context.support.WebApplicationContextUtils;
/*     */ import org.springframework.web.util.WebUtils;
/*     */ 
/*     */ @Deprecated
/*     */ public abstract class ServletEndpointSupport
/*     */   implements ServiceLifecycle
/*     */ {
/*  64 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   private ServletEndpointContext servletEndpointContext;
/*     */   private WebApplicationContext webApplicationContext;
/*     */   private MessageSourceAccessor messageSourceAccessor;
/*     */ 
/*     */   public final void init(Object context)
/*     */     throws ServiceException
/*     */   {
/*  81 */     if (!(context instanceof ServletEndpointContext)) {
/*  82 */       throw new ServiceException("ServletEndpointSupport needs ServletEndpointContext, not [" + context + "]");
/*     */     }
/*  84 */     this.servletEndpointContext = ((ServletEndpointContext)context);
/*  85 */     ServletContext servletContext = this.servletEndpointContext.getServletContext();
/*  86 */     this.webApplicationContext = WebApplicationContextUtils.getRequiredWebApplicationContext(servletContext);
/*  87 */     this.messageSourceAccessor = new MessageSourceAccessor(this.webApplicationContext);
/*  88 */     onInit();
/*     */   }
/*     */ 
/*     */   protected final ServletEndpointContext getServletEndpointContext()
/*     */   {
/*  95 */     return this.servletEndpointContext;
/*     */   }
/*     */ 
/*     */   protected final ApplicationContext getApplicationContext()
/*     */   {
/* 102 */     return this.webApplicationContext;
/*     */   }
/*     */ 
/*     */   protected final WebApplicationContext getWebApplicationContext()
/*     */   {
/* 109 */     return this.webApplicationContext;
/*     */   }
/*     */ 
/*     */   protected final MessageSourceAccessor getMessageSourceAccessor()
/*     */   {
/* 117 */     return this.messageSourceAccessor;
/*     */   }
/*     */ 
/*     */   protected final ServletContext getServletContext()
/*     */   {
/* 124 */     return this.webApplicationContext.getServletContext();
/*     */   }
/*     */ 
/*     */   protected final File getTempDir()
/*     */   {
/* 133 */     return WebUtils.getTempDir(getServletContext());
/*     */   }
/*     */ 
/*     */   protected void onInit()
/*     */     throws ServiceException
/*     */   {
/*     */   }
/*     */ 
/*     */   public void destroy()
/*     */   {
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.remoting.jaxrpc.ServletEndpointSupport
 * JD-Core Version:    0.6.0
 */