/*    */ package org.springframework.remoting.jaxrpc;
/*    */ 
/*    */ import org.springframework.aop.framework.ProxyFactory;
/*    */ import org.springframework.beans.factory.BeanClassLoaderAware;
/*    */ import org.springframework.beans.factory.FactoryBean;
/*    */ import org.springframework.util.ClassUtils;
/*    */ 
/*    */ @Deprecated
/*    */ public class JaxRpcPortProxyFactoryBean extends JaxRpcPortClientInterceptor
/*    */   implements FactoryBean<Object>, BeanClassLoaderAware
/*    */ {
/* 52 */   private ClassLoader beanClassLoader = ClassUtils.getDefaultClassLoader();
/*    */   private Object serviceProxy;
/*    */ 
/*    */   public void setBeanClassLoader(ClassLoader classLoader)
/*    */   {
/* 58 */     this.beanClassLoader = classLoader;
/*    */   }
/*    */ 
/*    */   public void afterPropertiesSet()
/*    */   {
/* 63 */     if (getServiceInterface() == null)
/*    */     {
/* 66 */       if (getPortInterface() != null) {
/* 67 */         setServiceInterface(getPortInterface());
/*    */       }
/*    */       else {
/* 70 */         throw new IllegalArgumentException("Property 'serviceInterface' is required");
/*    */       }
/*    */     }
/* 73 */     super.afterPropertiesSet();
/* 74 */     this.serviceProxy = new ProxyFactory(getServiceInterface(), this).getProxy(this.beanClassLoader);
/*    */   }
/*    */ 
/*    */   public Object getObject()
/*    */   {
/* 79 */     return this.serviceProxy;
/*    */   }
/*    */ 
/*    */   public Class<?> getObjectType() {
/* 83 */     return getServiceInterface();
/*    */   }
/*    */ 
/*    */   public boolean isSingleton() {
/* 87 */     return true;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.remoting.jaxrpc.JaxRpcPortProxyFactoryBean
 * JD-Core Version:    0.6.0
 */