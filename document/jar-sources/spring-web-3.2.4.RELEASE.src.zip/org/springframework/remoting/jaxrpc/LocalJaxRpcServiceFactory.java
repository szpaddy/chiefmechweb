/*     */ package org.springframework.remoting.jaxrpc;
/*     */ 
/*     */ import java.net.URL;
/*     */ import java.util.Properties;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.rpc.Service;
/*     */ import javax.xml.rpc.ServiceException;
/*     */ import javax.xml.rpc.ServiceFactory;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ 
/*     */ @Deprecated
/*     */ public class LocalJaxRpcServiceFactory
/*     */ {
/*  52 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   private ServiceFactory serviceFactory;
/*     */   private Class serviceFactoryClass;
/*     */   private URL wsdlDocumentUrl;
/*     */   private String namespaceUri;
/*     */   private String serviceName;
/*     */   private Class jaxRpcServiceInterface;
/*     */   private Properties jaxRpcServiceProperties;
/*     */   private JaxRpcServicePostProcessor[] servicePostProcessors;
/*     */ 
/*     */   public void setServiceFactory(ServiceFactory serviceFactory)
/*     */   {
/*  78 */     this.serviceFactory = serviceFactory;
/*     */   }
/*     */ 
/*     */   public ServiceFactory getServiceFactory()
/*     */   {
/*  85 */     return this.serviceFactory;
/*     */   }
/*     */ 
/*     */   public void setServiceFactoryClass(Class serviceFactoryClass)
/*     */   {
/*  96 */     if ((serviceFactoryClass != null) && (!ServiceFactory.class.isAssignableFrom(serviceFactoryClass))) {
/*  97 */       throw new IllegalArgumentException("'serviceFactoryClass' must implement [javax.xml.rpc.ServiceFactory]");
/*     */     }
/*  99 */     this.serviceFactoryClass = serviceFactoryClass;
/*     */   }
/*     */ 
/*     */   public Class getServiceFactoryClass()
/*     */   {
/* 106 */     return this.serviceFactoryClass;
/*     */   }
/*     */ 
/*     */   public void setWsdlDocumentUrl(URL wsdlDocumentUrl)
/*     */   {
/* 113 */     this.wsdlDocumentUrl = wsdlDocumentUrl;
/*     */   }
/*     */ 
/*     */   public URL getWsdlDocumentUrl()
/*     */   {
/* 120 */     return this.wsdlDocumentUrl;
/*     */   }
/*     */ 
/*     */   public void setNamespaceUri(String namespaceUri)
/*     */   {
/* 128 */     this.namespaceUri = (namespaceUri != null ? namespaceUri.trim() : null);
/*     */   }
/*     */ 
/*     */   public String getNamespaceUri()
/*     */   {
/* 135 */     return this.namespaceUri;
/*     */   }
/*     */ 
/*     */   public void setServiceName(String serviceName)
/*     */   {
/* 146 */     this.serviceName = serviceName;
/*     */   }
/*     */ 
/*     */   public String getServiceName()
/*     */   {
/* 153 */     return this.serviceName;
/*     */   }
/*     */ 
/*     */   public void setJaxRpcServiceInterface(Class jaxRpcServiceInterface)
/*     */   {
/* 169 */     this.jaxRpcServiceInterface = jaxRpcServiceInterface;
/*     */   }
/*     */ 
/*     */   public Class getJaxRpcServiceInterface()
/*     */   {
/* 176 */     return this.jaxRpcServiceInterface;
/*     */   }
/*     */ 
/*     */   public void setJaxRpcServiceProperties(Properties jaxRpcServiceProperties)
/*     */   {
/* 186 */     this.jaxRpcServiceProperties = jaxRpcServiceProperties;
/*     */   }
/*     */ 
/*     */   public Properties getJaxRpcServiceProperties()
/*     */   {
/* 193 */     return this.jaxRpcServiceProperties;
/*     */   }
/*     */ 
/*     */   public void setServicePostProcessors(JaxRpcServicePostProcessor[] servicePostProcessors)
/*     */   {
/* 208 */     this.servicePostProcessors = servicePostProcessors;
/*     */   }
/*     */ 
/*     */   public JaxRpcServicePostProcessor[] getServicePostProcessors()
/*     */   {
/* 216 */     return this.servicePostProcessors;
/*     */   }
/*     */ 
/*     */   public Service createJaxRpcService()
/*     */     throws ServiceException
/*     */   {
/* 227 */     ServiceFactory serviceFactory = getServiceFactory();
/* 228 */     if (serviceFactory == null) {
/* 229 */       serviceFactory = createServiceFactory();
/*     */     }
/*     */ 
/* 233 */     Service service = createService(serviceFactory);
/*     */ 
/* 236 */     postProcessJaxRpcService(service);
/*     */ 
/* 238 */     return service;
/*     */   }
/*     */ 
/*     */   protected QName getQName(String name)
/*     */   {
/* 247 */     return getNamespaceUri() != null ? new QName(getNamespaceUri(), name) : new QName(name);
/*     */   }
/*     */ 
/*     */   protected ServiceFactory createServiceFactory()
/*     */     throws ServiceException
/*     */   {
/* 258 */     if (getServiceFactoryClass() != null) {
/* 259 */       return (ServiceFactory)BeanUtils.instantiateClass(getServiceFactoryClass());
/*     */     }
/*     */ 
/* 262 */     return ServiceFactory.newInstance();
/*     */   }
/*     */ 
/*     */   protected Service createService(ServiceFactory serviceFactory)
/*     */     throws ServiceException
/*     */   {
/* 276 */     if ((getServiceName() == null) && (getJaxRpcServiceInterface() == null)) {
/* 277 */       throw new IllegalArgumentException("Either 'serviceName' or 'jaxRpcServiceInterface' is required");
/*     */     }
/*     */ 
/* 280 */     if (getJaxRpcServiceInterface() != null)
/*     */     {
/* 283 */       if ((getWsdlDocumentUrl() != null) || (getJaxRpcServiceProperties() != null)) {
/* 284 */         return serviceFactory.loadService(getWsdlDocumentUrl(), getJaxRpcServiceInterface(), getJaxRpcServiceProperties());
/*     */       }
/*     */ 
/* 287 */       return serviceFactory.loadService(getJaxRpcServiceInterface());
/*     */     }
/*     */ 
/* 291 */     QName serviceQName = getQName(getServiceName());
/* 292 */     if (getJaxRpcServiceProperties() != null)
/*     */     {
/* 294 */       return serviceFactory.loadService(getWsdlDocumentUrl(), serviceQName, getJaxRpcServiceProperties());
/*     */     }
/* 296 */     if (getWsdlDocumentUrl() != null) {
/* 297 */       return serviceFactory.createService(getWsdlDocumentUrl(), serviceQName);
/*     */     }
/* 299 */     return serviceFactory.createService(serviceQName);
/*     */   }
/*     */ 
/*     */   protected void postProcessJaxRpcService(Service service)
/*     */   {
/* 315 */     JaxRpcServicePostProcessor[] postProcessors = getServicePostProcessors();
/* 316 */     if (postProcessors != null)
/* 317 */       for (int i = 0; i < postProcessors.length; i++)
/* 318 */         postProcessors[i].postProcessJaxRpcService(service);
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.remoting.jaxrpc.LocalJaxRpcServiceFactory
 * JD-Core Version:    0.6.0
 */