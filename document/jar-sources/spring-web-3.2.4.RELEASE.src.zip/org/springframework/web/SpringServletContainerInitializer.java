/*     */ package org.springframework.web;
/*     */ 
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import javax.servlet.ServletContainerInitializer;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.annotation.HandlesTypes;
/*     */ import org.springframework.core.annotation.AnnotationAwareOrderComparator;
/*     */ 
/*     */ @HandlesTypes({WebApplicationInitializer.class})
/*     */ public class SpringServletContainerInitializer
/*     */   implements ServletContainerInitializer
/*     */ {
/*     */   public void onStartup(Set<Class<?>> webAppInitializerClasses, ServletContext servletContext)
/*     */     throws ServletException
/*     */   {
/* 153 */     List initializers = new LinkedList();
/*     */ 
/* 155 */     if (webAppInitializerClasses != null) {
/* 156 */       for (Class waiClass : webAppInitializerClasses)
/*     */       {
/* 159 */         if ((!waiClass.isInterface()) && (!Modifier.isAbstract(waiClass.getModifiers())) && (WebApplicationInitializer.class.isAssignableFrom(waiClass))) {
/*     */           try
/*     */           {
/* 162 */             initializers.add((WebApplicationInitializer)waiClass.newInstance());
/*     */           }
/*     */           catch (Throwable ex) {
/* 165 */             throw new ServletException("Failed to instantiate WebApplicationInitializer class", ex);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 171 */     if (initializers.isEmpty()) {
/* 172 */       servletContext.log("No Spring WebApplicationInitializer types detected on classpath");
/* 173 */       return;
/*     */     }
/*     */ 
/* 176 */     Collections.sort(initializers, new AnnotationAwareOrderComparator());
/* 177 */     servletContext.log("Spring WebApplicationInitializers detected on classpath: " + initializers);
/*     */ 
/* 179 */     for (WebApplicationInitializer initializer : initializers)
/* 180 */       initializer.onStartup(servletContext);
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.web.SpringServletContainerInitializer
 * JD-Core Version:    0.6.0
 */