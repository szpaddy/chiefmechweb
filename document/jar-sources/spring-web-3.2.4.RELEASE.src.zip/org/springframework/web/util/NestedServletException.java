/*    */ package org.springframework.web.util;
/*    */ 
/*    */ import javax.servlet.ServletException;
/*    */ import org.springframework.core.NestedExceptionUtils;
/*    */ 
/*    */ public class NestedServletException extends ServletException
/*    */ {
/*    */   private static final long serialVersionUID = -5292377985529381145L;
/*    */ 
/*    */   public NestedServletException(String msg)
/*    */   {
/* 60 */     super(msg);
/*    */   }
/*    */ 
/*    */   public NestedServletException(String msg, Throwable cause)
/*    */   {
/* 70 */     super(msg, cause);
/*    */ 
/* 73 */     if ((getCause() == null) && (cause != null))
/* 74 */       initCause(cause);
/*    */   }
/*    */ 
/*    */   public String getMessage()
/*    */   {
/* 85 */     return NestedExceptionUtils.buildMessage(super.getMessage(), getCause());
/*    */   }
/*    */ 
/*    */   static
/*    */   {
/* 51 */     NestedExceptionUtils.class.getName();
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.web.util.NestedServletException
 * JD-Core Version:    0.6.0
 */