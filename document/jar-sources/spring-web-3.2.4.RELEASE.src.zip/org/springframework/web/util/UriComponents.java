/*     */ package org.springframework.web.util;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.net.URI;
/*     */ import java.util.Arrays;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ 
/*     */ public abstract class UriComponents
/*     */   implements Serializable
/*     */ {
/*     */   private static final String DEFAULT_ENCODING = "UTF-8";
/*  47 */   private static final Pattern NAMES_PATTERN = Pattern.compile("\\{([^/]+?)\\}");
/*     */   private final String scheme;
/*     */   private final String fragment;
/*     */ 
/*     */   protected UriComponents(String scheme, String fragment)
/*     */   {
/*  56 */     this.scheme = scheme;
/*  57 */     this.fragment = fragment;
/*     */   }
/*     */ 
/*     */   public final String getScheme()
/*     */   {
/*  67 */     return this.scheme;
/*     */   }
/*     */ 
/*     */   public abstract String getSchemeSpecificPart();
/*     */ 
/*     */   public abstract String getUserInfo();
/*     */ 
/*     */   public abstract String getHost();
/*     */ 
/*     */   public abstract int getPort();
/*     */ 
/*     */   public abstract String getPath();
/*     */ 
/*     */   public abstract List<String> getPathSegments();
/*     */ 
/*     */   public abstract String getQuery();
/*     */ 
/*     */   public abstract MultiValueMap<String, String> getQueryParams();
/*     */ 
/*     */   public final String getFragment()
/*     */   {
/* 114 */     return this.fragment;
/*     */   }
/*     */ 
/*     */   public final UriComponents encode()
/*     */   {
/*     */     try
/*     */     {
/* 125 */       return encode("UTF-8");
/*     */     } catch (UnsupportedEncodingException e) {
/*     */     }
/* 128 */     throw new InternalError("\"UTF-8\" not supported");
/*     */   }
/*     */ 
/*     */   public abstract UriComponents encode(String paramString)
/*     */     throws UnsupportedEncodingException;
/*     */ 
/*     */   public final UriComponents expand(Map<String, ?> uriVariables)
/*     */   {
/* 149 */     Assert.notNull(uriVariables, "'uriVariables' must not be null");
/* 150 */     return expandInternal(new MapTemplateVariables(uriVariables));
/*     */   }
/*     */ 
/*     */   public final UriComponents expand(Object[] uriVariableValues)
/*     */   {
/* 160 */     Assert.notNull(uriVariableValues, "'uriVariableValues' must not be null");
/* 161 */     return expandInternal(new VarArgsTemplateVariables(uriVariableValues));
/*     */   }
/*     */ 
/*     */   abstract UriComponents expandInternal(UriTemplateVariables paramUriTemplateVariables);
/*     */ 
/*     */   public abstract UriComponents normalize();
/*     */ 
/*     */   public abstract String toUriString();
/*     */ 
/*     */   public abstract URI toUri();
/*     */ 
/*     */   public final String toString()
/*     */   {
/* 190 */     return toUriString();
/*     */   }
/*     */ 
/*     */   static String expandUriComponent(String source, UriTemplateVariables uriVariables)
/*     */   {
/* 197 */     if (source == null) {
/* 198 */       return null;
/*     */     }
/* 200 */     if (source.indexOf('{') == -1) {
/* 201 */       return source;
/*     */     }
/* 203 */     Matcher matcher = NAMES_PATTERN.matcher(source);
/* 204 */     StringBuffer sb = new StringBuffer();
/* 205 */     while (matcher.find()) {
/* 206 */       String match = matcher.group(1);
/* 207 */       String variableName = getVariableName(match);
/* 208 */       Object variableValue = uriVariables.getValue(variableName);
/* 209 */       String variableValueString = getVariableValueAsString(variableValue);
/* 210 */       String replacement = Matcher.quoteReplacement(variableValueString);
/* 211 */       matcher.appendReplacement(sb, replacement);
/*     */     }
/* 213 */     matcher.appendTail(sb);
/* 214 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   private static String getVariableName(String match) {
/* 218 */     int colonIdx = match.indexOf(':');
/* 219 */     return colonIdx != -1 ? match.substring(0, colonIdx) : match;
/*     */   }
/*     */ 
/*     */   private static String getVariableValueAsString(Object variableValue) {
/* 223 */     return variableValue != null ? variableValue.toString() : "";
/*     */   }
/*     */ 
/*     */   private static class VarArgsTemplateVariables
/*     */     implements UriComponents.UriTemplateVariables
/*     */   {
/*     */     private final Iterator<Object> valueIterator;
/*     */ 
/*     */     public VarArgsTemplateVariables(Object[] uriVariableValues)
/*     */     {
/* 265 */       this.valueIterator = Arrays.asList(uriVariableValues).iterator();
/*     */     }
/*     */ 
/*     */     public Object getValue(String name) {
/* 269 */       if (!this.valueIterator.hasNext()) {
/* 270 */         throw new IllegalArgumentException("Not enough variable values available to expand '" + name + "'");
/*     */       }
/*     */ 
/* 273 */       return this.valueIterator.next();
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class MapTemplateVariables
/*     */     implements UriComponents.UriTemplateVariables
/*     */   {
/*     */     private final Map<String, ?> uriVariables;
/*     */ 
/*     */     public MapTemplateVariables(Map<String, ?> uriVariables)
/*     */     {
/* 245 */       this.uriVariables = uriVariables;
/*     */     }
/*     */ 
/*     */     public Object getValue(String name) {
/* 249 */       if (!this.uriVariables.containsKey(name)) {
/* 250 */         throw new IllegalArgumentException("Map has no value for '" + name + "'");
/*     */       }
/* 252 */       return this.uriVariables.get(name);
/*     */     }
/*     */   }
/*     */ 
/*     */   static abstract interface UriTemplateVariables
/*     */   {
/*     */     public abstract Object getValue(String paramString);
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.web.util.UriComponents
 * JD-Core Version:    0.6.0
 */