/*     */ package org.springframework.web.util;
/*     */ 
/*     */ import java.net.URI;
/*     */ import java.util.ArrayList;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.LinkedMultiValueMap;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class UriComponentsBuilder
/*     */ {
/*  59 */   private static final Pattern QUERY_PARAM_PATTERN = Pattern.compile("([^&=]+)(=?)([^&]+)?");
/*     */   private static final String SCHEME_PATTERN = "([^:/?#]+):";
/*     */   private static final String HTTP_PATTERN = "(?i)(http|https):";
/*     */   private static final String USERINFO_PATTERN = "([^@/]*)";
/*     */   private static final String HOST_PATTERN = "([^/?#:]*)";
/*     */   private static final String PORT_PATTERN = "(\\d*)";
/*     */   private static final String PATH_PATTERN = "([^?#]*)";
/*     */   private static final String QUERY_PATTERN = "([^#]*)";
/*     */   private static final String LAST_PATTERN = "(.*)";
/*  78 */   private static final Pattern URI_PATTERN = Pattern.compile("^(([^:/?#]+):)?(//(([^@/]*)@)?([^/?#:]*)(:(\\d*))?)?([^?#]*)(\\?([^#]*))?(#(.*))?");
/*     */ 
/*  82 */   private static final Pattern HTTP_URL_PATTERN = Pattern.compile("^(?i)(http|https):(//(([^@/]*)@)?([^/?#:]*)(:(\\d*))?)?([^?#]*)(\\?(.*))?");
/*     */   private String scheme;
/*     */   private String ssp;
/*     */   private String userInfo;
/*     */   private String host;
/*  95 */   private int port = -1;
/*     */ 
/*  97 */   private CompositePathComponentBuilder pathBuilder = new CompositePathComponentBuilder();
/*     */ 
/*  99 */   private final MultiValueMap<String, String> queryParams = new LinkedMultiValueMap();
/*     */   private String fragment;
/*     */ 
/*     */   public static UriComponentsBuilder newInstance()
/*     */   {
/* 121 */     return new UriComponentsBuilder();
/*     */   }
/*     */ 
/*     */   public static UriComponentsBuilder fromPath(String path)
/*     */   {
/* 130 */     UriComponentsBuilder builder = new UriComponentsBuilder();
/* 131 */     builder.path(path);
/* 132 */     return builder;
/*     */   }
/*     */ 
/*     */   public static UriComponentsBuilder fromUri(URI uri)
/*     */   {
/* 141 */     UriComponentsBuilder builder = new UriComponentsBuilder();
/* 142 */     builder.uri(uri);
/* 143 */     return builder;
/*     */   }
/*     */ 
/*     */   public static UriComponentsBuilder fromUriString(String uri)
/*     */   {
/* 161 */     Assert.hasLength(uri, "'uri' must not be empty");
/* 162 */     Matcher m = URI_PATTERN.matcher(uri);
/* 163 */     if (m.matches()) {
/* 164 */       UriComponentsBuilder builder = new UriComponentsBuilder();
/* 165 */       String scheme = m.group(2);
/* 166 */       String userInfo = m.group(5);
/* 167 */       String host = m.group(6);
/* 168 */       String port = m.group(8);
/* 169 */       String path = m.group(9);
/* 170 */       String query = m.group(11);
/* 171 */       String fragment = m.group(13);
/* 172 */       boolean opaque = false;
/* 173 */       if (StringUtils.hasLength(scheme)) {
/* 174 */         String s = uri.substring(scheme.length());
/* 175 */         if (!s.startsWith(":/")) {
/* 176 */           opaque = true;
/*     */         }
/*     */       }
/* 179 */       builder.scheme(scheme);
/* 180 */       if (opaque) {
/* 181 */         String ssp = uri.substring(scheme.length()).substring(1);
/* 182 */         if (StringUtils.hasLength(fragment)) {
/* 183 */           ssp = ssp.substring(0, ssp.length() - (fragment.length() + 1));
/*     */         }
/* 185 */         builder.schemeSpecificPart(ssp);
/*     */       }
/*     */       else {
/* 188 */         builder.userInfo(userInfo);
/* 189 */         builder.host(host);
/* 190 */         if (StringUtils.hasLength(port)) {
/* 191 */           builder.port(Integer.parseInt(port));
/*     */         }
/* 193 */         builder.path(path);
/* 194 */         builder.query(query);
/*     */       }
/* 196 */       if (StringUtils.hasText(fragment)) {
/* 197 */         builder.fragment(fragment);
/*     */       }
/* 199 */       return builder;
/*     */     }
/*     */ 
/* 202 */     throw new IllegalArgumentException("[" + uri + "] is not a valid URI");
/*     */   }
/*     */ 
/*     */   public static UriComponentsBuilder fromHttpUrl(String httpUrl)
/*     */   {
/* 221 */     Assert.notNull(httpUrl, "'httpUrl' must not be null");
/* 222 */     Matcher m = HTTP_URL_PATTERN.matcher(httpUrl);
/* 223 */     if (m.matches()) {
/* 224 */       UriComponentsBuilder builder = new UriComponentsBuilder();
/*     */ 
/* 226 */       String scheme = m.group(1);
/* 227 */       builder.scheme(scheme != null ? scheme.toLowerCase() : scheme);
/* 228 */       builder.userInfo(m.group(4));
/* 229 */       builder.host(m.group(5));
/* 230 */       String port = m.group(7);
/* 231 */       if (StringUtils.hasLength(port)) {
/* 232 */         builder.port(Integer.parseInt(port));
/*     */       }
/* 234 */       builder.path(m.group(8));
/* 235 */       builder.query(m.group(10));
/*     */ 
/* 237 */       return builder;
/*     */     }
/*     */ 
/* 240 */     throw new IllegalArgumentException("[" + httpUrl + "] is not a valid HTTP URL");
/*     */   }
/*     */ 
/*     */   public UriComponents build()
/*     */   {
/* 252 */     return build(false);
/*     */   }
/*     */ 
/*     */   public UriComponents build(boolean encoded)
/*     */   {
/* 263 */     if (this.ssp != null) {
/* 264 */       return new OpaqueUriComponents(this.scheme, this.ssp, this.fragment);
/*     */     }
/*     */ 
/* 267 */     return new HierarchicalUriComponents(this.scheme, this.userInfo, this.host, this.port, this.pathBuilder.build(), this.queryParams, this.fragment, encoded, true);
/*     */   }
/*     */ 
/*     */   public UriComponents buildAndExpand(Map<String, ?> uriVariables)
/*     */   {
/* 280 */     return build(false).expand(uriVariables);
/*     */   }
/*     */ 
/*     */   public UriComponents buildAndExpand(Object[] uriVariableValues)
/*     */   {
/* 291 */     return build(false).expand(uriVariableValues);
/*     */   }
/*     */ 
/*     */   public UriComponentsBuilder uri(URI uri)
/*     */   {
/* 303 */     Assert.notNull(uri, "'uri' must not be null");
/* 304 */     this.scheme = uri.getScheme();
/* 305 */     if (uri.isOpaque()) {
/* 306 */       this.ssp = uri.getRawSchemeSpecificPart();
/* 307 */       resetHierarchicalComponents();
/*     */     }
/*     */     else {
/* 310 */       if (uri.getRawUserInfo() != null) {
/* 311 */         this.userInfo = uri.getRawUserInfo();
/*     */       }
/* 313 */       if (uri.getHost() != null) {
/* 314 */         this.host = uri.getHost();
/*     */       }
/* 316 */       if (uri.getPort() != -1) {
/* 317 */         this.port = uri.getPort();
/*     */       }
/* 319 */       if (StringUtils.hasLength(uri.getRawPath())) {
/* 320 */         this.pathBuilder = new CompositePathComponentBuilder(uri.getRawPath());
/*     */       }
/* 322 */       if (StringUtils.hasLength(uri.getRawQuery())) {
/* 323 */         this.queryParams.clear();
/* 324 */         query(uri.getRawQuery());
/*     */       }
/* 326 */       resetSchemeSpecificPart();
/*     */     }
/* 328 */     if (uri.getRawFragment() != null) {
/* 329 */       this.fragment = uri.getRawFragment();
/*     */     }
/* 331 */     return this;
/*     */   }
/*     */ 
/*     */   private void resetHierarchicalComponents() {
/* 335 */     this.userInfo = null;
/* 336 */     this.host = null;
/* 337 */     this.port = -1;
/* 338 */     this.pathBuilder = new CompositePathComponentBuilder();
/* 339 */     this.queryParams.clear();
/*     */   }
/*     */ 
/*     */   private void resetSchemeSpecificPart() {
/* 343 */     this.ssp = null;
/*     */   }
/*     */ 
/*     */   public UriComponentsBuilder scheme(String scheme)
/*     */   {
/* 353 */     this.scheme = scheme;
/* 354 */     return this;
/*     */   }
/*     */ 
/*     */   public UriComponentsBuilder schemeSpecificPart(String ssp)
/*     */   {
/* 366 */     this.ssp = ssp;
/* 367 */     resetHierarchicalComponents();
/* 368 */     return this;
/*     */   }
/*     */ 
/*     */   public UriComponentsBuilder userInfo(String userInfo)
/*     */   {
/* 379 */     this.userInfo = userInfo;
/* 380 */     resetSchemeSpecificPart();
/* 381 */     return this;
/*     */   }
/*     */ 
/*     */   public UriComponentsBuilder host(String host)
/*     */   {
/* 391 */     this.host = host;
/* 392 */     resetSchemeSpecificPart();
/* 393 */     return this;
/*     */   }
/*     */ 
/*     */   public UriComponentsBuilder port(int port)
/*     */   {
/* 402 */     Assert.isTrue(port >= -1, "'port' must not be < -1");
/* 403 */     this.port = port;
/* 404 */     resetSchemeSpecificPart();
/* 405 */     return this;
/*     */   }
/*     */ 
/*     */   public UriComponentsBuilder path(String path)
/*     */   {
/* 415 */     this.pathBuilder.addPath(path);
/* 416 */     resetSchemeSpecificPart();
/* 417 */     return this;
/*     */   }
/*     */ 
/*     */   public UriComponentsBuilder replacePath(String path)
/*     */   {
/* 426 */     this.pathBuilder = new CompositePathComponentBuilder(path);
/* 427 */     resetSchemeSpecificPart();
/* 428 */     return this;
/*     */   }
/*     */ 
/*     */   public UriComponentsBuilder pathSegment(String[] pathSegments)
/*     */     throws IllegalArgumentException
/*     */   {
/* 438 */     Assert.notNull(pathSegments, "'segments' must not be null");
/* 439 */     this.pathBuilder.addPathSegments(pathSegments);
/* 440 */     resetSchemeSpecificPart();
/* 441 */     return this;
/*     */   }
/*     */ 
/*     */   public UriComponentsBuilder query(String query)
/*     */   {
/* 460 */     if (query != null) {
/* 461 */       Matcher m = QUERY_PARAM_PATTERN.matcher(query);
/* 462 */       while (m.find()) {
/* 463 */         String name = m.group(1);
/* 464 */         String eq = m.group(2);
/* 465 */         String value = m.group(3);
/* 466 */         queryParam(name, new Object[] { StringUtils.hasLength(eq) ? "" : value != null ? value : null });
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 471 */       this.queryParams.clear();
/*     */     }
/* 473 */     resetSchemeSpecificPart();
/* 474 */     return this;
/*     */   }
/*     */ 
/*     */   public UriComponentsBuilder replaceQuery(String query)
/*     */   {
/* 483 */     this.queryParams.clear();
/* 484 */     query(query);
/* 485 */     resetSchemeSpecificPart();
/* 486 */     return this;
/*     */   }
/*     */ 
/*     */   public UriComponentsBuilder queryParam(String name, Object[] values)
/*     */   {
/* 499 */     Assert.notNull(name, "'name' must not be null");
/* 500 */     if (!ObjectUtils.isEmpty(values)) {
/* 501 */       for (Object value : values) {
/* 502 */         String valueAsString = value != null ? value.toString() : null;
/* 503 */         this.queryParams.add(name, valueAsString);
/*     */       }
/*     */     }
/*     */     else {
/* 507 */       this.queryParams.add(name, null);
/*     */     }
/* 509 */     resetSchemeSpecificPart();
/* 510 */     return this;
/*     */   }
/*     */ 
/*     */   public UriComponentsBuilder replaceQueryParam(String name, Object[] values)
/*     */   {
/* 522 */     Assert.notNull(name, "'name' must not be null");
/* 523 */     this.queryParams.remove(name);
/* 524 */     if (!ObjectUtils.isEmpty(values)) {
/* 525 */       queryParam(name, values);
/*     */     }
/* 527 */     resetSchemeSpecificPart();
/* 528 */     return this;
/*     */   }
/*     */ 
/*     */   public UriComponentsBuilder fragment(String fragment)
/*     */   {
/* 539 */     if (fragment != null) {
/* 540 */       Assert.hasLength(fragment, "'fragment' must not be empty");
/* 541 */       this.fragment = fragment;
/*     */     }
/*     */     else {
/* 544 */       this.fragment = null;
/*     */     }
/* 546 */     return this;
/*     */   }
/*     */ 
/*     */   private static class PathSegmentComponentBuilder
/*     */     implements UriComponentsBuilder.PathComponentBuilder
/*     */   {
/* 655 */     private final List<String> pathSegments = new LinkedList();
/*     */ 
/*     */     public void append(String[] pathSegments) {
/* 658 */       for (String pathSegment : pathSegments)
/* 659 */         if (StringUtils.hasText(pathSegment))
/* 660 */           this.pathSegments.add(pathSegment);
/*     */     }
/*     */ 
/*     */     public HierarchicalUriComponents.PathComponent build()
/*     */     {
/* 666 */       return this.pathSegments.isEmpty() ? null : new HierarchicalUriComponents.PathSegmentComponent(this.pathSegments);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class FullPathComponentBuilder
/*     */     implements UriComponentsBuilder.PathComponentBuilder
/*     */   {
/* 630 */     private final StringBuilder path = new StringBuilder();
/*     */ 
/*     */     public void append(String path) {
/* 633 */       this.path.append(path);
/*     */     }
/*     */ 
/*     */     public HierarchicalUriComponents.PathComponent build() {
/* 637 */       if (this.path.length() == 0) {
/* 638 */         return null;
/*     */       }
/* 640 */       String path = this.path.toString().replace("//", "/");
/* 641 */       return new HierarchicalUriComponents.FullPathComponent(path);
/*     */     }
/*     */ 
/*     */     public void removeTrailingSlash() {
/* 645 */       int index = this.path.length() - 1;
/* 646 */       if (this.path.charAt(index) == '/')
/* 647 */         this.path.deleteCharAt(index);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class CompositePathComponentBuilder
/*     */     implements UriComponentsBuilder.PathComponentBuilder
/*     */   {
/* 558 */     private final LinkedList<UriComponentsBuilder.PathComponentBuilder> componentBuilders = new LinkedList();
/*     */ 
/*     */     public CompositePathComponentBuilder() {
/*     */     }
/*     */ 
/*     */     public CompositePathComponentBuilder(String path) {
/* 564 */       addPath(path);
/*     */     }
/*     */ 
/*     */     public void addPathSegments(String[] pathSegments) {
/* 568 */       if (!ObjectUtils.isEmpty(pathSegments)) {
/* 569 */         UriComponentsBuilder.PathSegmentComponentBuilder psBuilder = (UriComponentsBuilder.PathSegmentComponentBuilder)getLastBuilder(UriComponentsBuilder.PathSegmentComponentBuilder.class);
/* 570 */         UriComponentsBuilder.FullPathComponentBuilder fpBuilder = (UriComponentsBuilder.FullPathComponentBuilder)getLastBuilder(UriComponentsBuilder.FullPathComponentBuilder.class);
/* 571 */         if (psBuilder == null) {
/* 572 */           psBuilder = new UriComponentsBuilder.PathSegmentComponentBuilder(null);
/* 573 */           this.componentBuilders.add(psBuilder);
/* 574 */           if (fpBuilder != null) {
/* 575 */             fpBuilder.removeTrailingSlash();
/*     */           }
/*     */         }
/* 578 */         psBuilder.append(pathSegments);
/*     */       }
/*     */     }
/*     */ 
/*     */     public void addPath(String path) {
/* 583 */       if (StringUtils.hasText(path)) {
/* 584 */         UriComponentsBuilder.PathSegmentComponentBuilder psBuilder = (UriComponentsBuilder.PathSegmentComponentBuilder)getLastBuilder(UriComponentsBuilder.PathSegmentComponentBuilder.class);
/* 585 */         UriComponentsBuilder.FullPathComponentBuilder fpBuilder = (UriComponentsBuilder.FullPathComponentBuilder)getLastBuilder(UriComponentsBuilder.FullPathComponentBuilder.class);
/* 586 */         if (psBuilder != null) {
/* 587 */           path = "/" + path;
/*     */         }
/* 589 */         if (fpBuilder == null) {
/* 590 */           fpBuilder = new UriComponentsBuilder.FullPathComponentBuilder(null);
/* 591 */           this.componentBuilders.add(fpBuilder);
/*     */         }
/* 593 */         fpBuilder.append(path);
/*     */       }
/*     */     }
/*     */ 
/*     */     private <T> T getLastBuilder(Class<T> builderClass)
/*     */     {
/* 599 */       if (!this.componentBuilders.isEmpty()) {
/* 600 */         UriComponentsBuilder.PathComponentBuilder last = (UriComponentsBuilder.PathComponentBuilder)this.componentBuilders.getLast();
/* 601 */         if (builderClass.isInstance(last)) {
/* 602 */           return last;
/*     */         }
/*     */       }
/* 605 */       return null;
/*     */     }
/*     */ 
/*     */     public HierarchicalUriComponents.PathComponent build() {
/* 609 */       int size = this.componentBuilders.size();
/* 610 */       List components = new ArrayList(size);
/* 611 */       for (UriComponentsBuilder.PathComponentBuilder componentBuilder : this.componentBuilders) {
/* 612 */         HierarchicalUriComponents.PathComponent pathComponent = componentBuilder.build();
/* 613 */         if (pathComponent != null) {
/* 614 */           components.add(pathComponent);
/*     */         }
/*     */       }
/* 617 */       if (components.isEmpty()) {
/* 618 */         return HierarchicalUriComponents.NULL_PATH_COMPONENT;
/*     */       }
/* 620 */       if (components.size() == 1) {
/* 621 */         return (HierarchicalUriComponents.PathComponent)components.get(0);
/*     */       }
/* 623 */       return new HierarchicalUriComponents.PathComponentComposite(components);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static abstract interface PathComponentBuilder
/*     */   {
/*     */     public abstract HierarchicalUriComponents.PathComponent build();
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.web.util.UriComponentsBuilder
 * JD-Core Version:    0.6.0
 */