/*     */ package org.springframework.web.util;
/*     */ 
/*     */ public class JavaScriptUtils
/*     */ {
/*     */   public static String javaScriptEscape(String input)
/*     */   {
/*  41 */     if (input == null) {
/*  42 */       return input;
/*     */     }
/*     */ 
/*  45 */     StringBuilder filtered = new StringBuilder(input.length());
/*  46 */     char prevChar = '\000';
/*     */ 
/*  48 */     for (int i = 0; i < input.length(); i++) {
/*  49 */       char c = input.charAt(i);
/*  50 */       if (c == '"') {
/*  51 */         filtered.append("\\\"");
/*     */       }
/*  53 */       else if (c == '\'') {
/*  54 */         filtered.append("\\'");
/*     */       }
/*  56 */       else if (c == '\\') {
/*  57 */         filtered.append("\\\\");
/*     */       }
/*  59 */       else if (c == '/') {
/*  60 */         filtered.append("\\/");
/*     */       }
/*  62 */       else if (c == '\t') {
/*  63 */         filtered.append("\\t");
/*     */       }
/*  65 */       else if (c == '\n') {
/*  66 */         if (prevChar != '\r') {
/*  67 */           filtered.append("\\n");
/*     */         }
/*     */       }
/*  70 */       else if (c == '\r') {
/*  71 */         filtered.append("\\n");
/*     */       }
/*  73 */       else if (c == '\f') {
/*  74 */         filtered.append("\\f");
/*     */       }
/*  76 */       else if (c == '\b') {
/*  77 */         filtered.append("\\b");
/*     */       }
/*  80 */       else if (c == '\013') {
/*  81 */         filtered.append("\\v");
/*     */       }
/*  83 */       else if (c == '<') {
/*  84 */         filtered.append("\\u003C");
/*     */       }
/*  86 */       else if (c == '>') {
/*  87 */         filtered.append("\\u003E");
/*     */       }
/*  90 */       else if (c == ' ') {
/*  91 */         filtered.append("\\u2028");
/*     */       }
/*  94 */       else if (c == ' ') {
/*  95 */         filtered.append("\\u2029");
/*     */       }
/*     */       else {
/*  98 */         filtered.append(c);
/*     */       }
/* 100 */       prevChar = c;
/*     */     }
/*     */ 
/* 103 */     return filtered.toString();
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.web.util.JavaScriptUtils
 * JD-Core Version:    0.6.0
 */