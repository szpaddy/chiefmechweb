/*     */ package org.springframework.web.util;
/*     */ 
/*     */ import javax.servlet.http.Cookie;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class CookieGenerator
/*     */ {
/*     */   public static final String DEFAULT_COOKIE_PATH = "/";
/*     */ 
/*     */   @Deprecated
/*     */   public static final int DEFAULT_COOKIE_MAX_AGE = 2147483647;
/*  55 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   private String cookieName;
/*     */   private String cookieDomain;
/*  61 */   private String cookiePath = "/";
/*     */ 
/*  63 */   private Integer cookieMaxAge = null;
/*     */ 
/*  65 */   private boolean cookieSecure = false;
/*     */ 
/*  67 */   private boolean cookieHttpOnly = false;
/*     */ 
/*     */   public void setCookieName(String cookieName)
/*     */   {
/*  75 */     this.cookieName = cookieName;
/*     */   }
/*     */ 
/*     */   public String getCookieName()
/*     */   {
/*  82 */     return this.cookieName;
/*     */   }
/*     */ 
/*     */   public void setCookieDomain(String cookieDomain)
/*     */   {
/*  91 */     this.cookieDomain = cookieDomain;
/*     */   }
/*     */ 
/*     */   public String getCookieDomain()
/*     */   {
/*  98 */     return this.cookieDomain;
/*     */   }
/*     */ 
/*     */   public void setCookiePath(String cookiePath)
/*     */   {
/* 107 */     this.cookiePath = cookiePath;
/*     */   }
/*     */ 
/*     */   public String getCookiePath()
/*     */   {
/* 114 */     return this.cookiePath;
/*     */   }
/*     */ 
/*     */   public void setCookieMaxAge(Integer cookieMaxAge)
/*     */   {
/* 123 */     this.cookieMaxAge = cookieMaxAge;
/*     */   }
/*     */ 
/*     */   public Integer getCookieMaxAge()
/*     */   {
/* 130 */     return this.cookieMaxAge;
/*     */   }
/*     */ 
/*     */   public void setCookieSecure(boolean cookieSecure)
/*     */   {
/* 140 */     this.cookieSecure = cookieSecure;
/*     */   }
/*     */ 
/*     */   public boolean isCookieSecure()
/*     */   {
/* 148 */     return this.cookieSecure;
/*     */   }
/*     */ 
/*     */   public void setCookieHttpOnly(boolean cookieHttpOnly)
/*     */   {
/* 157 */     this.cookieHttpOnly = cookieHttpOnly;
/*     */   }
/*     */ 
/*     */   public boolean isCookieHttpOnly()
/*     */   {
/* 164 */     return this.cookieHttpOnly;
/*     */   }
/*     */ 
/*     */   public void addCookie(HttpServletResponse response, String cookieValue)
/*     */   {
/* 180 */     Cookie cookie = createCookie(cookieValue);
/* 181 */     Integer maxAge = getCookieMaxAge();
/* 182 */     if (maxAge != null) {
/* 183 */       cookie.setMaxAge(maxAge.intValue());
/*     */     }
/* 185 */     if (isCookieSecure()) {
/* 186 */       cookie.setSecure(true);
/*     */     }
/* 188 */     if (isCookieHttpOnly()) {
/* 189 */       cookie.setHttpOnly(true);
/*     */     }
/* 191 */     response.addCookie(cookie);
/* 192 */     if (this.logger.isDebugEnabled())
/* 193 */       this.logger.debug("Added cookie with name [" + getCookieName() + "] and value [" + cookieValue + "]");
/*     */   }
/*     */ 
/*     */   public void removeCookie(HttpServletResponse response)
/*     */   {
/* 207 */     Cookie cookie = createCookie("");
/* 208 */     cookie.setMaxAge(0);
/* 209 */     response.addCookie(cookie);
/* 210 */     if (this.logger.isDebugEnabled())
/* 211 */       this.logger.debug("Removed cookie with name [" + getCookieName() + "]");
/*     */   }
/*     */ 
/*     */   protected Cookie createCookie(String cookieValue)
/*     */   {
/* 225 */     Cookie cookie = new Cookie(getCookieName(), cookieValue);
/* 226 */     if (getCookieDomain() != null) {
/* 227 */       cookie.setDomain(getCookieDomain());
/*     */     }
/* 229 */     cookie.setPath(getCookiePath());
/* 230 */     return cookie;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.web.util.CookieGenerator
 * JD-Core Version:    0.6.0
 */