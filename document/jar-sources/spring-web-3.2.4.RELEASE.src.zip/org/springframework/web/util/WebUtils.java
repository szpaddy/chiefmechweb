/*     */ package org.springframework.web.util;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Properties;
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.TreeMap;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.ServletRequestWrapper;
/*     */ import javax.servlet.ServletResponse;
/*     */ import javax.servlet.ServletResponseWrapper;
/*     */ import javax.servlet.http.Cookie;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.LinkedMultiValueMap;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public abstract class WebUtils
/*     */ {
/*     */   public static final String INCLUDE_REQUEST_URI_ATTRIBUTE = "javax.servlet.include.request_uri";
/*     */   public static final String INCLUDE_CONTEXT_PATH_ATTRIBUTE = "javax.servlet.include.context_path";
/*     */   public static final String INCLUDE_SERVLET_PATH_ATTRIBUTE = "javax.servlet.include.servlet_path";
/*     */   public static final String INCLUDE_PATH_INFO_ATTRIBUTE = "javax.servlet.include.path_info";
/*     */   public static final String INCLUDE_QUERY_STRING_ATTRIBUTE = "javax.servlet.include.query_string";
/*     */   public static final String FORWARD_REQUEST_URI_ATTRIBUTE = "javax.servlet.forward.request_uri";
/*     */   public static final String FORWARD_CONTEXT_PATH_ATTRIBUTE = "javax.servlet.forward.context_path";
/*     */   public static final String FORWARD_SERVLET_PATH_ATTRIBUTE = "javax.servlet.forward.servlet_path";
/*     */   public static final String FORWARD_PATH_INFO_ATTRIBUTE = "javax.servlet.forward.path_info";
/*     */   public static final String FORWARD_QUERY_STRING_ATTRIBUTE = "javax.servlet.forward.query_string";
/*     */   public static final String ERROR_STATUS_CODE_ATTRIBUTE = "javax.servlet.error.status_code";
/*     */   public static final String ERROR_EXCEPTION_TYPE_ATTRIBUTE = "javax.servlet.error.exception_type";
/*     */   public static final String ERROR_MESSAGE_ATTRIBUTE = "javax.servlet.error.message";
/*     */   public static final String ERROR_EXCEPTION_ATTRIBUTE = "javax.servlet.error.exception";
/*     */   public static final String ERROR_REQUEST_URI_ATTRIBUTE = "javax.servlet.error.request_uri";
/*     */   public static final String ERROR_SERVLET_NAME_ATTRIBUTE = "javax.servlet.error.servlet_name";
/*     */   public static final String CONTENT_TYPE_CHARSET_PREFIX = ";charset=";
/*     */   public static final String DEFAULT_CHARACTER_ENCODING = "ISO-8859-1";
/*     */   public static final String TEMP_DIR_CONTEXT_ATTRIBUTE = "javax.servlet.context.tempdir";
/*     */   public static final String HTML_ESCAPE_CONTEXT_PARAM = "defaultHtmlEscape";
/*     */   public static final String WEB_APP_ROOT_KEY_PARAM = "webAppRootKey";
/*     */   public static final String DEFAULT_WEB_APP_ROOT_KEY = "webapp.root";
/* 120 */   public static final String[] SUBMIT_IMAGE_SUFFIXES = { ".x", ".y" };
/*     */ 
/* 123 */   public static final String SESSION_MUTEX_ATTRIBUTE = WebUtils.class.getName() + ".MUTEX";
/*     */ 
/*     */   public static void setWebAppRootSystemProperty(ServletContext servletContext)
/*     */     throws IllegalStateException
/*     */   {
/* 141 */     Assert.notNull(servletContext, "ServletContext must not be null");
/* 142 */     String root = servletContext.getRealPath("/");
/* 143 */     if (root == null) {
/* 144 */       throw new IllegalStateException("Cannot set web app root system property when WAR file is not expanded");
/*     */     }
/*     */ 
/* 147 */     String param = servletContext.getInitParameter("webAppRootKey");
/* 148 */     String key = param != null ? param : "webapp.root";
/* 149 */     String oldValue = System.getProperty(key);
/* 150 */     if ((oldValue != null) && (!StringUtils.pathEquals(oldValue, root))) {
/* 151 */       throw new IllegalStateException("Web app root system property already set to different value: '" + key + "' = [" + oldValue + "] instead of [" + root + "] - " + "Choose unique values for the 'webAppRootKey' context-param in your web.xml files!");
/*     */     }
/*     */ 
/* 156 */     System.setProperty(key, root);
/* 157 */     servletContext.log("Set web app root system property: '" + key + "' = [" + root + "]");
/*     */   }
/*     */ 
/*     */   public static void removeWebAppRootSystemProperty(ServletContext servletContext)
/*     */   {
/* 167 */     Assert.notNull(servletContext, "ServletContext must not be null");
/* 168 */     String param = servletContext.getInitParameter("webAppRootKey");
/* 169 */     String key = param != null ? param : "webapp.root";
/* 170 */     System.getProperties().remove(key);
/*     */   }
/*     */ 
/*     */   public static boolean isDefaultHtmlEscape(ServletContext servletContext)
/*     */   {
/* 181 */     if (servletContext == null) {
/* 182 */       return false;
/*     */     }
/* 184 */     String param = servletContext.getInitParameter("defaultHtmlEscape");
/* 185 */     return Boolean.valueOf(param).booleanValue();
/*     */   }
/*     */ 
/*     */   public static Boolean getDefaultHtmlEscape(ServletContext servletContext)
/*     */   {
/* 199 */     if (servletContext == null) {
/* 200 */       return null;
/*     */     }
/* 202 */     Assert.notNull(servletContext, "ServletContext must not be null");
/* 203 */     String param = servletContext.getInitParameter("defaultHtmlEscape");
/* 204 */     return StringUtils.hasText(param) ? Boolean.valueOf(param) : null;
/*     */   }
/*     */ 
/*     */   public static File getTempDir(ServletContext servletContext)
/*     */   {
/* 214 */     Assert.notNull(servletContext, "ServletContext must not be null");
/* 215 */     return (File)servletContext.getAttribute("javax.servlet.context.tempdir");
/*     */   }
/*     */ 
/*     */   public static String getRealPath(ServletContext servletContext, String path)
/*     */     throws FileNotFoundException
/*     */   {
/* 232 */     Assert.notNull(servletContext, "ServletContext must not be null");
/*     */ 
/* 234 */     if (!path.startsWith("/")) {
/* 235 */       path = "/" + path;
/*     */     }
/* 237 */     String realPath = servletContext.getRealPath(path);
/* 238 */     if (realPath == null) {
/* 239 */       throw new FileNotFoundException("ServletContext resource [" + path + "] cannot be resolved to absolute file path - " + "web application archive not expanded?");
/*     */     }
/*     */ 
/* 243 */     return realPath;
/*     */   }
/*     */ 
/*     */   public static String getSessionId(HttpServletRequest request)
/*     */   {
/* 253 */     Assert.notNull(request, "Request must not be null");
/* 254 */     HttpSession session = request.getSession(false);
/* 255 */     return session != null ? session.getId() : null;
/*     */   }
/*     */ 
/*     */   public static Object getSessionAttribute(HttpServletRequest request, String name)
/*     */   {
/* 267 */     Assert.notNull(request, "Request must not be null");
/* 268 */     HttpSession session = request.getSession(false);
/* 269 */     return session != null ? session.getAttribute(name) : null;
/*     */   }
/*     */ 
/*     */   public static Object getRequiredSessionAttribute(HttpServletRequest request, String name)
/*     */     throws IllegalStateException
/*     */   {
/* 284 */     Object attr = getSessionAttribute(request, name);
/* 285 */     if (attr == null) {
/* 286 */       throw new IllegalStateException("No session attribute '" + name + "' found");
/*     */     }
/* 288 */     return attr;
/*     */   }
/*     */ 
/*     */   public static void setSessionAttribute(HttpServletRequest request, String name, Object value)
/*     */   {
/* 300 */     Assert.notNull(request, "Request must not be null");
/* 301 */     if (value != null) {
/* 302 */       request.getSession().setAttribute(name, value);
/*     */     }
/*     */     else {
/* 305 */       HttpSession session = request.getSession(false);
/* 306 */       if (session != null)
/* 307 */         session.removeAttribute(name);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static Object getOrCreateSessionAttribute(HttpSession session, String name, Class clazz)
/*     */     throws IllegalArgumentException
/*     */   {
/* 325 */     Assert.notNull(session, "Session must not be null");
/* 326 */     Object sessionObject = session.getAttribute(name);
/* 327 */     if (sessionObject == null) {
/*     */       try {
/* 329 */         sessionObject = clazz.newInstance();
/*     */       }
/*     */       catch (InstantiationException ex) {
/* 332 */         throw new IllegalArgumentException("Could not instantiate class [" + clazz.getName() + "] for session attribute '" + name + "': " + ex.getMessage());
/*     */       }
/*     */       catch (IllegalAccessException ex)
/*     */       {
/* 337 */         throw new IllegalArgumentException("Could not access default constructor of class [" + clazz.getName() + "] for session attribute '" + name + "': " + ex.getMessage());
/*     */       }
/*     */ 
/* 341 */       session.setAttribute(name, sessionObject);
/*     */     }
/* 343 */     return sessionObject;
/*     */   }
/*     */ 
/*     */   public static Object getSessionMutex(HttpSession session)
/*     */   {
/* 367 */     Assert.notNull(session, "Session must not be null");
/* 368 */     Object mutex = session.getAttribute(SESSION_MUTEX_ATTRIBUTE);
/* 369 */     if (mutex == null) {
/* 370 */       mutex = session;
/*     */     }
/* 372 */     return mutex;
/*     */   }
/*     */ 
/*     */   public static <T> T getNativeRequest(ServletRequest request, Class<T> requiredType)
/*     */   {
/* 386 */     if (requiredType != null) {
/* 387 */       if (requiredType.isInstance(request)) {
/* 388 */         return request;
/*     */       }
/* 390 */       if ((request instanceof ServletRequestWrapper)) {
/* 391 */         return getNativeRequest(((ServletRequestWrapper)request).getRequest(), requiredType);
/*     */       }
/*     */     }
/* 394 */     return null;
/*     */   }
/*     */ 
/*     */   public static <T> T getNativeResponse(ServletResponse response, Class<T> requiredType)
/*     */   {
/* 407 */     if (requiredType != null) {
/* 408 */       if (requiredType.isInstance(response)) {
/* 409 */         return response;
/*     */       }
/* 411 */       if ((response instanceof ServletResponseWrapper)) {
/* 412 */         return getNativeResponse(((ServletResponseWrapper)response).getResponse(), requiredType);
/*     */       }
/*     */     }
/* 415 */     return null;
/*     */   }
/*     */ 
/*     */   public static boolean isIncludeRequest(ServletRequest request)
/*     */   {
/* 428 */     return request.getAttribute("javax.servlet.include.request_uri") != null;
/*     */   }
/*     */ 
/*     */   public static void exposeForwardRequestAttributes(HttpServletRequest request)
/*     */   {
/* 445 */     exposeRequestAttributeIfNotPresent(request, "javax.servlet.forward.request_uri", request.getRequestURI());
/* 446 */     exposeRequestAttributeIfNotPresent(request, "javax.servlet.forward.context_path", request.getContextPath());
/* 447 */     exposeRequestAttributeIfNotPresent(request, "javax.servlet.forward.servlet_path", request.getServletPath());
/* 448 */     exposeRequestAttributeIfNotPresent(request, "javax.servlet.forward.path_info", request.getPathInfo());
/* 449 */     exposeRequestAttributeIfNotPresent(request, "javax.servlet.forward.query_string", request.getQueryString());
/*     */   }
/*     */ 
/*     */   public static void exposeErrorRequestAttributes(HttpServletRequest request, Throwable ex, String servletName)
/*     */   {
/* 471 */     exposeRequestAttributeIfNotPresent(request, "javax.servlet.error.status_code", Integer.valueOf(200));
/* 472 */     exposeRequestAttributeIfNotPresent(request, "javax.servlet.error.exception_type", ex.getClass());
/* 473 */     exposeRequestAttributeIfNotPresent(request, "javax.servlet.error.message", ex.getMessage());
/* 474 */     exposeRequestAttributeIfNotPresent(request, "javax.servlet.error.exception", ex);
/* 475 */     exposeRequestAttributeIfNotPresent(request, "javax.servlet.error.request_uri", request.getRequestURI());
/* 476 */     exposeRequestAttributeIfNotPresent(request, "javax.servlet.error.servlet_name", servletName);
/*     */   }
/*     */ 
/*     */   private static void exposeRequestAttributeIfNotPresent(ServletRequest request, String name, Object value)
/*     */   {
/* 486 */     if (request.getAttribute(name) == null)
/* 487 */       request.setAttribute(name, value);
/*     */   }
/*     */ 
/*     */   public static void clearErrorRequestAttributes(HttpServletRequest request)
/*     */   {
/* 503 */     request.removeAttribute("javax.servlet.error.status_code");
/* 504 */     request.removeAttribute("javax.servlet.error.exception_type");
/* 505 */     request.removeAttribute("javax.servlet.error.message");
/* 506 */     request.removeAttribute("javax.servlet.error.exception");
/* 507 */     request.removeAttribute("javax.servlet.error.request_uri");
/* 508 */     request.removeAttribute("javax.servlet.error.servlet_name");
/*     */   }
/*     */ 
/*     */   public static void exposeRequestAttributes(ServletRequest request, Map<String, ?> attributes)
/*     */   {
/* 518 */     Assert.notNull(request, "Request must not be null");
/* 519 */     Assert.notNull(attributes, "Attributes Map must not be null");
/* 520 */     for (Map.Entry entry : attributes.entrySet())
/* 521 */       request.setAttribute((String)entry.getKey(), entry.getValue());
/*     */   }
/*     */ 
/*     */   public static Cookie getCookie(HttpServletRequest request, String name)
/*     */   {
/* 533 */     Assert.notNull(request, "Request must not be null");
/* 534 */     Cookie[] cookies = request.getCookies();
/* 535 */     if (cookies != null) {
/* 536 */       for (Cookie cookie : cookies) {
/* 537 */         if (name.equals(cookie.getName())) {
/* 538 */           return cookie;
/*     */         }
/*     */       }
/*     */     }
/* 542 */     return null;
/*     */   }
/*     */ 
/*     */   public static boolean hasSubmitParameter(ServletRequest request, String name)
/*     */   {
/* 555 */     Assert.notNull(request, "Request must not be null");
/* 556 */     if (request.getParameter(name) != null) {
/* 557 */       return true;
/*     */     }
/* 559 */     for (String suffix : SUBMIT_IMAGE_SUFFIXES) {
/* 560 */       if (request.getParameter(name + suffix) != null) {
/* 561 */         return true;
/*     */       }
/*     */     }
/* 564 */     return false;
/*     */   }
/*     */ 
/*     */   public static String findParameterValue(ServletRequest request, String name)
/*     */   {
/* 577 */     return findParameterValue(request.getParameterMap(), name);
/*     */   }
/*     */ 
/*     */   public static String findParameterValue(Map<String, ?> parameters, String name)
/*     */   {
/* 605 */     Object value = parameters.get(name);
/* 606 */     if ((value instanceof String[])) {
/* 607 */       String[] values = (String[])(String[])value;
/* 608 */       return values.length > 0 ? values[0] : null;
/*     */     }
/* 610 */     if (value != null) {
/* 611 */       return value.toString();
/*     */     }
/*     */ 
/* 614 */     String prefix = name + "_";
/* 615 */     for (String paramName : parameters.keySet()) {
/* 616 */       if (paramName.startsWith(prefix))
/*     */       {
/* 618 */         for (String suffix : SUBMIT_IMAGE_SUFFIXES) {
/* 619 */           if (paramName.endsWith(suffix)) {
/* 620 */             return paramName.substring(prefix.length(), paramName.length() - suffix.length());
/*     */           }
/*     */         }
/* 623 */         return paramName.substring(prefix.length());
/*     */       }
/*     */     }
/*     */ 
/* 627 */     return null;
/*     */   }
/*     */ 
/*     */   public static Map<String, Object> getParametersStartingWith(ServletRequest request, String prefix)
/*     */   {
/* 645 */     Assert.notNull(request, "Request must not be null");
/* 646 */     Enumeration paramNames = request.getParameterNames();
/* 647 */     Map params = new TreeMap();
/* 648 */     if (prefix == null) {
/* 649 */       prefix = "";
/*     */     }
/* 651 */     while ((paramNames != null) && (paramNames.hasMoreElements())) {
/* 652 */       String paramName = (String)paramNames.nextElement();
/* 653 */       if (("".equals(prefix)) || (paramName.startsWith(prefix))) {
/* 654 */         String unprefixed = paramName.substring(prefix.length());
/* 655 */         String[] values = request.getParameterValues(paramName);
/* 656 */         if ((values != null) && (values.length != 0))
/*     */         {
/* 659 */           if (values.length > 1) {
/* 660 */             params.put(unprefixed, values);
/*     */           }
/*     */           else
/* 663 */             params.put(unprefixed, values[0]);
/*     */         }
/*     */       }
/*     */     }
/* 667 */     return params;
/*     */   }
/*     */ 
/*     */   public static int getTargetPage(ServletRequest request, String paramPrefix, int currentPage)
/*     */   {
/* 680 */     Enumeration paramNames = request.getParameterNames();
/* 681 */     while (paramNames.hasMoreElements()) {
/* 682 */       String paramName = (String)paramNames.nextElement();
/* 683 */       if (paramName.startsWith(paramPrefix)) {
/* 684 */         for (int i = 0; i < SUBMIT_IMAGE_SUFFIXES.length; i++) {
/* 685 */           String suffix = SUBMIT_IMAGE_SUFFIXES[i];
/* 686 */           if (paramName.endsWith(suffix)) {
/* 687 */             paramName = paramName.substring(0, paramName.length() - suffix.length());
/*     */           }
/*     */         }
/* 690 */         return Integer.parseInt(paramName.substring(paramPrefix.length()));
/*     */       }
/*     */     }
/* 693 */     return currentPage;
/*     */   }
/*     */ 
/*     */   public static String extractFilenameFromUrlPath(String urlPath)
/*     */   {
/* 704 */     String filename = extractFullFilenameFromUrlPath(urlPath);
/* 705 */     int dotIndex = filename.lastIndexOf('.');
/* 706 */     if (dotIndex != -1) {
/* 707 */       filename = filename.substring(0, dotIndex);
/*     */     }
/* 709 */     return filename;
/*     */   }
/*     */ 
/*     */   public static String extractFullFilenameFromUrlPath(String urlPath)
/*     */   {
/* 719 */     int end = urlPath.indexOf(';');
/* 720 */     if (end == -1) {
/* 721 */       end = urlPath.indexOf('?');
/* 722 */       if (end == -1) {
/* 723 */         end = urlPath.length();
/*     */       }
/*     */     }
/* 726 */     int begin = urlPath.lastIndexOf('/', end) + 1;
/* 727 */     return urlPath.substring(begin, end);
/*     */   }
/*     */ 
/*     */   public static MultiValueMap<String, String> parseMatrixVariables(String matrixVariables)
/*     */   {
/* 740 */     MultiValueMap result = new LinkedMultiValueMap();
/* 741 */     if (!StringUtils.hasText(matrixVariables)) {
/* 742 */       return result;
/*     */     }
/* 744 */     StringTokenizer pairs = new StringTokenizer(matrixVariables, ";");
/* 745 */     while (pairs.hasMoreTokens()) {
/* 746 */       String pair = pairs.nextToken();
/* 747 */       int index = pair.indexOf('=');
/* 748 */       if (index != -1) {
/* 749 */         String name = pair.substring(0, index);
/* 750 */         String rawValue = pair.substring(index + 1);
/* 751 */         for (String value : StringUtils.commaDelimitedListToStringArray(rawValue))
/* 752 */           result.add(name, value);
/*     */       }
/*     */       else
/*     */       {
/* 756 */         result.add(pair, "");
/*     */       }
/*     */     }
/* 759 */     return result;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.web.util.WebUtils
 * JD-Core Version:    0.6.0
 */