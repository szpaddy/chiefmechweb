/*     */ package org.springframework.web.util;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.Serializable;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map.Entry;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.LinkedMultiValueMap;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ final class HierarchicalUriComponents extends UriComponents
/*     */ {
/*     */   private static final char PATH_DELIMITER = '/';
/*     */   private final String userInfo;
/*     */   private final String host;
/*     */   private final int port;
/*     */   private final PathComponent path;
/*     */   private final MultiValueMap<String, String> queryParams;
/*     */   private final boolean encoded;
/* 764 */   static final PathComponent NULL_PATH_COMPONENT = new PathComponent() {
/*     */     public String getPath() {
/* 766 */       return null;
/*     */     }
/*     */     public List<String> getPathSegments() {
/* 769 */       return Collections.emptyList();
/*     */     }
/*     */     public HierarchicalUriComponents.PathComponent encode(String encoding) throws UnsupportedEncodingException {
/* 772 */       return this;
/*     */     }
/*     */     public void verify() {
/*     */     }
/*     */     public HierarchicalUriComponents.PathComponent expand(UriComponents.UriTemplateVariables uriVariables) {
/* 777 */       return this;
/*     */     }
/*     */ 
/*     */     public boolean equals(Object obj) {
/* 781 */       return this == obj;
/*     */     }
/*     */ 
/*     */     public int hashCode() {
/* 785 */       return 42;
/*     */     }
/* 764 */   };
/*     */ 
/*     */   HierarchicalUriComponents(String scheme, String userInfo, String host, int port, PathComponent path, MultiValueMap<String, String> queryParams, String fragment, boolean encoded, boolean verify)
/*     */   {
/*  79 */     super(scheme, fragment);
/*  80 */     this.userInfo = userInfo;
/*  81 */     this.host = host;
/*  82 */     this.port = port;
/*  83 */     this.path = (path != null ? path : NULL_PATH_COMPONENT);
/*  84 */     this.queryParams = CollectionUtils.unmodifiableMultiValueMap(queryParams != null ? queryParams : new LinkedMultiValueMap(0));
/*     */ 
/*  86 */     this.encoded = encoded;
/*  87 */     if (verify)
/*  88 */       verify();
/*     */   }
/*     */ 
/*     */   public String getSchemeSpecificPart()
/*     */   {
/*  97 */     return null;
/*     */   }
/*     */ 
/*     */   public String getUserInfo()
/*     */   {
/* 102 */     return this.userInfo;
/*     */   }
/*     */ 
/*     */   public String getHost()
/*     */   {
/* 107 */     return this.host;
/*     */   }
/*     */ 
/*     */   public int getPort()
/*     */   {
/* 112 */     return this.port;
/*     */   }
/*     */ 
/*     */   public String getPath()
/*     */   {
/* 117 */     return this.path.getPath();
/*     */   }
/*     */ 
/*     */   public List<String> getPathSegments()
/*     */   {
/* 122 */     return this.path.getPathSegments();
/*     */   }
/*     */ 
/*     */   public String getQuery()
/*     */   {
/* 127 */     if (!this.queryParams.isEmpty()) {
/* 128 */       StringBuilder queryBuilder = new StringBuilder();
/* 129 */       for (Map.Entry entry : this.queryParams.entrySet()) {
/* 130 */         name = (String)entry.getKey();
/* 131 */         List values = (List)entry.getValue();
/* 132 */         if (CollectionUtils.isEmpty(values)) {
/* 133 */           if (queryBuilder.length() != 0) {
/* 134 */             queryBuilder.append('&');
/*     */           }
/* 136 */           queryBuilder.append(name);
/*     */         }
/*     */         else {
/* 139 */           for (i$ = values.iterator(); i$.hasNext(); ) { Object value = i$.next();
/* 140 */             if (queryBuilder.length() != 0) {
/* 141 */               queryBuilder.append('&');
/*     */             }
/* 143 */             queryBuilder.append(name);
/*     */ 
/* 145 */             if (value != null) {
/* 146 */               queryBuilder.append('=');
/* 147 */               queryBuilder.append(value.toString());
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */       String name;
/*     */       Iterator i$;
/* 152 */       return queryBuilder.toString();
/*     */     }
/*     */ 
/* 155 */     return null;
/*     */   }
/*     */ 
/*     */   public MultiValueMap<String, String> getQueryParams()
/*     */   {
/* 164 */     return this.queryParams;
/*     */   }
/*     */ 
/*     */   public HierarchicalUriComponents encode(String encoding)
/*     */     throws UnsupportedEncodingException
/*     */   {
/* 179 */     Assert.hasLength(encoding, "'encoding' must not be empty");
/* 180 */     if (this.encoded) {
/* 181 */       return this;
/*     */     }
/* 183 */     String encodedScheme = encodeUriComponent(getScheme(), encoding, Type.SCHEME);
/* 184 */     String encodedUserInfo = encodeUriComponent(this.userInfo, encoding, Type.USER_INFO);
/* 185 */     String encodedHost = encodeUriComponent(this.host, encoding, Type.HOST);
/* 186 */     PathComponent encodedPath = this.path.encode(encoding);
/* 187 */     MultiValueMap encodedQueryParams = new LinkedMultiValueMap(this.queryParams.size());
/*     */ 
/* 189 */     for (Map.Entry entry : this.queryParams.entrySet()) {
/* 190 */       String encodedName = encodeUriComponent((String)entry.getKey(), encoding, Type.QUERY_PARAM);
/* 191 */       List encodedValues = new ArrayList(((List)entry.getValue()).size());
/* 192 */       for (String value : (List)entry.getValue()) {
/* 193 */         String encodedValue = encodeUriComponent(value, encoding, Type.QUERY_PARAM);
/* 194 */         encodedValues.add(encodedValue);
/*     */       }
/* 196 */       encodedQueryParams.put(encodedName, encodedValues);
/*     */     }
/* 198 */     String encodedFragment = encodeUriComponent(getFragment(), encoding, Type.FRAGMENT);
/* 199 */     return new HierarchicalUriComponents(encodedScheme, encodedUserInfo, encodedHost, this.port, encodedPath, encodedQueryParams, encodedFragment, true, false);
/*     */   }
/*     */ 
/*     */   static String encodeUriComponent(String source, String encoding, Type type)
/*     */     throws UnsupportedEncodingException
/*     */   {
/* 213 */     if (source == null) {
/* 214 */       return null;
/*     */     }
/* 216 */     Assert.hasLength(encoding, "'encoding' must not be empty");
/* 217 */     byte[] bytes = encodeBytes(source.getBytes(encoding), type);
/* 218 */     return new String(bytes, "US-ASCII");
/*     */   }
/*     */ 
/*     */   private static byte[] encodeBytes(byte[] source, Type type) {
/* 222 */     Assert.notNull(source, "'source' must not be null");
/* 223 */     Assert.notNull(type, "'type' must not be null");
/* 224 */     ByteArrayOutputStream bos = new ByteArrayOutputStream(source.length);
/* 225 */     for (byte b : source) {
/* 226 */       if (b < 0) {
/* 227 */         b = (byte)(b + 256);
/*     */       }
/* 229 */       if (type.isAllowed(b)) {
/* 230 */         bos.write(b);
/*     */       }
/*     */       else {
/* 233 */         bos.write(37);
/* 234 */         char hex1 = Character.toUpperCase(Character.forDigit(b >> 4 & 0xF, 16));
/* 235 */         char hex2 = Character.toUpperCase(Character.forDigit(b & 0xF, 16));
/* 236 */         bos.write(hex1);
/* 237 */         bos.write(hex2);
/*     */       }
/*     */     }
/* 240 */     return bos.toByteArray();
/*     */   }
/*     */ 
/*     */   private void verify()
/*     */   {
/* 252 */     if (!this.encoded) {
/* 253 */       return;
/*     */     }
/* 255 */     verifyUriComponent(getScheme(), Type.SCHEME);
/* 256 */     verifyUriComponent(this.userInfo, Type.USER_INFO);
/* 257 */     verifyUriComponent(this.host, Type.HOST);
/* 258 */     this.path.verify();
/* 259 */     for (Map.Entry entry : this.queryParams.entrySet()) {
/* 260 */       verifyUriComponent((String)entry.getKey(), Type.QUERY_PARAM);
/* 261 */       for (String value : (List)entry.getValue()) {
/* 262 */         verifyUriComponent(value, Type.QUERY_PARAM);
/*     */       }
/*     */     }
/* 265 */     verifyUriComponent(getFragment(), Type.FRAGMENT);
/*     */   }
/*     */ 
/*     */   private static void verifyUriComponent(String source, Type type) {
/* 269 */     if (source == null) {
/* 270 */       return;
/*     */     }
/* 272 */     int length = source.length();
/* 273 */     for (int i = 0; i < length; i++) {
/* 274 */       char ch = source.charAt(i);
/* 275 */       if (ch == '%') {
/* 276 */         if (i + 2 < length) {
/* 277 */           char hex1 = source.charAt(i + 1);
/* 278 */           char hex2 = source.charAt(i + 2);
/* 279 */           int u = Character.digit(hex1, 16);
/* 280 */           int l = Character.digit(hex2, 16);
/* 281 */           if ((u == -1) || (l == -1)) {
/* 282 */             throw new IllegalArgumentException("Invalid encoded sequence \"" + source.substring(i) + "\"");
/*     */           }
/* 284 */           i += 2;
/*     */         }
/*     */         else {
/* 287 */           throw new IllegalArgumentException("Invalid encoded sequence \"" + source.substring(i) + "\"");
/*     */         }
/*     */       }
/* 290 */       else if (!type.isAllowed(ch))
/* 291 */         throw new IllegalArgumentException("Invalid character '" + ch + "' for " + type.name() + " in \"" + source + "\"");
/*     */     }
/*     */   }
/*     */ 
/*     */   protected HierarchicalUriComponents expandInternal(UriComponents.UriTemplateVariables uriVariables)
/*     */   {
/* 302 */     Assert.state(!this.encoded, "Cannot expand an already encoded UriComponents object");
/* 303 */     String expandedScheme = expandUriComponent(getScheme(), uriVariables);
/* 304 */     String expandedUserInfo = expandUriComponent(this.userInfo, uriVariables);
/* 305 */     String expandedHost = expandUriComponent(this.host, uriVariables);
/* 306 */     PathComponent expandedPath = this.path.expand(uriVariables);
/* 307 */     MultiValueMap expandedQueryParams = new LinkedMultiValueMap(this.queryParams.size());
/*     */ 
/* 309 */     for (Map.Entry entry : this.queryParams.entrySet()) {
/* 310 */       String expandedName = expandUriComponent((String)entry.getKey(), uriVariables);
/* 311 */       List expandedValues = new ArrayList(((List)entry.getValue()).size());
/* 312 */       for (String value : (List)entry.getValue()) {
/* 313 */         String expandedValue = expandUriComponent(value, uriVariables);
/* 314 */         expandedValues.add(expandedValue);
/*     */       }
/* 316 */       expandedQueryParams.put(expandedName, expandedValues);
/*     */     }
/* 318 */     String expandedFragment = expandUriComponent(getFragment(), uriVariables);
/* 319 */     return new HierarchicalUriComponents(expandedScheme, expandedUserInfo, expandedHost, this.port, expandedPath, expandedQueryParams, expandedFragment, false, false);
/*     */   }
/*     */ 
/*     */   public UriComponents normalize()
/*     */   {
/* 329 */     String normalizedPath = StringUtils.cleanPath(getPath());
/* 330 */     return new HierarchicalUriComponents(getScheme(), this.userInfo, this.host, this.port, new FullPathComponent(normalizedPath), this.queryParams, getFragment(), this.encoded, false);
/*     */   }
/*     */ 
/*     */   public String toUriString()
/*     */   {
/* 343 */     StringBuilder uriBuilder = new StringBuilder();
/* 344 */     if (getScheme() != null) {
/* 345 */       uriBuilder.append(getScheme());
/* 346 */       uriBuilder.append(':');
/*     */     }
/* 348 */     if ((this.userInfo != null) || (this.host != null)) {
/* 349 */       uriBuilder.append("//");
/* 350 */       if (this.userInfo != null) {
/* 351 */         uriBuilder.append(this.userInfo);
/* 352 */         uriBuilder.append('@');
/*     */       }
/* 354 */       if (this.host != null) {
/* 355 */         uriBuilder.append(this.host);
/*     */       }
/* 357 */       if (this.port != -1) {
/* 358 */         uriBuilder.append(':');
/* 359 */         uriBuilder.append(this.port);
/*     */       }
/*     */     }
/* 362 */     String path = getPath();
/* 363 */     if (StringUtils.hasLength(path)) {
/* 364 */       if ((uriBuilder.length() != 0) && (path.charAt(0) != '/')) {
/* 365 */         uriBuilder.append('/');
/*     */       }
/* 367 */       uriBuilder.append(path);
/*     */     }
/* 369 */     String query = getQuery();
/* 370 */     if (query != null) {
/* 371 */       uriBuilder.append('?');
/* 372 */       uriBuilder.append(query);
/*     */     }
/* 374 */     if (getFragment() != null) {
/* 375 */       uriBuilder.append('#');
/* 376 */       uriBuilder.append(getFragment());
/*     */     }
/* 378 */     return uriBuilder.toString();
/*     */   }
/*     */ 
/*     */   public URI toUri()
/*     */   {
/*     */     try
/*     */     {
/* 387 */       if (this.encoded) {
/* 388 */         return new URI(toString());
/*     */       }
/*     */ 
/* 391 */       String path = getPath();
/* 392 */       if ((StringUtils.hasLength(path)) && (path.charAt(0) != '/'))
/*     */       {
/* 394 */         if ((getScheme() != null) || (getUserInfo() != null) || (getHost() != null) || (getPort() != -1)) {
/* 395 */           path = '/' + path;
/*     */         }
/*     */       }
/* 398 */       return new URI(getScheme(), getUserInfo(), getHost(), getPort(), path, getQuery(), getFragment());
/*     */     }
/*     */     catch (URISyntaxException ex)
/*     */     {
/*     */     }
/* 403 */     throw new IllegalStateException("Could not create URI object: " + ex.getMessage(), ex);
/*     */   }
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 409 */     if (this == obj) {
/* 410 */       return true;
/*     */     }
/* 412 */     if (!(obj instanceof HierarchicalUriComponents)) {
/* 413 */       return false;
/*     */     }
/* 415 */     HierarchicalUriComponents other = (HierarchicalUriComponents)obj;
/* 416 */     return (ObjectUtils.nullSafeEquals(getScheme(), other.getScheme())) && (ObjectUtils.nullSafeEquals(getUserInfo(), other.getUserInfo())) && (ObjectUtils.nullSafeEquals(getHost(), other.getHost())) && (getPort() == other.getPort()) && (this.path.equals(other.path)) && (this.queryParams.equals(other.queryParams)) && (ObjectUtils.nullSafeEquals(getFragment(), other.getFragment()));
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 427 */     int result = ObjectUtils.nullSafeHashCode(getScheme());
/* 428 */     result = 31 * result + ObjectUtils.nullSafeHashCode(this.userInfo);
/* 429 */     result = 31 * result + ObjectUtils.nullSafeHashCode(this.host);
/* 430 */     result = 31 * result + this.port;
/* 431 */     result = 31 * result + this.path.hashCode();
/* 432 */     result = 31 * result + this.queryParams.hashCode();
/* 433 */     result = 31 * result + ObjectUtils.nullSafeHashCode(getFragment());
/* 434 */     return result;
/*     */   }
/*     */ 
/*     */   static final class PathComponentComposite
/*     */     implements HierarchicalUriComponents.PathComponent
/*     */   {
/*     */     private final List<HierarchicalUriComponents.PathComponent> pathComponents;
/*     */ 
/*     */     public PathComponentComposite(List<HierarchicalUriComponents.PathComponent> pathComponents)
/*     */     {
/* 718 */       this.pathComponents = pathComponents;
/*     */     }
/*     */ 
/*     */     public String getPath() {
/* 722 */       StringBuilder pathBuilder = new StringBuilder();
/* 723 */       for (HierarchicalUriComponents.PathComponent pathComponent : this.pathComponents) {
/* 724 */         pathBuilder.append(pathComponent.getPath());
/*     */       }
/* 726 */       return pathBuilder.toString();
/*     */     }
/*     */ 
/*     */     public List<String> getPathSegments() {
/* 730 */       List result = new ArrayList();
/* 731 */       for (HierarchicalUriComponents.PathComponent pathComponent : this.pathComponents) {
/* 732 */         result.addAll(pathComponent.getPathSegments());
/*     */       }
/* 734 */       return result;
/*     */     }
/*     */ 
/*     */     public HierarchicalUriComponents.PathComponent encode(String encoding) throws UnsupportedEncodingException {
/* 738 */       List encodedComponents = new ArrayList(this.pathComponents.size());
/* 739 */       for (HierarchicalUriComponents.PathComponent pathComponent : this.pathComponents) {
/* 740 */         encodedComponents.add(pathComponent.encode(encoding));
/*     */       }
/* 742 */       return new PathComponentComposite(encodedComponents);
/*     */     }
/*     */ 
/*     */     public void verify() {
/* 746 */       for (HierarchicalUriComponents.PathComponent pathComponent : this.pathComponents)
/* 747 */         pathComponent.verify();
/*     */     }
/*     */ 
/*     */     public HierarchicalUriComponents.PathComponent expand(UriComponents.UriTemplateVariables uriVariables)
/*     */     {
/* 752 */       List expandedComponents = new ArrayList(this.pathComponents.size());
/* 753 */       for (HierarchicalUriComponents.PathComponent pathComponent : this.pathComponents) {
/* 754 */         expandedComponents.add(pathComponent.expand(uriVariables));
/*     */       }
/* 756 */       return new PathComponentComposite(expandedComponents);
/*     */     }
/*     */   }
/*     */ 
/*     */   static final class PathSegmentComponent
/*     */     implements HierarchicalUriComponents.PathComponent
/*     */   {
/*     */     private final List<String> pathSegments;
/*     */ 
/*     */     public PathSegmentComponent(List<String> pathSegments)
/*     */     {
/* 651 */       this.pathSegments = Collections.unmodifiableList(pathSegments);
/*     */     }
/*     */ 
/*     */     public String getPath() {
/* 655 */       StringBuilder pathBuilder = new StringBuilder();
/* 656 */       pathBuilder.append('/');
/* 657 */       for (Iterator iterator = this.pathSegments.iterator(); iterator.hasNext(); ) {
/* 658 */         String pathSegment = (String)iterator.next();
/* 659 */         pathBuilder.append(pathSegment);
/* 660 */         if (iterator.hasNext()) {
/* 661 */           pathBuilder.append('/');
/*     */         }
/*     */       }
/* 664 */       return pathBuilder.toString();
/*     */     }
/*     */ 
/*     */     public List<String> getPathSegments() {
/* 668 */       return this.pathSegments;
/*     */     }
/*     */ 
/*     */     public HierarchicalUriComponents.PathComponent encode(String encoding) throws UnsupportedEncodingException {
/* 672 */       List pathSegments = getPathSegments();
/* 673 */       List encodedPathSegments = new ArrayList(pathSegments.size());
/* 674 */       for (String pathSegment : pathSegments) {
/* 675 */         String encodedPathSegment = HierarchicalUriComponents.encodeUriComponent(pathSegment, encoding, HierarchicalUriComponents.Type.PATH_SEGMENT);
/* 676 */         encodedPathSegments.add(encodedPathSegment);
/*     */       }
/* 678 */       return new PathSegmentComponent(encodedPathSegments);
/*     */     }
/*     */ 
/*     */     public void verify() {
/* 682 */       for (String pathSegment : getPathSegments())
/* 683 */         HierarchicalUriComponents.access$100(pathSegment, HierarchicalUriComponents.Type.PATH_SEGMENT);
/*     */     }
/*     */ 
/*     */     public HierarchicalUriComponents.PathComponent expand(UriComponents.UriTemplateVariables uriVariables)
/*     */     {
/* 688 */       List pathSegments = getPathSegments();
/* 689 */       List expandedPathSegments = new ArrayList(pathSegments.size());
/* 690 */       for (String pathSegment : pathSegments) {
/* 691 */         String expandedPathSegment = UriComponents.expandUriComponent(pathSegment, uriVariables);
/* 692 */         expandedPathSegments.add(expandedPathSegment);
/*     */       }
/* 694 */       return new PathSegmentComponent(expandedPathSegments);
/*     */     }
/*     */ 
/*     */     public boolean equals(Object obj)
/*     */     {
/* 699 */       return (this == obj) || (((obj instanceof PathSegmentComponent)) && (getPathSegments().equals(((PathSegmentComponent)obj).getPathSegments())));
/*     */     }
/*     */ 
/*     */     public int hashCode()
/*     */     {
/* 705 */       return getPathSegments().hashCode();
/*     */     }
/*     */   }
/*     */ 
/*     */   static final class FullPathComponent
/*     */     implements HierarchicalUriComponents.PathComponent
/*     */   {
/*     */     private final String path;
/*     */ 
/*     */     public FullPathComponent(String path)
/*     */     {
/* 603 */       this.path = path;
/*     */     }
/*     */ 
/*     */     public String getPath() {
/* 607 */       return this.path;
/*     */     }
/*     */ 
/*     */     public List<String> getPathSegments() {
/* 611 */       String delimiter = new String(new char[] { '/' });
/* 612 */       String[] pathSegments = StringUtils.tokenizeToStringArray(this.path, delimiter);
/* 613 */       return Collections.unmodifiableList(Arrays.asList(pathSegments));
/*     */     }
/*     */ 
/*     */     public HierarchicalUriComponents.PathComponent encode(String encoding) throws UnsupportedEncodingException {
/* 617 */       String encodedPath = HierarchicalUriComponents.encodeUriComponent(getPath(), encoding, HierarchicalUriComponents.Type.PATH);
/* 618 */       return new FullPathComponent(encodedPath);
/*     */     }
/*     */ 
/*     */     public void verify() {
/* 622 */       HierarchicalUriComponents.access$100(this.path, HierarchicalUriComponents.Type.PATH);
/*     */     }
/*     */ 
/*     */     public HierarchicalUriComponents.PathComponent expand(UriComponents.UriTemplateVariables uriVariables) {
/* 626 */       String expandedPath = UriComponents.expandUriComponent(getPath(), uriVariables);
/* 627 */       return new FullPathComponent(expandedPath);
/*     */     }
/*     */ 
/*     */     public boolean equals(Object obj)
/*     */     {
/* 632 */       return (this == obj) || (((obj instanceof FullPathComponent)) && (getPath().equals(((FullPathComponent)obj).getPath())));
/*     */     }
/*     */ 
/*     */     public int hashCode()
/*     */     {
/* 638 */       return getPath().hashCode();
/*     */     }
/*     */   }
/*     */ 
/*     */   static abstract interface PathComponent extends Serializable
/*     */   {
/*     */     public abstract String getPath();
/*     */ 
/*     */     public abstract List<String> getPathSegments();
/*     */ 
/*     */     public abstract PathComponent encode(String paramString)
/*     */       throws UnsupportedEncodingException;
/*     */ 
/*     */     public abstract void verify();
/*     */ 
/*     */     public abstract PathComponent expand(UriComponents.UriTemplateVariables paramUriTemplateVariables);
/*     */   }
/*     */ 
/*     */   static abstract enum Type
/*     */   {
/* 447 */     SCHEME, 
/*     */ 
/* 453 */     AUTHORITY, 
/*     */ 
/* 459 */     USER_INFO, 
/*     */ 
/* 465 */     HOST, 
/*     */ 
/* 471 */     PORT, 
/*     */ 
/* 477 */     PATH, 
/*     */ 
/* 483 */     PATH_SEGMENT, 
/*     */ 
/* 489 */     QUERY, 
/*     */ 
/* 495 */     QUERY_PARAM, 
/*     */ 
/* 506 */     FRAGMENT;
/*     */ 
/*     */     public abstract boolean isAllowed(int paramInt);
/*     */ 
/*     */     protected boolean isAlpha(int c)
/*     */     {
/* 524 */       return ((c >= 97) && (c <= 122)) || ((c >= 65) && (c <= 90));
/*     */     }
/*     */ 
/*     */     protected boolean isDigit(int c)
/*     */     {
/* 532 */       return (c >= 48) && (c <= 57);
/*     */     }
/*     */ 
/*     */     protected boolean isGenericDelimiter(int c)
/*     */     {
/* 540 */       return (58 == c) || (47 == c) || (63 == c) || (35 == c) || (91 == c) || (93 == c) || (64 == c);
/*     */     }
/*     */ 
/*     */     protected boolean isSubDelimiter(int c)
/*     */     {
/* 548 */       return (33 == c) || (36 == c) || (38 == c) || (39 == c) || (40 == c) || (41 == c) || (42 == c) || (43 == c) || (44 == c) || (59 == c) || (61 == c);
/*     */     }
/*     */ 
/*     */     protected boolean isReserved(char c)
/*     */     {
/* 557 */       return (isGenericDelimiter(c)) || (isReserved(c));
/*     */     }
/*     */ 
/*     */     protected boolean isUnreserved(int c)
/*     */     {
/* 565 */       return (isAlpha(c)) || (isDigit(c)) || (45 == c) || (46 == c) || (95 == c) || (126 == c);
/*     */     }
/*     */ 
/*     */     protected boolean isPchar(int c)
/*     */     {
/* 573 */       return (isUnreserved(c)) || (isSubDelimiter(c)) || (58 == c) || (64 == c);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.web.util.HierarchicalUriComponents
 * JD-Core Version:    0.6.0
 */