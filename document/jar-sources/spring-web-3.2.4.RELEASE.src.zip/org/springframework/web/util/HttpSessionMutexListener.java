/*    */ package org.springframework.web.util;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import javax.servlet.http.HttpSession;
/*    */ import javax.servlet.http.HttpSessionEvent;
/*    */ import javax.servlet.http.HttpSessionListener;
/*    */ 
/*    */ public class HttpSessionMutexListener
/*    */   implements HttpSessionListener
/*    */ {
/*    */   public void sessionCreated(HttpSessionEvent event)
/*    */   {
/* 48 */     event.getSession().setAttribute(WebUtils.SESSION_MUTEX_ATTRIBUTE, new Mutex(null));
/*    */   }
/*    */ 
/*    */   public void sessionDestroyed(HttpSessionEvent event) {
/* 52 */     event.getSession().removeAttribute(WebUtils.SESSION_MUTEX_ATTRIBUTE);
/*    */   }
/*    */ 
/*    */   private static class Mutex
/*    */     implements Serializable
/*    */   {
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.web.util.HttpSessionMutexListener
 * JD-Core Version:    0.6.0
 */