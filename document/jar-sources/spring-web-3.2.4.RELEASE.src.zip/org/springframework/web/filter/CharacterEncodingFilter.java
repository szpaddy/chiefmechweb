/*    */ package org.springframework.web.filter;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import javax.servlet.FilterChain;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ 
/*    */ public class CharacterEncodingFilter extends OncePerRequestFilter
/*    */ {
/*    */   private String encoding;
/* 47 */   private boolean forceEncoding = false;
/*    */ 
/*    */   public void setEncoding(String encoding)
/*    */   {
/* 58 */     this.encoding = encoding;
/*    */   }
/*    */ 
/*    */   public void setForceEncoding(boolean forceEncoding)
/*    */   {
/* 73 */     this.forceEncoding = forceEncoding;
/*    */   }
/*    */ 
/*    */   protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
/*    */     throws ServletException, IOException
/*    */   {
/* 82 */     if ((this.encoding != null) && ((this.forceEncoding) || (request.getCharacterEncoding() == null))) {
/* 83 */       request.setCharacterEncoding(this.encoding);
/* 84 */       if (this.forceEncoding) {
/* 85 */         response.setCharacterEncoding(this.encoding);
/*    */       }
/*    */     }
/* 88 */     filterChain.doFilter(request, response);
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.web.filter.CharacterEncodingFilter
 * JD-Core Version:    0.6.0
 */