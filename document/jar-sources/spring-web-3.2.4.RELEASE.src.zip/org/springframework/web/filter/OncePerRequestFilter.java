/*     */ package org.springframework.web.filter;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import javax.servlet.FilterChain;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.ServletResponse;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.springframework.web.context.request.async.WebAsyncManager;
/*     */ import org.springframework.web.context.request.async.WebAsyncUtils;
/*     */ 
/*     */ public abstract class OncePerRequestFilter extends GenericFilterBean
/*     */ {
/*     */   public static final String ALREADY_FILTERED_SUFFIX = ".FILTERED";
/*     */ 
/*     */   public final void doFilter(ServletRequest request, ServletResponse response, FilterChain filterChain)
/*     */     throws ServletException, IOException
/*     */   {
/*  89 */     if ((!(request instanceof HttpServletRequest)) || (!(response instanceof HttpServletResponse))) {
/*  90 */       throw new ServletException("OncePerRequestFilter just supports HTTP requests");
/*     */     }
/*  92 */     HttpServletRequest httpRequest = (HttpServletRequest)request;
/*  93 */     HttpServletResponse httpResponse = (HttpServletResponse)response;
/*     */ 
/*  95 */     String alreadyFilteredAttributeName = getAlreadyFilteredAttributeName();
/*  96 */     boolean hasAlreadyFilteredAttribute = request.getAttribute(alreadyFilteredAttributeName) != null;
/*     */ 
/*  98 */     if ((hasAlreadyFilteredAttribute) || (skipDispatch(httpRequest)) || (shouldNotFilter(httpRequest)))
/*     */     {
/* 101 */       filterChain.doFilter(request, response);
/*     */     }
/*     */     else
/*     */     {
/* 105 */       request.setAttribute(alreadyFilteredAttributeName, Boolean.TRUE);
/*     */       try {
/* 107 */         doFilterInternal(httpRequest, httpResponse, filterChain);
/*     */       }
/*     */       finally
/*     */       {
/* 111 */         request.removeAttribute(alreadyFilteredAttributeName);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private boolean skipDispatch(HttpServletRequest request) {
/* 117 */     if ((isAsyncDispatch(request)) && (shouldNotFilterAsyncDispatch())) {
/* 118 */       return true;
/*     */     }
/*     */ 
/* 121 */     return (request.getAttribute("javax.servlet.error.request_uri") != null) && (shouldNotFilterErrorDispatch());
/*     */   }
/*     */ 
/*     */   protected boolean isAsyncDispatch(HttpServletRequest request)
/*     */   {
/* 136 */     return WebAsyncUtils.getAsyncManager(request).hasConcurrentResult();
/*     */   }
/*     */ 
/*     */   protected boolean isAsyncStarted(HttpServletRequest request)
/*     */   {
/* 147 */     return WebAsyncUtils.getAsyncManager(request).isConcurrentHandlingStarted();
/*     */   }
/*     */ 
/*     */   protected String getAlreadyFilteredAttributeName()
/*     */   {
/* 160 */     String name = getFilterName();
/* 161 */     if (name == null) {
/* 162 */       name = getClass().getName();
/*     */     }
/* 164 */     return name + ".FILTERED";
/*     */   }
/*     */ 
/*     */   protected boolean shouldNotFilter(HttpServletRequest request)
/*     */     throws ServletException
/*     */   {
/* 176 */     return false;
/*     */   }
/*     */ 
/*     */   protected boolean shouldNotFilterAsyncDispatch()
/*     */   {
/* 197 */     return true;
/*     */   }
/*     */ 
/*     */   protected boolean shouldNotFilterErrorDispatch()
/*     */   {
/* 207 */     return true;
/*     */   }
/*     */ 
/*     */   protected abstract void doFilterInternal(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse, FilterChain paramFilterChain)
/*     */     throws ServletException, IOException;
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.web.filter.OncePerRequestFilter
 * JD-Core Version:    0.6.0
 */