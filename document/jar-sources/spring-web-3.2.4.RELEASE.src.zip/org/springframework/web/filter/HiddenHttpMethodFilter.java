/*    */ package org.springframework.web.filter;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.Locale;
/*    */ import javax.servlet.FilterChain;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletRequestWrapper;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ public class HiddenHttpMethodFilter extends OncePerRequestFilter
/*    */ {
/*    */   public static final String DEFAULT_METHOD_PARAM = "_method";
/*    */   private String methodParam;
/*    */ 
/*    */   public HiddenHttpMethodFilter()
/*    */   {
/* 54 */     this.methodParam = "_method";
/*    */   }
/*    */ 
/*    */   public void setMethodParam(String methodParam)
/*    */   {
/* 62 */     Assert.hasText(methodParam, "'methodParam' must not be empty");
/* 63 */     this.methodParam = methodParam;
/*    */   }
/*    */ 
/*    */   protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
/*    */     throws ServletException, IOException
/*    */   {
/* 70 */     String paramValue = request.getParameter(this.methodParam);
/* 71 */     if (("POST".equals(request.getMethod())) && (StringUtils.hasLength(paramValue))) {
/* 72 */       String method = paramValue.toUpperCase(Locale.ENGLISH);
/* 73 */       HttpServletRequest wrapper = new HttpMethodRequestWrapper(request, method);
/* 74 */       filterChain.doFilter(wrapper, response);
/*    */     }
/*    */     else {
/* 77 */       filterChain.doFilter(request, response);
/*    */     }
/*    */   }
/*    */ 
/*    */   private static class HttpMethodRequestWrapper extends HttpServletRequestWrapper
/*    */   {
/*    */     private final String method;
/*    */ 
/*    */     public HttpMethodRequestWrapper(HttpServletRequest request, String method)
/*    */     {
/* 91 */       super();
/* 92 */       this.method = method;
/*    */     }
/*    */ 
/*    */     public String getMethod()
/*    */     {
/* 97 */       return this.method;
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.web.filter.HiddenHttpMethodFilter
 * JD-Core Version:    0.6.0
 */