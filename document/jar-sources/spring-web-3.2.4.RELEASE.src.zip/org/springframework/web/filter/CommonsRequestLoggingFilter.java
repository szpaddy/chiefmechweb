/*    */ package org.springframework.web.filter;
/*    */ 
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import org.apache.commons.logging.Log;
/*    */ 
/*    */ public class CommonsRequestLoggingFilter extends AbstractRequestLoggingFilter
/*    */ {
/*    */   protected void beforeRequest(HttpServletRequest request, String message)
/*    */   {
/* 41 */     if (this.logger.isDebugEnabled())
/* 42 */       this.logger.debug(message);
/*    */   }
/*    */ 
/*    */   protected void afterRequest(HttpServletRequest request, String message)
/*    */   {
/* 51 */     if (this.logger.isDebugEnabled())
/* 52 */       this.logger.debug(message);
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.web.filter.CommonsRequestLoggingFilter
 * JD-Core Version:    0.6.0
 */