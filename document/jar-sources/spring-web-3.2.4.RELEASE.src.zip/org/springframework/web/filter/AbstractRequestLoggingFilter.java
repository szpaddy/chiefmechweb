/*     */ package org.springframework.web.filter;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import javax.servlet.FilterChain;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.ServletInputStream;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletRequestWrapper;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public abstract class AbstractRequestLoggingFilter extends OncePerRequestFilter
/*     */ {
/*     */   public static final String DEFAULT_BEFORE_MESSAGE_PREFIX = "Before request [";
/*     */   public static final String DEFAULT_BEFORE_MESSAGE_SUFFIX = "]";
/*     */   public static final String DEFAULT_AFTER_MESSAGE_PREFIX = "After request [";
/*     */   public static final String DEFAULT_AFTER_MESSAGE_SUFFIX = "]";
/*     */   private static final int DEFAULT_MAX_PAYLOAD_LENGTH = 50;
/*     */   private boolean includeQueryString;
/*     */   private boolean includeClientInfo;
/*     */   private boolean includePayload;
/*     */   private int maxPayloadLength;
/*     */   private String beforeMessagePrefix;
/*     */   private String beforeMessageSuffix;
/*     */   private String afterMessagePrefix;
/*     */   private String afterMessageSuffix;
/*     */ 
/*     */   public AbstractRequestLoggingFilter()
/*     */   {
/*  72 */     this.includeQueryString = false;
/*     */ 
/*  74 */     this.includeClientInfo = false;
/*     */ 
/*  76 */     this.includePayload = false;
/*     */ 
/*  78 */     this.maxPayloadLength = 50;
/*     */ 
/*  80 */     this.beforeMessagePrefix = "Before request [";
/*     */ 
/*  82 */     this.beforeMessageSuffix = "]";
/*     */ 
/*  84 */     this.afterMessagePrefix = "After request [";
/*     */ 
/*  86 */     this.afterMessageSuffix = "]";
/*     */   }
/*     */ 
/*     */   public void setIncludeQueryString(boolean includeQueryString)
/*     */   {
/*  94 */     this.includeQueryString = includeQueryString;
/*     */   }
/*     */ 
/*     */   protected boolean isIncludeQueryString()
/*     */   {
/* 101 */     return this.includeQueryString;
/*     */   }
/*     */ 
/*     */   public void setIncludeClientInfo(boolean includeClientInfo)
/*     */   {
/* 110 */     this.includeClientInfo = includeClientInfo;
/*     */   }
/*     */ 
/*     */   protected boolean isIncludeClientInfo()
/*     */   {
/* 117 */     return this.includeClientInfo;
/*     */   }
/*     */ 
/*     */   public void setIncludePayload(boolean includePayload)
/*     */   {
/* 127 */     this.includePayload = includePayload;
/*     */   }
/*     */ 
/*     */   protected boolean isIncludePayload()
/*     */   {
/* 134 */     return this.includePayload;
/*     */   }
/*     */ 
/*     */   public void setMaxPayloadLength(int maxPayloadLength)
/*     */   {
/* 141 */     Assert.isTrue(maxPayloadLength >= 0, "'maxPayloadLength' should be larger than or equal to 0");
/* 142 */     this.maxPayloadLength = maxPayloadLength;
/*     */   }
/*     */ 
/*     */   protected int getMaxPayloadLength()
/*     */   {
/* 149 */     return this.maxPayloadLength;
/*     */   }
/*     */ 
/*     */   public void setBeforeMessagePrefix(String beforeMessagePrefix)
/*     */   {
/* 156 */     this.beforeMessagePrefix = beforeMessagePrefix;
/*     */   }
/*     */ 
/*     */   public void setBeforeMessageSuffix(String beforeMessageSuffix)
/*     */   {
/* 163 */     this.beforeMessageSuffix = beforeMessageSuffix;
/*     */   }
/*     */ 
/*     */   public void setAfterMessagePrefix(String afterMessagePrefix)
/*     */   {
/* 170 */     this.afterMessagePrefix = afterMessagePrefix;
/*     */   }
/*     */ 
/*     */   public void setAfterMessageSuffix(String afterMessageSuffix)
/*     */   {
/* 177 */     this.afterMessageSuffix = afterMessageSuffix;
/*     */   }
/*     */ 
/*     */   protected boolean shouldNotFilterAsyncDispatch()
/*     */   {
/* 187 */     return false;
/*     */   }
/*     */ 
/*     */   protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
/*     */     throws ServletException, IOException
/*     */   {
/* 201 */     boolean isFirstRequest = !isAsyncDispatch(request);
/*     */ 
/* 203 */     if ((isIncludePayload()) && 
/* 204 */       (isFirstRequest)) {
/* 205 */       request = new RequestCachingRequestWrapper(request, null);
/*     */     }
/*     */ 
/* 209 */     if (isFirstRequest)
/* 210 */       beforeRequest(request, getBeforeMessage(request));
/*     */     try
/*     */     {
/* 213 */       filterChain.doFilter(request, response);
/*     */     }
/*     */     finally {
/* 216 */       if (!isAsyncStarted(request))
/* 217 */         afterRequest(request, getAfterMessage(request));
/*     */     }
/*     */   }
/*     */ 
/*     */   private String getBeforeMessage(HttpServletRequest request)
/*     */   {
/* 228 */     return createMessage(request, this.beforeMessagePrefix, this.beforeMessageSuffix);
/*     */   }
/*     */ 
/*     */   private String getAfterMessage(HttpServletRequest request)
/*     */   {
/* 237 */     return createMessage(request, this.afterMessagePrefix, this.afterMessageSuffix);
/*     */   }
/*     */ 
/*     */   protected String createMessage(HttpServletRequest request, String prefix, String suffix)
/*     */   {
/* 247 */     StringBuilder msg = new StringBuilder();
/* 248 */     msg.append(prefix);
/* 249 */     msg.append("uri=").append(request.getRequestURI());
/* 250 */     if (isIncludeQueryString()) {
/* 251 */       msg.append('?').append(request.getQueryString());
/*     */     }
/* 253 */     if (isIncludeClientInfo()) {
/* 254 */       String client = request.getRemoteAddr();
/* 255 */       if (StringUtils.hasLength(client)) {
/* 256 */         msg.append(";client=").append(client);
/*     */       }
/* 258 */       HttpSession session = request.getSession(false);
/* 259 */       if (session != null) {
/* 260 */         msg.append(";session=").append(session.getId());
/*     */       }
/* 262 */       String user = request.getRemoteUser();
/* 263 */       if (user != null) {
/* 264 */         msg.append(";user=").append(user);
/*     */       }
/*     */     }
/* 267 */     if ((isIncludePayload()) && ((request instanceof RequestCachingRequestWrapper))) {
/* 268 */       RequestCachingRequestWrapper wrapper = (RequestCachingRequestWrapper)request;
/* 269 */       byte[] buf = wrapper.toByteArray();
/* 270 */       if (buf.length > 0) { int length = Math.min(buf.length, getMaxPayloadLength());
/*     */         String payload;
/*     */         try { payload = new String(buf, 0, length, wrapper.getCharacterEncoding());
/*     */         } catch (UnsupportedEncodingException e)
/*     */         {
/* 277 */           payload = "[unknown]";
/*     */         }
/* 279 */         msg.append(";payload=").append(payload);
/*     */       }
/*     */     }
/*     */ 
/* 283 */     msg.append(suffix);
/* 284 */     return msg.toString();
/*     */   }
/*     */ 
/*     */   protected abstract void beforeRequest(HttpServletRequest paramHttpServletRequest, String paramString);
/*     */ 
/*     */   protected abstract void afterRequest(HttpServletRequest paramHttpServletRequest, String paramString);
/*     */ 
/*     */   private static class RequestCachingRequestWrapper extends HttpServletRequestWrapper {
/* 306 */     private final ByteArrayOutputStream bos = new ByteArrayOutputStream();
/*     */     private final ServletInputStream inputStream;
/*     */     private BufferedReader reader;
/*     */ 
/*     */     private RequestCachingRequestWrapper(HttpServletRequest request) throws IOException {
/* 313 */       super();
/* 314 */       this.inputStream = new RequestCachingInputStream(request.getInputStream(), null);
/*     */     }
/*     */ 
/*     */     public ServletInputStream getInputStream() throws IOException
/*     */     {
/* 319 */       return this.inputStream;
/*     */     }
/*     */ 
/*     */     public String getCharacterEncoding()
/*     */     {
/* 324 */       return super.getCharacterEncoding() != null ? super.getCharacterEncoding() : "ISO-8859-1";
/*     */     }
/*     */ 
/*     */     public BufferedReader getReader()
/*     */       throws IOException
/*     */     {
/* 330 */       if (this.reader == null) {
/* 331 */         this.reader = new BufferedReader(new InputStreamReader(this.inputStream, getCharacterEncoding()));
/*     */       }
/* 333 */       return this.reader;
/*     */     }
/*     */ 
/*     */     private byte[] toByteArray() {
/* 337 */       return this.bos.toByteArray();
/*     */     }
/*     */ 
/*     */     private class RequestCachingInputStream extends ServletInputStream {
/*     */       private final ServletInputStream is;
/*     */ 
/*     */       private RequestCachingInputStream(ServletInputStream is) {
/* 345 */         this.is = is;
/*     */       }
/*     */ 
/*     */       public int read() throws IOException
/*     */       {
/* 350 */         int ch = this.is.read();
/* 351 */         if (ch != -1) {
/* 352 */           AbstractRequestLoggingFilter.RequestCachingRequestWrapper.this.bos.write(ch);
/*     */         }
/* 354 */         return ch;
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.web.filter.AbstractRequestLoggingFilter
 * JD-Core Version:    0.6.0
 */