/*    */ package org.springframework.web.jsf;
/*    */ 
/*    */ import javax.faces.context.FacesContext;
/*    */ import javax.faces.el.EvaluationException;
/*    */ import javax.faces.el.VariableResolver;
/*    */ 
/*    */ @Deprecated
/*    */ public class SpringBeanVariableResolver extends DelegatingVariableResolver
/*    */ {
/*    */   public SpringBeanVariableResolver(VariableResolver originalVariableResolver)
/*    */   {
/* 41 */     super(originalVariableResolver);
/*    */   }
/*    */ 
/*    */   public Object resolveVariable(FacesContext facesContext, String name) throws EvaluationException
/*    */   {
/* 46 */     Object bean = resolveSpringBean(facesContext, name);
/* 47 */     if (bean != null) {
/* 48 */       return bean;
/*    */     }
/* 50 */     Object value = resolveOriginal(facesContext, name);
/* 51 */     if (value != null) {
/* 52 */       return value;
/*    */     }
/* 54 */     return null;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.web.jsf.SpringBeanVariableResolver
 * JD-Core Version:    0.6.0
 */