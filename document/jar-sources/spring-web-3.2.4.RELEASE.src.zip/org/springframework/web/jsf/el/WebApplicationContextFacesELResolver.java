/*     */ package org.springframework.web.jsf.el;
/*     */ 
/*     */ import java.beans.FeatureDescriptor;
/*     */ import java.util.Iterator;
/*     */ import javax.el.ELContext;
/*     */ import javax.el.ELException;
/*     */ import javax.el.ELResolver;
/*     */ import javax.faces.context.FacesContext;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.web.context.WebApplicationContext;
/*     */ import org.springframework.web.jsf.FacesContextUtils;
/*     */ 
/*     */ public class WebApplicationContextFacesELResolver extends ELResolver
/*     */ {
/*     */   public static final String WEB_APPLICATION_CONTEXT_VARIABLE_NAME = "webApplicationContext";
/*  67 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */ 
/*     */   public Object getValue(ELContext elContext, Object base, Object property)
/*     */     throws ELException
/*     */   {
/*  72 */     if (base != null) {
/*  73 */       if ((base instanceof WebApplicationContext)) {
/*  74 */         WebApplicationContext wac = (WebApplicationContext)base;
/*  75 */         String beanName = property.toString();
/*  76 */         if (this.logger.isTraceEnabled()) {
/*  77 */           this.logger.trace("Attempting to resolve property '" + beanName + "' in root WebApplicationContext");
/*     */         }
/*  79 */         if (wac.containsBean(beanName)) {
/*  80 */           if (this.logger.isDebugEnabled()) {
/*  81 */             this.logger.debug("Successfully resolved property '" + beanName + "' in root WebApplicationContext");
/*     */           }
/*  83 */           elContext.setPropertyResolved(true);
/*     */           try {
/*  85 */             return wac.getBean(beanName);
/*     */           }
/*     */           catch (BeansException ex) {
/*  88 */             throw new ELException(ex);
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/*  93 */         return null;
/*     */       }
/*     */ 
/*     */     }
/*  98 */     else if ("webApplicationContext".equals(property)) {
/*  99 */       elContext.setPropertyResolved(true);
/* 100 */       return getWebApplicationContext(elContext);
/*     */     }
/*     */ 
/* 104 */     return null;
/*     */   }
/*     */ 
/*     */   public Class<?> getType(ELContext elContext, Object base, Object property) throws ELException
/*     */   {
/* 109 */     if (base != null) {
/* 110 */       if ((base instanceof WebApplicationContext)) {
/* 111 */         WebApplicationContext wac = (WebApplicationContext)base;
/* 112 */         String beanName = property.toString();
/* 113 */         if (this.logger.isDebugEnabled()) {
/* 114 */           this.logger.debug("Attempting to resolve property '" + beanName + "' in root WebApplicationContext");
/*     */         }
/* 116 */         if (wac.containsBean(beanName)) {
/* 117 */           if (this.logger.isDebugEnabled()) {
/* 118 */             this.logger.debug("Successfully resolved property '" + beanName + "' in root WebApplicationContext");
/*     */           }
/* 120 */           elContext.setPropertyResolved(true);
/*     */           try {
/* 122 */             return wac.getType(beanName);
/*     */           }
/*     */           catch (BeansException ex) {
/* 125 */             throw new ELException(ex);
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/* 130 */         return null;
/*     */       }
/*     */ 
/*     */     }
/* 135 */     else if ("webApplicationContext".equals(property)) {
/* 136 */       elContext.setPropertyResolved(true);
/* 137 */       return WebApplicationContext.class;
/*     */     }
/*     */ 
/* 141 */     return null;
/*     */   }
/*     */ 
/*     */   public void setValue(ELContext elContext, Object base, Object property, Object value) throws ELException
/*     */   {
/*     */   }
/*     */ 
/*     */   public boolean isReadOnly(ELContext elContext, Object base, Object property) throws ELException
/*     */   {
/* 150 */     if ((base instanceof WebApplicationContext)) {
/* 151 */       elContext.setPropertyResolved(true);
/* 152 */       return false;
/*     */     }
/* 154 */     return false;
/*     */   }
/*     */ 
/*     */   public Iterator<FeatureDescriptor> getFeatureDescriptors(ELContext elContext, Object base)
/*     */   {
/* 159 */     return null;
/*     */   }
/*     */ 
/*     */   public Class<?> getCommonPropertyType(ELContext elContext, Object base)
/*     */   {
/* 164 */     return Object.class;
/*     */   }
/*     */ 
/*     */   protected WebApplicationContext getWebApplicationContext(ELContext elContext)
/*     */   {
/* 177 */     FacesContext facesContext = FacesContext.getCurrentInstance();
/* 178 */     return FacesContextUtils.getRequiredWebApplicationContext(facesContext);
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.web.jsf.el.WebApplicationContextFacesELResolver
 * JD-Core Version:    0.6.0
 */