/*     */ package org.springframework.web.jsf;
/*     */ 
/*     */ import javax.faces.context.FacesContext;
/*     */ import javax.faces.el.EvaluationException;
/*     */ import javax.faces.el.VariableResolver;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.context.WebApplicationContext;
/*     */ 
/*     */ @Deprecated
/*     */ public class WebApplicationContextVariableResolver extends VariableResolver
/*     */ {
/*     */   public static final String WEB_APPLICATION_CONTEXT_VARIABLE_NAME = "webApplicationContext";
/*     */   protected final VariableResolver originalVariableResolver;
/*     */ 
/*     */   public WebApplicationContextVariableResolver(VariableResolver originalVariableResolver)
/*     */   {
/*  74 */     Assert.notNull(originalVariableResolver, "Original JSF VariableResolver must not be null");
/*  75 */     this.originalVariableResolver = originalVariableResolver;
/*     */   }
/*     */ 
/*     */   protected final VariableResolver getOriginalVariableResolver()
/*     */   {
/*  83 */     return this.originalVariableResolver;
/*     */   }
/*     */ 
/*     */   public Object resolveVariable(FacesContext context, String name)
/*     */     throws EvaluationException
/*     */   {
/*  95 */     Object value = null;
/*  96 */     if ("webApplicationContext".equals(name)) {
/*  97 */       value = getWebApplicationContext(context);
/*     */     }
/*  99 */     if (value == null) {
/* 100 */       value = getOriginalVariableResolver().resolveVariable(context, name);
/*     */     }
/* 102 */     return value;
/*     */   }
/*     */ 
/*     */   protected WebApplicationContext getWebApplicationContext(FacesContext facesContext)
/*     */   {
/* 114 */     return FacesContextUtils.getWebApplicationContext(facesContext);
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.web.jsf.WebApplicationContextVariableResolver
 * JD-Core Version:    0.6.0
 */