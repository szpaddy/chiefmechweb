/*    */ package org.springframework.web.accept;
/*    */ 
/*    */ import java.util.Map;
/*    */ import javax.servlet.ServletContext;
/*    */ import org.springframework.http.MediaType;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.util.StringUtils;
/*    */ import org.springframework.web.context.request.NativeWebRequest;
/*    */ 
/*    */ public class ServletPathExtensionContentNegotiationStrategy extends PathExtensionContentNegotiationStrategy
/*    */ {
/*    */   private final ServletContext servletContext;
/*    */ 
/*    */   public ServletPathExtensionContentNegotiationStrategy(ServletContext servletContext, Map<String, MediaType> mediaTypes)
/*    */   {
/* 47 */     super(mediaTypes);
/* 48 */     Assert.notNull(servletContext, "ServletContext is required!");
/* 49 */     this.servletContext = servletContext;
/*    */   }
/*    */ 
/*    */   public ServletPathExtensionContentNegotiationStrategy(ServletContext servletContext)
/*    */   {
/* 59 */     this(servletContext, null);
/*    */   }
/*    */ 
/*    */   protected MediaType handleNoMatch(NativeWebRequest webRequest, String extension)
/*    */   {
/* 68 */     MediaType mediaType = null;
/* 69 */     if (this.servletContext != null) {
/* 70 */       String mimeType = this.servletContext.getMimeType("file." + extension);
/* 71 */       if (StringUtils.hasText(mimeType)) {
/* 72 */         mediaType = MediaType.parseMediaType(mimeType);
/*    */       }
/*    */     }
/* 75 */     if ((mediaType == null) || (MediaType.APPLICATION_OCTET_STREAM.equals(mediaType))) {
/* 76 */       MediaType superMediaType = super.handleNoMatch(webRequest, extension);
/* 77 */       if (superMediaType != null) {
/* 78 */         mediaType = superMediaType;
/*    */       }
/*    */     }
/* 81 */     return mediaType;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.web.accept.ServletPathExtensionContentNegotiationStrategy
 * JD-Core Version:    0.6.0
 */