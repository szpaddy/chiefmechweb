/*    */ package org.springframework.web.accept;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.http.MediaType;
/*    */ import org.springframework.web.context.request.NativeWebRequest;
/*    */ 
/*    */ public class FixedContentNegotiationStrategy
/*    */   implements ContentNegotiationStrategy
/*    */ {
/* 35 */   private static final Log logger = LogFactory.getLog(FixedContentNegotiationStrategy.class);
/*    */   private final MediaType defaultContentType;
/*    */ 
/*    */   public FixedContentNegotiationStrategy(MediaType defaultContentType)
/*    */   {
/* 43 */     this.defaultContentType = defaultContentType;
/*    */   }
/*    */ 
/*    */   public List<MediaType> resolveMediaTypes(NativeWebRequest webRequest) {
/* 47 */     if (logger.isDebugEnabled()) {
/* 48 */       logger.debug("Requested media types is " + this.defaultContentType + " (based on default MediaType)");
/*    */     }
/* 50 */     return Collections.singletonList(this.defaultContentType);
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.web.accept.FixedContentNegotiationStrategy
 * JD-Core Version:    0.6.0
 */