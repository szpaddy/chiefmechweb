/*     */ package org.springframework.web.accept;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.HttpMediaTypeNotAcceptableException;
/*     */ import org.springframework.web.context.request.NativeWebRequest;
/*     */ 
/*     */ public class ContentNegotiationManager
/*     */   implements ContentNegotiationStrategy, MediaTypeFileExtensionResolver
/*     */ {
/*  53 */   private static final List<MediaType> MEDIA_TYPE_ALL = Arrays.asList(new MediaType[] { MediaType.ALL });
/*     */ 
/*  55 */   private final List<ContentNegotiationStrategy> contentNegotiationStrategies = new ArrayList();
/*     */ 
/*  58 */   private final Set<MediaTypeFileExtensionResolver> fileExtensionResolvers = new LinkedHashSet();
/*     */ 
/*     */   public ContentNegotiationManager(ContentNegotiationStrategy[] strategies)
/*     */   {
/*  69 */     Assert.notEmpty(strategies, "At least one ContentNegotiationStrategy is expected");
/*  70 */     this.contentNegotiationStrategies.addAll(Arrays.asList(strategies));
/*  71 */     for (ContentNegotiationStrategy strategy : this.contentNegotiationStrategies)
/*  72 */       if ((strategy instanceof MediaTypeFileExtensionResolver))
/*  73 */         this.fileExtensionResolvers.add((MediaTypeFileExtensionResolver)strategy);
/*     */   }
/*     */ 
/*     */   public ContentNegotiationManager(Collection<ContentNegotiationStrategy> strategies)
/*     */   {
/*  85 */     Assert.notEmpty(strategies, "At least one ContentNegotiationStrategy is expected");
/*  86 */     this.contentNegotiationStrategies.addAll(strategies);
/*  87 */     for (ContentNegotiationStrategy strategy : this.contentNegotiationStrategies)
/*  88 */       if ((strategy instanceof MediaTypeFileExtensionResolver))
/*  89 */         this.fileExtensionResolvers.add((MediaTypeFileExtensionResolver)strategy);
/*     */   }
/*     */ 
/*     */   public ContentNegotiationManager()
/*     */   {
/*  98 */     this(new MediaTypeFileExtensionResolver[] { new HeaderContentNegotiationStrategy() });
/*     */   }
/*     */ 
/*     */   public void addFileExtensionResolvers(MediaTypeFileExtensionResolver[] resolvers)
/*     */   {
/* 111 */     this.fileExtensionResolvers.addAll(Arrays.asList(resolvers));
/*     */   }
/*     */ 
/*     */   public List<MediaType> resolveMediaTypes(NativeWebRequest webRequest)
/*     */     throws HttpMediaTypeNotAcceptableException
/*     */   {
/* 122 */     for (ContentNegotiationStrategy strategy : this.contentNegotiationStrategies) {
/* 123 */       List mediaTypes = strategy.resolveMediaTypes(webRequest);
/* 124 */       if ((!mediaTypes.isEmpty()) && (!mediaTypes.equals(MEDIA_TYPE_ALL)))
/*     */       {
/* 127 */         return mediaTypes;
/*     */       }
/*     */     }
/* 129 */     return Collections.emptyList();
/*     */   }
/*     */ 
/*     */   public List<String> resolveFileExtensions(MediaType mediaType)
/*     */   {
/* 137 */     Set result = new LinkedHashSet();
/* 138 */     for (MediaTypeFileExtensionResolver resolver : this.fileExtensionResolvers) {
/* 139 */       result.addAll(resolver.resolveFileExtensions(mediaType));
/*     */     }
/* 141 */     return new ArrayList(result);
/*     */   }
/*     */ 
/*     */   public List<String> getAllFileExtensions()
/*     */   {
/* 149 */     Set result = new LinkedHashSet();
/* 150 */     for (MediaTypeFileExtensionResolver resolver : this.fileExtensionResolvers) {
/* 151 */       result.addAll(resolver.getAllFileExtensions());
/*     */     }
/* 153 */     return new ArrayList(result);
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.web.accept.ContentNegotiationManager
 * JD-Core Version:    0.6.0
 */