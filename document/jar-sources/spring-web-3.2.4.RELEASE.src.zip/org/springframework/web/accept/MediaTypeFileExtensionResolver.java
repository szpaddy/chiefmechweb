package org.springframework.web.accept;

import java.util.List;
import org.springframework.http.MediaType;

public abstract interface MediaTypeFileExtensionResolver
{
  public abstract List<String> resolveFileExtensions(MediaType paramMediaType);

  public abstract List<String> getAllFileExtensions();
}

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.web.accept.MediaTypeFileExtensionResolver
 * JD-Core Version:    0.6.0
 */