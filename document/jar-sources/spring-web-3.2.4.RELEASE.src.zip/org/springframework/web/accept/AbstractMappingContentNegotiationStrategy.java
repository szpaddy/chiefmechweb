/*    */ package org.springframework.web.accept;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import org.springframework.http.MediaType;
/*    */ import org.springframework.util.StringUtils;
/*    */ import org.springframework.web.context.request.NativeWebRequest;
/*    */ 
/*    */ public abstract class AbstractMappingContentNegotiationStrategy extends MappingMediaTypeFileExtensionResolver
/*    */   implements ContentNegotiationStrategy, MediaTypeFileExtensionResolver
/*    */ {
/*    */   public AbstractMappingContentNegotiationStrategy(Map<String, MediaType> mediaTypes)
/*    */   {
/* 42 */     super(mediaTypes);
/*    */   }
/*    */ 
/*    */   public List<MediaType> resolveMediaTypes(NativeWebRequest webRequest) {
/* 46 */     String key = getMediaTypeKey(webRequest);
/* 47 */     if (StringUtils.hasText(key)) {
/* 48 */       MediaType mediaType = lookupMediaType(key);
/* 49 */       if (mediaType != null) {
/* 50 */         handleMatch(key, mediaType);
/* 51 */         return Collections.singletonList(mediaType);
/*    */       }
/* 53 */       mediaType = handleNoMatch(webRequest, key);
/* 54 */       if (mediaType != null) {
/* 55 */         addMapping(key, mediaType);
/* 56 */         return Collections.singletonList(mediaType);
/*    */       }
/*    */     }
/* 59 */     return Collections.emptyList();
/*    */   }
/*    */ 
/*    */   protected abstract String getMediaTypeKey(NativeWebRequest paramNativeWebRequest);
/*    */ 
/*    */   protected void handleMatch(String mappingKey, MediaType mediaType)
/*    */   {
/*    */   }
/*    */ 
/*    */   protected MediaType handleNoMatch(NativeWebRequest request, String mappingKey)
/*    */   {
/* 79 */     return null;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.web.accept.AbstractMappingContentNegotiationStrategy
 * JD-Core Version:    0.6.0
 */