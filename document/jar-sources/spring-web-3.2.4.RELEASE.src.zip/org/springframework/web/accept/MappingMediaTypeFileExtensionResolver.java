/*    */ package org.springframework.web.accept;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.LinkedList;
/*    */ import java.util.List;
/*    */ import java.util.Locale;
/*    */ import java.util.Map;
/*    */ import java.util.Map.Entry;
/*    */ import java.util.concurrent.ConcurrentHashMap;
/*    */ import java.util.concurrent.ConcurrentMap;
/*    */ import org.springframework.http.MediaType;
/*    */ import org.springframework.util.LinkedMultiValueMap;
/*    */ import org.springframework.util.MultiValueMap;
/*    */ 
/*    */ public class MappingMediaTypeFileExtensionResolver
/*    */   implements MediaTypeFileExtensionResolver
/*    */ {
/* 41 */   private final ConcurrentMap<String, MediaType> mediaTypes = new ConcurrentHashMap(64);
/*    */ 
/* 43 */   private final MultiValueMap<MediaType, String> fileExtensions = new LinkedMultiValueMap();
/*    */ 
/* 45 */   private final List<String> allFileExtensions = new LinkedList();
/*    */ 
/*    */   public MappingMediaTypeFileExtensionResolver(Map<String, MediaType> mediaTypes)
/*    */   {
/* 53 */     if (mediaTypes != null)
/* 54 */       for (Map.Entry entries : mediaTypes.entrySet()) {
/* 55 */         String extension = ((String)entries.getKey()).toLowerCase(Locale.ENGLISH);
/* 56 */         MediaType mediaType = (MediaType)entries.getValue();
/* 57 */         addMapping(extension, mediaType);
/*    */       }
/*    */   }
/*    */ 
/*    */   public List<String> resolveFileExtensions(MediaType mediaType)
/*    */   {
/* 67 */     List fileExtensions = (List)this.fileExtensions.get(mediaType);
/* 68 */     return fileExtensions != null ? fileExtensions : Collections.emptyList();
/*    */   }
/*    */ 
/*    */   public List<String> getAllFileExtensions() {
/* 72 */     return Collections.unmodifiableList(this.allFileExtensions);
/*    */   }
/*    */ 
/*    */   protected MediaType lookupMediaType(String extension)
/*    */   {
/* 80 */     return (MediaType)this.mediaTypes.get(extension);
/*    */   }
/*    */ 
/*    */   protected void addMapping(String extension, MediaType mediaType)
/*    */   {
/* 87 */     MediaType previous = (MediaType)this.mediaTypes.putIfAbsent(extension, mediaType);
/* 88 */     if (previous == null) {
/* 89 */       this.fileExtensions.add(mediaType, extension);
/* 90 */       this.allFileExtensions.add(extension);
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.web.accept.MappingMediaTypeFileExtensionResolver
 * JD-Core Version:    0.6.0
 */