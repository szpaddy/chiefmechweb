/*     */ package org.springframework.web.client;
/*     */ 
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.nio.charset.Charset;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpStatus;
/*     */ 
/*     */ public abstract class HttpStatusCodeException extends RestClientException
/*     */ {
/*     */   private static final long serialVersionUID = -5807494703720513267L;
/*     */   private static final String DEFAULT_CHARSET = "ISO-8859-1";
/*     */   private final HttpStatus statusCode;
/*     */   private final String statusText;
/*     */   private final byte[] responseBody;
/*     */   private final HttpHeaders responseHeaders;
/*     */   private final String responseCharset;
/*     */ 
/*     */   protected HttpStatusCodeException(HttpStatus statusCode)
/*     */   {
/*  55 */     this(statusCode, statusCode.name(), null, null, null);
/*     */   }
/*     */ 
/*     */   protected HttpStatusCodeException(HttpStatus statusCode, String statusText)
/*     */   {
/*  65 */     this(statusCode, statusText, null, null, null);
/*     */   }
/*     */ 
/*     */   protected HttpStatusCodeException(HttpStatus statusCode, String statusText, byte[] responseBody, Charset responseCharset)
/*     */   {
/*  81 */     this(statusCode, statusText, null, responseBody, responseCharset);
/*     */   }
/*     */ 
/*     */   protected HttpStatusCodeException(HttpStatus statusCode, String statusText, HttpHeaders responseHeaders, byte[] responseBody, Charset responseCharset)
/*     */   {
/*  96 */     super(statusCode.value() + " " + statusText);
/*  97 */     this.statusCode = statusCode;
/*  98 */     this.statusText = statusText;
/*  99 */     this.responseHeaders = responseHeaders;
/* 100 */     this.responseBody = (responseBody != null ? responseBody : new byte[0]);
/* 101 */     this.responseCharset = (responseCharset != null ? responseCharset.name() : "ISO-8859-1");
/*     */   }
/*     */ 
/*     */   public HttpStatus getStatusCode()
/*     */   {
/* 109 */     return this.statusCode;
/*     */   }
/*     */ 
/*     */   public String getStatusText()
/*     */   {
/* 116 */     return this.statusText;
/*     */   }
/*     */ 
/*     */   public HttpHeaders getResponseHeaders()
/*     */   {
/* 124 */     return this.responseHeaders;
/*     */   }
/*     */ 
/*     */   public byte[] getResponseBodyAsByteArray()
/*     */   {
/* 133 */     return this.responseBody;
/*     */   }
/*     */ 
/*     */   public String getResponseBodyAsString()
/*     */   {
/*     */     try
/*     */     {
/* 142 */       return new String(this.responseBody, this.responseCharset);
/*     */     }
/*     */     catch (UnsupportedEncodingException ex) {
/*     */     }
/* 146 */     throw new InternalError(ex.getMessage());
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.web.client.HttpStatusCodeException
 * JD-Core Version:    0.6.0
 */