/*     */ package org.springframework.web.client;
/*     */ 
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.nio.charset.Charset;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ 
/*     */ public class UnknownHttpStatusCodeException extends RestClientException
/*     */ {
/*     */   private static final long serialVersionUID = 4702443689088991600L;
/*     */   private static final String DEFAULT_CHARSET = "ISO-8859-1";
/*     */   private final int rawStatusCode;
/*     */   private final String statusText;
/*     */   private final byte[] responseBody;
/*     */   private final HttpHeaders responseHeaders;
/*     */   private final String responseCharset;
/*     */ 
/*     */   public UnknownHttpStatusCodeException(int rawStatusCode, String statusText, HttpHeaders responseHeaders, byte[] responseBody, Charset responseCharset)
/*     */   {
/*  59 */     super("Unknown status code [" + String.valueOf(rawStatusCode) + "]" + " " + statusText);
/*  60 */     this.rawStatusCode = rawStatusCode;
/*  61 */     this.statusText = statusText;
/*  62 */     this.responseHeaders = responseHeaders;
/*  63 */     this.responseBody = (responseBody != null ? responseBody : new byte[0]);
/*  64 */     this.responseCharset = (responseCharset != null ? responseCharset.name() : "ISO-8859-1");
/*     */   }
/*     */ 
/*     */   public int getRawStatusCode()
/*     */   {
/*  71 */     return this.rawStatusCode;
/*     */   }
/*     */ 
/*     */   public String getStatusText()
/*     */   {
/*  78 */     return this.statusText;
/*     */   }
/*     */ 
/*     */   public HttpHeaders getResponseHeaders()
/*     */   {
/*  85 */     return this.responseHeaders;
/*     */   }
/*     */ 
/*     */   public byte[] getResponseBodyAsByteArray()
/*     */   {
/*  92 */     return this.responseBody;
/*     */   }
/*     */ 
/*     */   public String getResponseBodyAsString()
/*     */   {
/*     */     try
/*     */     {
/* 100 */       return new String(this.responseBody, this.responseCharset);
/*     */     }
/*     */     catch (UnsupportedEncodingException ex) {
/*     */     }
/* 104 */     throw new InternalError(ex.getMessage());
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.web.client.UnknownHttpStatusCodeException
 * JD-Core Version:    0.6.0
 */