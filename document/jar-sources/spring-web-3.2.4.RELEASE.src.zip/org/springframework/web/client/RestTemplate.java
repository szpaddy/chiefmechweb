/*     */ package org.springframework.web.client;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Type;
/*     */ import java.net.URI;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.core.ParameterizedTypeReference;
/*     */ import org.springframework.http.HttpEntity;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.ResponseEntity;
/*     */ import org.springframework.http.client.ClientHttpRequest;
/*     */ import org.springframework.http.client.ClientHttpRequestFactory;
/*     */ import org.springframework.http.client.ClientHttpResponse;
/*     */ import org.springframework.http.client.support.InterceptingHttpAccessor;
/*     */ import org.springframework.http.converter.ByteArrayHttpMessageConverter;
/*     */ import org.springframework.http.converter.GenericHttpMessageConverter;
/*     */ import org.springframework.http.converter.HttpMessageConverter;
/*     */ import org.springframework.http.converter.ResourceHttpMessageConverter;
/*     */ import org.springframework.http.converter.StringHttpMessageConverter;
/*     */ import org.springframework.http.converter.feed.AtomFeedHttpMessageConverter;
/*     */ import org.springframework.http.converter.feed.RssChannelHttpMessageConverter;
/*     */ import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
/*     */ import org.springframework.http.converter.json.MappingJacksonHttpMessageConverter;
/*     */ import org.springframework.http.converter.support.AllEncompassingFormHttpMessageConverter;
/*     */ import org.springframework.http.converter.xml.Jaxb2RootElementHttpMessageConverter;
/*     */ import org.springframework.http.converter.xml.SourceHttpMessageConverter;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.web.util.UriTemplate;
/*     */ 
/*     */ public class RestTemplate extends InterceptingHttpAccessor
/*     */   implements RestOperations
/*     */ {
/* 125 */   private static boolean romePresent = ClassUtils.isPresent("com.sun.syndication.feed.WireFeed", RestTemplate.class.getClassLoader());
/*     */ 
/* 128 */   private static final boolean jaxb2Present = ClassUtils.isPresent("javax.xml.bind.Binder", RestTemplate.class.getClassLoader());
/*     */ 
/* 131 */   private static final boolean jackson2Present = (ClassUtils.isPresent("com.fasterxml.jackson.databind.ObjectMapper", RestTemplate.class.getClassLoader())) && (ClassUtils.isPresent("com.fasterxml.jackson.core.JsonGenerator", RestTemplate.class.getClassLoader()));
/*     */ 
/* 135 */   private static final boolean jacksonPresent = (ClassUtils.isPresent("org.codehaus.jackson.map.ObjectMapper", RestTemplate.class.getClassLoader())) && (ClassUtils.isPresent("org.codehaus.jackson.JsonGenerator", RestTemplate.class.getClassLoader()));
/*     */ 
/* 140 */   private final ResponseExtractor<HttpHeaders> headersExtractor = new HeadersExtractor(null);
/*     */ 
/* 142 */   private List<HttpMessageConverter<?>> messageConverters = new ArrayList();
/*     */ 
/* 144 */   private ResponseErrorHandler errorHandler = new DefaultResponseErrorHandler();
/*     */ 
/*     */   public RestTemplate()
/*     */   {
/* 151 */     this.messageConverters.add(new ByteArrayHttpMessageConverter());
/* 152 */     this.messageConverters.add(new StringHttpMessageConverter());
/* 153 */     this.messageConverters.add(new ResourceHttpMessageConverter());
/* 154 */     this.messageConverters.add(new SourceHttpMessageConverter());
/* 155 */     this.messageConverters.add(new AllEncompassingFormHttpMessageConverter());
/* 156 */     if (romePresent) {
/* 157 */       this.messageConverters.add(new AtomFeedHttpMessageConverter());
/* 158 */       this.messageConverters.add(new RssChannelHttpMessageConverter());
/*     */     }
/* 160 */     if (jaxb2Present) {
/* 161 */       this.messageConverters.add(new Jaxb2RootElementHttpMessageConverter());
/*     */     }
/* 163 */     if (jackson2Present) {
/* 164 */       this.messageConverters.add(new MappingJackson2HttpMessageConverter());
/*     */     }
/* 166 */     else if (jacksonPresent)
/* 167 */       this.messageConverters.add(new MappingJacksonHttpMessageConverter());
/*     */   }
/*     */ 
/*     */   public RestTemplate(ClientHttpRequestFactory requestFactory)
/*     */   {
/* 178 */     this();
/* 179 */     setRequestFactory(requestFactory);
/*     */   }
/*     */ 
/*     */   public void setMessageConverters(List<HttpMessageConverter<?>> messageConverters)
/*     */   {
/* 188 */     Assert.notEmpty(messageConverters, "'messageConverters' must not be empty");
/* 189 */     this.messageConverters = messageConverters;
/*     */   }
/*     */ 
/*     */   public List<HttpMessageConverter<?>> getMessageConverters()
/*     */   {
/* 196 */     return this.messageConverters;
/*     */   }
/*     */ 
/*     */   public void setErrorHandler(ResponseErrorHandler errorHandler)
/*     */   {
/* 204 */     Assert.notNull(errorHandler, "'errorHandler' must not be null");
/* 205 */     this.errorHandler = errorHandler;
/*     */   }
/*     */ 
/*     */   public ResponseErrorHandler getErrorHandler()
/*     */   {
/* 212 */     return this.errorHandler;
/*     */   }
/*     */ 
/*     */   public <T> T getForObject(String url, Class<T> responseType, Object[] urlVariables)
/*     */     throws RestClientException
/*     */   {
/* 219 */     AcceptHeaderRequestCallback requestCallback = new AcceptHeaderRequestCallback(responseType, null);
/* 220 */     HttpMessageConverterExtractor responseExtractor = new HttpMessageConverterExtractor(responseType, getMessageConverters(), this.logger);
/*     */ 
/* 222 */     return execute(url, HttpMethod.GET, requestCallback, responseExtractor, urlVariables);
/*     */   }
/*     */ 
/*     */   public <T> T getForObject(String url, Class<T> responseType, Map<String, ?> urlVariables) throws RestClientException {
/* 226 */     AcceptHeaderRequestCallback requestCallback = new AcceptHeaderRequestCallback(responseType, null);
/* 227 */     HttpMessageConverterExtractor responseExtractor = new HttpMessageConverterExtractor(responseType, getMessageConverters(), this.logger);
/*     */ 
/* 229 */     return execute(url, HttpMethod.GET, requestCallback, responseExtractor, urlVariables);
/*     */   }
/*     */ 
/*     */   public <T> T getForObject(URI url, Class<T> responseType) throws RestClientException {
/* 233 */     AcceptHeaderRequestCallback requestCallback = new AcceptHeaderRequestCallback(responseType, null);
/* 234 */     HttpMessageConverterExtractor responseExtractor = new HttpMessageConverterExtractor(responseType, getMessageConverters(), this.logger);
/*     */ 
/* 236 */     return execute(url, HttpMethod.GET, requestCallback, responseExtractor);
/*     */   }
/*     */ 
/*     */   public <T> ResponseEntity<T> getForEntity(String url, Class<T> responseType, Object[] urlVariables) throws RestClientException
/*     */   {
/* 241 */     AcceptHeaderRequestCallback requestCallback = new AcceptHeaderRequestCallback(responseType, null);
/* 242 */     ResponseEntityResponseExtractor responseExtractor = new ResponseEntityResponseExtractor(responseType);
/*     */ 
/* 244 */     return (ResponseEntity)execute(url, HttpMethod.GET, requestCallback, responseExtractor, urlVariables);
/*     */   }
/*     */ 
/*     */   public <T> ResponseEntity<T> getForEntity(String url, Class<T> responseType, Map<String, ?> urlVariables) throws RestClientException
/*     */   {
/* 249 */     AcceptHeaderRequestCallback requestCallback = new AcceptHeaderRequestCallback(responseType, null);
/* 250 */     ResponseEntityResponseExtractor responseExtractor = new ResponseEntityResponseExtractor(responseType);
/*     */ 
/* 252 */     return (ResponseEntity)execute(url, HttpMethod.GET, requestCallback, responseExtractor, urlVariables);
/*     */   }
/*     */ 
/*     */   public <T> ResponseEntity<T> getForEntity(URI url, Class<T> responseType) throws RestClientException {
/* 256 */     AcceptHeaderRequestCallback requestCallback = new AcceptHeaderRequestCallback(responseType, null);
/* 257 */     ResponseEntityResponseExtractor responseExtractor = new ResponseEntityResponseExtractor(responseType);
/*     */ 
/* 259 */     return (ResponseEntity)execute(url, HttpMethod.GET, requestCallback, responseExtractor);
/*     */   }
/*     */ 
/*     */   public HttpHeaders headForHeaders(String url, Object[] urlVariables)
/*     */     throws RestClientException
/*     */   {
/* 265 */     return (HttpHeaders)execute(url, HttpMethod.HEAD, null, this.headersExtractor, urlVariables);
/*     */   }
/*     */ 
/*     */   public HttpHeaders headForHeaders(String url, Map<String, ?> urlVariables) throws RestClientException {
/* 269 */     return (HttpHeaders)execute(url, HttpMethod.HEAD, null, this.headersExtractor, urlVariables);
/*     */   }
/*     */ 
/*     */   public HttpHeaders headForHeaders(URI url) throws RestClientException {
/* 273 */     return (HttpHeaders)execute(url, HttpMethod.HEAD, null, this.headersExtractor);
/*     */   }
/*     */ 
/*     */   public URI postForLocation(String url, Object request, Object[] urlVariables)
/*     */     throws RestClientException
/*     */   {
/* 279 */     HttpEntityRequestCallback requestCallback = new HttpEntityRequestCallback(request, null);
/* 280 */     HttpHeaders headers = (HttpHeaders)execute(url, HttpMethod.POST, requestCallback, this.headersExtractor, urlVariables);
/* 281 */     return headers.getLocation();
/*     */   }
/*     */ 
/*     */   public URI postForLocation(String url, Object request, Map<String, ?> urlVariables) throws RestClientException
/*     */   {
/* 286 */     HttpEntityRequestCallback requestCallback = new HttpEntityRequestCallback(request, null);
/* 287 */     HttpHeaders headers = (HttpHeaders)execute(url, HttpMethod.POST, requestCallback, this.headersExtractor, urlVariables);
/* 288 */     return headers.getLocation();
/*     */   }
/*     */ 
/*     */   public URI postForLocation(URI url, Object request) throws RestClientException {
/* 292 */     HttpEntityRequestCallback requestCallback = new HttpEntityRequestCallback(request, null);
/* 293 */     HttpHeaders headers = (HttpHeaders)execute(url, HttpMethod.POST, requestCallback, this.headersExtractor);
/* 294 */     return headers.getLocation();
/*     */   }
/*     */ 
/*     */   public <T> T postForObject(String url, Object request, Class<T> responseType, Object[] uriVariables) throws RestClientException
/*     */   {
/* 299 */     HttpEntityRequestCallback requestCallback = new HttpEntityRequestCallback(request, responseType, null);
/* 300 */     HttpMessageConverterExtractor responseExtractor = new HttpMessageConverterExtractor(responseType, getMessageConverters(), this.logger);
/*     */ 
/* 302 */     return execute(url, HttpMethod.POST, requestCallback, responseExtractor, uriVariables);
/*     */   }
/*     */ 
/*     */   public <T> T postForObject(String url, Object request, Class<T> responseType, Map<String, ?> uriVariables) throws RestClientException
/*     */   {
/* 307 */     HttpEntityRequestCallback requestCallback = new HttpEntityRequestCallback(request, responseType, null);
/* 308 */     HttpMessageConverterExtractor responseExtractor = new HttpMessageConverterExtractor(responseType, getMessageConverters(), this.logger);
/*     */ 
/* 310 */     return execute(url, HttpMethod.POST, requestCallback, responseExtractor, uriVariables);
/*     */   }
/*     */ 
/*     */   public <T> T postForObject(URI url, Object request, Class<T> responseType) throws RestClientException {
/* 314 */     HttpEntityRequestCallback requestCallback = new HttpEntityRequestCallback(request, responseType, null);
/* 315 */     HttpMessageConverterExtractor responseExtractor = new HttpMessageConverterExtractor(responseType, getMessageConverters());
/*     */ 
/* 317 */     return execute(url, HttpMethod.POST, requestCallback, responseExtractor);
/*     */   }
/*     */ 
/*     */   public <T> ResponseEntity<T> postForEntity(String url, Object request, Class<T> responseType, Object[] uriVariables)
/*     */     throws RestClientException
/*     */   {
/* 323 */     HttpEntityRequestCallback requestCallback = new HttpEntityRequestCallback(request, responseType, null);
/* 324 */     ResponseEntityResponseExtractor responseExtractor = new ResponseEntityResponseExtractor(responseType);
/*     */ 
/* 326 */     return (ResponseEntity)execute(url, HttpMethod.POST, requestCallback, responseExtractor, uriVariables);
/*     */   }
/*     */ 
/*     */   public <T> ResponseEntity<T> postForEntity(String url, Object request, Class<T> responseType, Map<String, ?> uriVariables)
/*     */     throws RestClientException
/*     */   {
/* 332 */     HttpEntityRequestCallback requestCallback = new HttpEntityRequestCallback(request, responseType, null);
/* 333 */     ResponseEntityResponseExtractor responseExtractor = new ResponseEntityResponseExtractor(responseType);
/*     */ 
/* 335 */     return (ResponseEntity)execute(url, HttpMethod.POST, requestCallback, responseExtractor, uriVariables);
/*     */   }
/*     */ 
/*     */   public <T> ResponseEntity<T> postForEntity(URI url, Object request, Class<T> responseType) throws RestClientException {
/* 339 */     HttpEntityRequestCallback requestCallback = new HttpEntityRequestCallback(request, responseType, null);
/* 340 */     ResponseEntityResponseExtractor responseExtractor = new ResponseEntityResponseExtractor(responseType);
/*     */ 
/* 342 */     return (ResponseEntity)execute(url, HttpMethod.POST, requestCallback, responseExtractor);
/*     */   }
/*     */ 
/*     */   public void put(String url, Object request, Object[] urlVariables)
/*     */     throws RestClientException
/*     */   {
/* 348 */     HttpEntityRequestCallback requestCallback = new HttpEntityRequestCallback(request, null);
/* 349 */     execute(url, HttpMethod.PUT, requestCallback, null, urlVariables);
/*     */   }
/*     */ 
/*     */   public void put(String url, Object request, Map<String, ?> urlVariables) throws RestClientException {
/* 353 */     HttpEntityRequestCallback requestCallback = new HttpEntityRequestCallback(request, null);
/* 354 */     execute(url, HttpMethod.PUT, requestCallback, null, urlVariables);
/*     */   }
/*     */ 
/*     */   public void put(URI url, Object request) throws RestClientException {
/* 358 */     HttpEntityRequestCallback requestCallback = new HttpEntityRequestCallback(request, null);
/* 359 */     execute(url, HttpMethod.PUT, requestCallback, null);
/*     */   }
/*     */ 
/*     */   public void delete(String url, Object[] urlVariables)
/*     */     throws RestClientException
/*     */   {
/* 365 */     execute(url, HttpMethod.DELETE, null, null, urlVariables);
/*     */   }
/*     */ 
/*     */   public void delete(String url, Map<String, ?> urlVariables) throws RestClientException {
/* 369 */     execute(url, HttpMethod.DELETE, null, null, urlVariables);
/*     */   }
/*     */ 
/*     */   public void delete(URI url) throws RestClientException {
/* 373 */     execute(url, HttpMethod.DELETE, null, null);
/*     */   }
/*     */ 
/*     */   public Set<HttpMethod> optionsForAllow(String url, Object[] urlVariables)
/*     */     throws RestClientException
/*     */   {
/* 379 */     HttpHeaders headers = (HttpHeaders)execute(url, HttpMethod.OPTIONS, null, this.headersExtractor, urlVariables);
/* 380 */     return headers.getAllow();
/*     */   }
/*     */ 
/*     */   public Set<HttpMethod> optionsForAllow(String url, Map<String, ?> urlVariables) throws RestClientException {
/* 384 */     HttpHeaders headers = (HttpHeaders)execute(url, HttpMethod.OPTIONS, null, this.headersExtractor, urlVariables);
/* 385 */     return headers.getAllow();
/*     */   }
/*     */ 
/*     */   public Set<HttpMethod> optionsForAllow(URI url) throws RestClientException {
/* 389 */     HttpHeaders headers = (HttpHeaders)execute(url, HttpMethod.OPTIONS, null, this.headersExtractor);
/* 390 */     return headers.getAllow();
/*     */   }
/*     */ 
/*     */   public <T> ResponseEntity<T> exchange(String url, HttpMethod method, HttpEntity<?> requestEntity, Class<T> responseType, Object[] uriVariables)
/*     */     throws RestClientException
/*     */   {
/* 398 */     HttpEntityRequestCallback requestCallback = new HttpEntityRequestCallback(requestEntity, responseType, null);
/* 399 */     ResponseEntityResponseExtractor responseExtractor = new ResponseEntityResponseExtractor(responseType);
/* 400 */     return (ResponseEntity)execute(url, method, requestCallback, responseExtractor, uriVariables);
/*     */   }
/*     */ 
/*     */   public <T> ResponseEntity<T> exchange(String url, HttpMethod method, HttpEntity<?> requestEntity, Class<T> responseType, Map<String, ?> uriVariables)
/*     */     throws RestClientException
/*     */   {
/* 406 */     HttpEntityRequestCallback requestCallback = new HttpEntityRequestCallback(requestEntity, responseType, null);
/* 407 */     ResponseEntityResponseExtractor responseExtractor = new ResponseEntityResponseExtractor(responseType);
/* 408 */     return (ResponseEntity)execute(url, method, requestCallback, responseExtractor, uriVariables);
/*     */   }
/*     */ 
/*     */   public <T> ResponseEntity<T> exchange(URI url, HttpMethod method, HttpEntity<?> requestEntity, Class<T> responseType)
/*     */     throws RestClientException
/*     */   {
/* 414 */     HttpEntityRequestCallback requestCallback = new HttpEntityRequestCallback(requestEntity, responseType, null);
/* 415 */     ResponseEntityResponseExtractor responseExtractor = new ResponseEntityResponseExtractor(responseType);
/* 416 */     return (ResponseEntity)execute(url, method, requestCallback, responseExtractor);
/*     */   }
/*     */ 
/*     */   public <T> ResponseEntity<T> exchange(String url, HttpMethod method, HttpEntity<?> requestEntity, ParameterizedTypeReference<T> responseType, Object[] uriVariables)
/*     */     throws RestClientException
/*     */   {
/* 422 */     Type type = responseType.getType();
/* 423 */     HttpEntityRequestCallback requestCallback = new HttpEntityRequestCallback(requestEntity, type, null);
/* 424 */     ResponseEntityResponseExtractor responseExtractor = new ResponseEntityResponseExtractor(type);
/* 425 */     return (ResponseEntity)execute(url, method, requestCallback, responseExtractor, uriVariables);
/*     */   }
/*     */ 
/*     */   public <T> ResponseEntity<T> exchange(String url, HttpMethod method, HttpEntity<?> requestEntity, ParameterizedTypeReference<T> responseType, Map<String, ?> uriVariables)
/*     */     throws RestClientException
/*     */   {
/* 431 */     Type type = responseType.getType();
/* 432 */     HttpEntityRequestCallback requestCallback = new HttpEntityRequestCallback(requestEntity, type, null);
/* 433 */     ResponseEntityResponseExtractor responseExtractor = new ResponseEntityResponseExtractor(type);
/* 434 */     return (ResponseEntity)execute(url, method, requestCallback, responseExtractor, uriVariables);
/*     */   }
/*     */ 
/*     */   public <T> ResponseEntity<T> exchange(URI url, HttpMethod method, HttpEntity<?> requestEntity, ParameterizedTypeReference<T> responseType)
/*     */     throws RestClientException
/*     */   {
/* 440 */     Type type = responseType.getType();
/* 441 */     HttpEntityRequestCallback requestCallback = new HttpEntityRequestCallback(requestEntity, type, null);
/* 442 */     ResponseEntityResponseExtractor responseExtractor = new ResponseEntityResponseExtractor(type);
/* 443 */     return (ResponseEntity)execute(url, method, requestCallback, responseExtractor);
/*     */   }
/*     */ 
/*     */   public <T> T execute(String url, HttpMethod method, RequestCallback requestCallback, ResponseExtractor<T> responseExtractor, Object[] urlVariables)
/*     */     throws RestClientException
/*     */   {
/* 451 */     URI expanded = new UriTemplate(url).expand(urlVariables);
/* 452 */     return doExecute(expanded, method, requestCallback, responseExtractor);
/*     */   }
/*     */ 
/*     */   public <T> T execute(String url, HttpMethod method, RequestCallback requestCallback, ResponseExtractor<T> responseExtractor, Map<String, ?> urlVariables)
/*     */     throws RestClientException
/*     */   {
/* 458 */     URI expanded = new UriTemplate(url).expand(urlVariables);
/* 459 */     return doExecute(expanded, method, requestCallback, responseExtractor);
/*     */   }
/*     */ 
/*     */   public <T> T execute(URI url, HttpMethod method, RequestCallback requestCallback, ResponseExtractor<T> responseExtractor)
/*     */     throws RestClientException
/*     */   {
/* 465 */     return doExecute(url, method, requestCallback, responseExtractor);
/*     */   }
/*     */ 
/*     */   protected <T> T doExecute(URI url, HttpMethod method, RequestCallback requestCallback, ResponseExtractor<T> responseExtractor)
/*     */     throws RestClientException
/*     */   {
/* 480 */     Assert.notNull(url, "'url' must not be null");
/* 481 */     Assert.notNull(method, "'method' must not be null");
/* 482 */     ClientHttpResponse response = null;
/*     */     try {
/* 484 */       ClientHttpRequest request = createRequest(url, method);
/* 485 */       if (requestCallback != null) {
/* 486 */         requestCallback.doWithRequest(request);
/*     */       }
/* 488 */       response = request.execute();
/* 489 */       if (!getErrorHandler().hasError(response)) {
/* 490 */         logResponseStatus(method, url, response);
/*     */       }
/*     */       else {
/* 493 */         handleResponseError(method, url, response);
/*     */       }
/* 495 */       if (responseExtractor != null) {
/* 496 */         localObject1 = responseExtractor.extractData(response);
/*     */         return localObject1;
/*     */       }
/* 499 */       Object localObject1 = null;
/*     */       return localObject1;
/*     */     }
/*     */     catch (IOException ex)
/*     */     {
/* 503 */       throw new ResourceAccessException("I/O error on " + method.name() + " request for \"" + url + "\":" + ex.getMessage(), ex);
/*     */     }
/*     */     finally
/*     */     {
/* 507 */       if (response != null)
/* 508 */         response.close(); 
/* 508 */     }throw localObject2;
/*     */   }
/*     */ 
/*     */   private void logResponseStatus(HttpMethod method, URI url, ClientHttpResponse response)
/*     */   {
/* 514 */     if (this.logger.isDebugEnabled())
/*     */       try {
/* 516 */         this.logger.debug(method.name() + " request for \"" + url + "\" resulted in " + response.getStatusCode() + " (" + response.getStatusText() + ")");
/*     */       }
/*     */       catch (IOException e)
/*     */       {
/*     */       }
/*     */   }
/*     */ 
/*     */   private void handleResponseError(HttpMethod method, URI url, ClientHttpResponse response)
/*     */     throws IOException
/*     */   {
/* 527 */     if (this.logger.isWarnEnabled()) {
/*     */       try {
/* 529 */         this.logger.warn(method.name() + " request for \"" + url + "\" resulted in " + response.getStatusCode() + " (" + response.getStatusText() + "); invoking error handler");
/*     */       }
/*     */       catch (IOException e)
/*     */       {
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 537 */     getErrorHandler().handleError(response);
/*     */   }
/*     */ 
/*     */   private static class HeadersExtractor
/*     */     implements ResponseExtractor<HttpHeaders>
/*     */   {
/*     */     public HttpHeaders extractData(ClientHttpResponse response)
/*     */       throws IOException
/*     */     {
/* 709 */       return response.getHeaders();
/*     */     }
/*     */   }
/*     */ 
/*     */   private class ResponseEntityResponseExtractor<T>
/*     */     implements ResponseExtractor<ResponseEntity<T>>
/*     */   {
/*     */     private final HttpMessageConverterExtractor<T> delegate;
/*     */ 
/*     */     public ResponseEntityResponseExtractor(Type responseType)
/*     */     {
/* 684 */       if ((responseType != null) && (!Void.class.equals(responseType)))
/* 685 */         this.delegate = new HttpMessageConverterExtractor(responseType, RestTemplate.this.getMessageConverters(), RestTemplate.this.logger);
/*     */       else
/* 687 */         this.delegate = null;
/*     */     }
/*     */ 
/*     */     public ResponseEntity<T> extractData(ClientHttpResponse response) throws IOException
/*     */     {
/* 692 */       if (this.delegate != null) {
/* 693 */         Object body = this.delegate.extractData(response);
/* 694 */         return new ResponseEntity(body, response.getHeaders(), response.getStatusCode());
/*     */       }
/*     */ 
/* 697 */       return new ResponseEntity(response.getHeaders(), response.getStatusCode());
/*     */     }
/*     */   }
/*     */ 
/*     */   private class HttpEntityRequestCallback extends RestTemplate.AcceptHeaderRequestCallback
/*     */   {
/*     */     private final HttpEntity requestEntity;
/*     */ 
/*     */     private HttpEntityRequestCallback(Object requestBody)
/*     */     {
/* 610 */       this(requestBody, null);
/*     */     }
/*     */ 
/*     */     private HttpEntityRequestCallback(Object requestBody, Type responseType)
/*     */     {
/* 615 */       super(responseType, null);
/* 616 */       if ((requestBody instanceof HttpEntity)) {
/* 617 */         this.requestEntity = ((HttpEntity)requestBody);
/*     */       }
/* 619 */       else if (requestBody != null) {
/* 620 */         this.requestEntity = new HttpEntity(requestBody);
/*     */       }
/*     */       else
/* 623 */         this.requestEntity = HttpEntity.EMPTY;
/*     */     }
/*     */ 
/*     */     public void doWithRequest(ClientHttpRequest httpRequest)
/*     */       throws IOException
/*     */     {
/* 630 */       super.doWithRequest(httpRequest);
/* 631 */       if (!this.requestEntity.hasBody()) {
/* 632 */         HttpHeaders httpHeaders = httpRequest.getHeaders();
/* 633 */         HttpHeaders requestHeaders = this.requestEntity.getHeaders();
/* 634 */         if (!requestHeaders.isEmpty()) {
/* 635 */           httpHeaders.putAll(requestHeaders);
/*     */         }
/* 637 */         if (httpHeaders.getContentLength() == -1L)
/* 638 */           httpHeaders.setContentLength(0L);
/*     */       }
/*     */       else
/*     */       {
/* 642 */         Object requestBody = this.requestEntity.getBody();
/* 643 */         Class requestType = requestBody.getClass();
/* 644 */         HttpHeaders requestHeaders = this.requestEntity.getHeaders();
/* 645 */         MediaType requestContentType = requestHeaders.getContentType();
/* 646 */         for (HttpMessageConverter messageConverter : RestTemplate.this.getMessageConverters()) {
/* 647 */           if (messageConverter.canWrite(requestType, requestContentType)) {
/* 648 */             if (!requestHeaders.isEmpty()) {
/* 649 */               httpRequest.getHeaders().putAll(requestHeaders);
/*     */             }
/* 651 */             if (RestTemplate.this.logger.isDebugEnabled()) {
/* 652 */               if (requestContentType != null) {
/* 653 */                 RestTemplate.this.logger.debug("Writing [" + requestBody + "] as \"" + requestContentType + "\" using [" + messageConverter + "]");
/*     */               }
/*     */               else
/*     */               {
/* 657 */                 RestTemplate.this.logger.debug("Writing [" + requestBody + "] using [" + messageConverter + "]");
/*     */               }
/*     */             }
/*     */ 
/* 661 */             messageConverter.write(requestBody, requestContentType, httpRequest);
/* 662 */             return;
/*     */           }
/*     */         }
/* 665 */         String message = "Could not write request: no suitable HttpMessageConverter found for request type [" + requestType.getName() + "]";
/*     */ 
/* 667 */         if (requestContentType != null) {
/* 668 */           message = message + " and content type [" + requestContentType + "]";
/*     */         }
/* 670 */         throw new RestClientException(message);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private class AcceptHeaderRequestCallback
/*     */     implements RequestCallback
/*     */   {
/*     */     private final Type responseType;
/*     */ 
/*     */     private AcceptHeaderRequestCallback(Type responseType)
/*     */     {
/* 549 */       this.responseType = responseType;
/*     */     }
/*     */ 
/*     */     public void doWithRequest(ClientHttpRequest request) throws IOException
/*     */     {
/* 554 */       if (this.responseType != null) {
/* 555 */         Class responseClass = null;
/* 556 */         if ((this.responseType instanceof Class)) {
/* 557 */           responseClass = (Class)this.responseType;
/*     */         }
/*     */ 
/* 560 */         List allSupportedMediaTypes = new ArrayList();
/* 561 */         for (HttpMessageConverter converter : RestTemplate.this.getMessageConverters()) {
/* 562 */           if (responseClass != null) {
/* 563 */             if (converter.canRead(responseClass, null)) {
/* 564 */               allSupportedMediaTypes.addAll(getSupportedMediaTypes(converter));
/*     */             }
/*     */           }
/* 567 */           else if ((converter instanceof GenericHttpMessageConverter))
/*     */           {
/* 569 */             GenericHttpMessageConverter genericConverter = (GenericHttpMessageConverter)converter;
/* 570 */             if (genericConverter.canRead(this.responseType, null, null)) {
/* 571 */               allSupportedMediaTypes.addAll(getSupportedMediaTypes(converter));
/*     */             }
/*     */           }
/*     */         }
/*     */ 
/* 576 */         if (!allSupportedMediaTypes.isEmpty()) {
/* 577 */           MediaType.sortBySpecificity(allSupportedMediaTypes);
/* 578 */           if (RestTemplate.this.logger.isDebugEnabled()) {
/* 579 */             RestTemplate.this.logger.debug("Setting request Accept header to " + allSupportedMediaTypes);
/*     */           }
/*     */ 
/* 582 */           request.getHeaders().setAccept(allSupportedMediaTypes);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*     */     private List<MediaType> getSupportedMediaTypes(HttpMessageConverter<?> messageConverter) {
/* 588 */       List supportedMediaTypes = messageConverter.getSupportedMediaTypes();
/* 589 */       List result = new ArrayList(supportedMediaTypes.size());
/* 590 */       for (MediaType supportedMediaType : supportedMediaTypes) {
/* 591 */         if (supportedMediaType.getCharSet() != null) {
/* 592 */           supportedMediaType = new MediaType(supportedMediaType.getType(), supportedMediaType.getSubtype());
/*     */         }
/*     */ 
/* 595 */         result.add(supportedMediaType);
/*     */       }
/* 597 */       return result;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.web.client.RestTemplate
 * JD-Core Version:    0.6.0
 */