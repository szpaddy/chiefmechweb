package org.springframework.web.client;

import java.io.IOException;
import org.springframework.http.client.ClientHttpResponse;

public abstract interface ResponseExtractor<T>
{
  public abstract T extractData(ClientHttpResponse paramClientHttpResponse)
    throws IOException;
}

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.web.client.ResponseExtractor
 * JD-Core Version:    0.6.0
 */