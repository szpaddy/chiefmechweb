package org.springframework.web.method.support;

import org.springframework.core.MethodParameter;
import org.springframework.web.bind.support.WebDataBinderFactory;
import org.springframework.web.context.request.NativeWebRequest;

public abstract interface HandlerMethodArgumentResolver
{
  public abstract boolean supportsParameter(MethodParameter paramMethodParameter);

  public abstract Object resolveArgument(MethodParameter paramMethodParameter, ModelAndViewContainer paramModelAndViewContainer, NativeWebRequest paramNativeWebRequest, WebDataBinderFactory paramWebDataBinderFactory)
    throws Exception;
}

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.web.method.support.HandlerMethodArgumentResolver
 * JD-Core Version:    0.6.0
 */