/*     */ package org.springframework.web.method.support;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Arrays;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.core.GenericTypeResolver;
/*     */ import org.springframework.core.LocalVariableTableParameterNameDiscoverer;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.ParameterNameDiscoverer;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ import org.springframework.web.bind.support.WebDataBinderFactory;
/*     */ import org.springframework.web.context.request.NativeWebRequest;
/*     */ import org.springframework.web.method.HandlerMethod;
/*     */ 
/*     */ public class InvocableHandlerMethod extends HandlerMethod
/*     */ {
/*  50 */   private HandlerMethodArgumentResolverComposite argumentResolvers = new HandlerMethodArgumentResolverComposite();
/*     */   private WebDataBinderFactory dataBinderFactory;
/*  54 */   private ParameterNameDiscoverer parameterNameDiscoverer = new LocalVariableTableParameterNameDiscoverer();
/*     */ 
/*     */   public InvocableHandlerMethod(Object bean, Method method)
/*     */   {
/*  61 */     super(bean, method);
/*     */   }
/*     */ 
/*     */   public InvocableHandlerMethod(HandlerMethod handlerMethod)
/*     */   {
/*  68 */     super(handlerMethod);
/*     */   }
/*     */ 
/*     */   public InvocableHandlerMethod(Object bean, String methodName, Class<?>[] parameterTypes)
/*     */     throws NoSuchMethodException
/*     */   {
/*  80 */     super(bean, methodName, parameterTypes);
/*     */   }
/*     */ 
/*     */   public void setDataBinderFactory(WebDataBinderFactory dataBinderFactory)
/*     */   {
/*  89 */     this.dataBinderFactory = dataBinderFactory;
/*     */   }
/*     */ 
/*     */   public void setHandlerMethodArgumentResolvers(HandlerMethodArgumentResolverComposite argumentResolvers)
/*     */   {
/*  96 */     this.argumentResolvers = argumentResolvers;
/*     */   }
/*     */ 
/*     */   public void setParameterNameDiscoverer(ParameterNameDiscoverer parameterNameDiscoverer)
/*     */   {
/* 104 */     this.parameterNameDiscoverer = parameterNameDiscoverer;
/*     */   }
/*     */ 
/*     */   public final Object invokeForRequest(NativeWebRequest request, ModelAndViewContainer mavContainer, Object[] providedArgs)
/*     */     throws Exception
/*     */   {
/* 123 */     Object[] args = getMethodArgumentValues(request, mavContainer, providedArgs);
/*     */ 
/* 125 */     if (this.logger.isTraceEnabled()) {
/* 126 */       StringBuilder builder = new StringBuilder("Invoking [");
/* 127 */       builder.append(getMethod().getName()).append("] method with arguments ");
/* 128 */       builder.append(Arrays.asList(args));
/* 129 */       this.logger.trace(builder.toString());
/*     */     }
/*     */ 
/* 132 */     Object returnValue = invoke(args);
/*     */ 
/* 134 */     if (this.logger.isTraceEnabled()) {
/* 135 */       this.logger.trace("Method [" + getMethod().getName() + "] returned [" + returnValue + "]");
/*     */     }
/*     */ 
/* 138 */     return returnValue;
/*     */   }
/*     */ 
/*     */   private Object[] getMethodArgumentValues(NativeWebRequest request, ModelAndViewContainer mavContainer, Object[] providedArgs)
/*     */     throws Exception
/*     */   {
/* 148 */     MethodParameter[] parameters = getMethodParameters();
/* 149 */     Object[] args = new Object[parameters.length];
/* 150 */     for (int i = 0; i < parameters.length; i++) {
/* 151 */       MethodParameter parameter = parameters[i];
/* 152 */       parameter.initParameterNameDiscovery(this.parameterNameDiscoverer);
/* 153 */       GenericTypeResolver.resolveParameterType(parameter, getBean().getClass());
/*     */ 
/* 155 */       args[i] = resolveProvidedArgument(parameter, providedArgs);
/* 156 */       if (args[i] != null)
/*     */       {
/*     */         continue;
/*     */       }
/* 160 */       if (this.argumentResolvers.supportsParameter(parameter)) {
/*     */         try {
/* 162 */           args[i] = this.argumentResolvers.resolveArgument(parameter, mavContainer, request, this.dataBinderFactory);
/*     */         }
/*     */         catch (Exception ex) {
/* 165 */           if (this.logger.isTraceEnabled()) {
/* 166 */             this.logger.trace(getArgumentResolutionErrorMessage("Error resolving argument", i), ex);
/*     */           }
/* 168 */           throw ex;
/*     */         }
/*     */ 
/*     */       }
/* 172 */       else if (args[i] == null) {
/* 173 */         String msg = getArgumentResolutionErrorMessage("No suitable resolver for argument", i);
/* 174 */         throw new IllegalStateException(msg);
/*     */       }
/*     */     }
/* 177 */     return args;
/*     */   }
/*     */ 
/*     */   private String getArgumentResolutionErrorMessage(String message, int index) {
/* 181 */     MethodParameter param = getMethodParameters()[index];
/* 182 */     message = message + " [" + index + "] [type=" + param.getParameterType().getName() + "]";
/* 183 */     return getDetailedErrorMessage(message);
/*     */   }
/*     */ 
/*     */   protected String getDetailedErrorMessage(String message)
/*     */   {
/* 191 */     StringBuilder sb = new StringBuilder(message).append("\n");
/* 192 */     sb.append("HandlerMethod details: \n");
/* 193 */     sb.append("Controller [").append(getBeanType().getName()).append("]\n");
/* 194 */     sb.append("Method [").append(getBridgedMethod().toGenericString()).append("]\n");
/* 195 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   private Object resolveProvidedArgument(MethodParameter parameter, Object[] providedArgs)
/*     */   {
/* 202 */     if (providedArgs == null) {
/* 203 */       return null;
/*     */     }
/* 205 */     for (Object providedArg : providedArgs) {
/* 206 */       if (parameter.getParameterType().isInstance(providedArg)) {
/* 207 */         return providedArg;
/*     */       }
/*     */     }
/* 210 */     return null;
/*     */   }
/* 217 */   private Object invoke(Object[] args) throws Exception { ReflectionUtils.makeAccessible(getBridgedMethod());
/*     */     Throwable targetException;
/*     */     String msg;
/*     */     try { return getBridgedMethod().invoke(getBean(), args);
/*     */     } catch (IllegalArgumentException e)
/*     */     {
/* 222 */       String msg = getInvocationErrorMessage(e.getMessage(), args);
/* 223 */       throw new IllegalArgumentException(msg, e);
/*     */     }
/*     */     catch (InvocationTargetException e)
/*     */     {
/* 227 */       targetException = e.getTargetException();
/* 228 */       if ((targetException instanceof RuntimeException)) {
/* 229 */         throw ((RuntimeException)targetException);
/*     */       }
/* 231 */       if ((targetException instanceof Error)) {
/* 232 */         throw ((Error)targetException);
/*     */       }
/* 234 */       if ((targetException instanceof Exception)) {
/* 235 */         throw ((Exception)targetException);
/*     */       }
/*     */ 
/* 238 */       msg = getInvocationErrorMessage("Failed to invoke controller method", args);
/* 239 */     }throw new IllegalStateException(msg, targetException);
/*     */   }
/*     */ 
/*     */   private String getInvocationErrorMessage(String message, Object[] resolvedArgs)
/*     */   {
/* 245 */     StringBuilder sb = new StringBuilder(getDetailedErrorMessage(message));
/* 246 */     sb.append("Resolved arguments: \n");
/* 247 */     for (int i = 0; i < resolvedArgs.length; i++) {
/* 248 */       sb.append("[").append(i).append("] ");
/* 249 */       if (resolvedArgs[i] == null) {
/* 250 */         sb.append("[null] \n");
/*     */       }
/*     */       else {
/* 253 */         sb.append("[type=").append(resolvedArgs[i].getClass().getName()).append("] ");
/* 254 */         sb.append("[value=").append(resolvedArgs[i]).append("]\n");
/*     */       }
/*     */     }
/* 257 */     return sb.toString();
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.web.method.support.InvocableHandlerMethod
 * JD-Core Version:    0.6.0
 */