/*     */ package org.springframework.web.method.annotation;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.springframework.core.ExceptionDepthComparator;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ReflectionUtils.MethodFilter;
/*     */ import org.springframework.web.bind.annotation.ExceptionHandler;
/*     */ import org.springframework.web.method.HandlerMethodSelector;
/*     */ 
/*     */ public class ExceptionHandlerMethodResolver
/*     */ {
/*  46 */   private static final Method NO_METHOD_FOUND = ClassUtils.getMethodIfAvailable(System.class, "currentTimeMillis", new Class[0]);
/*     */ 
/*  48 */   private final Map<Class<? extends Throwable>, Method> mappedMethods = new ConcurrentHashMap(16);
/*     */ 
/*  51 */   private final Map<Class<? extends Throwable>, Method> exceptionLookupCache = new ConcurrentHashMap(16);
/*     */ 
/* 144 */   public static final ReflectionUtils.MethodFilter EXCEPTION_HANDLER_METHODS = new ReflectionUtils.MethodFilter()
/*     */   {
/*     */     public boolean matches(Method method) {
/* 147 */       return AnnotationUtils.findAnnotation(method, ExceptionHandler.class) != null;
/*     */     }
/* 144 */   };
/*     */ 
/*     */   public ExceptionHandlerMethodResolver(Class<?> handlerType)
/*     */   {
/*  59 */     for (Iterator i$ = HandlerMethodSelector.selectMethods(handlerType, EXCEPTION_HANDLER_METHODS).iterator(); i$.hasNext(); ) { method = (Method)i$.next();
/*  60 */       for (Class exceptionType : detectExceptionMappings(method))
/*  61 */         addExceptionMapping(exceptionType, method);
/*     */     }
/*     */     Method method;
/*     */   }
/*     */ 
/*     */   private List<Class<? extends Throwable>> detectExceptionMappings(Method method)
/*     */   {
/*  72 */     List result = new ArrayList();
/*     */ 
/*  74 */     ExceptionHandler annotation = (ExceptionHandler)AnnotationUtils.findAnnotation(method, ExceptionHandler.class);
/*  75 */     result.addAll(Arrays.asList(annotation.value()));
/*     */ 
/*  77 */     if (result.isEmpty()) {
/*  78 */       for (Class paramType : method.getParameterTypes()) {
/*  79 */         if (Throwable.class.isAssignableFrom(paramType)) {
/*  80 */           result.add(paramType);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*  85 */     Assert.notEmpty(result, "No exception types mapped to {" + method + "}");
/*     */ 
/*  87 */     return result;
/*     */   }
/*     */ 
/*     */   private void addExceptionMapping(Class<? extends Throwable> exceptionType, Method method) {
/*  91 */     Method oldMethod = (Method)this.mappedMethods.put(exceptionType, method);
/*  92 */     if ((oldMethod != null) && (!oldMethod.equals(method)))
/*  93 */       throw new IllegalStateException("Ambiguous @ExceptionHandler method mapped for [" + exceptionType + "]: {" + oldMethod + ", " + method + "}.");
/*     */   }
/*     */ 
/*     */   public boolean hasExceptionMappings()
/*     */   {
/* 103 */     return this.mappedMethods.size() > 0;
/*     */   }
/*     */ 
/*     */   public Method resolveMethod(Exception exception)
/*     */   {
/* 113 */     Class exceptionType = exception.getClass();
/* 114 */     Method method = (Method)this.exceptionLookupCache.get(exceptionType);
/* 115 */     if (method == null) {
/* 116 */       method = getMappedMethod(exceptionType);
/* 117 */       this.exceptionLookupCache.put(exceptionType, method != null ? method : NO_METHOD_FOUND);
/*     */     }
/* 119 */     return method != NO_METHOD_FOUND ? method : null;
/*     */   }
/*     */ 
/*     */   private Method getMappedMethod(Class<? extends Exception> exceptionType)
/*     */   {
/* 126 */     List matches = new ArrayList();
/* 127 */     for (Class mappedException : this.mappedMethods.keySet()) {
/* 128 */       if (mappedException.isAssignableFrom(exceptionType)) {
/* 129 */         matches.add(mappedException);
/*     */       }
/*     */     }
/* 132 */     if (!matches.isEmpty()) {
/* 133 */       Collections.sort(matches, new ExceptionDepthComparator(exceptionType));
/* 134 */       return (Method)this.mappedMethods.get(matches.get(0));
/*     */     }
/*     */ 
/* 137 */     return null;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.web.method.annotation.ExceptionHandlerMethodResolver
 * JD-Core Version:    0.6.0
 */