/*     */ package org.springframework.web.method.annotation;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.core.Conventions;
/*     */ import org.springframework.core.GenericTypeResolver;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.ui.ModelMap;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.validation.BindingResult;
/*     */ import org.springframework.web.HttpSessionRequiredException;
/*     */ import org.springframework.web.bind.WebDataBinder;
/*     */ import org.springframework.web.bind.annotation.ModelAttribute;
/*     */ import org.springframework.web.bind.support.SessionStatus;
/*     */ import org.springframework.web.bind.support.WebDataBinderFactory;
/*     */ import org.springframework.web.context.request.NativeWebRequest;
/*     */ import org.springframework.web.method.HandlerMethod;
/*     */ import org.springframework.web.method.support.InvocableHandlerMethod;
/*     */ import org.springframework.web.method.support.ModelAndViewContainer;
/*     */ 
/*     */ public final class ModelFactory
/*     */ {
/*     */   private final List<InvocableHandlerMethod> attributeMethods;
/*     */   private final WebDataBinderFactory binderFactory;
/*     */   private final SessionAttributesHandler sessionAttributesHandler;
/*     */ 
/*     */   public ModelFactory(List<InvocableHandlerMethod> attributeMethods, WebDataBinderFactory binderFactory, SessionAttributesHandler sessionAttributesHandler)
/*     */   {
/*  71 */     this.attributeMethods = (attributeMethods != null ? attributeMethods : new ArrayList());
/*  72 */     this.binderFactory = binderFactory;
/*  73 */     this.sessionAttributesHandler = sessionAttributesHandler;
/*     */   }
/*     */ 
/*     */   public void initModel(NativeWebRequest request, ModelAndViewContainer mavContainer, HandlerMethod handlerMethod)
/*     */     throws Exception
/*     */   {
/*  94 */     Map attributesInSession = this.sessionAttributesHandler.retrieveAttributes(request);
/*  95 */     mavContainer.mergeAttributes(attributesInSession);
/*     */ 
/*  97 */     invokeModelAttributeMethods(request, mavContainer);
/*     */ 
/*  99 */     for (String name : findSessionAttributeArguments(handlerMethod))
/* 100 */       if (!mavContainer.containsAttribute(name)) {
/* 101 */         Object value = this.sessionAttributesHandler.retrieveAttribute(request, name);
/* 102 */         if (value == null) {
/* 103 */           throw new HttpSessionRequiredException("Expected session attribute '" + name + "'");
/*     */         }
/* 105 */         mavContainer.addAttribute(name, value);
/*     */       }
/*     */   }
/*     */ 
/*     */   private void invokeModelAttributeMethods(NativeWebRequest request, ModelAndViewContainer mavContainer)
/*     */     throws Exception
/*     */   {
/* 117 */     for (InvocableHandlerMethod attrMethod : this.attributeMethods) {
/* 118 */       String modelName = ((ModelAttribute)attrMethod.getMethodAnnotation(ModelAttribute.class)).value();
/* 119 */       if (mavContainer.containsAttribute(modelName))
/*     */       {
/*     */         continue;
/*     */       }
/* 123 */       Object returnValue = attrMethod.invokeForRequest(request, mavContainer, new Object[0]);
/*     */ 
/* 125 */       if (!attrMethod.isVoid()) {
/* 126 */         String returnValueName = getNameForReturnValue(returnValue, attrMethod.getReturnType());
/* 127 */         if (!mavContainer.containsAttribute(returnValueName))
/* 128 */           mavContainer.addAttribute(returnValueName, returnValue);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private List<String> findSessionAttributeArguments(HandlerMethod handlerMethod)
/*     */   {
/* 139 */     List result = new ArrayList();
/* 140 */     for (MethodParameter param : handlerMethod.getMethodParameters()) {
/* 141 */       if (param.hasParameterAnnotation(ModelAttribute.class)) {
/* 142 */         String name = getNameForParameter(param);
/* 143 */         if (this.sessionAttributesHandler.isHandlerSessionAttribute(name, param.getParameterType())) {
/* 144 */           result.add(name);
/*     */         }
/*     */       }
/*     */     }
/* 148 */     return result;
/*     */   }
/*     */ 
/*     */   public static String getNameForReturnValue(Object returnValue, MethodParameter returnType)
/*     */   {
/* 164 */     ModelAttribute annot = (ModelAttribute)returnType.getMethodAnnotation(ModelAttribute.class);
/* 165 */     if ((annot != null) && (StringUtils.hasText(annot.value()))) {
/* 166 */       return annot.value();
/*     */     }
/*     */ 
/* 169 */     Method method = returnType.getMethod();
/* 170 */     Class resolvedType = GenericTypeResolver.resolveReturnType(method, returnType.getDeclaringClass());
/* 171 */     return Conventions.getVariableNameForReturnType(method, resolvedType, returnValue);
/*     */   }
/*     */ 
/*     */   public static String getNameForParameter(MethodParameter parameter)
/*     */   {
/* 184 */     ModelAttribute annot = (ModelAttribute)parameter.getParameterAnnotation(ModelAttribute.class);
/* 185 */     String attrName = annot != null ? annot.value() : null;
/* 186 */     return StringUtils.hasText(attrName) ? attrName : Conventions.getVariableNameForParameter(parameter);
/*     */   }
/*     */ 
/*     */   public void updateModel(NativeWebRequest request, ModelAndViewContainer mavContainer)
/*     */     throws Exception
/*     */   {
/* 198 */     if (mavContainer.getSessionStatus().isComplete()) {
/* 199 */       this.sessionAttributesHandler.cleanupAttributes(request);
/*     */     }
/*     */     else {
/* 202 */       this.sessionAttributesHandler.storeAttributes(request, mavContainer.getModel());
/*     */     }
/*     */ 
/* 205 */     if (!mavContainer.isRequestHandled())
/* 206 */       updateBindingResult(request, mavContainer.getModel());
/*     */   }
/*     */ 
/*     */   private void updateBindingResult(NativeWebRequest request, ModelMap model)
/*     */     throws Exception
/*     */   {
/* 214 */     List keyNames = new ArrayList(model.keySet());
/* 215 */     for (String name : keyNames) {
/* 216 */       Object value = model.get(name);
/*     */ 
/* 218 */       if (isBindingCandidate(name, value)) {
/* 219 */         String bindingResultKey = BindingResult.MODEL_KEY_PREFIX + name;
/*     */ 
/* 221 */         if (!model.containsAttribute(bindingResultKey)) {
/* 222 */           WebDataBinder dataBinder = this.binderFactory.createBinder(request, value, name);
/* 223 */           model.put(bindingResultKey, dataBinder.getBindingResult());
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private boolean isBindingCandidate(String attributeName, Object value)
/*     */   {
/* 233 */     if (attributeName.startsWith(BindingResult.MODEL_KEY_PREFIX)) {
/* 234 */       return false;
/*     */     }
/*     */ 
/* 237 */     Class attrType = value != null ? value.getClass() : null;
/* 238 */     if (this.sessionAttributesHandler.isHandlerSessionAttribute(attributeName, attrType)) {
/* 239 */       return true;
/*     */     }
/*     */ 
/* 242 */     return (value != null) && (!value.getClass().isArray()) && (!(value instanceof Collection)) && (!(value instanceof Map)) && (!BeanUtils.isSimpleValueType(value.getClass()));
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.web.method.annotation.ModelFactory
 * JD-Core Version:    0.6.0
 */