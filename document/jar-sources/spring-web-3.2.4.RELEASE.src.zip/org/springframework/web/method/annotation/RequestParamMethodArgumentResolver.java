/*     */ package org.springframework.web.method.annotation;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.factory.config.ConfigurableBeanFactory;
/*     */ import org.springframework.core.GenericCollectionTypeResolver;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.bind.MissingServletRequestParameterException;
/*     */ import org.springframework.web.bind.annotation.RequestParam;
/*     */ import org.springframework.web.bind.annotation.RequestPart;
/*     */ import org.springframework.web.context.request.NativeWebRequest;
/*     */ import org.springframework.web.multipart.MultipartException;
/*     */ import org.springframework.web.multipart.MultipartFile;
/*     */ import org.springframework.web.multipart.MultipartHttpServletRequest;
/*     */ import org.springframework.web.util.WebUtils;
/*     */ 
/*     */ public class RequestParamMethodArgumentResolver extends AbstractNamedValueMethodArgumentResolver
/*     */ {
/*     */   private final boolean useDefaultResolution;
/*     */ 
/*     */   public RequestParamMethodArgumentResolver(ConfigurableBeanFactory beanFactory, boolean useDefaultResolution)
/*     */   {
/*  86 */     super(beanFactory);
/*  87 */     this.useDefaultResolution = useDefaultResolution;
/*     */   }
/*     */ 
/*     */   public boolean supportsParameter(MethodParameter parameter)
/*     */   {
/* 106 */     Class paramType = parameter.getParameterType();
/* 107 */     if (parameter.hasParameterAnnotation(RequestParam.class)) {
/* 108 */       if (Map.class.isAssignableFrom(paramType)) {
/* 109 */         String paramName = ((RequestParam)parameter.getParameterAnnotation(RequestParam.class)).value();
/* 110 */         return StringUtils.hasText(paramName);
/*     */       }
/*     */ 
/* 113 */       return true;
/*     */     }
/*     */ 
/* 117 */     if (parameter.hasParameterAnnotation(RequestPart.class)) {
/* 118 */       return false;
/*     */     }
/* 120 */     if ((MultipartFile.class.equals(paramType)) || ("javax.servlet.http.Part".equals(paramType.getName()))) {
/* 121 */       return true;
/*     */     }
/* 123 */     if (this.useDefaultResolution) {
/* 124 */       return BeanUtils.isSimpleProperty(paramType);
/*     */     }
/*     */ 
/* 127 */     return false;
/*     */   }
/*     */ 
/*     */   protected AbstractNamedValueMethodArgumentResolver.NamedValueInfo createNamedValueInfo(MethodParameter parameter)
/*     */   {
/* 134 */     RequestParam annotation = (RequestParam)parameter.getParameterAnnotation(RequestParam.class);
/* 135 */     return annotation != null ? new RequestParamNamedValueInfo(annotation, null) : new RequestParamNamedValueInfo(null);
/*     */   }
/*     */ 
/*     */   protected Object resolveName(String name, MethodParameter parameter, NativeWebRequest webRequest)
/*     */     throws Exception
/*     */   {
/* 145 */     HttpServletRequest servletRequest = (HttpServletRequest)webRequest.getNativeRequest(HttpServletRequest.class);
/* 146 */     MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest)WebUtils.getNativeRequest(servletRequest, MultipartHttpServletRequest.class);
/*     */     Object arg;
/*     */     Object arg;
/* 149 */     if (MultipartFile.class.equals(parameter.getParameterType())) {
/* 150 */       assertIsMultipartRequest(servletRequest);
/* 151 */       Assert.notNull(multipartRequest, "Expected MultipartHttpServletRequest: is a MultipartResolver configured?");
/* 152 */       arg = multipartRequest.getFile(name);
/*     */     }
/*     */     else
/*     */     {
/*     */       Object arg;
/* 154 */       if (isMultipartFileCollection(parameter)) {
/* 155 */         assertIsMultipartRequest(servletRequest);
/* 156 */         Assert.notNull(multipartRequest, "Expected MultipartHttpServletRequest: is a MultipartResolver configured?");
/* 157 */         arg = multipartRequest.getFiles(name);
/*     */       }
/*     */       else
/*     */       {
/*     */         Object arg;
/* 159 */         if ("javax.servlet.http.Part".equals(parameter.getParameterType().getName())) {
/* 160 */           assertIsMultipartRequest(servletRequest);
/* 161 */           arg = servletRequest.getPart(name);
/*     */         }
/*     */         else {
/* 164 */           arg = null;
/* 165 */           if (multipartRequest != null) {
/* 166 */             List files = multipartRequest.getFiles(name);
/* 167 */             if (!files.isEmpty()) {
/* 168 */               arg = files.size() == 1 ? files.get(0) : files;
/*     */             }
/*     */           }
/* 171 */           if (arg == null) {
/* 172 */             String[] paramValues = webRequest.getParameterValues(name);
/* 173 */             if (paramValues != null)
/* 174 */               arg = paramValues.length == 1 ? paramValues[0] : paramValues;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 179 */     return arg;
/*     */   }
/*     */ 
/*     */   private void assertIsMultipartRequest(HttpServletRequest request) {
/* 183 */     String contentType = request.getContentType();
/* 184 */     if ((contentType == null) || (!contentType.toLowerCase().startsWith("multipart/")))
/* 185 */       throw new MultipartException("The current request is not a multipart request");
/*     */   }
/*     */ 
/*     */   private boolean isMultipartFileCollection(MethodParameter parameter)
/*     */   {
/* 190 */     Class paramType = parameter.getParameterType();
/* 191 */     if ((Collection.class.equals(paramType)) || (List.class.isAssignableFrom(paramType))) {
/* 192 */       Class valueType = GenericCollectionTypeResolver.getCollectionParameterType(parameter);
/* 193 */       if ((valueType != null) && (valueType.equals(MultipartFile.class))) {
/* 194 */         return true;
/*     */       }
/*     */     }
/* 197 */     return false;
/*     */   }
/*     */ 
/*     */   protected void handleMissingValue(String paramName, MethodParameter parameter) throws ServletException
/*     */   {
/* 202 */     throw new MissingServletRequestParameterException(paramName, parameter.getParameterType().getSimpleName());
/*     */   }
/*     */ 
/*     */   private class RequestParamNamedValueInfo extends AbstractNamedValueMethodArgumentResolver.NamedValueInfo
/*     */   {
/*     */     private RequestParamNamedValueInfo() {
/* 208 */       super(false, "\n\t\t\n\t\t\n\n\t\t\t\t\n");
/*     */     }
/*     */ 
/*     */     private RequestParamNamedValueInfo(RequestParam annotation) {
/* 212 */       super(annotation.required(), annotation.defaultValue());
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.web.method.annotation.RequestParamMethodArgumentResolver
 * JD-Core Version:    0.6.0
 */