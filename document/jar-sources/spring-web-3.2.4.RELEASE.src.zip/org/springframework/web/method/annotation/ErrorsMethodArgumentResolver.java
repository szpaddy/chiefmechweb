/*    */ package org.springframework.web.method.annotation;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import org.springframework.core.MethodParameter;
/*    */ import org.springframework.ui.ModelMap;
/*    */ import org.springframework.validation.BindingResult;
/*    */ import org.springframework.validation.Errors;
/*    */ import org.springframework.web.bind.support.WebDataBinderFactory;
/*    */ import org.springframework.web.context.request.NativeWebRequest;
/*    */ import org.springframework.web.method.support.HandlerMethodArgumentResolver;
/*    */ import org.springframework.web.method.support.ModelAndViewContainer;
/*    */ 
/*    */ public class ErrorsMethodArgumentResolver
/*    */   implements HandlerMethodArgumentResolver
/*    */ {
/*    */   public boolean supportsParameter(MethodParameter parameter)
/*    */   {
/* 44 */     Class paramType = parameter.getParameterType();
/* 45 */     return Errors.class.isAssignableFrom(paramType);
/*    */   }
/*    */ 
/*    */   public Object resolveArgument(MethodParameter parameter, ModelAndViewContainer mavContainer, NativeWebRequest webRequest, WebDataBinderFactory binderFactory)
/*    */     throws Exception
/*    */   {
/* 53 */     ModelMap model = mavContainer.getModel();
/* 54 */     if (model.size() > 0) {
/* 55 */       int lastIndex = model.size() - 1;
/* 56 */       String lastKey = (String)new ArrayList(model.keySet()).get(lastIndex);
/* 57 */       if (lastKey.startsWith(BindingResult.MODEL_KEY_PREFIX)) {
/* 58 */         return model.get(lastKey);
/*    */       }
/*    */     }
/*    */ 
/* 62 */     throw new IllegalStateException("An Errors/BindingResult argument is expected to be declared immediately after the model attribute, the @RequestBody or the @RequestPart arguments to which they apply: " + parameter.getMethod());
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.web.method.annotation.ErrorsMethodArgumentResolver
 * JD-Core Version:    0.6.0
 */