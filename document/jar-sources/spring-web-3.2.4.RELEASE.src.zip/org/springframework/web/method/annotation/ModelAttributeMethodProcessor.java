/*     */ package org.springframework.web.method.annotation;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.ui.ModelMap;
/*     */ import org.springframework.validation.BindException;
/*     */ import org.springframework.validation.BindingResult;
/*     */ import org.springframework.validation.Errors;
/*     */ import org.springframework.web.bind.WebDataBinder;
/*     */ import org.springframework.web.bind.annotation.ModelAttribute;
/*     */ import org.springframework.web.bind.support.WebDataBinderFactory;
/*     */ import org.springframework.web.bind.support.WebRequestDataBinder;
/*     */ import org.springframework.web.context.request.NativeWebRequest;
/*     */ import org.springframework.web.method.support.HandlerMethodArgumentResolver;
/*     */ import org.springframework.web.method.support.HandlerMethodReturnValueHandler;
/*     */ import org.springframework.web.method.support.ModelAndViewContainer;
/*     */ 
/*     */ public class ModelAttributeMethodProcessor
/*     */   implements HandlerMethodArgumentResolver, HandlerMethodReturnValueHandler
/*     */ {
/*  57 */   protected Log logger = LogFactory.getLog(getClass());
/*     */   private final boolean annotationNotRequired;
/*     */ 
/*     */   public ModelAttributeMethodProcessor(boolean annotationNotRequired)
/*     */   {
/*  67 */     this.annotationNotRequired = annotationNotRequired;
/*     */   }
/*     */ 
/*     */   public boolean supportsParameter(MethodParameter parameter)
/*     */   {
/*  75 */     if (parameter.hasParameterAnnotation(ModelAttribute.class)) {
/*  76 */       return true;
/*     */     }
/*  78 */     if (this.annotationNotRequired) {
/*  79 */       return !BeanUtils.isSimpleProperty(parameter.getParameterType());
/*     */     }
/*     */ 
/*  82 */     return false;
/*     */   }
/*     */ 
/*     */   public final Object resolveArgument(MethodParameter parameter, ModelAndViewContainer mavContainer, NativeWebRequest request, WebDataBinderFactory binderFactory)
/*     */     throws Exception
/*     */   {
/* 100 */     String name = ModelFactory.getNameForParameter(parameter);
/* 101 */     Object attribute = mavContainer.containsAttribute(name) ? mavContainer.getModel().get(name) : createAttribute(name, parameter, binderFactory, request);
/*     */ 
/* 104 */     WebDataBinder binder = binderFactory.createBinder(request, attribute, name);
/* 105 */     if (binder.getTarget() != null) {
/* 106 */       bindRequestParameters(binder, request);
/* 107 */       validateIfApplicable(binder, parameter);
/* 108 */       if ((binder.getBindingResult().hasErrors()) && 
/* 109 */         (isBindExceptionRequired(binder, parameter))) {
/* 110 */         throw new BindException(binder.getBindingResult());
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 117 */     Map bindingResultModel = binder.getBindingResult().getModel();
/* 118 */     mavContainer.removeAttributes(bindingResultModel);
/* 119 */     mavContainer.addAllAttributes(bindingResultModel);
/*     */ 
/* 121 */     return binder.getTarget();
/*     */   }
/*     */ 
/*     */   protected Object createAttribute(String attributeName, MethodParameter parameter, WebDataBinderFactory binderFactory, NativeWebRequest request)
/*     */     throws Exception
/*     */   {
/* 136 */     return BeanUtils.instantiateClass(parameter.getParameterType());
/*     */   }
/*     */ 
/*     */   protected void bindRequestParameters(WebDataBinder binder, NativeWebRequest request)
/*     */   {
/* 145 */     ((WebRequestDataBinder)binder).bind(request);
/*     */   }
/*     */ 
/*     */   protected void validateIfApplicable(WebDataBinder binder, MethodParameter parameter)
/*     */   {
/* 155 */     Annotation[] annotations = parameter.getParameterAnnotations();
/* 156 */     for (Annotation annot : annotations)
/* 157 */       if (annot.annotationType().getSimpleName().startsWith("Valid")) {
/* 158 */         Object hints = AnnotationUtils.getValue(annot);
/* 159 */         binder.validate(new Object[] { (hints instanceof Object[]) ? (Object[])(Object[])hints : hints });
/* 160 */         break;
/*     */       }
/*     */   }
/*     */ 
/*     */   protected boolean isBindExceptionRequired(WebDataBinder binder, MethodParameter parameter)
/*     */   {
/* 172 */     int i = parameter.getParameterIndex();
/* 173 */     Class[] paramTypes = parameter.getMethod().getParameterTypes();
/* 174 */     boolean hasBindingResult = (paramTypes.length > i + 1) && (Errors.class.isAssignableFrom(paramTypes[(i + 1)]));
/*     */ 
/* 176 */     return !hasBindingResult;
/*     */   }
/*     */ 
/*     */   public boolean supportsReturnType(MethodParameter returnType)
/*     */   {
/* 184 */     if (returnType.getMethodAnnotation(ModelAttribute.class) != null) {
/* 185 */       return true;
/*     */     }
/* 187 */     if (this.annotationNotRequired) {
/* 188 */       return !BeanUtils.isSimpleProperty(returnType.getParameterType());
/*     */     }
/*     */ 
/* 191 */     return false;
/*     */   }
/*     */ 
/*     */   public void handleReturnValue(Object returnValue, MethodParameter returnType, ModelAndViewContainer mavContainer, NativeWebRequest webRequest)
/*     */     throws Exception
/*     */   {
/* 203 */     if (returnValue != null) {
/* 204 */       String name = ModelFactory.getNameForReturnValue(returnValue, returnType);
/* 205 */       mavContainer.addAttribute(name, returnValue);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.web.method.annotation.ModelAttributeMethodProcessor
 * JD-Core Version:    0.6.0
 */