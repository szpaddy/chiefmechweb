/*    */ package org.springframework.web.method.annotation;
/*    */ 
/*    */ import org.springframework.beans.factory.config.ConfigurableBeanFactory;
/*    */ import org.springframework.core.MethodParameter;
/*    */ import org.springframework.web.bind.ServletRequestBindingException;
/*    */ import org.springframework.web.bind.annotation.CookieValue;
/*    */ 
/*    */ public abstract class AbstractCookieValueMethodArgumentResolver extends AbstractNamedValueMethodArgumentResolver
/*    */ {
/*    */   public AbstractCookieValueMethodArgumentResolver(ConfigurableBeanFactory beanFactory)
/*    */   {
/* 48 */     super(beanFactory);
/*    */   }
/*    */ 
/*    */   public boolean supportsParameter(MethodParameter parameter) {
/* 52 */     return parameter.hasParameterAnnotation(CookieValue.class);
/*    */   }
/*    */ 
/*    */   protected AbstractNamedValueMethodArgumentResolver.NamedValueInfo createNamedValueInfo(MethodParameter parameter)
/*    */   {
/* 57 */     CookieValue annotation = (CookieValue)parameter.getParameterAnnotation(CookieValue.class);
/* 58 */     return new CookieValueNamedValueInfo(annotation, null);
/*    */   }
/*    */ 
/*    */   protected void handleMissingValue(String cookieName, MethodParameter param) throws ServletRequestBindingException
/*    */   {
/* 63 */     String paramType = param.getParameterType().getName();
/* 64 */     throw new ServletRequestBindingException("Missing cookie named '" + cookieName + "' for method parameter type [" + paramType + "]");
/*    */   }
/*    */ 
/*    */   private static class CookieValueNamedValueInfo extends AbstractNamedValueMethodArgumentResolver.NamedValueInfo
/*    */   {
/*    */     private CookieValueNamedValueInfo(CookieValue annotation)
/*    */     {
/* 71 */       super(annotation.required(), annotation.defaultValue());
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.web.method.annotation.AbstractCookieValueMethodArgumentResolver
 * JD-Core Version:    0.6.0
 */