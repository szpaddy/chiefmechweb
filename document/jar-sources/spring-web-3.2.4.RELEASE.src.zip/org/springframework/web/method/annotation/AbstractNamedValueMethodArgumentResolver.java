/*     */ package org.springframework.web.method.annotation;
/*     */ 
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import javax.servlet.ServletException;
/*     */ import org.springframework.beans.factory.config.BeanExpressionContext;
/*     */ import org.springframework.beans.factory.config.BeanExpressionResolver;
/*     */ import org.springframework.beans.factory.config.ConfigurableBeanFactory;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.bind.WebDataBinder;
/*     */ import org.springframework.web.bind.support.WebDataBinderFactory;
/*     */ import org.springframework.web.context.request.NativeWebRequest;
/*     */ import org.springframework.web.context.request.RequestScope;
/*     */ import org.springframework.web.method.support.HandlerMethodArgumentResolver;
/*     */ import org.springframework.web.method.support.ModelAndViewContainer;
/*     */ 
/*     */ public abstract class AbstractNamedValueMethodArgumentResolver
/*     */   implements HandlerMethodArgumentResolver
/*     */ {
/*     */   private final ConfigurableBeanFactory configurableBeanFactory;
/*     */   private final BeanExpressionContext expressionContext;
/*  64 */   private Map<MethodParameter, NamedValueInfo> namedValueInfoCache = new ConcurrentHashMap(256);
/*     */ 
/*     */   public AbstractNamedValueMethodArgumentResolver(ConfigurableBeanFactory beanFactory)
/*     */   {
/*  73 */     this.configurableBeanFactory = beanFactory;
/*  74 */     this.expressionContext = (beanFactory != null ? new BeanExpressionContext(beanFactory, new RequestScope()) : null);
/*     */   }
/*     */ 
/*     */   public final Object resolveArgument(MethodParameter parameter, ModelAndViewContainer mavContainer, NativeWebRequest webRequest, WebDataBinderFactory binderFactory)
/*     */     throws Exception
/*     */   {
/*  83 */     Class paramType = parameter.getParameterType();
/*  84 */     NamedValueInfo namedValueInfo = getNamedValueInfo(parameter);
/*     */ 
/*  86 */     Object arg = resolveName(namedValueInfo.name, parameter, webRequest);
/*  87 */     if (arg == null) {
/*  88 */       if (namedValueInfo.defaultValue != null) {
/*  89 */         arg = resolveDefaultValue(namedValueInfo.defaultValue);
/*     */       }
/*  91 */       else if (namedValueInfo.required) {
/*  92 */         handleMissingValue(namedValueInfo.name, parameter);
/*     */       }
/*  94 */       arg = handleNullValue(namedValueInfo.name, arg, paramType);
/*     */     }
/*  96 */     else if (("".equals(arg)) && (namedValueInfo.defaultValue != null)) {
/*  97 */       arg = resolveDefaultValue(namedValueInfo.defaultValue);
/*     */     }
/*     */ 
/* 100 */     if (binderFactory != null) {
/* 101 */       WebDataBinder binder = binderFactory.createBinder(webRequest, null, namedValueInfo.name);
/* 102 */       arg = binder.convertIfNecessary(arg, paramType, parameter);
/*     */     }
/*     */ 
/* 105 */     handleResolvedValue(arg, namedValueInfo.name, parameter, mavContainer, webRequest);
/*     */ 
/* 107 */     return arg;
/*     */   }
/*     */ 
/*     */   private NamedValueInfo getNamedValueInfo(MethodParameter parameter)
/*     */   {
/* 114 */     NamedValueInfo namedValueInfo = (NamedValueInfo)this.namedValueInfoCache.get(parameter);
/* 115 */     if (namedValueInfo == null) {
/* 116 */       namedValueInfo = createNamedValueInfo(parameter);
/* 117 */       namedValueInfo = updateNamedValueInfo(parameter, namedValueInfo);
/* 118 */       this.namedValueInfoCache.put(parameter, namedValueInfo);
/*     */     }
/* 120 */     return namedValueInfo;
/*     */   }
/*     */ 
/*     */   protected abstract NamedValueInfo createNamedValueInfo(MethodParameter paramMethodParameter);
/*     */ 
/*     */   private NamedValueInfo updateNamedValueInfo(MethodParameter parameter, NamedValueInfo info)
/*     */   {
/* 135 */     String name = info.name;
/* 136 */     if (info.name.length() == 0) {
/* 137 */       name = parameter.getParameterName();
/* 138 */       Assert.notNull(name, "Name for argument type [" + parameter.getParameterType().getName() + "] not available, and parameter name information not found in class file either.");
/*     */     }
/*     */ 
/* 141 */     String defaultValue = "\n\t\t\n\t\t\n\n\t\t\t\t\n".equals(info.defaultValue) ? null : info.defaultValue;
/* 142 */     return new NamedValueInfo(name, info.required, defaultValue);
/*     */   }
/*     */ 
/*     */   protected abstract Object resolveName(String paramString, MethodParameter paramMethodParameter, NativeWebRequest paramNativeWebRequest)
/*     */     throws Exception;
/*     */ 
/*     */   private Object resolveDefaultValue(String defaultValue)
/*     */   {
/* 160 */     if (this.configurableBeanFactory == null) {
/* 161 */       return defaultValue;
/*     */     }
/* 163 */     String placeholdersResolved = this.configurableBeanFactory.resolveEmbeddedValue(defaultValue);
/* 164 */     BeanExpressionResolver exprResolver = this.configurableBeanFactory.getBeanExpressionResolver();
/* 165 */     if (exprResolver == null) {
/* 166 */       return defaultValue;
/*     */     }
/* 168 */     return exprResolver.evaluate(placeholdersResolved, this.expressionContext);
/*     */   }
/*     */ 
/*     */   protected abstract void handleMissingValue(String paramString, MethodParameter paramMethodParameter)
/*     */     throws ServletException;
/*     */ 
/*     */   private Object handleNullValue(String name, Object value, Class<?> paramType)
/*     */   {
/* 183 */     if (value == null) {
/* 184 */       if (Boolean.TYPE.equals(paramType)) {
/* 185 */         return Boolean.FALSE;
/*     */       }
/* 187 */       if (paramType.isPrimitive()) {
/* 188 */         throw new IllegalStateException("Optional " + paramType + " parameter '" + name + "' is present but cannot be translated into a null value due to being declared as a " + "primitive type. Consider declaring it as object wrapper for the corresponding primitive type.");
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 193 */     return value;
/*     */   }
/*     */ 
/*     */   protected void handleResolvedValue(Object arg, String name, MethodParameter parameter, ModelAndViewContainer mavContainer, NativeWebRequest webRequest)
/*     */   {
/*     */   }
/*     */ 
/*     */   protected static class NamedValueInfo
/*     */   {
/*     */     private final String name;
/*     */     private final boolean required;
/*     */     private final String defaultValue;
/*     */ 
/*     */     protected NamedValueInfo(String name, boolean required, String defaultValue)
/*     */     {
/* 221 */       this.name = name;
/* 222 */       this.required = required;
/* 223 */       this.defaultValue = defaultValue;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.web.method.annotation.AbstractNamedValueMethodArgumentResolver
 * JD-Core Version:    0.6.0
 */