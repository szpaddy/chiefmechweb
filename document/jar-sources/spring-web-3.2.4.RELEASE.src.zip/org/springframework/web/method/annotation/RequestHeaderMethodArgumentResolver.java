/*    */ package org.springframework.web.method.annotation;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.springframework.beans.factory.config.ConfigurableBeanFactory;
/*    */ import org.springframework.core.MethodParameter;
/*    */ import org.springframework.web.bind.ServletRequestBindingException;
/*    */ import org.springframework.web.bind.annotation.RequestHeader;
/*    */ import org.springframework.web.context.request.NativeWebRequest;
/*    */ 
/*    */ public class RequestHeaderMethodArgumentResolver extends AbstractNamedValueMethodArgumentResolver
/*    */ {
/*    */   public RequestHeaderMethodArgumentResolver(ConfigurableBeanFactory beanFactory)
/*    */   {
/* 52 */     super(beanFactory);
/*    */   }
/*    */ 
/*    */   public boolean supportsParameter(MethodParameter parameter) {
/* 56 */     return (parameter.hasParameterAnnotation(RequestHeader.class)) && (!Map.class.isAssignableFrom(parameter.getParameterType()));
/*    */   }
/*    */ 
/*    */   protected AbstractNamedValueMethodArgumentResolver.NamedValueInfo createNamedValueInfo(MethodParameter parameter)
/*    */   {
/* 62 */     RequestHeader annotation = (RequestHeader)parameter.getParameterAnnotation(RequestHeader.class);
/* 63 */     return new RequestHeaderNamedValueInfo(annotation, null);
/*    */   }
/*    */ 
/*    */   protected Object resolveName(String name, MethodParameter parameter, NativeWebRequest request) throws Exception
/*    */   {
/* 68 */     String[] headerValues = request.getHeaderValues(name);
/* 69 */     if (headerValues != null) {
/* 70 */       return headerValues.length == 1 ? headerValues[0] : headerValues;
/*    */     }
/*    */ 
/* 73 */     return null;
/*    */   }
/*    */ 
/*    */   protected void handleMissingValue(String headerName, MethodParameter param)
/*    */     throws ServletRequestBindingException
/*    */   {
/* 79 */     String paramType = param.getParameterType().getName();
/* 80 */     throw new ServletRequestBindingException("Missing header '" + headerName + "' for method parameter type [" + paramType + "]");
/*    */   }
/*    */ 
/*    */   private static class RequestHeaderNamedValueInfo extends AbstractNamedValueMethodArgumentResolver.NamedValueInfo
/*    */   {
/*    */     private RequestHeaderNamedValueInfo(RequestHeader annotation)
/*    */     {
/* 87 */       super(annotation.required(), annotation.defaultValue());
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.web.method.annotation.RequestHeaderMethodArgumentResolver
 * JD-Core Version:    0.6.0
 */