/*     */ package org.springframework.web.method;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Method;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.core.BridgeMethodResolver;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ public class HandlerMethod
/*     */ {
/*  49 */   protected final Log logger = LogFactory.getLog(HandlerMethod.class);
/*     */   private final Object bean;
/*     */   private final Method method;
/*     */   private final BeanFactory beanFactory;
/*     */   private final MethodParameter[] parameters;
/*     */   private final Method bridgedMethod;
/*     */ 
/*     */   public HandlerMethod(Object bean, Method method)
/*     */   {
/*  66 */     Assert.notNull(bean, "bean is required");
/*  67 */     Assert.notNull(method, "method is required");
/*  68 */     this.bean = bean;
/*  69 */     this.beanFactory = null;
/*  70 */     this.method = method;
/*  71 */     this.bridgedMethod = BridgeMethodResolver.findBridgedMethod(method);
/*  72 */     this.parameters = initMethodParameters();
/*     */   }
/*     */ 
/*     */   private MethodParameter[] initMethodParameters() {
/*  76 */     int count = this.bridgedMethod.getParameterTypes().length;
/*  77 */     MethodParameter[] result = new MethodParameter[count];
/*  78 */     for (int i = 0; i < count; i++) {
/*  79 */       result[i] = new HandlerMethodParameter(i);
/*     */     }
/*  81 */     return result;
/*     */   }
/*     */ 
/*     */   public HandlerMethod(Object bean, String methodName, Class<?>[] parameterTypes)
/*     */     throws NoSuchMethodException
/*     */   {
/*  89 */     Assert.notNull(bean, "bean is required");
/*  90 */     Assert.notNull(methodName, "method is required");
/*  91 */     this.bean = bean;
/*  92 */     this.beanFactory = null;
/*  93 */     this.method = bean.getClass().getMethod(methodName, parameterTypes);
/*  94 */     this.bridgedMethod = BridgeMethodResolver.findBridgedMethod(this.method);
/*  95 */     this.parameters = initMethodParameters();
/*     */   }
/*     */ 
/*     */   public HandlerMethod(String beanName, BeanFactory beanFactory, Method method)
/*     */   {
/* 104 */     Assert.hasText(beanName, "beanName is required");
/* 105 */     Assert.notNull(beanFactory, "beanFactory is required");
/* 106 */     Assert.notNull(method, "method is required");
/* 107 */     Assert.isTrue(beanFactory.containsBean(beanName), "Bean factory [" + beanFactory + "] does not contain bean [" + beanName + "]");
/*     */ 
/* 109 */     this.bean = beanName;
/* 110 */     this.beanFactory = beanFactory;
/* 111 */     this.method = method;
/* 112 */     this.bridgedMethod = BridgeMethodResolver.findBridgedMethod(method);
/* 113 */     this.parameters = initMethodParameters();
/*     */   }
/*     */ 
/*     */   protected HandlerMethod(HandlerMethod handlerMethod)
/*     */   {
/* 120 */     Assert.notNull(handlerMethod, "HandlerMethod is required");
/* 121 */     this.bean = handlerMethod.bean;
/* 122 */     this.beanFactory = handlerMethod.beanFactory;
/* 123 */     this.method = handlerMethod.method;
/* 124 */     this.bridgedMethod = handlerMethod.bridgedMethod;
/* 125 */     this.parameters = handlerMethod.parameters;
/*     */   }
/*     */ 
/*     */   private HandlerMethod(HandlerMethod handlerMethod, Object handler)
/*     */   {
/* 132 */     Assert.notNull(handlerMethod, "handlerMethod is required");
/* 133 */     Assert.notNull(handler, "handler is required");
/* 134 */     this.bean = handler;
/* 135 */     this.beanFactory = handlerMethod.beanFactory;
/* 136 */     this.method = handlerMethod.method;
/* 137 */     this.bridgedMethod = handlerMethod.bridgedMethod;
/* 138 */     this.parameters = handlerMethod.parameters;
/*     */   }
/*     */ 
/*     */   public Object getBean()
/*     */   {
/* 145 */     return this.bean;
/*     */   }
/*     */ 
/*     */   public Method getMethod()
/*     */   {
/* 152 */     return this.method;
/*     */   }
/*     */ 
/*     */   public Class<?> getBeanType()
/*     */   {
/* 160 */     Class clazz = (this.bean instanceof String) ? this.beanFactory.getType((String)this.bean) : this.bean.getClass();
/*     */ 
/* 163 */     return ClassUtils.getUserClass(clazz);
/*     */   }
/*     */ 
/*     */   protected Method getBridgedMethod()
/*     */   {
/* 171 */     return this.bridgedMethod;
/*     */   }
/*     */ 
/*     */   public MethodParameter[] getMethodParameters()
/*     */   {
/* 178 */     return this.parameters;
/*     */   }
/*     */ 
/*     */   public MethodParameter getReturnType()
/*     */   {
/* 185 */     return new HandlerMethodParameter(-1);
/*     */   }
/*     */ 
/*     */   public MethodParameter getReturnValueType(Object returnValue)
/*     */   {
/* 192 */     return new ReturnValueMethodParameter(returnValue);
/*     */   }
/*     */ 
/*     */   public boolean isVoid()
/*     */   {
/* 199 */     return Void.TYPE.equals(getReturnType().getParameterType());
/*     */   }
/*     */ 
/*     */   public <A extends Annotation> A getMethodAnnotation(Class<A> annotationType)
/*     */   {
/* 209 */     return AnnotationUtils.findAnnotation(this.method, annotationType);
/*     */   }
/*     */ 
/*     */   public HandlerMethod createWithResolvedBean()
/*     */   {
/* 217 */     Object handler = this.bean;
/* 218 */     if ((this.bean instanceof String)) {
/* 219 */       String beanName = (String)this.bean;
/* 220 */       handler = this.beanFactory.getBean(beanName);
/*     */     }
/* 222 */     return new HandlerMethod(this, handler);
/*     */   }
/*     */ 
/*     */   public boolean equals(Object o)
/*     */   {
/* 227 */     if (this == o) {
/* 228 */       return true;
/*     */     }
/* 230 */     if ((o != null) && ((o instanceof HandlerMethod))) {
/* 231 */       HandlerMethod other = (HandlerMethod)o;
/* 232 */       return (this.bean.equals(other.bean)) && (this.method.equals(other.method));
/*     */     }
/* 234 */     return false;
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 239 */     return 31 * this.bean.hashCode() + this.method.hashCode();
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 244 */     return this.method.toGenericString();
/*     */   }
/*     */ 
/*     */   private class ReturnValueMethodParameter extends HandlerMethod.HandlerMethodParameter
/*     */   {
/*     */     private final Object returnValue;
/*     */ 
/*     */     public ReturnValueMethodParameter(Object returnValue)
/*     */     {
/* 275 */       super(-1);
/* 276 */       this.returnValue = returnValue;
/*     */     }
/*     */ 
/*     */     public Class<?> getParameterType()
/*     */     {
/* 281 */       return this.returnValue != null ? this.returnValue.getClass() : super.getParameterType();
/*     */     }
/*     */   }
/*     */ 
/*     */   private class HandlerMethodParameter extends MethodParameter
/*     */   {
/*     */     protected HandlerMethodParameter(int index)
/*     */     {
/* 253 */       super(index);
/*     */     }
/*     */ 
/*     */     public Class<?> getDeclaringClass()
/*     */     {
/* 258 */       return HandlerMethod.this.getBeanType();
/*     */     }
/*     */ 
/*     */     public <T extends Annotation> T getMethodAnnotation(Class<T> annotationType)
/*     */     {
/* 263 */       return HandlerMethod.this.getMethodAnnotation(annotationType);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.web.method.HandlerMethod
 * JD-Core Version:    0.6.0
 */