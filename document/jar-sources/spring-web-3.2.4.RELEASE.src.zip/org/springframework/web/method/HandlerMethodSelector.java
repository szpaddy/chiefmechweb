/*    */ package org.springframework.web.method;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import java.lang.reflect.Proxy;
/*    */ import java.util.Arrays;
/*    */ import java.util.LinkedHashSet;
/*    */ import java.util.Set;
/*    */ import org.springframework.core.BridgeMethodResolver;
/*    */ import org.springframework.util.ClassUtils;
/*    */ import org.springframework.util.ReflectionUtils;
/*    */ import org.springframework.util.ReflectionUtils.MethodCallback;
/*    */ import org.springframework.util.ReflectionUtils.MethodFilter;
/*    */ 
/*    */ public abstract class HandlerMethodSelector
/*    */ {
/*    */   public static Set<Method> selectMethods(Class<?> handlerType, ReflectionUtils.MethodFilter handlerMethodFilter)
/*    */   {
/* 48 */     Set handlerMethods = new LinkedHashSet();
/* 49 */     Set handlerTypes = new LinkedHashSet();
/* 50 */     Class specificHandlerType = null;
/* 51 */     if (!Proxy.isProxyClass(handlerType)) {
/* 52 */       handlerTypes.add(handlerType);
/* 53 */       specificHandlerType = handlerType;
/*    */     }
/* 55 */     handlerTypes.addAll(Arrays.asList(handlerType.getInterfaces()));
/* 56 */     for (Class currentHandlerType : handlerTypes) {
/* 57 */       Class targetClass = specificHandlerType != null ? specificHandlerType : currentHandlerType;
/* 58 */       ReflectionUtils.doWithMethods(currentHandlerType, new ReflectionUtils.MethodCallback(targetClass, handlerMethodFilter, handlerMethods) {
/*    */         public void doWith(Method method) {
/* 60 */           Method specificMethod = ClassUtils.getMostSpecificMethod(method, this.val$targetClass);
/* 61 */           Method bridgedMethod = BridgeMethodResolver.findBridgedMethod(specificMethod);
/* 62 */           if ((this.val$handlerMethodFilter.matches(specificMethod)) && ((bridgedMethod == specificMethod) || (!this.val$handlerMethodFilter.matches(bridgedMethod))))
/*    */           {
/* 64 */             this.val$handlerMethods.add(specificMethod);
/*    */           }
/*    */         }
/*    */       }
/*    */       , ReflectionUtils.USER_DECLARED_METHODS);
/*    */     }
/*    */ 
/* 69 */     return handlerMethods;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.web.method.HandlerMethodSelector
 * JD-Core Version:    0.6.0
 */