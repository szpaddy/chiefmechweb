/*     */ package org.springframework.web.method;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.core.Ordered;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.core.annotation.Order;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.web.bind.annotation.ControllerAdvice;
/*     */ 
/*     */ public class ControllerAdviceBean
/*     */   implements Ordered
/*     */ {
/*     */   private final Object bean;
/*     */   private final int order;
/*     */   private final BeanFactory beanFactory;
/*     */ 
/*     */   public ControllerAdviceBean(String beanName, BeanFactory beanFactory)
/*     */   {
/*  56 */     Assert.hasText(beanName, "'beanName' must not be null");
/*  57 */     Assert.notNull(beanFactory, "'beanFactory' must not be null");
/*  58 */     Assert.isTrue(beanFactory.containsBean(beanName), "Bean factory [" + beanFactory + "] does not contain bean " + "with name [" + beanName + "]");
/*     */ 
/*  60 */     this.bean = beanName;
/*  61 */     this.beanFactory = beanFactory;
/*  62 */     this.order = initOrderFromBeanType(this.beanFactory.getType(beanName));
/*     */   }
/*     */ 
/*     */   private static int initOrderFromBeanType(Class<?> beanType) {
/*  66 */     Order annot = (Order)AnnotationUtils.findAnnotation(beanType, Order.class);
/*  67 */     return annot != null ? annot.value() : 2147483647;
/*     */   }
/*     */ 
/*     */   public ControllerAdviceBean(Object bean)
/*     */   {
/*  75 */     Assert.notNull(bean, "'bean' must not be null");
/*  76 */     this.bean = bean;
/*  77 */     this.order = initOrderFromBean(bean);
/*  78 */     this.beanFactory = null;
/*     */   }
/*     */ 
/*     */   private static int initOrderFromBean(Object bean) {
/*  82 */     return (bean instanceof Ordered) ? ((Ordered)bean).getOrder() : initOrderFromBeanType(bean.getClass());
/*     */   }
/*     */ 
/*     */   public static List<ControllerAdviceBean> findAnnotatedBeans(ApplicationContext applicationContext)
/*     */   {
/*  91 */     List beans = new ArrayList();
/*  92 */     for (String name : applicationContext.getBeanDefinitionNames()) {
/*  93 */       if (applicationContext.findAnnotationOnBean(name, ControllerAdvice.class) != null) {
/*  94 */         beans.add(new ControllerAdviceBean(name, applicationContext));
/*     */       }
/*     */     }
/*  97 */     return beans;
/*     */   }
/*     */ 
/*     */   public int getOrder()
/*     */   {
/* 105 */     return this.order;
/*     */   }
/*     */ 
/*     */   public Class<?> getBeanType()
/*     */   {
/* 113 */     Class clazz = (this.bean instanceof String) ? this.beanFactory.getType((String)this.bean) : this.bean.getClass();
/*     */ 
/* 116 */     return ClassUtils.getUserClass(clazz);
/*     */   }
/*     */ 
/*     */   public Object resolveBean()
/*     */   {
/* 123 */     return (this.bean instanceof String) ? this.beanFactory.getBean((String)this.bean) : this.bean;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object o)
/*     */   {
/* 128 */     if (this == o) {
/* 129 */       return true;
/*     */     }
/* 131 */     if ((o != null) && ((o instanceof ControllerAdviceBean))) {
/* 132 */       ControllerAdviceBean other = (ControllerAdviceBean)o;
/* 133 */       return this.bean.equals(other.bean);
/*     */     }
/* 135 */     return false;
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 140 */     return 31 * this.bean.hashCode();
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 145 */     return this.bean.toString();
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.web.method.ControllerAdviceBean
 * JD-Core Version:    0.6.0
 */