package org.springframework.web;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;

public abstract interface WebApplicationInitializer
{
  public abstract void onStartup(ServletContext paramServletContext)
    throws ServletException;
}

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.web.WebApplicationInitializer
 * JD-Core Version:    0.6.0
 */