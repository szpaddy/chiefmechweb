/*    */ package org.springframework.web;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.springframework.http.MediaType;
/*    */ 
/*    */ public class HttpMediaTypeNotAcceptableException extends HttpMediaTypeException
/*    */ {
/*    */   public HttpMediaTypeNotAcceptableException(String message)
/*    */   {
/* 37 */     super(message);
/*    */   }
/*    */ 
/*    */   public HttpMediaTypeNotAcceptableException(List<MediaType> supportedMediaTypes)
/*    */   {
/* 45 */     super("Could not find acceptable representation", supportedMediaTypes);
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.web.HttpMediaTypeNotAcceptableException
 * JD-Core Version:    0.6.0
 */