/*     */ package org.springframework.web.context.support;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Collections;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.faces.context.ExternalContext;
/*     */ import javax.faces.context.FacesContext;
/*     */ import javax.servlet.ServletConfig;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import org.springframework.beans.factory.ObjectFactory;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.core.env.MutablePropertySources;
/*     */ import org.springframework.core.env.PropertySource.StubPropertySource;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.web.context.WebApplicationContext;
/*     */ import org.springframework.web.context.request.RequestAttributes;
/*     */ import org.springframework.web.context.request.RequestContextHolder;
/*     */ import org.springframework.web.context.request.RequestScope;
/*     */ import org.springframework.web.context.request.ServletRequestAttributes;
/*     */ import org.springframework.web.context.request.ServletWebRequest;
/*     */ import org.springframework.web.context.request.SessionScope;
/*     */ import org.springframework.web.context.request.WebRequest;
/*     */ 
/*     */ public abstract class WebApplicationContextUtils
/*     */ {
/*  71 */   private static final boolean jsfPresent = ClassUtils.isPresent("javax.faces.context.FacesContext", RequestContextHolder.class.getClassLoader());
/*     */ 
/*     */   public static WebApplicationContext getRequiredWebApplicationContext(ServletContext sc)
/*     */     throws IllegalStateException
/*     */   {
/*  88 */     WebApplicationContext wac = getWebApplicationContext(sc);
/*  89 */     if (wac == null) {
/*  90 */       throw new IllegalStateException("No WebApplicationContext found: no ContextLoaderListener registered?");
/*     */     }
/*  92 */     return wac;
/*     */   }
/*     */ 
/*     */   public static WebApplicationContext getWebApplicationContext(ServletContext sc)
/*     */   {
/* 105 */     return getWebApplicationContext(sc, WebApplicationContext.ROOT_WEB_APPLICATION_CONTEXT_ATTRIBUTE);
/*     */   }
/*     */ 
/*     */   public static WebApplicationContext getWebApplicationContext(ServletContext sc, String attrName)
/*     */   {
/* 115 */     Assert.notNull(sc, "ServletContext must not be null");
/* 116 */     Object attr = sc.getAttribute(attrName);
/* 117 */     if (attr == null) {
/* 118 */       return null;
/*     */     }
/* 120 */     if ((attr instanceof RuntimeException)) {
/* 121 */       throw ((RuntimeException)attr);
/*     */     }
/* 123 */     if ((attr instanceof Error)) {
/* 124 */       throw ((Error)attr);
/*     */     }
/* 126 */     if ((attr instanceof Exception)) {
/* 127 */       throw new IllegalStateException((Exception)attr);
/*     */     }
/* 129 */     if (!(attr instanceof WebApplicationContext)) {
/* 130 */       throw new IllegalStateException("Context attribute is not of type WebApplicationContext: " + attr);
/*     */     }
/* 132 */     return (WebApplicationContext)attr;
/*     */   }
/*     */ 
/*     */   public static void registerWebApplicationScopes(ConfigurableListableBeanFactory beanFactory)
/*     */   {
/* 142 */     registerWebApplicationScopes(beanFactory, null);
/*     */   }
/*     */ 
/*     */   public static void registerWebApplicationScopes(ConfigurableListableBeanFactory beanFactory, ServletContext sc)
/*     */   {
/* 152 */     beanFactory.registerScope("request", new RequestScope());
/* 153 */     beanFactory.registerScope("session", new SessionScope(false));
/* 154 */     beanFactory.registerScope("globalSession", new SessionScope(true));
/* 155 */     if (sc != null) {
/* 156 */       ServletContextScope appScope = new ServletContextScope(sc);
/* 157 */       beanFactory.registerScope("application", appScope);
/*     */ 
/* 159 */       sc.setAttribute(ServletContextScope.class.getName(), appScope);
/*     */     }
/*     */ 
/* 162 */     beanFactory.registerResolvableDependency(ServletRequest.class, new RequestObjectFactory(null));
/* 163 */     beanFactory.registerResolvableDependency(HttpSession.class, new SessionObjectFactory(null));
/* 164 */     beanFactory.registerResolvableDependency(WebRequest.class, new WebRequestObjectFactory(null));
/* 165 */     if (jsfPresent)
/* 166 */       FacesDependencyRegistrar.registerFacesDependencies(beanFactory);
/*     */   }
/*     */ 
/*     */   public static void registerEnvironmentBeans(ConfigurableListableBeanFactory bf, ServletContext sc)
/*     */   {
/* 177 */     registerEnvironmentBeans(bf, sc, null);
/*     */   }
/*     */ 
/*     */   public static void registerEnvironmentBeans(ConfigurableListableBeanFactory bf, ServletContext sc, ServletConfig config)
/*     */   {
/* 190 */     if ((sc != null) && (!bf.containsBean("servletContext"))) {
/* 191 */       bf.registerSingleton("servletContext", sc);
/*     */     }
/*     */ 
/* 194 */     if ((config != null) && (!bf.containsBean("servletConfig"))) {
/* 195 */       bf.registerSingleton("servletConfig", config);
/*     */     }
/*     */ 
/* 198 */     if (!bf.containsBean("contextParameters")) {
/* 199 */       Map parameterMap = new HashMap();
/* 200 */       if (sc != null) {
/* 201 */         Enumeration paramNameEnum = sc.getInitParameterNames();
/* 202 */         while (paramNameEnum.hasMoreElements()) {
/* 203 */           String paramName = (String)paramNameEnum.nextElement();
/* 204 */           parameterMap.put(paramName, sc.getInitParameter(paramName));
/*     */         }
/*     */       }
/* 207 */       if (config != null) {
/* 208 */         Enumeration paramNameEnum = config.getInitParameterNames();
/* 209 */         while (paramNameEnum.hasMoreElements()) {
/* 210 */           String paramName = (String)paramNameEnum.nextElement();
/* 211 */           parameterMap.put(paramName, config.getInitParameter(paramName));
/*     */         }
/*     */       }
/* 214 */       bf.registerSingleton("contextParameters", Collections.unmodifiableMap(parameterMap));
/*     */     }
/*     */ 
/* 218 */     if (!bf.containsBean("contextAttributes")) {
/* 219 */       Map attributeMap = new HashMap();
/* 220 */       if (sc != null) {
/* 221 */         Enumeration attrNameEnum = sc.getAttributeNames();
/* 222 */         while (attrNameEnum.hasMoreElements()) {
/* 223 */           String attrName = (String)attrNameEnum.nextElement();
/* 224 */           attributeMap.put(attrName, sc.getAttribute(attrName));
/*     */         }
/*     */       }
/* 227 */       bf.registerSingleton("contextAttributes", Collections.unmodifiableMap(attributeMap));
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void initServletPropertySources(MutablePropertySources propertySources, ServletContext servletContext)
/*     */   {
/* 240 */     initServletPropertySources(propertySources, servletContext, null);
/*     */   }
/*     */ 
/*     */   public static void initServletPropertySources(MutablePropertySources propertySources, ServletContext servletContext, ServletConfig servletConfig)
/*     */   {
/* 263 */     Assert.notNull(propertySources, "propertySources must not be null");
/* 264 */     if ((servletContext != null) && (propertySources.contains("servletContextInitParams")) && ((propertySources.get("servletContextInitParams") instanceof PropertySource.StubPropertySource)))
/*     */     {
/* 267 */       propertySources.replace("servletContextInitParams", new ServletContextPropertySource("servletContextInitParams", servletContext));
/*     */     }
/* 269 */     if ((servletConfig != null) && (propertySources.contains("servletConfigInitParams")) && ((propertySources.get("servletConfigInitParams") instanceof PropertySource.StubPropertySource)))
/*     */     {
/* 272 */       propertySources.replace("servletConfigInitParams", new ServletConfigPropertySource("servletConfigInitParams", servletConfig));
/*     */     }
/*     */   }
/*     */ 
/*     */   private static ServletRequestAttributes currentRequestAttributes()
/*     */   {
/* 281 */     RequestAttributes requestAttr = RequestContextHolder.currentRequestAttributes();
/* 282 */     if (!(requestAttr instanceof ServletRequestAttributes)) {
/* 283 */       throw new IllegalStateException("Current request is not a servlet request");
/*     */     }
/* 285 */     return (ServletRequestAttributes)requestAttr;
/*     */   }
/*     */ 
/*     */   private static class FacesDependencyRegistrar
/*     */   {
/*     */     public static void registerFacesDependencies(ConfigurableListableBeanFactory beanFactory)
/*     */     {
/* 346 */       beanFactory.registerResolvableDependency(FacesContext.class, new ObjectFactory() {
/*     */         public FacesContext getObject() {
/* 348 */           return FacesContext.getCurrentInstance();
/*     */         }
/*     */ 
/*     */         public String toString() {
/* 352 */           return "Current JSF FacesContext";
/*     */         }
/*     */       });
/* 355 */       beanFactory.registerResolvableDependency(ExternalContext.class, new ObjectFactory() {
/*     */         public ExternalContext getObject() {
/* 357 */           return FacesContext.getCurrentInstance().getExternalContext();
/*     */         }
/*     */ 
/*     */         public String toString() {
/* 361 */           return "Current JSF ExternalContext";
/*     */         }
/*     */       });
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class WebRequestObjectFactory
/*     */     implements ObjectFactory<WebRequest>, Serializable
/*     */   {
/*     */     public WebRequest getObject()
/*     */     {
/* 330 */       return new ServletWebRequest(WebApplicationContextUtils.access$300().getRequest());
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/* 335 */       return "Current ServletWebRequest";
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class SessionObjectFactory
/*     */     implements ObjectFactory<HttpSession>, Serializable
/*     */   {
/*     */     public HttpSession getObject()
/*     */     {
/* 313 */       return WebApplicationContextUtils.access$300().getRequest().getSession();
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/* 318 */       return "Current HttpSession";
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class RequestObjectFactory
/*     */     implements ObjectFactory<ServletRequest>, Serializable
/*     */   {
/*     */     public ServletRequest getObject()
/*     */     {
/* 296 */       return WebApplicationContextUtils.access$300().getRequest();
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/* 301 */       return "Current HttpServletRequest";
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.support.WebApplicationContextUtils
 * JD-Core Version:    0.6.0
 */