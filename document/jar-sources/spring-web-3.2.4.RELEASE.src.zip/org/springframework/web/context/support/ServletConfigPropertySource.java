/*    */ package org.springframework.web.context.support;
/*    */ 
/*    */ import javax.servlet.ServletConfig;
/*    */ import org.springframework.core.env.EnumerablePropertySource;
/*    */ import org.springframework.util.CollectionUtils;
/*    */ 
/*    */ public class ServletConfigPropertySource extends EnumerablePropertySource<ServletConfig>
/*    */ {
/*    */   public ServletConfigPropertySource(String name, ServletConfig servletConfig)
/*    */   {
/* 35 */     super(name, servletConfig);
/*    */   }
/*    */ 
/*    */   public String[] getPropertyNames()
/*    */   {
/* 40 */     return (String[])CollectionUtils.toArray(((ServletConfig)this.source).getInitParameterNames(), EMPTY_NAMES_ARRAY);
/*    */   }
/*    */ 
/*    */   public String getProperty(String name)
/*    */   {
/* 46 */     return ((ServletConfig)this.source).getInitParameter(name);
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.support.ServletConfigPropertySource
 * JD-Core Version:    0.6.0
 */