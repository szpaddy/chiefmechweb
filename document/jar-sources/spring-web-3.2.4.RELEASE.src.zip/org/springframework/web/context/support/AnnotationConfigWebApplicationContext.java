/*     */ package org.springframework.web.context.support;
/*     */ 
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.beans.factory.support.BeanNameGenerator;
/*     */ import org.springframework.beans.factory.support.DefaultListableBeanFactory;
/*     */ import org.springframework.context.annotation.AnnotatedBeanDefinitionReader;
/*     */ import org.springframework.context.annotation.ClassPathBeanDefinitionScanner;
/*     */ import org.springframework.context.annotation.ScopeMetadataResolver;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class AnnotationConfigWebApplicationContext extends AbstractRefreshableWebApplicationContext
/*     */ {
/*     */   private Class<?>[] annotatedClasses;
/*     */   private String[] basePackages;
/*     */   private BeanNameGenerator beanNameGenerator;
/*     */   private ScopeMetadataResolver scopeMetadataResolver;
/*     */ 
/*     */   public void setConfigLocation(String location)
/*     */   {
/* 108 */     super.setConfigLocation(location);
/*     */   }
/*     */ 
/*     */   public void setConfigLocations(String[] locations)
/*     */   {
/* 130 */     super.setConfigLocations(locations);
/*     */   }
/*     */ 
/*     */   public void register(Class<?>[] annotatedClasses)
/*     */   {
/* 147 */     Assert.notEmpty(annotatedClasses, "At least one annotated class must be specified");
/* 148 */     this.annotatedClasses = annotatedClasses;
/*     */   }
/*     */ 
/*     */   public void scan(String[] basePackages)
/*     */   {
/* 162 */     Assert.notEmpty(basePackages, "At least one base package must be specified");
/* 163 */     this.basePackages = basePackages;
/*     */   }
/*     */ 
/*     */   protected void loadBeanDefinitions(DefaultListableBeanFactory beanFactory)
/*     */   {
/* 189 */     AnnotatedBeanDefinitionReader reader = new AnnotatedBeanDefinitionReader(beanFactory);
/* 190 */     reader.setEnvironment(getEnvironment());
/*     */ 
/* 192 */     ClassPathBeanDefinitionScanner scanner = new ClassPathBeanDefinitionScanner(beanFactory);
/* 193 */     scanner.setEnvironment(getEnvironment());
/*     */ 
/* 195 */     BeanNameGenerator beanNameGenerator = getBeanNameGenerator();
/* 196 */     ScopeMetadataResolver scopeMetadataResolver = getScopeMetadataResolver();
/* 197 */     if (beanNameGenerator != null) {
/* 198 */       reader.setBeanNameGenerator(beanNameGenerator);
/* 199 */       scanner.setBeanNameGenerator(beanNameGenerator);
/* 200 */       beanFactory.registerSingleton("org.springframework.context.annotation.internalConfigurationBeanNameGenerator", beanNameGenerator);
/*     */     }
/*     */ 
/* 203 */     if (scopeMetadataResolver != null) {
/* 204 */       reader.setScopeMetadataResolver(scopeMetadataResolver);
/* 205 */       scanner.setScopeMetadataResolver(scopeMetadataResolver);
/*     */     }
/*     */ 
/* 208 */     if (!ObjectUtils.isEmpty(this.annotatedClasses)) {
/* 209 */       if (this.logger.isInfoEnabled()) {
/* 210 */         this.logger.info("Registering annotated classes: [" + StringUtils.arrayToCommaDelimitedString(this.annotatedClasses) + "]");
/*     */       }
/*     */ 
/* 213 */       reader.register(this.annotatedClasses);
/*     */     }
/*     */ 
/* 216 */     if (!ObjectUtils.isEmpty(this.basePackages)) {
/* 217 */       if (this.logger.isInfoEnabled()) {
/* 218 */         this.logger.info("Scanning base packages: [" + StringUtils.arrayToCommaDelimitedString(this.basePackages) + "]");
/*     */       }
/*     */ 
/* 221 */       scanner.scan(this.basePackages);
/*     */     }
/*     */ 
/* 224 */     String[] configLocations = getConfigLocations();
/* 225 */     if (configLocations != null)
/* 226 */       for (String configLocation : configLocations)
/*     */         try {
/* 228 */           Class clazz = getClassLoader().loadClass(configLocation);
/* 229 */           if (this.logger.isInfoEnabled()) {
/* 230 */             this.logger.info("Successfully resolved class for [" + configLocation + "]");
/*     */           }
/* 232 */           reader.register(new Class[] { clazz });
/*     */         }
/*     */         catch (ClassNotFoundException ex) {
/* 235 */           if (this.logger.isDebugEnabled()) {
/* 236 */             this.logger.debug("Could not load class for config location [" + configLocation + "] - trying package scan. " + ex);
/*     */           }
/*     */ 
/* 239 */           int count = scanner.scan(new String[] { configLocation });
/* 240 */           if (this.logger.isInfoEnabled())
/* 241 */             if (count == 0) {
/* 242 */               this.logger.info("No annotated classes found for specified class/package [" + configLocation + "]");
/*     */             }
/*     */             else
/* 245 */               this.logger.info("Found " + count + " annotated classes in package [" + configLocation + "]");
/*     */         }
/*     */   }
/*     */ 
/*     */   public void setBeanNameGenerator(BeanNameGenerator beanNameGenerator)
/*     */   {
/* 254 */     this.beanNameGenerator = beanNameGenerator;
/*     */   }
/*     */ 
/*     */   protected BeanNameGenerator getBeanNameGenerator()
/*     */   {
/* 265 */     return this.beanNameGenerator;
/*     */   }
/*     */ 
/*     */   public void setScopeMetadataResolver(ScopeMetadataResolver scopeMetadataResolver)
/*     */   {
/* 273 */     this.scopeMetadataResolver = scopeMetadataResolver;
/*     */   }
/*     */ 
/*     */   protected ScopeMetadataResolver getScopeMetadataResolver()
/*     */   {
/* 284 */     return this.scopeMetadataResolver;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.support.AnnotationConfigWebApplicationContext
 * JD-Core Version:    0.6.0
 */