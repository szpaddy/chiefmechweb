/*     */ package org.springframework.web.context.support;
/*     */ 
/*     */ import javax.servlet.ServletConfig;
/*     */ import javax.servlet.ServletContext;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.beans.factory.support.DefaultListableBeanFactory;
/*     */ import org.springframework.context.support.GenericApplicationContext;
/*     */ import org.springframework.core.env.ConfigurableEnvironment;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.support.ResourcePatternResolver;
/*     */ import org.springframework.ui.context.Theme;
/*     */ import org.springframework.ui.context.ThemeSource;
/*     */ import org.springframework.ui.context.support.UiApplicationContextUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.context.ConfigurableWebApplicationContext;
/*     */ import org.springframework.web.context.ConfigurableWebEnvironment;
/*     */ import org.springframework.web.context.ServletContextAware;
/*     */ 
/*     */ public class GenericWebApplicationContext extends GenericApplicationContext
/*     */   implements ConfigurableWebApplicationContext, ThemeSource
/*     */ {
/*     */   private ServletContext servletContext;
/*     */   private ThemeSource themeSource;
/*     */ 
/*     */   public GenericWebApplicationContext()
/*     */   {
/*     */   }
/*     */ 
/*     */   public GenericWebApplicationContext(ServletContext servletContext)
/*     */   {
/*  89 */     this.servletContext = servletContext;
/*     */   }
/*     */ 
/*     */   public GenericWebApplicationContext(DefaultListableBeanFactory beanFactory)
/*     */   {
/* 100 */     super(beanFactory);
/*     */   }
/*     */ 
/*     */   public GenericWebApplicationContext(DefaultListableBeanFactory beanFactory, ServletContext servletContext)
/*     */   {
/* 111 */     super(beanFactory);
/* 112 */     this.servletContext = servletContext;
/*     */   }
/*     */ 
/*     */   public void setServletContext(ServletContext servletContext)
/*     */   {
/* 120 */     this.servletContext = servletContext;
/*     */   }
/*     */ 
/*     */   public ServletContext getServletContext() {
/* 124 */     return this.servletContext;
/*     */   }
/*     */ 
/*     */   public String getApplicationName()
/*     */   {
/* 129 */     if (this.servletContext == null) {
/* 130 */       return "";
/*     */     }
/* 132 */     if ((this.servletContext.getMajorVersion() == 2) && (this.servletContext.getMinorVersion() < 5)) {
/* 133 */       String name = this.servletContext.getServletContextName();
/* 134 */       return name != null ? name : "";
/*     */     }
/*     */ 
/* 138 */     return this.servletContext.getContextPath();
/*     */   }
/*     */ 
/*     */   protected ConfigurableEnvironment createEnvironment()
/*     */   {
/* 147 */     return new StandardServletEnvironment();
/*     */   }
/*     */ 
/*     */   protected void postProcessBeanFactory(ConfigurableListableBeanFactory beanFactory)
/*     */   {
/* 156 */     beanFactory.addBeanPostProcessor(new ServletContextAwareProcessor(this.servletContext));
/* 157 */     beanFactory.ignoreDependencyInterface(ServletContextAware.class);
/*     */ 
/* 159 */     WebApplicationContextUtils.registerWebApplicationScopes(beanFactory, this.servletContext);
/* 160 */     WebApplicationContextUtils.registerEnvironmentBeans(beanFactory, this.servletContext);
/*     */   }
/*     */ 
/*     */   protected Resource getResourceByPath(String path)
/*     */   {
/* 169 */     return new ServletContextResource(this.servletContext, path);
/*     */   }
/*     */ 
/*     */   protected ResourcePatternResolver getResourcePatternResolver()
/*     */   {
/* 178 */     return new ServletContextResourcePatternResolver(this);
/*     */   }
/*     */ 
/*     */   protected void onRefresh()
/*     */   {
/* 186 */     this.themeSource = UiApplicationContextUtils.initThemeSource(this);
/*     */   }
/*     */ 
/*     */   protected void initPropertySources()
/*     */   {
/* 195 */     super.initPropertySources();
/* 196 */     ConfigurableEnvironment env = getEnvironment();
/* 197 */     if ((env instanceof ConfigurableWebEnvironment))
/* 198 */       ((ConfigurableWebEnvironment)env).initPropertySources(this.servletContext, null);
/*     */   }
/*     */ 
/*     */   public Theme getTheme(String themeName)
/*     */   {
/* 204 */     return this.themeSource.getTheme(themeName);
/*     */   }
/*     */ 
/*     */   public void setServletConfig(ServletConfig servletConfig)
/*     */   {
/*     */   }
/*     */ 
/*     */   public ServletConfig getServletConfig()
/*     */   {
/* 217 */     throw new UnsupportedOperationException("GenericWebApplicationContext does not support getServletConfig()");
/*     */   }
/*     */ 
/*     */   public void setNamespace(String namespace)
/*     */   {
/*     */   }
/*     */ 
/*     */   public String getNamespace()
/*     */   {
/* 226 */     throw new UnsupportedOperationException("GenericWebApplicationContext does not support getNamespace()");
/*     */   }
/*     */ 
/*     */   public void setConfigLocation(String configLocation)
/*     */   {
/* 231 */     if (StringUtils.hasText(configLocation))
/* 232 */       throw new UnsupportedOperationException("GenericWebApplicationContext does not support setConfigLocation(). Do you still have an 'contextConfigLocations' init-param set?");
/*     */   }
/*     */ 
/*     */   public void setConfigLocations(String[] configLocations)
/*     */   {
/* 239 */     if (!ObjectUtils.isEmpty(configLocations))
/* 240 */       throw new UnsupportedOperationException("GenericWebApplicationContext does not support setConfigLocations(). Do you still have an 'contextConfigLocations' init-param set?");
/*     */   }
/*     */ 
/*     */   public String[] getConfigLocations()
/*     */   {
/* 247 */     throw new UnsupportedOperationException("GenericWebApplicationContext does not support getConfigLocations()");
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.support.GenericWebApplicationContext
 * JD-Core Version:    0.6.0
 */