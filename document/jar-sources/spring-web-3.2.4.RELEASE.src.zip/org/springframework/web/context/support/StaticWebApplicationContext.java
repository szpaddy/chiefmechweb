/*     */ package org.springframework.web.context.support;
/*     */ 
/*     */ import javax.servlet.ServletConfig;
/*     */ import javax.servlet.ServletContext;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.context.support.StaticApplicationContext;
/*     */ import org.springframework.core.env.ConfigurableEnvironment;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.support.ResourcePatternResolver;
/*     */ import org.springframework.ui.context.Theme;
/*     */ import org.springframework.ui.context.ThemeSource;
/*     */ import org.springframework.ui.context.support.UiApplicationContextUtils;
/*     */ import org.springframework.web.context.ConfigurableWebApplicationContext;
/*     */ import org.springframework.web.context.ServletConfigAware;
/*     */ import org.springframework.web.context.ServletContextAware;
/*     */ 
/*     */ public class StaticWebApplicationContext extends StaticApplicationContext
/*     */   implements ConfigurableWebApplicationContext, ThemeSource
/*     */ {
/*     */   private ServletContext servletContext;
/*     */   private ServletConfig servletConfig;
/*     */   private String namespace;
/*     */   private ThemeSource themeSource;
/*     */ 
/*     */   public StaticWebApplicationContext()
/*     */   {
/*  69 */     setDisplayName("Root WebApplicationContext");
/*     */   }
/*     */ 
/*     */   public void setServletContext(ServletContext servletContext)
/*     */   {
/*  77 */     this.servletContext = servletContext;
/*     */   }
/*     */ 
/*     */   public ServletContext getServletContext() {
/*  81 */     return this.servletContext;
/*     */   }
/*     */ 
/*     */   public void setServletConfig(ServletConfig servletConfig) {
/*  85 */     this.servletConfig = servletConfig;
/*  86 */     if ((servletConfig != null) && (this.servletContext == null))
/*  87 */       this.servletContext = servletConfig.getServletContext();
/*     */   }
/*     */ 
/*     */   public ServletConfig getServletConfig()
/*     */   {
/*  92 */     return this.servletConfig;
/*     */   }
/*     */ 
/*     */   public void setNamespace(String namespace) {
/*  96 */     this.namespace = namespace;
/*  97 */     if (namespace != null)
/*  98 */       setDisplayName("WebApplicationContext for namespace '" + namespace + "'");
/*     */   }
/*     */ 
/*     */   public String getNamespace()
/*     */   {
/* 103 */     return this.namespace;
/*     */   }
/*     */ 
/*     */   public void setConfigLocation(String configLocation)
/*     */   {
/* 111 */     if (configLocation != null)
/* 112 */       throw new UnsupportedOperationException("StaticWebApplicationContext does not support config locations");
/*     */   }
/*     */ 
/*     */   public void setConfigLocations(String[] configLocations)
/*     */   {
/* 121 */     if (configLocations != null)
/* 122 */       throw new UnsupportedOperationException("StaticWebApplicationContext does not support config locations");
/*     */   }
/*     */ 
/*     */   public String[] getConfigLocations()
/*     */   {
/* 127 */     return null;
/*     */   }
/*     */ 
/*     */   protected void postProcessBeanFactory(ConfigurableListableBeanFactory beanFactory)
/*     */   {
/* 136 */     beanFactory.addBeanPostProcessor(new ServletContextAwareProcessor(this.servletContext, this.servletConfig));
/* 137 */     beanFactory.ignoreDependencyInterface(ServletContextAware.class);
/* 138 */     beanFactory.ignoreDependencyInterface(ServletConfigAware.class);
/*     */ 
/* 140 */     WebApplicationContextUtils.registerWebApplicationScopes(beanFactory, this.servletContext);
/* 141 */     WebApplicationContextUtils.registerEnvironmentBeans(beanFactory, this.servletContext, this.servletConfig);
/*     */   }
/*     */ 
/*     */   protected Resource getResourceByPath(String path)
/*     */   {
/* 150 */     return new ServletContextResource(this.servletContext, path);
/*     */   }
/*     */ 
/*     */   protected ResourcePatternResolver getResourcePatternResolver()
/*     */   {
/* 159 */     return new ServletContextResourcePatternResolver(this);
/*     */   }
/*     */ 
/*     */   protected ConfigurableEnvironment createEnvironment()
/*     */   {
/* 167 */     return new StandardServletEnvironment();
/*     */   }
/*     */ 
/*     */   protected void onRefresh()
/*     */   {
/* 175 */     this.themeSource = UiApplicationContextUtils.initThemeSource(this);
/*     */   }
/*     */ 
/*     */   protected void initPropertySources()
/*     */   {
/* 180 */     super.initPropertySources();
/* 181 */     WebApplicationContextUtils.initServletPropertySources(getEnvironment().getPropertySources(), this.servletContext, this.servletConfig);
/*     */   }
/*     */ 
/*     */   public Theme getTheme(String themeName)
/*     */   {
/* 186 */     return this.themeSource.getTheme(themeName);
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.support.StaticWebApplicationContext
 * JD-Core Version:    0.6.0
 */