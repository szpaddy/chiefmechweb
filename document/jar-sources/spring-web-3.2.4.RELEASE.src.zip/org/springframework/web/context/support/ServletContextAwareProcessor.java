/*    */ package org.springframework.web.context.support;
/*    */ 
/*    */ import javax.servlet.ServletConfig;
/*    */ import javax.servlet.ServletContext;
/*    */ import org.springframework.beans.BeansException;
/*    */ import org.springframework.beans.factory.config.BeanPostProcessor;
/*    */ import org.springframework.web.context.ServletConfigAware;
/*    */ import org.springframework.web.context.ServletContextAware;
/*    */ 
/*    */ public class ServletContextAwareProcessor
/*    */   implements BeanPostProcessor
/*    */ {
/*    */   private ServletContext servletContext;
/*    */   private ServletConfig servletConfig;
/*    */ 
/*    */   public ServletContextAwareProcessor(ServletContext servletContext)
/*    */   {
/* 51 */     this(servletContext, null);
/*    */   }
/*    */ 
/*    */   public ServletContextAwareProcessor(ServletConfig servletConfig)
/*    */   {
/* 58 */     this(null, servletConfig);
/*    */   }
/*    */ 
/*    */   public ServletContextAwareProcessor(ServletContext servletContext, ServletConfig servletConfig)
/*    */   {
/* 65 */     this.servletContext = servletContext;
/* 66 */     this.servletConfig = servletConfig;
/* 67 */     if ((servletContext == null) && (servletConfig != null))
/* 68 */       this.servletContext = servletConfig.getServletContext();
/*    */   }
/*    */ 
/*    */   public Object postProcessBeforeInitialization(Object bean, String beanName)
/*    */     throws BeansException
/*    */   {
/* 74 */     if ((this.servletContext != null) && ((bean instanceof ServletContextAware))) {
/* 75 */       ((ServletContextAware)bean).setServletContext(this.servletContext);
/*    */     }
/* 77 */     if ((this.servletConfig != null) && ((bean instanceof ServletConfigAware))) {
/* 78 */       ((ServletConfigAware)bean).setServletConfig(this.servletConfig);
/*    */     }
/* 80 */     return bean;
/*    */   }
/*    */ 
/*    */   public Object postProcessAfterInitialization(Object bean, String beanName) {
/* 84 */     return bean;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.support.ServletContextAwareProcessor
 * JD-Core Version:    0.6.0
 */