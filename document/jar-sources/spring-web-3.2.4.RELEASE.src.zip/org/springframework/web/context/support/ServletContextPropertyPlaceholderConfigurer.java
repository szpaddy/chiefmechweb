/*     */ package org.springframework.web.context.support;
/*     */ 
/*     */ import java.util.Properties;
/*     */ import javax.servlet.ServletContext;
/*     */ import org.springframework.beans.factory.config.PropertyPlaceholderConfigurer;
/*     */ import org.springframework.web.context.ServletContextAware;
/*     */ 
/*     */ @Deprecated
/*     */ public class ServletContextPropertyPlaceholderConfigurer extends PropertyPlaceholderConfigurer
/*     */   implements ServletContextAware
/*     */ {
/*  68 */   private boolean contextOverride = false;
/*     */ 
/*  70 */   private boolean searchContextAttributes = false;
/*     */   private ServletContext servletContext;
/*     */ 
/*     */   public void setContextOverride(boolean contextOverride)
/*     */   {
/*  86 */     this.contextOverride = contextOverride;
/*     */   }
/*     */ 
/*     */   public void setSearchContextAttributes(boolean searchContextAttributes)
/*     */   {
/* 102 */     this.searchContextAttributes = searchContextAttributes;
/*     */   }
/*     */ 
/*     */   public void setServletContext(ServletContext servletContext)
/*     */   {
/* 113 */     this.servletContext = servletContext;
/*     */   }
/*     */ 
/*     */   protected String resolvePlaceholder(String placeholder, Properties props)
/*     */   {
/* 119 */     String value = null;
/* 120 */     if ((this.contextOverride) && (this.servletContext != null)) {
/* 121 */       value = resolvePlaceholder(placeholder, this.servletContext, this.searchContextAttributes);
/*     */     }
/* 123 */     if (value == null) {
/* 124 */       value = super.resolvePlaceholder(placeholder, props);
/*     */     }
/* 126 */     if ((value == null) && (this.servletContext != null)) {
/* 127 */       value = resolvePlaceholder(placeholder, this.servletContext, this.searchContextAttributes);
/*     */     }
/* 129 */     return value;
/*     */   }
/*     */ 
/*     */   protected String resolvePlaceholder(String placeholder, ServletContext servletContext, boolean searchContextAttributes)
/*     */   {
/* 150 */     String value = null;
/* 151 */     if (searchContextAttributes) {
/* 152 */       Object attrValue = servletContext.getAttribute(placeholder);
/* 153 */       if (attrValue != null) {
/* 154 */         value = attrValue.toString();
/*     */       }
/*     */     }
/* 157 */     if (value == null) {
/* 158 */       value = servletContext.getInitParameter(placeholder);
/*     */     }
/* 160 */     return value;
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.support.ServletContextPropertyPlaceholderConfigurer
 * JD-Core Version:    0.6.0
 */