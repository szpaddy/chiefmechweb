/*     */ package org.springframework.web.context.support;
/*     */ 
/*     */ import java.io.File;
/*     */ import javax.servlet.ServletContext;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.support.ApplicationObjectSupport;
/*     */ import org.springframework.web.context.ServletContextAware;
/*     */ import org.springframework.web.context.WebApplicationContext;
/*     */ import org.springframework.web.util.WebUtils;
/*     */ 
/*     */ public abstract class WebApplicationObjectSupport extends ApplicationObjectSupport
/*     */   implements ServletContextAware
/*     */ {
/*     */   private ServletContext servletContext;
/*     */ 
/*     */   public final void setServletContext(ServletContext servletContext)
/*     */   {
/*  44 */     if (servletContext != this.servletContext) {
/*  45 */       this.servletContext = servletContext;
/*  46 */       if (servletContext != null)
/*  47 */         initServletContext(servletContext);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected boolean isContextRequired()
/*     */   {
/*  63 */     return true;
/*     */   }
/*     */ 
/*     */   protected void initApplicationContext(ApplicationContext context)
/*     */   {
/*  72 */     super.initApplicationContext(context);
/*  73 */     if ((this.servletContext == null) && ((context instanceof WebApplicationContext))) {
/*  74 */       this.servletContext = ((WebApplicationContext)context).getServletContext();
/*  75 */       if (this.servletContext != null)
/*  76 */         initServletContext(this.servletContext);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void initServletContext(ServletContext servletContext)
/*     */   {
/*     */   }
/*     */ 
/*     */   protected final WebApplicationContext getWebApplicationContext()
/*     */     throws IllegalStateException
/*     */   {
/* 103 */     ApplicationContext ctx = getApplicationContext();
/* 104 */     if ((ctx instanceof WebApplicationContext)) {
/* 105 */       return (WebApplicationContext)getApplicationContext();
/*     */     }
/* 107 */     if (isContextRequired()) {
/* 108 */       throw new IllegalStateException("WebApplicationObjectSupport instance [" + this + "] does not run in a WebApplicationContext but in: " + ctx);
/*     */     }
/*     */ 
/* 112 */     return null;
/*     */   }
/*     */ 
/*     */   protected final ServletContext getServletContext()
/*     */     throws IllegalStateException
/*     */   {
/* 121 */     if (this.servletContext != null) {
/* 122 */       return this.servletContext;
/*     */     }
/* 124 */     ServletContext servletContext = getWebApplicationContext().getServletContext();
/* 125 */     if ((servletContext == null) && (isContextRequired())) {
/* 126 */       throw new IllegalStateException("WebApplicationObjectSupport instance [" + this + "] does not run within a ServletContext. Make sure the object is fully configured!");
/*     */     }
/*     */ 
/* 129 */     return servletContext;
/*     */   }
/*     */ 
/*     */   protected final File getTempDir()
/*     */     throws IllegalStateException
/*     */   {
/* 140 */     return WebUtils.getTempDir(getServletContext());
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.support.WebApplicationObjectSupport
 * JD-Core Version:    0.6.0
 */