/*    */ package org.springframework.web.context.support;
/*    */ 
/*    */ import javax.servlet.ServletContext;
/*    */ import org.springframework.beans.factory.FactoryBean;
/*    */ import org.springframework.web.context.ServletContextAware;
/*    */ 
/*    */ public class ServletContextParameterFactoryBean
/*    */   implements FactoryBean<String>, ServletContextAware
/*    */ {
/*    */   private String initParamName;
/*    */   private String paramValue;
/*    */ 
/*    */   public void setInitParamName(String initParamName)
/*    */   {
/* 50 */     this.initParamName = initParamName;
/*    */   }
/*    */ 
/*    */   public void setServletContext(ServletContext servletContext) {
/* 54 */     if (this.initParamName == null) {
/* 55 */       throw new IllegalArgumentException("initParamName is required");
/*    */     }
/* 57 */     this.paramValue = servletContext.getInitParameter(this.initParamName);
/* 58 */     if (this.paramValue == null)
/* 59 */       throw new IllegalStateException("No ServletContext init parameter '" + this.initParamName + "' found");
/*    */   }
/*    */ 
/*    */   public String getObject()
/*    */   {
/* 65 */     return this.paramValue;
/*    */   }
/*    */ 
/*    */   public Class<String> getObjectType() {
/* 69 */     return String.class;
/*    */   }
/*    */ 
/*    */   public boolean isSingleton() {
/* 73 */     return true;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.support.ServletContextParameterFactoryBean
 * JD-Core Version:    0.6.0
 */