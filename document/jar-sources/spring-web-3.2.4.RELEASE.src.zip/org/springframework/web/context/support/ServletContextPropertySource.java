/*    */ package org.springframework.web.context.support;
/*    */ 
/*    */ import javax.servlet.ServletContext;
/*    */ import org.springframework.core.env.EnumerablePropertySource;
/*    */ import org.springframework.util.CollectionUtils;
/*    */ 
/*    */ public class ServletContextPropertySource extends EnumerablePropertySource<ServletContext>
/*    */ {
/*    */   public ServletContextPropertySource(String name, ServletContext servletContext)
/*    */   {
/* 35 */     super(name, servletContext);
/*    */   }
/*    */ 
/*    */   public String[] getPropertyNames()
/*    */   {
/* 40 */     return (String[])CollectionUtils.toArray(((ServletContext)this.source).getInitParameterNames(), EMPTY_NAMES_ARRAY);
/*    */   }
/*    */ 
/*    */   public String getProperty(String name)
/*    */   {
/* 46 */     return ((ServletContext)this.source).getInitParameter(name);
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.support.ServletContextPropertySource
 * JD-Core Version:    0.6.0
 */