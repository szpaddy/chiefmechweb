/*    */ package org.springframework.web.context;
/*    */ 
/*    */ import javax.servlet.ServletConfig;
/*    */ import javax.servlet.ServletContext;
/*    */ import org.springframework.context.ConfigurableApplicationContext;
/*    */ 
/*    */ public abstract interface ConfigurableWebApplicationContext extends WebApplicationContext, ConfigurableApplicationContext
/*    */ {
/* 45 */   public static final String APPLICATION_CONTEXT_ID_PREFIX = WebApplicationContext.class.getName() + ":";
/*    */   public static final String SERVLET_CONFIG_BEAN_NAME = "servletConfig";
/*    */ 
/*    */   public abstract void setServletContext(ServletContext paramServletContext);
/*    */ 
/*    */   public abstract void setServletConfig(ServletConfig paramServletConfig);
/*    */ 
/*    */   public abstract ServletConfig getServletConfig();
/*    */ 
/*    */   public abstract void setNamespace(String paramString);
/*    */ 
/*    */   public abstract String getNamespace();
/*    */ 
/*    */   public abstract void setConfigLocation(String paramString);
/*    */ 
/*    */   public abstract void setConfigLocations(String[] paramArrayOfString);
/*    */ 
/*    */   public abstract String[] getConfigLocations();
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.ConfigurableWebApplicationContext
 * JD-Core Version:    0.6.0
 */