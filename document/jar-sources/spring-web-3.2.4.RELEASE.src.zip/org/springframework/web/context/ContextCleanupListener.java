/*    */ package org.springframework.web.context;
/*    */ 
/*    */ import java.util.Enumeration;
/*    */ import javax.servlet.ServletContext;
/*    */ import javax.servlet.ServletContextEvent;
/*    */ import javax.servlet.ServletContextListener;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.beans.factory.DisposableBean;
/*    */ 
/*    */ public class ContextCleanupListener
/*    */   implements ServletContextListener
/*    */ {
/* 43 */   private static final Log logger = LogFactory.getLog(ContextCleanupListener.class);
/*    */ 
/*    */   public void contextInitialized(ServletContextEvent event)
/*    */   {
/*    */   }
/*    */ 
/*    */   public void contextDestroyed(ServletContextEvent event) {
/* 50 */     cleanupAttributes(event.getServletContext());
/*    */   }
/*    */ 
/*    */   static void cleanupAttributes(ServletContext sc)
/*    */   {
/* 60 */     Enumeration attrNames = sc.getAttributeNames();
/* 61 */     while (attrNames.hasMoreElements()) {
/* 62 */       String attrName = (String)attrNames.nextElement();
/* 63 */       if (attrName.startsWith("org.springframework.")) {
/* 64 */         Object attrValue = sc.getAttribute(attrName);
/* 65 */         if ((attrValue instanceof DisposableBean))
/*    */           try {
/* 67 */             ((DisposableBean)attrValue).destroy();
/*    */           }
/*    */           catch (Throwable ex) {
/* 70 */             logger.error("Couldn't invoke destroy method of attribute with name '" + attrName + "'", ex);
/*    */           }
/*    */       }
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.ContextCleanupListener
 * JD-Core Version:    0.6.0
 */