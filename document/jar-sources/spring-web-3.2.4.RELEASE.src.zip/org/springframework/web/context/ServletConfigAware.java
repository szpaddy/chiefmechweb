package org.springframework.web.context;

import javax.servlet.ServletConfig;
import org.springframework.beans.factory.Aware;

public abstract interface ServletConfigAware extends Aware
{
  public abstract void setServletConfig(ServletConfig paramServletConfig);
}

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.ServletConfigAware
 * JD-Core Version:    0.6.0
 */