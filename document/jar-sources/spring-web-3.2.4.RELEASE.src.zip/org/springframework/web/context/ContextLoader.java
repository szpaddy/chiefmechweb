/*     */ package org.springframework.web.context;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import javax.servlet.ServletContext;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.factory.access.BeanFactoryLocator;
/*     */ import org.springframework.beans.factory.access.BeanFactoryReference;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationContextException;
/*     */ import org.springframework.context.ApplicationContextInitializer;
/*     */ import org.springframework.context.ConfigurableApplicationContext;
/*     */ import org.springframework.context.access.ContextSingletonBeanFactoryLocator;
/*     */ import org.springframework.core.GenericTypeResolver;
/*     */ import org.springframework.core.annotation.AnnotationAwareOrderComparator;
/*     */ import org.springframework.core.env.ConfigurableEnvironment;
/*     */ import org.springframework.core.io.ClassPathResource;
/*     */ import org.springframework.core.io.support.PropertiesLoaderUtils;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class ContextLoader
/*     */ {
/*     */   public static final String CONTEXT_CLASS_PARAM = "contextClass";
/*     */   public static final String CONTEXT_ID_PARAM = "contextId";
/*     */   public static final String CONTEXT_INITIALIZER_CLASSES_PARAM = "contextInitializerClasses";
/*     */   public static final String CONFIG_LOCATION_PARAM = "contextConfigLocation";
/*     */   public static final String LOCATOR_FACTORY_SELECTOR_PARAM = "locatorFactorySelector";
/*     */   public static final String LOCATOR_FACTORY_KEY_PARAM = "parentContextKey";
/*     */   private static final String DEFAULT_STRATEGIES_PATH = "ContextLoader.properties";
/*     */   private static final Properties defaultStrategies;
/*     */   private static final Map<ClassLoader, WebApplicationContext> currentContextPerThread;
/*     */   private static volatile WebApplicationContext currentContext;
/*     */   private WebApplicationContext context;
/*     */   private BeanFactoryReference parentContextRef;
/*     */ 
/*     */   public ContextLoader()
/*     */   {
/*     */   }
/*     */ 
/*     */   public ContextLoader(WebApplicationContext context)
/*     */   {
/* 249 */     this.context = context;
/*     */   }
/*     */ 
/*     */   public WebApplicationContext initWebApplicationContext(ServletContext servletContext)
/*     */   {
/* 264 */     if (servletContext.getAttribute(WebApplicationContext.ROOT_WEB_APPLICATION_CONTEXT_ATTRIBUTE) != null) {
/* 265 */       throw new IllegalStateException("Cannot initialize context because there is already a root application context present - check whether you have multiple ContextLoader* definitions in your web.xml!");
/*     */     }
/*     */ 
/* 270 */     Log logger = LogFactory.getLog(ContextLoader.class);
/* 271 */     servletContext.log("Initializing Spring root WebApplicationContext");
/* 272 */     if (logger.isInfoEnabled()) {
/* 273 */       logger.info("Root WebApplicationContext: initialization started");
/*     */     }
/* 275 */     long startTime = System.currentTimeMillis();
/*     */     try
/*     */     {
/* 280 */       if (this.context == null) {
/* 281 */         this.context = createWebApplicationContext(servletContext);
/*     */       }
/* 283 */       if ((this.context instanceof ConfigurableWebApplicationContext)) {
/* 284 */         ConfigurableWebApplicationContext cwac = (ConfigurableWebApplicationContext)this.context;
/* 285 */         if (!cwac.isActive())
/*     */         {
/* 288 */           if (cwac.getParent() == null)
/*     */           {
/* 291 */             ApplicationContext parent = loadParentContext(servletContext);
/* 292 */             cwac.setParent(parent);
/*     */           }
/* 294 */           configureAndRefreshWebApplicationContext(cwac, servletContext);
/*     */         }
/*     */       }
/* 297 */       servletContext.setAttribute(WebApplicationContext.ROOT_WEB_APPLICATION_CONTEXT_ATTRIBUTE, this.context);
/*     */ 
/* 299 */       ClassLoader ccl = Thread.currentThread().getContextClassLoader();
/* 300 */       if (ccl == ContextLoader.class.getClassLoader()) {
/* 301 */         currentContext = this.context;
/*     */       }
/* 303 */       else if (ccl != null) {
/* 304 */         currentContextPerThread.put(ccl, this.context);
/*     */       }
/*     */ 
/* 307 */       if (logger.isDebugEnabled()) {
/* 308 */         logger.debug("Published root WebApplicationContext as ServletContext attribute with name [" + WebApplicationContext.ROOT_WEB_APPLICATION_CONTEXT_ATTRIBUTE + "]");
/*     */       }
/*     */ 
/* 311 */       if (logger.isInfoEnabled()) {
/* 312 */         long elapsedTime = System.currentTimeMillis() - startTime;
/* 313 */         logger.info("Root WebApplicationContext: initialization completed in " + elapsedTime + " ms");
/*     */       }
/*     */ 
/* 316 */       return this.context;
/*     */     }
/*     */     catch (RuntimeException ex) {
/* 319 */       logger.error("Context initialization failed", ex);
/* 320 */       servletContext.setAttribute(WebApplicationContext.ROOT_WEB_APPLICATION_CONTEXT_ATTRIBUTE, ex);
/* 321 */       throw ex;
/*     */     }
/*     */     catch (Error err) {
/* 324 */       logger.error("Context initialization failed", err);
/* 325 */       servletContext.setAttribute(WebApplicationContext.ROOT_WEB_APPLICATION_CONTEXT_ATTRIBUTE, err);
/* 326 */     }throw err;
/*     */   }
/*     */ 
/*     */   protected WebApplicationContext createWebApplicationContext(ServletContext sc)
/*     */   {
/* 343 */     Class contextClass = determineContextClass(sc);
/* 344 */     if (!ConfigurableWebApplicationContext.class.isAssignableFrom(contextClass)) {
/* 345 */       throw new ApplicationContextException("Custom context class [" + contextClass.getName() + "] is not of type [" + ConfigurableWebApplicationContext.class.getName() + "]");
/*     */     }
/*     */ 
/* 348 */     return (ConfigurableWebApplicationContext)BeanUtils.instantiateClass(contextClass);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   protected WebApplicationContext createWebApplicationContext(ServletContext sc, ApplicationContext parent)
/*     */   {
/* 358 */     return createWebApplicationContext(sc);
/*     */   }
/*     */ 
/*     */   protected void configureAndRefreshWebApplicationContext(ConfigurableWebApplicationContext wac, ServletContext sc) {
/* 362 */     if (ObjectUtils.identityToString(wac).equals(wac.getId()))
/*     */     {
/* 365 */       String idParam = sc.getInitParameter("contextId");
/* 366 */       if (idParam != null) {
/* 367 */         wac.setId(idParam);
/*     */       }
/* 371 */       else if ((sc.getMajorVersion() == 2) && (sc.getMinorVersion() < 5))
/*     */       {
/* 373 */         wac.setId(ConfigurableWebApplicationContext.APPLICATION_CONTEXT_ID_PREFIX + ObjectUtils.getDisplayString(sc.getServletContextName()));
/*     */       }
/*     */       else
/*     */       {
/* 377 */         wac.setId(ConfigurableWebApplicationContext.APPLICATION_CONTEXT_ID_PREFIX + ObjectUtils.getDisplayString(sc.getContextPath()));
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 383 */     wac.setServletContext(sc);
/* 384 */     String initParameter = sc.getInitParameter("contextConfigLocation");
/* 385 */     if (initParameter != null) {
/* 386 */       wac.setConfigLocation(initParameter);
/*     */     }
/* 388 */     customizeContext(sc, wac);
/* 389 */     wac.refresh();
/*     */   }
/*     */ 
/*     */   protected Class<?> determineContextClass(ServletContext servletContext)
/*     */   {
/* 401 */     String contextClassName = servletContext.getInitParameter("contextClass");
/* 402 */     if (contextClassName != null) {
/*     */       try {
/* 404 */         return ClassUtils.forName(contextClassName, ClassUtils.getDefaultClassLoader());
/*     */       }
/*     */       catch (ClassNotFoundException ex) {
/* 407 */         throw new ApplicationContextException("Failed to load custom context class [" + contextClassName + "]", ex);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 412 */     contextClassName = defaultStrategies.getProperty(WebApplicationContext.class.getName());
/*     */     try {
/* 414 */       return ClassUtils.forName(contextClassName, ContextLoader.class.getClassLoader());
/*     */     } catch (ClassNotFoundException ex) {
/*     */     }
/* 417 */     throw new ApplicationContextException("Failed to load default context class [" + contextClassName + "]", ex);
/*     */   }
/*     */ 
/*     */   protected List<Class<ApplicationContextInitializer<ConfigurableApplicationContext>>> determineContextInitializerClasses(ServletContext servletContext)
/*     */   {
/* 432 */     String classNames = servletContext.getInitParameter("contextInitializerClasses");
/* 433 */     List classes = new ArrayList();
/*     */ 
/* 435 */     if (classNames != null) {
/* 436 */       for (String className : StringUtils.tokenizeToStringArray(classNames, ",")) {
/*     */         try {
/* 438 */           Class clazz = ClassUtils.forName(className, ClassUtils.getDefaultClassLoader());
/* 439 */           Assert.isAssignable(ApplicationContextInitializer.class, clazz, "class [" + className + "] must implement ApplicationContextInitializer");
/*     */ 
/* 441 */           classes.add(clazz);
/*     */         }
/*     */         catch (ClassNotFoundException ex) {
/* 444 */           throw new ApplicationContextException("Failed to load context initializer class [" + className + "]", ex);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 449 */     return classes;
/*     */   }
/*     */ 
/*     */   protected void customizeContext(ServletContext servletContext, ConfigurableWebApplicationContext applicationContext)
/*     */   {
/* 471 */     List initializerClasses = determineContextInitializerClasses(servletContext);
/*     */ 
/* 473 */     if (initializerClasses.size() == 0)
/*     */     {
/* 475 */       return;
/*     */     }
/*     */ 
/* 478 */     Class contextClass = applicationContext.getClass();
/* 479 */     ArrayList initializerInstances = new ArrayList();
/*     */ 
/* 482 */     for (Class initializerClass : initializerClasses) {
/* 483 */       Class initializerContextClass = GenericTypeResolver.resolveTypeArgument(initializerClass, ApplicationContextInitializer.class);
/*     */ 
/* 485 */       if (initializerContextClass != null) {
/* 486 */         Assert.isAssignable(initializerContextClass, contextClass, String.format("Could not add context initializer [%s] as its generic parameter [%s] is not assignable from the type of application context used by this context loader [%s]: ", new Object[] { initializerClass.getName(), initializerContextClass.getName(), contextClass.getName() }));
/*     */       }
/*     */ 
/* 492 */       initializerInstances.add(BeanUtils.instantiateClass(initializerClass));
/*     */     }
/*     */ 
/* 495 */     ConfigurableEnvironment env = applicationContext.getEnvironment();
/* 496 */     if ((env instanceof ConfigurableWebEnvironment)) {
/* 497 */       ((ConfigurableWebEnvironment)env).initPropertySources(servletContext, null);
/*     */     }
/*     */ 
/* 500 */     Collections.sort(initializerInstances, new AnnotationAwareOrderComparator());
/* 501 */     for (ApplicationContextInitializer initializer : initializerInstances)
/* 502 */       initializer.initialize(applicationContext);
/*     */   }
/*     */ 
/*     */   protected ApplicationContext loadParentContext(ServletContext servletContext)
/*     */   {
/* 527 */     ApplicationContext parentContext = null;
/* 528 */     String locatorFactorySelector = servletContext.getInitParameter("locatorFactorySelector");
/* 529 */     String parentContextKey = servletContext.getInitParameter("parentContextKey");
/*     */ 
/* 531 */     if (parentContextKey != null)
/*     */     {
/* 533 */       BeanFactoryLocator locator = ContextSingletonBeanFactoryLocator.getInstance(locatorFactorySelector);
/* 534 */       Log logger = LogFactory.getLog(ContextLoader.class);
/* 535 */       if (logger.isDebugEnabled()) {
/* 536 */         logger.debug("Getting parent context definition: using parent context key of '" + parentContextKey + "' with BeanFactoryLocator");
/*     */       }
/*     */ 
/* 539 */       this.parentContextRef = locator.useBeanFactory(parentContextKey);
/* 540 */       parentContext = (ApplicationContext)this.parentContextRef.getFactory();
/*     */     }
/*     */ 
/* 543 */     return parentContext;
/*     */   }
/*     */ 
/*     */   public void closeWebApplicationContext(ServletContext servletContext)
/*     */   {
/* 556 */     servletContext.log("Closing Spring root WebApplicationContext");
/*     */     try {
/* 558 */       if ((this.context instanceof ConfigurableWebApplicationContext))
/* 559 */         ((ConfigurableWebApplicationContext)this.context).close();
/*     */     }
/*     */     finally
/*     */     {
/*     */       ClassLoader ccl;
/* 563 */       ClassLoader ccl = Thread.currentThread().getContextClassLoader();
/* 564 */       if (ccl == ContextLoader.class.getClassLoader()) {
/* 565 */         currentContext = null;
/*     */       }
/* 567 */       else if (ccl != null) {
/* 568 */         currentContextPerThread.remove(ccl);
/*     */       }
/* 570 */       servletContext.removeAttribute(WebApplicationContext.ROOT_WEB_APPLICATION_CONTEXT_ATTRIBUTE);
/* 571 */       if (this.parentContextRef != null)
/* 572 */         this.parentContextRef.release();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static WebApplicationContext getCurrentWebApplicationContext()
/*     */   {
/* 587 */     ClassLoader ccl = Thread.currentThread().getContextClassLoader();
/* 588 */     if (ccl != null) {
/* 589 */       WebApplicationContext ccpt = (WebApplicationContext)currentContextPerThread.get(ccl);
/* 590 */       if (ccpt != null) {
/* 591 */         return ccpt;
/*     */       }
/*     */     }
/* 594 */     return currentContext;
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/* 164 */       ClassPathResource resource = new ClassPathResource("ContextLoader.properties", ContextLoader.class);
/* 165 */       defaultStrategies = PropertiesLoaderUtils.loadProperties(resource);
/*     */     }
/*     */     catch (IOException ex) {
/* 168 */       throw new IllegalStateException("Could not load 'ContextLoader.properties': " + ex.getMessage());
/*     */     }
/*     */ 
/* 176 */     currentContextPerThread = new ConcurrentHashMap(1);
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.ContextLoader
 * JD-Core Version:    0.6.0
 */