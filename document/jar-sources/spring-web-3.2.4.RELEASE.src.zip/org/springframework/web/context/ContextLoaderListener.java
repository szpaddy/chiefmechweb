/*     */ package org.springframework.web.context;
/*     */ 
/*     */ import javax.servlet.ServletContextEvent;
/*     */ import javax.servlet.ServletContextListener;
/*     */ 
/*     */ public class ContextLoaderListener extends ContextLoader
/*     */   implements ServletContextListener
/*     */ {
/*     */   private ContextLoader contextLoader;
/*     */ 
/*     */   public ContextLoaderListener()
/*     */   {
/*     */   }
/*     */ 
/*     */   public ContextLoaderListener(WebApplicationContext context)
/*     */   {
/* 101 */     super(context);
/*     */   }
/*     */ 
/*     */   public void contextInitialized(ServletContextEvent event)
/*     */   {
/* 108 */     this.contextLoader = createContextLoader();
/* 109 */     if (this.contextLoader == null) {
/* 110 */       this.contextLoader = this;
/*     */     }
/* 112 */     this.contextLoader.initWebApplicationContext(event.getServletContext());
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   protected ContextLoader createContextLoader()
/*     */   {
/* 123 */     return null;
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public ContextLoader getContextLoader()
/*     */   {
/* 134 */     return this.contextLoader;
/*     */   }
/*     */ 
/*     */   public void contextDestroyed(ServletContextEvent event)
/*     */   {
/* 142 */     if (this.contextLoader != null) {
/* 143 */       this.contextLoader.closeWebApplicationContext(event.getServletContext());
/*     */     }
/* 145 */     ContextCleanupListener.cleanupAttributes(event.getServletContext());
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.ContextLoaderListener
 * JD-Core Version:    0.6.0
 */