package org.springframework.web.context.request.async;

import org.springframework.web.context.request.NativeWebRequest;

public abstract interface AsyncWebRequest extends NativeWebRequest
{
  public abstract void setTimeout(Long paramLong);

  public abstract void addTimeoutHandler(Runnable paramRunnable);

  public abstract void addCompletionHandler(Runnable paramRunnable);

  public abstract void startAsync();

  public abstract boolean isAsyncStarted();

  public abstract void dispatch();

  public abstract boolean isAsyncComplete();
}

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.request.async.AsyncWebRequest
 * JD-Core Version:    0.6.0
 */