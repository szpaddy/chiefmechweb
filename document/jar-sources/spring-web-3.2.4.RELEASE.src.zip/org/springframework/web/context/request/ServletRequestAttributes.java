/*     */ package org.springframework.web.context.request;
/*     */ 
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.util.WebUtils;
/*     */ 
/*     */ public class ServletRequestAttributes extends AbstractRequestAttributes
/*     */ {
/*  45 */   public static final String DESTRUCTION_CALLBACK_NAME_PREFIX = ServletRequestAttributes.class.getName() + ".DESTRUCTION_CALLBACK.";
/*     */   private final HttpServletRequest request;
/*     */   private volatile HttpSession session;
/*  53 */   private final Map<String, Object> sessionAttributesToUpdate = new ConcurrentHashMap(1);
/*     */ 
/*     */   public ServletRequestAttributes(HttpServletRequest request)
/*     */   {
/*  61 */     Assert.notNull(request, "Request must not be null");
/*  62 */     this.request = request;
/*     */   }
/*     */ 
/*     */   public final HttpServletRequest getRequest()
/*     */   {
/*  70 */     return this.request;
/*     */   }
/*     */ 
/*     */   protected final HttpSession getSession(boolean allowCreate)
/*     */   {
/*  78 */     if (isRequestActive()) {
/*  79 */       return this.request.getSession(allowCreate);
/*     */     }
/*     */ 
/*  83 */     if ((this.session == null) && (allowCreate)) {
/*  84 */       throw new IllegalStateException("No session found and request already completed - cannot create new session!");
/*     */     }
/*     */ 
/*  87 */     return this.session;
/*     */   }
/*     */ 
/*     */   public Object getAttribute(String name, int scope)
/*     */   {
/*  93 */     if (scope == 0) {
/*  94 */       if (!isRequestActive()) {
/*  95 */         throw new IllegalStateException("Cannot ask for request attribute - request is not active anymore!");
/*     */       }
/*     */ 
/*  98 */       return this.request.getAttribute(name);
/*     */     }
/*     */ 
/* 101 */     HttpSession session = getSession(false);
/* 102 */     if (session != null) {
/*     */       try {
/* 104 */         Object value = session.getAttribute(name);
/* 105 */         if (value != null) {
/* 106 */           this.sessionAttributesToUpdate.put(name, value);
/*     */         }
/* 108 */         return value;
/*     */       }
/*     */       catch (IllegalStateException ex)
/*     */       {
/*     */       }
/*     */     }
/* 114 */     return null;
/*     */   }
/*     */ 
/*     */   public void setAttribute(String name, Object value, int scope)
/*     */   {
/* 119 */     if (scope == 0) {
/* 120 */       if (!isRequestActive()) {
/* 121 */         throw new IllegalStateException("Cannot set request attribute - request is not active anymore!");
/*     */       }
/*     */ 
/* 124 */       this.request.setAttribute(name, value);
/*     */     }
/*     */     else {
/* 127 */       HttpSession session = getSession(true);
/* 128 */       this.sessionAttributesToUpdate.remove(name);
/* 129 */       session.setAttribute(name, value);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void removeAttribute(String name, int scope) {
/* 134 */     if (scope == 0) {
/* 135 */       if (isRequestActive()) {
/* 136 */         this.request.removeAttribute(name);
/* 137 */         removeRequestDestructionCallback(name);
/*     */       }
/*     */     }
/*     */     else {
/* 141 */       HttpSession session = getSession(false);
/* 142 */       if (session != null) {
/* 143 */         this.sessionAttributesToUpdate.remove(name);
/*     */         try {
/* 145 */           session.removeAttribute(name);
/*     */ 
/* 147 */           session.removeAttribute(DESTRUCTION_CALLBACK_NAME_PREFIX + name);
/*     */         }
/*     */         catch (IllegalStateException ex)
/*     */         {
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public String[] getAttributeNames(int scope) {
/* 157 */     if (scope == 0) {
/* 158 */       if (!isRequestActive()) {
/* 159 */         throw new IllegalStateException("Cannot ask for request attributes - request is not active anymore!");
/*     */       }
/*     */ 
/* 162 */       return StringUtils.toStringArray(this.request.getAttributeNames());
/*     */     }
/*     */ 
/* 165 */     HttpSession session = getSession(false);
/* 166 */     if (session != null) {
/*     */       try {
/* 168 */         return StringUtils.toStringArray(session.getAttributeNames());
/*     */       }
/*     */       catch (IllegalStateException ex)
/*     */       {
/*     */       }
/*     */     }
/* 174 */     return new String[0];
/*     */   }
/*     */ 
/*     */   public void registerDestructionCallback(String name, Runnable callback, int scope)
/*     */   {
/* 179 */     if (scope == 0) {
/* 180 */       registerRequestDestructionCallback(name, callback);
/*     */     }
/*     */     else
/* 183 */       registerSessionDestructionCallback(name, callback);
/*     */   }
/*     */ 
/*     */   public Object resolveReference(String key)
/*     */   {
/* 188 */     if ("request".equals(key)) {
/* 189 */       return this.request;
/*     */     }
/* 191 */     if ("session".equals(key)) {
/* 192 */       return getSession(true);
/*     */     }
/*     */ 
/* 195 */     return null;
/*     */   }
/*     */ 
/*     */   public String getSessionId()
/*     */   {
/* 200 */     return getSession(true).getId();
/*     */   }
/*     */ 
/*     */   public Object getSessionMutex() {
/* 204 */     return WebUtils.getSessionMutex(getSession(true));
/*     */   }
/*     */ 
/*     */   protected void updateAccessedSessionAttributes()
/*     */   {
/* 215 */     this.session = this.request.getSession(false);
/*     */ 
/* 217 */     if (this.session != null) {
/*     */       try {
/* 219 */         for (Map.Entry entry : this.sessionAttributesToUpdate.entrySet()) {
/* 220 */           String name = (String)entry.getKey();
/* 221 */           Object newValue = entry.getValue();
/* 222 */           Object oldValue = this.session.getAttribute(name);
/* 223 */           if (oldValue == newValue) {
/* 224 */             this.session.setAttribute(name, newValue);
/*     */           }
/*     */         }
/*     */       }
/*     */       catch (IllegalStateException ex)
/*     */       {
/*     */       }
/*     */     }
/* 232 */     this.sessionAttributesToUpdate.clear();
/*     */   }
/*     */ 
/*     */   protected void registerSessionDestructionCallback(String name, Runnable callback)
/*     */   {
/* 243 */     HttpSession session = getSession(true);
/* 244 */     session.setAttribute(DESTRUCTION_CALLBACK_NAME_PREFIX + name, new DestructionCallbackBindingListener(callback));
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 251 */     return this.request.toString();
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.request.ServletRequestAttributes
 * JD-Core Version:    0.6.0
 */