/*    */ package org.springframework.web.context.request.async;
/*    */ 
/*    */ import java.util.concurrent.Callable;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.springframework.http.HttpStatus;
/*    */ import org.springframework.web.context.request.NativeWebRequest;
/*    */ 
/*    */ public class TimeoutCallableProcessingInterceptor extends CallableProcessingInterceptorAdapter
/*    */ {
/*    */   public <T> Object handleTimeout(NativeWebRequest request, Callable<T> task)
/*    */     throws Exception
/*    */   {
/* 42 */     HttpServletResponse servletResponse = (HttpServletResponse)request.getNativeResponse(HttpServletResponse.class);
/* 43 */     if (!servletResponse.isCommitted()) {
/* 44 */       servletResponse.sendError(HttpStatus.SERVICE_UNAVAILABLE.value());
/*    */     }
/* 46 */     return CallableProcessingInterceptor.RESPONSE_HANDLED;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.request.async.TimeoutCallableProcessingInterceptor
 * JD-Core Version:    0.6.0
 */