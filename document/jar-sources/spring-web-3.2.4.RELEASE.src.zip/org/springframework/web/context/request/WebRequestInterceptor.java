package org.springframework.web.context.request;

import org.springframework.ui.ModelMap;

public abstract interface WebRequestInterceptor
{
  public abstract void preHandle(WebRequest paramWebRequest)
    throws Exception;

  public abstract void postHandle(WebRequest paramWebRequest, ModelMap paramModelMap)
    throws Exception;

  public abstract void afterCompletion(WebRequest paramWebRequest, Exception paramException)
    throws Exception;
}

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.request.WebRequestInterceptor
 * JD-Core Version:    0.6.0
 */