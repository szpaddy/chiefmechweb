/*    */ package org.springframework.web.context.request.async;
/*    */ 
/*    */ import java.lang.reflect.Constructor;
/*    */ import javax.servlet.ServletRequest;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.springframework.beans.BeanUtils;
/*    */ import org.springframework.util.ClassUtils;
/*    */ import org.springframework.web.context.request.WebRequest;
/*    */ 
/*    */ public abstract class WebAsyncUtils
/*    */ {
/* 37 */   public static final String WEB_ASYNC_MANAGER_ATTRIBUTE = WebAsyncManager.class.getName() + ".WEB_ASYNC_MANAGER";
/*    */   private static Constructor<?> standardAsyncRequestConstructor;
/*    */ 
/*    */   public static WebAsyncManager getAsyncManager(ServletRequest servletRequest)
/*    */   {
/* 47 */     WebAsyncManager asyncManager = (WebAsyncManager)servletRequest.getAttribute(WEB_ASYNC_MANAGER_ATTRIBUTE);
/* 48 */     if (asyncManager == null) {
/* 49 */       asyncManager = new WebAsyncManager();
/* 50 */       servletRequest.setAttribute(WEB_ASYNC_MANAGER_ATTRIBUTE, asyncManager);
/*    */     }
/* 52 */     return asyncManager;
/*    */   }
/*    */ 
/*    */   public static WebAsyncManager getAsyncManager(WebRequest webRequest)
/*    */   {
/* 60 */     int scope = 0;
/* 61 */     WebAsyncManager asyncManager = (WebAsyncManager)webRequest.getAttribute(WEB_ASYNC_MANAGER_ATTRIBUTE, scope);
/* 62 */     if (asyncManager == null) {
/* 63 */       asyncManager = new WebAsyncManager();
/* 64 */       webRequest.setAttribute(WEB_ASYNC_MANAGER_ATTRIBUTE, asyncManager, scope);
/*    */     }
/* 66 */     return asyncManager;
/*    */   }
/*    */ 
/*    */   public static AsyncWebRequest createAsyncWebRequest(HttpServletRequest request, HttpServletResponse response)
/*    */   {
/* 80 */     return ClassUtils.hasMethod(ServletRequest.class, "startAsync", new Class[0]) ? createStandardServletAsyncWebRequest(request, response) : new NoSupportAsyncWebRequest(request, response);
/*    */   }
/*    */ 
/*    */   private static AsyncWebRequest createStandardServletAsyncWebRequest(HttpServletRequest request, HttpServletResponse response)
/*    */   {
/*    */     try {
/* 86 */       if (standardAsyncRequestConstructor == null) {
/* 87 */         String className = "org.springframework.web.context.request.async.StandardServletAsyncWebRequest";
/* 88 */         Class clazz = ClassUtils.forName(className, WebAsyncUtils.class.getClassLoader());
/* 89 */         standardAsyncRequestConstructor = clazz.getConstructor(new Class[] { HttpServletRequest.class, HttpServletResponse.class });
/*    */       }
/* 91 */       return (AsyncWebRequest)BeanUtils.instantiateClass(standardAsyncRequestConstructor, new Object[] { request, response });
/*    */     } catch (Throwable t) {
/*    */     }
/* 94 */     throw new IllegalStateException("Failed to instantiate StandardServletAsyncWebRequest", t);
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.request.async.WebAsyncUtils
 * JD-Core Version:    0.6.0
 */