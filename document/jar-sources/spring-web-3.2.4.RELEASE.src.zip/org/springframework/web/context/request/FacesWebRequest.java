/*     */ package org.springframework.web.context.request;
/*     */ 
/*     */ import java.security.Principal;
/*     */ import java.util.Iterator;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.faces.context.ExternalContext;
/*     */ import javax.faces.context.FacesContext;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class FacesWebRequest extends FacesRequestAttributes
/*     */   implements NativeWebRequest
/*     */ {
/*     */   public FacesWebRequest(FacesContext facesContext)
/*     */   {
/*  42 */     super(facesContext);
/*     */   }
/*     */ 
/*     */   public Object getNativeRequest()
/*     */   {
/*  47 */     return getExternalContext().getRequest();
/*     */   }
/*     */ 
/*     */   public Object getNativeResponse() {
/*  51 */     return getExternalContext().getResponse();
/*     */   }
/*     */ 
/*     */   public <T> T getNativeRequest(Class<T> requiredType)
/*     */   {
/*  56 */     if (requiredType != null) {
/*  57 */       Object request = getExternalContext().getRequest();
/*  58 */       if (requiredType.isInstance(request)) {
/*  59 */         return request;
/*     */       }
/*     */     }
/*  62 */     return null;
/*     */   }
/*     */ 
/*     */   public <T> T getNativeResponse(Class<T> requiredType)
/*     */   {
/*  67 */     if (requiredType != null) {
/*  68 */       Object response = getExternalContext().getResponse();
/*  69 */       if (requiredType.isInstance(response)) {
/*  70 */         return response;
/*     */       }
/*     */     }
/*  73 */     return null;
/*     */   }
/*     */ 
/*     */   public String getHeader(String headerName)
/*     */   {
/*  78 */     return (String)getExternalContext().getRequestHeaderMap().get(headerName);
/*     */   }
/*     */ 
/*     */   public String[] getHeaderValues(String headerName) {
/*  82 */     return (String[])getExternalContext().getRequestHeaderValuesMap().get(headerName);
/*     */   }
/*     */ 
/*     */   public Iterator<String> getHeaderNames() {
/*  86 */     return getExternalContext().getRequestHeaderMap().keySet().iterator();
/*     */   }
/*     */ 
/*     */   public String getParameter(String paramName) {
/*  90 */     return (String)getExternalContext().getRequestParameterMap().get(paramName);
/*     */   }
/*     */ 
/*     */   public Iterator<String> getParameterNames() {
/*  94 */     return getExternalContext().getRequestParameterNames();
/*     */   }
/*     */ 
/*     */   public String[] getParameterValues(String paramName) {
/*  98 */     return (String[])getExternalContext().getRequestParameterValuesMap().get(paramName);
/*     */   }
/*     */ 
/*     */   public Map<String, String[]> getParameterMap() {
/* 102 */     return getExternalContext().getRequestParameterValuesMap();
/*     */   }
/*     */ 
/*     */   public Locale getLocale() {
/* 106 */     return getFacesContext().getExternalContext().getRequestLocale();
/*     */   }
/*     */ 
/*     */   public String getContextPath() {
/* 110 */     return getFacesContext().getExternalContext().getRequestContextPath();
/*     */   }
/*     */ 
/*     */   public String getRemoteUser() {
/* 114 */     return getFacesContext().getExternalContext().getRemoteUser();
/*     */   }
/*     */ 
/*     */   public Principal getUserPrincipal() {
/* 118 */     return getFacesContext().getExternalContext().getUserPrincipal();
/*     */   }
/*     */ 
/*     */   public boolean isUserInRole(String role) {
/* 122 */     return getFacesContext().getExternalContext().isUserInRole(role);
/*     */   }
/*     */ 
/*     */   public boolean isSecure() {
/* 126 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean checkNotModified(long lastModifiedTimestamp) {
/* 130 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean checkNotModified(String eTag) {
/* 134 */     return false;
/*     */   }
/*     */ 
/*     */   public String getDescription(boolean includeClientInfo) {
/* 138 */     ExternalContext externalContext = getExternalContext();
/* 139 */     StringBuilder sb = new StringBuilder();
/* 140 */     sb.append("context=").append(externalContext.getRequestContextPath());
/* 141 */     if (includeClientInfo) {
/* 142 */       Object session = externalContext.getSession(false);
/* 143 */       if (session != null) {
/* 144 */         sb.append(";session=").append(getSessionId());
/*     */       }
/* 146 */       String user = externalContext.getRemoteUser();
/* 147 */       if (StringUtils.hasLength(user)) {
/* 148 */         sb.append(";user=").append(user);
/*     */       }
/*     */     }
/* 151 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 157 */     return "FacesWebRequest: " + getDescription(true);
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.request.FacesWebRequest
 * JD-Core Version:    0.6.0
 */