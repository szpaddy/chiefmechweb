/*     */ package org.springframework.web.context.request;
/*     */ 
/*     */ import org.springframework.beans.factory.ObjectFactory;
/*     */ 
/*     */ public class SessionScope extends AbstractRequestAttributesScope
/*     */ {
/*     */   private final int scope;
/*     */ 
/*     */   public SessionScope()
/*     */   {
/*  58 */     this.scope = 1;
/*     */   }
/*     */ 
/*     */   public SessionScope(boolean globalSession)
/*     */   {
/*  75 */     this.scope = (globalSession ? 2 : 1);
/*     */   }
/*     */ 
/*     */   protected int getScope()
/*     */   {
/*  81 */     return this.scope;
/*     */   }
/*     */ 
/*     */   public String getConversationId() {
/*  85 */     return RequestContextHolder.currentRequestAttributes().getSessionId();
/*     */   }
/*     */ 
/*     */   public Object get(String name, ObjectFactory objectFactory)
/*     */   {
/*  90 */     Object mutex = RequestContextHolder.currentRequestAttributes().getSessionMutex();
/*  91 */     synchronized (mutex) {
/*  92 */       return super.get(name, objectFactory);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Object remove(String name)
/*     */   {
/*  98 */     Object mutex = RequestContextHolder.currentRequestAttributes().getSessionMutex();
/*  99 */     synchronized (mutex) {
/* 100 */       return super.remove(name);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.request.SessionScope
 * JD-Core Version:    0.6.0
 */