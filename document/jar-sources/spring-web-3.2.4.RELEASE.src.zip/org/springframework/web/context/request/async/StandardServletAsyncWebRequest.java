/*     */ package org.springframework.web.context.request.async;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import javax.servlet.AsyncContext;
/*     */ import javax.servlet.AsyncEvent;
/*     */ import javax.servlet.AsyncListener;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.context.request.ServletWebRequest;
/*     */ 
/*     */ public class StandardServletAsyncWebRequest extends ServletWebRequest
/*     */   implements AsyncWebRequest, AsyncListener
/*     */ {
/*     */   private Long timeout;
/*     */   private AsyncContext asyncContext;
/*  50 */   private AtomicBoolean asyncCompleted = new AtomicBoolean(false);
/*     */ 
/*  52 */   private final List<Runnable> timeoutHandlers = new ArrayList();
/*     */ 
/*  54 */   private final List<Runnable> completionHandlers = new ArrayList();
/*     */ 
/*     */   public StandardServletAsyncWebRequest(HttpServletRequest request, HttpServletResponse response)
/*     */   {
/*  63 */     super(request, response);
/*     */   }
/*     */ 
/*     */   public void setTimeout(Long timeout)
/*     */   {
/*  72 */     Assert.state(!isAsyncStarted(), "Cannot change the timeout with concurrent handling in progress");
/*  73 */     this.timeout = timeout;
/*     */   }
/*     */ 
/*     */   public void addTimeoutHandler(Runnable timeoutHandler) {
/*  77 */     this.timeoutHandlers.add(timeoutHandler);
/*     */   }
/*     */ 
/*     */   public void addCompletionHandler(Runnable runnable) {
/*  81 */     this.completionHandlers.add(runnable);
/*     */   }
/*     */ 
/*     */   public boolean isAsyncStarted() {
/*  85 */     return (this.asyncContext != null) && (getRequest().isAsyncStarted());
/*     */   }
/*     */ 
/*     */   public boolean isAsyncComplete()
/*     */   {
/*  94 */     return this.asyncCompleted.get();
/*     */   }
/*     */ 
/*     */   public void startAsync() {
/*  98 */     Assert.state(getRequest().isAsyncSupported(), "Async support must be enabled on a servlet and for all filters involved in async request processing. This is done in Java code using the Servlet API or by adding \"<async-supported>true</async-supported>\" to servlet and filter declarations in web.xml.");
/*     */ 
/* 103 */     Assert.state(!isAsyncComplete(), "Async processing has already completed");
/* 104 */     if (isAsyncStarted()) {
/* 105 */       return;
/*     */     }
/* 107 */     this.asyncContext = getRequest().startAsync(getRequest(), getResponse());
/* 108 */     this.asyncContext.addListener(this);
/* 109 */     if (this.timeout != null)
/* 110 */       this.asyncContext.setTimeout(this.timeout.longValue());
/*     */   }
/*     */ 
/*     */   public void dispatch()
/*     */   {
/* 115 */     Assert.notNull(this.asyncContext, "Cannot dispatch without an AsyncContext");
/* 116 */     this.asyncContext.dispatch();
/*     */   }
/*     */ 
/*     */   public void onStartAsync(AsyncEvent event)
/*     */     throws IOException
/*     */   {
/*     */   }
/*     */ 
/*     */   public void onError(AsyncEvent event) throws IOException
/*     */   {
/*     */   }
/*     */ 
/*     */   public void onTimeout(AsyncEvent event) throws IOException
/*     */   {
/* 130 */     for (Runnable handler : this.timeoutHandlers)
/* 131 */       handler.run();
/*     */   }
/*     */ 
/*     */   public void onComplete(AsyncEvent event) throws IOException
/*     */   {
/* 136 */     for (Runnable handler : this.completionHandlers) {
/* 137 */       handler.run();
/*     */     }
/* 139 */     this.asyncContext = null;
/* 140 */     this.asyncCompleted.set(true);
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.request.async.StandardServletAsyncWebRequest
 * JD-Core Version:    0.6.0
 */