/*     */ package org.springframework.web.context.request;
/*     */ 
/*     */ import java.security.Principal;
/*     */ import java.util.Iterator;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.util.WebUtils;
/*     */ 
/*     */ public class ServletWebRequest extends ServletRequestAttributes
/*     */   implements NativeWebRequest
/*     */ {
/*     */   private static final String HEADER_ETAG = "ETag";
/*     */   private static final String HEADER_IF_MODIFIED_SINCE = "If-Modified-Since";
/*     */   private static final String HEADER_IF_NONE_MATCH = "If-None-Match";
/*     */   private static final String HEADER_LAST_MODIFIED = "Last-Modified";
/*     */   private static final String METHOD_GET = "GET";
/*     */   private HttpServletResponse response;
/*  53 */   private boolean notModified = false;
/*     */ 
/*     */   public ServletWebRequest(HttpServletRequest request)
/*     */   {
/*  61 */     super(request);
/*     */   }
/*     */ 
/*     */   public ServletWebRequest(HttpServletRequest request, HttpServletResponse response)
/*     */   {
/*  70 */     this(request);
/*  71 */     this.response = response;
/*     */   }
/*     */ 
/*     */   public final HttpServletResponse getResponse()
/*     */   {
/*  79 */     return this.response;
/*     */   }
/*     */ 
/*     */   public Object getNativeRequest() {
/*  83 */     return getRequest();
/*     */   }
/*     */ 
/*     */   public Object getNativeResponse() {
/*  87 */     return getResponse();
/*     */   }
/*     */ 
/*     */   public <T> T getNativeRequest(Class<T> requiredType) {
/*  91 */     return WebUtils.getNativeRequest(getRequest(), requiredType);
/*     */   }
/*     */ 
/*     */   public <T> T getNativeResponse(Class<T> requiredType) {
/*  95 */     return WebUtils.getNativeResponse(getResponse(), requiredType);
/*     */   }
/*     */ 
/*     */   public String getHeader(String headerName)
/*     */   {
/* 100 */     return getRequest().getHeader(headerName);
/*     */   }
/*     */ 
/*     */   public String[] getHeaderValues(String headerName) {
/* 104 */     String[] headerValues = StringUtils.toStringArray(getRequest().getHeaders(headerName));
/* 105 */     return !ObjectUtils.isEmpty(headerValues) ? headerValues : null;
/*     */   }
/*     */ 
/*     */   public Iterator<String> getHeaderNames() {
/* 109 */     return CollectionUtils.toIterator(getRequest().getHeaderNames());
/*     */   }
/*     */ 
/*     */   public String getParameter(String paramName) {
/* 113 */     return getRequest().getParameter(paramName);
/*     */   }
/*     */ 
/*     */   public String[] getParameterValues(String paramName) {
/* 117 */     return getRequest().getParameterValues(paramName);
/*     */   }
/*     */ 
/*     */   public Iterator<String> getParameterNames() {
/* 121 */     return CollectionUtils.toIterator(getRequest().getParameterNames());
/*     */   }
/*     */ 
/*     */   public Map<String, String[]> getParameterMap() {
/* 125 */     return getRequest().getParameterMap();
/*     */   }
/*     */ 
/*     */   public Locale getLocale() {
/* 129 */     return getRequest().getLocale();
/*     */   }
/*     */ 
/*     */   public String getContextPath() {
/* 133 */     return getRequest().getContextPath();
/*     */   }
/*     */ 
/*     */   public String getRemoteUser() {
/* 137 */     return getRequest().getRemoteUser();
/*     */   }
/*     */ 
/*     */   public Principal getUserPrincipal() {
/* 141 */     return getRequest().getUserPrincipal();
/*     */   }
/*     */ 
/*     */   public boolean isUserInRole(String role) {
/* 145 */     return getRequest().isUserInRole(role);
/*     */   }
/*     */ 
/*     */   public boolean isSecure() {
/* 149 */     return getRequest().isSecure();
/*     */   }
/*     */ 
/*     */   public boolean checkNotModified(long lastModifiedTimestamp) {
/* 153 */     if ((lastModifiedTimestamp >= 0L) && (!this.notModified) && ((this.response == null) || (!this.response.containsHeader("Last-Modified"))))
/*     */     {
/* 155 */       long ifModifiedSince = getRequest().getDateHeader("If-Modified-Since");
/* 156 */       this.notModified = (ifModifiedSince >= lastModifiedTimestamp / 1000L * 1000L);
/* 157 */       if (this.response != null) {
/* 158 */         if ((this.notModified) && ("GET".equals(getRequest().getMethod()))) {
/* 159 */           this.response.setStatus(304);
/*     */         }
/*     */         else {
/* 162 */           this.response.setDateHeader("Last-Modified", lastModifiedTimestamp);
/*     */         }
/*     */       }
/*     */     }
/* 166 */     return this.notModified;
/*     */   }
/*     */ 
/*     */   public boolean checkNotModified(String eTag) {
/* 170 */     if ((StringUtils.hasLength(eTag)) && (!this.notModified) && ((this.response == null) || (!this.response.containsHeader("ETag"))))
/*     */     {
/* 172 */       String ifNoneMatch = getRequest().getHeader("If-None-Match");
/* 173 */       this.notModified = eTag.equals(ifNoneMatch);
/* 174 */       if (this.response != null) {
/* 175 */         if ((this.notModified) && ("GET".equals(getRequest().getMethod()))) {
/* 176 */           this.response.setStatus(304);
/*     */         }
/*     */         else {
/* 179 */           this.response.setHeader("ETag", eTag);
/*     */         }
/*     */       }
/*     */     }
/* 183 */     return this.notModified;
/*     */   }
/*     */ 
/*     */   public boolean isNotModified()
/*     */   {
/* 188 */     return this.notModified;
/*     */   }
/*     */ 
/*     */   public String getDescription(boolean includeClientInfo) {
/* 192 */     HttpServletRequest request = getRequest();
/* 193 */     StringBuilder sb = new StringBuilder();
/* 194 */     sb.append("uri=").append(request.getRequestURI());
/* 195 */     if (includeClientInfo) {
/* 196 */       String client = request.getRemoteAddr();
/* 197 */       if (StringUtils.hasLength(client)) {
/* 198 */         sb.append(";client=").append(client);
/*     */       }
/* 200 */       HttpSession session = request.getSession(false);
/* 201 */       if (session != null) {
/* 202 */         sb.append(";session=").append(session.getId());
/*     */       }
/* 204 */       String user = request.getRemoteUser();
/* 205 */       if (StringUtils.hasLength(user)) {
/* 206 */         sb.append(";user=").append(user);
/*     */       }
/*     */     }
/* 209 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 215 */     return "ServletWebRequest: " + getDescription(true);
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.request.ServletWebRequest
 * JD-Core Version:    0.6.0
 */