/*    */ package org.springframework.web.context.request;
/*    */ 
/*    */ public class RequestScope extends AbstractRequestAttributesScope
/*    */ {
/*    */   protected int getScope()
/*    */   {
/* 48 */     return 0;
/*    */   }
/*    */ 
/*    */   public String getConversationId()
/*    */   {
/* 56 */     return null;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.request.RequestScope
 * JD-Core Version:    0.6.0
 */