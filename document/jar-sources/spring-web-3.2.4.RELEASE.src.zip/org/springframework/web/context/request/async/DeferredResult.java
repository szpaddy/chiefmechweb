/*     */ package org.springframework.web.context.request.async;
/*     */ 
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.context.request.NativeWebRequest;
/*     */ 
/*     */ public class DeferredResult<T>
/*     */ {
/*  51 */   private static final Log logger = LogFactory.getLog(DeferredResult.class);
/*     */ 
/*  53 */   private static final Object RESULT_NONE = new Object();
/*     */   private final Long timeout;
/*     */   private final Object timeoutResult;
/*     */   private Runnable timeoutCallback;
/*     */   private Runnable completionCallback;
/*     */   private DeferredResultHandler resultHandler;
/*  66 */   private Object result = RESULT_NONE;
/*     */   private boolean expired;
/*     */ 
/*     */   public DeferredResult()
/*     */   {
/*  75 */     this(null, RESULT_NONE);
/*     */   }
/*     */ 
/*     */   public DeferredResult(long timeout)
/*     */   {
/*  83 */     this(Long.valueOf(timeout), RESULT_NONE);
/*     */   }
/*     */ 
/*     */   public DeferredResult(Long timeout, Object timeoutResult)
/*     */   {
/*  93 */     this.timeoutResult = timeoutResult;
/*  94 */     this.timeout = timeout;
/*     */   }
/*     */ 
/*     */   public final boolean isSetOrExpired()
/*     */   {
/* 107 */     return (this.result != RESULT_NONE) || (this.expired);
/*     */   }
/*     */ 
/*     */   final Long getTimeoutValue()
/*     */   {
/* 114 */     return this.timeout;
/*     */   }
/*     */ 
/*     */   public void onTimeout(Runnable callback)
/*     */   {
/* 126 */     this.timeoutCallback = callback;
/*     */   }
/*     */ 
/*     */   public void onCompletion(Runnable callback)
/*     */   {
/* 136 */     this.completionCallback = callback;
/*     */   }
/*     */ 
/*     */   public final void setResultHandler(DeferredResultHandler resultHandler)
/*     */   {
/* 145 */     Assert.notNull(resultHandler, "DeferredResultHandler is required");
/* 146 */     synchronized (this) {
/* 147 */       this.resultHandler = resultHandler;
/* 148 */       if ((this.result != RESULT_NONE) && (!this.expired))
/*     */         try {
/* 150 */           this.resultHandler.handleResult(this.result);
/*     */         }
/*     */         catch (Throwable t) {
/* 153 */           logger.trace("DeferredResult not handled", t);
/*     */         }
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean setResult(T result)
/*     */   {
/* 167 */     return setResultInternal(result);
/*     */   }
/*     */ 
/*     */   private boolean setResultInternal(Object result) {
/* 171 */     synchronized (this) {
/* 172 */       if (isSetOrExpired()) {
/* 173 */         return false;
/*     */       }
/* 175 */       this.result = result;
/*     */     }
/* 177 */     if (this.resultHandler != null) {
/* 178 */       this.resultHandler.handleResult(this.result);
/*     */     }
/* 180 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean setErrorResult(Object result)
/*     */   {
/* 194 */     return setResultInternal(result);
/*     */   }
/*     */ 
/*     */   final DeferredResultProcessingInterceptor getInterceptor() {
/* 198 */     return new DeferredResultProcessingInterceptorAdapter()
/*     */     {
/*     */       public <S> boolean handleTimeout(NativeWebRequest request, DeferredResult<S> deferredResult)
/*     */       {
/* 202 */         if (DeferredResult.this.timeoutCallback != null) {
/* 203 */           DeferredResult.this.timeoutCallback.run();
/*     */         }
/* 205 */         if (DeferredResult.this.timeoutResult != DeferredResult.RESULT_NONE) {
/* 206 */           DeferredResult.this.setResultInternal(DeferredResult.this.timeoutResult);
/*     */         }
/* 208 */         return true;
/*     */       }
/*     */ 
/*     */       public <S> void afterCompletion(NativeWebRequest request, DeferredResult<S> deferredResult)
/*     */       {
/* 213 */         synchronized (DeferredResult.this) {
/* 214 */           DeferredResult.access$402(DeferredResult.this, true);
/*     */         }
/* 216 */         if (DeferredResult.this.completionCallback != null)
/* 217 */           DeferredResult.this.completionCallback.run();
/*     */       }
/*     */     };
/*     */   }
/*     */ 
/*     */   public static abstract interface DeferredResultHandler
/*     */   {
/*     */     public abstract void handleResult(Object paramObject);
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.request.async.DeferredResult
 * JD-Core Version:    0.6.0
 */