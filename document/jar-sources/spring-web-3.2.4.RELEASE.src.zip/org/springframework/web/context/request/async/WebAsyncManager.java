/*     */ package org.springframework.web.context.request.async;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.Callable;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.task.AsyncTaskExecutor;
/*     */ import org.springframework.core.task.SimpleAsyncTaskExecutor;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.util.UrlPathHelper;
/*     */ 
/*     */ public final class WebAsyncManager
/*     */ {
/*  59 */   private static final Object RESULT_NONE = new Object();
/*     */ 
/*  61 */   private static final Log logger = LogFactory.getLog(WebAsyncManager.class);
/*     */ 
/*  63 */   private static final UrlPathHelper urlPathHelper = new UrlPathHelper();
/*     */ 
/*  65 */   private static final CallableProcessingInterceptor timeoutCallableInterceptor = new TimeoutCallableProcessingInterceptor();
/*     */ 
/*  68 */   private static final DeferredResultProcessingInterceptor timeoutDeferredResultInterceptor = new TimeoutDeferredResultProcessingInterceptor();
/*     */   private AsyncWebRequest asyncWebRequest;
/*  74 */   private AsyncTaskExecutor taskExecutor = new SimpleAsyncTaskExecutor(getClass().getSimpleName());
/*     */ 
/*  76 */   private Object concurrentResult = RESULT_NONE;
/*     */   private Object[] concurrentResultContext;
/*  80 */   private final Map<Object, CallableProcessingInterceptor> callableInterceptors = new LinkedHashMap();
/*     */ 
/*  83 */   private final Map<Object, DeferredResultProcessingInterceptor> deferredResultInterceptors = new LinkedHashMap();
/*     */ 
/*     */   public void setAsyncWebRequest(AsyncWebRequest asyncWebRequest)
/*     */   {
/* 106 */     Assert.notNull(asyncWebRequest, "AsyncWebRequest must not be null");
/* 107 */     Assert.state(!isConcurrentHandlingStarted(), "Can't set AsyncWebRequest with concurrent handling in progress");
/* 108 */     this.asyncWebRequest = asyncWebRequest;
/* 109 */     this.asyncWebRequest.addCompletionHandler(new Runnable(asyncWebRequest) {
/*     */       public void run() {
/* 111 */         this.val$asyncWebRequest.removeAttribute(WebAsyncUtils.WEB_ASYNC_MANAGER_ATTRIBUTE, 0);
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   public void setTaskExecutor(AsyncTaskExecutor taskExecutor)
/*     */   {
/* 122 */     this.taskExecutor = taskExecutor;
/*     */   }
/*     */ 
/*     */   public boolean isConcurrentHandlingStarted()
/*     */   {
/* 134 */     return (this.asyncWebRequest != null) && (this.asyncWebRequest.isAsyncStarted());
/*     */   }
/*     */ 
/*     */   public boolean hasConcurrentResult()
/*     */   {
/* 141 */     return this.concurrentResult != RESULT_NONE;
/*     */   }
/*     */ 
/*     */   public Object getConcurrentResult()
/*     */   {
/* 152 */     return this.concurrentResult;
/*     */   }
/*     */ 
/*     */   public Object[] getConcurrentResultContext()
/*     */   {
/* 162 */     return this.concurrentResultContext;
/*     */   }
/*     */ 
/*     */   public CallableProcessingInterceptor getCallableInterceptor(Object key)
/*     */   {
/* 171 */     return (CallableProcessingInterceptor)this.callableInterceptors.get(key);
/*     */   }
/*     */ 
/*     */   public DeferredResultProcessingInterceptor getDeferredResultInterceptor(Object key)
/*     */   {
/* 180 */     return (DeferredResultProcessingInterceptor)this.deferredResultInterceptors.get(key);
/*     */   }
/*     */ 
/*     */   public void registerCallableInterceptor(Object key, CallableProcessingInterceptor interceptor)
/*     */   {
/* 189 */     Assert.notNull(key, "Key is required");
/* 190 */     Assert.notNull(interceptor, "CallableProcessingInterceptor  is required");
/* 191 */     this.callableInterceptors.put(key, interceptor);
/*     */   }
/*     */ 
/*     */   public void registerCallableInterceptors(CallableProcessingInterceptor[] interceptors)
/*     */   {
/* 200 */     Assert.notNull(interceptors, "A CallableProcessingInterceptor is required");
/* 201 */     for (CallableProcessingInterceptor interceptor : interceptors) {
/* 202 */       String key = interceptor.getClass().getName() + ":" + interceptor.hashCode();
/* 203 */       this.callableInterceptors.put(key, interceptor);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void registerDeferredResultInterceptor(Object key, DeferredResultProcessingInterceptor interceptor)
/*     */   {
/* 213 */     Assert.notNull(key, "Key is required");
/* 214 */     Assert.notNull(interceptor, "DeferredResultProcessingInterceptor is required");
/* 215 */     this.deferredResultInterceptors.put(key, interceptor);
/*     */   }
/*     */ 
/*     */   public void registerDeferredResultInterceptors(DeferredResultProcessingInterceptor[] interceptors)
/*     */   {
/* 224 */     Assert.notNull(interceptors, "A DeferredResultProcessingInterceptor is required");
/* 225 */     for (DeferredResultProcessingInterceptor interceptor : interceptors) {
/* 226 */       String key = interceptors.getClass().getName() + ":" + interceptors.hashCode();
/* 227 */       this.deferredResultInterceptors.put(key, interceptor);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void clearConcurrentResult()
/*     */   {
/* 236 */     this.concurrentResult = RESULT_NONE;
/* 237 */     this.concurrentResultContext = null;
/*     */   }
/*     */ 
/*     */   public void startCallableProcessing(Callable<?> callable, Object[] processingContext)
/*     */     throws Exception
/*     */   {
/* 257 */     Assert.notNull(callable, "Callable must not be null");
/* 258 */     startCallableProcessing(new WebAsyncTask(callable), processingContext);
/*     */   }
/*     */ 
/*     */   public void startCallableProcessing(WebAsyncTask<?> webAsyncTask, Object[] processingContext)
/*     */     throws Exception
/*     */   {
/* 272 */     Assert.notNull(webAsyncTask, "WebAsyncTask must not be null");
/* 273 */     Assert.state(this.asyncWebRequest != null, "AsyncWebRequest must not be null");
/*     */ 
/* 275 */     Long timeout = webAsyncTask.getTimeout();
/* 276 */     if (timeout != null) {
/* 277 */       this.asyncWebRequest.setTimeout(timeout);
/*     */     }
/*     */ 
/* 280 */     AsyncTaskExecutor executor = webAsyncTask.getExecutor();
/* 281 */     if (executor != null) {
/* 282 */       this.taskExecutor = executor;
/*     */     }
/*     */ 
/* 285 */     List interceptors = new ArrayList();
/* 286 */     interceptors.add(webAsyncTask.getInterceptor());
/* 287 */     interceptors.addAll(this.callableInterceptors.values());
/* 288 */     interceptors.add(timeoutCallableInterceptor);
/*     */ 
/* 290 */     Callable callable = webAsyncTask.getCallable();
/* 291 */     CallableInterceptorChain interceptorChain = new CallableInterceptorChain(interceptors);
/*     */ 
/* 293 */     this.asyncWebRequest.addTimeoutHandler(new Runnable(interceptorChain, callable) {
/*     */       public void run() {
/* 295 */         WebAsyncManager.logger.debug("Processing timeout");
/* 296 */         Object result = this.val$interceptorChain.triggerAfterTimeout(WebAsyncManager.this.asyncWebRequest, this.val$callable);
/* 297 */         if (result != CallableProcessingInterceptor.RESULT_NONE)
/* 298 */           WebAsyncManager.this.setConcurrentResultAndDispatch(result);
/*     */       }
/*     */     });
/* 303 */     this.asyncWebRequest.addCompletionHandler(new Runnable(interceptorChain, callable) {
/*     */       public void run() {
/* 305 */         this.val$interceptorChain.triggerAfterCompletion(WebAsyncManager.this.asyncWebRequest, this.val$callable);
/*     */       }
/*     */     });
/* 309 */     interceptorChain.applyBeforeConcurrentHandling(this.asyncWebRequest, callable);
/*     */ 
/* 311 */     startAsyncProcessing(processingContext);
/*     */ 
/* 313 */     this.taskExecutor.submit(new Runnable(interceptorChain, callable) {
/*     */       public void run() {
/* 315 */         Object result = null;
/*     */         try {
/* 317 */           this.val$interceptorChain.applyPreProcess(WebAsyncManager.this.asyncWebRequest, this.val$callable);
/* 318 */           result = this.val$callable.call();
/*     */         }
/*     */         catch (Throwable t) {
/* 321 */           result = t;
/*     */         }
/*     */         finally {
/* 324 */           result = this.val$interceptorChain.applyPostProcess(WebAsyncManager.this.asyncWebRequest, this.val$callable, result);
/*     */         }
/* 326 */         WebAsyncManager.this.setConcurrentResultAndDispatch(result);
/*     */       } } );
/*     */   }
/*     */ 
/*     */   private void setConcurrentResultAndDispatch(Object result) {
/* 332 */     synchronized (this) {
/* 333 */       if (hasConcurrentResult()) {
/* 334 */         return;
/*     */       }
/* 336 */       this.concurrentResult = result;
/*     */     }
/*     */ 
/* 339 */     if (this.asyncWebRequest.isAsyncComplete()) {
/* 340 */       logger.error("Could not complete async processing due to timeout or network error");
/* 341 */       return;
/*     */     }
/*     */ 
/* 344 */     logger.debug("Concurrent result value [" + this.concurrentResult + "]");
/* 345 */     logger.debug("Dispatching request to resume processing");
/*     */ 
/* 347 */     this.asyncWebRequest.dispatch();
/*     */   }
/*     */ 
/*     */   public void startDeferredResultProcessing(DeferredResult<?> deferredResult, Object[] processingContext)
/*     */     throws Exception
/*     */   {
/* 369 */     Assert.notNull(deferredResult, "DeferredResult must not be null");
/* 370 */     Assert.state(this.asyncWebRequest != null, "AsyncWebRequest must not be null");
/*     */ 
/* 372 */     Long timeout = deferredResult.getTimeoutValue();
/* 373 */     if (timeout != null) {
/* 374 */       this.asyncWebRequest.setTimeout(timeout);
/*     */     }
/*     */ 
/* 377 */     List interceptors = new ArrayList();
/* 378 */     interceptors.add(deferredResult.getInterceptor());
/* 379 */     interceptors.addAll(this.deferredResultInterceptors.values());
/* 380 */     interceptors.add(timeoutDeferredResultInterceptor);
/*     */ 
/* 382 */     DeferredResultInterceptorChain interceptorChain = new DeferredResultInterceptorChain(interceptors);
/*     */ 
/* 384 */     this.asyncWebRequest.addTimeoutHandler(new Runnable(interceptorChain, deferredResult) {
/*     */       public void run() {
/*     */         try {
/* 387 */           this.val$interceptorChain.triggerAfterTimeout(WebAsyncManager.this.asyncWebRequest, this.val$deferredResult);
/*     */         }
/*     */         catch (Throwable t) {
/* 390 */           WebAsyncManager.this.setConcurrentResultAndDispatch(t);
/*     */         }
/*     */       }
/*     */     });
/* 395 */     this.asyncWebRequest.addCompletionHandler(new Runnable(interceptorChain, deferredResult) {
/*     */       public void run() {
/* 397 */         this.val$interceptorChain.triggerAfterCompletion(WebAsyncManager.this.asyncWebRequest, this.val$deferredResult);
/*     */       }
/*     */     });
/* 401 */     interceptorChain.applyBeforeConcurrentHandling(this.asyncWebRequest, deferredResult);
/*     */ 
/* 403 */     startAsyncProcessing(processingContext);
/*     */     try
/*     */     {
/* 406 */       interceptorChain.applyPreProcess(this.asyncWebRequest, deferredResult);
/* 407 */       deferredResult.setResultHandler(new DeferredResult.DeferredResultHandler(interceptorChain, deferredResult) {
/*     */         public void handleResult(Object result) {
/* 409 */           result = this.val$interceptorChain.applyPostProcess(WebAsyncManager.this.asyncWebRequest, this.val$deferredResult, result);
/* 410 */           WebAsyncManager.this.setConcurrentResultAndDispatch(result);
/*     */         } } );
/*     */     }
/*     */     catch (Throwable t) {
/* 415 */       setConcurrentResultAndDispatch(t);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void startAsyncProcessing(Object[] processingContext)
/*     */   {
/* 421 */     clearConcurrentResult();
/* 422 */     this.concurrentResultContext = processingContext;
/*     */ 
/* 424 */     this.asyncWebRequest.startAsync();
/*     */ 
/* 426 */     if (logger.isDebugEnabled()) {
/* 427 */       HttpServletRequest request = (HttpServletRequest)this.asyncWebRequest.getNativeRequest(HttpServletRequest.class);
/* 428 */       String requestUri = urlPathHelper.getRequestUri(request);
/* 429 */       logger.debug("Concurrent handling starting for " + request.getMethod() + " [" + requestUri + "]");
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.request.async.WebAsyncManager
 * JD-Core Version:    0.6.0
 */