package org.springframework.web.context.request;

public abstract interface AsyncWebRequestInterceptor extends WebRequestInterceptor
{
  public abstract void afterConcurrentHandlingStarted(WebRequest paramWebRequest);
}

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.request.AsyncWebRequestInterceptor
 * JD-Core Version:    0.6.0
 */