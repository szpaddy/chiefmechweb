/*    */ package org.springframework.web.context;
/*    */ 
/*    */ import javax.servlet.ServletContext;
/*    */ import javax.servlet.ServletException;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.web.WebApplicationInitializer;
/*    */ 
/*    */ public abstract class AbstractContextLoaderInitializer
/*    */   implements WebApplicationInitializer
/*    */ {
/* 42 */   protected final Log logger = LogFactory.getLog(getClass());
/*    */ 
/*    */   public void onStartup(ServletContext servletContext) throws ServletException {
/* 45 */     registerContextLoaderListener(servletContext);
/*    */   }
/*    */ 
/*    */   protected void registerContextLoaderListener(ServletContext servletContext)
/*    */   {
/* 55 */     WebApplicationContext rootAppContext = createRootApplicationContext();
/* 56 */     if (rootAppContext != null) {
/* 57 */       servletContext.addListener(new ContextLoaderListener(rootAppContext));
/*    */     }
/*    */     else
/* 60 */       this.logger.debug("No ContextLoaderListener registered, as createRootApplicationContext() did not return an application context");
/*    */   }
/*    */ 
/*    */   protected abstract WebApplicationContext createRootApplicationContext();
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.AbstractContextLoaderInitializer
 * JD-Core Version:    0.6.0
 */