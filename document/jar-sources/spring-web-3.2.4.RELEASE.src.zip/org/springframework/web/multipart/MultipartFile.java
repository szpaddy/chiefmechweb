package org.springframework.web.multipart;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;

public abstract interface MultipartFile
{
  public abstract String getName();

  public abstract String getOriginalFilename();

  public abstract String getContentType();

  public abstract boolean isEmpty();

  public abstract long getSize();

  public abstract byte[] getBytes()
    throws IOException;

  public abstract InputStream getInputStream()
    throws IOException;

  public abstract void transferTo(File paramFile)
    throws IOException, IllegalStateException;
}

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.web.multipart.MultipartFile
 * JD-Core Version:    0.6.0
 */