/*    */ package org.springframework.web.multipart;
/*    */ 
/*    */ public class MaxUploadSizeExceededException extends MultipartException
/*    */ {
/*    */   private final long maxUploadSize;
/*    */ 
/*    */   public MaxUploadSizeExceededException(long maxUploadSize)
/*    */   {
/* 37 */     this(maxUploadSize, null);
/*    */   }
/*    */ 
/*    */   public MaxUploadSizeExceededException(long maxUploadSize, Throwable ex)
/*    */   {
/* 46 */     super("Maximum upload size of " + maxUploadSize + " bytes exceeded", ex);
/* 47 */     this.maxUploadSize = maxUploadSize;
/*    */   }
/*    */ 
/*    */   public long getMaxUploadSize()
/*    */   {
/* 55 */     return this.maxUploadSize;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.web.multipart.MaxUploadSizeExceededException
 * JD-Core Version:    0.6.0
 */