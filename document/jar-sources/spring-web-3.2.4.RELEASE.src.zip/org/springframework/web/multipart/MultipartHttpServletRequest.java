package org.springframework.web.multipart;

import javax.servlet.http.HttpServletRequest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;

public abstract interface MultipartHttpServletRequest extends HttpServletRequest, MultipartRequest
{
  public abstract HttpMethod getRequestMethod();

  public abstract HttpHeaders getRequestHeaders();

  public abstract HttpHeaders getMultipartHeaders(String paramString);
}

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.web.multipart.MultipartHttpServletRequest
 * JD-Core Version:    0.6.0
 */