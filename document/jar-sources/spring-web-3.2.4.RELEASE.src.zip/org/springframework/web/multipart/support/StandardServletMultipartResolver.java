/*    */ package org.springframework.web.multipart.support;
/*    */ 
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.Part;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.web.multipart.MultipartException;
/*    */ import org.springframework.web.multipart.MultipartHttpServletRequest;
/*    */ import org.springframework.web.multipart.MultipartResolver;
/*    */ 
/*    */ public class StandardServletMultipartResolver
/*    */   implements MultipartResolver
/*    */ {
/*    */   public boolean isMultipart(HttpServletRequest request)
/*    */   {
/* 50 */     if (!"post".equals(request.getMethod().toLowerCase())) {
/* 51 */       return false;
/*    */     }
/* 53 */     String contentType = request.getContentType();
/* 54 */     return (contentType != null) && (contentType.toLowerCase().startsWith("multipart/"));
/*    */   }
/*    */ 
/*    */   public MultipartHttpServletRequest resolveMultipart(HttpServletRequest request) throws MultipartException {
/* 58 */     return new StandardMultipartHttpServletRequest(request);
/*    */   }
/*    */ 
/*    */   public void cleanupMultipart(MultipartHttpServletRequest request)
/*    */   {
/*    */     try
/*    */     {
/* 65 */       for (Part part : request.getParts()) {
/* 66 */         if (request.getFile(part.getName()) != null)
/* 67 */           part.delete();
/*    */       }
/*    */     }
/*    */     catch (Exception ex)
/*    */     {
/* 72 */       LogFactory.getLog(getClass()).warn("Failed to perform cleanup of multipart items", ex);
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.web.multipart.support.StandardServletMultipartResolver
 * JD-Core Version:    0.6.0
 */