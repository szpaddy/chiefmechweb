/*     */ package org.springframework.web.multipart.support;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.Part;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.util.FileCopyUtils;
/*     */ import org.springframework.util.LinkedMultiValueMap;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.web.multipart.MultipartException;
/*     */ import org.springframework.web.multipart.MultipartFile;
/*     */ 
/*     */ public class StandardMultipartHttpServletRequest extends AbstractMultipartHttpServletRequest
/*     */ {
/*     */   private static final String CONTENT_DISPOSITION = "content-disposition";
/*     */   private static final String FILENAME_KEY = "filename=";
/*     */ 
/*     */   public StandardMultipartHttpServletRequest(HttpServletRequest request)
/*     */     throws MultipartException
/*     */   {
/*  55 */     super(request);
/*     */     try {
/*  57 */       Collection parts = request.getParts();
/*  58 */       MultiValueMap files = new LinkedMultiValueMap(parts.size());
/*  59 */       for (Part part : parts) {
/*  60 */         String filename = extractFilename(part.getHeader("content-disposition"));
/*  61 */         if (filename != null) {
/*  62 */           files.add(part.getName(), new StandardMultipartFile(part, filename));
/*     */         }
/*     */       }
/*  65 */       setMultipartFiles(files);
/*     */     }
/*     */     catch (Exception ex) {
/*  68 */       throw new MultipartException("Could not parse multipart servlet request", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   private String extractFilename(String contentDisposition) {
/*  73 */     if (contentDisposition == null) {
/*  74 */       return null;
/*     */     }
/*     */ 
/*  77 */     int startIndex = contentDisposition.indexOf("filename=");
/*  78 */     if (startIndex == -1) {
/*  79 */       return null;
/*     */     }
/*  81 */     String filename = contentDisposition.substring(startIndex + "filename=".length());
/*  82 */     if (filename.startsWith("\"")) {
/*  83 */       int endIndex = filename.indexOf("\"", 1);
/*  84 */       if (endIndex != -1)
/*  85 */         return filename.substring(1, endIndex);
/*     */     }
/*     */     else
/*     */     {
/*  89 */       int endIndex = filename.indexOf(";");
/*  90 */       if (endIndex != -1) {
/*  91 */         return filename.substring(0, endIndex);
/*     */       }
/*     */     }
/*  94 */     return filename;
/*     */   }
/*     */ 
/*     */   public String getMultipartContentType(String paramOrFileName)
/*     */   {
/*     */     try {
/* 100 */       Part part = getPart(paramOrFileName);
/* 101 */       return part != null ? part.getContentType() : null;
/*     */     } catch (Exception ex) {
/*     */     }
/* 104 */     throw new MultipartException("Could not access multipart servlet request", ex);
/*     */   }
/*     */ 
/*     */   public HttpHeaders getMultipartHeaders(String paramOrFileName)
/*     */   {
/*     */     try {
/* 110 */       Part part = getPart(paramOrFileName);
/* 111 */       if (part != null) {
/* 112 */         HttpHeaders headers = new HttpHeaders();
/* 113 */         for (String headerName : part.getHeaderNames()) {
/* 114 */           headers.put(headerName, new ArrayList(part.getHeaders(headerName)));
/*     */         }
/* 116 */         return headers;
/*     */       }
/*     */ 
/* 119 */       return null;
/*     */     }
/*     */     catch (Exception ex) {
/*     */     }
/* 123 */     throw new MultipartException("Could not access multipart servlet request", ex);
/*     */   }
/*     */ 
/*     */   private static class StandardMultipartFile
/*     */     implements MultipartFile
/*     */   {
/*     */     private final Part part;
/*     */     private final String filename;
/*     */ 
/*     */     public StandardMultipartFile(Part part, String filename)
/*     */     {
/* 138 */       this.part = part;
/* 139 */       this.filename = filename;
/*     */     }
/*     */ 
/*     */     public String getName() {
/* 143 */       return this.part.getName();
/*     */     }
/*     */ 
/*     */     public String getOriginalFilename() {
/* 147 */       return this.filename;
/*     */     }
/*     */ 
/*     */     public String getContentType() {
/* 151 */       return this.part.getContentType();
/*     */     }
/*     */ 
/*     */     public boolean isEmpty() {
/* 155 */       return this.part.getSize() == 0L;
/*     */     }
/*     */ 
/*     */     public long getSize() {
/* 159 */       return this.part.getSize();
/*     */     }
/*     */ 
/*     */     public byte[] getBytes() throws IOException {
/* 163 */       return FileCopyUtils.copyToByteArray(this.part.getInputStream());
/*     */     }
/*     */ 
/*     */     public InputStream getInputStream() throws IOException {
/* 167 */       return this.part.getInputStream();
/*     */     }
/*     */ 
/*     */     public void transferTo(File dest) throws IOException, IllegalStateException {
/* 171 */       this.part.write(dest.getPath());
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.web.multipart.support.StandardMultipartHttpServletRequest
 * JD-Core Version:    0.6.0
 */