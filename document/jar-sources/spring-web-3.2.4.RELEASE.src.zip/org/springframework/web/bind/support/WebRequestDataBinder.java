/*     */ package org.springframework.web.bind.support;
/*     */ 
/*     */ import org.springframework.beans.MutablePropertyValues;
/*     */ import org.springframework.validation.BindException;
/*     */ import org.springframework.validation.BindingResult;
/*     */ import org.springframework.web.bind.WebDataBinder;
/*     */ import org.springframework.web.context.request.NativeWebRequest;
/*     */ import org.springframework.web.context.request.WebRequest;
/*     */ import org.springframework.web.multipart.MultipartRequest;
/*     */ 
/*     */ public class WebRequestDataBinder extends WebDataBinder
/*     */ {
/*     */   public WebRequestDataBinder(Object target)
/*     */   {
/*  69 */     super(target);
/*     */   }
/*     */ 
/*     */   public WebRequestDataBinder(Object target, String objectName)
/*     */   {
/*  79 */     super(target, objectName);
/*     */   }
/*     */ 
/*     */   public void bind(WebRequest request)
/*     */   {
/* 102 */     MutablePropertyValues mpvs = new MutablePropertyValues(request.getParameterMap());
/* 103 */     if ((request instanceof NativeWebRequest)) {
/* 104 */       MultipartRequest multipartRequest = (MultipartRequest)((NativeWebRequest)request).getNativeRequest(MultipartRequest.class);
/* 105 */       if (multipartRequest != null) {
/* 106 */         bindMultipart(multipartRequest.getMultiFileMap(), mpvs);
/*     */       }
/*     */     }
/* 109 */     doBind(mpvs);
/*     */   }
/*     */ 
/*     */   public void closeNoCatch()
/*     */     throws BindException
/*     */   {
/* 119 */     if (getBindingResult().hasErrors())
/* 120 */       throw new BindException(getBindingResult());
/*     */   }
/*     */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.web.bind.support.WebRequestDataBinder
 * JD-Core Version:    0.6.0
 */