package org.springframework.web.bind.support;

import org.springframework.web.context.request.WebRequest;

public abstract interface SessionAttributeStore
{
  public abstract void storeAttribute(WebRequest paramWebRequest, String paramString, Object paramObject);

  public abstract Object retrieveAttribute(WebRequest paramWebRequest, String paramString);

  public abstract void cleanupAttribute(WebRequest paramWebRequest, String paramString);
}

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.web.bind.support.SessionAttributeStore
 * JD-Core Version:    0.6.0
 */