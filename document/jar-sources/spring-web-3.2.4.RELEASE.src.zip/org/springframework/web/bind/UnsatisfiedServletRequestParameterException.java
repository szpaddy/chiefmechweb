/*    */ package org.springframework.web.bind;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ import java.util.Map;
/*    */ import java.util.Map.Entry;
/*    */ import java.util.Set;
/*    */ import org.springframework.util.ObjectUtils;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ public class UnsatisfiedServletRequestParameterException extends ServletRequestBindingException
/*    */ {
/*    */   private final String[] paramConditions;
/*    */   private final Map<String, String[]> actualParams;
/*    */ 
/*    */   public UnsatisfiedServletRequestParameterException(String[] paramConditions, Map actualParams)
/*    */   {
/* 49 */     super("");
/* 50 */     this.paramConditions = paramConditions;
/* 51 */     this.actualParams = actualParams;
/*    */   }
/*    */ 
/*    */   public String getMessage()
/*    */   {
/* 57 */     return "Parameter conditions \"" + StringUtils.arrayToDelimitedString(this.paramConditions, ", ") + "\" not met for actual request parameters: " + requestParameterMapToString(this.actualParams);
/*    */   }
/*    */ 
/*    */   private static String requestParameterMapToString(Map<String, String[]> actualParams)
/*    */   {
/* 62 */     StringBuilder result = new StringBuilder();
/* 63 */     for (Iterator it = actualParams.entrySet().iterator(); it.hasNext(); ) {
/* 64 */       Map.Entry entry = (Map.Entry)it.next();
/* 65 */       result.append((String)entry.getKey()).append('=').append(ObjectUtils.nullSafeToString((Object[])entry.getValue()));
/* 66 */       if (it.hasNext()) {
/* 67 */         result.append(", ");
/*    */       }
/*    */     }
/* 70 */     return result.toString();
/*    */   }
/*    */ 
/*    */   public final String[] getParamConditions()
/*    */   {
/* 78 */     return this.paramConditions;
/*    */   }
/*    */ 
/*    */   public final Map<String, String[]> getActualParams()
/*    */   {
/* 86 */     return this.actualParams;
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.web.bind.UnsatisfiedServletRequestParameterException
 * JD-Core Version:    0.6.0
 */