/*    */ package org.springframework.web.bind.annotation;
/*    */ 
/*    */ public enum RequestMethod
/*    */ {
/* 39 */   GET, HEAD, POST, PUT, PATCH, DELETE, OPTIONS, TRACE;
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.web.bind.annotation.RequestMethod
 * JD-Core Version:    0.6.0
 */