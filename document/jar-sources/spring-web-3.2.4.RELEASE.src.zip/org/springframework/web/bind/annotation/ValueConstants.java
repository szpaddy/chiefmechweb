package org.springframework.web.bind.annotation;

public abstract interface ValueConstants
{
  public static final String DEFAULT_NONE = "\n\t\t\n\t\t\n\n\t\t\t\t\n";
}

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.web.bind.annotation.ValueConstants
 * JD-Core Version:    0.6.0
 */