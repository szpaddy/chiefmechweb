/*    */ package org.springframework.web.bind;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import org.springframework.core.MethodParameter;
/*    */ import org.springframework.validation.BindingResult;
/*    */ import org.springframework.validation.ObjectError;
/*    */ 
/*    */ public class MethodArgumentNotValidException extends Exception
/*    */ {
/*    */   private final MethodParameter parameter;
/*    */   private final BindingResult bindingResult;
/*    */ 
/*    */   public MethodArgumentNotValidException(MethodParameter parameter, BindingResult bindingResult)
/*    */   {
/* 43 */     this.parameter = parameter;
/* 44 */     this.bindingResult = bindingResult;
/*    */   }
/*    */ 
/*    */   public MethodParameter getParameter()
/*    */   {
/* 51 */     return this.parameter;
/*    */   }
/*    */ 
/*    */   public BindingResult getBindingResult()
/*    */   {
/* 58 */     return this.bindingResult;
/*    */   }
/*    */ 
/*    */   public String getMessage()
/*    */   {
/* 64 */     StringBuilder sb = new StringBuilder("Validation failed for argument at index ").append(this.parameter.getParameterIndex()).append(" in method: ").append(this.parameter.getMethod().toGenericString()).append(", with ").append(this.bindingResult.getErrorCount()).append(" error(s): ");
/*    */ 
/* 68 */     for (ObjectError error : this.bindingResult.getAllErrors()) {
/* 69 */       sb.append("[").append(error).append("] ");
/*    */     }
/* 71 */     return sb.toString();
/*    */   }
/*    */ }

/* Location:           D:\JavaServer\Workspace\chiefmechweb\WebContent\WEB-INF\lib\spring-web-3.2.4.RELEASE.jar
 * Qualified Name:     org.springframework.web.bind.MethodArgumentNotValidException
 * JD-Core Version:    0.6.0
 */